<?php
// ============================================
// UTILIDADES PARA PROVEEDORES
// ============================================
// Este archivo centraliza toda la lógica de detección
// y verificación de proveedores para toda la plataforma
// ============================================

/**
 * Obtiene el proveedor_id del usuario actual
 * @param mysqli $conn Conexión a la base de datos
 * @param int $usuario_id ID del usuario
 * @param string $rol Nombre del rol
 * @return int ID del proveedor (0 si es rol de sistema)
 */
function obtenerProveedorId($conn, $usuario_id, $rol) {
    $roles_con_proveedor = ['Proveedor', 'Inventario', 'Vendedor', 'Empaquetador', 'Transportista'];
    
    // Si no es rol de proveedor, retorna 0 (sistema)
    if (!in_array($rol, $roles_con_proveedor)) {
        return 0;
    }
    
    // Buscar en la tabla usuario_proveedor
    $stmt = $conn->prepare("SELECT proveedor_id FROM usuario_proveedor WHERE usuario_id = ? AND activo = 1");
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return (int)$row['proveedor_id'];
    }
    
    return 0;
}

/**
 * Verifica si un rol es de proveedor
 * @param string $rol Nombre del rol
 * @return bool True si es rol de proveedor
 */
function esRolProveedor($rol) {
    $roles_con_proveedor = ['Proveedor', 'Inventario', 'Vendedor', 'Empaquetador', 'Transportista'];
    return in_array($rol, $roles_con_proveedor);
}

/**
 * Verifica si un producto pertenece al proveedor
 * @param mysqli $conn Conexión a la base de datos
 * @param int $producto_id ID del producto
 * @param int $proveedor_id ID del proveedor
 * @return bool True si el producto pertenece al proveedor
 */
function productoPerteneceAProveedor($conn, $producto_id, $proveedor_id) {
    // Si es usuario de sistema (proveedor_id = 0), puede ver todo
    if ($proveedor_id == 0) {
        return true;
    }
    
    $stmt = $conn->prepare("SELECT id FROM productos WHERE id = ? AND proveedor_id = ?");
    $stmt->bind_param("ii", $producto_id, $proveedor_id);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

/**
 * Verifica si un combo pertenece al proveedor
 * @param mysqli $conn Conexión a la base de datos
 * @param int $combo_id ID del combo
 * @param int $proveedor_id ID del proveedor
 * @return bool True si el combo pertenece al proveedor
 */
function comboPerteneceAProveedor($conn, $combo_id, $proveedor_id) {
    if ($proveedor_id == 0) {
        return true;
    }
    
    $stmt = $conn->prepare("SELECT id FROM combos WHERE id = ? AND proveedor_id = ?");
    $stmt->bind_param("ii", $combo_id, $proveedor_id);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

/**
 * Verifica si un pedido pertenece al proveedor
 * @param mysqli $conn Conexión a la base de datos
 * @param int $pedido_id ID del pedido
 * @param int $proveedor_id ID del proveedor
 * @return bool True si el pedido pertenece al proveedor
 */
function pedidoPerteneceAProveedor($conn, $pedido_id, $proveedor_id) {
    if ($proveedor_id == 0) {
        return true;
    }
    
    $stmt = $conn->prepare("
        SELECT p.id 
        FROM pedidos p
        INNER JOIN pedido_detalles pd ON p.id = pd.pedido_id
        WHERE p.id = ? AND pd.proveedor_id = ?
        GROUP BY p.id
    ");
    $stmt->bind_param("ii", $pedido_id, $proveedor_id);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

/**
 * Obtiene el nombre de la tienda del proveedor
 * @param mysqli $conn Conexión a la base de datos
 * @param int $proveedor_id ID del proveedor
 * @return string Nombre de la tienda
 */
function obtenerNombreTienda($conn, $proveedor_id) {
    if ($proveedor_id == 0) {
        return 'Catalejoo';
    }
    
    $stmt = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['nombre_tienda'];
    }
    
    return 'Catalejoo';
}

/**
 * Genera condición WHERE para filtrar por proveedor
 * @param int $proveedor_id ID del proveedor
 * @param string $alias Alias de la tabla (opcional)
 * @return string Condición WHERE o cadena vacía
 */
function filtroProveedorSQL($proveedor_id, $alias = '') {
    if ($proveedor_id == 0) {
        return '';
    }
    $tabla = $alias ? "$alias." : "";
    return " AND {$tabla}proveedor_id = $proveedor_id";
}

/**
 * Obtiene el ID del proveedor desde la URL (para acciones)
 * @param mysqli $conn Conexión a la base de datos
 * @param int $usuario_id ID del usuario
 * @param string $rol Nombre del rol
 * @param int $proveedor_url ID de proveedor desde URL (opcional)
 * @return int ID del proveedor validado
 */
function obtenerProveedorValidado($conn, $usuario_id, $rol, $proveedor_url = 0) {
    $proveedor_id = obtenerProveedorId($conn, $usuario_id, $rol);
    
    // Si es usuario de sistema y se pasó un proveedor por URL, validarlo
    if ($proveedor_id == 0 && $proveedor_url > 0) {
        $stmt = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
        $stmt->bind_param("i", $proveedor_url);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            return $proveedor_url;
        }
        return 0;
    }
    
    return $proveedor_id;
}

/**
 * Verifica si el usuario tiene permiso para ver/editar un proveedor específico
 * @param int $proveedor_usuario ID del proveedor del usuario
 * @param int $proveedor_objetivo ID del proveedor que se quiere ver/editar
 * @return bool True si tiene permiso
 */
function tienePermisoProveedor($proveedor_usuario, $proveedor_objetivo) {
    // Si es usuario de sistema (0), puede ver todo
    if ($proveedor_usuario == 0) {
        return true;
    }
    // Si es proveedor, solo puede ver el suyo
    return $proveedor_usuario == $proveedor_objetivo;
}
<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}
    
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';
require_once __DIR__ . '/moneda_funciones.php';

// ============================================
// SESIÓN (necesaria para caché de moneda)
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

header('Content-Type: text/html; charset=utf-8');

// ============================================
// RECIBIR PROVEEDOR Y CALCULAR FILTRO
// ============================================
$proveedor_slug = isset($_GET['proveedor']) ? trim($_GET['proveedor']) : '';
$proveedor_id = 0;

if (!empty($proveedor_slug)) {
    $stmt_prov = $conn->prepare("SELECT id FROM proveedores WHERE slug = ? AND activo = 1");
    $stmt_prov->bind_param("s", $proveedor_slug);
    $stmt_prov->execute();
    $result_prov = $stmt_prov->get_result();
    if ($row = $result_prov->fetch_assoc()) {
        $proveedor_id = $row['id'];
    }
    $stmt_prov->close();
}

// Determinar proveedor filtro (URL > usuario logueado > 0)
$proveedor_filtro_id = 0;
if ($proveedor_id > 0) {
    $proveedor_filtro_id = $proveedor_id;
} elseif ($es_proveedor && $proveedor_id_usuario > 0) {
    $proveedor_filtro_id = $proveedor_id_usuario;
}

// ============================================
// DETERMINAR MONEDA (según proveedor y cliente)
// ============================================
require_once __DIR__ . '/cliente_identificador.php';

$cliente = obtenerClienteActual($conn);
$cliente_registrado = (!empty($cliente['id']) && $cliente['id'] > 0);

$moneda_actual = getMonedaParaProveedor($conn, $proveedor_filtro_id, $cliente);
$moneda_simbolo = getSimboloPorMoneda($moneda_actual);
$moneda_codigo = $moneda_actual;

$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
$limite = isset($_GET['limite']) ? intval($_GET['limite']) : 12;

// Obtener configuración
$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion");
while($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}

$sitio_nombre = $config['sitio_nombre'] ?? 'TiendaVirtual';
// $moneda_simbolo y $moneda_codigo ya están calculados arriba

// ===== CONSULTA DE COMBOS CON FILTRO DE PROVEEDOR =====
$sql = "SELECT c.*, 
               (SELECT COUNT(*) FROM combo_productos WHERE combo_id = c.id) as productos_distintos,
               (SELECT SUM(cantidad) FROM combo_productos WHERE combo_id = c.id) as unidades_totales
        FROM combos c 
        WHERE c.activo = 1 ";

// $proveedor_filtro_id ya está calculado arriba

if ($proveedor_filtro_id > 0) {
    $sql .= " AND c.proveedor_id = " . intval($proveedor_filtro_id) . " ";
}

$sql .= " ORDER BY c.fecha_creacion DESC 
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $limite, $offset);
$stmt->execute();
$combos = $stmt->get_result();

while($combo = $combos->fetch_assoc()):
    $productos_distintos = intval($combo['productos_distintos']);
    $unidades_totales = intval($combo['unidades_totales']);
    include __DIR__ . '/../combo_card.php';
endwhile;

$conn->close();
?>
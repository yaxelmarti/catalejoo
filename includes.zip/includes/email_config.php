<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/PHPMailer/Exception.php';
require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';
require_once __DIR__ . '/../conexion.php';

// ============================================
// URL BASE DEL SITIO (para uso en emails)
// ============================================
if (!defined('BASE_URL')) {
    $base_url_tmp = '';
    if (isset($conn) && $conn instanceof mysqli) {
        $stmt_url = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'sitio_url' AND proveedor_id = 0 LIMIT 1");
        if ($stmt_url) {
            $stmt_url->execute();
            $res_url = $stmt_url->get_result()->fetch_assoc();
            $stmt_url->close();
            if (!empty($res_url['valor'])) {
                $base_url_tmp = rtrim($res_url['valor'], '/');
            }
        }
    }
    
    if (empty($base_url_tmp)) {
        $base_url_tmp = 'https://catalejoo.com';
    }
    
    define('BASE_URL', $base_url_tmp);
}

/**
 * Función base para enviar correos
 */
function enviarCorreoBase($destinatario, $asunto, $cuerpoHTML, $cuerpoTexto = '') {
    global $conn;
    
    // Validar destinatario
    if (empty($destinatario) || !filter_var($destinatario, FILTER_VALIDATE_EMAIL)) {
        error_log("[enviarCorreoBase] Email inválido: " . $destinatario);
        return false;
    }
    
    // Obtener configuraciones de email desde la base de datos
    $config = [];
    $stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE clave IN ('smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_encryption', 'sitio_nombre', 'sitio_email')");
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $config[$row['clave']] = $row['valor'];
    }
    $stmt->close();
    
    // Valores por defecto
    $smtp_host = $config['smtp_host'] ?? 'smtp.gmail.com';
    $smtp_port = $config['smtp_port'] ?? '587';
    $smtp_user = $config['smtp_user'] ?? '';
    $smtp_pass = $config['smtp_pass'] ?? '';
    $smtp_encryption = $config['smtp_encryption'] ?? 'tls';
    $sitio_nombre = $config['sitio_nombre'] ?? 'Mi Tienda';
    $sitio_email = $config['sitio_email'] ?? $smtp_user;
    
        $mail = new PHPMailer(true);
    
    // Timeout de 10 segundos para evitar cuelgues
    $mail->Timeout = 10;
    $mail->SMTPDebug = 0;
    
    try {
        // Configuración SMTP
        $mail->isSMTP();
        $mail->Host       = $smtp_host;
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp_user;
        $mail->Password   = $smtp_pass;
        $mail->SMTPSecure = $smtp_encryption === 'tls' ? PHPMailer::ENCRYPTION_STARTTLS : PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = intval($smtp_port);
        $mail->CharSet    = 'UTF-8';
        
        // Remitente y destinatario
        $mail->setFrom($sitio_email, $sitio_nombre);
        $mail->addAddress($destinatario);
        
        // Contenido
        $mail->isHTML(true);
        $mail->Subject = '=?UTF-8?B?' . base64_encode($asunto) . '?=';
        $mail->Body    = $cuerpoHTML;
        $mail->AltBody = $cuerpoTexto ?: strip_tags($cuerpoHTML);
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("[enviarCorreoBase] Error SMTP: " . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Enviar email con nueva contraseña (ya existente)
 */
function enviarEmailNuevaPassword($destinatario, $nueva_password) {
    $asunto = 'Nueva contraseña';
    $cuerpoHTML = "
        <html>
        <head>
            <title>Nueva contraseña</title>
        </head>
        <body>
            <h2>Recuperación de contraseña</h2>
            <p>Has solicitado una nueva contraseña. Aquí está:</p>
            <p style='font-size: 24px; background: #f0f0f0; padding: 10px; text-align: center;'>
                <strong>$nueva_password</strong>
            </p>
            <p>Puedes cambiarla después en el panel de cliente.</p>
        </body>
        </html>
    ";
    
    return enviarCorreoBase($destinatario, $asunto, $cuerpoHTML);
}

/**
 * Enviar factura de pedido (usa las plantillas de email_templates.php)
 */
function enviarFacturaPedido($pedido_id, $accion) {
    require_once __DIR__ . '/email_functions.php';
    return enviarNotificacionPedido($pedido_id, $accion);
}
?>
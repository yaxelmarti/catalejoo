<?php
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    $stmt = $conn->prepare("SELECT nombre, icono FROM categorias WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo json_encode(['nombre' => $row['nombre'], 'icono' => $row['icono'] ?? '📁']);
    } else {
        echo json_encode(['nombre' => 'Categoría', 'icono' => '📁']);
    }
} else {
    echo json_encode(['nombre' => 'Productos', 'icono' => '🛍️']);
}
?>
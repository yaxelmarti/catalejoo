<?php
// ============================================
// OBTENER MUNICIPIOS POR PROVINCIA (AJAX)
// ============================================
// Devuelve los municipios activos de una provincia
// con el costo de envío según el proveedor

// 1. Configurar cookies de sesión seguras
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Conexión y archivos necesarios
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/proveedor_utils.php';
require_once __DIR__ . '/cliente_identificador.php';
require_once __DIR__ . '/carrito_funciones.php';
require_once __DIR__ . '/moneda_funciones.php';

// 3. Solo aceptar GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// 4. Obtener parámetros
$provincia_id = isset($_GET['provincia_id']) ? intval($_GET['provincia_id']) : 0;
$proveedor_id = isset($_GET['proveedor_id']) ? intval($_GET['proveedor_id']) : 0;

// 5. Validar provincia_id
if ($provincia_id <= 0) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit;
}

// 6. Detectar proveedor del usuario logueado (seguridad)
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

// 7. Validar que el proveedor existe y está activo
if ($proveedor_id > 0) {
    $check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $check->bind_param("i", $proveedor_id);
    $check->execute();
    $check_result = $check->get_result();
    
    if ($check_result->num_rows === 0) {
        $proveedor_id = 0;
    }
    $check->close();
}

// 8. Seguridad: si es proveedor, solo puede ver sus propios municipios
if ($es_proveedor && $proveedor_id_usuario > 0 && $proveedor_id > 0 && $proveedor_id != $proveedor_id_usuario) {
    $proveedor_id = $proveedor_id_usuario;
}

// 9. Obtener municipios con su costo (personalizado o global)
if ($proveedor_id > 0) {
    $sql = "
        SELECT 
            m.id,
            m.nombre AS municipio,
            COALESCE(pec.costo_personalizado, ce.costo) AS costo
        FROM municipios m
        INNER JOIN proveedor_envio_config pec 
            ON pec.municipio_id = m.id 
            AND pec.proveedor_id = ? 
            AND pec.activo = 1
        LEFT JOIN costos_envio ce 
            ON ce.municipio_id = m.id 
            AND ce.proveedor_id = 0 
            AND ce.activo = 1
        WHERE m.provincia_id = ? AND m.activo = 1
        HAVING costo IS NOT NULL
        ORDER BY m.nombre
    ";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        error_log("Error en prepare (municipios proveedor): " . $conn->error);
        header('Content-Type: application/json');
        http_response_code(500);
        echo json_encode(['error' => 'Error interno']);
        exit;
    }
    
    $stmt->bind_param("ii", $proveedor_id, $provincia_id);
} else {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit;
}

$stmt->execute();
$result = $stmt->get_result();
$municipios = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ============================================
// 9.5. CONVERTIR COSTO DE ENVÍO A LA MONEDA DE LA COMPRA
// ============================================
$moneda_envio = 'USD';

// 1. Prioridad: carrito pendiente del mismo proveedor
$cliente_actual = obtenerClienteActual($conn);
$carrito_actual = null;
if (!empty($cliente_actual['id'])) {
    $carrito_actual = iniciarCarrito($conn, $cliente_actual['id']);
}

if ($carrito_actual && intval($carrito_actual['proveedor_id']) === $proveedor_id) {
    $moneda_envio = $carrito_actual['moneda'] ?? 'USD';
} elseif (!empty($cliente_actual['id'])) {
    // 2. Selector de moneda en sesión
    if (!empty($_SESSION['moneda_proveedor_' . $proveedor_id])) {
        $moneda_envio = $_SESSION['moneda_proveedor_' . $proveedor_id];
    } else {
        // 3. Lógica estándar
        $moneda_envio = getMonedaParaProveedor($conn, $proveedor_id, $cliente_actual);
    }
} else {
    // 4. Visitante
    $moneda_envio = getMonedaParaProveedor($conn, $proveedor_id, null);
}

// Convertir cada costo si la moneda no es USD
if ($moneda_envio !== 'USD' && !empty($municipios)) {
    // Calcular la tasa UNA SOLA VEZ
    $tasa_envio = getTasaProveedor($conn, $proveedor_id, $moneda_envio);
    
    if ($tasa_envio > 0) {
        foreach ($municipios as &$mun) {
            $mun['costo'] = round(floatval($mun['costo']) * $tasa_envio, 2);
        }
        unset($mun);
    }
}

// Añadir metadatos de moneda a cada municipio (escalable)
// Solo si hay municipios, para no hacer queries innecesarias
if (!empty($municipios)) {
    $simbolo_envio = getSimboloPorMoneda($moneda_envio);
    foreach ($municipios as &$mun) {
        $mun['moneda'] = $moneda_envio;
        $mun['simbolo'] = $simbolo_envio;
    }
    unset($mun);
}

header('Content-Type: application/json');
echo json_encode($municipios);

$conn->close();
?>
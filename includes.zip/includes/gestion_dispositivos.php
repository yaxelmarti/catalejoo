<?php
// ============================================
// GESTOR DE DISPOSITIVOS
// ============================================
// Este archivo maneja la gestión de dispositivos vinculados a un cliente
// ============================================

/**
 * Obtiene la lista de dispositivos vinculados a un cliente
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @return array Lista de dispositivos con su información
 */
function obtenerDispositivosCliente($conn, $cliente_id) {
    $stmt = $conn->prepare("SELECT 
        uuid, uuid2, uuid3,
        dispositivo_info_1, dispositivo_info_2, dispositivo_info_3,
        ip_1, ip_2, ip_3,
        ultimo_uso_1, ultimo_uso_2, ultimo_uso_3,
        fecha_asignacion_1, fecha_asignacion_2, fecha_asignacion_3
        FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente) {
        return [];
    }
    
    $dispositivos = [];
    $campos = ['uuid' => 1, 'uuid2' => 2, 'uuid3' => 3];
    
    foreach ($campos as $campo => $num) {
        if (!empty($cliente[$campo])) {
            $dispositivos[] = [
                'uuid' => $cliente[$campo],
                'campo' => $campo,
                'info' => $cliente['dispositivo_info_' . $num] ?? 'Dispositivo desconocido',
                'ip' => $cliente['ip_' . $num] ?? 'IP desconocida',
                'ultimo_uso' => $cliente['ultimo_uso_' . $num] ?? $cliente['fecha_asignacion_' . $num] ?? date('Y-m-d H:i:s'),
                'fecha_asignacion' => $cliente['fecha_asignacion_' . $num] ?? 'Fecha desconocida'
            ];
        }
    }
    
    return $dispositivos;
}

/**
 * Cuenta cuántos dispositivos tiene vinculados un cliente
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @return int Número de dispositivos
 */
function contarDispositivosCliente($conn, $cliente_id) {
    $dispositivos = obtenerDispositivosCliente($conn, $cliente_id);
    return count($dispositivos);
}

/**
 * Verifica si un cliente tiene 3 dispositivos vinculados
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @return bool True si tiene 3 dispositivos
 */
function tieneTresDispositivos($conn, $cliente_id) {
    return contarDispositivosCliente($conn, $cliente_id) >= 3;
}

/**
 * Obtiene el dispositivo más antiguo (menor último uso)
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @return array|null Dispositivo más antiguo o null si no hay
 */
function obtenerDispositivoMasAntiguo($conn, $cliente_id) {
    $dispositivos = obtenerDispositivosCliente($conn, $cliente_id);
    
    if (empty($dispositivos)) {
        return null;
    }
    
    usort($dispositivos, function($a, $b) {
        return strtotime($a['ultimo_uso']) - strtotime($b['ultimo_uso']);
    });
    
    return $dispositivos[0];
}

/**
 * Detecta información del dispositivo a partir del User-Agent
 * @param string $user_agent El User-Agent del navegador
 * @return array Información del dispositivo
 */
function detectarDispositivo($user_agent) {
    $info = [
        'tipo' => 'Otro',
        'sistema' => 'Desconocido',
        'navegador' => 'Desconocido',
        'marca' => '',
        'icono' => '🖥️'
    ];
    
    // Detectar sistema operativo
    if (strpos($user_agent, 'Windows NT 10.0') !== false) $info['sistema'] = 'Windows 10/11';
    elseif (strpos($user_agent, 'Windows NT 6.3') !== false) $info['sistema'] = 'Windows 8.1';
    elseif (strpos($user_agent, 'Windows NT 6.2') !== false) $info['sistema'] = 'Windows 8';
    elseif (strpos($user_agent, 'Windows NT 6.1') !== false) $info['sistema'] = 'Windows 7';
    elseif (strpos($user_agent, 'Windows') !== false) $info['sistema'] = 'Windows';
    elseif (strpos($user_agent, 'macOS') !== false || strpos($user_agent, 'Mac OS X') !== false) $info['sistema'] = 'macOS';
    elseif (strpos($user_agent, 'Linux') !== false && strpos($user_agent, 'Android') === false) $info['sistema'] = 'Linux';
    elseif (strpos($user_agent, 'Android') !== false) $info['sistema'] = 'Android';
    elseif (strpos($user_agent, 'iPhone') !== false) $info['sistema'] = 'iOS (iPhone)';
    elseif (strpos($user_agent, 'iPad') !== false) $info['sistema'] = 'iOS (iPad)';
    elseif (strpos($user_agent, 'iOS') !== false) $info['sistema'] = 'iOS';
    
    // Detectar tipo
    if (strpos($user_agent, 'Mobile') !== false || strpos($user_agent, 'Android') !== false || strpos($user_agent, 'iPhone') !== false) {
        $info['tipo'] = 'Móvil';
        $info['icono'] = '📱';
    } elseif (strpos($user_agent, 'iPad') !== false) {
        $info['tipo'] = 'Tablet';
        $info['icono'] = '📱';
    } else {
        $info['tipo'] = 'Desktop';
        $info['icono'] = '🖥️';
    }
    
    // Detectar marca
    $marcas = ['Samsung', 'Xiaomi', 'Huawei', 'Motorola', 'LG', 'Sony', 'Nokia', 'Google', 'OnePlus', 'Oppo', 'Vivo', 'Realme', 'Honor', 'ZTE', 'HTC', 'Apple', 'Dell', 'HP', 'Lenovo', 'Acer', 'Asus'];
    foreach ($marcas as $marca) {
        if (strpos($user_agent, $marca) !== false) {
            $info['marca'] = $marca;
            break;
        }
    }
    
    // Detectar navegador
    if (strpos($user_agent, 'Chrome') !== false && strpos($user_agent, 'Edg') === false && strpos($user_agent, 'OPR') === false) {
        $info['navegador'] = 'Chrome';
    } elseif (strpos($user_agent, 'Firefox') !== false) {
        $info['navegador'] = 'Firefox';
    } elseif (strpos($user_agent, 'Safari') !== false && strpos($user_agent, 'Chrome') === false) {
        $info['navegador'] = 'Safari';
    } elseif (strpos($user_agent, 'Edg') !== false) {
        $info['navegador'] = 'Edge';
    } elseif (strpos($user_agent, 'OPR') !== false || strpos($user_agent, 'Opera') !== false) {
        $info['navegador'] = 'Opera';
    } elseif (strpos($user_agent, 'Brave') !== false) {
        $info['navegador'] = 'Brave';
    }
    
    return $info;
}

/**
 * Formatea la información del dispositivo para mostrar al cliente
 * @param string $user_agent El User-Agent del navegador
 * @param string $ip Dirección IP
 * @return string Texto formateado
 */
function formatearDispositivo($user_agent, $ip) {
    $info = detectarDispositivo($user_agent);
    
    $texto = $info['icono'] . ' ' . $info['tipo'];
    if (!empty($info['marca'])) {
        $texto .= ' ' . $info['marca'];
    }
    if (!empty($info['sistema']) && $info['sistema'] != 'Desconocido') {
        $texto .= ' · ' . $info['sistema'];
    }
    if (!empty($info['navegador']) && $info['navegador'] != 'Desconocido') {
        $texto .= ' · ' . $info['navegador'];
    }
    
    // Acortar IP
    $ip_corta = $ip;
    if (preg_match('/(\d+\.\d+\.\d+)\.\d+$/', $ip, $matches)) {
        $ip_corta = $matches[1] . '.*';
    } elseif (preg_match('/([a-f0-9:]+):[a-f0-9]+$/i', $ip, $matches)) {
        $ip_corta = $matches[1] . ':*';
    }
    
    $texto .= ' (' . $ip_corta . ')';
    
    return $texto;
}

/**
 * Asigna un nuevo UUID a un cliente
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @param string $nuevo_uuid Nuevo UUID a asignar
 * @param string $user_agent User-Agent del dispositivo
 * @param string $ip IP del dispositivo
 * @return array Resultado de la operación
 */
function asignarDispositivoCliente($conn, $cliente_id, $nuevo_uuid, $user_agent, $ip) {
    // Obtener datos actuales
    $stmt = $conn->prepare("SELECT uuid, uuid2, uuid3 FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente) {
        return ['success' => false, 'mensaje' => 'Cliente no encontrado'];
    }
    
    // Verificar si el UUID ya está vinculado
    $ya_vinculado = (
        $cliente['uuid'] == $nuevo_uuid || 
        $cliente['uuid2'] == $nuevo_uuid || 
        $cliente['uuid3'] == $nuevo_uuid
    );
    
    if ($ya_vinculado) {
        return ['success' => true, 'mensaje' => 'UUID ya vinculado', 'accion' => 'ya_vinculado'];
    }
    
    // Verificar si tiene 3 dispositivos
    if (tieneTresDispositivos($conn, $cliente_id)) {
        // Reemplazar el más antiguo
        return reemplazarDispositivoMasAntiguo($conn, $cliente_id, $nuevo_uuid, $user_agent, $ip);
    }
    
    // Buscar espacio libre
    $campos = ['uuid', 'uuid2', 'uuid3'];
    $campo_encontrado = null;
    $num = null;
    
    foreach ($campos as $campo) {
        if (empty($cliente[$campo])) {
            $campo_encontrado = $campo;
            $num = (int)substr($campo, -1);
            break;
        }
    }
    
    if (!$campo_encontrado) {
        return ['success' => false, 'mensaje' => 'No hay espacio disponible'];
    }
    
    // Asignar
    $info = formatearDispositivo($user_agent, $ip);
    
    $stmt = $conn->prepare("UPDATE clientes SET 
        $campo_encontrado = ?,
        dispositivo_info_$num = ?,
        ip_$num = ?,
        ultimo_uso_$num = NOW(),
        fecha_asignacion_$num = NOW()
        WHERE id = ?");
    $stmt->bind_param("sssi", $nuevo_uuid, $info, $ip, $cliente_id);
    
    if ($stmt->execute()) {
        return [
            'success' => true, 
            'mensaje' => 'Dispositivo asignado correctamente',
            'accion' => 'asignado',
            'campo' => $campo_encontrado
        ];
    }
    
    return ['success' => false, 'mensaje' => 'Error al asignar dispositivo'];
}

/**
 * Reemplaza el dispositivo más antiguo por uno nuevo
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @param string $nuevo_uuid Nuevo UUID a asignar
 * @param string $user_agent User-Agent del nuevo dispositivo
 * @param string $ip IP del nuevo dispositivo
 * @return array Resultado de la operación
 */
function reemplazarDispositivoMasAntiguo($conn, $cliente_id, $nuevo_uuid, $user_agent, $ip) {
    $antiguo = obtenerDispositivoMasAntiguo($conn, $cliente_id);
    
    if (!$antiguo) {
        return ['success' => false, 'mensaje' => 'No hay dispositivos para reemplazar'];
    }
    
    $campo = $antiguo['campo'];
    $num = (int)substr($campo, -1);
    $info = formatearDispositivo($user_agent, $ip);
    
    $stmt = $conn->prepare("UPDATE clientes SET 
        $campo = ?,
        dispositivo_info_$num = ?,
        ip_$num = ?,
        ultimo_uso_$num = NOW(),
        fecha_asignacion_$num = NOW()
        WHERE id = ?");
    $stmt->bind_param("sssi", $nuevo_uuid, $info, $ip, $cliente_id);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'mensaje' => 'Dispositivo reemplazado correctamente',
            'antiguo' => $antiguo,
            'nuevo_uuid' => $nuevo_uuid
        ];
    }
    
    return ['success' => false, 'mensaje' => 'Error al reemplazar dispositivo'];
}

/**
 * Desvincula un dispositivo específico por su UUID
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @param string $uuid UUID a desvincular
 * @return array Resultado de la operación
 */
function desvincularDispositivo($conn, $cliente_id, $uuid) {
    $stmt = $conn->prepare("SELECT uuid, uuid2, uuid3 FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente) {
        return ['success' => false, 'mensaje' => 'Cliente no encontrado'];
    }
    
    $campo = null;
    $num = null;
    
    if ($cliente['uuid'] == $uuid) {
        $campo = 'uuid';
        $num = 1;
    } elseif ($cliente['uuid2'] == $uuid) {
        $campo = 'uuid2';
        $num = 2;
    } elseif ($cliente['uuid3'] == $uuid) {
        $campo = 'uuid3';
        $num = 3;
    }
    
    if (!$campo) {
        return ['success' => false, 'mensaje' => 'UUID no encontrado'];
    }
    
    $stmt = $conn->prepare("UPDATE clientes SET 
        $campo = NULL,
        dispositivo_info_$num = NULL,
        ip_$num = NULL,
        ultimo_uso_$num = NULL,
        fecha_asignacion_$num = NULL
        WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'mensaje' => 'Dispositivo desvinculado correctamente',
            'campo' => $campo
        ];
    }
    
    return ['success' => false, 'mensaje' => 'Error al desvincular dispositivo'];
}
?>
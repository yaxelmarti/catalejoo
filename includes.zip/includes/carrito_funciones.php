<?php
/**
 * FUNCIONES DEL CARRITO - CON LIMPIEZA AUTOMÁTICA DE EXPIRADOS
 */

// Obtener tiempo de expiración desde configuración
function getTiempoExpiracion($conn) {
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'tiempo_expiracion'");
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return intval($result->fetch_assoc()['valor']);
    }
    return 48; // valor por defecto
}

// ============================================
// LIMPIAR CARRITOS EXPIRADOS
// ============================================
function limpiarCarritosExpirados($conn) {
    static $ya_limpio = false;
    
    // Solo ejecutar una vez por request
    if ($ya_limpio) return;
    $ya_limpio = true;
    
    // Buscar carritos pendientes expirados
    $stmt = $conn->prepare("SELECT id FROM carritos WHERE estado = 'pendiente' AND fecha_expiracion < NOW()");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $carritos = [];
    while($row = $result->fetch_assoc()) {
        $carritos[] = $row['id'];
    }
    
    if (empty($carritos)) return;
    
    foreach ($carritos as $carrito_id) {
        // Iniciar transacción por carrito
        $conn->begin_transaction();
        
        try {
            // ============================================
            // 1. DEVOLVER STOCK DE COMBOS
            // ============================================
            $stmt_combos = $conn->prepare("SELECT combo_id, cantidad FROM carrito_combos WHERE carrito_id = ?");
            $stmt_combos->bind_param("i", $carrito_id);
            $stmt_combos->execute();
            $combos_exp = $stmt_combos->get_result();
            
            while ($combo = $combos_exp->fetch_assoc()) {
                // Devolver stock del combo
                $stmt_cs = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                $stmt_cs->bind_param("ii", $combo['cantidad'], $combo['combo_id']);
                $stmt_cs->execute();
                
                // Devolver stock de productos internos del combo
                $stmt_pc = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                $stmt_pc->bind_param("i", $combo['combo_id']);
                $stmt_pc->execute();
                $prod_combo = $stmt_pc->get_result();
                
                               while ($pc = $prod_combo->fetch_assoc()) {
    $stock_devolver = $pc['cantidad'] * $combo['cantidad'];
    $stmt_up = $conn->prepare("
        UPDATE productos 
        SET cantidad = cantidad + ?,
            reservado_por_combos = reservado_por_combos + ?,
            fecha_actualizacion_reserva = NOW(),
            en_combo = 1,
            fecha_agotado = NULL,
            activo = 1
        WHERE id = ?
    ");
    $stmt_up->bind_param("iii", $stock_devolver, $stock_devolver, $pc['producto_id']);
    $stmt_up->execute();
}
            }
            
            // ============================================
            // 2. OBTENER PRODUCTOS INDIVIDUALES
            // ============================================
            $stmt = $conn->prepare("SELECT producto_id, cantidad, precio_unitario FROM carrito_productos WHERE carrito_id = ?");
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $productos = $stmt->get_result();
            
            // ============================================
            // 3. CALCULAR TOTAL (productos + combos)
            // ============================================
            $stmt_total_p = $conn->prepare("SELECT SUM(cantidad * precio_unitario) as total FROM carrito_productos WHERE carrito_id = ?");
            $stmt_total_p->bind_param("i", $carrito_id);
            $stmt_total_p->execute();
            $total_p = $stmt_total_p->get_result()->fetch_assoc()['total'] ?? 0;
            
            $stmt_total_c = $conn->prepare("SELECT SUM(precio_total) as total FROM carrito_combos WHERE carrito_id = ?");
            $stmt_total_c->bind_param("i", $carrito_id);
            $stmt_total_c->execute();
            $total_c = $stmt_total_c->get_result()->fetch_assoc()['total'] ?? 0;
            
            $total_carrito = $total_p + $total_c;
            
            // Obtener cliente_id del carrito
            $stmt_cliente = $conn->prepare("SELECT cliente_id FROM carritos WHERE id = ?");
            $stmt_cliente->bind_param("i", $carrito_id);
            $stmt_cliente->execute();
            $cliente_id_carrito = $stmt_cliente->get_result()->fetch_assoc()['cliente_id'] ?? 0;
            
            $fecha_actual = date('Y-m-d H:i:s');
            $motivo = 'expirado_automatico';
            
            // ============================================
            // 4. GUARDAR HISTORIAL
            // ============================================
            $stmt_historial = $conn->prepare("INSERT INTO historial_carritos_cancelados (carrito_id, cliente_id, fecha_cancelacion, motivo, total) VALUES (?, ?, ?, ?, ?)");
            $stmt_historial->bind_param("iissd", $carrito_id, $cliente_id_carrito, $fecha_actual, $motivo, $total_carrito);
            $stmt_historial->execute();
            $cancelacion_id = $conn->insert_id;
            
            while ($item = $productos->fetch_assoc()) {
                $subtotal = $item['cantidad'] * $item['precio_unitario'];
                
                $stmt_nombre = $conn->prepare("SELECT nombre FROM productos WHERE id = ?");
                $stmt_nombre->bind_param("i", $item['producto_id']);
                $stmt_nombre->execute();
                $nombre = $stmt_nombre->get_result()->fetch_assoc()['nombre'] ?? 'Producto #' . $item['producto_id'];
                
                $stmt_hp = $conn->prepare("INSERT INTO historial_carritos_cancelados_productos (cancelacion_id, producto_id, nombre, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt_hp->bind_param("iisidd", $cancelacion_id, $item['producto_id'], $nombre, $item['cantidad'], $item['precio_unitario'], $subtotal);
                $stmt_hp->execute();
            }
            
                        // ============================================
            // 5. DEVOLVER STOCK DE PRODUCTOS
            // ============================================
            $productos->data_seek(0);
            while ($item = $productos->fetch_assoc()) {
                $stmt2 = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                $stmt2->bind_param("ii", $item['cantidad'], $item['producto_id']);
                $stmt2->execute();
                
                // ✅ Reactivar producto si estaba agotado
                $stmt_react = $conn->prepare("UPDATE productos SET activo = 1, fecha_agotado = NULL WHERE id = ? AND cantidad > 0 AND activo = 0");
                $stmt_react->bind_param("i", $item['producto_id']);
                $stmt_react->execute();
                
                $obs = "Cancelación automática por expiración - Carrito #$carrito_id";
                $stmt3 = $conn->prepare("INSERT INTO historial_producto (producto_id, tipo_evento, cantidad, observaciones) VALUES (?, 'cancelacion_carrito', ?, ?)");
                $stmt3->bind_param("iis", $item['producto_id'], $item['cantidad'], $obs);
                $stmt3->execute();
            }
            
            // ============================================
            // 6. ELIMINAR PRODUCTOS Y COMBOS
            // ============================================
            $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ?");
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            
            $stmt = $conn->prepare("DELETE FROM carrito_combos WHERE carrito_id = ?");
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            
            // ============================================
            // 7. MARCAR CARRITO COMO EXPIRADO
            // ============================================
            $stmt = $conn->prepare("UPDATE carritos SET estado = 'expirado', fecha_cierre = NOW(), motivo_cancelacion = 'expirado_automatico' WHERE id = ?");
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            
            // Confirmar transacción
            $conn->commit();
            
        } catch (Exception $e) {
            // Revertir transacción si algo falla
            $conn->rollback();
            error_log("Error al limpiar carrito expirado #$carrito_id: " . $e->getMessage());
        }
    }
}

// Buscar carrito pendiente (CON ACTUALIZACIÓN AUTOMÁTICA)
function iniciarCarrito($conn, $cliente_id) {
    // Si no hay cliente registrado (ID válido), no buscar carrito
    if ($cliente_id <= 0) {
        return null;
    }
    
    // LIMPIAR CARRITOS EXPIRADOS ANTES DE BUSCAR
    limpiarCarritosExpirados($conn);
    
    $tiempo_config = getTiempoExpiracion($conn);
    
    $stmt = $conn->prepare("SELECT * FROM carritos 
                            WHERE cliente_id = ? AND estado = 'pendiente' AND fecha_expiracion > NOW() 
                            ORDER BY fecha_inicio DESC LIMIT 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $carrito = $result->fetch_assoc();
        
        $expiracion_actual = strtotime($carrito['fecha_expiracion']);
        $horas_restantes = round(($expiracion_actual - time()) / 3600, 1);
        
        if ($horas_restantes > $tiempo_config) {
            $nueva_expiracion = date('Y-m-d H:i:s', strtotime("+$tiempo_config hours"));
            $stmt2 = $conn->prepare("UPDATE carritos SET fecha_expiracion = ? WHERE id = ?");
            $stmt2->bind_param("si", $nueva_expiracion, $carrito['id']);
            $stmt2->execute();
            $carrito['fecha_expiracion'] = $nueva_expiracion;
        }
        
        return $carrito;
    }
    
    return null;
}

// Crear nuevo carrito
function crearCarrito($conn, $cliente_id, $moneda = 'USD', $proveedor_id = null) {
    // No crear carrito para visitantes (ID <= 0)
    if ($cliente_id <= 0) {
        return null;
    }
    
    // ✅ Normalizar: 0 o vacío → NULL
    if (empty($proveedor_id) || $proveedor_id <= 0) {
        $proveedor_id = null;
    }
    
    $horas = getTiempoExpiracion($conn);
    $fecha_expiracion = date('Y-m-d H:i:s', strtotime("+$horas hours"));
    
    // ✅ IMPORTANTE: bind_param con 'i' convierte null a 0.
    // Si es null, usar NULL literal en el SQL.
    if ($proveedor_id === null) {
        $stmt = $conn->prepare("INSERT INTO carritos (cliente_id, moneda, proveedor_id, fecha_expiracion) VALUES (?, ?, NULL, ?)");
        $stmt->bind_param("iss", $cliente_id, $moneda, $fecha_expiracion);
    } else {
        $stmt = $conn->prepare("INSERT INTO carritos (cliente_id, moneda, proveedor_id, fecha_expiracion) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isis", $cliente_id, $moneda, $proveedor_id, $fecha_expiracion);
    }
    
    // ✅ Verificar que el INSERT se ejecutó correctamente
    if (!$stmt->execute()) {
        error_log("Error al crear carrito para cliente $cliente_id: " . $stmt->error);
        return null;
    }
    
    return [
        'id' => $conn->insert_id,
        'moneda' => $moneda,
        'proveedor_id' => $proveedor_id,
        'fecha_expiracion' => $fecha_expiracion
    ];
}

// Obtener o crear carrito
function obtenerOCrearCarrito($conn, $cliente_id, $moneda = 'USD', $proveedor_id = null) {
    // Si no hay cliente registrado, NO crear carrito
    if ($cliente_id <= 0) {
        return null;
    }
    
    limpiarCarritosExpirados($conn);
    $carrito = iniciarCarrito($conn, $cliente_id);
    return $carrito ?: crearCarrito($conn, $cliente_id, $moneda, $proveedor_id);
}

// Calcular total del carrito (productos + combos)
function calcularTotalCarrito($conn, $carrito_id) {
    // Productos individuales
    $stmt = $conn->prepare("SELECT SUM(cantidad * precio_unitario) as total FROM carrito_productos WHERE carrito_id = ?");
    $stmt->bind_param("i", $carrito_id);
    $stmt->execute();
    $total_p = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    
    // Combos
    $stmt = $conn->prepare("SELECT SUM(precio_total) as total FROM carrito_combos WHERE carrito_id = ?");
    $stmt->bind_param("i", $carrito_id);
    $stmt->execute();
    $total_c = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    
    return $total_p + $total_c;
}

// Actualizar datos del cliente (CON contraseña)
function actualizarDatosCliente($conn, $cliente_id, $nombre, $apellidos, $email, $documento, $movil, $password = null) {
    if ($password) {
        $stmt = $conn->prepare("UPDATE clientes SET nombre = ?, apellidos = ?, email = ?, documento = ?, movil = ?, password = ? WHERE id = ?");
        $stmt->bind_param("ssssssi", $nombre, $apellidos, $email, $documento, $movil, $password, $cliente_id);
    } else {
        $stmt = $conn->prepare("UPDATE clientes SET nombre = ?, apellidos = ?, email = ?, documento = ?, movil = ? WHERE id = ?");
        $stmt->bind_param("sssssi", $nombre, $apellidos, $email, $documento, $movil, $cliente_id);
    }
    return $stmt->execute();
}

// Obtener stock de producto
function obtenerStockProducto($conn, $producto_id) {
    $stmt = $conn->prepare("SELECT cantidad FROM productos WHERE id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    return $result['cantidad'] ?? 0;
}

// Verificar stock suficiente
function verificarStock($conn, $producto_id, $cantidad_deseada) {
    $stock = obtenerStockProducto($conn, $producto_id);
    return $stock >= $cantidad_deseada;
}

// CANCELAR CARRITO (MANUAL - admin o cliente)
function cancelarCarrito($conn, $carrito_id, $motivo) {
    // Iniciar transacción
    $conn->begin_transaction();
    
    try {
        // ============================================
        // 1. DEVOLVER STOCK DE COMBOS
        // ============================================
        $stmt_combos = $conn->prepare("SELECT combo_id, cantidad FROM carrito_combos WHERE carrito_id = ?");
        $stmt_combos->bind_param("i", $carrito_id);
        $stmt_combos->execute();
        $combos = $stmt_combos->get_result();
        
        while ($combo = $combos->fetch_assoc()) {
            // Devolver stock del combo
            $stmt_cs = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
            $stmt_cs->bind_param("ii", $combo['cantidad'], $combo['combo_id']);
            $stmt_cs->execute();
            
            // Devolver stock de productos internos del combo
            $stmt_pc = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
            $stmt_pc->bind_param("i", $combo['combo_id']);
            $stmt_pc->execute();
            $prod_combo = $stmt_pc->get_result();
            
                        while ($pc = $prod_combo->fetch_assoc()) {
    $stock_devolver = $pc['cantidad'] * $combo['cantidad'];
    $stmt_up = $conn->prepare("
        UPDATE productos 
        SET cantidad = cantidad + ?,
            reservado_por_combos = reservado_por_combos + ?,
            fecha_actualizacion_reserva = NOW(),
            en_combo = 1,
            fecha_agotado = NULL,
            activo = 1
        WHERE id = ?
    ");
    $stmt_up->bind_param("iii", $stock_devolver, $stock_devolver, $pc['producto_id']);
    $stmt_up->execute();
}
        }
        
        // ============================================
        // 2. OBTENER PRODUCTOS INDIVIDUALES
        // ============================================
        $stmt = $conn->prepare("SELECT producto_id, cantidad, precio_unitario FROM carrito_productos WHERE carrito_id = ?");
        $stmt->bind_param("i", $carrito_id);
        $stmt->execute();
        $productos = $stmt->get_result();
        
        // ============================================
        // 3. CALCULAR TOTAL (productos + combos)
        // ============================================
        $stmt_total_p = $conn->prepare("SELECT SUM(cantidad * precio_unitario) as total FROM carrito_productos WHERE carrito_id = ?");
        $stmt_total_p->bind_param("i", $carrito_id);
        $stmt_total_p->execute();
        $total_p = $stmt_total_p->get_result()->fetch_assoc()['total'] ?? 0;
        
        $stmt_total_c = $conn->prepare("SELECT SUM(precio_total) as total FROM carrito_combos WHERE carrito_id = ?");
        $stmt_total_c->bind_param("i", $carrito_id);
        $stmt_total_c->execute();
        $total_c = $stmt_total_c->get_result()->fetch_assoc()['total'] ?? 0;
        
        $total_carrito = $total_p + $total_c;
        
        // Obtener cliente_id del carrito
        $stmt_cliente = $conn->prepare("SELECT cliente_id FROM carritos WHERE id = ?");
        $stmt_cliente->bind_param("i", $carrito_id);
        $stmt_cliente->execute();
        $cliente_id_carrito = $stmt_cliente->get_result()->fetch_assoc()['cliente_id'] ?? 0;
        
        $fecha_actual = date('Y-m-d H:i:s');
        
        // ============================================
        // 4. GUARDAR HISTORIAL
        // ============================================
        $stmt_historial = $conn->prepare("INSERT INTO historial_carritos_cancelados (carrito_id, cliente_id, fecha_cancelacion, motivo, total) VALUES (?, ?, ?, ?, ?)");
        $stmt_historial->bind_param("iissd", $carrito_id, $cliente_id_carrito, $fecha_actual, $motivo, $total_carrito);
        $stmt_historial->execute();
        $cancelacion_id = $conn->insert_id;
        
        // Insertar cada producto individual
        $productos->data_seek(0);
        while ($item = $productos->fetch_assoc()) {
            $subtotal = $item['cantidad'] * $item['precio_unitario'];
            
            $stmt_nombre = $conn->prepare("SELECT nombre FROM productos WHERE id = ?");
            $stmt_nombre->bind_param("i", $item['producto_id']);
            $stmt_nombre->execute();
            $nombre = $stmt_nombre->get_result()->fetch_assoc()['nombre'] ?? 'Producto #' . $item['producto_id'];
            
            $stmt_hp = $conn->prepare("INSERT INTO historial_carritos_cancelados_productos (cancelacion_id, producto_id, nombre, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt_hp->bind_param("iisidd", $cancelacion_id, $item['producto_id'], $nombre, $item['cantidad'], $item['precio_unitario'], $subtotal);
            $stmt_hp->execute();
        }
        
                // ============================================
        // 5. DEVOLVER STOCK DE PRODUCTOS INDIVIDUALES
        // ============================================
        $productos->data_seek(0);
        while ($item = $productos->fetch_assoc()) {
            $stmt2 = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
            $stmt2->bind_param("ii", $item['cantidad'], $item['producto_id']);
            $stmt2->execute();
            
            // ✅ Reactivar producto si tenía stock 0 y ahora tiene > 0
            $stmt_react = $conn->prepare("UPDATE productos SET activo = 1, fecha_agotado = NULL WHERE id = ? AND cantidad > 0 AND activo = 0");
            $stmt_react->bind_param("i", $item['producto_id']);
            $stmt_react->execute();
        }
        
        // ============================================
        // 6. BORRAR PRODUCTOS Y COMBOS
        // ============================================
        $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ?");
        $stmt->bind_param("i", $carrito_id);
        $stmt->execute();
        
        $stmt = $conn->prepare("DELETE FROM carrito_combos WHERE carrito_id = ?");
        $stmt->bind_param("i", $carrito_id);
        $stmt->execute();
        
        // ============================================
        // 7. MARCAR CARRITO COMO CANCELADO
        // ============================================
        $stmt = $conn->prepare("UPDATE carritos SET estado = 'cancelado', fecha_cierre = NOW(), motivo_cancelacion = ? WHERE id = ?");
        $stmt->bind_param("si", $motivo, $carrito_id);
        $stmt->execute();
        
        // Confirmar transacción
        $conn->commit();
        return true;
        
    } catch (Exception $e) {
        // Revertir transacción
        $conn->rollback();
        error_log("Error al cancelar carrito #$carrito_id: " . $e->getMessage());
        return false;
    }
}

// Registrar cambios de clientes
function registrarCambioCliente($conn, $cliente_id, $campo, $valor_anterior, $valor_nuevo) {
    if ($valor_anterior == $valor_nuevo) return true;
    
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $dispositivo = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $stmt = $conn->prepare("INSERT INTO historial_clientes_cambios 
        (cliente_id, campo_modificado, valor_anterior, valor_nuevo, dispositivo_info, ip_address) 
        VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $cliente_id, $campo, $valor_anterior, $valor_nuevo, $dispositivo, $ip);
    return $stmt->execute();
}

// ============================================
// FUNCIONES DE SEGUIMIENTO - SEGURAS
// ============================================

function registrarVisita($conn) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    $session_id = session_id();
    $pagina = $_SERVER['REQUEST_URI'] ?? '/';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $fecha = date('Y-m-d H:i:s');
    
    if (strlen($pagina) > 500) {
        $pagina = substr($pagina, 0, 500);
    }
    
    $stmt = $conn->prepare("SELECT id FROM visitas WHERE session_id = ? AND pagina = ? AND DATE(fecha) = CURDATE()");
    $stmt->bind_param("ss", $session_id, $pagina);
    $stmt->execute();
    $existe = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$existe) {
        $stmt = $conn->prepare("INSERT INTO visitas (ip, user_agent, pagina, fecha, session_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $ip, $user_agent, $pagina, $fecha, $session_id);
        $stmt->execute();
        $stmt->close();
    }
}

function registrarEvento($conn, $evento, $producto_id = null) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    $session_id = session_id();
    $url = $_SERVER['REQUEST_URI'] ?? '/';
    $fecha = date('Y-m-d H:i:s');
    
    if (strlen($url) > 500) {
        $url = substr($url, 0, 500);
    }
    
    $stmt = $conn->prepare("INSERT INTO eventos_conversion (session_id, evento, producto_id, url, fecha) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $session_id, $evento, $producto_id, $url, $fecha);
    $stmt->execute();
    $stmt->close();
}
?>
<?php
// ============================================
// PAGINACIÓN - SOLO BOTONES
// ============================================

// Validaciones de seguridad
if (!isset($total_registros) || $total_registros <= 0) return;
if (!isset($por_pagina) || $por_pagina <= 0) return;
if (!isset($pagina_actual) || $pagina_actual < 1) return;

$total_paginas = ceil($total_registros / $por_pagina);
if ($total_paginas <= 1) return;

// Mantener todos los parámetros actuales excepto 'pagina'
$parametros = array_filter($_GET, function($v) {
    return $v !== '' && $v !== null;
});
unset($parametros['pagina']);

$url_base = '?' . http_build_query($parametros);
if (!empty($parametros)) {
    $url_base .= '&';
}
?>
<style>
.paginacion {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
    margin: 1.5rem 0;
    flex-wrap: wrap;
}
.btn-pagina {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 40px;
    height: 40px;
    padding: 0 0.75rem;
    background: white;
    color: #4a5568;
    text-decoration: none;
    border-radius: 8px;
    font-size: 0.85rem;
    font-weight: 500;
    transition: all 0.2s ease;
    border: 1px solid #e2e8f0;
    cursor: pointer;
}
.btn-pagina:hover {
    background: #edf2f7;
    border-color: #cbd5e0;
    transform: translateY(-2px);
}
.btn-pagina.activo {
    background: linear-gradient(135deg, <?php echo htmlspecialchars($color_primario ?? '#667eea'); ?> 0%, <?php echo htmlspecialchars($color_secundario ?? '#764ba2'); ?> 100%);
    color: white;
    border: none;
    cursor: default;
    transform: none;
}
.btn-pagina.disabled {
    opacity: 0.5;
    cursor: not-allowed;
    background: #f7fafc;
    transform: none;
}
@media (max-width: 768px) {
    .paginacion { gap: 0.3rem; margin: 1rem 0; }
    .btn-pagina { min-width: 34px; height: 34px; padding: 0 0.5rem; font-size: 0.75rem; }
}
@media (max-width: 480px) {
    .paginacion { gap: 0.25rem; }
    .btn-pagina { min-width: 30px; height: 30px; padding: 0 0.4rem; font-size: 0.7rem; }
}
</style>

<div class="paginacion">
    <?php if ($pagina_actual > 1): ?>
        <a href="<?php echo htmlspecialchars($url_base . 'pagina=1'); ?>" class="btn-pagina" title="Primera">««</a>
        <a href="<?php echo htmlspecialchars($url_base . 'pagina=' . ($pagina_actual - 1)); ?>" class="btn-pagina">« Anterior</a>
    <?php else: ?>
        <span class="btn-pagina disabled">««</span>
        <span class="btn-pagina disabled">« Anterior</span>
    <?php endif; ?>
    
    <?php
    $inicio = max(1, $pagina_actual - 2);
    $fin = min($total_paginas, $pagina_actual + 2);
    
    if ($inicio > 1) {
        echo '<a href="' . htmlspecialchars($url_base . 'pagina=1') . '" class="btn-pagina">1</a>';
        if ($inicio > 2) echo '<span class="btn-pagina disabled">...</span>';
    }
    
    for ($i = $inicio; $i <= $fin; $i++):
        if ($i == $pagina_actual):
    ?>
            <span class="btn-pagina activo"><?php echo $i; ?></span>
        <?php else: ?>
            <a href="<?php echo htmlspecialchars($url_base . 'pagina=' . $i); ?>" class="btn-pagina"><?php echo $i; ?></a>
        <?php endif;
    endfor;
    
    if ($fin < $total_paginas) {
        if ($fin < $total_paginas - 1) echo '<span class="btn-pagina disabled">...</span>';
        echo '<a href="' . htmlspecialchars($url_base . 'pagina=' . $total_paginas) . '" class="btn-pagina">' . $total_paginas . '</a>';
    }
    ?>
    
    <?php if ($pagina_actual < $total_paginas): ?>
        <a href="<?php echo htmlspecialchars($url_base . 'pagina=' . ($pagina_actual + 1)); ?>" class="btn-pagina">Siguiente »</a>
        <a href="<?php echo htmlspecialchars($url_base . 'pagina=' . $total_paginas); ?>" class="btn-pagina" title="Última">»»</a>
    <?php else: ?>
        <span class="btn-pagina disabled">Siguiente »</span>
        <span class="btn-pagina disabled">»»</span>
    <?php endif; ?>
</div>
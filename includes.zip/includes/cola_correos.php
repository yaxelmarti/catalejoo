<?php
// ============================================
// COLA DE CORREOS
// ============================================
// Todas las funciones son defensivas:
// - Verifican conexión MySQL antes de escribir (auto-reconectan si murió).
// - try/catch envuelve cualquier operación.
// - Nunca lanzan excepción no capturada.
// ============================================

/**
 * Verifica que la conexión MySQL esté viva.
 * Si murió (timeout), intenta reconectar usando las constantes de conexion.php.
 *
 * @param mysqli $conn  Conexión actual (por referencia)
 * @return bool         true si la conexión está OK, false si no
 */
function asegurarConexionBD(&$conn) {
    // Si no es objeto mysqli, no hay nada que hacer
    if (!($conn instanceof mysqli)) {
        return false;
    }
    
    // Ping: verifica si el servidor sigue respondiendo
    try {
        if (@$conn->ping()) {
            return true;
        }
    } catch (Throwable $e) {
        error_log('[cola_correos] ping() excepción: ' . $e->getMessage());
    }
    
    // La conexión murió. Reconectar.
    error_log('[cola_correos] Conexión MySQL muerta. Reconectando...');
    
    // Cerrar la vieja
    try { @$conn->close(); } catch (Throwable $e) {}
    
    // Verificar que existan las constantes de conexión
    if (!defined('DB_HOST') || !defined('DB_USER') || !defined('DB_PASS') || !defined('DB_NAME')) {
        error_log('[cola_correos] No se pueden reconectar: constantes DB_* no definidas');
        return false;
    }
    
    // Reconectar
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            error_log('[cola_correos] Reconexión falló: ' . $conn->connect_error);
            return false;
        }
        $conn->set_charset('utf8mb4');
        return true;
    } catch (Throwable $e) {
        error_log('[cola_correos] Excepción al reconectar: ' . $e->getMessage());
        return false;
    }
}

/**
 * Encola un correo para enviarlo después
 */
function encolarCorreo($conn, $destinatario, $asunto, $cuerpo, $adjunto = null, $pedido_id = null) {
    // Validar destinatario
    if (empty($destinatario) || !filter_var($destinatario, FILTER_VALIDATE_EMAIL)) {
        error_log('[cola_correos] Destinatario inválido: ' . var_export($destinatario, true));
        return false;
    }
    
    // Validar asunto
    if (empty(trim((string)$asunto))) {
        error_log('[cola_correos] Asunto vacío para: ' . $destinatario);
        return false;
    }
    
    // Validar cuerpo
    if (empty(trim((string)$cuerpo))) {
        error_log('[cola_correos] Cuerpo vacío para: ' . $destinatario . ' (asunto: ' . $asunto . ')');
        return false;
    }
    
    // Asegurar conexión
    if (!asegurarConexionBD($conn)) {
        error_log('[cola_correos] encolarCorreo: sin conexión a BD');
        return false;
    }
    
    // Normalizar adjunto y pedido_id
    $adjunto_val = $adjunto ?? '';
    $pedido_id_val = intval($pedido_id ?? 0);
    
    try {
        $stmt = $conn->prepare("
            INSERT INTO cola_correos (destinatario, asunto, cuerpo, adjunto, pedido_id)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        if (!$stmt) {
            error_log('[cola_correos] prepare() falló: ' . $conn->error);
            return false;
        }
        
        $stmt->bind_param("ssssi", $destinatario, $asunto, $cuerpo, $adjunto_val, $pedido_id_val);
        
        if (!$stmt->execute()) {
            error_log('[cola_correos] execute() falló: ' . $stmt->error);
            $stmt->close();
            return false;
        }
        
        $id = $conn->insert_id;
        $stmt->close();
        return $id;
        
    } catch (Throwable $e) {
        error_log('[cola_correos] encolarCorreo excepción: ' . $e->getMessage());
        return false;
    }
}

/**
 * Obtiene los correos pendientes de envío
 */
function obtenerCorreosPendientes($conn, $limite = 10) {
    // Asegurar conexión
    if (!asegurarConexionBD($conn)) {
        error_log('[cola_correos] obtenerCorreosPendientes: sin conexión a BD');
        return [];
    }
    
    try {
        $stmt = $conn->prepare("
            SELECT * FROM cola_correos 
            WHERE enviado = 0 AND intentos < 3
            ORDER BY fecha_creacion ASC
            LIMIT ?
        ");
        
        if (!$stmt) {
            error_log('[cola_correos] obtenerCorreosPendientes prepare() falló: ' . $conn->error);
            return [];
        }
        
        $stmt->bind_param("i", $limite);
        $stmt->execute();
        $result = $stmt->get_result();
        $correos = [];
        while ($row = $result->fetch_assoc()) {
            $correos[] = $row;
        }
        $stmt->close();
        return $correos;
        
    } catch (Throwable $e) {
        error_log('[cola_correos] obtenerCorreosPendientes excepción: ' . $e->getMessage());
        return [];
    }
}

/**
 * Marca un correo como enviado
 */
function marcarCorreoEnviado($conn, $id) {
    // Asegurar conexión
    if (!asegurarConexionBD($conn)) {
        error_log('[cola_correos] marcarCorreoEnviado: sin conexión a BD');
        return false;
    }
    
    try {
        $stmt = $conn->prepare("
            UPDATE cola_correos 
            SET enviado = 1, fecha_envio = NOW() 
            WHERE id = ?
        ");
        
        if (!$stmt) {
            error_log('[cola_correos] marcarCorreoEnviado prepare() falló: ' . $conn->error);
            return false;
        }
        
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        return true;
        
    } catch (Throwable $e) {
        error_log('[cola_correos] marcarCorreoEnviado excepción: ' . $e->getMessage());
        return false;
    }
}

/**
 * Marca un correo con error
 */
function marcarCorreoError($conn, $id, $error) {
    // Asegurar conexión
    if (!asegurarConexionBD($conn)) {
        error_log('[cola_correos] marcarCorreoError: sin conexión a BD');
        return false;
    }
    
    // Limitar longitud del error (por si viene muy largo)
    $error = mb_substr((string)$error, 0, 500);
    
    try {
        $stmt = $conn->prepare("
            UPDATE cola_correos 
            SET intentos = intentos + 1, error = ? 
            WHERE id = ?
        ");
        
        if (!$stmt) {
            error_log('[cola_correos] marcarCorreoError prepare() falló: ' . $conn->error);
            return false;
        }
        
        $stmt->bind_param("si", $error, $id);
        $stmt->execute();
        $stmt->close();
        return true;
        
    } catch (Throwable $e) {
        error_log('[cola_correos] marcarCorreoError excepción: ' . $e->getMessage());
        return false;
    }
}

/**
 * Cuenta los correos pendientes
 */
function contarCorreosPendientes($conn) {
    // Asegurar conexión
    if (!asegurarConexionBD($conn)) {
        error_log('[cola_correos] contarCorreosPendientes: sin conexión a BD');
        return 0;
    }
    
    try {
        $result = $conn->query("SELECT COUNT(*) as total FROM cola_correos WHERE enviado = 0");
        if (!$result) {
            error_log('[cola_correos] contarCorreosPendientes query() falló: ' . $conn->error);
            return 0;
        }
        $row = $result->fetch_assoc();
        return intval($row['total'] ?? 0);
        
    } catch (Throwable $e) {
        error_log('[cola_correos] contarCorreosPendientes excepción: ' . $e->getMessage());
        return 0;
    }
}
?>
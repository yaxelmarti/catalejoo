<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}
    
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';
require_once __DIR__ . '/moneda_funciones.php';

// ============================================
// SESIÓN (necesaria para caché de moneda)
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

header('Content-Type: text/html; charset=utf-8');

// ============================================
// RECIBIR PROVEEDOR Y CALCULAR FILTRO
// ============================================
$proveedor_slug = isset($_GET['proveedor']) ? trim($_GET['proveedor']) : '';
$proveedor_id = 0;

if (!empty($proveedor_slug)) {
    $stmt_prov = $conn->prepare("SELECT id FROM proveedores WHERE slug = ? AND activo = 1");
    $stmt_prov->bind_param("s", $proveedor_slug);
    $stmt_prov->execute();
    $result_prov = $stmt_prov->get_result();
    if ($row = $result_prov->fetch_assoc()) {
        $proveedor_id = $row['id'];
    }
    $stmt_prov->close();
}

// Determinar proveedor filtro (URL > usuario logueado > 0)
$proveedor_filtro_id = 0;
if ($proveedor_id > 0) {
    $proveedor_filtro_id = $proveedor_id;
} elseif ($es_proveedor && $proveedor_id_usuario > 0) {
    $proveedor_filtro_id = $proveedor_id_usuario;
}

// ============================================
// DETERMINAR MONEDA (según proveedor y cliente)
// ============================================
require_once __DIR__ . '/cliente_identificador.php';

$cliente = obtenerClienteActual($conn);
$cliente_registrado = (!empty($cliente['id']) && $cliente['id'] > 0);

$moneda_actual = getMonedaParaProveedor($conn, $proveedor_filtro_id, $cliente);
$moneda_simbolo = getSimboloPorMoneda($moneda_actual);
$moneda_codigo = $moneda_actual;

$offset = isset($_GET['offset']) ? max(0, min(3000, intval($_GET['offset']))) : 0;
$categoria = isset($_GET['categoria']) ? max(0, intval($_GET['categoria'])) : 0;
$buscar = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';
$filtro = isset($_GET['filtro']) ? trim($_GET['filtro']) : '';
$limite = isset($_GET['limite']) ? intval($_GET['limite']) : 16;

// Obtener configuración
$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion");
while($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}

$sitio_nombre = $config['sitio_nombre'] ?? 'TiendaVirtual';
// $moneda_simbolo y $moneda_codigo ya están calculados arriba

// Consulta con búsqueda o filtro
if (!empty($buscar)) {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono,
            CASE 
                WHEN p.porcentaje_rebaja > 0 THEN 1 
                ELSE 4 
            END as orden_rebaja,
            COALESCE((SELECT SUM(cp.cantidad) FROM carrito_productos cp 
                      JOIN carritos ca ON cp.carrito_id = ca.id 
                      WHERE cp.producto_id = p.id AND ca.estado = 'comprado'), 0) as total_vendidos,
            CASE 
                WHEN TIMESTAMPDIFF(HOUR, p.fecha_creacion, NOW()) <= 48 THEN 2
                ELSE 3
            END as orden_nuevo
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 ";

    // ===== FILTRO DE PROVEEDOR =====
// Prioridad: 1. proveedor de la URL (slug) | 2. proveedor del usuario | 3. todos
$proveedor_filtro_id = 0;

if ($proveedor_id > 0) {
    // Si hay slug en URL, usar ese (sobreescribe)
    $proveedor_filtro_id = $proveedor_id;
    // Validar que el proveedor existe y está activo
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_filtro_id);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $proveedor_filtro_id = 0;
    }
    $stmt_check->close();
} elseif ($es_proveedor && $proveedor_id_usuario > 0) {
    // Si es proveedor logueado, filtrar por su proveedor
    $proveedor_filtro_id = $proveedor_id_usuario;
}

if ($proveedor_filtro_id > 0) {
    $sql .= " AND p.proveedor_id = " . intval($proveedor_filtro_id) . " ";
}

    $sql .= " AND (p.nombre LIKE ? OR p.descripcion LIKE ? OR p.marca LIKE ?)
              ORDER BY orden_rebaja ASC, total_vendidos DESC, orden_nuevo ASC, p.nombre ASC, p.id ASC
              LIMIT ? OFFSET ?";
    
    $param = "%$buscar%";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssii", $param, $param, $param, $limite, $offset);
    $stmt->execute();
    $productos = $stmt->get_result();
    
} elseif ($categoria > 0) {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono,
            CASE 
                WHEN p.porcentaje_rebaja > 0 THEN 1 
                ELSE 4 
            END as orden_rebaja,
            COALESCE((SELECT SUM(cp.cantidad) FROM carrito_productos cp 
                      JOIN carritos ca ON cp.carrito_id = ca.id 
                      WHERE cp.producto_id = p.id AND ca.estado = 'comprado'), 0) as total_vendidos,
            CASE 
                WHEN TIMESTAMPDIFF(HOUR, p.fecha_creacion, NOW()) <= 48 THEN 2
                ELSE 3
            END as orden_nuevo
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 ";

    // ===== FILTRO DE PROVEEDOR (agregado) =====
    if ($proveedor_id > 0) {
        $sql .= " AND p.proveedor_id = " . intval($proveedor_id) . " ";
    }

    $sql .= " AND p.categoria_id = ? 
              ORDER BY orden_rebaja ASC, total_vendidos DESC, orden_nuevo ASC, p.nombre ASC, p.id ASC
              LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $categoria, $limite, $offset);
    $stmt->execute();
    $productos = $stmt->get_result();
    
} elseif (!empty($filtro)) {
    // ===== FILTRO NUEVOS =====
    if ($filtro == 'nuevos') {
        $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono
                FROM productos p 
                LEFT JOIN categorias c ON p.categoria_id = c.id 
                WHERE p.activo = 1 ";

        if ($proveedor_id > 0) {
            $sql .= " AND p.proveedor_id = " . intval($proveedor_id) . " ";
        }

        $sql .= " AND TIMESTAMPDIFF(HOUR, p.fecha_creacion, NOW()) <= 48
                  ORDER BY p.fecha_creacion DESC, p.id ASC
                  LIMIT ? OFFSET ?";
    
    // ===== FILTRO MÁS VENDIDOS =====
    } elseif ($filtro == 'mas_vendidos') {
        $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono,
                COALESCE((SELECT SUM(cp.cantidad) FROM carrito_productos cp 
                          JOIN carritos ca ON cp.carrito_id = ca.id 
                          WHERE cp.producto_id = p.id AND ca.estado = 'comprado'), 0) as total_vendidos
                FROM productos p 
                LEFT JOIN categorias c ON p.categoria_id = c.id 
                WHERE p.activo = 1 ";

        if ($proveedor_id > 0) {
            $sql .= " AND p.proveedor_id = " . intval($proveedor_id) . " ";
        }

        $sql .= " ORDER BY total_vendidos DESC, p.id ASC
                  LIMIT ? OFFSET ?";
    
    // ===== FILTRO OFERTAS =====
    } elseif ($filtro == 'ofertas') {
        $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono
                FROM productos p 
                LEFT JOIN categorias c ON p.categoria_id = c.id 
                WHERE p.activo = 1 ";

        if ($proveedor_id > 0) {
            $sql .= " AND p.proveedor_id = " . intval($proveedor_id) . " ";
        }

        $sql .= " AND p.porcentaje_rebaja > 0
                  ORDER BY p.porcentaje_rebaja DESC, p.id ASC
                  LIMIT ? OFFSET ?";
    }
    
    if (isset($sql)) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $limite, $offset);
        $stmt->execute();
        $productos = $stmt->get_result();
    }
    
} else {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono,
            CASE 
                WHEN p.porcentaje_rebaja > 0 THEN 1 
                ELSE 4 
            END as orden_rebaja,
            COALESCE((SELECT SUM(cp.cantidad) FROM carrito_productos cp 
                      JOIN carritos ca ON cp.carrito_id = ca.id 
                      WHERE cp.producto_id = p.id AND ca.estado = 'comprado'), 0) as total_vendidos,
            CASE 
                WHEN TIMESTAMPDIFF(HOUR, p.fecha_creacion, NOW()) <= 48 THEN 2
                ELSE 3
            END as orden_nuevo
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 ";

    // ===== FILTRO DE PROVEEDOR (agregado) =====
    if ($proveedor_id > 0) {
        $sql .= " AND p.proveedor_id = " . intval($proveedor_id) . " ";
    }

    $sql .= " ORDER BY orden_rebaja ASC, total_vendidos DESC, orden_nuevo ASC, p.nombre ASC, p.id ASC
              LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $limite, $offset);
    $stmt->execute();
    $productos = $stmt->get_result();
}

while($producto = $productos->fetch_assoc()):
    // Calcular variables necesarias
    $horas_antiguedad = floor((time() - strtotime($producto['fecha_creacion'])) / 3600);
    $es_nuevo = $horas_antiguedad < 168;  // 168 horas = 7 días
    $tiene_rebaja = $producto['porcentaje_rebaja'] > 0;
    
    // Pasar proveedor_contexto a producto_card.php (0 si global, X si tienda)
    $proveedor_contexto = $proveedor_filtro_id;
    
    // $moneda_simbolo, $moneda_codigo y $sitio_nombre ya están calculados arriba
    
    include __DIR__ . '/../producto_card.php';
endwhile;

$conn->close();
?>
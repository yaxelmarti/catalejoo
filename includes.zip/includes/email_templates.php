<?php
/**
 * PLANTILLAS DE CORREOS PARA NOTIFICACIONES
 */

require_once __DIR__ . '/moneda_funciones.php';

function plantilla_factura($pedido, $cliente, $direccion, $productos, $accion, $datos_parcial = []) {
    
    // ============================================
    // MONEDA HISTÓRICA DEL PEDIDO
    // ============================================
    $moneda = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
    $moneda_simbolo = getSimboloPorMoneda($moneda);
    $moneda_codigo = $moneda;
    
       $subtotal = floatval($pedido['subtotal_convertido'] ?? $pedido['subtotal'] ?? 0);
    $costo_envio = floatval($pedido['envio'] ?? 0);
    $total = floatval($pedido['total_convertido'] ?? $pedido['total'] ?? 0);
    $monto_pendiente = floatval($datos_parcial['monto_pendiente'] ?? 0);
    $es_parcial = $datos_parcial['es_parcial'] ?? false;
    $porcentaje_pagado = $datos_parcial['porcentaje'] ?? 100;
    
    $fecha_creacion = date('d/m/Y H:i', strtotime($pedido['fecha_pedido']));
    $fecha_entrega = date('d/m/Y', strtotime($pedido['fecha_pedido'] . ' +3 days'));
    $nombre_cliente = htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellidos']);
    $nombre_tienda = $GLOBALS['config']['sitio_nombre'] ?? 'Mi Tienda';
    
    // ===== Comentario personalizado según acción y tipo de pago =====
    $comentario = '';
    switch($accion) {
        case 'pagado':
            if ($es_parcial) {
                $comentario = "Estimado {$nombre_cliente}, se ha confirmado su pago parcial del pedido. El monto restante se pagará al recibir su pedido.";
            } else {
                $comentario = "Estimado {$nombre_cliente}, se ha confirmado su pago completo. Su pedido comenzará a procesarse.";
            }
            break;
        case 'pagado_parcial':
            $comentario = "Estimado {$nombre_cliente}, se ha confirmado su pago parcial. Recuerde que el monto restante se pagará al momento de la entrega.";
            break;
        case 'empaquetado':
            $comentario = "Estimado {$nombre_cliente}, su pedido ha pasado al proceso de empaquetado. Pronto estará en camino.";
            break;
        case 'transporte':
            $comentario = "Estimado {$nombre_cliente}, su pedido ha pasado al proceso de transporte. Por favor, comuníquese con su beneficiario.";
            break;
        case 'entregado':
            if ($monto_pendiente > 0) {
                $comentario = "Estimado {$nombre_cliente}, su pedido ha sido entregado. Realice el pago restante en el momento de la entrega. Muchas gracias por comprar en {$nombre_tienda}.";
            } else {
                $comentario = "Estimado {$nombre_cliente}, su pedido ha sido entregado. Muchas gracias por comprar en {$nombre_tienda}.";
            }
            break;
        case 'cancelado':
            $comentario = "Estimado {$nombre_cliente}, su pedido ha sido cancelado. Si tiene dudas, contáctenos.";
            break;
        default:
            $comentario = "Estimado {$nombre_cliente}, su pedido ha sido actualizado.";
    }
    
        // Productos - Generar HTML de filas
    $productos_html = '';
    foreach ($productos as $item) {
        // Precios históricos del pedido
        $precio_unit_hist = isset($item['precio_convertido']) && $item['precio_convertido'] !== null
            ? floatval($item['precio_convertido'])
            : floatval($item['precio_unitario'] ?? 0);
        $subtotal_hist = isset($item['subtotal_convertido']) && $item['subtotal_convertido'] !== null
            ? floatval($item['subtotal_convertido'])
            : floatval($item['subtotal'] ?? 0);
        
        $productos_html .= "
        <tr>
            <td align='left' style='padding:8px; border-bottom:1px solid #ddd;'>" . htmlspecialchars($item['nombre']) . "</td>
            <td align='center' style='padding:8px; border-bottom:1px solid #ddd;'>{$item['cantidad']}</td>
            <td align='right' style='padding:8px; border-bottom:1px solid #ddd;'>" . htmlspecialchars($moneda_simbolo) . number_format($precio_unit_hist, 2) . "</td>
            <td align='right' style='padding:8px; border-bottom:1px solid #ddd;'>" . htmlspecialchars($moneda_simbolo) . number_format($subtotal_hist, 2) . "</td>
        </tr>";
        // Si es combo, agregar fila de productos
if (isset($item['productos_detalle'])) {
    $productos_html .= "
    <tr>
        <td colspan='4' style='padding:5px 10px; font-size:10px; color:#4a5568; background:#f7fafc; border-bottom:1px solid #ddd;'>
            " . htmlspecialchars($item['productos_detalle']) . "
        </td>
    </tr>";
}
    }
    
      // ===== Total: según método de pago (contra entrega sin tachar) =====
$total_html = '';
if ($accion == 'cancelado') {
    // Cancelado: mostrar normal (sin tachar)
    $total_html = htmlspecialchars($moneda_simbolo) . number_format($total, 2) . " {$moneda_codigo}";
} elseif ($pedido['tipo_pago'] == 'contra_entrega') {
    // Contra entrega: NO tachar, mostrar total normal (aún no pagado)
    $total_html = htmlspecialchars($moneda_simbolo) . number_format($total, 2) . " {$moneda_codigo}";
} else {
    // Pagos por adelantado (completo o parcial): tachar total
    $total_html = "<span style='text-decoration: line-through; color: #c00;'>" . htmlspecialchars($moneda_simbolo) . number_format($total, 2) . " {$moneda_codigo}</span>";
    if ($es_parcial && $monto_pendiente > 0) {
        // Pago parcial: mostrar el monto pendiente (sin tachar)
        $total_html .= " <strong>Pendiente: " . htmlspecialchars($moneda_simbolo) . number_format($monto_pendiente, 2) . " {$moneda_codigo}</strong>";
    }
}
    
    // ===== Estado para mostrar en la línea de datos del pedido =====
    $estado_texto = '';
    switch($accion) {
        case 'pagado': $estado_texto = $es_parcial ? 'PAGO PARCIAL CONFIRMADO' : 'PAGO CONFIRMADO'; break;
        case 'pagado_parcial': $estado_texto = 'PAGO PARCIAL CONFIRMADO'; break;
        case 'empaquetado': $estado_texto = 'EMPAQUETADO'; break;
        case 'transporte': $estado_texto = 'EN TRANSPORTE'; break;
        case 'entregado': $estado_texto = $monto_pendiente > 0 ? 'ENTREGADO (PAGO PENDIENTE)' : 'ENTREGADO'; break;
        case 'cancelado': $estado_texto = 'CANCELADO'; break;
        default: $estado_texto = strtoupper($accion);
    }
    
        // Formatear números para el tfoot
    $subtotal_formateado = htmlspecialchars($moneda_simbolo) . number_format($subtotal, 2) . " {$moneda_codigo}";
    $envio_formateado = htmlspecialchars($moneda_simbolo) . number_format($costo_envio, 2) . " {$moneda_codigo}";
    
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Factura Pedido {$pedido['codigo']}</title>
       <style>
    @media print {
        body { margin: 0; padding: 0.5cm; }
        .no-print { display: none; }
    }
    body { 
        font-family: 'Courier New', Courier, monospace; 
        font-size: 11px; 
        line-height: 1.2; 
        margin: 0; 
        padding: 10px; 
    }
    .factura { 
        max-width: 700px; 
        margin: 0 auto; 
        border: 1px solid #000; 
        padding: 10px;
        margin-right: 15px;
    }
    .header { text-align: center; border-bottom: 1px solid #000; padding-bottom: 5px; margin-bottom: 10px; }
    .header h1 { margin: 0; font-size: 16px; }
    .info-line { display: flex; justify-content: space-between; border-bottom: 1px solid #ccc; padding: 3px 0; }
    .section { margin: 10px 0; }
    .section-title { font-weight: bold; background: #eee; padding: 3px; margin-bottom: 5px; text-transform: uppercase; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 8px; text-align: left !important; border-bottom: 1px solid #ddd; }
    th { background: #eee; font-weight: bold; }
    .text-right { text-align: right; }
    .pendiente { color: #c00; font-weight: bold; }
    .footer { text-align: center; border-top: 1px solid #000; margin-top: 10px; padding-top: 5px; font-size: 9px; }
</style>
    </head>
    <body>
        <div class='factura'>
            <div style='border-top: 1px solid #000;'></div>
                        <div style='display: flex; justify-content: space-between; padding: 5px 0;'>
                <strong>" . ($GLOBALS['config']['sitio_nombre'] ?? 'FACTURA') . "</strong>
                <span>Fecha: " . date('d/m/Y H:i') . "</span>
            </div>
            " . (!empty($GLOBALS['config']['proveedor_nombre_tienda']) ? "<div style='text-align: left; margin: 3px 0; font-size: 10px;'><strong>Tienda:</strong> " . htmlspecialchars($GLOBALS['config']['proveedor_nombre_tienda']) . "</div>" : "") . "
            <div style='text-align: left; margin: 5px 0;'>
                {$comentario}
            </div>
            <div style='border-bottom: 1px solid #000; margin-bottom: 10px;'></div>
            
            <div class='info-line'>
                <span><strong>No. {$pedido['codigo']}</strong></span>
                <span><strong>Fecha:</strong> {$fecha_creacion}</span>
                <span><strong>Estado:</strong> {$estado_texto}</span>
                                " . ($monto_pendiente > 0 && $accion != 'cancelado' ? "<span><strong>Pendiente:</strong> " . htmlspecialchars($moneda_simbolo) . number_format($monto_pendiente, 2) . " {$moneda_codigo}</span>" : "") . "
            </div>
            
            <div class='info-line'>
                <span><strong>Cliente:</strong> {$nombre_cliente}</span>
                <span><strong>Documento:</strong> " . htmlspecialchars($direccion['documento'] ?? '-') . "</span>
                <span><strong>Teléfono:</strong> " . htmlspecialchars($direccion['telefono'] ?? '-') . "</span>
            </div>           
            
             <div class='section'>
                <div class='section-title'>DETALLE DE PRODUCTOS</div>
                <table>
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th style='width:40px'>Cant.</th>
                            <th style='width:70px'>Precio</th>
                            <th style='width:70px'>Subtotal</th>
                        </thead>
                    <tbody>
                        {$productos_html}
                    </tbody>
                   <tfoot>
    <tr>
        <td colspan='3' style='padding:8px;'><strong>SUBTOTAL:</strong></td>
        <td style='padding:8px;'>{$subtotal_formateado}</td>
    </tr>
    <tr>
        <td colspan='3' style='padding:8px;'><strong>ENVÍO:</strong></td>
        <td style='padding:8px;'>{$envio_formateado}</td>
    </tr>
    <tr style='font-size:1.1rem;'>
        <td colspan='3' style='padding:8px;'><strong>TOTAL:</strong></td>
        <td style='padding:8px;'>{$total_html}</td>
    </tr>
</tfoot>
                </table>
            </div>
                                            <div class='section'>
    <div class='section-title'>MÉTODO DE PAGO</div>";

    // ===== Mostrar SOLO nombre de la pasarela y tipo (API / Manual) =====
    if ($pedido['tipo_pago'] == 'contra_entrega') {
        $html .= "<div class='info-line'>
            <span><strong>Método de pago:</strong></span>
            <span>Pago contra entrega (Manual)</span>
        </div>";
    } else {
        // Consultar la tabla `pasarelas` para obtener nombre y tipo
        $nombre_pasarela = ucfirst($pedido['tipo_pago']);
        $tipo_pasarela = 'API';
        if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli) {
            $stmt_pas = $GLOBALS['conn']->prepare("SELECT nombre, tipo FROM pasarelas WHERE slug = ? LIMIT 1");
            if ($stmt_pas) {
                $stmt_pas->bind_param("s", $pedido['tipo_pago']);
                $stmt_pas->execute();
                $res_pas = $stmt_pas->get_result()->fetch_assoc();
                $stmt_pas->close();
                if ($res_pas) {
                    $nombre_pasarela = $res_pas['nombre'];
                    $tipo_pasarela = ($res_pas['tipo'] === 'manual') ? 'Manual' : 'API';
                }
            }
        }
        $html .= "<div class='info-line'>
            <span><strong>Método de pago:</strong></span>
            <span>" . htmlspecialchars($nombre_pasarela) . " (" . htmlspecialchars($tipo_pasarela) . ")</span>
        </div>";
    }

    $html .= "
</div>
           <div class='section'>
    <div class='section-title'>DATOS DE ENTREGA</div>
    <div class='info-line'>
        <span><strong>Beneficiario:</strong></span>
        <span>" . htmlspecialchars($direccion['nombre_completo'] ?? '-') . "</span>
    </div>
    <div class='info-line'>
        <span><strong>Documento:</strong></span>
        <span>" . htmlspecialchars($direccion['documento'] ?? '-') . "</span>
    </div>
    <div class='info-line'>
        <span><strong>Teléfono:</strong></span>
        <span>" . htmlspecialchars($direccion['telefono'] ?? '-') . "</span>
    </div>
    <div class='info-line'>
        <span><strong>Dirección:</strong></span>
        <span>" . htmlspecialchars($direccion['direccion'] ?? '') . ", " . htmlspecialchars($direccion['municipio'] ?? '') . ", " . htmlspecialchars($direccion['provincia'] ?? '') . "</span>
    </div>
    " . (!empty($direccion['instrucciones']) ? "<div class='info-line'><span><strong>Instrucciones:</strong></span><span>" . nl2br(htmlspecialchars($direccion['instrucciones'])) . "</span></div>" : "") . "
</div>
                <div class='info-line'>
                    <span><strong>Fecha estimada:</strong></span>
                    <span>{$fecha_entrega}</span>
                </div>
            </div>
            
            <div class='footer'>
                <p>¡Gracias por comprar con nosotros!</p>
                <p class='no-print'>© " . date('Y') . " " . ($GLOBALS['config']['sitio_nombre'] ?? 'Mi Tienda') . "</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    return $html;
}

function plantilla_texto_simple($pedido, $accion) {
    if (!defined('BASE_URL')) {
        define('BASE_URL', 'https://catalejoo.com');
    }
    
    $texto = "Pedido {$pedido['codigo']} ha sido {$accion}.\n";
    $texto .= "Puedes ver los detalles en: " . BASE_URL . "/mis_pedidos.php";
    return $texto;
}

function plantilla_verificacion($cliente, $token) {
    if (!defined('BASE_URL')) {
        define('BASE_URL', 'https://catalejoo.com');
    }
    
    $enlace = BASE_URL . "/verificar_email.php?token=" . $token;
    
    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Verifica tu email</title>
        <style>
            @media print {
                body { margin: 0; padding: 0.5cm; }
            }
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 10px; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; }
            .button { display: inline-block; padding: 12px 25px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 20px; color: #718096; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>📧 Verifica tu email</h1>
            </div>
            <div class='content'>
                <h2>¡Hola " . htmlspecialchars($cliente['nombre']) . "!</h2>
                <p>Gracias por registrarte en nuestra tienda.</p>
                <p>Para comenzar a recibir notificaciones sobre el estado de tus pedidos, verifica tu email haciendo clic en el siguiente enlace:</p>
                <p style='text-align: center;'>
                    <a href='$enlace' class='button'>Verificar mi email</a>
                </p>
                <p>Si no solicitaste este registro, ignora este mensaje.</p>
                <p>¡Gracias por confiar en nosotros!</p>
            </div>
            <div class='footer'>
                <p>© " . date('Y') . " " . ($GLOBALS['config']['sitio_nombre'] ?? 'Mi Tienda') . "</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    return $html;
}

function plantilla_pendiente_pago($pedido, $cliente, $direccion, $productos, $metodo_pago, $datos_pago, $contacto, $datos_parcial = []) {
    
    // ============================================
    // MONEDA HISTÓRICA DEL PEDIDO
    // ============================================
    $moneda = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
    $moneda_simbolo = getSimboloPorMoneda($moneda);
    $moneda_codigo = $moneda;
    
       $subtotal = floatval($pedido['subtotal_convertido'] ?? $pedido['subtotal'] ?? 0);
    $costo_envio = floatval($pedido['envio'] ?? 0);
    $total = floatval($pedido['total_convertido'] ?? $pedido['total'] ?? 0);
    
    $porcentaje = $datos_parcial['porcentaje'] ?? 0;
    $monto_pagar = $datos_parcial['monto_pagar'] ?? $total;
    $monto_pendiente = floatval($datos_parcial['monto_pendiente'] ?? 0);
    $es_parcial = $datos_parcial['es_parcial'] ?? false;
    
    $fecha_creacion = date('d/m/Y H:i', strtotime($pedido['fecha_pedido']));
    $nombre_cliente = htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellidos']);
    $fecha_entrega = date('d/m/Y', strtotime($pedido['fecha_pedido'] . ' +3 days'));
    
    // ===== Comentario personalizado según método de pago =====
if ($metodo_pago == 'contra_entrega') {
    $comentario = "Estimado {$nombre_cliente}, usted ha solicitado la entrega de un pedido, pronto será contactado.";
} elseif ($es_parcial) {
    $comentario = "Estimado {$nombre_cliente}, usted ha creado un nuevo pedido de pago parcial. Realice el pago inicial para comenzar el proceso.";
} else {
    $comentario = "Estimado {$nombre_cliente}, usted ha creado un nuevo pedido. Proceda con el pago para confirmar su pedido.";
}
    
        // Productos (igual que en plantilla_factura)
    $productos_html = '';
    foreach ($productos as $item) {
        // Precios históricos del pedido
        $precio_unit_hist = isset($item['precio_convertido']) && $item['precio_convertido'] !== null
            ? floatval($item['precio_convertido'])
            : floatval($item['precio_unitario'] ?? 0);
        $subtotal_hist = isset($item['subtotal_convertido']) && $item['subtotal_convertido'] !== null
            ? floatval($item['subtotal_convertido'])
            : floatval($item['subtotal'] ?? 0);
        
        $productos_html .= "
        <tr>
            <td style='padding: 8px; border-bottom: 1px solid #ddd;'>" . htmlspecialchars($item['nombre']) . "</td>
            <td style='padding: 8px; border-bottom: 1px solid #ddd; text-align: center;'>{$item['cantidad']}</td>
            <td style='padding: 8px; border-bottom: 1px solid #ddd; text-align: right;'>" . htmlspecialchars($moneda_simbolo) . number_format($precio_unit_hist, 2) . "</td>
            <td style='padding: 8px; border-bottom: 1px solid #ddd; text-align: right;'>" . htmlspecialchars($moneda_simbolo) . number_format($subtotal_hist, 2) . "</td>
        </tr>";
        // Si es combo, agregar fila de productos
if (isset($item['productos_detalle'])) {
    $productos_html .= "
    <tr>
        <td colspan='4' style='padding:5px 10px; font-size:10px; color:#4a5568; background:#f7fafc; border-bottom:1px solid #ddd;'>
            " . htmlspecialchars($item['productos_detalle']) . "
        </td>
    </tr>";
}
    }
    
    // Instrucciones de pago
    $instrucciones_pago_html = '';
    if ($metodo_pago == 'contra_entrega') {
    $instrucciones_pago_html = "<p><strong>Método de pago:</strong> Pago contra entrega</p>
                                <p>Usted pagará el monto total al recibir su pedido. Un administrador se contactará con usted vía WhatsApp para coordinar la entrega.</p>";
    } elseif ($metodo_pago == 'paypal') {
        $instrucciones_pago_html = "<p><strong>PayPal:</strong> " . htmlspecialchars($datos_pago['paypal_email'] ?? '') . "</p>";
    } elseif ($metodo_pago == 'transferencia_usd') {
        $instrucciones_pago_html = "
            <p><strong>Banco:</strong> " . htmlspecialchars($datos_pago['usd_banco'] ?? '') . "</p>
            <p><strong>Cuenta USD:</strong> " . htmlspecialchars($datos_pago['usd_numero'] ?? '') . "</p>
            <p><strong>Beneficiario:</strong> " . htmlspecialchars($datos_pago['usd_beneficiario'] ?? '') . "</p>";
    } elseif ($metodo_pago == 'transferencia_clasica') {
        $instrucciones_pago_html = "
            <p><strong>Banco:</strong> " . htmlspecialchars($datos_pago['clasica_banco'] ?? '') . "</p>
            <p><strong>Cuenta:</strong> " . htmlspecialchars($datos_pago['clasica_numero'] ?? '') . "</p>
            <p><strong>Beneficiario:</strong> " . htmlspecialchars($datos_pago['clasica_beneficiario'] ?? '') . "</p>";
    }
    
    // Estado para mostrar
    if ($metodo_pago == 'contra_entrega') {
    $estado_texto = "PENDIENTE DE ENTREGA";
} else {
    $estado_texto = $es_parcial ? "PENDIENTE DE PAGO PARCIAL" : "PENDIENTE DE PAGO";
}
    
       // Total: tachado en rojo + pendiente al lado (igual que plantilla_factura)
   $total_html = '';
if ($es_parcial) {
    $total_html = "<span style='text-decoration: line-through; color: #c00;'>" . htmlspecialchars($moneda_simbolo) . number_format($total, 2) . " {$moneda_codigo}</span>";
    $total_html .= " <strong>Pendiente: " . htmlspecialchars($moneda_simbolo) . number_format($monto_pendiente, 2) . " {$moneda_codigo}</strong>";
} else {
    $total_html = htmlspecialchars($moneda_simbolo) . number_format($total, 2) . " {$moneda_codigo}";
}

$subtotal_formateado = htmlspecialchars($moneda_simbolo) . number_format($subtotal, 2) . " {$moneda_codigo}";
$envio_formateado = htmlspecialchars($moneda_simbolo) . number_format($costo_envio, 2) . " {$moneda_codigo}";
    
    $html = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Instrucciones de Pago - Pedido {$pedido['codigo']}</title>
    <style>
    @media print { body { margin: 0; padding: 0.5cm; } .no-print { display: none; } }
    body { font-family: 'Courier New', Courier, monospace; font-size: 11px; line-height: 1.2; margin: 0; padding: 10px; }
    .factura { max-width: 700px; margin: 0 auto; border: 1px solid #000; padding: 10px; margin-right: 15px; }
    .header { text-align: center; border-bottom: 1px solid #000; padding-bottom: 5px; margin-bottom: 10px; }
    .header h1 { margin: 0; font-size: 16px; }
    .info-line { display: flex; justify-content: space-between; border-bottom: 1px solid #ccc; padding: 3px 0; }
    .section { margin: 10px 0; }
    .section-title { font-weight: bold; background: #eee; padding: 3px; margin-bottom: 5px; text-transform: uppercase; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 8px; text-align: left !important; border-bottom: 1px solid #ddd; }
    th { background: #eee; font-weight: bold; }
    .text-right { text-align: right; }
    .pendiente { color: #c00; font-weight: bold; }
    .footer { text-align: center; border-top: 1px solid #000; margin-top: 10px; padding-top: 5px; font-size: 9px; }
    </style>
</head>
<body>
    <div class='factura'>
        <div style='border-top: 1px solid #000;'></div>
                <div style='display: flex; justify-content: space-between; padding: 5px 0;'>
            <strong>" . ($GLOBALS['config']['sitio_nombre'] ?? 'INSTRUCCIONES DE PAGO') . "</strong>
            <span>Fecha: " . date('d/m/Y H:i') . "</span>
        </div>
        " . (!empty($GLOBALS['config']['proveedor_nombre_tienda']) ? "<div style='text-align: left; margin: 3px 0; font-size: 10px;'><strong>Tienda:</strong> " . htmlspecialchars($GLOBALS['config']['proveedor_nombre_tienda']) . "</div>" : "") . "
        <div style='text-align: left; margin: 5px 0;'>{$comentario}</div>
        <div style='border-bottom: 1px solid #000; margin-bottom: 10px;'></div>
        
        <!-- Datos del pedido -->
        <div class='info-line'>
            <span><strong>No. {$pedido['codigo']}</strong></span>
            <span><strong>Fecha:</strong> {$fecha_creacion}</span>
            <span><strong>Estado:</strong> {$estado_texto}</span>
                        " . ($monto_pendiente > 0 ? "<span><strong>Pendiente:</strong> " . htmlspecialchars($moneda_simbolo) . number_format($monto_pendiente, 2) . " {$moneda_codigo}</span>" : "") . "
        </div>
        
        <!-- Datos del cliente -->
        <div class='info-line'>
            <span><strong>Cliente:</strong> {$nombre_cliente}</span>
            <span><strong>Documento:</strong> " . htmlspecialchars($direccion['documento'] ?? '-') . "</span>
            <span><strong>Teléfono:</strong> " . htmlspecialchars($direccion['telefono'] ?? '-') . "</span>
        </div>
        
        <div class='section'>
            <div class='section-title'>DETALLE DE PRODUCTOS</div>
            <table>
                <thead>
                    <tr><th>Producto</th><th style='width:40px'>Cant.</th><th style='width:70px'>Precio</th><th style='width:70px'>Subtotal</th></tr>
                </thead>
                <tbody>{$productos_html}</tbody>
                <tfoot>
                    <tr><td colspan='3'><strong>SUBTOTAL:</strong></td><td>{$subtotal_formateado}</td></tr>
                    <tr><td colspan='3'><strong>ENVÍO:</strong></td><td>{$envio_formateado}</td></tr>
                    <tr style='font-size:1.1rem;'><td colspan='3'><strong>TOTAL:</strong></td><td>{$total_html}</td></tr>
                </tfoot>
            </table>
        </div>
        
                <div class='section'>
            <div class='section-title'>MÉTODO DE PAGO</div>";
            
            if ($metodo_pago == 'contra_entrega') {
                $html .= "<div class='info-line'>
                    <span><strong>Método de pago:</strong></span>
                    <span>Pago contra entrega (Manual)</span>
                </div>";
            } else {
                // Consultar la tabla `pasarelas` para obtener nombre y tipo
                $nombre_pasarela = ucfirst($pedido['tipo_pago']);
                $tipo_pasarela = 'API';
                if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli) {
                    $stmt_pas = $GLOBALS['conn']->prepare("SELECT nombre, tipo FROM pasarelas WHERE slug = ? LIMIT 1");
                    if ($stmt_pas) {
                        $stmt_pas->bind_param("s", $pedido['tipo_pago']);
                        $stmt_pas->execute();
                        $res_pas = $stmt_pas->get_result()->fetch_assoc();
                        $stmt_pas->close();
                        if ($res_pas) {
                            $nombre_pasarela = $res_pas['nombre'];
                            $tipo_pasarela = ($res_pas['tipo'] === 'manual') ? 'Manual' : 'API';
                        }
                    }
                }
                $html .= "<div class='info-line'>
                    <span><strong>Método de pago:</strong></span>
                    <span>" . htmlspecialchars($nombre_pasarela) . " (" . htmlspecialchars($tipo_pasarela) . ")</span>
                </div>";
            }
            
$html .= "
        </div>
        
        <div class='section'>
    <div class='section-title'>DATOS DE ENTREGA</div>
    <div class='info-line'><span><strong>Beneficiario:</strong></span><span>" . htmlspecialchars($direccion['nombre_completo'] ?? '-') . "</span></div>
    <div class='info-line'><span><strong>Documento:</strong></span><span>" . htmlspecialchars($direccion['documento'] ?? '-') . "</span></div>
    <div class='info-line'><span><strong>Teléfono:</strong></span><span>" . htmlspecialchars($direccion['telefono'] ?? '-') . "</span></div>
    <div class='info-line'><span><strong>Dirección:</strong></span><span>" . htmlspecialchars($direccion['direccion'] ?? '') . ", " . htmlspecialchars($direccion['municipio'] ?? '') . ", " . htmlspecialchars($direccion['provincia'] ?? '') . "</span></div>
    " . (!empty($direccion['instrucciones']) ? "<div class='info-line'><span><strong>Instrucciones:</strong></span><span>" . nl2br(htmlspecialchars($direccion['instrucciones'])) . "</span></div>" : "") . "
            <div class='info-line'><span><strong>Fecha estimada:</strong></span><span>{$fecha_entrega}</span></div>
        </div>
        
        <div class='footer'>
            <p>¿Dudas? Contacte a " . htmlspecialchars($contacto['email'] ?? '') . " | " . htmlspecialchars($contacto['telefono'] ?? '') . "</p>
            <p>¡Gracias por comprar con nosotros!</p>
            <p class='no-print'>© " . date('Y') . " " . ($GLOBALS['config']['sitio_nombre'] ?? 'Mi Tienda') . "</p>
        </div>
    </div>
</body>
</html>
";

return $html;
}

/**
 * Plantilla: error al generar la URL de pago (pasarela API falló)
 *
 * @param array  $pedido  Datos del pedido
 * @param array  $cliente ['nombre' => ..., 'apellidos' => ...]
 * @param string $metodo  Slug de la pasarela (paypal, stripe, amazon, qvapay, ...)
 * @return string         HTML del correo
 */
function plantilla_error_pasarela($pedido, $cliente, $metodo) {
    if (!defined('BASE_URL')) {
        define('BASE_URL', 'https://catalejoo.com');
    }

    $moneda       = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
    $simbolo      = getSimboloPorMoneda($moneda);
    $codigo       = $pedido['codigo'] ?? '';
    $nombre       = htmlspecialchars(trim(($cliente['nombre'] ?? '') . ' ' . ($cliente['apellidos'] ?? '')));
    $sitio        = htmlspecialchars($GLOBALS['config']['sitio_nombre'] ?? 'CataLejoo');
    $metodo_txt   = htmlspecialchars(ucfirst($metodo));
    $link         = BASE_URL . '/mis_pedidos.php';
    $fecha        = date('d/m/Y H:i');

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Problema al procesar el pago</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 10px; background: #f4f4f4; }
            .container { max-width: 600px; margin: 0 auto; background: #fff; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; }
            .header { background: #d9534f; color: #fff; padding: 20px; text-align: center; }
            .header h1 { margin: 0; font-size: 20px; }
            .content { padding: 24px; }
            .info { background: #f9f9f9; border-left: 4px solid #d9534f; padding: 12px 16px; margin: 16px 0; font-size: 14px; }
            .button { display: inline-block; padding: 12px 24px; background: #5cb85c; color: #fff; text-decoration: none; border-radius: 5px; margin: 16px 0; font-weight: bold; }
            .footer { text-align: center; padding: 16px; color: #888; font-size: 12px; border-top: 1px solid #eee; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>⚠️ No pudimos procesar tu pago</h1>
            </div>
            <div class='content'>
                <p>Hola <strong>{$nombre}</strong>,</p>
                <p>Hubo un problema al conectar con el método de pago <strong>{$metodo_txt}</strong> para tu pedido <strong>{$codigo}</strong>.</p>
                <div class='info'>
                    <strong>Pedido:</strong> {$codigo}<br>
                    <strong>Método de pago:</strong> {$metodo_txt}<br>
                    <strong>Fecha del intento:</strong> {$fecha}
                </div>
                <p>Por favor, intenta de nuevo desde tu cuenta. Si el problema persiste, puedes elegir otro método de pago disponible o contactarnos.</p>
                <p style='text-align: center;'>
                    <a href='{$link}' class='button'>Ir a mis pedidos</a>
                </p>
                <p style='font-size: 13px; color: #777;'>Tu pedido sigue reservado. Solo necesitas completar el pago para que podamos procesarlo.</p>
            </div>
            <div class='footer'>
                <p>© " . date('Y') . " {$sitio}</p>
            </div>
        </div>
    </body>
    </html>
    ";

    return $html;
}
?>
<?php
// ===== ELIMINAR CUALQUIER SALIDA PREVIA =====
if (ob_get_level()) ob_end_clean();
ob_start();
// ============================================
// GENERAR PDF DEL PEDIDO (CORREGIDO)
// ============================================

require_once dirname(__DIR__) . '/includes/moneda_funciones.php';

/**
 * Limpia texto de caracteres extraños y BOM
 */
function limpiarTextoPDF($texto) {
    if (!is_string($texto)) return $texto;
    
    // Eliminar BOM UTF-8
    $texto = preg_replace('/^\xEF\xBB\xBF/', '', $texto);
    
    // Eliminar caracteres de control (excepto tab, LF, CR)
    $texto = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $texto);
    
    // Eliminar BOM mal codificado pero NO '?' legítimos
    $texto = str_replace(['ï»¿', '﻿'], '', $texto);
    
    // Limpiar espacios
    $texto = trim($texto);
    
    return $texto;
}

/**
 * Limpia strings fijos del HTML
 */
function limpiarString($texto) {
    $texto = preg_replace('/^\xEF\xBB\xBF/', '', $texto);
    $texto = preg_replace('/^\xFE\xFF/', '', $texto);
    $texto = preg_replace('/^\xFF\xFE/', '', $texto);
    $texto = preg_replace('/^[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $texto);
    $texto = str_replace(['ï»¿', '﻿'], '', $texto);
    return trim($texto);
}

function obtenerDatosPagoPDF($conn, $metodo_pago, $proveedor_id = 0) {
    $datos = [];
    $like = $metodo_pago . '_%';
    
    // Priorizar config del proveedor sobre la global
    $proveedor_id = intval($proveedor_id);
    
    $stmt = $conn->prepare("
        SELECT clave, valor, proveedor_id 
        FROM configuracion 
        WHERE clave LIKE ? 
          AND grupo = 'pagos' 
          AND proveedor_id IN (0, ?)
        ORDER BY proveedor_id DESC
    ");
    $stmt->bind_param("si", $like, $proveedor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $clave = str_replace($metodo_pago . '_', '', $row['clave']);
        // Solo sobrescribe si no existe (prioriza proveedor > global por ORDER BY DESC)
        if (!isset($datos[$clave]) || $row['proveedor_id'] == $proveedor_id) {
            $datos[$clave] = limpiarTextoPDF($row['valor']);
        }
    }
    $stmt->close();
    
    return $datos;
}

function generarPDFPedido($pedido_id, $conn, $estado = null) {
    // ===== FORZAR LIMPIEZA TOTAL =====
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start(); // Iniciar nuevo buffer limpio
    
    try {
        require_once dirname(__DIR__) . '/includes/tcpdf/tcpdf.php';
        
        // ===== OBTENER CONFIGURACIÓN =====
        $config = [];
        $stmt_config = $conn->prepare("SELECT clave, valor FROM configuracion WHERE clave IN ('sitio_nombre', 'logo_url', 'color_primario', 'color_secundario')");
        $stmt_config->execute();
        $result_config = $stmt_config->get_result();
        while ($row = $result_config->fetch_assoc()) {
            $config[$row['clave']] = limpiarTextoPDF($row['valor']);
        }
        
        $nombre_tienda = $config['sitio_nombre'] ?? 'Catalejo';
        $logo_url = $config['logo_url'] ?? '';
        $color_primario = $config['color_primario'] ?? '#667eea';
        $color_secundario = $config['color_secundario'] ?? '#764ba2';
        
        // ===== OBTENER DATOS DEL PEDIDO =====
        $stmt = $conn->prepare("SELECT p.*, c.nombre, c.apellidos, c.email as cliente_email 
                                FROM pedidos p 
                                JOIN clientes c ON p.cliente_id = c.id 
                                WHERE p.id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $pedido = $stmt->get_result()->fetch_assoc();
        
        if (!$pedido) {
            return generarPDFRespaldo($pedido_id, $conn);
        }
        
        // Limpiar datos del pedido
        foreach ($pedido as $key => $value) {
            if (is_string($value)) {
                $pedido[$key] = limpiarTextoPDF($value);
            }
        }
        
                // ============================================
        // MONEDA HISTÓRICA DEL PEDIDO
        // ============================================
        $moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
        $moneda_simbolo = getSimboloPorMoneda($moneda_pedido);
        $moneda_codigo = $moneda_pedido;
        
        // ===== OBTENER DIRECCIÓN =====
        $stmt = $conn->prepare("SELECT * FROM direcciones_envio WHERE pedido_id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $direccion = $stmt->get_result()->fetch_assoc();
        
        // Limpiar datos de dirección
        if ($direccion) {
            foreach ($direccion as $key => $value) {
                if (is_string($value)) {
                    $direccion[$key] = limpiarTextoPDF($value);
                }
            }
        }
        
        // ===== OBTENER PRODUCTOS =====
        $stmt = $conn->prepare("SELECT pd.*, p.nombre FROM pedido_detalles pd JOIN productos p ON pd.producto_id = p.id WHERE pd.pedido_id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $productos = $stmt->get_result();
        
       // ===== OBTENER COMBOS CON SUS PRODUCTOS =====
$stmt_combos = $conn->prepare("SELECT pd.*, c.nombre FROM pedido_detalles pd JOIN combos c ON pd.combo_id = c.id WHERE pd.pedido_id = ?");
$stmt_combos->bind_param("i", $pedido_id);
$stmt_combos->execute();
$combos = $stmt_combos->get_result();

// ===== COMBINAR ITEMS =====
$items = [];
while ($item = $productos->fetch_assoc()) {
    $item['tipo'] = 'producto';
    $item['nombre'] = limpiarTextoPDF($item['nombre']);
    $items[] = $item;
}

while ($combo = $combos->fetch_assoc()) {
    // Obtener productos del combo
    $stmt_prod_combo = $conn->prepare("SELECT cp.cantidad, p.nombre 
                                        FROM combo_productos cp 
                                        JOIN productos p ON cp.producto_id = p.id 
                                        WHERE cp.combo_id = ?");
    $stmt_prod_combo->bind_param("i", $combo['combo_id']);
    $stmt_prod_combo->execute();
    $productos_combo = $stmt_prod_combo->get_result();
    
    $productos_lista = [];
    while ($prod = $productos_combo->fetch_assoc()) {
        $productos_lista[] = $prod['cantidad'] . 'x ' . limpiarTextoPDF($prod['nombre']);
    }
    
    $total_productos = count($productos_lista);
    $combo['tipo'] = 'combo';
    $combo['nombre'] = limpiarTextoPDF($combo['nombre']);
    $combo['nombre'] = limpiarTextoPDF($combo['nombre']) . ' ( '  . $total_productos . ' Prod)';
    $combo['productos_detalle'] = implode(', ', $productos_lista);
    $items[] = $combo;
}

usort($items, function($a, $b) {
    if ($a['tipo'] === $b['tipo']) return 0;
    return ($a['tipo'] === 'producto') ? -1 : 1;
});
        
        // ============================================
        // CALCULAR TOTALES (moneda del pedido)
        // ============================================
        // Subtotal: sumar de items (preferir subtotal_convertido)
        $subtotal = 0;
        foreach ($items as $it) {
            $sub = isset($it['subtotal_convertido']) && $it['subtotal_convertido'] !== null
                ? floatval($it['subtotal_convertido'])
                : floatval($it['subtotal'] ?? 0);
            $subtotal += $sub;
        }
        
                $costo_envio = floatval($pedido['envio'] ?? 0);
        
        // Total: preferir total_convertido (moneda del pedido), fallback a total (USD)
        $total = !empty($pedido['total_convertido']) 
            ? floatval($pedido['total_convertido']) 
            : floatval($pedido['total']);
        
        $fecha_estimada = date('d/m/Y', strtotime($pedido['fecha_pedido'] . ' +3 days'));
        // Nombre del método: leer de pasarelas.nombre (escalable)
$nombre_metodo = ucfirst(str_replace('_', ' ', $pedido['tipo_pago'] ?? 'contra_entrega'));
if (!empty($pedido['tipo_pago'])) {
    $stmt_nombre_pdf = $conn->prepare("SELECT nombre FROM pasarelas WHERE slug = ? LIMIT 1");
    $stmt_nombre_pdf->bind_param("s", $pedido['tipo_pago']);
    $stmt_nombre_pdf->execute();
    $res_nombre_pdf = $stmt_nombre_pdf->get_result()->fetch_assoc();
    $stmt_nombre_pdf->close();
    if (!empty($res_nombre_pdf['nombre'])) {
        $nombre_metodo = $res_nombre_pdf['nombre'];
    }
}
$nombre_metodo = limpiarTextoPDF($nombre_metodo);
  
 // Obtener proveedor del pedido (desde pedido_detalles)
$proveedor_pedido_pdf = 0;
$stmt_prov_pdf = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? AND proveedor_id > 0 LIMIT 1");
$stmt_prov_pdf->bind_param("i", $pedido_id);
$stmt_prov_pdf->execute();
$res_prov_pdf = $stmt_prov_pdf->get_result()->fetch_assoc();
$proveedor_pedido_pdf = $res_prov_pdf['proveedor_id'] ?? 0;
$stmt_prov_pdf->close();

$datos_metodo = obtenerDatosPagoPDF($conn, $pedido['tipo_pago'] ?? 'contra_entrega', $proveedor_pedido_pdf);
        $estado_texto = ucfirst(str_replace('_', ' ', $pedido['estado_actual'] ?? 'pendiente'));
        $estado_texto = limpiarTextoPDF($estado_texto);
        
        // ===== LIMPIAR TEXTOS FIJOS =====
        $fecha_label = limpiarString(' Fecha:');
        $total_label = limpiarString(' Total:');
        $estado_label = limpiarString(' Estado:');
        $cliente_label = limpiarString(' Cliente:');
        $email_label = limpiarString(' Email:');
        $telefono_label = limpiarString(' Teléfono:');
        $detalle_label = limpiarString(' DETALLE DE PRODUCTOS');
        $subtotal_label = limpiarString(' Subtotal');
        $envio_label = limpiarString(' Envío');
        $total_final_label = limpiarString(' TOTAL');
        $pago_label = limpiarString(' DATOS DEL PAGO');
        $entrega_label = limpiarString(' DATOS DE ENTREGA');
        $fecha_estimada_label = limpiarString(' FECHA ESTIMADA DE ENTREGA:');
        
        // ===== CREAR PDF =====
        $pdf = new TCPDF('P', 'mm', 'LETTER', true, 'UTF-8', false);
        $pdf->SetCreator($nombre_tienda);
        $pdf->SetAuthor($nombre_tienda);
        $pdf->SetTitle('Pedido #' . $pedido['codigo']);
        $pdf->SetMargins(20, 5, 8);
        $pdf->SetRightMargin(20);
        $pdf->SetAutoPageBreak(true, 10);
        $pdf->AddPage();
        
        // ===== ENCABEZADO =====
        $pdf->SetY(4);
        
        // Logo
                if (!empty($logo_url)) {
            // Construir ruta absoluta robusta (funciona en web y en cron)
            $doc_root = $_SERVER['DOCUMENT_ROOT'] ?? '';
            if (empty($doc_root)) {
                // Fallback: subir 1 nivel desde includes/ (a public_html/)
                $doc_root = dirname(__DIR__, 1);
            }
            
            $logo_path = rtrim($doc_root, '/') . '/' . ltrim($logo_url, '/');
            
            if (file_exists($logo_path)) {
                $pdf->Image($logo_path, 32, 7, 10, 0, '', '', 'T', false, 300, '', false, false, 0, false, false, false);
                $pdf->SetY(4);
                $pdf->SetX(47);
                $pdf->SetFont('helvetica', 'B', 14);
                $pdf->SetTextColor(102, 126, 234);
                $pdf->Cell(0, 8, $nombre_tienda, 0, 1, 'L');
            } else {
                // Fallback: sin logo
                $pdf->SetFont('helvetica', 'B', 16);
                $pdf->SetTextColor(102, 126, 234);
                $pdf->Cell(0, 8, $nombre_tienda, 0, 1, 'C');
            }
        } else {
            $pdf->SetFont('helvetica', 'B', 16);
            $pdf->SetTextColor(102, 126, 234);
            $pdf->Cell(0, 8, $nombre_tienda, 0, 1, 'C');
        }
        
        $pdf->Ln(1);
        
        // ============================================
        // NOMBRE DEL PROVEEDOR
        // ============================================
        $nombre_proveedor_pdf = '';
        if (!empty($pedido['proveedor_id'])) {
            $stmt_prov_pdf = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ? LIMIT 1");
            if ($stmt_prov_pdf) {
                $stmt_prov_pdf->bind_param("i", $pedido['proveedor_id']);
                $stmt_prov_pdf->execute();
                $res_prov_pdf = $stmt_prov_pdf->get_result()->fetch_assoc();
                $stmt_prov_pdf->close();
                if (!empty($res_prov_pdf['nombre_tienda'])) {
                    $nombre_proveedor_pdf = limpiarTextoPDF($res_prov_pdf['nombre_tienda']);
                }
            }
        }
        
        // Línea 1: COMPROBANTE DE PEDIDO + código (juntos)
        $pdf->SetFont('helvetica', '', 8);
        $pdf->SetTextColor(100, 100, 100);
        $pdf->Cell(0, 4, 'COMPROBANTE DE PEDIDO- ' . $pedido['codigo'], 0, 1, 'C');
        
        // Línea 2: Nombre de la tienda del proveedor (si existe)
        if (!empty($nombre_proveedor_pdf)) {
            $pdf->SetFont('helvetica', 'I', 10);
            $pdf->SetTextColor(102, 126, 234);
            $pdf->Cell(0, 5, 'Tienda: ' . $nombre_proveedor_pdf, 0, 1, 'C');
        }
        
        $pdf->Ln(1);
        $pdf->SetDrawColor(102, 126, 234);
        $pdf->Line(20, 24, 195, 24);
        $pdf->SetY(26);
        
// =============================================================
// ===== INFORMACIÓN DEL PEDIDO (tabla con TCPDF) =====
// =============================================================

// Primera línea: Fecha | Total | Estado
$pdf->SetFont('helvetica', '', 7);
$pdf->SetFillColor(247, 250, 252);
$pdf->SetTextColor(45, 55, 72);

// Fila 1: Fecha, Total, Estado
$pdf->Cell(50, 5, $fecha_label . ' ' . date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])), 'LR', 0, 'L', 1);
$pdf->Cell(50, 5, $total_label . ' ' . $moneda_simbolo . number_format($total, 2) . ' ' . $moneda_codigo, 'LR', 0, 'L', 1);
$pdf->Cell(60, 5, $estado_label . ' ' . $estado_texto, 'LR', 1, 'L', 1);

// Fila 2: Cliente, Email, Teléfono
$pdf->Cell(50, 5, $cliente_label . ' ' . htmlspecialchars($pedido['nombre'] . ' ' . ($pedido['apellidos'] ?? '')), 'LR', 0, 'L', 1);
$pdf->Cell(50, 5, $email_label . ' ' . htmlspecialchars($pedido['cliente_email']), 'LR', 0, 'L', 1);
$pdf->Cell(60, 5, $telefono_label . ' ' . htmlspecialchars($direccion['telefono'] ?? '-'), 'LR', 1, 'L', 1);

// Línea final
$pdf->Cell(160, 0, '', 'T', 1);
$pdf->Ln(2);

// =============================================================
// ===== TABLA DE PRODUCTOS CON TCPDF NATIVO =====
// =============================================================

// Añadir título de la sección
$html = '';
$html = '<div class="section-title">' . $detalle_label . '</div>';

// Escribir el título en el PDF
$pdf->writeHTML($html, true, false, true, false, '');
$html = ''; // Limpiar HTML para seguir con el contenido

// Anchos de columna en mm
$w = array(90, 20, 25, 25);

// Encabezados
$pdf->SetFont('helvetica', 'B', 7);
$pdf->SetFillColor(102, 126, 234);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell($w[0], 5, 'Producto', 1, 0, 'L', 1);
$pdf->Cell($w[1], 5, 'Cant', 1, 0, 'C', 1);
$pdf->Cell($w[2], 5, 'Precio', 1, 0, 'R', 1);
$pdf->Cell($w[3], 5, 'Subtotal', 1, 1, 'R', 1);

// Datos
$pdf->SetFont('helvetica', '', 7);
$pdf->SetTextColor(45, 55, 72);
$pdf->SetFillColor(255, 255, 255);

foreach ($items as $item) {
    // Precios históricos del pedido
    $precio_unit_hist = isset($item['precio_convertido']) && $item['precio_convertido'] !== null
        ? floatval($item['precio_convertido'])
        : floatval($item['precio_unitario'] ?? 0);
    $subtotal_hist = isset($item['subtotal_convertido']) && $item['subtotal_convertido'] !== null
        ? floatval($item['subtotal_convertido'])
        : floatval($item['subtotal'] ?? 0);
    
    // Si es combo, mostrar el combo y sus productos
    if (isset($item['productos_detalle'])) {
        // === FILA DEL COMBO ===
        $pdf->Cell($w[0], 4.5, $item['nombre'], 'LR', 0, 'L', 0);
        $pdf->Cell($w[1], 4.5, $item['cantidad'], 'LR', 0, 'C', 0);
        $pdf->Cell($w[2], 4.5, $moneda_simbolo . number_format($precio_unit_hist, 2), 'LR', 0, 'R', 0);
        $pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($subtotal_hist, 2), 'LR', 1, 'R', 0);
        
        // === FILAS DE PRODUCTOS DEL COMBO (debajo del combo) ===
// Obtener los productos del combo desde la base de datos
$stmt_prod_combo = $conn->prepare("SELECT cp.cantidad, p.nombre 
                                    FROM combo_productos cp 
                                    JOIN productos p ON cp.producto_id = p.id 
                                    WHERE cp.combo_id = ?");
$stmt_prod_combo->bind_param("i", $item['combo_id']);
$stmt_prod_combo->execute();
$productos_combo = $stmt_prod_combo->get_result();

while ($prod = $productos_combo->fetch_assoc()) {
    // Sangría para mostrar jerarquía
    $sangria = 5;
    
    $pdf->SetFont('helvetica', 'I', 6);
    $pdf->SetTextColor(74, 85, 104);
    
    // Celda de sangría (sin borde visible, pero con borde LR para que coincida con la tabla)
    $pdf->Cell($sangria, 4, '', 'LR', 0, 'L', 0);
    
    // Nombre del producto con sangría
    $pdf->Cell($w[0] - $sangria, 4, $prod['nombre'], 'LR', 0, 'L', 0);
    
    // Cantidad
    $pdf->Cell($w[1], 4, $prod['cantidad'], 'LR', 0, 'C', 0);
    
    // Precio (vacío)
    $pdf->Cell($w[2], 4, '', 'LR', 0, 'R', 0);
    
    // Subtotal (vacío)
    $pdf->Cell($w[3], 4, '', 'LR', 1, 'R', 0);
}
        
        $pdf->SetFont('helvetica', '', 7);
        $pdf->SetTextColor(45, 55, 72);
        
        } else {
        // === PRODUCTO NORMAL ===
        $pdf->Cell($w[0], 4.5, $item['nombre'], 'LR', 0, 'L', 0);
        $pdf->Cell($w[1], 4.5, $item['cantidad'], 'LR', 0, 'C', 0);
        $pdf->Cell($w[2], 4.5, $moneda_simbolo . number_format($precio_unit_hist, 2), 'LR', 0, 'R', 0);
        $pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($subtotal_hist, 2), 'LR', 1, 'R', 0);
    }
}
        
// =============================================================
// ===== TOTALES =====
// =============================================================

// (totales ya calculados arriba)

// Fila de SUBTOTAL
$pdf->SetFont('helvetica', 'B', 7);
$pdf->SetTextColor(45, 55, 72);
$pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
$pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
$pdf->Cell($w[2], 4.5, 'Subtotal:', 'LR', 0, 'R', 0);
$pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($subtotal, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 0);

// Fila de ENVÍO
$pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
$pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
$pdf->Cell($w[2], 4.5, 'Envío:', 'LR', 0, 'R', 0);
$pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($costo_envio, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 0);

// Fila de TOTAL (con fondo y negrita)
$pdf->SetFont('helvetica', 'B', 8);
$pdf->SetFillColor(102, 126, 234);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell($w[0], 5, '', 'LR', 0, 'L', 0);
$pdf->Cell($w[1], 5, '', 'LR', 0, 'C', 0);
$pdf->Cell($w[2], 5, 'TOTAL:', 'LR', 0, 'R', 1);
$pdf->Cell($w[3], 5, $moneda_simbolo . number_format($total, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 1);

// Restaurar colores
$pdf->SetTextColor(45, 55, 72);
$pdf->SetFillColor(255, 255, 255);

// ============================================
// DESGLOSE DE PAGO PARCIAL / ENTREGA
// Se muestra siempre que estado_pago sea parcial o entrega,
// sin importar estado_actual (para auditoría)
// ============================================
$monto_pagado_pdf = floatval($pedido['monto_pagado'] ?? 0);
$monto_pendiente_pdf = floatval($pedido['monto_pendiente'] ?? 0);
$porcentaje_pagado_pdf = floatval($pedido['porcentaje_pagado'] ?? 0);
$estado_pago_pdf = $pedido['estado_pago'] ?? '';

if ($estado_pago_pdf === 'pendiente_parcial') {
    if ($monto_pagado_pdf > 0) {
        // Ya pagó algo
        $pdf->SetFont('helvetica', 'B', 7);
        $pdf->SetTextColor(16, 185, 129); // verde
        $pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
        $pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
        $pdf->Cell($w[2], 4.5, 'Ya pagó:', 'LR', 0, 'R', 0);
        $pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($monto_pagado_pdf, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 0);
        
        $pdf->SetTextColor(237, 137, 54); // naranja
        $pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
        $pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
        $pdf->Cell($w[2], 4.5, 'Pendiente al recibir:', 'LR', 0, 'R', 0);
        $pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($monto_pendiente_pdf, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 0);
    } else {
        // Aún no ha pagado la parte online
        $porcentaje_ahora_pdf = 100 - $porcentaje_pagado_pdf;
        $pdf->SetFont('helvetica', 'B', 7);
        $pdf->SetTextColor(16, 185, 129);
        $pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
        $pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
        $pdf->Cell($w[2], 4.5, 'Paga ahora (' . $porcentaje_ahora_pdf . '%):', 'LR', 0, 'R', 0);
        $pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($monto_pagado_pdf, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 0);
        
        $pdf->SetTextColor(237, 137, 54);
        $pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
        $pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
        $pdf->Cell($w[2], 4.5, 'Paga al recibir:', 'LR', 0, 'R', 0);
        $pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($monto_pendiente_pdf, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 0);
    }
} elseif ($estado_pago_pdf === 'pendiente_entrega') {
    // Pago contra entrega
    $monto_mostrar_entrega = ($monto_pendiente_pdf > 0) ? $monto_pendiente_pdf : $total;
    $texto_entrega = ($monto_pendiente_pdf > 0) ? 'Paga al recibir:' : 'Se iba a pagar al recibir:';
    
    $pdf->SetFont('helvetica', 'B', 7);
    $pdf->SetTextColor(237, 137, 54);
    $pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
    $pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
    $pdf->Cell($w[2], 4.5, $texto_entrega, 'LR', 0, 'R', 0);
    $pdf->Cell($w[3], 4.5, $moneda_simbolo . number_format($monto_mostrar_entrega, 2) . ' ' . $moneda_codigo, 'LR', 1, 'R', 0);
} elseif ($estado_pago_pdf === 'pagado') {
    // Pagado completamente
    $pdf->SetFont('helvetica', 'B', 7);
    $pdf->SetTextColor(16, 185, 129);
    $pdf->Cell($w[0], 4.5, '', 'LR', 0, 'L', 0);
    $pdf->Cell($w[1], 4.5, '', 'LR', 0, 'C', 0);
    $pdf->Cell($w[2], 4.5, 'Pagado completamente', 'LR', 0, 'R', 0);
    $pdf->Cell($w[3], 4.5, '', 'LR', 1, 'R', 0);
}

// Restaurar colores
$pdf->SetTextColor(45, 55, 72);
$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('helvetica', '', 7);

// Línea final de la tabla
$pdf->Cell(array_sum($w), 0, '', 'T', 1);
$pdf->Ln(2);

// =============================================================
// ===== MÉTODO DE PAGO (tabla) =====
// =============================================================

$pdf->Ln(2);
$pdf->SetFont('helvetica', 'B', 9);
$pdf->SetTextColor(45, 55, 72);
$pdf->Cell(0, 5, $pago_label, 0, 1, 'L');
$pdf->SetDrawColor(102, 126, 234);
$pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 160, $pdf->GetY());
$pdf->Ln(1);

// Anchos para la tabla de pago (2 columnas)
$w_pago = array(40, 120);

// Encabezados
$pdf->SetFont('helvetica', 'B', 7);
$pdf->SetFillColor(102, 126, 234);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell($w_pago[0], 5, 'Campo', 1, 0, 'L', 1);
$pdf->Cell($w_pago[1], 5, 'Valor', 1, 1, 'L', 1);

// Datos
$pdf->SetFont('helvetica', '', 7);
$pdf->SetTextColor(45, 55, 72);
$pdf->SetFillColor(255, 255, 255);

// Método de pago
$pdf->Cell($w_pago[0], 4.5, 'Método', 'LR', 0, 'L', 0);
$pdf->Cell($w_pago[1], 4.5, $nombre_metodo, 'LR', 1, 'L', 0);

foreach ($datos_metodo as $clave => $valor) {
    if ($clave != 'activo' && $clave != 'modo' && !empty($valor)) {
        $pdf->Cell($w_pago[0], 4.5, ucfirst(str_replace('_', ' ', $clave)), 'LR', 0, 'L', 0);
        $pdf->Cell($w_pago[1], 4.5, htmlspecialchars($valor), 'LR', 1, 'L', 0);
    }
}

// Línea final
$pdf->Cell(array_sum($w_pago), 0, '', 'T', 1);
$pdf->Ln(2);

// =============================================================
// ===== DATOS DE ENTREGA (tabla) =====
// =============================================================

$pdf->SetFont('helvetica', 'B', 9);
$pdf->SetTextColor(45, 55, 72);
$pdf->Cell(0, 5, $entrega_label, 0, 1, 'L');
$pdf->SetDrawColor(102, 126, 234);
$pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 160, $pdf->GetY());
$pdf->Ln(1);

// Anchos para la tabla de entrega (2 columnas)
$w_entrega = array(40, 120);

// Encabezados
$pdf->SetFont('helvetica', 'B', 7);
$pdf->SetFillColor(102, 126, 234);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell($w_entrega[0], 5, 'Campo', 1, 0, 'L', 1);
$pdf->Cell($w_entrega[1], 5, 'Valor', 1, 1, 'L', 1);

// Datos
$pdf->SetFont('helvetica', '', 7);
$pdf->SetTextColor(45, 55, 72);
$pdf->SetFillColor(255, 255, 255);

$pdf->Cell($w_entrega[0], 4.5, 'Beneficiario', 'LR', 0, 'L', 0);
$pdf->Cell($w_entrega[1], 4.5, htmlspecialchars($direccion['nombre_completo'] ?? '-'), 'LR', 1, 'L', 0);

$pdf->Cell($w_entrega[0], 4.5, 'Documento', 'LR', 0, 'L', 0);
$pdf->Cell($w_entrega[1], 4.5, htmlspecialchars($direccion['documento'] ?? '-'), 'LR', 1, 'L', 0);

$pdf->Cell($w_entrega[0], 4.5, 'Teléfono', 'LR', 0, 'L', 0);
$pdf->Cell($w_entrega[1], 4.5, htmlspecialchars($direccion['telefono'] ?? '-'), 'LR', 1, 'L', 0);

$pdf->Cell($w_entrega[0], 4.5, 'Dirección', 'LR', 0, 'L', 0);
$pdf->Cell($w_entrega[1], 4.5, htmlspecialchars($direccion['direccion'] ?? '') . ', ' . htmlspecialchars($direccion['municipio'] ?? '') . ', ' . htmlspecialchars($direccion['provincia'] ?? ''), 'LR', 1, 'L', 0);

if (!empty($direccion['instrucciones'])) {
    $pdf->Cell($w_entrega[0], 4.5, 'Instrucciones', 'LR', 0, 'L', 0);
    $pdf->Cell($w_entrega[1], 4.5, htmlspecialchars($direccion['instrucciones']), 'LR', 1, 'L', 0);
}

// Línea final
$pdf->Cell(array_sum($w_entrega), 0, '', 'T', 1);
$pdf->Ln(2);

// =============================================================
// ===== FECHA ESTIMADA =====
// =============================================================

$pdf->SetFont('helvetica', 'B', 8);
$pdf->SetFillColor(102, 126, 234);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(0, 6, $fecha_estimada_label . ' ' . $fecha_estimada, 0, 1, 'C', 1);
$pdf->Ln(2);

// =============================================================
// ===== FOOTER =====
// =============================================================

$pdf->SetFont('helvetica', 'I', 7);
$pdf->SetTextColor(160, 174, 192);
$pdf->Cell(0, 4, '¡Gracias por confiar en nosotros!', 0, 1, 'C');
$pdf->Cell(0, 4, $nombre_tienda . ' - ' . date('Y'), 0, 1, 'C');
        
        // ===== LIMPIEZA COMPLETA DEL HTML =====
        // 1. Eliminar BOM UTF-8
        $html = preg_replace('/^\xEF\xBB\xBF/', '', $html);
        
        // 2. Eliminar cualquier caracter antes del primer '<'
        $html = preg_replace('/^[^<]*/', '', $html);
        
        // 3. Eliminar caracteres de control invisibles
        $html = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $html);
        
        // 4. Limpiar espacios al inicio
        $html = ltrim($html);
        
        // 5. Si no empieza con '<', buscar el primer '<'
        if (strpos($html, '<') !== 0 && strpos($html, '<') !== false) {
            $html = substr($html, strpos($html, '<'));
        }
        
        // 6. Eliminar caracteres específicos problemáticos
        $html = str_replace(['ï»¿', '﻿', '?'], '', $html);
        
        // 7. Eliminar ? que aparecen solos antes de palabras
        $html = preg_replace('/\?\s*([A-ZÁÉÍÓÚÑ])/', '$1', $html);
        
        $pdf->writeHTML($html, true, false, true, false, '');
        
        return $pdf->Output('pedido_' . $pedido['codigo'] . '.pdf', 'S');
        
    } catch (Exception $e) {
        error_log("ERROR en generarPDFPedido: " . $e->getMessage());
        return generarPDFRespaldo($pedido_id, $conn);
    }
}

/**
 * PDF DE RESPALDO (con productos)
 */
function generarPDFRespaldo($pedido_id, $conn) {
    try {
        require_once dirname(__DIR__) . '/includes/tcpdf/tcpdf.php';
        
        // Obtener datos del pedido
        $stmt = $conn->prepare("SELECT p.*, c.nombre, c.apellidos 
                                FROM pedidos p 
                                JOIN clientes c ON p.cliente_id = c.id 
                                WHERE p.id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $pedido = $stmt->get_result()->fetch_assoc();
        
                $moneda_pedido = 'USD';
        $moneda_simbolo = '$';
        $moneda_codigo = 'USD';
        
                if (!$pedido) {
            $codigo = 'DESCONOCIDO';
            $total = '0.00';
        } else {
            $codigo = limpiarTextoPDF($pedido['codigo']);
            
            // Total: preferir total_convertido (moneda del pedido), fallback a total (USD)
            $total_hist = !empty($pedido['total_convertido']) 
                ? floatval($pedido['total_convertido']) 
                : floatval($pedido['total']);
            $total = number_format($total_hist, 2);
            
            $cliente = limpiarTextoPDF($pedido['nombre'] . ' ' . $pedido['apellidos']);
            
            // Moneda del pedido
            $moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
            $moneda_simbolo = getSimboloPorMoneda($moneda_pedido);
            $moneda_codigo = $moneda_pedido;
        }
        
        // Obtener productos del pedido
        $stmt_prod = $conn->prepare("SELECT pd.*, p.nombre 
                                     FROM pedido_detalles pd 
                                     JOIN productos p ON pd.producto_id = p.id 
                                     WHERE pd.pedido_id = ?");
        $stmt_prod->bind_param("i", $pedido_id);
        $stmt_prod->execute();
        $productos = $stmt_prod->get_result();
        
        $pdf = new TCPDF('P', 'mm', 'LETTER', true, 'UTF-8', false);
        $pdf->SetCreator('Catalejo');
        $pdf->SetAuthor('Catalejo');
        $pdf->SetTitle('Pedido #' . $codigo);
        $pdf->SetMargins(15, 10, 15);
        $pdf->AddPage();
        
        // Título
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->SetTextColor(102, 126, 234);
        $pdf->Cell(0, 8, 'CATALEJO', 0, 1, 'C');
        $pdf->SetTextColor(50, 50, 50);
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 6, 'Pedido #' . $codigo, 0, 1, 'C');
        $pdf->Ln(2);
        
        // Cliente
        $pdf->SetFont('helvetica', '', 9);
        $pdf->Cell(0, 5, 'Cliente: ' . ($cliente ?? 'N/A'), 0, 1, 'L');
        $pdf->Cell(0, 5, 'Fecha: ' . date('d/m/Y H:i', strtotime($pedido['fecha_pedido'] ?? date('Y-m-d H:i:s'))), 0, 1, 'L');
        $pdf->Ln(2);
        
        // Tabla de productos
        $pdf->SetFont('helvetica', 'B', 8);
        $pdf->SetFillColor(102, 126, 234);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->Cell(80, 5, 'Producto', 1, 0, 'L', 1);
        $pdf->Cell(20, 5, 'Cant', 1, 0, 'C', 1);
        $pdf->Cell(30, 5, 'Precio', 1, 0, 'R', 1);
        $pdf->Cell(30, 5, 'Subtotal', 1, 1, 'R', 1);
        
        $pdf->SetFont('helvetica', '', 8);
        $pdf->SetTextColor(45, 55, 72);
        $pdf->SetFillColor(255, 255, 255);
        
        $subtotal = 0;
                while ($item = $productos->fetch_assoc()) {
            // Precios históricos del pedido
            $precio_unit_hist = isset($item['precio_convertido']) && $item['precio_convertido'] !== null
                ? floatval($item['precio_convertido'])
                : floatval($item['precio_unitario'] ?? 0);
            $subtotal_hist = isset($item['subtotal_convertido']) && $item['subtotal_convertido'] !== null
                ? floatval($item['subtotal_convertido'])
                : floatval($item['subtotal'] ?? 0);
            
            $subtotal += $subtotal_hist;
            $pdf->Cell(80, 4.5, limpiarTextoPDF($item['nombre']), 'LR', 0, 'L', 0);
            $pdf->Cell(20, 4.5, $item['cantidad'], 'LR', 0, 'C', 0);
            $pdf->Cell(30, 4.5, $moneda_simbolo . number_format($precio_unit_hist, 2), 'LR', 0, 'R', 0);
            $pdf->Cell(30, 4.5, $moneda_simbolo . number_format($subtotal_hist, 2), 'LR', 1, 'R', 0);
        }
        
        // Línea final
        $pdf->Cell(160, 0, '', 'T', 1);
        $pdf->Ln(2);
        
        // Totales
                $pdf->SetFont('helvetica', 'B', 10);
        $pdf->Cell(100, 5, '', 0, 0, 'L');
        $pdf->Cell(30, 5, 'Subtotal:', 0, 0, 'R');
        $pdf->Cell(30, 5, $moneda_simbolo . number_format($subtotal, 2) . ' ' . $moneda_codigo, 0, 1, 'R');
        
        $costo_envio = floatval($pedido['envio'] ?? 0);
        $pdf->Cell(100, 5, '', 0, 0, 'L');
        $pdf->Cell(30, 5, 'Envío:', 0, 0, 'R');
        $pdf->Cell(30, 5, $moneda_simbolo . number_format($costo_envio, 2) . ' ' . $moneda_codigo, 0, 1, 'R');
        
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->SetTextColor(102, 126, 234);
        $pdf->Cell(100, 6, '', 0, 0, 'L');
        $pdf->Cell(30, 6, 'TOTAL:', 0, 0, 'R');
        $pdf->Cell(30, 6, $moneda_simbolo . $total . ' ' . $moneda_codigo, 0, 1, 'R');
        
        $pdf->Ln(4);
        $pdf->SetTextColor(50, 50, 50);
        $pdf->SetFont('helvetica', 'I', 9);
        $pdf->Cell(0, 6, 'Gracias por su compra en Catalejo', 0, 1, 'C');
        
        return $pdf->Output('pedido_' . $codigo . '.pdf', 'S');
        
    } catch (Exception $e) {
        error_log("ERROR en PDF de respaldo: " . $e->getMessage());
        return null;
    }
}
?>
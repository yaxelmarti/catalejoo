<?php
// ============================================
// CLIENTE AJAX - BACKEND MEJORADO Y SEGURO
// ============================================

// ===== LIMPIAR SALIDA PREVIA =====
ob_clean();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ===== CONFIGURAR COOKIES DE SESIÓN SEGURAS =====
$is_secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $is_secure,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once dirname(__DIR__) . '/conexion.php';
require_once 'cliente_identificador.php';

// ===== CONFIGURACIÓN DE SEGURIDAD =====
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

// ===== VERIFICAR SESIÓN =====
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

if (!$cliente_id) {
    ob_end_clean();
    echo json_encode(['success' => false, 'mensaje' => 'Sesión no válida. Inicia sesión nuevamente.']);
    exit;
}

// ===== RATE LIMITING (CORREGIDO) =====
function checkRateLimit($cliente_id, $accion) {
    // Usar carpeta includes en lugar de /tmp (InfinityFree)
    $archivo = $_SERVER['DOCUMENT_ROOT'] . '/includes/rate_limit_' . $cliente_id . '_' . md5($accion) . '.txt';
    $ahora = time();
    $limite = 10;
    $ventana = 300;
    
    $datos = [];
    if (file_exists($archivo)) {
        $contenido = file_get_contents($archivo);
        $datos = json_decode($contenido, true) ?: [];
    }
    
    $datos = array_filter($datos, function($t) use ($ahora, $ventana) {
        return ($ahora - $t) < $ventana;
    });
    
    if (count($datos) >= $limite) {
        return false;
    }
    
    $datos[] = $ahora;
    file_put_contents($archivo, json_encode($datos));
    return true;
}

// ===== GENERAR CSRF TOKEN SI NO EXISTE =====
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';

// ============================================
// 1. VERIFICAR CONTRASEÑA
// ============================================
if ($accion === 'verificar_password') {
    $password = $_POST['password'] ?? '';
    
    if (!checkRateLimit($cliente_id, 'verificar_password')) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Demasiados intentos. Espera 5 minutos.']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT password FROM clientes WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    ob_end_clean();
    if ($result && !empty($result['password']) && password_verify($password, $result['password'])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Contraseña incorrecta']);
    }
    exit;
}

// ============================================
// 2. OBTENER DATOS DEL CLIENTE
// ============================================
if ($accion === 'obtener_datos') {
    $stmt = $conn->prepare("SELECT nombre, email, movil FROM clientes WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    ob_end_clean();
    if ($result) {
        echo json_encode([
            'success' => true,
            'nombre' => htmlspecialchars($result['nombre'], ENT_QUOTES, 'UTF-8'),
            'email' => htmlspecialchars($result['email'], ENT_QUOTES, 'UTF-8'),
            'movil' => htmlspecialchars($result['movil'], ENT_QUOTES, 'UTF-8')
        ]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Cliente no encontrado']);
    }
    exit;
}

// ============================================
// 3. ACTUALIZAR DATOS DEL CLIENTE
// ============================================
if ($accion === 'actualizar_datos') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (empty($csrf_token) || $csrf_token !== $_SESSION['csrf_token']) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Token de seguridad inválido. Recarga la página.']);
        exit;
    }
    
    if (!checkRateLimit($cliente_id, 'actualizar_datos')) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Demasiados intentos. Espera 5 minutos.']);
        exit;
    }
    
    $nombre = trim($_POST['edit_nombre'] ?? '');
    $email = trim($_POST['edit_email'] ?? '');
    $movil = trim($_POST['edit_movil'] ?? '');
    $password_nueva = $_POST['edit_password_new'] ?? '';
    
    $errores = [];
    
    if (empty($nombre)) {
        $errores[] = "El nombre es requerido";
    } elseif (strlen($nombre) < 2 || strlen($nombre) > 100) {
        $errores[] = "El nombre debe tener entre 2 y 100 caracteres";
    } elseif (!preg_match('/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/', $nombre)) {
        $errores[] = "El nombre solo puede contener letras y espacios";
    }
    
    if (empty($email)) {
        $errores[] = "El email es requerido";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "Email no válido";
    } elseif (strlen($email) > 100) {
        $errores[] = "El email no puede tener más de 100 caracteres";
    }
    
    if (empty($movil)) {
        $errores[] = "El móvil es requerido";
    } elseif (!preg_match('/^[0-9+\-\s]{5,20}$/', $movil)) {
        $errores[] = "Número de móvil inválido (solo números, +, - y espacios)";
    }
    
    if (!empty($password_nueva)) {
        if (strlen($password_nueva) < 6) {
            $errores[] = "La contraseña debe tener al menos 6 caracteres";
        } elseif (strlen($password_nueva) > 100) {
            $errores[] = "La contraseña no puede tener más de 100 caracteres";
        } elseif (!preg_match('/[A-Z]/', $password_nueva)) {
            $errores[] = "La contraseña debe tener al menos una mayúscula";
        } elseif (!preg_match('/[0-9]/', $password_nueva)) {
            $errores[] = "La contraseña debe tener al menos un número";
        }
    }
    
    if (!empty($errores)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => implode('<br>', $errores)]);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT id FROM clientes WHERE email = ? AND id != ? AND activo = 1");
    $stmt->bind_param("si", $email, $cliente_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Este email ya está registrado por otro usuario']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT id FROM clientes WHERE movil = ? AND id != ? AND activo = 1");
    $stmt->bind_param("si", $movil, $cliente_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Este móvil ya está registrado por otro usuario']);
        exit;
    }
    
    $conn->begin_transaction();
    
    try {
        $sql = "UPDATE clientes SET nombre = ?, email = ?, movil = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $nombre, $email, $movil, $cliente_id);
        $stmt->execute();
        
        if (!empty($password_nueva)) {
            $password_hash = password_hash($password_nueva, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE clientes SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $password_hash, $cliente_id);
            $stmt->execute();
        }
        
        $conn->commit();
        
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        
        ob_end_clean();
        echo json_encode([
            'success' => true,
            'mensaje' => 'Datos actualizados correctamente',
            'csrf_token' => $_SESSION['csrf_token']
        ]);
        
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Error actualizando cliente: " . $e->getMessage());
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Error al actualizar los datos']);
    }
    exit;
}

// ============================================
// 4. RECUPERAR CONTRASEÑA
// ============================================
if ($accion === 'recuperar_password') {
    if (!checkRateLimit($cliente_id, 'recuperar_password')) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Demasiados intentos. Espera 5 minutos.']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente_data = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente_data) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Cliente no encontrado']);
        exit;
    }
    
    $caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    $nueva_password = '';
    for ($i = 0; $i < 12; $i++) {
        $nueva_password .= $caracteres[random_int(0, strlen($caracteres) - 1)];
    }
    
    $password_hash = password_hash($nueva_password, PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("UPDATE clientes SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $password_hash, $cliente_id);
    $stmt->execute();
    
    require_once 'email_config.php';
    $resultado = enviarEmailNuevaPassword($cliente_data['email'], $nueva_password);
    
    if (!$resultado['success']) {
        error_log("Error PHPMailer: " . $resultado['mensaje']);
    }
    
    ob_end_clean();
    echo json_encode($resultado);
    exit;
}

// ============================================
// 5. OBTENER EMAIL DEL CLIENTE
// ============================================
if ($accion === 'obtener_email') {
    $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    ob_end_clean();
    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            'success' => true,
            'email' => htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8')
        ]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Cliente no encontrado']);
    }
    exit;
}

// ============================================
// 6. CERRAR SESIÓN EN TODOS LOS DISPOSITIVOS
// ============================================
if ($accion === 'cerrar_todas_sesiones') {
    $password = $_POST['password'] ?? '';
    
    $stmt = $conn->prepare("SELECT password FROM clientes WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if (!$result || !password_verify($password, $result['password'])) {
        ob_end_clean();
        echo json_encode(['success' => false, 'mensaje' => 'Contraseña incorrecta']);
        exit;
    }
    
    session_regenerate_id(true);
    $_SESSION = array();
    session_destroy();
    
    ob_end_clean();
    echo json_encode(['success' => true, 'mensaje' => 'Todas las sesiones cerradas']);
    exit;
}

// ============================================
// 7. VERIFICAR SESIÓN ACTIVA
// ============================================
if ($accion === 'verificar_sesion') {
    ob_end_clean();
    echo json_encode([
        'success' => true,
        'cliente_id' => $cliente_id,
        'nombre' => htmlspecialchars($cliente['nombre'] ?? '', ENT_QUOTES, 'UTF-8')
    ]);
    exit;
}

// ============================================
// RESPUESTA POR DEFECTO
// ============================================
ob_end_clean();
echo json_encode(['success' => false, 'mensaje' => 'Acción no válida']);
?>
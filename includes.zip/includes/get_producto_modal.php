<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}
    
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();
require_once '../conexion.php';
require_once '../includes/proveedor_utils.php';
require_once 'moneda_funciones.php';

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion");
while ($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}

$id = intval($_GET['id'] ?? 0);
if ($id == 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}

$stmt = $conn->prepare("SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono 
                        FROM productos p 
                        LEFT JOIN categorias c ON p.categoria_id = c.id 
                        WHERE p.id = ? AND p.activo = 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$producto = $stmt->get_result()->fetch_assoc();

if (!$producto) {
    echo json_encode(['success' => false, 'error' => 'Producto no encontrado']);
    exit;
}

// ============================================
// VALIDAR PROPIEDAD DEL PRODUCTO (si es proveedor)
// ============================================
if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_usuario)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'No tienes permiso para ver este producto']);
    exit;
}

// ============================================
// DETERMINAR MONEDA (según proveedor del producto y cliente)
// ============================================
require_once 'cliente_identificador.php';
require_once 'carrito_funciones.php';

$cliente = obtenerClienteActual($conn);
$cliente_registrado = (!empty($cliente['id']) && $cliente['id'] > 0);

$proveedor_producto = $producto['proveedor_id'] ?? 0;

// Detectar carrito pendiente del cliente (si es del mismo proveedor)
$carrito_moneda = null;
if ($cliente_registrado) {
    $carrito_pendiente = iniciarCarrito($conn, $cliente['id']);
    if ($carrito_pendiente && !empty($carrito_pendiente['moneda']) 
        && $carrito_pendiente['proveedor_id'] == $proveedor_producto) {
        $carrito_moneda = $carrito_pendiente['moneda'];
    }
}

$moneda_actual = getMonedaParaProveedor($conn, $proveedor_producto, $cliente, $carrito_moneda);
$moneda_simbolo = getSimboloPorMoneda($moneda_actual);
$moneda_codigo = $moneda_actual;

// ============================================
// DETERMINAR SI TIENE OFERTA
// ============================================
$tiene_oferta = ($producto['porcentaje_rebaja'] > 0);

// ============================================
// CONVERTIR PRECIOS A LA MONEDA DEL CLIENTE
// ============================================
$precio_original_usd = $tiene_oferta ? $producto['precio_original'] : $producto['precio'];
$precio_final_usd = $producto['precio'];

if ($moneda_actual !== 'USD' && $proveedor_producto > 0) {
    $precio_original = convertirMoneda($precio_original_usd, 'USD', $moneda_actual, $conn, $proveedor_producto);
    $precio_final = convertirMoneda($precio_final_usd, 'USD', $moneda_actual, $conn, $proveedor_producto);
} else {
    $precio_original = $precio_original_usd;
    $precio_final = $precio_final_usd;
}

$dias_antiguedad = floor((time() - strtotime($producto['fecha_creacion'])) / 86400);
$es_nuevo = $dias_antiguedad < 7;

echo json_encode([
    'success' => true,
    'id' => $producto['id'],
    'nombre' => htmlspecialchars($producto['nombre']),
    'marca' => htmlspecialchars($producto['marca'] ?? ''),
    'categoria_nombre' => htmlspecialchars($producto['categoria_nombre'] ?? ''),
    'categoria_icono' => html_entity_decode(htmlspecialchars($producto['categoria_icono'] ?? '📦')),
    'descripcion' => nl2br(htmlspecialchars($producto['descripcion'] ?? '')),
    'imagen' => htmlspecialchars($producto['imagen_url'] ?? '/img/producto-default.png'),
    'tiene_oferta' => $tiene_oferta,
    'porcentaje_rebaja' => $producto['porcentaje_rebaja'],
    'precio_original' => number_format($precio_original, 2),
    'precio_final' => number_format($precio_final, 2),
    'precio_normal' => number_format($precio_final, 2),
    'precio_original_usd' => number_format($precio_original_usd, 2),
    'precio_final_usd' => number_format($precio_final_usd, 2),
    'moneda' => $moneda_simbolo,
    'moneda_codigo' => $moneda_codigo,
    'cantidad' => intval($producto['cantidad']),
    'es_nuevo' => $es_nuevo
]);
?>
<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once dirname(__DIR__) . '/conexion.php';
require_once 'cliente_identificador.php';
require_once 'carrito_funciones.php';

header('Content-Type: application/json');

// Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'];

$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';
$respuesta = ['success' => false];

// ============================================
// REGISTRAR CLIENTE (CON VERIFICACIÓN DE EXISTENCIA)
// ============================================
if ($accion === 'registrar_cliente') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $documento = trim($_POST['documento'] ?? '');
    $movil = trim($_POST['movil'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $errores = [];
    if (empty($nombre)) $errores[] = "Nombre requerido";
    if (empty($apellidos)) $errores[] = "Apellidos requeridos";
    if (empty($email)) $errores[] = "Email requerido";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = "Email no válido";
    if (empty($documento)) $errores[] = "Documento requerido";
    if (empty($movil)) $errores[] = "Móvil requerido";
    if (empty($password)) $errores[] = "Contraseña requerida";
    if (strlen($password) < 6) $errores[] = "La contraseña debe tener al menos 6 caracteres";
    
    if (!empty($errores)) {
        echo json_encode(['success' => false, 'mensaje' => implode('<br>', $errores)]);
        exit;
    }
    
    // ===== VERIFICAR SI EL CLIENTE YA EXISTE (priorizando DOCUMENTO) =====
    $cliente_existente = verificarClienteExistente($conn, $documento, $movil, $email);
    
    if ($cliente_existente) {
        // Determinar por qué campo se encontró
        $campo_coincidencia = '';
        $valor_coincidencia = '';
        
        if ($cliente_existente['documento'] == $documento) {
            $campo_coincidencia = 'documento';
            $valor_coincidencia = $documento;
        } elseif ($cliente_existente['movil'] == $movil) {
            $campo_coincidencia = 'móvil';
            $valor_coincidencia = $movil;
        } elseif (!empty($email) && $cliente_existente['email'] == $email) {
            $campo_coincidencia = 'email';
            $valor_coincidencia = $email;
        }
        
        // Guardar datos nuevos en sesión temporal para usarlos después
        $_SESSION['datos_pendientes'] = [
            'nombre' => $nombre,
            'apellidos' => $apellidos,
            'email' => $email,
            'documento' => $documento,
            'movil' => $movil,
            'password' => $password
        ];
        $_SESSION['cliente_existente_id'] = $cliente_existente['id'];
        
        echo json_encode([
            'success' => false,
            'requiere_password' => true,
            'coincidencia' => $campo_coincidencia,
            'valor_coincidencia' => $valor_coincidencia,
            'mensaje' => "El $campo_coincidencia '$valor_coincidencia' se encuentra registrado desde otro dispositivo. Introduzca la contraseña correcta, inicie desde su dispositivo registrado o póngase en contacto con los administradores."
        ]);
        exit;
        
   } else {
    // Cliente nuevo
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $uuid_actual = $_COOKIE['cliente_uuid'] ?? session_id();
    
    // Insertar cliente directamente (sin usar actualizarDatosCliente)
    $sql = "INSERT INTO clientes 
            (uuid, nombre, apellidos, email, documento, movil, password, fecha_registro) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", 
        $uuid_actual, 
        $nombre, 
        $apellidos, 
        $email, 
        $documento, 
        $movil, 
        $password_hash
    );
    
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'mensaje' => 'Error al crear el cliente: ' . $conn->error]);
        exit;
    }
    
    $nuevo_cliente_id = $conn->insert_id;
    
    // Generar token de verificación
    $token = bin2hex(random_bytes(32));
    $expira = date('Y-m-d H:i:s', strtotime('+48 hours'));
    
    $stmt = $conn->prepare("UPDATE clientes SET 
                            email_verified = 0,
                            verification_token = ?, 
                            token_expires = ?,
                            verification_sent_at = NOW() 
                            WHERE id = ?");
    $stmt->bind_param("ssi", $token, $expira, $nuevo_cliente_id);
    $stmt->execute();
    
    // ===== ACTUALIZAR SESIÓN CON EL NUEVO ID =====
    $_SESSION['cliente_id'] = $nuevo_cliente_id;
    $cliente_id = $nuevo_cliente_id;
    
    // ============================================
    // ENVIAR CORREO DE VERIFICACIÓN
    // ============================================
    require_once dirname(__DIR__) . '/includes/email_config.php';
    require_once dirname(__DIR__) . '/includes/email_templates.php';
    
    // Obtener configuración para el nombre del sitio
    $config_sitio = [];
    $result_config = $conn->query("SELECT clave, valor FROM configuracion WHERE clave IN ('sitio_nombre', 'sitio_email')");
    while($row = $result_config->fetch_assoc()) {
        $config_sitio[$row['clave']] = $row['valor'];
    }
    $GLOBALS['config'] = $config_sitio;
    
    $datos_cliente = ['nombre' => $nombre];
    $asunto = "Verifica tu email - " . ($config_sitio['sitio_nombre'] ?? 'Mi Tienda');
    $cuerpo = plantilla_verificacion(['nombre' => $nombre], $token);
    
    // Usar la función base de email_config.php
    if (function_exists('enviarCorreoBase')) {
        enviarCorreoBase($email, $asunto, $cuerpo);
    }
    
    // Asignar UUID adicional si es necesario (uuid2, uuid3)
    require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
    $asignado = asignarUUIDaCliente($conn, $nuevo_cliente_id);

    echo json_encode([
        'success' => true, 
        'mensaje' => 'Registro exitoso',
        'requiere_verificacion' => true,
        'uuid_asignado' => $asignado,
        'cliente_id' => $nuevo_cliente_id
    ]);
    exit;
}
}

// ============================================
// VERIFICAR CONTRASEÑA Y VINCULAR DISPOSITIVO
// ============================================
if ($accion === 'verificar_password_vinculacion') {
    $password = $_POST['password'] ?? '';
    $cliente_existente_id = $_SESSION['cliente_existente_id'] ?? 0;
    $datos_pendientes = $_SESSION['datos_pendientes'] ?? null;
    
    if (!$cliente_existente_id || !$datos_pendientes) {
        echo json_encode(['success' => false, 'mensaje' => 'Datos no válidos. Intente nuevamente.']);
        exit;
    }
    
    // Obtener datos del cliente existente
    $stmt = $conn->prepare("SELECT * FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_existente_id);
    $stmt->execute();
    $cliente_existente = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente_existente) {
        echo json_encode(['success' => false, 'mensaje' => 'Cliente no encontrado']);
        exit;
    }
    
    // Verificar contraseña
    if (!password_verify($password, $cliente_existente['password'])) {
        echo json_encode(['success' => false, 'mensaje' => 'Contraseña incorrecta']);
        exit;
    }
    
    // ===== REGISTRAR CAMBIOS EN HISTORIAL =====
    $campos_a_verificar = ['nombre', 'apellidos', 'email', 'documento', 'movil'];
    foreach ($campos_a_verificar as $campo) {
        if ($cliente_existente[$campo] != $datos_pendientes[$campo]) {
            registrarCambioCliente($conn, $cliente_existente_id, $campo, 
                                  $cliente_existente[$campo], $datos_pendientes[$campo]);
        }
    }
    
    // ===== ACTUALIZAR DATOS DEL CLIENTE EXISTENTE =====
    $password_hash = password_hash($datos_pendientes['password'], PASSWORD_DEFAULT);
    actualizarDatosCliente($conn, $cliente_existente_id, 
                          $datos_pendientes['nombre'], $datos_pendientes['apellidos'],
                          $datos_pendientes['email'], $datos_pendientes['documento'],
                          $datos_pendientes['movil'], $password_hash);
    
    // ===== TRANSFERIR CARRITOS =====
    $stmt = $conn->prepare("UPDATE carritos SET cliente_id = ? WHERE cliente_id = ?");
    $stmt->bind_param("ii", $cliente_existente_id, $cliente_id);
    $stmt->execute();
    
    // ===== ACTUALIZAR UUID DEL CLIENTE EXISTENTE (buscar espacio libre) =====
    $uuid_actual = $_COOKIE['cliente_uuid'] ?? session_id();
    
    // Verificar si este UUID ya está registrado para este cliente
    if ($cliente_existente['uuid'] == $uuid_actual || 
        $cliente_existente['uuid2'] == $uuid_actual || 
        $cliente_existente['uuid3'] == $uuid_actual) {
        // El UUID ya está registrado, no hacer nada
    } else {
        // Buscar un espacio libre (uuid2 o uuid3)
        if (empty($cliente_existente['uuid2'])) {
            // Guardar en uuid2
            $stmt = $conn->prepare("UPDATE clientes SET uuid2 = ? WHERE id = ?");
            $stmt->bind_param("si", $uuid_actual, $cliente_existente_id);
            $stmt->execute();
        } elseif (empty($cliente_existente['uuid3'])) {
            // Guardar en uuid3
            $stmt = $conn->prepare("UPDATE clientes SET uuid3 = ? WHERE id = ?");
            $stmt->bind_param("si", $uuid_actual, $cliente_existente_id);
            $stmt->execute();
        } else {
            // Los 3 espacios están ocupados - opcional: reemplazar el más antiguo
            // Por ahora, no hacemos nada (el cliente no puede vincular más dispositivos)
            // Podrías mostrar un mensaje al usuario
        }
    }
    
    // ===== ELIMINAR CLIENTE TEMPORAL =====
    if ($cliente_existente_id != $cliente_id) {
        $stmt = $conn->prepare("DELETE FROM clientes WHERE id = ?");
        $stmt->bind_param("i", $cliente_id);
        $stmt->execute();
    }
    
    // ===== ACTUALIZAR SESIÓN =====
    $_SESSION['cliente_id'] = $cliente_existente_id;
    
    // ===== LIMPIAR SESIÓN TEMPORAL =====
    unset($_SESSION['cliente_existente_id']);
    unset($_SESSION['datos_pendientes']);
    
    echo json_encode([
        'success' => true,
        'mensaje' => 'Dispositivo vinculado correctamente. ¡Bienvenido!'
    ]);
    exit;
}

// ============================================
// REENVIAR VERIFICACIÓN
// ============================================
if ($accion === 'reenviar_verificacion') {
    // Verificar último envío (anti-spam)
    $stmt = $conn->prepare("SELECT email, nombre, verification_sent_at FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente) {
        echo json_encode(['success' => false, 'mensaje' => 'Cliente no encontrado']);
        exit;
    }
    
    // Control de spam: mínimo 5 minutos entre reenvíos
    if ($cliente['verification_sent_at'] && 
        strtotime($cliente['verification_sent_at']) > strtotime('-5 minutes')) {
        echo json_encode([
            'success' => false, 
            'mensaje' => 'Espera 5 minutos antes de reenviar'
        ]);
        exit;
    }
    
    // Generar nuevo token
    $token = bin2hex(random_bytes(32));
    $expira = date('Y-m-d H:i:s', strtotime('+48 hours'));
    
    $stmt = $conn->prepare("UPDATE clientes SET 
                            verification_token = ?, 
                            token_expires = ?,
                            verification_sent_at = NOW() 
                            WHERE id = ?");
    $stmt->bind_param("ssi", $token, $expira, $cliente_id);
    $stmt->execute();
    
    // ============================================
    // REENVIAR CORREO DE VERIFICACIÓN
    // ============================================
    require_once dirname(__DIR__) . '/includes/email_config.php';
    require_once dirname(__DIR__) . '/includes/email_templates.php';
    
    $config_sitio = [];
    $result_config = $conn->query("SELECT clave, valor FROM configuracion WHERE clave IN ('sitio_nombre', 'sitio_email')");
    while($row = $result_config->fetch_assoc()) {
        $config_sitio[$row['clave']] = $row['valor'];
    }
    $GLOBALS['config'] = $config_sitio;
    
    $asunto = "Verifica tu email - " . ($config_sitio['sitio_nombre'] ?? 'Mi Tienda');
    $cuerpo = plantilla_verificacion(['nombre' => $cliente['nombre']], $token);
    
    if (function_exists('enviarCorreoBase')) {
        enviarCorreoBase($cliente['email'], $asunto, $cuerpo);
    }
    
    echo json_encode([
        'success' => true,
        'mensaje' => 'Hemos enviado un nuevo enlace a tu email'
    ]);
    exit;
}

// ============================================
// VERIFICAR CARRITO PENDIENTE
// ============================================
if ($accion === 'verificar_carrito_pendiente') {
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => true, 'tiene_carrito' => false]);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT cp.*, p.nombre, p.imagen_url 
                            FROM carrito_productos cp 
                            JOIN productos p ON cp.producto_id = p.id 
                            WHERE cp.carrito_id = ?");
    $stmt->bind_param("i", $carrito['id']);
    $stmt->execute();
    $productos = $stmt->get_result();
    
    $items = [];
    $total = 0;
    while ($item = $productos->fetch_assoc()) {
        $subtotal = $item['cantidad'] * $item['precio_unitario'];
        $total += $subtotal;
        $items[] = [
            'producto_id' => $item['producto_id'],
            'nombre' => $item['nombre'],
            'imagen' => $item['imagen_url'],
            'cantidad' => $item['cantidad'],
            'precio' => $item['precio_unitario'],
            'subtotal' => $subtotal
        ];
    }
    
    $expiracion = strtotime($carrito['fecha_expiracion']);
    $horas_restantes = round(($expiracion - time()) / 3600, 1);
    
    echo json_encode([
        'success' => true,
        'tiene_carrito' => true,
        'carrito_id' => $carrito['id'],
        'items' => $items,
        'total' => $total,
        'horas_restantes' => $horas_restantes
    ]);
    exit;
}

// ============================================
// CONTINUAR COMPRA (RENOVAR)
// ============================================
if ($accion === 'continuar_compra') {
    $carrito_id = intval($_POST['carrito_id'] ?? 0);
    
    if ($carrito_id) {
        $horas = getTiempoExpiracion($conn);
        $nueva_expiracion = date('Y-m-d H:i:s', strtotime("+$horas hours"));
        
        $stmt = $conn->prepare("UPDATE carritos SET fecha_expiracion = ? WHERE id = ? AND cliente_id = ?");
        $stmt->bind_param("sii", $nueva_expiracion, $carrito_id, $cliente_id);
        $stmt->execute();
        
        echo json_encode(['success' => true, 'mensaje' => 'Carrito renovado']);
        exit;
    }
    echo json_encode(['success' => false, 'mensaje' => 'Error al renovar']);
    exit;
}

// ============================================
// NUEVA COMPRA (CANCELA ANTERIOR)
// ============================================
if ($accion === 'nueva_compra') {
    $carrito_anterior = iniciarCarrito($conn, $cliente_id);
    if ($carrito_anterior) {
        cancelarCarrito($conn, $carrito_anterior['id'], 'cancelado_cliente');
    }
    
    // No crear nuevo carrito
    echo json_encode([
        'success' => true,
        'mensaje' => 'Carrito cancelado. Puedes empezar una nueva compra.'
    ]);
    exit;
}

// ============================================
// AGREGAR PRODUCTO
// ============================================
if ($accion === 'agregar') {
    $producto_id = intval($_POST['producto_id'] ?? 0);
    $cantidad = intval($_POST['cantidad'] ?? 1);
    
    if ($producto_id <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto inválido']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT cantidad, precio FROM productos WHERE id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();
    
    if (!$producto) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto no encontrado']);
        exit;
    }
    
    if ($producto['cantidad'] < $cantidad) {
    echo json_encode([
        'success' => false, 
        'mensaje' => "Stock insuficiente. Solo hay {$producto['cantidad']} unidades."
    ]);
    exit;
}
    
    $carrito = obtenerOCrearCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode([
            'success' => false, 
            'requiere_registro' => true,
            'mensaje' => 'Debes registrarte para agregar productos'
        ]);
        exit;
    }
    
    $carrito_id = is_array($carrito) ? $carrito['id'] : $carrito;

$nuevo_stock = $producto['cantidad'] - $cantidad;
$stmt = $conn->prepare("UPDATE productos SET cantidad = ? WHERE id = ?");
$stmt->bind_param("ii", $nuevo_stock, $producto_id);
$stmt->execute();

// Si el stock llegó a 0, guardar fecha_agotado
if ($nuevo_stock == 0) {
    $conn->query("UPDATE productos SET fecha_agotado = NOW() WHERE id = $producto_id");
    
        // Desactivar si ya llevaba más de 48 horas agotado
    $conn->query("UPDATE productos SET activo = 0 
                  WHERE id = $producto_id 
                    AND fecha_agotado IS NOT NULL 
                    AND TIMESTAMPDIFF(HOUR, fecha_agotado, NOW()) > 48");

}

$stmt = $conn->prepare("SELECT id, cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
$stmt->bind_param("ii", $carrito_id, $producto_id);
$stmt->execute();
$existente = $stmt->get_result()->fetch_assoc();
    
    if ($existente) {
        $nueva_cantidad = $existente['cantidad'] + $cantidad;
        $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE id = ?");
        $stmt->bind_param("ii", $nueva_cantidad, $existente['id']);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("INSERT INTO carrito_productos (carrito_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiid", $carrito_id, $producto_id, $cantidad, $producto['precio']);
        $stmt->execute();
    }
    
    echo json_encode(['success' => true, 'mensaje' => 'Producto agregado']);
    exit;
}

// ============================================
// OBTENER CARRITO
// ============================================
if ($accion === 'obtener_carrito') {
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => true, 'vacio' => true]);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT cp.*, p.nombre, p.imagen_url 
                            FROM carrito_productos cp 
                            JOIN productos p ON cp.producto_id = p.id 
                            WHERE cp.carrito_id = ?");
    $stmt->bind_param("i", $carrito['id']);
    $stmt->execute();
    $productos = $stmt->get_result();
    
    $items = [];
    $total = 0;
    while ($item = $productos->fetch_assoc()) {
        $subtotal = $item['cantidad'] * $item['precio_unitario'];
        $total += $subtotal;
        $items[] = [
            'producto_id' => $item['producto_id'],
            'nombre' => $item['nombre'],
            'imagen' => $item['imagen_url'],
            'cantidad' => $item['cantidad'],
            'precio' => $item['precio_unitario'],
            'subtotal' => $subtotal
        ];
    }
    
    $expiracion = strtotime($carrito['fecha_expiracion']);
    $horas_restantes = round(($expiracion - time()) / 3600, 1);
    
    echo json_encode([
        'success' => true,
        'vacio' => false,
        'items' => $items,
        'total' => $total,
        'horas_restantes' => $horas_restantes
    ]);
    exit;
}

// ============================================
// ACTUALIZAR CANTIDAD
// ============================================
if ($accion === 'actualizar_cantidad') {
    $producto_id = intval($_POST['producto_id'] ?? 0);
    $nueva_cantidad = intval($_POST['cantidad'] ?? 0);
    
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => false, 'mensaje' => 'No hay carrito']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
    $stmt->bind_param("ii", $carrito['id'], $producto_id);
    $stmt->execute();
    $actual = $stmt->get_result()->fetch_assoc();
    
    if (!$actual) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto no encontrado']);
        exit;
    }
    
    $diferencia = $nueva_cantidad - $actual['cantidad'];
    
    if ($diferencia > 0) {
        $stmt = $conn->prepare("SELECT cantidad FROM productos WHERE id = ?");
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stock = $stmt->get_result()->fetch_assoc();
        
        if ($stock['cantidad'] < $diferencia) {
    echo json_encode([
        'success' => false, 
        'mensaje' => "Stock insuficiente. Solo hay {$stock['cantidad']} unidades."
    ]);
    exit;
}
        
        $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad - ? WHERE id = ?");
        $stmt->bind_param("ii", $diferencia, $producto_id);
        $stmt->execute();
        
        $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE carrito_id = ? AND producto_id = ?");
        $stmt->bind_param("iii", $nueva_cantidad, $carrito['id'], $producto_id);
        $stmt->execute();
        
    } elseif ($diferencia < 0) {
        $diferencia_abs = abs($diferencia);
        
        $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
        $stmt->bind_param("ii", $diferencia_abs, $producto_id);
        $stmt->execute();
        
        if ($nueva_cantidad == 0) {
            $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
            $stmt->bind_param("ii", $carrito['id'], $producto_id);
            $stmt->execute();
        } else {
            $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE carrito_id = ? AND producto_id = ?");
            $stmt->bind_param("iii", $nueva_cantidad, $carrito['id'], $producto_id);
            $stmt->execute();
        }
    }
    
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// ELIMINAR PRODUCTO
// ============================================
if ($accion === 'eliminar') {
    $producto_id = intval($_POST['producto_id'] ?? 0);
    
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => false, 'mensaje' => 'No hay carrito']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
    $stmt->bind_param("ii", $carrito['id'], $producto_id);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    
    if ($item) {
        $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
        $stmt->bind_param("ii", $item['cantidad'], $producto_id);
        $stmt->execute();
        
        // AGREGAR ESTO (para limpiar fecha_agotado si ahora tiene stock)
$check = $conn->query("SELECT cantidad FROM productos WHERE id = $producto_id");
$stock_actual = $check->fetch_assoc()['cantidad'];
if ($stock_actual > 0) {
    $conn->query("UPDATE productos SET fecha_agotado = NULL WHERE id = $producto_id");
}
        
        $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
        $stmt->bind_param("ii", $carrito['id'], $producto_id);
        $stmt->execute();
    }
    
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// COMPRAR (verifica contraseña y muestra modal de datos de entrega)
// ============================================
if ($accion === 'comprar') {
    // Verificar si viene con contraseña
    $password = $_POST['password'] ?? '';
    
    if (empty($password)) {
        echo json_encode([
            'success' => false,
            'requiere_password' => true,
            'mensaje' => 'Ingresa tu contraseña para continuar'
        ]);
        exit;
    }
    
    // Verificar contraseña
    $stmt = $conn->prepare("SELECT password FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente_data = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente_data || !password_verify($password, $cliente_data['password'])) {
        echo json_encode([
            'success' => false,
            'password_incorrecta' => true,
            'mensaje' => 'Contraseña incorrecta'
        ]);
        exit;
    }
    
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => false, 'mensaje' => 'No hay carrito activo']);
        exit;
    }
    
    // Verificar que el carrito no esté vacío
    $check = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos WHERE carrito_id = ?");
    $check->bind_param("i", $carrito['id']);
    $check->execute();
    $total_productos = $check->get_result()->fetch_assoc()['total'];
    
    if ($total_productos == 0) {
        echo json_encode(['success' => false, 'mensaje' => 'El carrito está vacío']);
        exit;
    }
    
    // Obtener el subtotal del carrito para pasarlo al modal
    $stmt_subtotal = $conn->prepare("SELECT SUM(cantidad * precio_unitario) as total FROM carrito_productos WHERE carrito_id = ?");
    $stmt_subtotal->bind_param("i", $carrito['id']);
    $stmt_subtotal->execute();
    $subtotal_result = $stmt_subtotal->get_result()->fetch_assoc();
    $subtotal = $subtotal_result['total'] ?? 0;
    
    // Contraseña correcta - Devolver datos para abrir modal de datos de entrega
    echo json_encode([
    'success' => true,
    'mostrar_modal_entrega' => true,
    'subtotal' => (float)$subtotal,
    'mensaje' => 'Completa tus datos de entrega'
]);
    exit;
}

// ============================================
// VACIAR CARRITO
// ============================================
if ($accion === 'vaciar') {
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if ($carrito) {
        cancelarCarrito($conn, $carrito['id'], 'cancelado_cliente');
    }
    
    echo json_encode(['success' => true, 'mensaje' => 'Carrito cancelado']);
    exit;
}

// ============================================
// SINCRONIZAR POR EMAIL
// ============================================
if ($accion === 'sincronizar') {
    $email = trim($_POST['email'] ?? '');
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'mensaje' => 'Email no válido']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT id FROM clientes WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $cliente_email = $result->fetch_assoc();
        
        $stmt = $conn->prepare("UPDATE carritos SET cliente_id = ? WHERE cliente_id = ?");
        $stmt->bind_param("ii", $cliente_id, $cliente_email['id']);
        $stmt->execute();
        $afectados = $conn->affected_rows;
        
        echo json_encode([
            'success' => true,
            'mensaje' => 'Carrito sincronizado',
            'tiene_carrito' => $afectados > 0
        ]);
        exit;
    } else {
        $stmt = $conn->prepare("UPDATE clientes SET email = ? WHERE id = ?");
        $stmt->bind_param("si", $email, $cliente_id);
        $stmt->execute();
        
        echo json_encode([
            'success' => true,
            'mensaje' => 'Email guardado',
            'tiene_carrito' => false
        ]);
        exit;
    }
}

// ============================================
// ACCIÓN NO VÁLIDA
// ============================================
echo json_encode(['success' => false, 'mensaje' => 'Acción no válida']);
exit;
?>
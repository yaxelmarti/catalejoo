// ============================================
// VARIABLES GLOBALES
// ============================================
window.carritoPendienteId = null;
window.productoPendiente = null;
window.busquedaActiva = '';
window.scrollInfinitoHabilitado = true;
window.totalCargado = 0;
window.limiteScroll = 30;
window.scrollActivo = true;
window.cargaPendiente = false;
window.limiteScrollPC = 48;
window.modalComboAbierto = false;
window.pasoAtras = 0;
window.modalCerradoConAtras = false;

// ============================================
// FUNCIONES DEL CARRITO
// ============================================
function cambiarCantidad(btn, delta) {
    const selector = btn.closest('.cantidad-selector');
    const input = selector.querySelector('.cantidad-input');
    let valor = parseInt(input.value) || 1;
    valor = Math.max(1, Math.min(99, valor + delta));
    input.value = valor;
}

function agregarAlCarrito(productoId, btn) {
    const card = btn.closest('.producto-card, .producto-card-dashboard, .producto-card-carrusel');
    if (!card) return;
    const selector = card.querySelector('.cantidad-selector');
    if (!selector) return;
    const cantidad = parseInt(selector.querySelector('.cantidad-input').value) || 1;
    
    if (!window.clienteRegistrado) {
        document.getElementById('modalRegistro').style.display = 'block';
        window.productoPendiente = { id: productoId, cantidad: cantidad };
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=agregar&producto_id=' + productoId + '&cantidad=' + cantidad
    })
    .then(response => response.json())
    .then(data => {
    if (data.success) {
        mostrarNotificacion('✅ Producto agregado', 'exito');
        actualizarContadorCarrito();
    } else if (data.requiere_registro) {
        document.getElementById('modalRegistro').style.display = 'block';
        window.productoPendiente = { id: productoId, cantidad: cantidad };
    } else if (data.error === 'cambio_tienda') {
        // 🔥 CONFLICTO DE TIENDAS
        const tiendaActual = data.proveedor_actual_nombre || 'otra tienda';
        if (confirm(`⚠️ Ya tienes productos de "${tiendaActual}" en tu carrito. Para agregar este producto, debes vaciar tu carrito actual. ¿Deseas continuar?`)) {
            // Vaciar carrito y volver a intentar
            fetch('includes/carrito_ajax.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'accion=vaciar'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Reintentar agregar el producto
                    agregarAlCarrito(productoId, btn);
                } else {
                    mostrarNotificacion('❌ Error al vaciar el carrito', 'error');
                }
            });
        } else {
            mostrarNotificacion('ℹ️ Operación cancelada', 'info');
        }
    } else {
        mostrarNotificacion('❌ ' + data.mensaje, 'error');
    }
})
    .catch(error => {
        console.error('Error en fetch:', error);
        mostrarNotificacion('❌ Error al conectar con el servidor', 'error');
    });
}

function actualizarContadorCarrito() {
    fetch('includes/carrito_ajax.php?accion=obtener_carrito')
    .then(response => response.json())
    .then(data => {
        const contadorHeader = document.getElementById('carritoContadorHeader');
        if (data.success && !data.vacio) {
            const totalItems = data.items.reduce((sum, item) => sum + item.cantidad, 0);
            if (contadorHeader) {
                contadorHeader.textContent = totalItems;
                contadorHeader.style.display = 'flex';
            }
        } else {
            if (contadorHeader) contadorHeader.style.display = 'none';
        }
        
        const sideContador = document.getElementById('sideMenuCarritoContador');
        if (sideContador && data.success && !data.vacio) {
            const totalItems = data.items.reduce((sum, item) => sum + item.cantidad, 0);
            sideContador.textContent = totalItems;
            sideContador.style.display = 'inline-flex';
        } else if (sideContador) {
            sideContador.style.display = 'none';
        }
    });
}

function abrirCarrito() {
    const modal = document.getElementById('modalCarrito');
    if (modal) {
        modal.style.display = 'block';
        if (typeof actualizarContadorCarrito === 'function') {
            actualizarContadorCarrito();
        }
    }
}

function verificarCarritoPendiente() {
    // Si ya se mostró en esta sesión, no hacer nada
    if (sessionStorage.getItem('carrito_pendiente_mostrado') === 'true') {
        console.log('Carrito pendiente ya mostrado en esta sesión');
        return;
    }
    
    // Si el usuario pide no mostrar (desde algún enlace)
    if (sessionStorage.getItem('no_mostrar_carrito_pendiente') === 'true') {
        sessionStorage.removeItem('no_mostrar_carrito_pendiente');
        return;
    }
    
    fetch('includes/carrito_ajax.php?accion=verificar_carrito_pendiente')
    .then(response => response.json())
    .then(data => {
        if (data.success && data.tiene_carrito) {
            mostrarModalCarritoPendiente(data);
            // Marcar que ya se mostró en esta sesión
            sessionStorage.setItem('carrito_pendiente_mostrado', 'true');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function mostrarModalCarritoPendiente(data) {
    const info = document.getElementById('infoCarritoPendiente');
    if (!info) return;
    
    const totalItems = data.items.reduce((sum, item) => sum + item.cantidad, 0);
    const moneda = window.monedaSimbolo || '$';
    
    info.innerHTML = `
        <p class="cantidad">📦 ${totalItems} producto${totalItems !== 1 ? 's' : ''}</p>
        <p class="total">💰 ${moneda}${data.total.toFixed(2)}</p>
        <p class="tiempo">⏰ Expira en: ${data.horas_restantes} horas</p>
    `;
    
    window.carritoPendienteId = data.carrito_id;
    document.getElementById('modalCarritoPendiente').style.display = 'block';
}

function agregarComboAlCarrito(comboId, btn) {
    const card = btn.closest('.combo-card-dashboard, .combo-card-carrusel, .producto-card');
    if (!card) return;
    const selector = card.querySelector('.cantidad-selector');
    if (!selector) return;
    const cantidad = parseInt(selector.querySelector('.cantidad-input').value) || 1;
    
    if (!window.clienteRegistrado) {
        document.getElementById('modalRegistro').style.display = 'block';
        window.productoPendiente = { combo: true, id: comboId, cantidad: cantidad };
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=agregar_combo&combo_id=' + comboId + '&cantidad=' + cantidad
    })
    .then(response => response.json())
    .then(data => {
    if (data.success) {
        mostrarNotificacion('✅ Combo agregado', 'exito');
        actualizarContadorCarrito();
    } else if (data.error === 'cambio_tienda') {
        // 🔥 CONFLICTO DE TIENDAS
        const tiendaActual = data.proveedor_actual_nombre || 'otra tienda';
        if (confirm(`⚠️ Ya tienes productos de "${tiendaActual}" en tu carrito. Para agregar este combo, debes vaciar tu carrito actual. ¿Deseas continuar?`)) {
            // Vaciar carrito y volver a intentar
            fetch('includes/carrito_ajax.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'accion=vaciar'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Reintentar agregar el combo
                    agregarComboAlCarrito(comboId, btn);
                } else {
                    mostrarNotificacion('❌ Error al vaciar el carrito', 'error');
                }
            });
        } else {
            mostrarNotificacion('ℹ️ Operación cancelada', 'info');
        }
    } else {
        mostrarNotificacion('❌ ' + data.mensaje, 'error');
    }
})

function cambiarCantidadCombo(btn, delta) {
    const selector = btn.closest('.cantidad-selector');
    const input = selector.querySelector('.cantidad-input');
    let valor = parseInt(input.value) || 1;
    valor = Math.max(1, Math.min(99, valor + delta));
    input.value = valor;
}

// ============================================
// FUNCIONES DE CLIENTE
// ============================================
function abrirRegistro() {
    document.getElementById('modalRegistro').style.display = 'block';
}

function abrirPanelCliente() {
    cerrarSideMenu();
    document.getElementById('modalPasswordCliente').style.display = 'block';
}

function cerrarSesion() {
    if (confirm('¿Cerrar sesión?')) {
        window.location.href = 'logout.php';
    }
}

function reenviarVerificacionDesdeCliente() {
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=reenviar_verificacion'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacion('✅ Nuevo enlace enviado a tu email', 'exito');
        } else {
            mostrarNotificacion('❌ ' + data.mensaje, 'error');
        }
    });
}

function actualizarMenuCliente(nombre, email) {
    const bottomNombre = document.querySelector('#clienteBottomMenu .cliente-bottom-nombre');
    const bottomEmail = document.querySelector('#clienteBottomMenu .cliente-bottom-email');
    
    if (bottomNombre) bottomNombre.textContent = nombre;
    if (bottomEmail) bottomEmail.textContent = email;
    
    const sideNombre = document.querySelector('#sideMenu .side-menu-nombre');
    const sideEmail = document.querySelector('#sideMenu .side-menu-email');
    
    if (sideNombre) sideNombre.textContent = nombre;
    if (sideEmail) sideEmail.textContent = email;
    
    const bottomItems = document.querySelector('#clienteBottomMenu .cliente-bottom-items');
    if (bottomItems) {
        bottomItems.innerHTML = `
            <li><div class="menu-item" onclick="cerrarClienteBottomMenu(); abrirPanelCliente();">👤 Mi Perfil</div></li>
            <li><div class="menu-item" onclick="cerrarClienteBottomMenu(); abrirCarrito();">🛒 Mi Carrito</div></li>
            <li><a href="/mis_pedidos.php" class="menu-item" onclick="cerrarClienteBottomMenu()">📋 Mis Compras</a></li>
            <li><a href="/ayuda.php" class="menu-item" onclick="cerrarClienteBottomMenu()">❓ Ayuda</a></li>
        `;
    }
    
    const sideFooter = document.querySelector('#sideMenu .side-menu-footer');
    if (sideFooter) {
        sideFooter.innerHTML = '<a href="#" onclick="cerrarSesion()">Cerrar sesión</a>';
    }
    
    mostrarNotificacion('👋 ¡Bienvenido ' + nombre + '!', 'exito');
}

// ============================================
// FUNCIONES DE MENÚS DEL HEADER
// ============================================
function toggleSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('menuOverlay');
    
    if (!menu) return;
    
    if (menu.classList.contains('show')) {
        menu.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
    } else {
        menu.classList.add('show');
        if (overlay) overlay.classList.add('show');
        if (typeof actualizarContadorCarrito === 'function') {
            actualizarContadorCarrito();
        }
    }
}

function cerrarSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('menuOverlay');
    if (menu) menu.classList.remove('show');
    if (overlay) overlay.classList.remove('show');
}

function toggleClienteBottomMenu() {
    const menu = document.getElementById('clienteBottomMenu');
    const overlay = document.getElementById('bottomOverlay');
    
    if (!menu) return;
    
    if (menu.classList.contains('show')) {
        menu.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
    } else {
        menu.classList.add('show');
        if (overlay) overlay.classList.add('show');
    }
}

function cerrarClienteBottomMenu() {
    const menu = document.getElementById('clienteBottomMenu');
    const overlay = document.getElementById('bottomOverlay');
    if (menu) menu.classList.remove('show');
    if (overlay) overlay.classList.remove('show');
}

function toggleCategoriasRightMenu() {
    const menu = document.getElementById('categoriasRightMenu');
    const overlay = document.getElementById('rightOverlay');
    
    if (!menu) return;
    
    if (menu.classList.contains('show')) {
        menu.classList.remove('show');
        if (overlay) overlay.classList.remove('show');
    } else {
        menu.classList.add('show');
        if (overlay) overlay.classList.add('show');
    }
}

function cerrarCategoriasRightMenu() {
    const menu = document.getElementById('categoriasRightMenu');
    const overlay = document.getElementById('rightOverlay');
    if (menu) menu.classList.remove('show');
    if (overlay) overlay.classList.remove('show');
}

// ============================================
// FUNCIONES DE MODALES
// ============================================
function cerrarModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = 'none';
}

function mostrarNotificacion(mensaje, tipo = 'exito') {
    const notif = document.createElement('div');
    notif.className = 'notificacion ' + (tipo === 'error' ? 'error' : tipo === 'warning' ? 'warning' : '');
    notif.textContent = mensaje;
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 3000);
}

// Cerrar modales al hacer clic en overlay
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal-overlay')) {
        event.target.style.display = 'none';
    }
});

// ============================================
// FUNCIONES DE FILTROS Y NAVEGACIÓN
// ============================================
function toggleCarrusel(ocultar) {
    const carrusel = document.getElementById('carruselContainer');
    if (carrusel) {
        carrusel.style.display = ocultar ? 'none' : 'block';
    }
}

function filtrarCategoria(categoriaId) {
    // Si no estamos en index.php, redirigir
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        window.location.href = '/index.php?categoria=' + categoriaId;
        return;
    }
    
    // Si estamos en index.php, ejecutar el filtro
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'none';
    
    window.totalCargado = 0;
    window.limiteScroll = 30;
    window.limiteScrollPC = 48;
    window.scrollActivo = true;
    window.scrollInfinitoHabilitado = true;
    document.getElementById('cargarMasBtn').style.display = 'none';
    document.getElementById('fin-productos').style.display = 'none';
    
    const grid = document.getElementById('productos-grid');
    if (grid) {
        grid.setAttribute('data-offset', '16');
    }
    toggleCarrusel(true);
    const url = new URL(window.location.href);
    if (categoriaId > 0) {
        url.searchParams.set('categoria', categoriaId);
    } else {
        url.searchParams.delete('categoria');
    }
    url.searchParams.delete('buscar');
    window.history.pushState({}, '', url);
    
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Cargando productos...</div>';
    
    fetch('includes/filtrar_productos.php?categoria=' + categoriaId + '&offset=0')
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        
        if (categoriaId == 0) {
            const combosContainer = document.getElementById('combosContainer');
            if (combosContainer) combosContainer.style.display = '';
        }
        
        window.totalCargado = document.querySelectorAll('.producto-card').length;
        
        fetch('includes/total_filtro.php?categoria=' + categoriaId)
        .then(r => r.json())
        .then(data => {
            const totalReal = data.total;
            const contadorDiv = document.getElementById('contador-productos');
            if (contadorDiv) {
                if (categoriaId > 0) {
                    fetch('includes/obtener_categoria.php?id=' + categoriaId)
                    .then(r => r.json())
                    .then(cat => {
                        grid.setAttribute('data-total', totalReal);
                        contadorDiv.innerHTML = `<span><span id="btnLimpiarFiltro" style="cursor: pointer; color: #ef4444; margin-right: 0.5rem; display: inline-block;">✕</span>(${totalReal} ${cat.icono} ${cat.nombre})</span>`;
                    });
                } else {
                    grid.setAttribute('data-total', totalReal);
                    contadorDiv.innerHTML = `<span>(${totalReal} productos)</span>`;
                }
            }
        });
        
        grid.setAttribute('data-categoria', categoriaId);
        grid.setAttribute('data-buscar', '');
        grid.setAttribute('data-offset', '16');
        grid.setAttribute('data-cargando', 'false');
        document.getElementById('loader-mas-productos').style.display = 'none';
        document.getElementById('fin-productos').style.display = 'none';
        ajustarTamanosTarjetas();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(error => {
        console.error('Error:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al cargar productos</h3></div>';
    });
}

function filtrarNuevos() {
    // Si no estamos en index.php, redirigir
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        window.location.href = '/index.php?filtro=nuevos';
        return;
    }
    
    // Si estamos en index.php, ejecutar el filtro
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'none';
    
    window.totalCargado = 0;
    window.limiteScroll = 30;
    window.limiteScrollPC = 48;
    window.scrollActivo = true;
    window.scrollInfinitoHabilitado = true;
    document.getElementById('cargarMasBtn').style.display = 'none';
    document.getElementById('fin-productos').style.display = 'none';
    
    const grid = document.getElementById('productos-grid');
    if (grid) {
        grid.setAttribute('data-offset', '16');
    }
    toggleCarrusel(true);
    window.busquedaActiva = '';
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Cargando productos nuevos...</div>';
    
    fetch('includes/filtrar_avanzado.php?nuevos=1&offset=0')
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        window.totalCargado = document.querySelectorAll('.producto-card').length;
        
        fetch('includes/total_filtro.php?nuevos=1')
        .then(r => r.json())
        .then(data => {
            const totalReal = data.total;
            grid.setAttribute('data-total', totalReal);
            const contadorDiv = document.getElementById('contador-productos');
            if (contadorDiv) {
                contadorDiv.innerHTML = `<span><span id="btnLimpiarFiltro" style="cursor: pointer; color: #ef4444; margin-right: 0.5rem; display: inline-block;">✕</span>(${totalReal} nuevos)</span>`;
            }
        });
        
        grid.setAttribute('data-filtro', 'nuevos');
        grid.setAttribute('data-offset', '16');
        grid.setAttribute('data-cargando', 'false');
        
        const url = new URL(window.location.href);
        url.searchParams.set('filtro', 'nuevos');
        url.searchParams.delete('buscar');
        window.history.pushState({}, '', url);
        ajustarTamanosTarjetas();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(error => {
        console.error('Error:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al cargar productos</h3></div>';
    });
}

function filtrarMasVendidos() {
    // Si no estamos en index.php, redirigir
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        window.location.href = '/index.php?filtro=mas_vendidos';
        return;
    }
    
    // Si estamos en index.php, ejecutar el filtro
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'none';
    
    window.totalCargado = 0;
    window.limiteScroll = 30;
    window.limiteScrollPC = 48;
    window.scrollActivo = true;
    window.scrollInfinitoHabilitado = true;
    document.getElementById('cargarMasBtn').style.display = 'none';
    document.getElementById('fin-productos').style.display = 'none';
    
    const grid = document.getElementById('productos-grid');
    if (grid) {
        grid.setAttribute('data-offset', '16');
    }
    toggleCarrusel(true);
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Cargando productos más vendidos...</div>';
    
    const esMovil = window.innerWidth <= 768;
    let productosPorCarga = esMovil ? 6 : 16;
    
    fetch('includes/filtrar_avanzado.php?mas_vendidos=1&offset=0&limite=' + productosPorCarga)
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        const nuevosProductos = document.querySelectorAll('.producto-card').length;
        window.totalCargado = nuevosProductos;
        grid.setAttribute('data-offset', nuevosProductos);
        
        fetch('includes/total_filtro.php?mas_vendidos=1')
        .then(r => r.json())
        .then(data => {
            const totalReal = data.total;
            grid.setAttribute('data-total', totalReal);
            const contadorDiv = document.getElementById('contador-productos');
            if (contadorDiv) {
                contadorDiv.innerHTML = `<span><span id="btnLimpiarFiltro" style="cursor: pointer; color: #ef4444; margin-right: 0.5rem; display: inline-block;">✕</span>(${totalReal} más vendidos)</span>`;
            }
        });
        
        grid.setAttribute('data-filtro', 'mas_vendidos');
        grid.setAttribute('data-cargando', 'false');
        
        const url = new URL(window.location.href);
        url.searchParams.set('filtro', 'mas_vendidos');
        url.searchParams.delete('buscar');
        window.history.pushState({}, '', url);
        ajustarTamanosTarjetas();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(error => {
        console.error('Error:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al cargar productos</h3></div>';
    });
}

function filtrarOfertas() {
    // Si no estamos en index.php, redirigir
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        window.location.href = '/index.php?filtro=ofertas';
        return;
    }
    
    // Si estamos en index.php, ejecutar el filtro
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'none';
    
    window.totalCargado = 0;
    window.limiteScroll = 30;
    window.limiteScrollPC = 48;
    window.scrollActivo = true;
    window.scrollInfinitoHabilitado = true;
    document.getElementById('cargarMasBtn').style.display = 'none';
    document.getElementById('fin-productos').style.display = 'none';
    
    const grid = document.getElementById('productos-grid');
    if (grid) {
        grid.setAttribute('data-offset', '16');
    }
    toggleCarrusel(true);
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Cargando productos en oferta...</div>';
    
    fetch('includes/filtrar_avanzado.php?ofertas=1&offset=0')
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        window.totalCargado = document.querySelectorAll('.producto-card').length;
        
        fetch('includes/total_filtro.php?ofertas=1')
        .then(r => r.json())
        .then(data => {
            const totalReal = data.total;
            grid.setAttribute('data-total', totalReal);
            const contadorDiv = document.getElementById('contador-productos');
            if (contadorDiv) {
                contadorDiv.innerHTML = `<span><span id="btnLimpiarFiltro" style="cursor: pointer; color: #ef4444; margin-right: 0.5rem; display: inline-block;">✕</span>(${totalReal} en oferta)</span>`;
            }
        });
        
        grid.setAttribute('data-filtro', 'ofertas');
        grid.setAttribute('data-offset', '16');
        grid.setAttribute('data-cargando', 'false');
        
        const url = new URL(window.location.href);
        url.searchParams.set('filtro', 'ofertas');
        url.searchParams.delete('buscar');
        window.history.pushState({}, '', url);
        ajustarTamanosTarjetas();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(error => {
        console.error('Error:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al cargar productos</h3></div>';
    });
}

function cargarCombos() {
    // Si no estamos en index.php, redirigir
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        window.location.href = '/index.php?filtro=combos';
        return;
    }
    
    // Si estamos en index.php, ejecutar el filtro
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'none';
    
    window.totalCargado = 0;
    window.limiteScroll = 60;
    window.scrollActivo = true;
    window.scrollInfinitoHabilitado = true;
    document.getElementById('cargarMasBtn').style.display = 'none';
    document.getElementById('fin-productos').style.display = 'none';
    
    const carrusel = document.getElementById('carruselContainer');
    if (carrusel) carrusel.style.display = 'none';
    
    const grid = document.getElementById('productos-grid');
    if (!grid) return;
    
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🎁 Cargando combos...</div>';
    
    const esMovil = window.innerWidth <= 768;
    let combosPorCarga = esMovil ? 6 : 12;
    
    fetch('includes/cargar_combos.php?offset=0&limite=' + combosPorCarga)
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        
        const contadorDiv = document.getElementById('contador-productos');
        if (contadorDiv) {
            fetch('includes/total_combos.php')
            .then(r => r.json())
            .then(data => {
                contadorDiv.innerHTML = `<span><span id="btnLimpiarFiltro" style="cursor: pointer; color: #ef4444; margin-right: 0.5rem; display: inline-block;">✕</span>(${data.total} 🎁 Combos)</span>`;
                grid.setAttribute('data-total', data.total);
            });
        }
        
        grid.setAttribute('data-filtro', 'combos');
        grid.setAttribute('data-offset', combosPorCarga);
        window.totalCargado = combosPorCarga;
        
        if (typeof ajustarTamanosTarjetas === 'function') ajustarTamanosTarjetas();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    })
    .catch(error => {
        console.error('Error:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al cargar combos</h3></div>';
    });
}

function limpiarFiltroAjax() {
    const grid = document.getElementById('productos-grid');
    const combosContainer = document.getElementById('combosContainer');
    if (!grid) return;
    
    if (combosContainer) combosContainer.style.display = 'block';
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Limpiando filtro...</div>';
    
    fetch('includes/filtrar_productos.php?categoria=0&offset=0')
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        const totalProductos = document.querySelectorAll('.producto-card').length;
        const contadorDiv = document.getElementById('contador-productos');
        if (contadorDiv) {
            contadorDiv.innerHTML = `<span>(${totalProductos} productos)</span>`;
        }
        grid.setAttribute('data-categoria', '0');
        grid.setAttribute('data-buscar', '');
        grid.setAttribute('data-filtro', '');
        grid.setAttribute('data-offset', '16');
        grid.setAttribute('data-total', totalProductos);
        grid.setAttribute('data-cargando', 'false');
        
        if (typeof ajustarTamanosTarjetas === 'function') ajustarTamanosTarjetas();
        const carrusel = document.getElementById('carruselContainer');
        if (carrusel) carrusel.style.display = 'block';
        window.pasoAtras = 1;
    })
    .catch(error => {
        console.error('Error al limpiar filtro:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al limpiar filtro</h3></div>';
    });
}

// ============================================
// FUNCIONES DE SCROLL INFINITO
// ============================================
function cargarMasProductos() {
    const grid = document.getElementById('productos-grid');
    if (!grid) return;
    
    const esMovil = window.innerWidth <= 768;
    let productosPorCarga = esMovil ? 6 : 16;
    
    if (esMovil && window.scrollActivo === false) return;
    if (esMovil && window.totalCargado >= window.limiteScroll) {
        document.getElementById('cargarMasBtn').style.display = 'block';
        return;
    }
    if (!esMovil && window.totalCargado >= window.limiteScrollPC) {
        document.getElementById('cargarMasBtn').style.display = 'block';
        return;
    }
    if (window.scrollInfinitoHabilitado === false) return;
    
    const cargando = grid.getAttribute('data-cargando') === 'true';
    const offset = parseInt(grid.getAttribute('data-offset') || 0);
    const total = parseInt(grid.getAttribute('data-total') || 0);
    const categoria = parseInt(grid.getAttribute('data-categoria') || 0);
    const buscar = grid.getAttribute('data-buscar') || '';
    
    if (cargando) return;
    if (offset >= total) {
        document.getElementById('fin-productos').style.display = 'block';
        window.scrollInfinitoHabilitado = false;
        return;
    }
    
    grid.setAttribute('data-cargando', 'true');
    document.getElementById('loader-mas-productos').style.display = 'block';
    
    let url;
    const filtro = grid.getAttribute('data-filtro');
    
    if (filtro === 'combos') {
        url = 'includes/cargar_mas_combos.php?offset=' + offset + '&limite=' + productosPorCarga;
    } else {
        url = 'includes/cargar_mas_productos.php?offset=' + offset + '&categoria=' + categoria + '&limite=' + productosPorCarga;
        if (buscar) {
            url += '&buscar=' + encodeURIComponent(buscar);
        }
        if (filtro) {
            url += '&filtro=' + filtro;
        }
    }
    
    fetch(url)
    .then(response => response.text())
    .then(html => {
        if (html.trim()) {
            grid.insertAdjacentHTML('beforeend', html);
            const nuevosProductos = document.querySelectorAll('.producto-card').length;
            grid.setAttribute('data-offset', nuevosProductos);
            window.totalCargado = nuevosProductos;
            ajustarTamanosTarjetas();
        }
        grid.setAttribute('data-cargando', 'false');
        document.getElementById('loader-mas-productos').style.display = 'none';
        
        if (esMovil && window.totalCargado >= window.limiteScroll) {
            document.getElementById('cargarMasBtn').style.display = 'block';
            window.scrollActivo = false;
            return;
        }
        if (!esMovil && window.totalCargado >= window.limiteScrollPC && window.scrollActivo === true) {
            document.getElementById('cargarMasBtn').style.display = 'block';
            window.scrollActivo = false;
            return;
        }
    })
    .catch(error => {
        console.error('Error al cargar más productos:', error);
        grid.setAttribute('data-cargando', 'false');
        document.getElementById('loader-mas-productos').style.display = 'none';
    });
}

function cargarMasManual() {
    const esMovil = window.innerWidth <= 768;
    
    if (esMovil) {
        window.limiteScroll += 30;
    } else {
        window.limiteScrollPC += 48;
    }
    
    const grid = document.getElementById('productos-grid');
    if (grid) {
        const nuevosProductos = document.querySelectorAll('.producto-card').length;
        window.totalCargado = nuevosProductos;
        grid.setAttribute('data-offset', nuevosProductos);
    }
    
    window.scrollActivo = true;
    document.getElementById('cargarMasBtn').style.display = 'none';
    cargarMasProductos();
}

// ============================================
// FUNCIONES DE BÚSQUEDA
// ============================================
function buscarProductosAJAX(termino) {
    // Si no estamos en index.php, redirigir con el término de búsqueda
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        if (termino && termino.trim() !== '') {
            window.location.href = '/index.php?buscar=' + encodeURIComponent(termino);
        }
        return;
    }
    
    // Si estamos en index.php, ejecutar la búsqueda AJAX
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'none';
    
    if (window.innerWidth <= 768) {
        window.totalCargado = 0;
        window.limiteScroll = 30;
        window.scrollActivo = true;
        document.getElementById('cargarMasBtn').style.display = 'none';
    }
    
    window.scrollInfinitoHabilitado = true;
    document.getElementById('fin-productos').style.display = 'none';
    
    if (!termino || termino.trim() === '') {
        return;
    }
    
    if (typeof window.detenerScrollInfinito === 'function') {
        window.detenerScrollInfinito();
    }
    window.busquedaActiva = termino;
    
    const grid = document.getElementById('productos-grid');
    if (!grid) {
        window.location.href = '/index.php?buscar=' + encodeURIComponent(termino);
        return;
    }
    
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Buscando productos...</div>';
    
    fetch('includes/buscar_ajax.php?termino=' + encodeURIComponent(termino))
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        const totalProductos = document.querySelectorAll('.producto-card').length;
        const contadorDiv = document.getElementById('contador-productos');
        if (contadorDiv) {
            contadorDiv.innerHTML = `<span>🔍 ${totalProductos}  "${termino}"</span>`;
        }
        const btnLimpiar = document.getElementById('btnLimpiarBusqueda');
        if (btnLimpiar) {
            btnLimpiar.style.display = 'block';
        }
        document.getElementById('loader-mas-productos').style.display = 'none';
        document.getElementById('fin-productos').style.display = 'none';
        if (typeof ajustarTamanosTarjetas === 'function') {
            ajustarTamanosTarjetas();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al buscar</h3></div>';
    });
}

function limpiarBusquedaCompleta() {
    window.busquedaActiva = '';
    const inputBuscar = document.getElementById('buscarInputTitulo');
    if (inputBuscar) {
        inputBuscar.value = '';
    }
    const btnLimpiar = document.getElementById('btnLimpiarBusqueda');
    if (btnLimpiar) {
        btnLimpiar.style.display = 'none';
    }
    
    // Si no estamos en index.php, redirigir a index sin parámetros
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        window.location.href = '/index.php';
        return;
    }
    
    // Si estamos en index.php, limpiar filtros
    filtrarCategoria(0);
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'block';
    setTimeout(() => {
        const totalProductos = document.querySelectorAll('.producto-card').length;
        const contadorDiv = document.getElementById('contador-productos');
        if (contadorDiv) {
            contadorDiv.innerHTML = `<span>(${totalProductos} productos)</span>`;
        }
    }, 100);
}

function ejecutarBusqueda() {
    const inputBuscar = document.getElementById('buscarInputTitulo');
    if (inputBuscar) {
        const termino = inputBuscar.value.trim();
        if (termino !== '') {
            // Si no estamos en index.php, redirigir con el término
            if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
                window.location.href = '/index.php?buscar=' + encodeURIComponent(termino);
                return;
            }
            // Si estamos en index.php, ejecutar búsqueda AJAX
            toggleCarrusel(true);
            buscarProductosAJAX(termino);
        }
    }
}

// ============================================
// FUNCIONES DE UI / VISUALES
// ============================================
function ajustarTamanosTarjetas() {
    var anchoPantalla = window.innerWidth;
    var esMovil = anchoPantalla <= 768;
    
    if (esMovil) {
        document.querySelectorAll('.producto-marca').forEach(el => el.style.setProperty('font-size', '10px', 'important'));
        document.querySelectorAll('.producto-nombre').forEach(el => {
            el.style.setProperty('font-size', '13px', 'important');
        });
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('font-size', '9px', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('font-size', '11px', 'important'));
        document.querySelectorAll('.producto-precio').forEach(el => el.style.removeProperty('color'));
        document.querySelectorAll('.producto-nombre').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('margin-bottom', '6px', 'important'));
    } else {
        document.querySelectorAll('.producto-marca').forEach(el => el.style.setProperty('font-size', '0.7rem', 'important'));
        document.querySelectorAll('.producto-nombre').forEach(el => {
            el.style.setProperty('font-size', '0.9rem', 'important');
        });
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('font-size', '0.65rem', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('font-size', '0.75rem', 'important'));
        document.querySelectorAll('.producto-precio').forEach(el => el.style.removeProperty('color'));
        document.querySelectorAll('.producto-nombre').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('margin-bottom', '6px', 'important'));
    }
}

function verImagenGrande(src) {
    if (window.innerWidth > 768) return;
    const modal = document.getElementById('modalImagenGrande');
    const img = document.getElementById('imagenGrande');
    if (modal && img) {
        img.src = src;
        modal.style.display = 'flex';
    } else {
        window.open(src);
    }
}

function bloquearScrollFondo() {
    document.body.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.width = '100%';
}

function desbloquearScrollFondo() {
    document.body.style.overflow = '';
    document.body.style.position = '';
    document.body.style.width = '';
}

// ============================================
// MODAL COMBO TIENDA
// ============================================
function abrirModalComboTienda(comboId) {
    if (!comboId || isNaN(Number(comboId))) return;
    if (window.modalComboAbierto) return;
    
    window.history.pushState({ modalCombo: true }, '', window.location.pathname + window.location.search + '#modal-combo');
    
    const modal = document.getElementById('modalComboTienda');
    const contenedor = document.getElementById('contenidoModalComboTienda');
    
    contenedor.innerHTML = `<div style="text-align: center; padding: 2rem;"><div class="spinner-modal"></div><p>Cargando combo...</p></div>`;
    modal.style.display = 'block';
    window.modalComboAbierto = true;
    
    fetch('includes/get_combo_modal.php?id=' + comboId)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            contenedor.innerHTML = `
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <div style="text-align: center;">
                        <div class="producto-etiquetas">
                            ${data.combo.es_nuevo ? '<span class="etiqueta-nuevo">NUEVO</span>' : ''}
                            ${data.combo.porcentaje_rebaja > 0 ? `<span class="etiqueta-rebaja">-${data.combo.porcentaje_rebaja}%</span>` : ''}
                        </div>
                        <img src="${data.combo.imagen_url}" style="max-width: 100%; max-height: 250px; object-fit: contain; border-radius: 8px;">
                    </div>
                    <div>
                        <h3 style="font-size: 1.5rem;">${data.combo.nombre}</h3>
                        <div style="margin: 0.5rem 0;">${data.combo.descripcion}</div>
                        <div style="font-size: 0.85rem;">🎁 ${data.combo.total_productos} productos - ${data.combo.total_unidades} unidades</div>
                        <div style="margin: 0.5rem 0;">
                            ${data.combo.porcentaje_rebaja > 0 ? `
                                <span style="text-decoration: line-through;">${data.moneda_simbolo}${data.combo.precio.toFixed(2)}</span>
                                <strong style="font-size: 1.5rem; color: #10b981;">${data.moneda_simbolo}${data.combo.precio_final.toFixed(2)}</strong>
                            ` : `<strong style="font-size: 1.5rem;">${data.moneda_simbolo}${data.combo.precio.toFixed(2)}</strong>`}
                            <small>${data.moneda_codigo}</small>
                        </div>
                        <div style="display: flex; align-items: center; gap: 1rem; ${data.combo.stock_combo <= 0 ? 'opacity: 0.5; pointer-events: none;' : ''}">
                            <div class="cantidad-selector">
                                <button class="cantidad-btn" onclick="cambiarCantidadComboModal(-1, ${data.combo.id})">−</button>
                                <input type="text" id="cantidadComboModal_${data.combo.id}" class="cantidad-input" value="1" readonly style="width: 50px;">
                                <button class="cantidad-btn" onclick="cambiarCantidadComboModal(1, ${data.combo.id})">+</button>
                            </div>
                            <button class="btn-carrito" onclick="agregarComboModalAlCarrito(${data.combo.id})" style="${data.combo.stock_combo <= 0 ? 'display: none;' : ''}">
                                🛒 Agregar combo
                            </button>
                        </div>
                        ${data.combo.stock_combo <= 0 ? '<div style="color: #ef4444; text-align: center; margin-top: 1rem;">❌ Combo agotado</div>' : ''}
                    </div>
                </div>
            `;
        } else {
            contenedor.innerHTML = `<div style="text-align: center; color: #ef4444;">❌ ${data.error}</div>`;
        }
    })
    .catch(error => {
        contenedor.innerHTML = `<div style="text-align: center; color: #ef4444;">❌ Error al cargar</div>`;
    });
}

function cerrarModalComboTienda(reemplazarHash = true) {
    if (reemplazarHash && window.location.hash.includes('modal-combo')) {
        const urlLimpia = window.location.pathname + window.location.search;
        window.history.replaceState({}, '', urlLimpia);
    }
    const modal = document.getElementById('modalComboTienda');
    if (modal) modal.style.display = 'none';
    window.modalComboAbierto = false;
}

function cambiarCantidadComboModal(delta, comboId) {
    const input = document.getElementById(`cantidadComboModal_${comboId}`);
    if (input) {
        let valor = parseInt(input.value) || 1;
        valor = Math.max(1, Math.min(99, valor + delta));
        input.value = valor;
    }
}

function agregarComboModalAlCarrito(comboId) {
    const input = document.getElementById(`cantidadComboModal_${comboId}`);
    const cantidad = input ? parseInt(input.value) : 1;
    
    if (!window.clienteRegistrado) {
        cerrarModalComboTienda();
        document.getElementById('modalRegistro').style.display = 'block';
        window.productoPendiente = { combo: true, id: comboId, cantidad: cantidad };
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=agregar_combo&combo_id=' + comboId + '&cantidad=' + cantidad
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacion('✅ Combo agregado al carrito', 'exito');
            actualizarContadorCarrito();
            cerrarModalComboTienda();
        } else {
            mostrarNotificacion('❌ ' + data.mensaje, 'error');
        }
    });
}

document.addEventListener('click', function(event) {
    if (event.target === document.getElementById('modalComboTienda')) {
        cerrarModalComboTienda();
    }
});

// ============================================
// DELEGACIÓN DE EVENTOS PARA MODAL DE PRODUCTO
// ============================================
document.addEventListener('click', function(e) {
    const tarjeta = e.target.closest('.producto-card');
    if (!tarjeta) return;
    
    if (e.target.closest('.btn-carrito')) return;
    if (e.target.closest('.cantidad-btn')) return;
    if (e.target.closest('.cantidad-input')) return;
    
    if (e.target.closest('.producto-imagen')) {
        e.preventDefault();
    }
    
    let productoId = tarjeta.getAttribute('data-producto-id');
    
    if (productoId && !isNaN(Number(productoId))) {
        e.preventDefault();
        abrirModalProductoTienda(parseInt(productoId));
    }
});

// ============================================
// POPSTATE (BOTÓN ATRÁS)
// ============================================
if (sessionStorage.getItem('recargar_desde_modal') === 'true') {
    sessionStorage.removeItem('recargar_desde_modal');
    if (window.history.length === 1) {
        window.history.pushState({}, '', window.location.href);
    }
}

if (window.history.length === 1) {
    window.history.pushState({ pagina: 'index' }, '', window.location.href);
}

window.addEventListener('popstate', function(e) {
    if (document.getElementById('sideMenu')?.classList.contains('show')) {
        cerrarSideMenu();
        e.stopPropagation();
        return;
    }
    if (document.getElementById('categoriasRightMenu')?.classList.contains('show')) {
        cerrarCategoriasRightMenu();
        e.stopPropagation();
        return;
    }
    if (document.getElementById('clienteBottomMenu')?.classList.contains('show')) {
        cerrarClienteBottomMenu();
        e.stopPropagation();
        return;
    }
    if (window.modalProductoAbierto) {
        cerrarModalProductoTienda(false);
        window.pasoAtras = 1;
        window.modalCerradoConAtras = true;
        e.stopPropagation();
        return;
    }
    if (window.modalComboAbierto) {
        cerrarModalComboTienda(false);
        window.pasoAtras = 1;
        window.modalCerradoConAtras = true;
        e.stopPropagation();
        return;
    }
    if (window.location.pathname === '/' || window.location.pathname === '/index.php') {
        const params = new URLSearchParams(window.location.search);
        const tieneFiltro = params.has('categoria') || params.has('filtro') || params.has('buscar');
        if (tieneFiltro) {
            e.stopPropagation();
            sessionStorage.setItem('no_mostrar_carrito_pendiente', 'true');
            window.location.href = window.location.pathname;
            return;
        }
    }
    if (window.modalCerradoConAtras) {
        window.modalCerradoConAtras = false;
        sessionStorage.setItem('no_mostrar_carrito_pendiente', 'true');
        sessionStorage.setItem('recargar_desde_modal', 'true');
        window.location.href = window.location.pathname;
        return;
    }
    if (window.pasoAtras === 1) {
        sessionStorage.setItem('no_mostrar_carrito_pendiente', 'true');
        sessionStorage.setItem('recargar_desde_modal', 'true');
        window.location.href = 'index.php';
    }
});

// ============================================
// MODAL DE PRODUCTO (wrapper)
// ============================================
if (typeof window.abrirModalProductoTiendaOriginal === 'undefined') {
    window.abrirModalProductoTiendaOriginal = window.abrirModalProductoTienda;
    window.cerrarModalProductoTiendaOriginal = window.cerrarModalProductoTienda;
    
    window.abrirModalProductoTienda = function(productoId) {
        if (window.innerWidth <= 768) {
            bloquearScrollFondo();
        }
        return window.abrirModalProductoTiendaOriginal(productoId);
    };
    
    window.cerrarModalProductoTienda = function() {
        if (window.innerWidth <= 768) {
            desbloquearScrollFondo();
        }
        return window.cerrarModalProductoTiendaOriginal();
    };
}

// ============================================
// SCROLL INFINITO (evento)
// ============================================
window.addEventListener('scroll', function() {
    if (window.busquedaActiva) return;
    if (window.scrollInfinitoHabilitado === false) return;
    
    const scrollPos = window.innerHeight + window.scrollY;
    const alturaTotal = document.body.scrollHeight;
    var esMovil = window.innerWidth <= 768;
    var sensibilidad = esMovil ? 700 : 400;
    
    if (scrollPos >= alturaTotal - sensibilidad) {
        cargarMasProductos();
    }
});

// ============================================
// HEARTBEAT
// ============================================
function enviarHeartbeat() {
    fetch('heartbeat_cliente.php')
    .then(response => response.json())
    .then(data => console.log('Heartbeat:', data))
    .catch(error => console.log('Heartbeat error:', error));
}

setInterval(enviarHeartbeat, 30000);

// ============================================
// INICIALIZACIÓN
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(ajustarTamanosTarjetas, 50);
    actualizarContadorCarrito();
});

window.addEventListener('resize', function() {
    ajustarTamanosTarjetas();
});

if (window.location.search.includes('abrir_editar=1')) {
    sessionStorage.setItem('no_mostrar_carrito_pendiente', 'true');
    setTimeout(function() {
        if (typeof cargarDatosCliente === 'function') {
            cargarDatosCliente();
        } else {
            const modalEditar = document.getElementById('modalEditarCliente');
            if (modalEditar) modalEditar.style.display = 'block';
        }
        window.history.replaceState({}, document.title, window.location.pathname);
    }, 500);
}

verificarCarritoPendiente();
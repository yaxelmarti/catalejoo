<?php
/**
 * SISTEMA HÍBRIDO DE IDENTIFICACIÓN DE CLIENTES
 * UUID en cookie persistente + session_id como respaldo
 * Soporte para 3 dispositivos por cliente + estado activo/inactivo
 * NO crea clientes automáticamente (versión para admin)
 */

function generarUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function obtenerIdentificadorCliente() {
    // Iniciar sesión si no está iniciada
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // 1. Intentar con cookie persistente
    if (isset($_COOKIE['cliente_uuid'])) {
        $uuid = $_COOKIE['cliente_uuid'];
    } else {
        // 2. Crear nuevo UUID y guardarlo en cookie (1 año)
        $uuid = generarUUID();
        setcookie('cliente_uuid', $uuid, [
    'expires' => time() + (86400 * 365),
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);
    }
    
    return $uuid;
}

function obtenerClienteActual($conn) {
    $uuid = obtenerIdentificadorCliente();
    $session_id = session_id();
    
    // ============================================
    // 1. Buscar cliente por UUID en cualquiera de las 3 columnas
    // ============================================
    $stmt = $conn->prepare("SELECT * FROM clientes WHERE (uuid = ? OR uuid2 = ? OR uuid3 = ?) AND activo = 1");
    $stmt->bind_param("sss", $uuid, $uuid, $uuid);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Cliente existe y está activo
        $cliente = $result->fetch_assoc();
        
        // ✅ GUARDAR CLIENTE EN SESIÓN
        $_SESSION['cliente_id'] = $cliente['id'];
        $_SESSION['cliente_nombre'] = $cliente['nombre'] . ' ' . $cliente['apellidos'];
        $_SESSION['cliente_email'] = $cliente['email'];
        
        // Actualizar última actividad
        $stmt = $conn->prepare("UPDATE clientes SET session_id = ?, ultima_actividad = NOW() WHERE id = ?");
        $stmt->bind_param("si", $session_id, $cliente['id']);
        $stmt->execute();
        
        return $cliente;
    }
    
    // ============================================
    // 2. Buscar por session_id (respaldo para clientes existentes sin UUID)
    // ============================================
    $stmt = $conn->prepare("SELECT * FROM clientes WHERE session_id = ? AND activo = 1");
    $stmt->bind_param("s", $session_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $cliente = $result->fetch_assoc();
        
        // ✅ ASIGNAR UUID AL CLIENTE
        $stmt_update = $conn->prepare("UPDATE clientes SET uuid = ? WHERE id = ?");
        $stmt_update->bind_param("si", $uuid, $cliente['id']);
        $stmt_update->execute();
        
        // ✅ GUARDAR EN SESIÓN
        $_SESSION['cliente_id'] = $cliente['id'];
        $_SESSION['cliente_nombre'] = $cliente['nombre'] . ' ' . $cliente['apellidos'];
        $_SESSION['cliente_email'] = $cliente['email'];
        
        // ✅ ACTUALIZAR COOKIE
        setcookie('cliente_uuid', $uuid, [
    'expires' => time() + (86400 * 365),
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);
        
        // Actualizar última actividad
        $stmt = $conn->prepare("UPDATE clientes SET session_id = ?, ultima_actividad = NOW() WHERE id = ?");
        $stmt->bind_param("si", $session_id, $cliente['id']);
        $stmt->execute();
        
        return $cliente;
    }
    
    // ============================================
    // 3. Buscar si el UUID existe pero el cliente está inactivo
    // ============================================
    $stmt = $conn->prepare("SELECT * FROM clientes WHERE (uuid = ? OR uuid2 = ? OR uuid3 = ?) AND activo = 0");
    $stmt->bind_param("sss", $uuid, $uuid, $uuid);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
    // Cliente existe pero está INACTIVO - denegar acceso
    return [
        'id' => 0,
        'uuid' => $uuid,
        'activo' => 0,
        'error' => 'inactivo',
        'pais' => null,
        'moneda' => 'USD'
    ];
}
    
// ============================================
// 4. NO CREAR CLIENTE AUTOMÁTICAMENTE
// Devolver array indicando que no hay cliente
// ============================================
return [
    'id' => 0,
    'uuid' => $uuid,
    'session_id' => $session_id,
    'nombre' => null,
    'apellidos' => null,
    'movil' => null,
    'activo' => 0,
    'pais' => null,
    'moneda' => 'USD'
];
}

function registrarEventoCliente($conn, $cliente_id, $tipo, $carrito_id = null) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $stmt = $conn->prepare("INSERT INTO eventos_cliente (cliente_id, tipo, carrito_id, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isiss", $cliente_id, $tipo, $carrito_id, $ip, $user_agent);
    $stmt->execute();
}

function registrarIntentoRegistro($conn, $datos, $resultado, $cliente_id = null) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $stmt = $conn->prepare("INSERT INTO intentos_registro 
        (cliente_id, documento, movil, nombre_ingresado, apellidos_ingresados, ip_address, user_agent, resultado) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssss", 
        $cliente_id, 
        $datos['documento'], 
        $datos['movil'], 
        $datos['nombre'], 
        $datos['apellidos'], 
        $ip, 
        $user_agent, 
        $resultado
    );
    $stmt->execute();
}

/**
 * Asigna el UUID actual a un cliente existente (para después del registro)
 * @param mysqli $conn Conexión a la BD
 * @param int $cliente_id ID del cliente
 * @return bool True si se asignó correctamente
 */
function asignarUUIDaCliente($conn, $cliente_id) {
    $uuid = obtenerIdentificadorCliente();
    
    // Verificar si el UUID ya está asignado a este cliente
    $stmt = $conn->prepare("SELECT id FROM clientes WHERE id = ? AND (uuid = ? OR uuid2 = ? OR uuid3 = ?)");
    $stmt->bind_param("isss", $cliente_id, $uuid, $uuid, $uuid);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return true; // Ya está asignado
    }
    
    // Buscar espacio libre
    $campos = ['uuid', 'uuid2', 'uuid3'];
    foreach ($campos as $campo) {
        $stmt = $conn->prepare("UPDATE clientes SET $campo = ? WHERE id = ? AND ($campo IS NULL OR $campo = '')");
        $stmt->bind_param("si", $uuid, $cliente_id);
        $stmt->execute();
        
        if ($conn->affected_rows > 0) {
            return true;
        }
    }
    
    // Si no hay espacio, usar uuid principal (sobrescribir)
    $stmt = $conn->prepare("UPDATE clientes SET uuid = ? WHERE id = ?");
    $stmt->bind_param("si", $uuid, $cliente_id);
    $stmt->execute();
    
    return $conn->affected_rows > 0;
}

/**
 * Verifica si un cliente ya existe por documento, móvil o email
 * @param mysqli $conn Conexión a la BD
 * @param string $documento Documento a verificar
 * @param string $movil Móvil a verificar
 * @param string $email Email a verificar
 * @return array|false Datos del cliente o false
 */
function verificarClienteExistente($conn, $movil, $email, $documento = null) {
    $sql = "SELECT id, documento, movil, email, password FROM clientes WHERE 
            movil = ? OR email = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $movil, $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0 ? $result->fetch_assoc() : false;
}
?>
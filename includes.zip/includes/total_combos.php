<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

header('Content-Type: application/json');

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

// ===== RECIBIR PROVEEDOR =====
$proveedor_slug = isset($_GET['proveedor']) ? trim($_GET['proveedor']) : '';
$proveedor_id = 0;

if (!empty($proveedor_slug)) {
    $stmt_prov = $conn->prepare("SELECT id FROM proveedores WHERE slug = ?");
    $stmt_prov->bind_param("s", $proveedor_slug);
    $stmt_prov->execute();
    $result_prov = $stmt_prov->get_result();
    if ($row = $result_prov->fetch_assoc()) {
        $proveedor_id = $row['id'];
    }
}

$sql = "SELECT COUNT(*) as total FROM combos WHERE activo = 1 ";

// ===== FILTRO DE PROVEEDOR CENTRALIZADO =====
$proveedor_filtro_id = 0;

if ($proveedor_id > 0) {
    // Si hay slug en URL, usar ese (sobreescribe)
    $proveedor_filtro_id = $proveedor_id;
    // Validar que el proveedor existe y está activo
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_filtro_id);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $proveedor_filtro_id = 0;
    }
    $stmt_check->close();
} elseif ($es_proveedor && $proveedor_id_usuario > 0) {
    // Si es proveedor logueado, filtrar por su proveedor
    $proveedor_filtro_id = $proveedor_id_usuario;
}

if ($proveedor_filtro_id > 0) {
    $sql .= " AND proveedor_id = " . intval($proveedor_filtro_id) . " ";
}

$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
$total = $result->fetch_assoc()['total'];

echo json_encode(['total' => $total]);

$conn->close();
?>
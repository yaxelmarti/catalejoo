<?php
// ============================================
// CAMBIAR MONEDA (AJAX)
// Guarda la elección del usuario en sesión
// Ubicación: /includes/proveedores/cambiar_moneda_ajax.php
//
// Comportamiento:
// - Carrito vacío → solo cambia la moneda de la tienda (sesión)
// - Carrito del MISMO proveedor → cambia moneda de tienda + carrito
// - Carrito de OTRO proveedor → rechaza el cambio
// ============================================

// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__, 2) . '/conexion.php';
require_once dirname(__DIR__, 2) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__, 2) . '/includes/moneda_funciones.php';
require_once dirname(__DIR__, 2) . '/includes/carrito_funciones.php';

header('Content-Type: application/json');

// ============================================
// OBTENER PARÁMETROS
// ============================================
$proveedor_id = intval($_POST['proveedor_id'] ?? $_GET['proveedor_id'] ?? 0);
$moneda = strtoupper(trim($_POST['moneda'] ?? $_GET['moneda'] ?? ''));

// Validaciones básicas
if ($proveedor_id <= 0) {
    echo json_encode(['success' => false, 'mensaje' => 'Proveedor inválido']);
    exit;
}

if (empty($moneda)) {
    echo json_encode(['success' => false, 'mensaje' => 'Moneda no válida']);
    exit;
}

// Validar que la moneda existe y está activa en el sistema (dinámico)
$stmt_mon = $conn->prepare("SELECT codigo FROM tazas_cambio WHERE codigo = ? AND activo = 1");
$stmt_mon->bind_param("s", $moneda);
$stmt_mon->execute();
$moneda_existe = ($stmt_mon->get_result()->num_rows > 0);
$stmt_mon->close();

if (!$moneda_existe) {
    echo json_encode(['success' => false, 'mensaje' => 'Moneda no válida']);
    exit;
}

// ============================================
// VALIDAR QUE EL PROVEEDOR EXISTE Y ESTÁ ACTIVO
// ============================================
$stmt = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
$stmt->bind_param("i", $proveedor_id);
$stmt->execute();
if ($stmt->get_result()->num_rows === 0) {
    echo json_encode(['success' => false, 'mensaje' => 'La tienda no está disponible']);
    exit;
}
$stmt->close();

// ============================================
// VALIDAR QUE EL PROVEEDOR ACEPTA ESA MONEDA
// ============================================
$monedas_prov = getMonedasDelProveedor($conn, $proveedor_id);
if (!in_array($moneda, $monedas_prov)) {
    echo json_encode(['success' => false, 'mensaje' => 'Esta tienda no vende en esa moneda']);
    exit;
}

// ============================================
// VALIDAR CLIENTE REGISTRADO
// ============================================
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;
$cliente_registrado = ($cliente_id > 0 && !empty($cliente['nombre']));

if (!$cliente_registrado) {
    echo json_encode(['success' => false, 'mensaje' => 'Debes registrarte para cambiar de moneda']);
    exit;
}

// ============================================
// VERIFICAR CARRITO ACTIVO (si lo hay)
// ============================================
$carrito = iniciarCarrito($conn, $cliente_id);
$total_prod = 0;
$total_combos = 0;
$mismo_proveedor = false;

if ($carrito) {
    // Contar productos
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos WHERE carrito_id = ?");
    $stmt->bind_param("i", $carrito['id']);
    $stmt->execute();
    $total_prod = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $stmt->close();
    
    // Contar combos
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM carrito_combos WHERE carrito_id = ?");
    $stmt->bind_param("i", $carrito['id']);
    $stmt->execute();
    $total_combos = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $stmt->close();
    
    // ¿Tiene productos?
    if (($total_prod + $total_combos) > 0) {
        // ¿Es del mismo proveedor?
        $carrito_prov = intval($carrito['proveedor_id'] ?? 0);
        if ($carrito_prov === $proveedor_id) {
            $mismo_proveedor = true;
        } else {
            // Carrito de OTRO proveedor → bloquear
            echo json_encode([
                'success' => false,
                'mensaje' => 'No puedes cambiar de moneda con un carrito de otra tienda. Vacíalo primero.'
            ]);
            exit;
        }
    }
}

// ============================================
// GUARDAR EN SESIÓN (moneda de la tienda)
// ============================================
$_SESSION['moneda_proveedor_' . $proveedor_id] = $moneda;

// ============================================
// SI EL CARRITO ES DEL MISMO PROVEEDOR → ACTUALIZAR SU MONEDA
// ============================================
if ($mismo_proveedor && $carrito) {
    // Actualizar la moneda del carrito
    $stmt = $conn->prepare("UPDATE carritos SET moneda = ? WHERE id = ?");
    $stmt->bind_param("si", $moneda, $carrito['id']);
    $stmt->execute();
    $stmt->close();
    
    // Actualizar la moneda de los productos del carrito
    $stmt = $conn->prepare("UPDATE carrito_productos SET moneda = ? WHERE carrito_id = ?");
    $stmt->bind_param("si", $moneda, $carrito['id']);
    $stmt->execute();
    $stmt->close();
    
    // Actualizar la moneda de los combos del carrito
    $stmt = $conn->prepare("UPDATE carrito_combos SET moneda = ? WHERE carrito_id = ?");
    $stmt->bind_param("si", $moneda, $carrito['id']);
    $stmt->execute();
    $stmt->close();
    
    // NOTA: precio_convertido y tasa_aplicada se recalculan
    // automáticamente en obtener_carrito() cuando el usuario abre el carrito
}

// ============================================
// RESPUESTA
// ============================================
echo json_encode([
    'success' => true,
    'moneda' => $moneda,
    'simbolo' => getSimboloPorMoneda($moneda),
    'carrito_actualizado' => $mismo_proveedor,
    'mensaje' => 'Moneda cambiada correctamente'
]);
exit;
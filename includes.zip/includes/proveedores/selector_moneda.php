<?php
// ============================================
// SELECTOR DE MONEDA
// Ubicación: /includes/proveedores/selector_moneda.php
// Se incluye desde index.php (dentro del título de la tienda)
//
// Aparece si:
// - Hay proveedor en contexto
// - El cliente está registrado
// - El proveedor vende 2+ monedas
//
// Se bloquea (pero se muestra) si:
// - Hay carrito activo con productos DE OTRO PROVEEDOR
//
// Se muestra activo si:
// - No hay carrito, o
// - El carrito es del MISMO proveedor (al cambiar, se actualiza el carrito)
// ============================================

// ============================================
// VERIFICACIONES (no imprimir si no aplica)
// ============================================

// 1. ¿Hay proveedor en contexto?
$selector_proveedor_id = intval($proveedor_contexto ?? $proveedor_id ?? 0);
if ($selector_proveedor_id <= 0) {
    return;
}

// 2. ¿Cliente registrado?
if (empty($cliente_registrado)) {
    return;
}

// 3. ¿Proveedor vende 2+ monedas?
if (!function_exists('getMonedasDelProveedor')) {
    return;
}
$selector_monedas = getMonedasDelProveedor($conn, $selector_proveedor_id);
if (count($selector_monedas) < 2) {
    return;
}

// ============================================
// 4. ¿HAY CARRITO ACTIVO CON PRODUCTOS?
// Solo bloquea si el carrito es de OTRO proveedor.
// Si es del mismo proveedor → activo (se actualizará el carrito).
// ============================================
$selector_carrito_activo = false;
if (function_exists('iniciarCarrito') && !empty($cliente['id'])) {
    $selector_carrito = iniciarCarrito($conn, $cliente['id']);
    if ($selector_carrito) {
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos WHERE carrito_id = ?");
        $stmt->bind_param("i", $selector_carrito['id']);
        $stmt->execute();
        $sel_total_prod = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
        $stmt->close();
        
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM carrito_combos WHERE carrito_id = ?");
        $stmt->bind_param("i", $selector_carrito['id']);
        $stmt->execute();
        $sel_total_combos = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
        $stmt->close();
        
        if (($sel_total_prod + $sel_total_combos) > 0) {
            // ¿Es del mismo proveedor?
            $carrito_prov = intval($selector_carrito['proveedor_id'] ?? 0);
            if ($carrito_prov !== $selector_proveedor_id) {
                $selector_carrito_activo = true; // Bloquear (otro proveedor)
            }
            // Si es del mismo proveedor → se queda activo (false)
        }
    }
}

// ============================================
// DETERMINAR MONEDA ACTUAL DEL SELECTOR
// ============================================
$selector_moneda_actual = $_SESSION['moneda_proveedor_' . $selector_proveedor_id] ?? $moneda_actual ?? 'USD';
if (!in_array($selector_moneda_actual, $selector_monedas)) {
    $selector_moneda_actual = $selector_monedas[0];
}

// ============================================
// ETIQUETAS DE MONEDA
// ============================================
$selector_labels = [
    'USD' => 'USD $',
    'EUR' => 'EUR €',
    'CUP' => 'CUP $'
];
?>

<!-- ============================================
     SELECTOR DE MONEDA
     ============================================ -->
<div class="selector-moneda-wrapper" style="margin-top: 0.5rem; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.3rem; flex-wrap: wrap;">
    <div style="display: flex; align-items: center; justify-content: center; gap: 0.4rem; flex-wrap: wrap;">
        <span style="font-size: 0.75rem; color: #6b7280; font-weight: 500;">💱 Moneda:</span>
        <div class="selector-moneda-pills" style="display: inline-flex; gap: 0.3rem; background: #f3f4f6; padding: 0.2rem; border-radius: 30px; <?php echo $selector_carrito_activo ? 'opacity: 0.6;' : ''; ?>">
            <?php foreach ($selector_monedas as $moneda_opcion): 
                $es_activa = ($moneda_opcion === $selector_moneda_actual);
            ?>
                <button 
                    type="button"
                    class="selector-moneda-btn <?php echo $es_activa ? 'activa' : ''; ?>"
                    data-moneda="<?php echo htmlspecialchars($moneda_opcion); ?>"
                    data-proveedor="<?php echo intval($selector_proveedor_id); ?>"
                    onclick="<?php echo $selector_carrito_activo ? 'return false;' : 'cambiarMonedaSelector(this)'; ?>"
                    title="<?php echo $selector_carrito_activo ? 'Vacía el carrito para cambiar de moneda' : 'Cambiar a ' . htmlspecialchars($selector_labels[$moneda_opcion] ?? $moneda_opcion); ?>"
                    style="
                        padding: 0.3rem 0.9rem;
                        border: none;
                        border-radius: 30px;
                        font-size: 0.8rem;
                        font-weight: 600;
                        cursor: <?php echo ($es_activa || $selector_carrito_activo) ? 'not-allowed' : 'pointer'; ?>;
                        transition: all 0.25s ease;
                        <?php if ($es_activa): ?>
                            background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
                            color: white;
                            box-shadow: 0 2px 8px rgba(102,126,234,0.3);
                        <?php else: ?>
                            background: transparent;
                            color: #4b5563;
                        <?php endif; ?>
                    "
                    <?php echo ($es_activa || $selector_carrito_activo) ? 'disabled' : ''; ?>
                >
                    <?php echo htmlspecialchars($selector_labels[$moneda_opcion] ?? $moneda_opcion); ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php if ($selector_carrito_activo): ?>
        <span style="font-size: 0.7rem; color: #d97706; font-weight: 500; text-align: center;">
            ⚠️ Vacía el carrito para cambiar de moneda
        </span>
    <?php endif; ?>
</div>

<style>
.selector-moneda-btn:not(.activa):not(:disabled):hover {
    background: #e5e7eb !important;
    color: #1f2937 !important;
}
.selector-moneda-btn.activa {
    cursor: default;
}
.selector-moneda-btn:disabled {
    opacity: 1;
}
</style>

<script>
window.cambiarMonedaSelector = function(btn) {
    const moneda = btn.getAttribute('data-moneda');
    const proveedorId = btn.getAttribute('data-proveedor');
    
    if (!moneda || !proveedorId) return;
    if (btn.disabled) return;
    
    // Deshabilitar botones mientras se procesa
    const todosBotones = document.querySelectorAll('.selector-moneda-btn');
    todosBotones.forEach(b => b.disabled = true);
    
    fetch('includes/proveedores/cambiar_moneda_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'proveedor_id=' + encodeURIComponent(proveedorId) + '&moneda=' + encodeURIComponent(moneda)
    })
    .then(response => response.json())
    .then(data => {
    if (data.success) {
        // Guardar posición del scroll para restaurarla tras la recarga
        try {
            sessionStorage.setItem('selector_scroll_restore', String(window.scrollY));
        } catch (e) {}
        
        // Recargar para que toda la tienda use la nueva moneda
        window.location.reload();
    } else {
            if (typeof mostrarNotificacion === 'function') {
                mostrarNotificacion('❌ ' + (data.mensaje || 'Error al cambiar moneda'), 'error');
            } else {
                alert(data.mensaje || 'Error al cambiar moneda');
            }
            // Rehabilitar botones
            todosBotones.forEach(b => b.disabled = false);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        if (typeof mostrarNotificacion === 'function') {
            mostrarNotificacion('❌ Error de conexión', 'error');
        }
        todosBotones.forEach(b => b.disabled = false);
    });
};
</script>
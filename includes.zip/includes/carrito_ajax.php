<?php
// Capturar errores fatales
error_log("=== CARRITO AJAX INICIADO ===");
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false, 
            'fatal_error' => true,
            'message' => $error['message'],
            'line' => $error['line'],
            'file' => $error['file']
        ]);
    }
});

// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/conexion.php';
require_once 'cliente_identificador.php';
require_once 'carrito_funciones.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once 'moneda_funciones.php';

// ============================================
// FUNCIÓN PARA OBTENER PROVEEDOR DEL CARRITO
// ============================================
function obtenerProveedorCarrito($conn, $carrito_id) {
    $stmt = $conn->prepare("SELECT proveedor_id FROM carritos WHERE id = ?");
    $stmt->bind_param("i", $carrito_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $proveedor_id = $result ? $result['proveedor_id'] : null;
    
    // ✅ Normalizar: 0, NULL o vacío → null (carrito vacío / sin proveedor)
    if (empty($proveedor_id) || $proveedor_id <= 0) {
        return null;
    }
    
    // 🔥 Validar que el proveedor existe y está activo
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        return null; // Proveedor no existe o está inactivo
    }
    $stmt_check->close();
    
    return $proveedor_id;
}

function asignarProveedorCarrito($conn, $carrito_id, $proveedor_id) {
    $stmt = $conn->prepare("UPDATE carritos SET proveedor_id = ? WHERE id = ?");
    $stmt->bind_param("ii", $proveedor_id, $carrito_id);
    return $stmt->execute();
}

header('Content-Type: application/json');

// Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'];

$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';
$respuesta = ['success' => false];

// ============================================
// HELPER: Obtener moneda del carrito o cliente
// ============================================
function getMonedaActual($conn, $cliente, $carrito_id = null, $proveedor_id = null) {
    // 1. Si hay carrito con moneda → esa
    if ($carrito_id !== null && $carrito_id > 0) {
        $stmt = $conn->prepare("SELECT moneda FROM carritos WHERE id = ?");
        $stmt->bind_param("i", $carrito_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($res && !empty($res['moneda'])) {
            return $res['moneda'];
        }
    }
    
    // 2. Si hay proveedor → usar getMonedaParaProveedor
    if ($proveedor_id !== null && $proveedor_id > 0) {
        return getMonedaParaProveedor($conn, $proveedor_id, $cliente);
    }
    
    // 3. Sin proveedor → moneda del cliente
    return getMonedaDelCliente($conn, $cliente);
}

// ============================================
// REGISTRAR CLIENTE (CON VERIFICACIÓN DE EXISTENCIA)
// ============================================
if ($accion === 'registrar_cliente') {
   $nombre_completo = trim($_POST['nombre_completo'] ?? '');
    $nombre = $nombre_completo;
$apellidos = '';
    $email = trim($_POST['email'] ?? '');
 //   $documento = trim($_POST['documento'] ?? '');
    $movil = trim($_POST['movil'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $errores = [];
    if (empty($nombre_completo)) $errores[] = "Nombre completo requerido";
    if (empty($email)) $errores[] = "Email requerido";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = "Email no válido";
   // if (empty($documento)) $errores[] = "Documento requerido";
    if (empty($movil)) $errores[] = "Móvil requerido";
   // if (empty($password)) $errores[] = "Contraseña requerida";
   // if (strlen($password) < 6) $errores[] = "La contraseña debe tener al menos 6 caracteres";
    
    if (!empty($errores)) {
        echo json_encode(['success' => false, 'mensaje' => implode('<br>', $errores)]);
        exit;
    }
    
    // ===== VERIFICAR SI EL CLIENTE YA EXISTE (priorizando DOCUMENTO) =====
    $cliente_existente = verificarClienteExistente($conn, $movil, $email);
    
    if ($cliente_existente) {
        $campo_coincidencia = '';
        $valor_coincidencia = '';
        
      /*  if ($cliente_existente['documento'] == $documento) {
            $campo_coincidencia = 'documento';
            $valor_coincidencia = $documento;    */
       if ($cliente_existente['email'] == $email) {
    $campo_coincidencia = 'email';
    $valor_coincidencia = $email;
} elseif ($cliente_existente['movil'] == $movil) {
    $campo_coincidencia = 'móvil';
    $valor_coincidencia = $movil;
}
        
        $_SESSION['datos_pendientes'] = [
            'nombre' => $nombre,
            'apellidos' => $apellidos,
            'email' => $email,
          //  'documento' => $documento,
            'movil' => $movil,
            'password' => $password
        ];
        $_SESSION['cliente_existente_id'] = $cliente_existente['id'];
        
        echo json_encode([
            'success' => false,
            'requiere_password' => true,
            'coincidencia' => $campo_coincidencia,
            'valor_coincidencia' => $valor_coincidencia,
            'mensaje' => "El $campo_coincidencia '$valor_coincidencia' ya se encuentra registrado. Si este es su Email Haz clic en el botón para verificar su $campo_coincidencia y vincular este dispositivo."
        ]);
        exit;
    }
    
        // Cliente nuevo
   $uuid_actual = $_COOKIE['cliente_uuid'] ?? session_id();
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// ============================================
// DETECTAR PAÍS Y MONEDA DEL CLIENTE
// ============================================
$pais_detectado = getPaisPorIP();
$moneda_asignada = getMonedaPorPais($pais_detectado);

$sql = "INSERT INTO clientes (uuid, nombre, apellidos, email, movil, password, pais, moneda, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssss", $uuid_actual, $nombre, $apellidos, $email, $movil, $password_hash, $pais_detectado, $moneda_asignada);
    
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'mensaje' => 'Error al crear el cliente: ' . $conn->error]);
        exit;
    }
    
    $nuevo_cliente_id = $conn->insert_id;
    
    $token = bin2hex(random_bytes(32));
    $expira = date('Y-m-d H:i:s', strtotime('+48 hours'));
    
    $stmt = $conn->prepare("UPDATE clientes SET email_verified = 0, verification_token = ?, token_expires = ?, verification_sent_at = NOW() WHERE id = ?");
    $stmt->bind_param("ssi", $token, $expira, $nuevo_cliente_id);
    $stmt->execute();
    
    $_SESSION['cliente_id'] = $nuevo_cliente_id;
    $cliente_id = $nuevo_cliente_id;

// ✅ CAMBIO 1: ACTUALIZAR COOKIE
setcookie('cliente_uuid', $uuid_actual, [
    'expires' => time() + (86400 * 365),
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

// ✅ CAMBIO 2: MIGRAR CARRITO DEL CLIENTE TEMPORAL
$cliente_anterior_id = $cliente_id ?? 0;
if ($cliente_anterior_id > 0 && $cliente_anterior_id != $nuevo_cliente_id) {
    $stmt = $conn->prepare("UPDATE carritos SET cliente_id = ? WHERE cliente_id = ? AND estado = 'pendiente'");
    $stmt->bind_param("ii", $nuevo_cliente_id, $cliente_anterior_id);
    $stmt->execute();
}

// ✅ CAMBIO 3: AGREGAR PRODUCTO PENDIENTE (si existe)
if (isset($_SESSION['producto_pendiente']) && !empty($_SESSION['producto_pendiente'])) {
    $producto_pendiente = $_SESSION['producto_pendiente'];
    $producto_id = $producto_pendiente['id'] ?? 0;
    $cantidad = $producto_pendiente['cantidad'] ?? 1;
    $es_combo = $producto_pendiente['combo'] ?? false;
    
    if ($producto_id > 0) {
        $carrito = obtenerOCrearCarrito($conn, $nuevo_cliente_id);
        if ($carrito) {
            $carrito_id = is_array($carrito) ? $carrito['id'] : $carrito;
            
            if ($es_combo) {
                $stmt_check = $conn->prepare("SELECT precio_final FROM combos WHERE id = ? AND activo = 1");
                $stmt_check->bind_param("i", $producto_id);
                $stmt_check->execute();
                $combo = $stmt_check->get_result()->fetch_assoc();
                
                if ($combo) {
                    $precio_total = $combo['precio_final'] * $cantidad;
                    $stmt_insert = $conn->prepare("INSERT INTO carrito_combos (carrito_id, combo_id, cantidad, precio_total) VALUES (?, ?, ?, ?)");
                    $stmt_insert->bind_param("iiid", $carrito_id, $producto_id, $cantidad, $precio_total);
                    $stmt_insert->execute();
                }
            } else {
                $stmt_check = $conn->prepare("SELECT precio FROM productos WHERE id = ? AND activo = 1");
                $stmt_check->bind_param("i", $producto_id);
                $stmt_check->execute();
                $producto = $stmt_check->get_result()->fetch_assoc();
                
                if ($producto) {
                    $stmt_insert = $conn->prepare("INSERT INTO carrito_productos (carrito_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)");
                    $stmt_insert->bind_param("iiid", $carrito_id, $producto_id, $cantidad, $producto['precio']);
                    $stmt_insert->execute();
                }
            }
        }
    }
    unset($_SESSION['producto_pendiente']);
}
    
    // Enviar correo de verificación
    require_once dirname(__DIR__) . '/includes/email_config.php';
    require_once dirname(__DIR__) . '/includes/email_templates.php';
    
    $config_sitio = [];
    $result_config = $conn->query("SELECT clave, valor FROM configuracion WHERE clave IN ('sitio_nombre', 'sitio_email')");
    while($row = $result_config->fetch_assoc()) {
        $config_sitio[$row['clave']] = $row['valor'];
    }
    $GLOBALS['config'] = $config_sitio;
    
    $asunto = "Verifica tu email - " . ($config_sitio['sitio_nombre'] ?? 'Mi Tienda');
    $cuerpo = plantilla_verificacion(['nombre' => $nombre], $token);
    
    if (function_exists('enviarCorreoBase')) {
        enviarCorreoBase($email, $asunto, $cuerpo);
    }
    
    if (function_exists('asignarUUIDaCliente')) {
        $asignado = asignarUUIDaCliente($conn, $nuevo_cliente_id);
    }
    
    echo json_encode([
        'success' => true, 
        'mensaje' => 'Registro exitoso',
        'requiere_verificacion' => true,
        'cliente_id' => $nuevo_cliente_id
    ]);
    exit;
}

// ============================================
// VERIFICAR CONTRASEÑA Y VINCULAR DISPOSITIVO
// ============================================
if ($accion === 'verificar_password_vinculacion') {
    // ✅ ASEGURAR QUE LA SESIÓN ESTÉ ACTIVA
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    $password = $_POST['password'] ?? '';
    
    // ✅ CASO 1: Cliente ya existe (datos pendientes)
    if (isset($_SESSION['cliente_existente_id']) && isset($_SESSION['datos_pendientes'])) {
        $cliente_existente_id = (int)$_SESSION['cliente_existente_id'];
        $datos_pendientes = $_SESSION['datos_pendientes'];
        
        // Obtener datos del cliente
        $stmt = $conn->prepare("SELECT * FROM clientes WHERE id = ? AND activo = 1");
        $stmt->bind_param("i", $cliente_existente_id);
        $stmt->execute();
        $cliente_existente = $stmt->get_result()->fetch_assoc();
        
        if (!$cliente_existente) {
            echo json_encode(['success' => false, 'mensaje' => 'Cliente no encontrado']);
            exit;
        }
        
        if (!password_verify($password, $cliente_existente['password'])) {
            echo json_encode(['success' => false, 'mensaje' => 'Contraseña incorrecta']);
            exit;
        }
        
        // ============================================
        // VINCULAR DISPOSITIVO (DENTRO DEL IF)
        // ============================================
        $uuid_actual = $_COOKIE['cliente_uuid'] ?? session_id();
        
        // Obtener UUIDs del cliente
        $stmt = $conn->prepare("SELECT uuid, uuid2, uuid3 FROM clientes WHERE id = ? AND activo = 1");
        $stmt->bind_param("i", $cliente_existente_id);
        $stmt->execute();
        $cliente_data = $stmt->get_result()->fetch_assoc();
        
        $uuid_ya_vinculado = (
            $cliente_data['uuid'] == $uuid_actual || 
            $cliente_data['uuid2'] == $uuid_actual || 
            $cliente_data['uuid3'] == $uuid_actual
        );
        
        if (!$uuid_ya_vinculado) {
    // ✅ REVISAR uuid, uuid2 y uuid3 (en orden)
    if (empty($cliente_data['uuid'])) {
        $campo = 'uuid';
    } elseif (empty($cliente_data['uuid2'])) {
        $campo = 'uuid2';
    } elseif (empty($cliente_data['uuid3'])) {
        $campo = 'uuid3';
    } else {
        echo json_encode([
            'success' => false, 
            'mensaje' => 'Ya tienes 3 dispositivos vinculados. Desvincula uno primero.'
        ]);
        exit;
    }
    
    $stmt = $conn->prepare("UPDATE clientes SET $campo = ? WHERE id = ?");
    $stmt->bind_param("si", $uuid_actual, $cliente_existente_id);
    $stmt->execute();
}
        
        // Crear cookie
        setcookie('cliente_uuid', $uuid_actual, [
            'expires' => time() + (86400 * 365),
            'path' => '/',
            'domain' => '',
            'secure' => false,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        
        // Guardar en sesión
        $nombre_completo = trim(($cliente_existente['nombre'] ?? '') . ' ' . ($cliente_existente['apellidos'] ?? ''));
        if (empty($nombre_completo)) {
            $nombre_completo = $cliente_existente['email'] ?? 'Cliente';
        }
        
        $_SESSION['cliente_id'] = $cliente_existente_id;
        $_SESSION['cliente_nombre'] = $nombre_completo;
        $_SESSION['cliente_email'] = $cliente_existente['email'] ?? '';
        
        // Limpiar variables temporales
        unset($_SESSION['cliente_existente_id']);
        unset($_SESSION['datos_pendientes']);
        
        echo json_encode([
            'success' => true, 
            'mensaje' => 'Dispositivo vinculado correctamente',
            'cliente_id' => $cliente_existente_id
        ]);
        exit;
    }
    
    // ✅ CASO 2: Cliente ya logueado (sin datos pendientes)
    $cliente = obtenerClienteActual($conn);
    $cliente_id = $cliente['id'] ?? 0;
    
    if ($cliente_id == 0) {
        echo json_encode(['success' => false, 'mensaje' => 'Sesión no válida. Inicia sesión nuevamente.']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT password, nombre, apellidos, email FROM clientes WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente_data = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente_data || !password_verify($password, $cliente_data['password'])) {
        echo json_encode(['success' => false, 'mensaje' => 'Contraseña incorrecta']);
        exit;
    }
    
    // ============================================
    // VINCULAR DISPOSITIVO (CASO 2)
    // ============================================
    $uuid_actual = $_COOKIE['cliente_uuid'] ?? session_id();
    
    $stmt = $conn->prepare("SELECT uuid, uuid2, uuid3 FROM clientes WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente_uuids = $stmt->get_result()->fetch_assoc();
    
    $uuid_ya_vinculado = (
        $cliente_uuids['uuid'] == $uuid_actual || 
        $cliente_uuids['uuid2'] == $uuid_actual || 
        $cliente_uuids['uuid3'] == $uuid_actual
    );
    
    if (!$uuid_ya_vinculado) {
    // ✅ REVISAR uuid, uuid2 y uuid3 (en orden)
    if (empty($cliente_uuids['uuid'])) {
        $campo = 'uuid';
    } elseif (empty($cliente_uuids['uuid2'])) {
        $campo = 'uuid2';
    } elseif (empty($cliente_uuids['uuid3'])) {
        $campo = 'uuid3';
    } else {
        echo json_encode([
            'success' => false, 
            'mensaje' => 'Ya tienes 3 dispositivos vinculados. Desvincula uno primero.'
        ]);
        exit;
    }
    
    $stmt = $conn->prepare("UPDATE clientes SET $campo = ? WHERE id = ?");
    $stmt->bind_param("si", $uuid_actual, $cliente_id);
    $stmt->execute();
}
    
    // Crear cookie
    setcookie('cliente_uuid', $uuid_actual, [
        'expires' => time() + (86400 * 365),
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    
    // Guardar en sesión
    $nombre_completo = trim(($cliente_data['nombre'] ?? '') . ' ' . ($cliente_data['apellidos'] ?? ''));
    if (empty($nombre_completo)) {
        $nombre_completo = $cliente_data['email'] ?? 'Cliente';
    }
    
    $_SESSION['cliente_id'] = $cliente_id;
    $_SESSION['cliente_nombre'] = $nombre_completo;
    $_SESSION['cliente_email'] = $cliente_data['email'] ?? '';
    
    echo json_encode([
        'success' => true, 
        'mensaje' => 'Dispositivo vinculado correctamente',
        'cliente_id' => $cliente_id
    ]);
    exit;
}

// ============================================
// REENVIAR VERIFICACIÓN
// ============================================
if ($accion === 'reenviar_verificacion') {
    $stmt = $conn->prepare("SELECT email, nombre, verification_sent_at FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    
    if (!$cliente) {
        echo json_encode(['success' => false, 'mensaje' => 'Cliente no encontrado']);
        exit;
    }
    
    if ($cliente['verification_sent_at'] && strtotime($cliente['verification_sent_at']) > strtotime('-5 minutes')) {
        echo json_encode(['success' => false, 'mensaje' => 'Espera 5 minutos antes de reenviar']);
        exit;
    }
    
    $token = bin2hex(random_bytes(32));
    $expira = date('Y-m-d H:i:s', strtotime('+48 hours'));
    
    $stmt = $conn->prepare("UPDATE clientes SET verification_token = ?, token_expires = ?, verification_sent_at = NOW() WHERE id = ?");
    $stmt->bind_param("ssi", $token, $expira, $cliente_id);
    $stmt->execute();
    
    require_once dirname(__DIR__) . '/includes/email_config.php';
    require_once dirname(__DIR__) . '/includes/email_templates.php';
    
    $config_sitio = [];
    $result_config = $conn->query("SELECT clave, valor FROM configuracion WHERE clave IN ('sitio_nombre', 'sitio_email')");
    while($row = $result_config->fetch_assoc()) {
        $config_sitio[$row['clave']] = $row['valor'];
    }
    $GLOBALS['config'] = $config_sitio;
    
    $asunto = "Verifica tu email - " . ($config_sitio['sitio_nombre'] ?? 'Mi Tienda');
    $cuerpo = plantilla_verificacion(['nombre' => $cliente['nombre']], $token);
    
    if (function_exists('enviarCorreoBase')) {
        enviarCorreoBase($cliente['email'], $asunto, $cuerpo);
    }
    
    echo json_encode(['success' => true, 'mensaje' => 'Hemos enviado un nuevo enlace a tu email']);
    exit;
}

// ============================================
// VERIFICAR CARRITO PENDIENTE
// ============================================
if ($accion === 'verificar_carrito_pendiente') {
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => true, 'tiene_carrito' => false]);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT cp.*, p.nombre, p.imagen_url FROM carrito_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.carrito_id = ?");
    $stmt->bind_param("i", $carrito['id']);
    $stmt->execute();
    $productos = $stmt->get_result();
    
        $items = [];
    $total = 0;
    
    $moneda_carrito = $carrito['moneda'] ?? null;
    $proveedor_carrito = $carrito['proveedor_id'] ?? 0;
    
    // Si el carrito no tiene moneda pero sí proveedor, calcularla
    if (empty($moneda_carrito) && $proveedor_carrito > 0) {
        $moneda_carrito = getMonedaParaProveedor($conn, $proveedor_carrito, $cliente);
        $stmt_upd = $conn->prepare("UPDATE carritos SET moneda = ? WHERE id = ?");
        $stmt_upd->bind_param("si", $moneda_carrito, $carrito['id']);
        $stmt_upd->execute();
        $stmt_upd->close();
    }
    
    // Fallback final
    if (empty($moneda_carrito)) {
        $moneda_carrito = 'USD';
    }
    
    while ($item = $productos->fetch_assoc()) {
        $tasa_actual = getTasaProveedor($conn, $proveedor_carrito, $moneda_carrito);
        $precio_convertido = floatval($item['precio_unitario']);
        if ($moneda_carrito !== 'USD' && $tasa_actual > 0) {
            $precio_convertido = floatval($item['precio_unitario']) * $tasa_actual;
        }
        $subtotal = $precio_convertido * $item['cantidad'];
        $total += $subtotal;
        $items[] = [
            'producto_id' => $item['producto_id'],
            'nombre' => $item['nombre'],
            'imagen' => $item['imagen_url'],
            'cantidad' => $item['cantidad'],
            'precio' => $precio_convertido,
            'subtotal' => $subtotal
        ];
    }
    
    $expiracion = strtotime($carrito['fecha_expiracion']);
    $horas_restantes = round(($expiracion - time()) / 3600, 1);
    
    $moneda_simbolo = getSimboloPorMoneda($moneda_carrito);
    $moneda_codigo = $moneda_carrito;
    
    echo json_encode([
        'success' => true,
        'tiene_carrito' => true,
        'carrito_id' => $carrito['id'],
        'items' => $items,
        'total' => $total,
        'horas_restantes' => $horas_restantes,
        'moneda_simbolo' => $moneda_simbolo,
        'moneda_codigo' => $moneda_codigo
    ]);
    exit;
}

// ============================================
// CONTINUAR COMPRA (RENOVAR)
// ============================================
if ($accion === 'continuar_compra') {
    $carrito_id = intval($_POST['carrito_id'] ?? 0);
    
    if ($carrito_id) {
        $horas = getTiempoExpiracion($conn);
        $nueva_expiracion = date('Y-m-d H:i:s', strtotime("+$horas hours"));
        
        $stmt = $conn->prepare("UPDATE carritos SET fecha_expiracion = ? WHERE id = ? AND cliente_id = ?");
        $stmt->bind_param("sii", $nueva_expiracion, $carrito_id, $cliente_id);
        $stmt->execute();
        
        echo json_encode(['success' => true, 'mensaje' => 'Carrito renovado']);
        exit;
    }
    echo json_encode(['success' => false, 'mensaje' => 'Error al renovar']);
    exit;
}

// ============================================
// NUEVA COMPRA (CANCELA ANTERIOR)
// ============================================
if ($accion === 'nueva_compra') {
    $carrito_anterior = iniciarCarrito($conn, $cliente_id);
    if ($carrito_anterior) {
        cancelarCarrito($conn, $carrito_anterior['id'], 'cancelado_cliente');
    }
    
    echo json_encode(['success' => true, 'mensaje' => 'Carrito cancelado. Puedes empezar una nueva compra.']);
    exit;
}

// ============================================
// AGREGAR COMBO AL CARRITO
// ============================================
if ($accion === 'agregar_combo') {
    $combo_id = intval($_POST['combo_id'] ?? $_GET['combo_id'] ?? 0);
    $cantidad = intval($_POST['cantidad'] ?? $_GET['cantidad'] ?? 1);
    
    if ($combo_id <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'Combo inválido']);
        exit;
    }
    
    // Registrar evento de agregar combo al carrito
    if (function_exists('registrarEvento')) {
        registrarEvento($conn, 'agregar_carrito', $combo_id);
    }
    
    $stmt = $conn->prepare("SELECT c.*, c.stock_combo, c.proveedor_id FROM combos c WHERE c.id = ? AND c.activo = 1");
    $stmt->bind_param("i", $combo_id);
    $stmt->execute();
    $combo = $stmt->get_result()->fetch_assoc();
    
    if (!$combo) {
        echo json_encode(['success' => false, 'mensaje' => 'Combo no encontrado']);
        exit;
    }
    
    if ($combo['stock_combo'] < $cantidad) {
        echo json_encode(['success' => false, 'mensaje' => 'Stock insuficiente de combos']);
        exit;
    }
    
    // Verificar stock de productos
    $stmt_prod = $conn->prepare("SELECT cp.producto_id, cp.cantidad, p.cantidad as stock FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = ?");
    $stmt_prod->bind_param("i", $combo_id);
    $stmt_prod->execute();
    $productos_combo = $stmt_prod->get_result();
    
    $stock_insuficiente = [];
    while ($prod = $productos_combo->fetch_assoc()) {
        $necesario = $prod['cantidad'] * $cantidad;
        if ($prod['stock'] < $necesario) {
            $stock_insuficiente[] = $prod['nombre'] . " (requiere $necesario)";
        }
    }
    
    if (!empty($stock_insuficiente)) {
        echo json_encode(['success' => false, 'mensaje' => 'Stock insuficiente: ' . implode(', ', $stock_insuficiente)]);
        exit;
    }
    
        $carrito = obtenerOCrearCarrito($conn, $cliente_id);
    if (!$carrito) {
        echo json_encode(['success' => false, 'requiere_registro' => true, 'mensaje' => 'Debes registrarte']);
        exit;
    }
    
    $carrito_id = is_array($carrito) ? $carrito['id'] : $carrito;

    // 🔹 VALIDACIÓN DE PROVEEDOR PARA COMBO
    // 🔥 Validar que el proveedor del combo existe y está activo
    $stmt_prov_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_prov_check->bind_param("i", $combo['proveedor_id']);
    $stmt_prov_check->execute();
    if ($stmt_prov_check->get_result()->num_rows === 0) {
        echo json_encode(['success' => false, 'mensaje' => 'La tienda del combo no está disponible']);
        exit;
    }
    $stmt_prov_check->close();
    
    $proveedor_actual = obtenerProveedorCarrito($conn, $carrito_id);
    
    if ($proveedor_actual === null) {
        // Carrito vacío → asignar proveedor Y moneda
        $moneda_carrito = getMonedaParaProveedor($conn, $combo['proveedor_id'], $cliente);
        $stmt_upd = $conn->prepare("UPDATE carritos SET proveedor_id = ?, moneda = ? WHERE id = ?");
        $stmt_upd->bind_param("isi", $combo['proveedor_id'], $moneda_carrito, $carrito_id);
        $stmt_upd->execute();
        $stmt_upd->close();
        $proveedor_actual = $combo['proveedor_id'];
    } elseif ($proveedor_actual != $combo['proveedor_id']) {
        // Conflicto de tiendas
        $stmt_tienda = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
        $stmt_tienda->bind_param("i", $proveedor_actual);
        $stmt_tienda->execute();
        $tienda_actual = $stmt_tienda->get_result()->fetch_assoc();
        
        echo json_encode([
            'success' => false,
            'error' => 'cambio_tienda',
            'proveedor_actual_id' => $proveedor_actual,
            'proveedor_actual_nombre' => $tienda_actual ? $tienda_actual['nombre_tienda'] : 'Tienda actual',
            'proveedor_slug' => $tienda_actual ? $tienda_actual['slug'] : '',
            'combo_id' => $combo_id,
            'cantidad' => $cantidad,
            'mensaje' => 'Ya tienes productos de otra tienda en tu carrito.'
        ]);
        exit;
    }
    
       // 🔹 OBTENER MONEDA DEL CARRITO
    $stmt_mon = $conn->prepare("SELECT moneda FROM carritos WHERE id = ?");
    $stmt_mon->bind_param("i", $carrito_id);
    $stmt_mon->execute();
    $moneda_carrito = $stmt_mon->get_result()->fetch_assoc()['moneda'] ?? null;
    $stmt_mon->close();
    
    if (empty($moneda_carrito)) {
        $moneda_carrito = getMonedaParaProveedor($conn, $combo['proveedor_id'], $cliente);
        $stmt_upd = $conn->prepare("UPDATE carritos SET moneda = ? WHERE id = ?");
        $stmt_upd->bind_param("si", $moneda_carrito, $carrito_id);
        $stmt_upd->execute();
        $stmt_upd->close();
    }
    
    // 🔹 CALCULAR CONVERSIÓN
    $tasa = getTasaProveedor($conn, $combo['proveedor_id'], $moneda_carrito);
    $precio_total_convertido = floatval($combo['precio_final']);
    if ($moneda_carrito !== 'USD' && $tasa > 0) {
        $precio_total_convertido = floatval($combo['precio_final']) * $tasa;
    }
    
    $stmt_check = $conn->prepare("SELECT id, cantidad FROM carrito_combos WHERE carrito_id = ? AND combo_id = ?");
    $stmt_check->bind_param("ii", $carrito_id, $combo_id);
    $stmt_check->execute();
    $existente = $stmt_check->get_result()->fetch_assoc();
    
        $conn->begin_transaction();
    try {
        if ($existente) {
            $nueva_cantidad = $existente['cantidad'] + $cantidad;
            $diferencia = $cantidad;
            $nuevo_precio_total = floatval($combo['precio_final']) * $nueva_cantidad;
            $nuevo_precio_convertido = $precio_total_convertido * $nueva_cantidad;
            $stmt_update = $conn->prepare("UPDATE carrito_combos SET cantidad = ?, precio_total = ?, precio_convertido = ?, tasa_aplicada = ? WHERE id = ?");
            $stmt_update->bind_param("idddi", $nueva_cantidad, $nuevo_precio_total, $nuevo_precio_convertido, $tasa, $existente['id']);
            $stmt_update->execute();
            $stmt_update->close();
        } else {
            $diferencia = $cantidad;
            $precio_total = floatval($combo['precio_final']) * $cantidad;
            $precio_total_convertido = $precio_total_convertido * $cantidad;
            $stmt_insert = $conn->prepare("INSERT INTO carrito_combos (carrito_id, combo_id, cantidad, precio_total, moneda, precio_convertido, tasa_aplicada) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt_insert->bind_param("iiidsdd", $carrito_id, $combo_id, $cantidad, $precio_total, $moneda_carrito, $precio_total_convertido, $tasa);
            $stmt_insert->execute();
            $stmt_insert->close();
        }

        // ===== DESCONTAR STOCK DEL COMBO =====
        $stmt_stock_combo = $conn->prepare("UPDATE combos SET stock_combo = GREATEST(0, stock_combo - ?) WHERE id = ?");
        $stmt_stock_combo->bind_param("ii", $diferencia, $combo_id);
        $stmt_stock_combo->execute();
        $stmt_stock_combo->close();

        // ===== DESCONTAR STOCK DE PRODUCTOS + LIBERAR RESERVA =====
        $productos_combo->data_seek(0);
        $stmt_stock_prod = $conn->prepare("
            UPDATE productos 
            SET cantidad = GREATEST(0, cantidad - ?),
                reservado_por_combos = GREATEST(0, reservado_por_combos - ?),
                fecha_actualizacion_reserva = NOW(),
                en_combo = CASE WHEN (reservado_por_combos - ?) > 0 THEN 1 ELSE 0 END,
                fecha_agotado = CASE WHEN (cantidad - ?) <= 0 THEN NOW() ELSE fecha_agotado END
            WHERE id = ?
        ");
        while ($prod = $productos_combo->fetch_assoc()) {
            $stock_a_descontar = intval($prod['cantidad']) * $diferencia;
            $reserva_a_liberar = intval($prod['cantidad']) * $diferencia;
            $stmt_stock_prod->bind_param("iiiii", $stock_a_descontar, $reserva_a_liberar, $reserva_a_liberar, $stock_a_descontar, $prod['producto_id']);
            $stmt_stock_prod->execute();
        }
        $stmt_stock_prod->close();

        $conn->commit();
        echo json_encode(['success' => true, 'mensaje' => 'Combo agregado al carrito']);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[carrito_ajax agregar_combo] ' . $e->getMessage());
        echo json_encode(['success' => false, 'mensaje' => 'Error al agregar el combo']);
    }
    exit;
}

// ============================================
// AGREGAR PRODUCTO
// ============================================
if ($accion === 'agregar') {
    $producto_id = intval($_POST['producto_id'] ?? $_GET['producto_id'] ?? 0);
    $cantidad = intval($_POST['cantidad'] ?? $_GET['cantidad'] ?? 1);
    
    if ($producto_id <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto inválido']);
        exit;
    }
    
        // Registrar evento de agregar al carrito
    if (function_exists('registrarEvento')) {
        registrarEvento($conn, 'agregar_carrito', $producto_id);
    }
    
    $stmt = $conn->prepare("SELECT cantidad, precio, proveedor_id FROM productos WHERE id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();
    
    if (!$producto) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto no encontrado']);
        exit;
    }
    
    if ($producto['cantidad'] < $cantidad) {
        echo json_encode(['success' => false, 'mensaje' => "Stock insuficiente. Solo hay {$producto['cantidad']} unidades."]);
        exit;
    }
    
        $carrito = obtenerOCrearCarrito($conn, $cliente_id);
    if (!$carrito) {
        echo json_encode(['success' => false, 'requiere_registro' => true, 'mensaje' => 'Debes registrarte']);
        exit;
    }
    
    $carrito_id = is_array($carrito) ? $carrito['id'] : $carrito;

    // 🔹 VALIDACIÓN DE PROVEEDOR
    $proveedor_actual = obtenerProveedorCarrito($conn, $carrito_id);
    
    if ($proveedor_actual === null) {
        // Carrito vacío → asignar proveedor Y moneda
        $moneda_carrito = getMonedaParaProveedor($conn, $producto['proveedor_id'], $cliente);
        $stmt_upd = $conn->prepare("UPDATE carritos SET proveedor_id = ?, moneda = ? WHERE id = ?");
        $stmt_upd->bind_param("isi", $producto['proveedor_id'], $moneda_carrito, $carrito_id);
        $stmt_upd->execute();
        $stmt_upd->close();
        $proveedor_actual = $producto['proveedor_id'];
    } elseif ($proveedor_actual != $producto['proveedor_id']) {
        // Conflicto de tiendas
        $stmt_tienda = $conn->prepare("SELECT nombre_tienda, slug FROM proveedores WHERE id = ?");
        $stmt_tienda->bind_param("i", $proveedor_actual);
        $stmt_tienda->execute();
        $tienda_actual = $stmt_tienda->get_result()->fetch_assoc();
        
        echo json_encode([
            'success' => false,
            'error' => 'cambio_tienda',
            'proveedor_actual_id' => $proveedor_actual,
            'proveedor_actual_nombre' => $tienda_actual ? $tienda_actual['nombre_tienda'] : 'Tienda actual',
            'proveedor_slug' => $tienda_actual ? $tienda_actual['slug'] : '',
            'producto_id' => $producto_id,
            'cantidad' => $cantidad,
            'mensaje' => 'Ya tienes productos de otra tienda en tu carrito.'
        ]);
        exit;
    }
    
       // 🔹 OBTENER MONEDA DEL CARRITO
    // Si el carrito ya tiene moneda guardada, respetarla
    // Si no, calcularla con getMonedaParaProveedor
    $stmt_mon = $conn->prepare("SELECT moneda FROM carritos WHERE id = ?");
    $stmt_mon->bind_param("i", $carrito_id);
    $stmt_mon->execute();
    $moneda_carrito = $stmt_mon->get_result()->fetch_assoc()['moneda'] ?? null;
    $stmt_mon->close();
    
    // Si el carrito NO tiene moneda (vacío o recién creado), calcularla
    if (empty($moneda_carrito)) {
        $moneda_carrito = getMonedaParaProveedor($conn, $producto['proveedor_id'], $cliente);
        $stmt_upd = $conn->prepare("UPDATE carritos SET moneda = ? WHERE id = ?");
        $stmt_upd->bind_param("si", $moneda_carrito, $carrito_id);
        $stmt_upd->execute();
        $stmt_upd->close();
    }
    
    // 🔹 CALCULAR CONVERSIÓN
    $tasa = getTasaProveedor($conn, $producto['proveedor_id'], $moneda_carrito);
    $precio_convertido = floatval($producto['precio']);
    if ($moneda_carrito !== 'USD' && $tasa > 0) {
        $precio_convertido = floatval($producto['precio']) * $tasa;
    }
    
        $conn->begin_transaction();
    try {
        // ===== ACTUALIZAR STOCK DEL PRODUCTO =====
        $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad - ? WHERE id = ?");
        if (!$stmt) throw new Exception("prepare stock: " . $conn->error);
        $stmt->bind_param("ii", $cantidad, $producto_id);
        $stmt->execute();
        $stmt->close();

        // ===== MARCAR AGOTADO SI LLEGA A 0 =====
        $stmt = $conn->prepare("
            UPDATE productos 
            SET fecha_agotado = CASE WHEN cantidad <= 0 THEN NOW() ELSE fecha_agotado END,
                activo = CASE WHEN cantidad <= 0 AND fecha_agotado IS NOT NULL AND TIMESTAMPDIFF(HOUR, fecha_agotado, NOW()) > 48 THEN 0 ELSE activo END
            WHERE id = ?
        ");
        if (!$stmt) throw new Exception("prepare agotado: " . $conn->error);
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stmt->close();

        // ===== INSERTAR O ACTUALIZAR EN CARRITO =====
        $stmt = $conn->prepare("SELECT id, cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
        if (!$stmt) throw new Exception("prepare check: " . $conn->error);
        $stmt->bind_param("ii", $carrito_id, $producto_id);
        $stmt->execute();
        $existente = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($existente) {
            $nueva_cantidad = $existente['cantidad'] + $cantidad;
            $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ?, precio_convertido = ?, tasa_aplicada = ? WHERE id = ?");
            if (!$stmt) throw new Exception("prepare update: " . $conn->error);
            $stmt->bind_param("iddi", $nueva_cantidad, $precio_convertido, $tasa, $existente['id']);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $conn->prepare("INSERT INTO carrito_productos (carrito_id, producto_id, cantidad, precio_unitario, moneda, precio_convertido, tasa_aplicada) VALUES (?, ?, ?, ?, ?, ?, ?)");
            if (!$stmt) throw new Exception("prepare insert: " . $conn->error);
            $stmt->bind_param("iiidsdd", $carrito_id, $producto_id, $cantidad, $producto['precio'], $moneda_carrito, $precio_convertido, $tasa);
            $stmt->execute();
            $stmt->close();
        }

        $conn->commit();
        echo json_encode(['success' => true, 'mensaje' => 'Producto agregado']);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[carrito_ajax agregar] ' . $e->getMessage());
        echo json_encode(['success' => false, 'mensaje' => 'Error al agregar el producto']);
    }
    exit;
  }

// ============================================
// OBTENER CARRITO
// ============================================
if ($accion === 'obtener_carrito') {
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => true, 'vacio' => true]);
        exit;
    }
    
        $items = [];
    $total_convertido = 0;
    
    // Moneda del carrito
    $moneda_carrito = $carrito['moneda'] ?? null;
    $proveedor_carrito = $carrito['proveedor_id'] ?? 0;
    
    // Si el carrito no tiene moneda pero sí proveedor, calcularla
    if (empty($moneda_carrito) && $proveedor_carrito > 0) {
        $moneda_carrito = getMonedaParaProveedor($conn, $proveedor_carrito, $cliente);
        $stmt_upd = $conn->prepare("UPDATE carritos SET moneda = ? WHERE id = ?");
        $stmt_upd->bind_param("si", $moneda_carrito, $carrito['id']);
        $stmt_upd->execute();
        $stmt_upd->close();
    }
    
    // Fallback final
    if (empty($moneda_carrito)) {
        $moneda_carrito = 'USD';
    }
    
    // 🔹 PRODUCTOS
    $stmt = $conn->prepare("SELECT cp.*, p.nombre, p.imagen_url FROM carrito_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.carrito_id = ? AND (cp.combo_id IS NULL OR cp.es_combo = 0)");
    $stmt->bind_param("i", $carrito['id']);
    $stmt->execute();
    $productos = $stmt->get_result();
    
    while ($item = $productos->fetch_assoc()) {
        // Recalcular conversión con la tasa ACTUAL
        $tasa_actual = getTasaProveedor($conn, $proveedor_carrito, $moneda_carrito);
        $precio_convertido = floatval($item['precio_unitario']);
        if ($moneda_carrito !== 'USD' && $tasa_actual > 0) {
            $precio_convertido = floatval($item['precio_unitario']) * $tasa_actual;
        }
        $subtotal_convertido = $precio_convertido * $item['cantidad'];
        $total_convertido += $subtotal_convertido;
        
        // Actualizar en BD si cambió la tasa
        if ($tasa_actual != $item['tasa_aplicada'] || $precio_convertido != $item['precio_convertido']) {
            $stmt_upd = $conn->prepare("UPDATE carrito_productos SET precio_convertido = ?, tasa_aplicada = ? WHERE id = ?");
            $stmt_upd->bind_param("ddi", $precio_convertido, $tasa_actual, $item['id']);
            $stmt_upd->execute();
            $stmt_upd->close();
        }
        
        $items[] = [
            'tipo' => 'producto',
            'id' => $item['producto_id'],
            'carrito_producto_id' => $item['id'],
            'nombre' => $item['nombre'],
            'imagen' => $item['imagen_url'],
            'cantidad' => $item['cantidad'],
            'precio' => $precio_convertido,
            'precio_unitario' => $precio_convertido,
            'subtotal' => $subtotal_convertido
        ];
    }
    
    // 🔹 COMBOS
    $stmt = $conn->prepare("SELECT cc.*, c.nombre, c.imagen_url FROM carrito_combos cc JOIN combos c ON cc.combo_id = c.id WHERE cc.carrito_id = ?");
    $stmt->bind_param("i", $carrito['id']);
    $stmt->execute();
    $combos = $stmt->get_result();
    
    while ($combo = $combos->fetch_assoc()) {
        // Recalcular conversión con la tasa ACTUAL
        $tasa_actual = getTasaProveedor($conn, $proveedor_carrito, $moneda_carrito);
        $precio_total_convertido = floatval($combo['precio_total']);
        if ($moneda_carrito !== 'USD' && $tasa_actual > 0) {
            $precio_total_convertido = floatval($combo['precio_total']) * $tasa_actual;
        }
        $total_convertido += $precio_total_convertido;
        
        // Actualizar en BD si cambió la tasa
        if ($tasa_actual != $combo['tasa_aplicada'] || $precio_total_convertido != $combo['precio_convertido']) {
            $stmt_upd = $conn->prepare("UPDATE carrito_combos SET precio_convertido = ?, tasa_aplicada = ? WHERE id = ?");
            $stmt_upd->bind_param("ddi", $precio_total_convertido, $tasa_actual, $combo['id']);
            $stmt_upd->execute();
            $stmt_upd->close();
        }
        
        $cantidad_segura = max(1, intval($combo['cantidad']));
$items[] = [
    'tipo' => 'combo',
    'id' => $combo['combo_id'],
    'carrito_combo_id' => $combo['id'],
    'nombre' => $combo['nombre'],
    'imagen' => $combo['imagen_url'],
    'cantidad' => $combo['cantidad'],
    'precio_unitario' => $precio_total_convertido / $cantidad_segura,
    'subtotal' => $precio_total_convertido
];
    }
    
    $expiracion = strtotime($carrito['fecha_expiracion']);
    $horas_restantes = round(($expiracion - time()) / 3600, 1);
    
    $moneda_simbolo = getSimboloPorMoneda($moneda_carrito);
    $moneda_codigo = $moneda_carrito;
    
    echo json_encode([
        'success' => true,
        'vacio' => false,
        'items' => $items,
        'total' => $total_convertido,
        'horas_restantes' => $horas_restantes,
        'moneda_simbolo' => $moneda_simbolo,
        'moneda_codigo' => $moneda_codigo
    ]);
    exit;
}

// ============================================
// ACTUALIZAR CANTIDAD (PRODUCTO O COMBO)
// ============================================
if ($accion === 'actualizar_cantidad') {
    $tipo = $_POST['tipo'] ?? $_GET['tipo'] ?? 'producto';
    $id = intval($_POST['id'] ?? $_GET['id'] ?? 0);
    $nueva_cantidad = intval($_POST['cantidad'] ?? $_GET['cantidad'] ?? 0);
    
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => false, 'mensaje' => 'No hay carrito']);
        exit;
    }
    
        if ($tipo === 'combo') {
        $stmt = $conn->prepare("SELECT combo_id, cantidad, precio_total FROM carrito_combos WHERE id = ? AND carrito_id = ?");
        $stmt->bind_param("ii", $id, $carrito['id']);
        $stmt->execute();
        $combo = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$combo) {
            echo json_encode(['success' => false, 'mensaje' => 'Combo no encontrado']);
            exit;
        }
        
        $diferencia = $nueva_cantidad - $combo['cantidad'];
        
        if ($diferencia == 0) {
            echo json_encode(['success' => true]);
            exit;
        }
        
        // Validar stock si se aumenta
        if ($diferencia > 0) {
            $stmt_stock_combo = $conn->prepare("SELECT stock_combo FROM combos WHERE id = ?");
            $stmt_stock_combo->bind_param("i", $combo['combo_id']);
            $stmt_stock_combo->execute();
            $stock_combo_actual = intval($stmt_stock_combo->get_result()->fetch_assoc()['stock_combo'] ?? 0);
            $stmt_stock_combo->close();
            
            if ($stock_combo_actual < $diferencia) {
                echo json_encode(['success' => false, 'mensaje' => 'Stock insuficiente de combos']);
                exit;
            }
            
            $stmt_prod = $conn->prepare("SELECT cp.producto_id, cp.cantidad, p.cantidad as stock FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = ?");
            $stmt_prod->bind_param("i", $combo['combo_id']);
            $stmt_prod->execute();
            $productos_combo = $stmt_prod->get_result();
            
            $stock_insuficiente = [];
            while ($prod = $productos_combo->fetch_assoc()) {
                $necesario = intval($prod['cantidad']) * $diferencia;
                if ($prod['stock'] < $necesario) {
                    $stock_insuficiente[] = "Producto ID {$prod['producto_id']}";
                }
            }
            $stmt_prod->close();
            
            if (!empty($stock_insuficiente)) {
                echo json_encode(['success' => false, 'mensaje' => 'Stock insuficiente de productos']);
                exit;
            }
        }
        
        $conn->begin_transaction();
        try {
            // ===== AJUSTAR STOCK DEL COMBO =====
            $stmt_stock_combo = $conn->prepare("UPDATE combos SET stock_combo = GREATEST(0, stock_combo - ?) WHERE id = ?");
            $stmt_stock_combo->bind_param("ii", $diferencia, $combo['combo_id']);
            $stmt_stock_combo->execute();
            $stmt_stock_combo->close();

            // ===== AJUSTAR STOCK DE PRODUCTOS + RESERVA =====
            $stmt_prod = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
            $stmt_prod->bind_param("i", $combo['combo_id']);
            $stmt_prod->execute();
            $productos_combo = $stmt_prod->get_result();
            $stmt_prod->close();

            $stmt_stock_prod = $conn->prepare("
                UPDATE productos 
                SET cantidad = GREATEST(0, cantidad - ?),
                    reservado_por_combos = GREATEST(0, reservado_por_combos - ?),
                    fecha_actualizacion_reserva = NOW(),
                    en_combo = CASE WHEN (reservado_por_combos - ?) > 0 THEN 1 ELSE 0 END,
                    fecha_agotado = CASE WHEN (cantidad - ?) <= 0 THEN NOW() ELSE fecha_agotado END
                WHERE id = ?
            ");
            while ($prod = $productos_combo->fetch_assoc()) {
                $stock_a_ajustar = intval($prod['cantidad']) * $diferencia;
                $stmt_stock_prod->bind_param("iiiii", $stock_a_ajustar, $stock_a_ajustar, $stock_a_ajustar, $stock_a_ajustar, $prod['producto_id']);
                $stmt_stock_prod->execute();
            }
            $stmt_stock_prod->close();

            // ===== RECALCULAR PRECIO =====
            $moneda_carrito = $carrito['moneda'] ?? 'USD';
            $proveedor_carrito = $carrito['proveedor_id'] ?? 0;
            $tasa_actual = getTasaProveedor($conn, $proveedor_carrito, $moneda_carrito);
            
            $precio_unitario_combo = ($combo['cantidad'] > 0) ? ($combo['precio_total'] / $combo['cantidad']) : 0;
            $nuevo_precio_total = $precio_unitario_combo * $nueva_cantidad;
            $nuevo_precio_convertido = $nuevo_precio_total;
            if ($moneda_carrito !== 'USD' && $tasa_actual > 0) {
                $nuevo_precio_convertido = $nuevo_precio_total * $tasa_actual;
            }
            
            $stmt_update = $conn->prepare("UPDATE carrito_combos SET cantidad = ?, precio_total = ?, precio_convertido = ?, tasa_aplicada = ? WHERE id = ?");
            $stmt_update->bind_param("idddi", $nueva_cantidad, $nuevo_precio_total, $nuevo_precio_convertido, $tasa_actual, $id);
            $stmt_update->execute();
            $stmt_update->close();

            $conn->commit();
            echo json_encode(['success' => true]);
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[carrito_ajax actualizar_cantidad combo] ' . $e->getMessage());
            echo json_encode(['success' => false, 'mensaje' => 'Error al actualizar la cantidad']);
        }
        exit;
    }
    
     // Producto individual
    $stmt = $conn->prepare("SELECT cantidad, combo_id, es_combo, producto_id, id FROM carrito_productos WHERE carrito_id = ? AND id = ?");
    if (!$stmt) throw new Exception("prepare check: " . $conn->error);
    $stmt->bind_param("ii", $carrito['id'], $id);
    $stmt->execute();
    $actual = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$actual) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto no encontrado en el carrito']);
        exit;
    }

    if ($actual['combo_id'] > 0 && $actual['es_combo'] == 1) {
        echo json_encode(['success' => false, 'mensaje' => 'Para modificar la cantidad, edita el combo completo']);
        exit;
    }

    $diferencia = $nueva_cantidad - $actual['cantidad'];
    $producto_id = $actual['producto_id'];
    $carrito_producto_id = $actual['id'];

    if ($diferencia == 0) {
        echo json_encode(['success' => true]);
        exit;
    }

    // Validar stock si se aumenta
    if ($diferencia > 0) {
        $stmt = $conn->prepare("SELECT cantidad FROM productos WHERE id = ?");
        if (!$stmt) throw new Exception("prepare stock: " . $conn->error);
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stock = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($stock['cantidad'] < $diferencia) {
            echo json_encode(['success' => false, 'mensaje' => 'Stock insuficiente']);
            exit;
        }
    }

    $conn->begin_transaction();
    try {
        // ===== AJUSTAR STOCK DEL PRODUCTO =====
        $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad - ? WHERE id = ?");
        if (!$stmt) throw new Exception("prepare stock update: " . $conn->error);
        $stmt->bind_param("ii", $diferencia, $producto_id);
        $stmt->execute();
        $stmt->close();

        // ===== ACTUALIZAR / ELIMINAR EN CARRITO =====
        if ($nueva_cantidad == 0) {
            $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE id = ?");
            if (!$stmt) throw new Exception("prepare delete: " . $conn->error);
            $stmt->bind_param("i", $carrito_producto_id);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE id = ?");
            if (!$stmt) throw new Exception("prepare update: " . $conn->error);
            $stmt->bind_param("ii", $nueva_cantidad, $carrito_producto_id);
            $stmt->execute();
            $stmt->close();
        }

        $conn->commit();
        echo json_encode(['success' => true]);
        } catch (Throwable $e) {
        $conn->rollback();
        error_log('[carrito_ajax actualizar_cantidad] ' . $e->getMessage());
        echo json_encode(['success' => false, 'mensaje' => 'Error al actualizar la cantidad']);
    }
    exit;
}

// ============================================
// ELIMINAR PRODUCTO O COMBO
// ============================================
if ($accion === 'eliminar') {
    $tipo = $_POST['tipo'] ?? $_GET['tipo'] ?? 'producto';
    $id = intval($_POST['id'] ?? $_GET['id'] ?? 0);
    
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => false, 'mensaje' => 'No hay carrito']);
        exit;
    }
    
        if ($tipo === 'combo') {
        $stmt = $conn->prepare("SELECT combo_id, cantidad FROM carrito_combos WHERE id = ? AND carrito_id = ?");
        $stmt->bind_param("ii", $id, $carrito['id']);
        $stmt->execute();
        $combo = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($combo) {
            $conn->begin_transaction();
            try {
                // ===== DEVOLVER STOCK DEL COMBO =====
                $stmt_stock_combo = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                $stmt_stock_combo->bind_param("ii", $combo['cantidad'], $combo['combo_id']);
                $stmt_stock_combo->execute();
                $stmt_stock_combo->close();

                // ===== DEVOLVER STOCK DE PRODUCTOS + VOLVER A RESERVAR =====
                $stmt_prod = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                $stmt_prod->bind_param("i", $combo['combo_id']);
                $stmt_prod->execute();
                $productos_combo = $stmt_prod->get_result();
                $stmt_prod->close();

                $stmt_stock_prod = $conn->prepare("
                    UPDATE productos 
                    SET cantidad = cantidad + ?,
                        reservado_por_combos = reservado_por_combos + ?,
                        fecha_actualizacion_reserva = NOW(),
                        en_combo = 1,
                        fecha_agotado = NULL
                    WHERE id = ?
                ");
                while ($prod = $productos_combo->fetch_assoc()) {
                    $stock_a_devolver = intval($prod['cantidad']) * intval($combo['cantidad']);
                    $stmt_stock_prod->bind_param("iii", $stock_a_devolver, $stock_a_devolver, $prod['producto_id']);
                    $stmt_stock_prod->execute();
                }
                $stmt_stock_prod->close();

                // ===== ELIMINAR DEL CARRITO =====
                $stmt_del = $conn->prepare("DELETE FROM carrito_combos WHERE id = ?");
                $stmt_del->bind_param("i", $id);
                $stmt_del->execute();
                $stmt_del->close();

                $conn->commit();
                echo json_encode(['success' => true]);
            } catch (Throwable $e) {
                $conn->rollback();
                error_log('[carrito_ajax eliminar combo] ' . $e->getMessage());
                echo json_encode(['success' => false, 'mensaje' => 'Error al eliminar el combo']);
            }
            exit;
        }
       } else {
        $stmt = $conn->prepare("SELECT cantidad, producto_id, combo_id, es_combo FROM carrito_productos WHERE carrito_id = ? AND id = ?");
        if (!$stmt) throw new Exception("prepare check: " . $conn->error);
        $stmt->bind_param("ii", $carrito['id'], $id);
        $stmt->execute();
        $item = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($item) {
            if ($item['combo_id'] > 0 && $item['es_combo'] == 1) {
                echo json_encode(['success' => false, 'mensaje' => 'Elimina el combo completo desde el carrito']);
                exit;
            }
            
            $conn->begin_transaction();
            try {
                // ===== DEVOLVER STOCK AL PRODUCTO =====
                $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                if (!$stmt) throw new Exception("prepare stock: " . $conn->error);
                $stmt->bind_param("ii", $item['cantidad'], $item['producto_id']);
                $stmt->execute();
                $stmt->close();

                // ===== LIMPIAR fecha_agotado SI HAY STOCK =====
                $stmt = $conn->prepare("UPDATE productos SET fecha_agotado = NULL WHERE id = ? AND cantidad > 0");
                if (!$stmt) throw new Exception("prepare fecha: " . $conn->error);
                $stmt->bind_param("i", $item['producto_id']);
                $stmt->execute();
                $stmt->close();

                // ===== ELIMINAR DEL CARRITO =====
                $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE id = ?");
                if (!$stmt) throw new Exception("prepare delete: " . $conn->error);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                echo json_encode(['success' => true]);
            } catch (Throwable $e) {
                $conn->rollback();
                error_log('[carrito_ajax eliminar] ' . $e->getMessage());
                echo json_encode(['success' => false, 'mensaje' => 'Error al eliminar el producto']);
            }
            exit;
        }
    }
    
    echo json_encode(['success' => false, 'mensaje' => 'Item no encontrado']);
    exit;
}

// ============================================
// COMPRAR
// ============================================
if ($accion === 'comprar') {
    $carrito = iniciarCarrito($conn, $cliente_id);
    
    if (!$carrito) {
        echo json_encode(['success' => false, 'mensaje' => 'No hay carrito activo']);
        exit;
    }
    
    // Verificar productos individuales
    $check = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos WHERE carrito_id = ?");
    $check->bind_param("i", $carrito['id']);
    $check->execute();
    $total_productos = $check->get_result()->fetch_assoc()['total'];
    
    // Verificar combos
    $check_combo = $conn->prepare("SELECT COUNT(*) as total FROM carrito_combos WHERE carrito_id = ?");
    $check_combo->bind_param("i", $carrito['id']);
    $check_combo->execute();
    $total_combos = $check_combo->get_result()->fetch_assoc()['total'];
    
    if ($total_productos == 0 && $total_combos == 0) {
        echo json_encode(['success' => false, 'mensaje' => 'El carrito está vacío']);
        exit;
    }
    
    // Sumar productos individuales
    $stmt_subtotal = $conn->prepare("SELECT SUM(cantidad * precio_unitario) as total FROM carrito_productos WHERE carrito_id = ?");
    $stmt_subtotal->bind_param("i", $carrito['id']);
    $stmt_subtotal->execute();
    $subtotal = $stmt_subtotal->get_result()->fetch_assoc()['total'] ?? 0;
    
    // Sumar combos
    $stmt_combo = $conn->prepare("SELECT SUM(precio_total) as total FROM carrito_combos WHERE carrito_id = ?");
    $stmt_combo->bind_param("i", $carrito['id']);
    $stmt_combo->execute();
    $total_combos_precio = $stmt_combo->get_result()->fetch_assoc()['total'] ?? 0;
    
       $subtotal_usd = $subtotal + $total_combos_precio;
    
        // Moneda del carrito
    $moneda_carrito = $carrito['moneda'] ?? null;
    $proveedor_carrito = $carrito['proveedor_id'] ?? 0;
    
    if (empty($moneda_carrito) && $proveedor_carrito > 0) {
        $moneda_carrito = getMonedaParaProveedor($conn, $proveedor_carrito, $cliente);
    }
    if (empty($moneda_carrito)) {
        $moneda_carrito = 'USD';
    }
    
    $tasa_actual = getTasaProveedor($conn, $proveedor_carrito, $moneda_carrito);
    
    $subtotal_convertido = $subtotal_usd;
    if ($moneda_carrito !== 'USD' && $tasa_actual > 0) {
        $subtotal_convertido = $subtotal_usd * $tasa_actual;
    }
    
    $moneda_simbolo = getSimboloPorMoneda($moneda_carrito);
    $moneda_codigo = $moneda_carrito;
    
    echo json_encode([
        'success' => true,
        'mostrar_modal_entrega' => true,
        'subtotal' => (float)$subtotal_convertido,
        'subtotal_usd' => (float)$subtotal_usd,
        'moneda_simbolo' => $moneda_simbolo,
        'moneda_codigo' => $moneda_codigo
    ]);
    exit;
}

// ============================================
// VACIAR CARRITO
// ============================================
if ($accion === 'vaciar') {
    $carrito = iniciarCarrito($conn, $cliente_id);
    if ($carrito) {
        cancelarCarrito($conn, $carrito['id'], 'cancelado_cliente');
    }
    echo json_encode(['success' => true, 'mensaje' => 'Carrito cancelado']);
    exit;
}

// ============================================
// SINCRONIZAR POR EMAIL
// ============================================
if ($accion === 'sincronizar') {
    $email = trim($_POST['email'] ?? '');
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'mensaje' => 'Email no válido']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT id FROM clientes WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $cliente_email = $result->fetch_assoc();
        $stmt = $conn->prepare("UPDATE carritos SET cliente_id = ? WHERE cliente_id = ?");
        $stmt->bind_param("ii", $cliente_email['id'], $cliente_id);
        $stmt->execute();
        echo json_encode(['success' => true, 'mensaje' => 'Carrito sincronizado']);
    } else {
        $stmt = $conn->prepare("UPDATE clientes SET email = ? WHERE id = ?");
        $stmt->bind_param("si", $email, $cliente_id);
        $stmt->execute();
        echo json_encode(['success' => true, 'mensaje' => 'Email guardado']);
    }
    exit;
}

// ============================================
// INCREMENTAR VISITAS
// ============================================
if ($accion === 'incrementar_vistas') {
    $tipo = $_POST['tipo'] ?? $_GET['tipo'] ?? '';
    $id = intval($_POST['id'] ?? $_GET['id'] ?? 0);
    
    if ($tipo === 'producto' && $id > 0) {
        $conn->query("UPDATE productos SET vistas = vistas + 1 WHERE id = $id");
        echo json_encode(['success' => true, 'mensaje' => 'Visita registrada']);
        exit;
    } elseif ($tipo === 'combo' && $id > 0) {
        $conn->query("UPDATE combos SET vistas = vistas + 1 WHERE id = $id");
        echo json_encode(['success' => true, 'mensaje' => 'Visita registrada']);
        exit;
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Datos inválidos: tipo=' . $tipo . ', id=' . $id]);
        exit;
    }
}

// ============================================
// GUARDAR PRODUCTO PENDIENTE
// ============================================
if ($accion === 'guardar_producto_pendiente') {
    $producto_id = intval($_POST['producto_id'] ?? 0);
    $cantidad = intval($_POST['cantidad'] ?? 1);
    $es_combo = isset($_POST['combo']) && $_POST['combo'] == 'true';
    
    if ($producto_id > 0) {
        $_SESSION['producto_pendiente'] = [
            'id' => $producto_id,
            'cantidad' => $cantidad,
            'combo' => $es_combo
        ];
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Producto inválido']);
    }
    exit;
}

// ============================================
// OBTENER PRODUCTO PENDIENTE (para cuando se cancela el carrito)
// ============================================
if ($accion === 'obtener_producto_pendiente') {
    if (isset($_SESSION['producto_pendiente'])) {
        echo json_encode([
            'success' => true,
            'producto_pendiente' => $_SESSION['producto_pendiente']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'mensaje' => 'No hay producto pendiente'
        ]);
    }
    exit;
}

// ============================================
// ACCIÓN NO VÁLIDA
// ============================================
echo json_encode(['success' => false, 'mensaje' => 'Acción no válida: ' . $accion]);
exit;
?>
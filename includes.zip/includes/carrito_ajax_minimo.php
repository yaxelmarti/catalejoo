<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

echo json_encode([
    'success' => true,
    'message' => 'El script mínimo funciona',
    'timestamp' => time()
]);
exit;
?>
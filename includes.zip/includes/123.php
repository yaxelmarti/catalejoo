<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

echo "=== DEBUG MUNICIPIOS ===<br><br>";

echo "1. PHP funciona<br>";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
echo "2. Sesión iniciada<br>";

$ruta_conexion = __DIR__ . '/../conexion.php';
echo "3. Buscando conexión en: " . $ruta_conexion . "<br>";
if (file_exists($ruta_conexion)) {
    echo "   ✅ Archivo existe<br>";
    require_once $ruta_conexion;
    echo "4. Conexión incluida<br>";
} else {
    echo "   ❌ Archivo NO existe<br>";
    exit;
}

$ruta_utils = __DIR__ . '/proveedor_utils.php';
echo "5. Buscando proveedor_utils en: " . $ruta_utils . "<br>";
if (file_exists($ruta_utils)) {
    echo "   ✅ Archivo existe<br>";
    require_once $ruta_utils;
    echo "6. proveedor_utils incluido<br>";
} else {
    echo "   ❌ Archivo NO existe<br>";
    exit;
}

echo "7. Variables GET:<br>";
echo "   provincia_id: " . ($_GET['provincia_id'] ?? 'NO') . "<br>";
echo "   proveedor_id: " . ($_GET['proveedor_id'] ?? 'NO') . "<br>";

echo "8. Probando conexión a BD...<br>";
if (isset($conn)) {
    echo "   ✅ \$conn existe<br>";
    $test = $conn->query("SELECT 1");
    echo "   ✅ Consulta simple funciona<br>";
} else {
    echo "   ❌ \$conn NO existe<br>";
}

echo "9. Convirtiendo provincia_id a integer...<br>";
$provincia_id = isset($_GET['provincia_id']) ? intval($_GET['provincia_id']) : 0;
echo "   provincia_id convertido: " . $provincia_id . "<br>";
echo "   Tipo: " . gettype($provincia_id) . "<br>";

echo "10. Probando consulta preparada...<br>";

$sql = "SELECT id, nombre, activo FROM municipios WHERE provincia_id = ? AND activo = 1 ORDER BY nombre";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo "❌ Error en prepare: " . $conn->error . "<br>";
    exit;
}
echo "✅ Prepare OK<br>";

$stmt->bind_param("i", $provincia_id);
echo "✅ Bind OK<br>";

$stmt->execute();
echo "✅ Execute OK<br>";

$result = $stmt->get_result();
echo "✅ Get result OK<br>";

$municipios = $result->fetch_all(MYSQLI_ASSOC);
echo "✅ Municipios encontrados: " . count($municipios) . "<br>";

echo "<pre>";
print_r($municipios);
echo "</pre>";

echo "<br>=== PRUEBA DIRECTA SQL ===<br>";

$test1 = $conn->query("SELECT COUNT(*) as total FROM municipios");
$row1 = $test1->fetch_assoc();
echo "Total municipios en BD: " . $row1['total'] . "<br>";

$test2 = $conn->query("SELECT COUNT(*) as total FROM municipios WHERE provincia_id = 7");
$row2 = $test2->fetch_assoc();
echo "Municipios provincia 7: " . $row2['total'] . "<br>";

$test3 = $conn->query("SELECT COUNT(*) as total FROM municipios WHERE provincia_id = 7 AND activo = 1");
$row3 = $test3->fetch_assoc();
echo "Municipios provincia 7 activos: " . $row3['total'] . "<br>";

$test4 = $conn->query("SELECT id, nombre, activo FROM municipios WHERE provincia_id = 7");
echo "<br>Lista de municipios provincia 7:<br>";
while ($row = $test4->fetch_assoc()) {
    echo "- ID: " . $row['id'] . " | " . $row['nombre'] . " | activo: " . $row['activo'] . "<br>";
}
?>
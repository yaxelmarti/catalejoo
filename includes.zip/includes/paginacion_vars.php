<?php
// ============================================
// PAGINACIÓN - SOLO VARIABLES
// ============================================

// Conectar a la base de datos si no está ya conectada
if (!isset($conn) || !$conn) {
    require_once __DIR__ . '/../conexion.php';
}

// Por página: respetar si el llamador ya lo definió
if (!isset($por_pagina) || $por_pagina <= 0) {
    $por_pagina = 12; // fallback
    $result = $conn->query("SELECT valor FROM configuracion WHERE clave = 'productos_por_pagina'");
    if ($result) {
        $row = $result->fetch_assoc();
        if ($row && intval($row['valor']) > 0) {
            $por_pagina = intval($row['valor']);
        }
        $result->free();
    }
}

// Página actual (mínimo 1)
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// Offset
$offset = ($pagina_actual - 1) * $por_pagina;
<?php
session_start();
require_once '../conexion.php';
require_once 'email_config.php';

header('Content-Type: application/json');

$email = $_POST['email'] ?? '';

if (empty($email)) {
    echo json_encode(['success' => false, 'mensaje' => 'Email requerido']);
    exit;
}

$stmt = $conn->prepare("SELECT id, nombre FROM clientes WHERE email = ? AND activo = 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'mensaje' => 'No hay cuenta con este email']);
    exit;
}

$cliente = $result->fetch_assoc();

$token = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', strtotime('+15 minutes'));

$stmt = $conn->prepare("UPDATE clientes SET reset_token = ?, reset_expires = ? WHERE id = ?");
$stmt->bind_param("ssi", $token, $expires, $cliente['id']);
$stmt->execute();

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$domain = $_SERVER['HTTP_HOST'];
$link = $protocol . $domain . '/index_modales/editar_cliente.php?token=' . urlencode($token);

$asunto = "✏️ Editar tus datos - Catalejo";
$cuerpoHTML = "
<html>
<body style='font-family: Arial, sans-serif;'>
    <h2>✏️ Editar tus datos</h2>
    <p>Hola <strong>" . htmlspecialchars($cliente['nombre']) . "</strong>,</p>
    <p>Haz clic en el siguiente enlace para editar tus datos personales:</p>
    <p><a href='$link' style='background:#667eea; color:white; padding:12px 24px; text-decoration:none; border-radius:8px;'>✏️ Editar mis datos</a></p>
    <p>Este enlace expira en <strong>15 minutos</strong>.</p>
    <p>Si no solicitaste esto, ignora este mensaje.</p>
</body>
</html>";

$resultado = enviarCorreoBase($email, $asunto, $cuerpoHTML, '');

if ($resultado['success']) {
    echo json_encode(['success' => true, 'mensaje' => 'Enlace enviado a tu email']);
} else {
    echo json_encode(['success' => false, 'mensaje' => 'Error al enviar email']);
}
?>
<?php
// ============================================
// UTILIDADES PARA PROVEEDORES
// ============================================
// Este archivo centraliza toda la lógica de detección
// y verificación de proveedores para toda la plataforma
// ============================================

/**
 * Obtiene el proveedor_id del usuario actual
 * 
 * @param mysqli $conn Conexión a la base de datos
 * @param int $usuario_id ID del usuario
 * @param string $rol Nombre del rol
 * @return int ID del proveedor (0 si es rol de sistema)
 */
function obtenerProveedorId($conn, $usuario_id, $rol) {
    $usuario_id = intval($usuario_id);
    $rol = $rol ?? '';
    
    // Validación temprana: sin usuario o sin rol, no hay proveedor
    if ($usuario_id <= 0 || empty($rol)) {
        return 0;
    }
    
    // Solo los roles de tienda pueden tener proveedor asociado
    $roles_con_proveedor = ['Proveedor', 'Inventario', 'Vendedor', 'Empaquetador', 'Transportista'];
    
    if (!in_array($rol, $roles_con_proveedor, true)) {
        return 0;
    }
    
    // Buscar la asociación activa en usuario_proveedor
    $stmt = $conn->prepare("SELECT proveedor_id FROM usuario_proveedor WHERE usuario_id = ? AND activo = 1 LIMIT 1");
    
    if (!$stmt) {
        error_log('[proveedor_utils] Error prepare obtenerProveedorId: ' . $conn->error);
        return 0;
    }
    
    $stmt->bind_param("i", $usuario_id);
    
    if (!$stmt->execute()) {
        error_log('[proveedor_utils] Error execute obtenerProveedorId: ' . $stmt->error);
        $stmt->close();
        return 0;
    }
    
    $result = $stmt->get_result();
    $proveedor_id = 0;
    
    if ($row = $result->fetch_assoc()) {
        $proveedor_id = (int)$row['proveedor_id'];
    }
    
    $stmt->close();
    
    return $proveedor_id;
}

/**
 * Verifica si un rol es de proveedor (tienda)
 * 
 * @param string $rol Nombre del rol
 * @return bool True si es rol de proveedor
 */
function esRolProveedor($rol) {
    $roles_con_proveedor = ['Proveedor', 'Inventario', 'Vendedor', 'Empaquetador', 'Transportista'];
    return in_array($rol ?? '', $roles_con_proveedor, true);
}

/**
 * Verifica si un producto pertenece al proveedor
 * 
 * @param mysqli $conn Conexión a la base de datos
 * @param int $producto_id ID del producto
 * @param int $proveedor_id ID del proveedor
 * @return bool True si el producto pertenece al proveedor
 */
function productoPerteneceAProveedor($conn, $producto_id, $proveedor_id) {
    $producto_id = intval($producto_id);
    $proveedor_id = intval($proveedor_id);
    
    // Validación temprana: sin producto válido, no hay pertenencia
    if ($producto_id <= 0) {
        return false;
    }
    
    // Usuario de sistema (proveedor_id = 0): acceso total
    // Se evalúa DESPUÉS de validar $producto_id para no dar falsos positivos
    if ($proveedor_id === 0) {
        return true;
    }
    
    $stmt = $conn->prepare("SELECT id FROM productos WHERE id = ? AND proveedor_id = ? LIMIT 1");
    
    if (!$stmt) {
        error_log('[proveedor_utils] Error prepare productoPerteneceAProveedor: ' . $conn->error);
        return false;
    }
    
    $stmt->bind_param("ii", $producto_id, $proveedor_id);
    
    if (!$stmt->execute()) {
        error_log('[proveedor_utils] Error execute productoPerteneceAProveedor: ' . $stmt->error);
        $stmt->close();
        return false;
    }
    
    $result = $stmt->get_result();
    $pertenece = $result->num_rows > 0;
    
    $stmt->close();
    
    return $pertenece;
}

/**
 * Verifica si un combo pertenece al proveedor
 * 
 * @param mysqli $conn Conexión a la base de datos
 * @param int $combo_id ID del combo
 * @param int $proveedor_id ID del proveedor
 * @return bool True si el combo pertenece al proveedor
 */
function comboPerteneceAProveedor($conn, $combo_id, $proveedor_id) {
    $combo_id = intval($combo_id);
    $proveedor_id = intval($proveedor_id);
    
    // Validación temprana: sin combo válido, no hay pertenencia
    if ($combo_id <= 0) {
        return false;
    }
    
    // Usuario de sistema (proveedor_id = 0): acceso total
    if ($proveedor_id === 0) {
        return true;
    }
    
    $stmt = $conn->prepare("SELECT id FROM combos WHERE id = ? AND proveedor_id = ? LIMIT 1");
    
    if (!$stmt) {
        error_log('[proveedor_utils] Error prepare comboPerteneceAProveedor: ' . $conn->error);
        return false;
    }
    
    $stmt->bind_param("ii", $combo_id, $proveedor_id);
    
    if (!$stmt->execute()) {
        error_log('[proveedor_utils] Error execute comboPerteneceAProveedor: ' . $stmt->error);
        $stmt->close();
        return false;
    }
    
    $result = $stmt->get_result();
    $pertenece = $result->num_rows > 0;
    
    $stmt->close();
    
    return $pertenece;
}

/**
 * Verifica si un pedido pertenece al proveedor
 * 
 * @param mysqli $conn Conexión a la base de datos
 * @param int $pedido_id ID del pedido
 * @param int $proveedor_id ID del proveedor
 * @return bool True si el pedido pertenece al proveedor
 */
function pedidoPerteneceAProveedor($conn, $pedido_id, $proveedor_id) {
    $pedido_id = intval($pedido_id);
    $proveedor_id = intval($proveedor_id);
    
    // Validación temprana: sin pedido válido, no hay pertenencia
    if ($pedido_id <= 0) {
        return false;
    }
    
    // Usuario de sistema (proveedor_id = 0): acceso total
    if ($proveedor_id === 0) {
        return true;
    }
    
    $stmt = $conn->prepare("
        SELECT p.id 
        FROM pedidos p
        INNER JOIN pedido_detalles pd ON p.id = pd.pedido_id
        WHERE p.id = ? AND pd.proveedor_id = ?
        LIMIT 1
    ");
    
    if (!$stmt) {
        error_log('[proveedor_utils] Error prepare pedidoPerteneceAProveedor: ' . $conn->error);
        return false;
    }
    
    $stmt->bind_param("ii", $pedido_id, $proveedor_id);
    
    if (!$stmt->execute()) {
        error_log('[proveedor_utils] Error execute pedidoPerteneceAProveedor: ' . $stmt->error);
        $stmt->close();
        return false;
    }
    
    $result = $stmt->get_result();
    $pertenece = $result->num_rows > 0;
    
    $stmt->close();
    
    return $pertenece;
}

/**
 * Obtiene el nombre de la tienda del proveedor
 * 
 * @param mysqli $conn Conexión a la base de datos
 * @param int $proveedor_id ID del proveedor
 * @return string Nombre de la tienda (fallback: 'Catalejoo')
 */
function obtenerNombreTienda($conn, $proveedor_id) {
    $proveedor_id = intval($proveedor_id);
    
    if ($proveedor_id === 0) {
        return 'Catalejoo';
    }
    
    $stmt = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ? LIMIT 1");
    
    if (!$stmt) {
        error_log('[proveedor_utils] Error prepare obtenerNombreTienda: ' . $conn->error);
        return 'Catalejoo';
    }
    
    $stmt->bind_param("i", $proveedor_id);
    
    if (!$stmt->execute()) {
        error_log('[proveedor_utils] Error execute obtenerNombreTienda: ' . $stmt->error);
        $stmt->close();
        return 'Catalejoo';
    }
    
    $result = $stmt->get_result();
    $nombre = 'Catalejoo';
    
    if ($row = $result->fetch_assoc()) {
        $nombre = $row['nombre_tienda'];
    }
    
    $stmt->close();
    
    return $nombre;
}

/**
 * Genera condición SQL para filtrar por proveedor
 * 
 * IMPORTANTE: esta función devuelve una condición para concatenar en un WHERE.
 * El parámetro $proveedor_id se castea a intval() para prevenir inyección SQL.
 * 
 * @param int $proveedor_id ID del proveedor
 * @param string $alias Alias de la tabla (opcional, ej: 'p')
 * @return string Condición AND (con espacio inicial) o cadena vacía
 */
function filtroProveedorSQL($proveedor_id, $alias = '') {
    $proveedor_id = intval($proveedor_id);
    
    if ($proveedor_id === 0) {
        return '';
    }
    
    $alias = preg_replace('/[^a-zA-Z0-9_]/', '', $alias);
    $tabla = $alias !== '' ? "$alias." : "";
    
    return " AND {$tabla}proveedor_id = $proveedor_id";
}

/**
 * Obtiene el ID del proveedor validando un parámetro de URL
 * 
 * Si el usuario es de sistema (proveedor_id = 0) y se pasa un proveedor por URL,
 * lo valida contra la BD y lo devuelve si existe y está activo.
 * 
 * @param mysqli $conn Conexión a la base de datos
 * @param int $usuario_id ID del usuario
 * @param string $rol Nombre del rol
 * @param int $proveedor_url ID de proveedor desde URL (opcional)
 * @return int ID del proveedor validado (0 si no aplica)
 */
function obtenerProveedorValidado($conn, $usuario_id, $rol, $proveedor_url = 0) {
    $proveedor_id = obtenerProveedorId($conn, $usuario_id, $rol);
    $proveedor_url = intval($proveedor_url);
    
    // Si es usuario de sistema y se pasó un proveedor por URL, validarlo
    if ($proveedor_id === 0 && $proveedor_url > 0) {
        $stmt = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1 LIMIT 1");
        
        if (!$stmt) {
            error_log('[proveedor_utils] Error prepare obtenerProveedorValidado: ' . $conn->error);
            return 0;
        }
        
        $stmt->bind_param("i", $proveedor_url);
        
        if (!$stmt->execute()) {
            error_log('[proveedor_utils] Error execute obtenerProveedorValidado: ' . $stmt->error);
            $stmt->close();
            return 0;
        }
        
        $result = $stmt->get_result();
        $valido = $result->num_rows > 0;
        $stmt->close();
        
        return $valido ? $proveedor_url : 0;
    }
    
    return $proveedor_id;
}

/**
 * Verifica si el usuario tiene permiso para ver/editar un proveedor específico
 * 
 * @param int $proveedor_usuario ID del proveedor del usuario (0 si es de sistema)
 * @param int $proveedor_objetivo ID del proveedor que se quiere ver/editar
 * @return bool True si tiene permiso
 */
function tienePermisoProveedor($proveedor_usuario, $proveedor_objetivo) {
    $proveedor_usuario = intval($proveedor_usuario);
    $proveedor_objetivo = intval($proveedor_objetivo);
    
    // Usuario de sistema (admin global): puede ver todo
    if ($proveedor_usuario === 0) {
        return true;
    }
    
    // Usuario de tienda: solo puede ver su propio proveedor
    // Si el objetivo es "sistema" (0), un usuario de tienda NO tiene permiso
    if ($proveedor_objetivo === 0) {
        return false;
    }
    
    return $proveedor_usuario === $proveedor_objetivo;
}
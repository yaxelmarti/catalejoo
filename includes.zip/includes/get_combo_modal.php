<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}
    
// ============================================
// SEGURIDAD: Configurar sesión y validar entrada
// ============================================
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();

require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/moneda_funciones.php';

// ============================================
// VALIDAR PARÁMETROS DE ENTRADA
// ============================================
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

// ============================================
// LIMITAR NÚMERO DE REGISTROS (SEGURIDAD)
// ============================================
// Solo un combo por ID, no hay riesgo de muchos registros

// ============================================
// SANITIZAR Y VALIDAR COMBOS
// ============================================
$stmt = $conn->prepare("SELECT c.*, 
                               (SELECT COUNT(*) FROM combo_productos WHERE combo_id = c.id LIMIT 1) as total_productos,
                               (SELECT SUM(cantidad) FROM combo_productos WHERE combo_id = c.id LIMIT 1) as total_unidades
                        FROM combos c 
                        WHERE c.id = ? AND c.activo = 1
                        LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$combo = $stmt->get_result()->fetch_assoc();

if (!$combo) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Combo no encontrado']);
    exit;
}

// ============================================
// VALIDAR PROPIEDAD DEL COMBO (si es proveedor)
// ============================================
if (!comboPerteneceAProveedor($conn, $id, $proveedor_id_usuario)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'No tienes permiso para ver este combo']);
    exit;
}

// Calcular si es nuevo (menos de 48 horas)
$horas_creacion = floor((time() - strtotime($combo['fecha_creacion'])) / 3600);
$es_nuevo = $horas_creacion < 48;

// ============================================
// SANITIZAR DATOS DEL COMBO
// ============================================
$combo_safe = [
    'id' => intval($combo['id']),
    'nombre' => htmlspecialchars($combo['nombre'] ?? ''),
    'descripcion' => nl2br(htmlspecialchars($combo['descripcion'] ?? '')),
    'imagen_url' => htmlspecialchars($combo['imagen_url'] ?? '/uploads/combos/default.webp'),
    'precio' => floatval($combo['precio'] ?? 0),
    'precio_final' => floatval($combo['precio_final'] ?? $combo['precio']),
    'porcentaje_rebaja' => intval($combo['porcentaje_rebaja'] ?? 0),
    'total_productos' => intval($combo['total_productos'] ?? 0),
    'total_unidades' => intval($combo['total_unidades'] ?? 0),
    'stock_combo' => intval($combo['stock_combo'] ?? 0),
    'es_nuevo' => $es_nuevo
];

// ============================================
// LIMITAR PRODUCTOS POR COMBO (SEGURIDAD)
// ============================================
$stmt = $conn->prepare("SELECT cp.*, p.nombre, p.imagen_url, p.precio 
                        FROM combo_productos cp 
                        JOIN productos p ON cp.producto_id = p.id 
                        WHERE cp.combo_id = ?
                        LIMIT 50");
$stmt->bind_param("i", $id);
$stmt->execute();
$productos = $stmt->get_result();

$items = [];
while ($item = $productos->fetch_assoc()) {
    $items[] = [
        'id' => intval($item['producto_id']),
        'nombre' => htmlspecialchars($item['nombre'] ?? ''),
        'imagen' => htmlspecialchars($item['imagen_url'] ?? '/img/producto-default.png'),
        'cantidad' => intval($item['cantidad']),
        'precio' => floatval($item['precio'] ?? 0)
    ];
}

// ============================================
// DETERMINAR MONEDA (según proveedor del combo y cliente)
// ============================================
require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__) . '/includes/carrito_funciones.php';

$cliente = obtenerClienteActual($conn);
$cliente_registrado = (!empty($cliente['id']) && $cliente['id'] > 0);

$proveedor_combo = $combo['proveedor_id'] ?? 0;

// Detectar carrito pendiente del cliente (si es del mismo proveedor)
$carrito_moneda = null;
if ($cliente_registrado) {
    $carrito_pendiente = iniciarCarrito($conn, $cliente['id']);
    if ($carrito_pendiente && !empty($carrito_pendiente['moneda']) 
        && $carrito_pendiente['proveedor_id'] == $proveedor_combo) {
        $carrito_moneda = $carrito_pendiente['moneda'];
    }
}

$moneda_actual = getMonedaParaProveedor($conn, $proveedor_combo, $cliente, $carrito_moneda);
$moneda_simbolo = getSimboloPorMoneda($moneda_actual);
$moneda_codigo = $moneda_actual;

// ============================================
// CONVERTIR PRECIOS A LA MONEDA DEL CLIENTE
// ============================================
// Precios del combo
$precio_combo_usd = floatval($combo['precio'] ?? 0);
$precio_final_combo_usd = floatval($combo['precio_final'] ?? $combo['precio']);

if ($moneda_actual !== 'USD' && $proveedor_combo > 0) {
    $precio_combo_conv = convertirMoneda($precio_combo_usd, 'USD', $moneda_actual, $conn, $proveedor_combo);
    $precio_final_combo_conv = convertirMoneda($precio_final_combo_usd, 'USD', $moneda_actual, $conn, $proveedor_combo);
} else {
    $precio_combo_conv = $precio_combo_usd;
    $precio_final_combo_conv = $precio_final_combo_usd;
}

// Actualizar precios del combo en $combo_safe
$combo_safe['precio'] = $precio_combo_conv;
$combo_safe['precio_final'] = $precio_final_combo_conv;

// Convertir precios de los productos del combo (para el detalle)
foreach ($items as &$it) {
    $precio_item_usd = floatval($it['precio']);
    if ($moneda_actual !== 'USD' && $proveedor_combo > 0) {
        $it['precio'] = convertirMoneda($precio_item_usd, 'USD', $moneda_actual, $conn, $proveedor_combo);
    }
}
unset($it);

// ============================================
// DEVOLVER JSON SEGURO
// ============================================
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'combo' => $combo_safe,
    'productos' => $items,
    'moneda_simbolo' => $moneda_simbolo,
    'moneda_codigo' => $moneda_codigo
]);
?>
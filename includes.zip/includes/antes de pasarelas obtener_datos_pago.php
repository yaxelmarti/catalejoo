<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once '../conexion.php';

header('Content-Type: application/json');

$metodo = $_GET['metodo'] ?? '';

if (empty($metodo)) {
    echo json_encode(['success' => false, 'mensaje' => 'Método no especificado']);
    exit;
}

// Obtener datos del método de pago desde configuración
$datos = [];
$like = $metodo . '_%';
$stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE grupo = 'pagos' AND clave LIKE ?");
$stmt->bind_param("s", $like);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $campo = str_replace($metodo . '_', '', $row['clave']);
    $datos[$campo] = $row['valor'];
}

// Mapeo de URLs de pasarelas oficiales
$urls_pasarelas = [
    'paypal' => 'https://www.paypal.com',
    'stripe' => 'https://stripe.com',
    'square' => 'https://squareup.com',
    'amazon' => 'https://pay.amazon.com',
    'mercadopago' => 'https://www.mercadopago.com',
    'bizum' => 'https://bizum.es',
    'tropipay' => 'https://www.tropipay.com/login',
    'flowglad' => 'https://flowglad.com',
    'transferencia_usd' => '',
    'transferencia_clasica' => '',
    'zelle' => ''
];

// Nombres bonitos
$nombres = [
    'paypal' => 'PayPal',
    'stripe' => 'Stripe',
    'square' => 'Square',
    'amazon' => 'Amazon Pay',
    'mercadopago' => 'Mercado Pago',
    'bizum' => 'Bizum',
    'tropipay' => 'TropiPay',
    'flowglad' => 'Flowglad',
    'transferencia_usd' => 'Transferencia USD',
    'transferencia_clasica' => 'Transferencia Clásica',
    'zelle' => 'Zelle'
];

echo json_encode([
    'success' => true,
    'nombre' => $nombres[$metodo] ?? ucfirst($metodo),
    'datos' => $datos,
    'url_pasarela' => $urls_pasarelas[$metodo] ?? ''
]);
?>
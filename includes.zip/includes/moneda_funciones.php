<?php
// ============================================
// FUNCIONES DE MONEDA - MARKETPLACE
// ============================================

/**
 * Determinar la moneda según el código de país
 * 
 * Prioridad:
 * 1. Tabla moneda_pais (BD, escalable)
 * 2. Fallback: hardcodeo (Cuba, países EUR de paises_euro.txt)
 * 3. Fallback universal: USD
 */
function getMonedaPorPais($codigo_pais) {
    global $conn;
    $pais = strtoupper($codigo_pais);
    
    if (empty($pais)) {
        return 'USD';
    }
    
    // 1. Leer de tabla moneda_pais
    if ($conn instanceof mysqli) {
        static $cache = [];
        if (isset($cache[$pais])) {
            return $cache[$pais];
        }
        
        $stmt = $conn->prepare("
            SELECT mp.moneda 
            FROM moneda_pais mp
            INNER JOIN tazas_cambio tc ON tc.codigo = mp.moneda
            WHERE mp.pais = ? AND tc.activo = 1
            LIMIT 1
        ");
        
        if ($stmt) {
            $stmt->bind_param("s", $pais);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if ($row && !empty($row['moneda'])) {
                $cache[$pais] = $row['moneda'];
                return $row['moneda'];
            }
        }
    }
    
    // 2. Fallback universal
    return 'USD';
}

/**
 * Obtener el símbolo según la moneda
 * 
 * Lee SIEMPRE de la tabla tazas_cambio.
 * Si no encuentra la moneda, devuelve el código como fallback.
 */
function getSimboloPorMoneda($moneda) {
    global $conn;
    $moneda = strtoupper($moneda);
    
    if (empty($moneda)) {
        return '';
    }
    
    // Cache por petición (1 query por moneda como máximo)
    static $cache = [];
    if (isset($cache[$moneda])) {
        return $cache[$moneda];
    }
    
    // Leer de tazas_cambio
    if ($conn instanceof mysqli) {
        $stmt = $conn->prepare("SELECT simbolo FROM tazas_cambio WHERE codigo = ? LIMIT 1");
        
        if ($stmt) {
            $stmt->bind_param("s", $moneda);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if ($row && isset($row['simbolo'])) {
                $cache[$moneda] = $row['simbolo'];
                return $row['simbolo'];
            }
        }
    }
    
    // Fallback: el propio código (nunca hardcodear símbolos)
    $cache[$moneda] = $moneda;
    return $moneda;
}

/**
 * Detectar país por IP usando IPinfo
 */
function getPaisPorIP() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    
    // IPs locales o privadas → US por defecto
    if (empty($ip) || $ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0) {
        return 'US';
    }
    
    // Token de IPinfo
    $token = 'ce2c2dabcded5a';
    
    $url = "https://ipinfo.io/{$ip}/json";
    if (!empty($token)) {
        $url .= "?token={$token}";
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code === 200 && $response) {
        $data = json_decode($response, true);
        if (!empty($data['country'])) {
            return strtoupper($data['country']);
        }
    }
    
    return 'US';
}

// ============================================
// FUNCIONES CENTRALES DEL MARKETPLACE
// ============================================

/**
 * Detectar la moneda del cliente (registrado o por IP)
 * 
 * @param mysqli $conn
 * @param array|null $cliente  Datos del cliente (o null si es visitante)
 * @return string  'USD' | 'EUR' | 'CUP'
 */
function getMonedaDelCliente($conn, $cliente = null) {
    // 1. Cliente registrado → su moneda en BD
    if (!empty($cliente['id']) && $cliente['id'] > 0 && !empty($cliente['moneda'])) {
        return strtoupper($cliente['moneda']);
    }
    
    // 2. Visitante → detección por IP con caché 5 min
    $ahora = time();
    $tiempo_cache = 1200; // 20 minutos
    
    if (!isset($_SESSION['pais_detectado']) || 
        !isset($_SESSION['pais_detectado_time']) || 
        ($ahora - $_SESSION['pais_detectado_time']) > $tiempo_cache) {
        $_SESSION['pais_detectado'] = getPaisPorIP();
        $_SESSION['pais_detectado_time'] = $ahora;
    }
    
    return getMonedaPorPais($_SESSION['pais_detectado']);
}

/**
 * Obtener las monedas activas de un proveedor
 * 
 * Lee de la tabla relacional proveedor_monedas.
 * Orden: primero la predeterminada (USD), luego por prioridad USD > EUR > CUP, luego el resto.
 * 
 * @param mysqli $conn
 * @param int $proveedor_id
 * @return array  Ej: ['USD', 'EUR', 'CUP', 'MXN', 'GBP']  (en orden de prioridad)
 */
function getMonedasDelProveedor($conn, $proveedor_id) {
    if ($proveedor_id <= 0) return ['USD'];
    
    // Validar que el proveedor existe y está activo
    $stmt_prov = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_prov->bind_param("i", $proveedor_id);
    $stmt_prov->execute();
    if ($stmt_prov->get_result()->num_rows === 0) {
        $stmt_prov->close();
        return ['USD'];
    }
    $stmt_prov->close();
    
    // Leer monedas activas del proveedor (JOIN con tazas_cambio para validar)
    $stmt = $conn->prepare("
        SELECT pm.moneda, tc.predeterminada
        FROM proveedor_monedas pm
        INNER JOIN tazas_cambio tc ON tc.codigo = pm.moneda AND tc.activo = 1
        WHERE pm.proveedor_id = ? AND pm.activo = 1
        ORDER BY tc.predeterminada DESC, pm.moneda ASC
    ");
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    $monedas = [];
    while ($row = $res->fetch_assoc()) {
        $monedas[] = $row['moneda'];
    }
    $stmt->close();
    
        // Fallback si el proveedor no tiene ninguna moneda activa
    if (empty($monedas)) {
        return ['USD'];
    }
    
    // El orden ya viene del SQL: predeterminada DESC, luego alfabético
    return $monedas;
}

/**
 * Determinar la moneda a mostrar para un proveedor + cliente
 * 
 * @param mysqli $conn
 * @param int $proveedor_id
 * @param array|null $cliente
 * @param string|null $carrito_moneda  Moneda del carrito pendiente (prioridad máxima)
 * @return string
 */
function getMonedaParaProveedor($conn, $proveedor_id, $cliente = null, $carrito_moneda = null) {
    // 1. Si hay carrito pendiente con moneda → siempre esa
    if (!empty($carrito_moneda)) {
        return strtoupper($carrito_moneda);
    }
    
    // 2. Si no hay proveedor → moneda del cliente
    if ($proveedor_id <= 0) {
        return getMonedaDelCliente($conn, $cliente);
    }
    
    // 3. Obtener monedas activas del proveedor
    $monedas_prov = getMonedasDelProveedor($conn, $proveedor_id);
    
    // 4. Si vende solo 1 → esa
    if (count($monedas_prov) == 1) {
        return $monedas_prov[0];
    }
    
    // 5. NUEVO: Si el cliente seleccionó una moneda en el selector → respetarla
    $moneda_selector = $_SESSION['moneda_proveedor_' . $proveedor_id] ?? null;
    if (!empty($moneda_selector) && in_array($moneda_selector, $monedas_prov)) {
        return strtoupper($moneda_selector);
    }
    
    // 6. Vende 2+ → moneda del cliente
    $moneda_cliente = getMonedaDelCliente($conn, $cliente);
    
    // 7. Si el proveedor acepta la del cliente → esa
    if (in_array($moneda_cliente, $monedas_prov)) {
        return $moneda_cliente;
    }
    
    // 8. Fallback: primera activa (ya en orden de prioridad)
    return $monedas_prov[0];
}

/**
 * Obtener la tasa de cambio de un proveedor para una moneda
 * 
 * @param mysqli $conn
 * @param int $proveedor_id
 * @param string $moneda  'USD' | 'EUR' | 'CUP'
 * @return float  Tasa (0 si no hay)
 */
function getTasaProveedor($conn, $proveedor_id, $moneda) {
    $moneda = strtoupper($moneda);
    
    // USD siempre es 1.0000
    if ($moneda === 'USD') return 1.0000;
    
    // 1. Buscar tasa personalizada del proveedor
    if ($proveedor_id > 0) {
        $stmt = $conn->prepare("SELECT tasa, usa_tasa_global FROM proveedor_tasas WHERE proveedor_id = ? AND moneda = ?");
        $stmt->bind_param("is", $proveedor_id, $moneda);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($res && $res['usa_tasa_global'] == 0 && floatval($res['tasa']) > 0) {
            return floatval($res['tasa']);
        }
    }
    
    // 2. Fallback: tasa global
    $stmt = $conn->prepare("SELECT tasa FROM tazas_cambio WHERE codigo = ? AND activo = 1 LIMIT 1");
    $stmt->bind_param("s", $moneda);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($res && floatval($res['tasa']) > 0) {
        return floatval($res['tasa']);
    }
    
    // 3. Sin tasa disponible → 0 (el llamador decidirá qué hacer)
    return 0;
}

/**
 * Convertir un monto entre monedas
 * 
 * @param float $monto  Monto original
 * @param string $de    Moneda origen
 * @param string $a     Moneda destino
 * @param mysqli $conn
 * @param int $proveedor_id  Para buscar tasa personalizada (opcional)
 * @return float  Monto convertido (o el mismo si no hay tasa)
 */
function convertirMoneda($monto, $de, $a, $conn, $proveedor_id = 0) {
    $de = strtoupper($de);
    $a = strtoupper($a);
    
    // Sin conversión
    if ($de === $a) return floatval($monto);
    
    $monto = floatval($monto);
    
    // Caso 1: Convertir DESDE USD
    if ($de === 'USD') {
        $tasa_destino = getTasaProveedor($conn, $proveedor_id, $a);
        if ($tasa_destino > 0) {
            return $monto * $tasa_destino;
        }
        return $monto; // Sin tasa → sin conversión
    }
    
    // Caso 2: Convertir HACIA USD
    if ($a === 'USD') {
        $tasa_origen = getTasaProveedor($conn, $proveedor_id, $de);
        if ($tasa_origen > 0) {
            return $monto / $tasa_origen;
        }
        return $monto;
    }
    
    // Caso 3: Convertir entre dos monedas no-USD (vía USD como puente)
    $tasa_origen = getTasaProveedor($conn, $proveedor_id, $de);
    $tasa_destino = getTasaProveedor($conn, $proveedor_id, $a);
    
    if ($tasa_origen > 0 && $tasa_destino > 0) {
        // monto en moneda origen → USD → moneda destino
        $monto_usd = $monto / $tasa_origen;
        return $monto_usd * $tasa_destino;
    }
    
    return $monto; // Sin tasas → sin conversión
}

/**
 * Obtener las monedas de adquisición de un proveedor.
 * Lee de proveedor_monedas WHERE permite_adquisicion = 1 + JOIN tazas_cambio activo.
 * USD siempre incluida.
 *
 * @param mysqli $conn
 * @param int $proveedor_id
 * @return array  Ej: ['USD', 'EUR', 'CUP']
 */
function getMonedasParaAdquisicion($conn, $proveedor_id) {
    if ($proveedor_id <= 0) return ['USD'];

    // Validar proveedor activo
    $stmt = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $valido = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    if (!$valido) return ['USD'];

    $stmt = $conn->prepare("
        SELECT pm.moneda, tc.predeterminada
        FROM proveedor_monedas pm
        INNER JOIN tazas_cambio tc ON tc.codigo = pm.moneda AND tc.activo = 1
        WHERE pm.proveedor_id = ? AND pm.permite_adquisicion = 1
        ORDER BY tc.predeterminada DESC, pm.moneda ASC
    ");
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $monedas = [];
    while ($row = $res->fetch_assoc()) {
        $monedas[] = $row['moneda'];
    }
    $stmt->close();

    if (!in_array('USD', $monedas)) {
        array_unshift($monedas, 'USD');
    }

    return !empty($monedas) ? $monedas : ['USD'];
}
?>
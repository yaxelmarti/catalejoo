<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once 'conexion.php';
require_once 'includes/cliente_identificador.php';

$mensaje = '';
$tipo_mensaje = '';
$token = $_GET['token'] ?? '';

if (!empty($token)) {
    // Buscar cliente con este token
    $stmt = $conn->prepare("SELECT id, email FROM clientes WHERE verification_token = ? AND token_expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($cliente = $result->fetch_assoc()) {
        // Verificar email
        $stmt = $conn->prepare("UPDATE clientes SET email_verified = 1, verification_token = NULL, token_expires = NULL WHERE id = ?");
        $stmt->bind_param("i", $cliente['id']);
        $stmt->execute();
        
        $mensaje = "✅ ¡Email verificado correctamente! Ahora recibirás notificaciones de tus pedidos.";
        $tipo_mensaje = "exito";
    } else {
        $mensaje = "❌ El enlace de verificación no es válido o ha expirado.";
        $tipo_mensaje = "error";
    }
}

// Obtener configuración
$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion");
while($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}
$sitio_nombre = $config['sitio_nombre'] ?? 'Mi Tienda';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar email - <?php echo htmlspecialchars($sitio_nombre); ?></title>
    <link rel="stylesheet" href="estilo.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        
        .container {
            max-width: 500px;
            width: 100%;
        }
        
        .card {
            background: white;
            border-radius: 30px;
            padding: 2.5rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .icono {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 2rem;
            color: white;
            font-size: 3rem;
        }
        
        .icono.error {
            background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
        }
        
        h1 {
            font-size: 2rem;
            color: #2d3748;
            margin-bottom: 1rem;
        }
        
        .mensaje {
            color: #718096;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .btn-volver {
            display: inline-block;
            padding: 1rem 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-volver:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <?php if ($tipo_mensaje == 'exito'): ?>
                <div class="icono">✅</div>
                <h1>¡Email verificado!</h1>
            <?php else: ?>
                <div class="icono error">❌</div>
                <h1>Error de verificación</h1>
            <?php endif; ?>
            
            <div class="mensaje"><?php echo $mensaje; ?></div>
            
            <a href="index.php" class="btn-volver">← Volver a la tienda</a>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>
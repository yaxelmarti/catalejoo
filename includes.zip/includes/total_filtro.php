<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}

require_once '../conexion.php';
require_once '../includes/proveedor_utils.php';

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

$categoria_id = isset($_GET['categoria']) ? intval($_GET['categoria']) : 0;
$tipo = '';

if (isset($_GET['nuevos'])) {
    $tipo = 'nuevos';
} elseif (isset($_GET['mas_vendidos'])) {
    $tipo = 'mas_vendidos';
} elseif (isset($_GET['ofertas'])) {
    $tipo = 'ofertas';
}

header('Content-Type: application/json');

if ($tipo == 'nuevos') {
    $sql = "SELECT COUNT(*) as total FROM productos WHERE activo = 1 AND DATEDIFF(NOW(), fecha_creacion) <= 7";
    if ($proveedor_id_usuario > 0) {
        $sql .= " AND proveedor_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $proveedor_id_usuario);
    } else {
        $stmt = $conn->prepare($sql);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
} elseif ($tipo == 'mas_vendidos') {
    $sql = "SELECT COUNT(*) as total FROM (
        SELECT p.id FROM productos p 
        WHERE p.activo = 1 
        AND EXISTS (SELECT 1 FROM carrito_productos cp 
                    JOIN carritos ca ON cp.carrito_id = ca.id 
                    WHERE cp.producto_id = p.id AND ca.estado = 'comprado')";
    if ($proveedor_id_usuario > 0) {
        $sql .= " AND p.proveedor_id = ?";
    }
    $sql .= " LIMIT 30
    ) as vendidos";
    if ($proveedor_id_usuario > 0) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $proveedor_id_usuario);
    } else {
        $stmt = $conn->prepare($sql);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
} elseif ($tipo == 'ofertas') {
    $sql = "SELECT COUNT(*) as total FROM productos WHERE activo = 1 AND porcentaje_rebaja > 0";
    if ($proveedor_id_usuario > 0) {
        $sql .= " AND proveedor_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $proveedor_id_usuario);
    } else {
        $stmt = $conn->prepare($sql);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
} elseif ($categoria_id > 0) {
    $sql = "SELECT COUNT(*) as total FROM productos WHERE activo = 1 AND categoria_id = ?";
    if ($proveedor_id_usuario > 0) {
        $sql .= " AND proveedor_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $categoria_id, $proveedor_id_usuario);
    } else {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $categoria_id);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
} else {
    $sql = "SELECT COUNT(*) as total FROM productos WHERE activo = 1";
    if ($proveedor_id_usuario > 0) {
        $sql .= " AND proveedor_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $proveedor_id_usuario);
    } else {
        $stmt = $conn->prepare($sql);
    }
    $stmt->execute();
    $result = $stmt->get_result();
}

$total = $result->fetch_assoc()['total'];
echo json_encode(['total' => $total]);

$conn->close();
?>
<?php
/**
 * Registra un cambio en el historial de productos
 * @param object $conn Conexión a la base de datos
 * @param int $producto_id ID del producto afectado
 * @param string $accion 'crear', 'editar' o 'eliminar'
 * @param mixed $cambios Array con detalles del cambio (opcional)
 * @return bool True si se registró correctamente
 */
function registrarCambioProducto($conn, $producto_id, $accion, $cambios = null) {
    $usuario_id = $_SESSION['usuario_id'] ?? 0;
    $usuario_nombre = $_SESSION['nombre'] ?? 'Sistema';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // Convertir cambios a JSON si es array
    $cambios_json = is_array($cambios) ? json_encode($cambios, JSON_UNESCAPED_UNICODE) : $cambios;
    
    $stmt = $conn->prepare("INSERT INTO historial_productos_cambios 
        (producto_id, usuario_id, usuario_nombre, accion, cambios, ip_address, user_agent) 
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iisssss", $producto_id, $usuario_id, $usuario_nombre, $accion, $cambios_json, $ip, $user_agent);
    return $stmt->execute();
}
?>
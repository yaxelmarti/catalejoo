<?php
define('SEGURO', true);
    
if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}
require_once '../conexion.php';
require_once '../includes/proveedor_utils.php';
require_once 'moneda_funciones.php';

// ============================================
// SESIÓN (necesaria para caché de moneda)
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

// ============================================
// RECIBIR PROVEEDOR Y CALCULAR FILTRO
// ============================================
$proveedor_slug = isset($_GET['proveedor']) ? trim($_GET['proveedor']) : '';
$proveedor_id = 0;

if (!empty($proveedor_slug)) {
    $stmt_prov = $conn->prepare("SELECT id FROM proveedores WHERE slug = ? AND activo = 1");
    $stmt_prov->bind_param("s", $proveedor_slug);
    $stmt_prov->execute();
    $result_prov = $stmt_prov->get_result();
    if ($row = $result_prov->fetch_assoc()) {
        $proveedor_id = $row['id'];
    }
    $stmt_prov->close();
}

// Determinar proveedor filtro (URL > usuario logueado > 0)
$proveedor_filtro_id = 0;
if ($proveedor_id > 0) {
    $proveedor_filtro_id = $proveedor_id;
} elseif ($es_proveedor && $proveedor_id_usuario > 0) {
    $proveedor_filtro_id = $proveedor_id_usuario;
}

// ============================================
// DETERMINAR MONEDA (según proveedor y cliente)
// ============================================
require_once 'cliente_identificador.php';

$cliente = obtenerClienteActual($conn);
$cliente_registrado = (!empty($cliente['id']) && $cliente['id'] > 0);

$moneda_actual = getMonedaParaProveedor($conn, $proveedor_filtro_id, $cliente);
$moneda_simbolo = getSimboloPorMoneda($moneda_actual);
$moneda_codigo = $moneda_actual;

// Obtener configuración
$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion");
while($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}

$sitio_nombre = $config['sitio_nombre'] ?? 'TiendaVirtual';
// $moneda_simbolo y $moneda_codigo ya están calculados arriba

$tipo = '';
if (isset($_GET['nuevos'])) {
    $tipo = 'nuevos';
} elseif (isset($_GET['mas_vendidos'])) {
    $tipo = 'mas_vendidos';
} elseif (isset($_GET['ofertas'])) {
    $tipo = 'ofertas';
}

$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
$limite = isset($_GET['limite']) ? intval($_GET['limite']) : 16;

// Limitar valores para evitar abusos
$offset = max(0, min(1000, $offset));
$limite = max(1, min(100, $limite));

// Construir consulta según el tipo usando prepared statements
if ($tipo == 'nuevos') {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 ";

        // $proveedor_filtro_id ya está calculado arriba

    if ($proveedor_filtro_id > 0) {
        $sql .= " AND p.proveedor_id = " . intval($proveedor_filtro_id) . " ";
    }

    $sql .= " AND DATEDIFF(NOW(), p.fecha_creacion) <= 7
              ORDER BY p.fecha_creacion DESC
              LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $limite, $offset);
    $stmt->execute();
    $productos_todos = $stmt->get_result();
    
} elseif ($tipo == 'mas_vendidos') {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono,
            COALESCE((SELECT SUM(cp.cantidad) FROM carrito_productos cp 
                      JOIN carritos ca ON cp.carrito_id = ca.id 
                      WHERE cp.producto_id = p.id AND ca.estado = 'comprado'), 0) as total_vendidos
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 ";

       // $proveedor_filtro_id ya está calculado arriba

    if ($proveedor_filtro_id > 0) {
        $sql .= " AND p.proveedor_id = " . intval($proveedor_filtro_id) . " ";
    }

    $sql .= " GROUP BY p.id
              HAVING total_vendidos > 0
              ORDER BY total_vendidos DESC, p.nombre ASC
              LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $limite, $offset);
    $stmt->execute();
    $productos_todos = $stmt->get_result();
    
} elseif ($tipo == 'ofertas') {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 ";

       // $proveedor_filtro_id ya está calculado arriba

    if ($proveedor_filtro_id > 0) {
        $sql .= " AND p.proveedor_id = " . intval($proveedor_filtro_id) . " ";
    }

    $sql .= " AND p.porcentaje_rebaja > 0
              ORDER BY p.porcentaje_rebaja DESC, p.nombre ASC
              LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $limite, $offset);
    $stmt->execute();
    $productos_todos = $stmt->get_result();
    
} else {
    // Si no hay filtro válido, no mostrar nada
    echo '<div style="text-align: center; padding: 4rem; background: white; border-radius: 16px;"><h3>📭 Filtro no válido</h3></div>';
    exit;
}

if ($productos_todos->num_rows == 0) {
    echo '<div style="text-align: center; padding: 4rem; background: white; border-radius: 16px;"><h3>📭 No hay productos disponibles</h3></div>';
    exit;
}

while($producto = $productos_todos->fetch_assoc()):
    // Calcular variables necesarias
    $dias_antiguedad = floor((time() - strtotime($producto['fecha_creacion'])) / 86400);
    $es_nuevo = $dias_antiguedad < 7;
    $tiene_rebaja = $producto['porcentaje_rebaja'] > 0;
    
    // $moneda_simbolo, $moneda_codigo y $sitio_nombre ya están calculados arriba
    
    include __DIR__ . '/../producto_card.php';
endwhile;

$conn->close();
?>
// ============================================
// FUNCIONES DE MENÚS Y TIENDA - HEADER TIENDA
// ============================================

// ============================================
// 1. MENÚ LATERAL IZQUIERDO
// ============================================
function toggleSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('menuOverlay');
    if (menu) {
        menu.classList.toggle('show');
    }
    if (overlay) {
        overlay.classList.toggle('show');
    }
}

function cerrarSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('menuOverlay');
    if (menu) {
        menu.classList.remove('show');
    }
    if (overlay) {
        overlay.classList.remove('show');
    }
}

// ============================================
// 2. MENÚ CLIENTE (DESDE ABAJO)
// ============================================
function toggleClienteBottomMenu() {
    const menu = document.getElementById('clienteBottomMenu');
    const overlay = document.getElementById('bottomOverlay');
    if (menu) {
        menu.classList.toggle('show');
    }
    if (overlay) {
        overlay.classList.toggle('show');
    }
}

function cerrarClienteBottomMenu() {
    const menu = document.getElementById('clienteBottomMenu');
    const overlay = document.getElementById('bottomOverlay');
    if (menu) {
        menu.classList.remove('show');
    }
    if (overlay) {
        overlay.classList.remove('show');
    }
}

// ============================================
// 3. MENÚ CATEGORÍAS LATERAL DERECHO
// ============================================
function toggleCategoriasRightMenu() {
    const menu = document.getElementById('categoriasRightMenu');
    const overlay = document.getElementById('rightOverlay');
    if (menu) {
        menu.classList.toggle('show');
    }
    if (overlay) {
        overlay.classList.toggle('show');
    }
}

function cerrarCategoriasRightMenu() {
    const menu = document.getElementById('categoriasRightMenu');
    const overlay = document.getElementById('rightOverlay');
    if (menu) {
        menu.classList.remove('show');
    }
    if (overlay) {
        overlay.classList.remove('show');
    }
}

// ============================================
// 4. FUNCIONES DE MODALES
// ============================================
function abrirRegistro() {
    const modal = document.getElementById('modalRegistro');
    if (modal) {
        modal.style.display = 'block';
    }
}

function abrirPanelCliente() {
    const modal = document.getElementById('modalPasswordCliente');
    if (modal) {
        modal.style.display = 'block';
    }
}

function abrirCarrito() {
    const modal = document.getElementById('modalCarrito');
    if (modal) {
        modal.style.display = 'block';
    }
}

function cerrarModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

// ============================================
// 5. CERRAR SESIÓN
// ============================================
function cerrarSesion() {
    if (confirm('¿Cerrar sesión?')) {
        window.location.href = 'logout.php';
    }
}

// ============================================
// 6. ACTUALIZAR MENÚ CLIENTE
// ============================================
function actualizarMenuCliente(nombre, email) {
    // Actualizar header del menú cliente
    const bottomNombre = document.querySelector('#clienteBottomMenu .cliente-bottom-nombre');
    const bottomEmail = document.querySelector('#clienteBottomMenu .cliente-bottom-email');
    
    if (bottomNombre) bottomNombre.textContent = nombre;
    if (bottomEmail) bottomEmail.textContent = email;
    
    // Actualizar side menu
    const sideNombre = document.querySelector('#sideMenu .side-menu-nombre');
    const sideEmail = document.querySelector('#sideMenu .side-menu-email');
    
    if (sideNombre) sideNombre.textContent = nombre;
    if (sideEmail) sideEmail.textContent = email;
    
    // Cambiar los items del menú cliente
    const bottomItems = document.querySelector('#clienteBottomMenu .cliente-bottom-items');
    if (bottomItems) {
        bottomItems.innerHTML = `
            <li><div class="menu-item" onclick="cerrarClienteBottomMenu(); abrirPanelCliente();">👤 Mi Perfil</div></li>
            <li><div class="menu-item" onclick="cerrarClienteBottomMenu(); abrirCarrito();">🛒 Mi Carrito</div></li>
            <li><a href="/mis_pedidos.php" class="menu-item" onclick="cerrarClienteBottomMenu()">📋 Mis Compras</a></li>
            <li><a href="/ayuda.php" class="menu-item" onclick="cerrarClienteBottomMenu()">❓ Ayuda</a></li>
        `;
    }
    
    // Cambiar footer del side menu
    const sideFooter = document.querySelector('#sideMenu .side-menu-footer');
    if (sideFooter) {
        sideFooter.innerHTML = '<a href="#" onclick="cerrarSesion()">Cerrar sesión</a>';
    }
    
    // Mostrar bienvenida
    if (typeof mostrarNotificacion === 'function') {
        mostrarNotificacion('👋 ¡Bienvenido ' + nombre + '!', 'exito');
    }
}

// ============================================
// 7. CERRAR MENÚS AL HACER CLICK FUERA (OVERLAYS)
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    // Menú lateral izquierdo
    const menuOverlay = document.getElementById('menuOverlay');
    if (menuOverlay) {
        menuOverlay.addEventListener('click', cerrarSideMenu);
    }
    
    // Menú lateral derecho
    const rightOverlay = document.getElementById('rightOverlay');
    if (rightOverlay) {
        rightOverlay.addEventListener('click', cerrarCategoriasRightMenu);
    }
    
    // Menú cliente (bottom)
    const bottomOverlay = document.getElementById('bottomOverlay');
    if (bottomOverlay) {
        bottomOverlay.addEventListener('click', cerrarClienteBottomMenu);
    }
});

// ============================================
// 8. FUNCIONES DE CARRITO
// ============================================
function cambiarCantidad(btn, delta) {
    const selector = btn.closest('.cantidad-selector');
    const input = selector.querySelector('.cantidad-input');
    let valor = parseInt(input.value) || 1;
    valor = Math.max(1, Math.min(99, valor + delta));
    input.value = valor;
}

function agregarAlCarrito(productoId, btn) {
    const selector = btn.closest('.producto-card').querySelector('.cantidad-selector');
    const cantidad = parseInt(selector.querySelector('.cantidad-input').value) || 1;
    
    if (!window.clienteRegistrado) {
        document.getElementById('modalRegistro').style.display = 'block';
        window.productoPendiente = { id: productoId, cantidad: cantidad };
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=agregar&producto_id=' + productoId + '&cantidad=' + cantidad
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacion('✅ Producto agregado', 'exito');
            actualizarContadorCarrito();
        } else if (data.requiere_registro) {
            document.getElementById('modalRegistro').style.display = 'block';
            window.productoPendiente = { id: productoId, cantidad: cantidad };
        } else {
            mostrarNotificacion('❌ ' + data.mensaje, 'error');
        }
    })
    .catch(error => {
        console.error('Error en fetch:', error);
        mostrarNotificacion('❌ Error al conectar con el servidor', 'error');
    });
}

function actualizarContadorCarrito() {
    fetch('includes/carrito_ajax.php?accion=obtener_carrito')
    .then(response => response.json())
    .then(data => {
        const contadorHeader = document.getElementById('carritoContadorHeader');
        if (data.success && !data.vacio) {
            const totalItems = data.items.reduce((sum, item) => sum + item.cantidad, 0);
            if (contadorHeader) {
                contadorHeader.textContent = totalItems;
                contadorHeader.style.display = 'flex';
            }
        } else {
            if (contadorHeader) contadorHeader.style.display = 'none';
        }
        
        const sideContador = document.getElementById('sideMenuCarritoContador');
        if (sideContador && data.success && !data.vacio) {
            const totalItems = data.items.reduce((sum, item) => sum + item.cantidad, 0);
            sideContador.textContent = totalItems;
            sideContador.style.display = 'inline-flex';
        } else if (sideContador) {
            sideContador.style.display = 'none';
        }
    });
}

function verificarCarritoPendiente() {
    if (sessionStorage.getItem('no_mostrar_carrito_pendiente') === 'true') {
        sessionStorage.removeItem('no_mostrar_carrito_pendiente');
        return;
    }
    
    fetch('includes/carrito_ajax.php?accion=verificar_carrito_pendiente')
    .then(response => response.json())
    .then(data => {
        if (data.success && data.tiene_carrito) {
            mostrarModalCarritoPendiente(data);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function mostrarModalCarritoPendiente(data) {
    const info = document.getElementById('infoCarritoPendiente');
    if (!info) return;
    
    const totalItems = data.items.reduce((sum, item) => sum + item.cantidad, 0);
    const moneda = '<?php echo $moneda_simbolo; ?>';
    
    info.innerHTML = `
        <p class="cantidad">📦 ${totalItems} producto${totalItems !== 1 ? 's' : ''}</p>
        <p class="total">💰 ${moneda}${data.total.toFixed(2)}</p>
        <p class="tiempo">⏰ Expira en: ${data.horas_restantes} horas</p>
    `;
    
    window.carritoPendienteId = data.carrito_id;
    document.getElementById('modalCarritoPendiente').style.display = 'block';
}

// ============================================
// 9. FUNCIONES DE FILTRO Y NAVEGACIÓN
// ============================================
function filtrarCategoria(categoriaId) {
    window.location.href = 'index.php?categoria=' + categoriaId;
}

function filtrarNuevos() {
    window.location.href = 'index.php?filtro=nuevos';
}

function filtrarMasVendidos() {
    window.location.href = 'index.php?filtro=mas_vendidos';
}

function filtrarOfertas() {
    window.location.href = 'index.php?filtro=ofertas';
}

function cargarCombos() {
    window.location.href = 'index.php?filtro=combos';
}

function toggleCarrusel(ocultar) {
    const carrusel = document.getElementById('carruselContainer');
    if (carrusel) {
        carrusel.style.display = ocultar ? 'none' : 'block';
    }
}

function limpiarFiltroAjax() {
    const grid = document.getElementById('productos-grid');
    const combosContainer = document.getElementById('combosContainer');
    if (!grid) return;

    if (combosContainer) combosContainer.style.display = 'block';
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Limpiando filtro...</div>';

    fetch('includes/filtrar_productos.php?categoria=0&offset=0')
        .then(response => response.text())
        .then(html => {
            grid.innerHTML = html;
            const totalProductos = document.querySelectorAll('.producto-card').length;
            const contadorDiv = document.getElementById('contador-productos');
            if (contadorDiv) {
                contadorDiv.innerHTML = `<span>(${totalProductos} productos)</span>`;
            }
            grid.setAttribute('data-categoria', '0');
            grid.setAttribute('data-buscar', '');
            grid.setAttribute('data-filtro', '');
            grid.setAttribute('data-offset', '16');
            grid.setAttribute('data-total', totalProductos);
            grid.setAttribute('data-cargando', 'false');

            if (typeof ajustarTamanosTarjetas === 'function') ajustarTamanosTarjetas();
            const carrusel = document.getElementById('carruselContainer');
            if (carrusel) carrusel.style.display = 'block';
            window.pasoAtras = 1;
        })
        .catch(error => {
            console.error('Error al limpiar filtro:', error);
            grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al limpiar filtro</h3></div>';
        });
}

// ============================================
// 10. FUNCIONES DE SCROLL INFINITO
// ============================================
function cargarMasProductos() {
    const grid = document.getElementById('productos-grid');
    if (!grid) return;
    
    const esMovil = window.innerWidth <= 768;
    let productosPorCarga = esMovil ? 6 : 16;

    if (esMovil && window.scrollActivo === false) return;
    if (esMovil && window.totalCargado >= window.limiteScroll) {
        document.getElementById('cargarMasBtn').style.display = 'block';
        return;
    }

    if (!esMovil && window.totalCargado >= window.limiteScrollPC) {
        document.getElementById('cargarMasBtn').style.display = 'block';
        return;
    }
    
    if (window.scrollInfinitoHabilitado === false) return;
    
    const cargando = grid.getAttribute('data-cargando') === 'true';
    const offset = parseInt(grid.getAttribute('data-offset') || 0);
    const total = parseInt(grid.getAttribute('data-total') || 0);
    const categoria = parseInt(grid.getAttribute('data-categoria') || 0);
    const buscar = grid.getAttribute('data-buscar') || '';
    
    if (cargando) return;
    if (offset >= total) {
        document.getElementById('fin-productos').style.display = 'block';
        window.scrollInfinitoHabilitado = false;
        return;
    }
    
    grid.setAttribute('data-cargando', 'true');
    document.getElementById('loader-mas-productos').style.display = 'block';

    let url;
    const filtro = grid.getAttribute('data-filtro');

    if (filtro === 'combos') {
        url = 'includes/cargar_mas_combos.php?offset=' + offset + '&limite=' + productosPorCarga;
    } else {
        url = 'includes/cargar_mas_productos.php?offset=' + offset + '&categoria=' + categoria + '&limite=' + productosPorCarga;
        if (buscar) {
            url += '&buscar=' + encodeURIComponent(buscar);
        }
        if (filtro) {
            url += '&filtro=' + filtro;
        }
    }
    
    fetch(url)
        .then(response => response.text())
        .then(html => {
            if (html.trim()) {
                grid.insertAdjacentHTML('beforeend', html);
                const nuevosProductos = document.querySelectorAll('.producto-card').length;
                grid.setAttribute('data-offset', nuevosProductos);
                window.totalCargado = nuevosProductos;
                ajustarTamanosTarjetas();
            }
            grid.setAttribute('data-cargando', 'false');
            document.getElementById('loader-mas-productos').style.display = 'none';
            
            if (esMovil && window.totalCargado >= window.limiteScroll) {
                document.getElementById('cargarMasBtn').style.display = 'block';
                window.scrollActivo = false;
                return;
            }

            if (!esMovil && window.totalCargado >= window.limiteScrollPC && window.scrollActivo === true) {
                document.getElementById('cargarMasBtn').style.display = 'block';
                window.scrollActivo = false;
                return;
            }
        })
        .catch(error => {
            console.error('Error al cargar más productos:', error);
            grid.setAttribute('data-cargando', 'false');
            document.getElementById('loader-mas-productos').style.display = 'none';
        });
}

function cargarMasManual() {
    const esMovil = window.innerWidth <= 768;
    
    if (esMovil) {
        window.limiteScroll += 30;
    } else {
        window.limiteScrollPC += 48;
    }
    
    const grid = document.getElementById('productos-grid');
    if (grid) {
        const nuevosProductos = document.querySelectorAll('.producto-card').length;
        window.totalCargado = nuevosProductos;
        grid.setAttribute('data-offset', nuevosProductos);
    }
    
    window.scrollActivo = true;
    document.getElementById('cargarMasBtn').style.display = 'none';
    cargarMasProductos();
}

// ============================================
// 11. FUNCIONES DE BÚSQUEDA
// ============================================
function buscarProductosAJAX(termino) {
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'none';
    if (window.innerWidth <= 768) {
        window.totalCargado = 0;
        window.limiteScroll = 30;
        window.scrollActivo = true;
        document.getElementById('cargarMasBtn').style.display = 'none';
    }
    
    window.scrollInfinitoHabilitado = true;
    document.getElementById('fin-productos').style.display = 'none';
    
    if (!termino || termino.trim() === '') {
        return;
    }
    
    if (typeof window.detenerScrollInfinito === 'function') {
        window.detenerScrollInfinito();
    }
    window.busquedaActiva = termino;
    
    const grid = document.getElementById('productos-grid');
    if (!grid) return;
    
    grid.innerHTML = '<div style="text-align: center; padding: 4rem;">🔄 Buscando productos...</div>';
    
    fetch('includes/buscar_ajax.php?termino=' + encodeURIComponent(termino))
    .then(response => response.text())
    .then(html => {
        grid.innerHTML = html;
        const totalProductos = document.querySelectorAll('.producto-card').length;
        const contadorDiv = document.getElementById('contador-productos');
        if (contadorDiv) {
            contadorDiv.innerHTML = `<span>🔍 ${totalProductos}  "${termino}"</span>`;
        }
        const btnLimpiar = document.getElementById('btnLimpiarBusqueda');
        if (btnLimpiar) {
            btnLimpiar.style.display = 'block';
        }
        document.getElementById('loader-mas-productos').style.display = 'none';
        document.getElementById('fin-productos').style.display = 'none';
        if (typeof ajustarTamanosTarjetas === 'function') {
            ajustarTamanosTarjetas();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        grid.innerHTML = '<div style="text-align: center; padding: 4rem;"><h3>❌ Error al buscar</h3></div>';
    });
}

function limpiarBusquedaCompleta() {
    window.busquedaActiva = '';
    const inputBuscar = document.getElementById('buscarInputTitulo');
    if (inputBuscar) {
        inputBuscar.value = '';
    }
    const btnLimpiar = document.getElementById('btnLimpiarBusqueda');
    if (btnLimpiar) {
        btnLimpiar.style.display = 'none';
    }
    filtrarCategoria(0);
    const combosContainer = document.getElementById('combosContainer');
    if (combosContainer) combosContainer.style.display = 'block';
    setTimeout(() => {
        const totalProductos = document.querySelectorAll('.producto-card').length;
        const contadorDiv = document.getElementById('contador-productos');
        if (contadorDiv) {
            contadorDiv.innerHTML = `<span>(${totalProductos} productos)</span>`;
        }
    }, 100);
}

function ejecutarBusqueda() {
    const inputBuscar = document.getElementById('buscarInputTitulo');
    if (inputBuscar) {
        const termino = inputBuscar.value.trim();
        if (termino !== '') {
            toggleCarrusel(true);
            buscarProductosAJAX(termino);
        }
    }
}

// ============================================
// 12. FUNCIONES UI / VISUALES
// ============================================
function ajustarTamanosTarjetas() {
    var anchoPantalla = window.innerWidth;
    var esMovil = anchoPantalla <= 768;
    
    if (esMovil) {
        document.querySelectorAll('.producto-marca').forEach(el => el.style.setProperty('font-size', '10px', 'important'));
        document.querySelectorAll('.producto-nombre').forEach(el => {
            el.style.setProperty('font-size', '13px', 'important');
        });
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('font-size', '9px', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('font-size', '11px', 'important'));
        document.querySelectorAll('.producto-precio').forEach(el => el.style.removeProperty('color'));
        document.querySelectorAll('.producto-nombre').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('margin-bottom', '6px', 'important'));
    } else {
        document.querySelectorAll('.producto-marca').forEach(el => el.style.setProperty('font-size', '0.7rem', 'important'));
        document.querySelectorAll('.producto-nombre').forEach(el => {
            el.style.setProperty('font-size', '0.9rem', 'important');
        });
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('font-size', '0.65rem', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('font-size', '0.75rem', 'important'));
        document.querySelectorAll('.producto-precio').forEach(el => el.style.removeProperty('color'));
        document.querySelectorAll('.producto-nombre').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-descripcion').forEach(el => el.style.setProperty('margin-bottom', '4px', 'important'));
        document.querySelectorAll('.producto-categoria').forEach(el => el.style.setProperty('margin-bottom', '6px', 'important'));
    }
}

function verImagenGrande(src) {
    if (window.innerWidth > 768) return;
    const modal = document.getElementById('modalImagenGrande');
    const img = document.getElementById('imagenGrande');
    if (modal && img) {
        img.src = src;
        modal.style.display = 'flex';
    } else {
        window.open(src);
    }
}

function bloquearScrollFondo() {
    document.body.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.width = '100%';
}

function desbloquearScrollFondo() {
    document.body.style.overflow = '';
    document.body.style.position = '';
    document.body.style.width = '';
}

// ============================================
// 13. NOTIFICACIONES
// ============================================
function mostrarNotificacion(mensaje, tipo = 'exito') {
    const notif = document.createElement('div');
    notif.className = 'notificacion ' + (tipo === 'error' ? 'error' : tipo === 'warning' ? 'warning' : '');
    notif.textContent = mensaje;
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 3000);
}

// ============================================
// 14. HEARTBEAT
// ============================================
function enviarHeartbeat() {
    fetch('heartbeat_cliente.php')
        .then(response => response.json())
        .then(data => console.log('Heartbeat:', data))
        .catch(error => console.log('Heartbeat error:', error));
}

// ============================================
// 15. MODAL COMBO TIENDA (funciones auxiliares)
// ============================================
function cambiarCantidadComboModal(delta, comboId) {
    const input = document.getElementById(`cantidadComboModal_${comboId}`);
    if (input) {
        let valor = parseInt(input.value) || 1;
        valor = Math.max(1, Math.min(99, valor + delta));
        input.value = valor;
    }
}

function agregarComboModalAlCarrito(comboId) {
    const input = document.getElementById(`cantidadComboModal_${comboId}`);
    const cantidad = input ? parseInt(input.value) : 1;
    
    if (!window.clienteRegistrado) {
        cerrarModalComboTienda();
        document.getElementById('modalRegistro').style.display = 'block';
        window.productoPendiente = { combo: true, id: comboId, cantidad: cantidad };
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=agregar_combo&combo_id=' + comboId + '&cantidad=' + cantidad
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacion('✅ Combo agregado al carrito', 'exito');
            actualizarContadorCarrito();
            cerrarModalComboTienda();
        } else {
            mostrarNotificacion('❌ ' + data.mensaje, 'error');
        }
    });
}

// Cerrar modal combo
function cerrarModalComboTienda(reemplazarHash = true) {
    if (reemplazarHash && window.location.hash.includes('modal-combo')) {
        const urlLimpia = window.location.pathname + window.location.search;
        window.history.replaceState({}, '', urlLimpia);
    }
    const modal = document.getElementById('modalComboTienda');
    if (modal) modal.style.display = 'none';
    window.modalComboAbierto = false;
}

// ============================================
// 16. INICIALIZACIÓN
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    actualizarContadorCarrito();
    verificarCarritoPendiente();
});

// Iniciar heartbeat cada 30 segundos
setInterval(enviarHeartbeat, 30000);
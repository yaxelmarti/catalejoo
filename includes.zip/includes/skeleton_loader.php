<?php
// ============================================
// SKELETON LOADER - Puntos saltarines con logo
// ============================================

// Obtener logo y colores de la configuración
$logo_config = $config['logo_url'] ?? '';
$sitio_nombre_config = $config['sitio_nombre'] ?? 'CataLejo';
$color_primario = $config['color_primario'] ?? '#667eea';
$color_secundario = $config['color_secundario'] ?? '#764ba2';
?>
<style>
#skeletonOverlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, <?php echo $color_primario; ?> 0%, <?php echo $color_secundario; ?> 100%);
    z-index: 99999;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    transition: opacity 0.6s ease;
}

#skeletonOverlay .dots {
    display: flex;
    gap: 16px;
}

#skeletonOverlay .dot {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    animation: saltar 1.4s ease-in-out infinite;
    box-shadow: 0 0 20px rgba(255,255,255,0.3);
}

#skeletonOverlay .dot:nth-child(1) {
    background: #FF6B6B;
    animation-delay: 0s;
}

#skeletonOverlay .dot:nth-child(2) {
    background: #FECA57;
    animation-delay: 0.15s;
}

#skeletonOverlay .dot:nth-child(3) {
    background: #48DBFB;
    animation-delay: 0.3s;
}

#skeletonOverlay .dot:nth-child(4) {
    background: #FF9FF3;
    animation-delay: 0.45s;
}

#skeletonOverlay .dot:nth-child(5) {
    background: #54A0FF;
    animation-delay: 0.6s;
}

#skeletonOverlay .logo-container {
    margin-top: 2.5rem;
    display: flex;
    flex-direction: column;
    align-items: center;
}

#skeletonOverlay .logo-img {
    max-width: 200px;
    max-height: 80px;
    object-fit: contain;
    filter: drop-shadow(0 0 20px rgba(255,255,255,0.3))
            drop-shadow(0 0 40px rgba(255,255,255,0.15));
    animation: brillo 2s ease-in-out infinite;
}

#skeletonOverlay .logo-texto {
    font-size: 1.8rem;
    font-weight: 700;
    color: white;
    letter-spacing: -0.5px;
    text-shadow: 0 0 30px rgba(255,255,255,0.2);
}

#skeletonOverlay .loading-text {
    margin-top: 1.2rem;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-weight: 700;
    font-size: 1rem;
    letter-spacing: 0.5px;
    color: rgba(255,255,255,0.9);
    text-shadow: 0 0 20px rgba(255,255,255,0.15);
    text-align: center;
    line-height: 1.8;
}

@keyframes saltar {
    0%, 80%, 100% {
        transform: translateY(0);
        opacity: 0.4;
    }
    40% {
        transform: translateY(-35px);
        opacity: 1;
    }
}

@keyframes brillo {
    0%, 100% {
        filter: drop-shadow(0 0 20px rgba(255,255,255,0.3))
                drop-shadow(0 0 40px rgba(255,255,255,0.15));
    }
    50% {
        filter: drop-shadow(0 0 30px rgba(255,255,255,0.6))
                drop-shadow(0 0 60px rgba(255,255,255,0.3));
    }
}

#skeletonOverlay.hidden {
    opacity: 0;
    pointer-events: none;
}
</style>

<div id="skeletonOverlay">
    <div class="dots">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
    </div>
    
    <div class="logo-container">
        <?php if (!empty($logo_config)): ?>
            <?php 
            $ruta_logo = $_SERVER['DOCUMENT_ROOT'] . $logo_config;
            $version_logo = file_exists($ruta_logo) ? filemtime($ruta_logo) : time();
            ?>
            <img src="<?php echo htmlspecialchars($logo_config) . '?v=' . $version_logo; ?>" 
                 alt="<?php echo htmlspecialchars($sitio_nombre_config); ?>" 
                 class="logo-img">
        <?php else: ?>
            <div class="logo-texto">✨ <?php echo htmlspecialchars($sitio_nombre_config); ?></div>
        <?php endif; ?>
    </div>
    
    <!-- ✅ DOS LÍNEAS -->
    <div class="loading-text">
        ✨ CACARGANDO PAGUINA
        <br>
        <span style="font-weight: 400; font-size: 0.8rem; opacity: 0.7;">Conexion Restablecida..</span>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const overlay = document.getElementById('skeletonOverlay');
    setTimeout(function() {
        overlay.classList.add('hidden');
        setTimeout(function() {
            overlay.style.display = 'none';
        }, 600);
    }, 400);
});
</script>
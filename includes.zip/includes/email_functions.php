<?php
require_once __DIR__ . '/email_config.php';
require_once __DIR__ . '/email_templates.php';
require_once __DIR__ . '/moneda_funciones.php';

function obtenerDatosMetodoPago($metodo_pago, $proveedor_id = 0) {
    global $conn;
    $datos = [];
    
    if (empty($metodo_pago)) {
        return $datos;
    }
    
    $like = $metodo_pago . '_%';
    $proveedor_id = intval($proveedor_id);
    
    // Priorizar config del proveedor sobre la global
    $stmt = $conn->prepare("
        SELECT clave, valor, proveedor_id 
        FROM configuracion 
        WHERE grupo = 'pagos' 
          AND clave LIKE ? 
          AND proveedor_id IN (0, ?)
        ORDER BY proveedor_id DESC
    ");
    
    if (!$stmt) {
        error_log('[obtenerDatosMetodoPago] prepare() falló: ' . $conn->error);
        return $datos;
    }
    
    $stmt->bind_param("si", $like, $proveedor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $campo = substr($row['clave'], strlen($metodo_pago) + 1);
        // El proveedor viene primero (ORDER BY DESC). Solo sobrescribe si es del proveedor.
        if (!isset($datos[$campo]) || $row['proveedor_id'] == $proveedor_id) {
            $datos[$campo] = $row['valor'];
        }
    }
    
    $stmt->close();
    return $datos;
}

function enviarNotificacionPedido($pedido_id, $accion, $destinatario_extra = null) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT p.*, c.nombre, c.apellidos, c.email as cliente_email FROM pedidos p JOIN clientes c ON p.cliente_id = c.id WHERE p.id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    if (!$pedido) return false;
    
    $stmt = $conn->prepare("SELECT * FROM direcciones_envio WHERE pedido_id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $direccion = $stmt->get_result()->fetch_assoc();
    
    $stmt = $conn->prepare("SELECT pd.*, p.nombre FROM pedido_detalles pd JOIN productos p ON pd.producto_id = p.id WHERE pd.pedido_id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $productos = $stmt->get_result();
    
        $items = [];
    while ($item = $productos->fetch_assoc()) {
        $item['tipo'] = 'producto';  // ← clave que falta
        $items[] = $item;
    }
    
    $stmt_combos = $conn->prepare("SELECT pd.*, c.nombre, 'combo' as tipo FROM pedido_detalles pd JOIN combos c ON pd.combo_id = c.id WHERE pd.pedido_id = ?");
    $stmt_combos->bind_param("i", $pedido_id);
    $stmt_combos->execute();
    $combos = $stmt_combos->get_result();
    
   while ($combo = $combos->fetch_assoc()) {
    // Obtener productos del combo
    $stmt_prod_combo = $conn->prepare("SELECT cp.cantidad, p.nombre 
                                        FROM combo_productos cp 
                                        JOIN productos p ON cp.producto_id = p.id 
                                        WHERE cp.combo_id = ?");
    $stmt_prod_combo->bind_param("i", $combo['combo_id']);
    $stmt_prod_combo->execute();
    $productos_combo = $stmt_prod_combo->get_result();
    
    $productos_lista = [];
    while ($prod = $productos_combo->fetch_assoc()) {
        $productos_lista[] = '📦 ' . $prod['cantidad'] . 'x ' . $prod['nombre'];
    }
    
    $total_productos = count($productos_lista);
    $combo['nombre'] = '🎁 ' . $combo['nombre'] . ' (' . $total_productos . ' 📦)';
    $combo['productos_detalle'] = implode(', ', $productos_lista);
    $items[] = $combo;
}
    
        usort($items, function($a, $b) {
        $tipo_a = $a['tipo'] ?? 'producto';
        $tipo_b = $b['tipo'] ?? 'producto';
        if ($tipo_a === $tipo_b) return 0;
        return ($tipo_a === 'producto') ? -1 : 1;
    });
    
    $cliente = [
        'nombre' => $pedido['nombre'],
        'apellidos' => $pedido['apellidos'],
        'email' => $pedido['cliente_email']
    ];
    
        global $config;
    if (!isset($config)) {
        $config = [];
        $result_config = $conn->query("SELECT clave, valor FROM configuracion WHERE proveedor_id = 0");
        while($row = $result_config->fetch_assoc()) {
            $config[$row['clave']] = $row['valor'];
        }
    }
    
    // ============================================
    // NOMBRE DEL PROVEEDOR (para mostrar en email)
    // ============================================
    $config['proveedor_nombre_tienda'] = '';
    if (!empty($pedido['proveedor_id'])) {
        $stmt_prov_nombre = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ? LIMIT 1");
        if ($stmt_prov_nombre) {
            $stmt_prov_nombre->bind_param("i", $pedido['proveedor_id']);
            $stmt_prov_nombre->execute();
            $res_prov_nombre = $stmt_prov_nombre->get_result()->fetch_assoc();
            $stmt_prov_nombre->close();
            if (!empty($res_prov_nombre['nombre_tienda'])) {
                $config['proveedor_nombre_tienda'] = $res_prov_nombre['nombre_tienda'];
            }
        }
    }
    
    if ($accion == 'error_pasarela') {
        // Correo al cliente avisando que la pasarela API falló
        $html = plantilla_error_pasarela($pedido, $cliente, $pedido['tipo_pago'] ?? 'desconocida');
        $asunto = "⚠️ No pudimos procesar tu pago - Pedido {$pedido['codigo']}";
    } elseif ($accion == 'creado' || $accion == 'pedido_creado' || $accion == 'pendiente_entrega_pago' || $accion == 'pedido_creado_proveedor') {
        // Obtener proveedor del pedido
        $proveedor_pedido_email = intval($pedido['proveedor_id'] ?? 0);
        
        // Cargar config de pagos priorizando proveedor sobre global
        $config_pagos = [];
        $stmt_pagos = $conn->prepare("
            SELECT clave, valor, proveedor_id 
            FROM configuracion 
            WHERE grupo = 'pagos' 
              AND proveedor_id IN (0, ?)
            ORDER BY proveedor_id DESC
        ");
        $stmt_pagos->bind_param("i", $proveedor_pedido_email);
        $stmt_pagos->execute();
        $result_pagos = $stmt_pagos->get_result();
        while ($row = $result_pagos->fetch_assoc()) {
            // El proveedor viene primero (DESC). Solo sobrescribe si es del proveedor.
            if (!isset($config_pagos[$row['clave']]) || $row['proveedor_id'] == $proveedor_pedido_email) {
                $config_pagos[$row['clave']] = $row['valor'];
            }
        }
        $stmt_pagos->close();
        
        $contacto = [
            'email' => $config['sitio_email'] ?? '',
            'telefono' => $config['sitio_telefono'] ?? '',
            'horario' => $config['horario_atencion'] ?? 'Lunes a Viernes 9am - 6pm'
        ];
        
        $datos_pago = [
            'paypal_email' => $config_pagos['paypal_email'] ?? '',
            'paypal_cuenta' => $config_pagos['paypal_cuenta'] ?? '',
            'usd_beneficiario' => $config_pagos['transferencia_usd_beneficiario'] ?? '',
            'usd_banco' => $config_pagos['transferencia_usd_banco'] ?? '',
            'usd_numero' => $config_pagos['transferencia_usd_numero'] ?? '',
            'usd_swift' => $config_pagos['transferencia_usd_swift'] ?? '',
            'usd_instrucciones' => $config_pagos['transferencia_usd_instrucciones'] ?? '',
            'clasica_beneficiario' => $config_pagos['transferencia_clasica_beneficiario'] ?? '',
            'clasica_banco' => $config_pagos['transferencia_clasica_banco'] ?? '',
            'clasica_numero' => $config_pagos['transferencia_clasica_numero'] ?? '',
            'clasica_instrucciones' => $config_pagos['transferencia_clasica_instrucciones'] ?? ''
        ];
        
        $datos_parcial = [
            'porcentaje' => $pedido['porcentaje_pagado'] ?? 0,
            'monto_pagar' => $pedido['monto_pagado'] ?? 0,
            'monto_pendiente' => $pedido['monto_pendiente'] ?? 0,
            'es_parcial' => ($pedido['porcentaje_pagado'] ?? 0) > 0 && ($pedido['porcentaje_pagado'] ?? 0) < 100
        ];
        
        $html = plantilla_pendiente_pago($pedido, $cliente, $direccion, $items, $pedido['tipo_pago'], $datos_pago, $contacto, $datos_parcial);
        
        if ($accion == 'pedido_creado_proveedor') {
            $asunto = "🆕 Nuevo pedido recibido - {$pedido['codigo']}";
        } elseif ($accion == 'creado' || $accion == 'pedido_creado') {
            $asunto = "🛒 Nuevo pedido {$pedido['codigo']}";
        } else {
            $asunto = "📦 Pedido {$pedido['codigo']} - Solicitud de entrega (pago contra entrega)";
        }
    } else {
        $datos_parcial = [
            'porcentaje' => $pedido['porcentaje_pagado'] ?? 0,
            'monto_pagar' => $pedido['monto_pagado'] ?? 0,
            'monto_pendiente' => $pedido['monto_pendiente'] ?? 0,
            'es_parcial' => ($pedido['porcentaje_pagado'] ?? 0) > 0 && ($pedido['porcentaje_pagado'] ?? 0) < 100
        ];
        
        $html = plantilla_factura($pedido, $cliente, $direccion, $items, $accion, $datos_parcial);
        
                // Moneda del pedido
        $moneda_pedido_email = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
        $simbolo_email = getSimboloPorMoneda($moneda_pedido_email);
        $codigo_email = $moneda_pedido_email;
        
        if ($datos_parcial['es_parcial'] && $datos_parcial['monto_pendiente'] > 0) {
            $pendiente_texto = " (Pendiente: " . $simbolo_email . number_format($datos_parcial['monto_pendiente'], 2) . " " . $codigo_email . ")";
        } else {
            $pendiente_texto = "";
        }
        
                $asunto = match($accion) {
            'pagado', 'pago_confirmado' => $datos_parcial['es_parcial'] ? "💰 Pago parcial confirmado para pedido {$pedido['codigo']}" : "💰 Pago confirmado para pedido {$pedido['codigo']}",
            'pago_confirmado_proveedor' => "💰 Pedido {$pedido['codigo']} pagado - Listo para procesar",
            'pagado_parcial' => "💰 Pago parcial confirmado para pedido {$pedido['codigo']}",
            'empaquetado' => "📦 Su pedido {$pedido['codigo']} paso a Empaquetado{$pendiente_texto}",
            'transporte' => "🚚 Su Pedido {$pedido['codigo']} paso a Transportacion{$pendiente_texto}",
            'entregado' => $datos_parcial['monto_pendiente'] > 0 ? "✅ Pedido {$pedido['codigo']} entregado - Recuerda pagar " . $simbolo_email . number_format($datos_parcial['monto_pendiente'], 2) . " " . $codigo_email : "✅ Pedido {$pedido['codigo']} entregado",
            'cancelado' => "❌ Pedido {$pedido['codigo']} cancelado",
            default => "Actualización de pedido {$pedido['codigo']}"
        };
    }
    
    $texto = plantilla_texto_simple($pedido, $accion);
    
    if ($destinatario_extra) {
        $enviado = enviarCorreoBase($destinatario_extra, $asunto, $html, $texto);
    } else {
        $enviado = enviarCorreoBase($cliente['email'], $asunto, $html, $texto);
    }
    return $enviado;
}

function enviarCorreo($para, $asunto, $html, $texto = '') {
    require_once __DIR__ . '/../configuracion.php';
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . ($GLOBALS['config']['sitio_nombre'] ?? 'Mi Tienda') . " <" . ($GLOBALS['config']['sitio_email'] ?? 'no-reply@mitienda.com') . ">\r\n";
    $headers .= "Reply-To: " . ($GLOBALS['config']['sitio_email'] ?? 'no-reply@mitienda.com') . "\r\n";
    return mail($para, $asunto, $html, $headers);
}

function enviarCorreoSMTP($para, $asunto, $html, $texto = '') {
    global $conn;
    require_once __DIR__ . '/PHPMailer/PHPMailer.php';
    require_once __DIR__ . '/PHPMailer/SMTP.php';
    require_once __DIR__ . '/PHPMailer/Exception.php';
    
    // Obtener configuración SMTP GLOBAL (proveedor_id = 0)
    $config = [];
    $stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE clave IN ('smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_encryption', 'sitio_nombre', 'sitio_email') AND proveedor_id = 0");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $config[$row['clave']] = $row['valor'];
    }
    $stmt->close();
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = $config['smtp_host'] ?? 'smtp.gmail.com';
$mail->SMTPAuth   = true;
$mail->Username   = $config['smtp_user'] ?? '';
$mail->Password   = $config['smtp_pass'] ?? '';
$mail->SMTPSecure = $config['smtp_encryption'] ?? 'tls';
$mail->Port       = intval($config['smtp_port'] ?? 587);
$mail->setFrom($config['sitio_email'] ?? $config['smtp_user'] ?? 'no-reply@mitienda.com', $config['sitio_nombre'] ?? 'Mi Tienda');
        $mail->addAddress($para);
        $mail->isHTML(true);
        $mail->Subject = $asunto;
        $mail->Body    = $html;
        $mail->AltBody = $texto ?: strip_tags($html);
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Error al enviar correo: " . $mail->ErrorInfo);
        return false;
    }
}

function enviarNotificacionPedidoConPDF($pedido_id, $accion, $destinatario_extra = null) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT p.*, c.nombre, c.apellidos, c.email as cliente_email FROM pedidos p JOIN clientes c ON p.cliente_id = c.id WHERE p.id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    if (!$pedido) return false;
    
        $email_cliente = $destinatario_extra ?? $pedido['cliente_email'];
    
    // ===== CASO ESPECIAL: error_pasarela NO lleva PDF =====
    // El pedido no se ha pagado aún, no tiene sentido adjuntar factura.
    if ($accion === 'error_pasarela') {
        return enviarNotificacionPedido($pedido_id, $accion, $destinatario_extra);
    }
    
    // ===== LIMPIAR SALIDA ANTES DEL PDF =====
while (ob_get_level()) {
    ob_end_clean();
}
ob_start();

require_once dirname(__DIR__) . '/includes/generar_pdf_pedido.php';
$pdf_content = generarPDFPedido($pedido_id, $conn, $accion);
    
    if (!$pdf_content) {
        return enviarNotificacionPedido($pedido_id, $accion, $destinatario_extra);
    }
    
    $stmt_dir = $conn->prepare("SELECT * FROM direcciones_envio WHERE pedido_id = ?");
    $stmt_dir->bind_param("i", $pedido_id);
    $stmt_dir->execute();
    $direccion = $stmt_dir->get_result()->fetch_assoc();
    
    $stmt_prod = $conn->prepare("SELECT pd.*, p.nombre FROM pedido_detalles pd JOIN productos p ON pd.producto_id = p.id WHERE pd.pedido_id = ?");
    $stmt_prod->bind_param("i", $pedido_id);
    $stmt_prod->execute();
    $productos = $stmt_prod->get_result();
    
       $items = [];
    while ($item = $productos->fetch_assoc()) {
        $item['tipo'] = 'producto';  // ← clave que falta
        $items[] = $item;
    }
    
    $stmt_combos = $conn->prepare("SELECT pd.*, c.nombre, 'combo' as tipo FROM pedido_detalles pd JOIN combos c ON pd.combo_id = c.id WHERE pd.pedido_id = ?");
    $stmt_combos->bind_param("i", $pedido_id);
    $stmt_combos->execute();
    $combos = $stmt_combos->get_result();
    
    while ($combo = $combos->fetch_assoc()) {
    // Obtener productos del combo
    $stmt_prod_combo = $conn->prepare("SELECT cp.cantidad, p.nombre 
                                        FROM combo_productos cp 
                                        JOIN productos p ON cp.producto_id = p.id 
                                        WHERE cp.combo_id = ?");
    $stmt_prod_combo->bind_param("i", $combo['combo_id']);
    $stmt_prod_combo->execute();
    $productos_combo = $stmt_prod_combo->get_result();
    
    $productos_lista = [];
    while ($prod = $productos_combo->fetch_assoc()) {
        $productos_lista[] = '📦 ' . $prod['cantidad'] . 'x ' . $prod['nombre'];
    }
    
    $total_productos = count($productos_lista);
    $combo['nombre'] = '🎁 ' . $combo['nombre'] . ' (' . $total_productos . ' 📦)';
    $combo['productos_detalle'] = implode(', ', $productos_lista);
    $items[] = $combo;
}
    
        usort($items, function($a, $b) {
        $tipo_a = $a['tipo'] ?? 'producto';
        $tipo_b = $b['tipo'] ?? 'producto';
        if ($tipo_a === $tipo_b) return 0;
        return ($tipo_a === 'producto') ? -1 : 1;
    });
    
    $cliente = [
        'nombre' => $pedido['nombre'],
        'apellidos' => $pedido['apellidos'],
        'email' => $pedido['cliente_email']
    ];
    
        global $config;
    if (!isset($config)) {
        $config = [];
        $result_config = $conn->query("SELECT clave, valor FROM configuracion WHERE proveedor_id = 0");
        while($row = $result_config->fetch_assoc()) {
            $config[$row['clave']] = $row['valor'];
        }
    }
    
    // ============================================
    // NOMBRE DEL PROVEEDOR (para mostrar en email)
    // ============================================
    $config['proveedor_nombre_tienda'] = '';
    if (!empty($pedido['proveedor_id'])) {
        $stmt_prov_nombre = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ? LIMIT 1");
        if ($stmt_prov_nombre) {
            $stmt_prov_nombre->bind_param("i", $pedido['proveedor_id']);
            $stmt_prov_nombre->execute();
            $res_prov_nombre = $stmt_prov_nombre->get_result()->fetch_assoc();
            $stmt_prov_nombre->close();
            if (!empty($res_prov_nombre['nombre_tienda'])) {
                $config['proveedor_nombre_tienda'] = $res_prov_nombre['nombre_tienda'];
            }
        }
    }
    
       if ($accion == 'error_pasarela') {
        // Correo al cliente avisando que la pasarela API falló
        $html = plantilla_error_pasarela($pedido, $cliente, $pedido['tipo_pago'] ?? 'desconocida');
        $asunto = "⚠️ No pudimos procesar tu pago - Pedido {$pedido['codigo']}";
    } elseif ($accion == 'creado' || $accion == 'pedido_creado' || $accion == 'pendiente_entrega_pago' || $accion == 'pedido_creado_proveedor') {
        // Obtener proveedor del pedido
        $proveedor_pedido_email = intval($pedido['proveedor_id'] ?? 0);
        
        // Cargar config de pagos priorizando proveedor sobre global
        $config_pagos = [];
        $stmt_pagos = $conn->prepare("
            SELECT clave, valor, proveedor_id 
            FROM configuracion 
            WHERE grupo = 'pagos' 
              AND proveedor_id IN (0, ?)
            ORDER BY proveedor_id DESC
        ");
        $stmt_pagos->bind_param("i", $proveedor_pedido_email);
        $stmt_pagos->execute();
        $result_pagos = $stmt_pagos->get_result();
        while ($row = $result_pagos->fetch_assoc()) {
            // El proveedor viene primero (DESC). Solo sobrescribe si es del proveedor.
            if (!isset($config_pagos[$row['clave']]) || $row['proveedor_id'] == $proveedor_pedido_email) {
                $config_pagos[$row['clave']] = $row['valor'];
            }
        }
        $stmt_pagos->close();
        
        $contacto = [
            'email' => $config['sitio_email'] ?? '',
            'telefono' => $config['sitio_telefono'] ?? '',
            'horario' => $config['horario_atencion'] ?? 'Lunes a Viernes 9am - 6pm'
        ];
        
        $datos_pago = [
            'paypal_email' => $config_pagos['paypal_email'] ?? '',
            'paypal_cuenta' => $config_pagos['paypal_cuenta'] ?? '',
            'usd_beneficiario' => $config_pagos['transferencia_usd_beneficiario'] ?? '',
            'usd_banco' => $config_pagos['transferencia_usd_banco'] ?? '',
            'usd_numero' => $config_pagos['transferencia_usd_numero'] ?? '',
            'usd_swift' => $config_pagos['transferencia_usd_swift'] ?? '',
            'usd_instrucciones' => $config_pagos['transferencia_usd_instrucciones'] ?? '',
            'clasica_beneficiario' => $config_pagos['transferencia_clasica_beneficiario'] ?? '',
            'clasica_banco' => $config_pagos['transferencia_clasica_banco'] ?? '',
            'clasica_numero' => $config_pagos['transferencia_clasica_numero'] ?? '',
            'clasica_instrucciones' => $config_pagos['transferencia_clasica_instrucciones'] ?? ''
        ];
        
        $datos_parcial = [
            'porcentaje' => $pedido['porcentaje_pagado'] ?? 0,
            'monto_pagar' => $pedido['monto_pagado'] ?? 0,
            'monto_pendiente' => $pedido['monto_pendiente'] ?? 0,
            'es_parcial' => ($pedido['porcentaje_pagado'] ?? 0) > 0 && ($pedido['porcentaje_pagado'] ?? 0) < 100
        ];
        
        $html = plantilla_pendiente_pago($pedido, $cliente, $direccion, $items, $pedido['tipo_pago'], $datos_pago, $contacto, $datos_parcial);
        
        if ($accion == 'pedido_creado_proveedor') {
            $asunto = "🆕 Nuevo pedido recibido - {$pedido['codigo']}";
        } elseif ($accion == 'creado' || $accion == 'pedido_creado') {
            $asunto = "🛒 Nuevo pedido {$pedido['codigo']}";
        } else {
            $asunto = "📦 Pedido {$pedido['codigo']} - Solicitud de entrega (pago contra entrega)";
        }
    } else {
        $datos_parcial = [
            'porcentaje' => $pedido['porcentaje_pagado'] ?? 0,
            'monto_pagar' => $pedido['monto_pagado'] ?? 0,
            'monto_pendiente' => $pedido['monto_pendiente'] ?? 0,
            'es_parcial' => ($pedido['porcentaje_pagado'] ?? 0) > 0 && ($pedido['porcentaje_pagado'] ?? 0) < 100
        ];
        
        $html = plantilla_factura($pedido, $cliente, $direccion, $items, $accion, $datos_parcial);
        
                $asunto = match($accion) {
            'pagado', 'pago_confirmado' => "💰 Pago confirmado para pedido {$pedido['codigo']}",
            'pago_confirmado_proveedor' => "💰 Pedido {$pedido['codigo']} pagado - Listo para procesar",
            'pagado_parcial' => "💰 Pago parcial confirmado para pedido {$pedido['codigo']}",
            'empaquetado' => "📦 Su pedido {$pedido['codigo']} paso a Empaquetado",
            'transporte' => "🚚 Su Pedido {$pedido['codigo']} paso a Transportacion",
            'entregado' => "✅ Pedido {$pedido['codigo']} entregado",
            'cancelado' => "❌ Pedido {$pedido['codigo']} cancelado",
            default => "Actualización de pedido {$pedido['codigo']}"
        };
    }
    
    $texto = plantilla_texto_simple($pedido, $accion);
    
    return enviarCorreoConPDF($email_cliente, $asunto, $html, $texto, $pdf_content, $pedido['codigo']);
}

function enviarCorreoConPDF($para, $asunto, $html, $texto, $pdf_content, $codigo_pedido) {
    global $conn;
    
    if (!filter_var($para, FILTER_VALIDATE_EMAIL)) {
        error_log("Email inválido: " . $para);
        return false;
    }
    
    $config = [];
$stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE clave IN ('smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_encryption', 'sitio_nombre', 'sitio_email') AND proveedor_id = 0");
$stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $config[$row['clave']] = $row['valor'];
    }
    
    $smtp_host = $config['smtp_host'] ?? 'smtp.gmail.com';
    $smtp_port = $config['smtp_port'] ?? '587';
    $smtp_user = $config['smtp_user'] ?? '';
    $smtp_pass = $config['smtp_pass'] ?? '';
    $smtp_encryption = $config['smtp_encryption'] ?? 'tls';
    $sitio_nombre = $config['sitio_nombre'] ?? 'Catalejo';
    $sitio_email = $config['sitio_email'] ?? $smtp_user;
    
    require_once __DIR__ . '/PHPMailer/Exception.php';
    require_once __DIR__ . '/PHPMailer/PHPMailer.php';
    require_once __DIR__ . '/PHPMailer/SMTP.php';
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host       = $smtp_host;
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp_user;
        $mail->Password   = $smtp_pass;
        
        if ($smtp_encryption === 'tls') {
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($smtp_encryption === 'ssl') {
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        }
        
        $mail->Port       = intval($smtp_port);
        $mail->CharSet    = 'UTF-8';
        
        $mail->setFrom($sitio_email, $sitio_nombre);
        $mail->addAddress($para);
        
        $mail->isHTML(true);
        $mail->Subject = '=?UTF-8?B?' . base64_encode($asunto) . '?=';
        $mail->Body    = $html;
        $mail->AltBody = $texto ?: strip_tags($html);
        
        if (!empty($pdf_content)) {
            $mail->addStringAttachment($pdf_content, 'pedido_' . $codigo_pedido . '.pdf', 'base64', 'application/pdf');
        }
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Error PHPMailer: " . $e->getMessage());
        return false;
    }
}
?>
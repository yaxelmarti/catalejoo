<?php
/**
 * Obtiene el proveedor asociado a un usuario
 * 
 * @param mysqli $conn
 * @param int $usuario_id
 * @param string $rol_nombre
 * @return array|null ['id' => int, 'nombre_tienda' => string, 'slug' => string] o null
 */
function obtenerProveedorDeUsuario($conn, $usuario_id, $rol_nombre = null) {
    // Si no se pasa el rol, obtenerlo de la sesión
    if ($rol_nombre === null) {
        $rol_nombre = $_SESSION['rol'] ?? '';
    }
    
    // 🔥 USUARIOS DEL SISTEMA: ven todo (sin filtrar)
    $roles_sistema = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
    if (in_array($rol_nombre, $roles_sistema)) {
        return null; // null = sin filtro = ver todo
    }
    
    // 🔥 USUARIOS DE TIENDA: buscar su proveedor
    // 1. Verificar si es dueño (proveedores.usuario_id)
    $stmt = $conn->prepare("SELECT id, nombre_tienda, slug FROM proveedores WHERE usuario_id = ? AND activo = 1");
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $proveedor = $result->fetch_assoc();
    
    if ($proveedor) {
        return $proveedor;
    }
    
    // 2. Buscar en tabla intermedia (usuario_proveedor)
    $stmt = $conn->prepare("
        SELECT p.id, p.nombre_tienda, p.slug 
        FROM proveedores p
        JOIN usuario_proveedor up ON p.id = up.proveedor_id
        WHERE up.usuario_id = ? AND up.activo = 1 AND p.activo = 1
    ");
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $proveedor = $result->fetch_assoc();
    
    return $proveedor; // null si no es proveedor
}

/**
 * Verifica si un usuario tiene acceso a un recurso (producto, pedido, etc.)
 * 
 * @param mysqli $conn
 * @param int $usuario_id
 * @param string $rol_nombre
 * @param int $recurso_proveedor_id  // proveedor_id del recurso
 * @return bool
 */
function usuarioTieneAccesoARecurso($conn, $usuario_id, $rol_nombre, $recurso_proveedor_id) {
    // Usuarios del sistema: acceso total
    $roles_sistema = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
    if (in_array($rol_nombre, $roles_sistema)) {
        return true;
    }
    
    // Obtener el proveedor del usuario
    $proveedor = obtenerProveedorDeUsuario($conn, $usuario_id, $rol_nombre);
    
    if (!$proveedor) {
        return false; // No es proveedor
    }
    
    // Verificar si el proveedor del recurso coincide
    return $proveedor['id'] == $recurso_proveedor_id;
}
?>
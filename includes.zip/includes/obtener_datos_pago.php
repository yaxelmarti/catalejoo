<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once '../conexion.php';
require_once '../includes/proveedor_utils.php';

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO (si está logueado)
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_id'] > 0) {
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
    $es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');
}

header('Content-Type: application/json');

$metodo = $_GET['metodo'] ?? '';

if (empty($metodo)) {
    echo json_encode(['success' => false, 'mensaje' => 'Método no especificado']);
    exit;
}

// Obtener datos del método de pago desde configuración
$datos = [];
$like = $metodo . '_%';
// Si es proveedor, buscar solo su configuración; si es admin, buscar global
if ($es_proveedor && $proveedor_id_usuario > 0) {
    $stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE grupo = 'pagos' AND clave LIKE ? AND proveedor_id = ?");
    $stmt->bind_param("si", $like, $proveedor_id_usuario);
} else {
    $stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE grupo = 'pagos' AND clave LIKE ? AND proveedor_id = 0");
    $stmt->bind_param("s", $like);
}
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $campo = str_replace($metodo . '_', '', $row['clave']);
    $datos[$campo] = $row['valor'];
}

// ============================================
// CONSTRUIR URL DE PASARELA (según cada método)
// ============================================
$url_pasarela = '';

switch ($metodo) {
    case 'paypal':
        $email = $datos['email'] ?? '';
        $currency = $datos['currency'] ?? 'USD';
        $modo = $datos['modo'] ?? 'production';
        $comision = $datos['comision'] ?? 0;
        
        if (!empty($email)) {
            $base_url = ($modo == 'sandbox') 
                ? 'https://www.sandbox.paypal.com/cgi-bin/webscr'
                : 'https://www.paypal.com/cgi-bin/webscr';
            $url_pasarela = $base_url . '?cmd=_xclick&business=' . urlencode($email) . '&currency_code=' . $currency;
        }
        break;
        
    case 'stripe':
        $public_key = $datos['public_key'] ?? '';
        $comision = $datos['comision'] ?? 0;
        if (!empty($public_key)) {
            $url_pasarela = 'https://js.stripe.com/v3/'; // Stripe usa JS, no URL directa
        }
        break;
        
    case 'mercadopago':
        $public_key = $datos['public_key'] ?? '';
        $comision = $datos['comision'] ?? 0;
        if (!empty($public_key)) {
            $url_pasarela = 'https://www.mercadopago.com.ar/checkout/v1/redirect';
        }
        break;
        
    case 'square':
        $comision = $datos['comision'] ?? 0;
        $url_pasarela = 'https://squareup.com';
        break;
        
    case 'amazon':
        $comision = $datos['comision'] ?? 0;
        $url_pasarela = 'https://pay.amazon.com';
        break;
        
    case 'bizum':
        $comision = $datos['comision'] ?? 0;
        $url_pasarela = 'https://bizum.es';
        break;
        
    case 'tropipay':
        $comision = $datos['comision'] ?? 0;
        $url_pasarela = 'https://www.tropipay.com/login';
        break;
        
    case 'flowglad':
        $comision = $datos['comision'] ?? 0;
        $url_pasarela = 'https://flowglad.com';
        break;
        
    case 'qvapay':
    $comision = $datos['comision'] ?? 0;
    $url_pasarela = 'https://qvapay.com';
    break;
        
    case 'transferencia_usd':
    case 'transferencia_clasica':
    case 'zelle':
        $url_pasarela = ''; // No tienen pasarela online
        break;
        
    default:
        $url_pasarela = '';
        break;
}

// Nombres bonitos
$nombres = [
    'paypal' => 'PayPal',
    'stripe' => 'Stripe',
    'square' => 'Square',
    'amazon' => 'Amazon Pay',
    'mercadopago' => 'Mercado Pago',
    'bizum' => 'Bizum',
    'tropipay' => 'TropiPay',
    'flowglad' => 'Flowglad',
    'qvapay' => 'QvaPay',
    'transferencia_usd' => 'Transferencia USD',
    'transferencia_clasica' => 'Transferencia Clásica',
    'zelle' => 'Zelle'
];

echo json_encode([
    'success' => true,
    'nombre' => $nombres[$metodo] ?? ucfirst($metodo),
    'datos' => $datos,
    'url_pasarela' => $url_pasarela
]);
?>
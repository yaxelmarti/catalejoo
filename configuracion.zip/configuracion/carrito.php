<?php
// ============================================
// CONFIGURACIÓN DEL CARRITO - GLOBAL Y PROVEEDORES
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_actual = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol']);
$es_proveedor = esRolProveedor($_SESSION['rol']);
$es_admin = in_array($_SESSION['rol'], ['Super Admin', 'Gerente']);

if ($es_proveedor && $proveedor_id_actual == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// Validar que el proveedor existe y está activo
if ($proveedor_id_actual > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_actual);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// OBTENER PROVEEDOR A EDITAR
// ============================================
$proveedor_id_editar = 0;

if ($es_proveedor) {
    $proveedor_id_editar = $proveedor_id_actual;
} else {
    if (isset($_GET['proveedor_id']) && is_numeric($_GET['proveedor_id'])) {
        $proveedor_id_editar = intval($_GET['proveedor_id']);
    }
}

// Si es administrador y está editando un proveedor específico, verificar que existe
if ($es_admin && $proveedor_id_editar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_editar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/carrito.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// PROCESAR GUARDAR
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/carrito.php" . ($proveedor_id_editar ? "?proveedor_id=$proveedor_id_editar" : ""));
        exit;
    }
    
    $proveedor_id_guardar = isset($_POST['proveedor_id']) && !empty($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : 0;

if ($es_proveedor) {
    $proveedor_id_guardar = $proveedor_id_actual;
}

// Verificar que el proveedor existe (si no es global)
if ($proveedor_id_guardar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_guardar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/carrito.php');
        exit;
    }
    $stmt_check->close();
}
    
    // Validar y sanitizar el valor
    $tiempo_expiracion = isset($_POST['tiempo_expiracion']) ? intval($_POST['tiempo_expiracion']) : 24;
    $tiempo_expiracion = max(1, min(168, $tiempo_expiracion)); // Entre 1 y 168 horas
    
    // Guardar en configuracion con proveedor_id
    $sql = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
            VALUES ('tiempo_expiracion', 'carrito', ?, 'numero', 1, ?) 
            ON DUPLICATE KEY UPDATE valor = VALUES(valor)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $tiempo_expiracion, $proveedor_id_guardar);
    $stmt->execute();
    $stmt->close();
    
    $_SESSION['mensaje'] = "✅ Configuración de carrito guardada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    
    $redirect_url = "/configuracion/carrito.php";
    if ($proveedor_id_guardar != 0) {
        $redirect_url .= "?proveedor_id=" . $proveedor_id_guardar;
    }
    header("Location: " . $redirect_url);
    exit;
}

// ============================================
// RECIBIR MENSAJES DE SESIÓN
// ============================================
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// OBTENER LISTA DE PROVEEDORES (PARA ADMIN)
// ============================================
if ($es_admin) {
    $sql_proveedores = "SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda";
    $proveedores_list = $conn->query($sql_proveedores);
}

// ============================================
// OBTENER CONFIGURACIÓN ACTUAL
// ============================================
$tiempo_expiracion = 24; // Valor por defecto
$tipo_config = 'global';

if ($proveedor_id_editar != 0) {
    // Buscar configuración del proveedor
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'tiempo_expiracion' AND proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $tiempo_expiracion = $row['valor'];
        $tipo_config = 'personalizado';
    } else {
        // Si no tiene, buscar global
        $stmt2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'tiempo_expiracion' AND proveedor_id = 0");
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        if ($row2 = $result2->fetch_assoc()) {
            $tiempo_expiracion = $row2['valor'];
            $tipo_config = 'global';
        }
    }
    $stmt->close();
} else {
    // Buscar global
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'tiempo_expiracion' AND proveedor_id = 0");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $tiempo_expiracion = $row['valor'];
        $tipo_config = 'global';
    }
    $stmt->close();
}

// Obtener valor global para referencia
$valor_global = 24;
$stmt_global = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'tiempo_expiracion' AND proveedor_id = 0");
$stmt_global->execute();
$result_global = $stmt_global->get_result();
if ($row_global = $result_global->fetch_assoc()) {
    $valor_global = $row_global['valor'];
}
$stmt_global->close();

// ============================================
// INCLUIR HEADER
// ============================================
require_once '../header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración del Carrito - Catalejo</title>
    <style>
        * { box-sizing: border-box; }
        .container { max-width: 800px; margin: 2rem auto; padding: 0 1rem; }
        @media (max-width: 768px) { .container { margin: 1rem auto; padding: 0 0.8rem; } }
        
        .card { background: white; border-radius: 16px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }
        @media (max-width: 768px) { .card { padding: 1rem; } }
        
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem; }
        .header h2 { font-size: 1.3rem; color: #1e293b; margin: 0; }
        @media (max-width: 768px) { .header h2 { font-size: 1.1rem; } }
        
        .subtext { color: #475569; font-size: 0.9rem; margin-bottom: 1.5rem; }
        @media (max-width: 768px) { .subtext { font-size: 0.8rem; margin-bottom: 1rem; } }
        
        .btn-volver { padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 0.85rem; transition: all 0.3s; }
        .btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }
        
        .selector-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; align-items: center; gap: 0.8rem; }
        .selector-proveedor label { font-weight: 600; color: #334155; }
        .selector-proveedor select { padding: 0.5rem 1rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; flex: 1; min-width: 200px; background: white; }
        .selector-proveedor .info { color: #64748b; font-size: 0.85rem; }
        
        .info-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #dbeafe; border-radius: 8px; border: 1px solid #bfdbfe; }
        .info-proveedor strong { color: #1e40af; }
        
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 0.3rem; color: #334155; font-size: 0.95rem; }
        .form-group .desc { font-size: 0.85rem; color: #64748b; margin-bottom: 0.5rem; }
        .form-group .input-group { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; }
        .form-group input[type="number"] { width: 120px; padding: 0.6rem 0.8rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; transition: all 0.3s; }
        .form-group input[type="number"]:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }
        .form-group .input-label { color: #64748b; font-size: 0.9rem; }
        .form-group .help-text { font-size: 0.75rem; color: #94a3b8; margin-top: 0.3rem; }
        
        .badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.7rem; font-weight: 600; }
        .badge.global { background: #dbeafe; color: #1e40af; }
        .badge.personalizado { background: #fef3c7; color: #92400e; }
        .badge.default { background: #f1f5f9; color: #475569; }
        
        .btn-guardar { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; padding: 0.8rem 2rem; border-radius: 30px; font-weight: 600; cursor: pointer; transition: 0.3s; float: right; font-size: 0.95rem; }
        .btn-guardar:hover { opacity: 0.9; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
        @media (max-width: 768px) { .btn-guardar { width: 100%; float: none; padding: 0.8rem; } }
        
        .clearfix::after { content: ""; clear: both; display: table; }
        
        .mensaje { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-size: 0.85rem; max-width: 500px; margin: 0 auto; }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; margin: 0; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        .mensaje.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        .info-box { background: #dbeafe; padding: 1rem; border-radius: 8px; border: 1px solid #bfdbfe; margin-top: 1rem; }
        .info-box p { color: #1e40af; margin: 0; font-size: 0.85rem; }
        .info-box strong { color: #1e40af; }
        
        .empty-state { padding: 2rem; text-align: center; color: #94a3b8; }
        .text-center { text-align: center; }
        .mt-2 { margin-top: 1.5rem; }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <div class="header">
            <h2>🛒 Configuración del Carrito</h2>
            <a href="../configuracion.php" class="btn-volver">← Volver</a>
        </div>
        <div class="subtext">
            Define el tiempo que los carritos permanecen activos antes de ser eliminados automáticamente.
        </div>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
        <?php endif; ?>
        
        <?php if ($es_admin): ?>
        <div class="selector-proveedor">
            <label for="sel_proveedor"><strong>🏪 Proveedor:</strong></label>
            <select id="sel_proveedor" onchange="window.location.href = this.value">
                <option value="/configuracion/carrito.php">📊 Global (Sistema)</option>
                <?php 
                if ($proveedores_list) {
                    $proveedores_list->data_seek(0);
                    while($prov = $proveedores_list->fetch_assoc()): 
                ?>
                    <option value="/configuracion/carrito.php?proveedor_id=<?php echo $prov['id']; ?>" 
                            <?php echo ($proveedor_id_editar == $prov['id']) ? 'selected' : ''; ?>>
                        🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                    </option>
                <?php 
                    endwhile;
                }
                ?>
            </select>
            <?php if ($proveedor_id_editar != 0): ?>
                <span class="info">Editando proveedor ID: <?php echo $proveedor_id_editar; ?></span>
            <?php else: ?>
                <span class="info">Editando configuración global</span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($es_proveedor): ?>
        <div class="info-proveedor">
            <strong>🏪 Tu Tienda:</strong> <?php echo htmlspecialchars($proveedor_id_actual); ?>
        </div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <?php if ($proveedor_id_editar): ?>
                <input type="hidden" name="proveedor_id" value="<?php echo $proveedor_id_editar; ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label>Tiempo de expiración del carrito</label>
                <div class="desc">
                    <?php if ($proveedor_id_editar != 0): ?>
                        <span class="badge personalizado">Personalizado</span>
                    <?php else: ?>
                        <span class="badge global">Global</span>
                    <?php endif; ?>
                    Los carritos se eliminarán automáticamente después de este tiempo.
                </div>
                <div class="input-group">
                    <input type="number" name="tiempo_expiracion" 
                           value="<?php echo htmlspecialchars($tiempo_expiracion); ?>" 
                           step="1" min="1" max="168" required>
                    <span class="input-label">horas</span>
                </div>
                <div class="help-text">
                    <?php if ($proveedor_id_editar != 0): ?>
                        El valor global es <strong><?php echo $valor_global; ?></strong> horas.
                    <?php else: ?>
                        Este valor aplica a todo el sistema.
                    <?php endif; ?>
                    (Mínimo 1 hora, máximo 168 horas / 7 días)
                </div>
            </div>
            
            <div class="info-box">
                <p>💡 <strong>Consejo:</strong> Los carritos expirados se eliminan automáticamente y los productos vuelven al stock. Cada proveedor puede tener su propio tiempo de expiración.</p>
            </div>
            
            <div class="clearfix">
                <button type="submit" name="guardar_config" class="btn-guardar">
                    💾 Guardar Configuración
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Auto-cerrar mensajes
setTimeout(function() {
    const mensaje = document.querySelector('.mensaje');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(function() {
            if (mensaje) mensaje.remove();
        }, 500);
    }
}, 5000);
</script>

<?php
$conn->close();
?>
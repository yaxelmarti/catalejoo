<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol']);
$es_proveedor = esRolProveedor($_SESSION['rol']);

if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// Validar que el proveedor existe y está activo
if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// OBTENER PROVEEDOR A EDITAR
// ============================================
$proveedor_id_editar = 0;

if ($es_proveedor) {
    $proveedor_id_editar = $proveedor_id_usuario;
} else {
    if (isset($_GET['proveedor_id']) && is_numeric($_GET['proveedor_id'])) {
        $proveedor_id_editar = intval($_GET['proveedor_id']);
    }
}

// Si es administrador y está editando un proveedor específico, verificar que existe
$es_admin = in_array($_SESSION['rol'], ['Super Admin', 'Gerente']);
if ($es_admin && $proveedor_id_editar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_editar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/email.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// MENSAJES
// ============================================
$mensaje = '';
$tipo_mensaje = '';
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// LISTA DE PROVEEDORES (PARA SELECTOR)
// ============================================
if (!$es_proveedor) {
    $sql_proveedores = "SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda";
    $proveedores_list = $conn->query($sql_proveedores);
}

// ============================================
// PROCESAR GUARDADO
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/email.php" . ($proveedor_id_editar ? "?proveedor_id=$proveedor_id_editar" : ""));
        exit;
    }
    
   $proveedor_id_guardar = isset($_POST['proveedor_id']) && !empty($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : 0;

if ($es_proveedor) {
    $proveedor_id_guardar = $proveedor_id_usuario;
}

// Verificar que el proveedor existe (si no es global)
if ($proveedor_id_guardar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_guardar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/email.php');
        exit;
    }
    $stmt_check->close();
}
    
    foreach ($_POST as $clave => $valor) {
        if (strpos($clave, 'config_') === 0) {
            $clave_real = substr($clave, 7);
            
            // Solo guardar campos de email
            $campos_permitidos = ['smtp_host', 'smtp_port', 'smtp_user', 'smtp_pass', 'smtp_encryption'];
            if (!in_array($clave_real, $campos_permitidos)) {
                continue;
            }
            
            // Determinar tipo
            $tipo = 'texto';
            if ($clave_real == 'smtp_port') {
                $tipo = 'numero';
                $valor = intval($valor);
            } else {
                $valor = trim(htmlspecialchars(strip_tags($valor)));
            }
            
            $sql = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
                    VALUES (?, 'email', ?, ?, 1, ?) 
                    ON DUPLICATE KEY UPDATE valor = VALUES(valor)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $clave_real, $valor, $tipo, $proveedor_id_guardar);
            $stmt->execute();
            $stmt->close();
        }
    }
    
    $_SESSION['mensaje'] = "✅ Configuración de email guardada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    
    $redirect_url = "/configuracion/email.php";
    if ($proveedor_id_guardar != 0) {
        $redirect_url .= "?proveedor_id=" . $proveedor_id_guardar;
    }
    header("Location: " . $redirect_url);
    exit;
}

// ============================================
// DEFINIR TODOS LOS CAMPOS DE EMAIL
// ============================================
$campos_email = [
    'smtp_host' => ['etiqueta' => 'Servidor SMTP', 'descripcion' => 'Servidor SMTP para envío de emails', 'tipo' => 'texto'],
    'smtp_port' => ['etiqueta' => 'Puerto SMTP', 'descripcion' => 'Puerto SMTP', 'tipo' => 'numero'],
    'smtp_user' => ['etiqueta' => 'Usuario SMTP', 'descripcion' => 'Usuario SMTP', 'tipo' => 'texto'],
    'smtp_pass' => ['etiqueta' => 'Contraseña SMTP', 'descripcion' => 'Contraseña SMTP', 'tipo' => 'password'],
    'smtp_encryption' => ['etiqueta' => 'Encriptación SMTP', 'descripcion' => 'Encriptación SMTP', 'tipo' => 'select']
];

// ============================================
// OBTENER VALORES GUARDADOS
// ============================================
$valores_guardados = [];

if ($proveedor_id_editar != 0) {
    $sql = "SELECT clave, valor FROM configuracion WHERE grupo = 'email' AND proveedor_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $valores_guardados[$row['clave']] = $row['valor'];
    }
    $stmt->close();
} else {
    $sql = "SELECT clave, valor FROM configuracion WHERE grupo = 'email' AND proveedor_id = 0";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $valores_guardados[$row['clave']] = $row['valor'];
    }
}

// ============================================
// CONSTRUIR LISTA DE ITEMS
// ============================================
$items_list = [];
foreach ($campos_email as $clave => $campo) {
    $item = $campo;
    $item['clave'] = $clave;
    $item['valor'] = isset($valores_guardados[$clave]) ? $valores_guardados[$clave] : '';
    $items_list[] = $item;
}

// ============================================
// HEADER
// ============================================
require_once '../header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración de Email</title>
    <style>
        .container { max-width: 1000px; margin: 2rem auto; padding: 0 2rem; }
        .card { background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        .header h2 { color: #1e293b; }
        .btn-volver { padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-decoration: none; border-radius: 8px; }
        .selector { margin-bottom: 1.5rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; }
        .selector select { padding: 0.5rem 1rem; border: 2px solid #e2e8f0; border-radius: 8px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .item { padding: 1rem; background: #f8fafc; border-radius: 8px; }
        .item label { font-weight: 600; display: block; margin-bottom: 0.3rem; }
        .item .desc { font-size: 0.8rem; color: #64748b; margin-bottom: 0.5rem; }
        .item input, .item select { width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 6px; box-sizing: border-box; }
        .pw-wrapper { position: relative; }
        .pw-wrapper input { width: 100%; padding: 0.5rem; padding-right: 2.5rem; border: 2px solid #e2e8f0; border-radius: 6px; box-sizing: border-box; }
        .pw-toggle { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; background: none; border: none; }
        .info-box { background: #e6f7ff; padding: 1rem; border-radius: 8px; margin-top: 1rem; }
        .btn-guardar { background: linear-gradient(135deg, #667eea, #764ba2); color: white; border: none; padding: 0.8rem 2rem; border-radius: 8px; cursor: pointer; font-weight: 600; float: right; margin-top: 1.5rem; }
        .clearfix::after { content: ""; clear: both; display: table; }
        .mensaje { padding: 1rem; border-radius: 8px; margin-bottom: 1rem; }
        .mensaje.exito { background: #dcfce7; color: #166534; border-left: 4px solid #22c55e; }
        .mensaje.error { background: #fee2e2; color: #991b1b; border-left: 4px solid #ef4444; }
        .info-proveedor { background: #dbeafe; padding: 1rem; border-radius: 8px; border: 1px solid #bfdbfe; margin-bottom: 1.5rem; }
        .badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.7rem; }
        .badge.azul { background: #dbeafe; color: #1e40af; }
        .badge.verde { background: #dcfce7; color: #166534; }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="header">
            <h2>📧 Configuración de Email</h2>
            <a href="../configuracion.php" class="btn-volver">← Volver</a>
        </div>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
        <?php endif; ?>
        
        <?php if (!$es_proveedor): ?>
        <div class="selector">
            <label for="sel_proveedor">🏪 Proveedor:</label>
            <select id="sel_proveedor" onchange="window.location.href = this.value">
                <option value="/configuracion/email.php">📊 Global (Sistema)</option>
                <?php 
                if ($proveedores_list) {
                    $proveedores_list->data_seek(0);
                    while($prov = $proveedores_list->fetch_assoc()): 
                ?>
                    <option value="/configuracion/email.php?proveedor_id=<?php echo $prov['id']; ?>" 
                            <?php echo ($proveedor_id_editar == $prov['id']) ? 'selected' : ''; ?>>
                        🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                    </option>
                <?php 
                    endwhile;
                }
                ?>
            </select>
            <?php if ($proveedor_id_editar != 0): ?>
                <span style="margin-left: 1rem; color: #64748b;">Proveedor ID: <?php echo $proveedor_id_editar; ?></span>
            <?php else: ?>
                <span style="margin-left: 1rem; color: #64748b;">Configuración Global</span>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <div class="info-proveedor">🏪 Tu Tienda (ID: <?php echo $proveedor_id_usuario; ?>)</div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="proveedor_id" value="<?php echo $proveedor_id_editar; ?>">
            
            <div class="grid">
                <?php foreach ($items_list as $item): 
                    $clave = $item['clave'];
                    $etiqueta = $item['etiqueta'] ?? $clave;
                    $valor = isset($item['valor']) ? $item['valor'] : '';
                ?>
                    <div class="item">
                        <label><?php echo htmlspecialchars($etiqueta); ?></label>
                        <div class="desc"><?php echo htmlspecialchars($item['descripcion'] ?? ''); ?></div>
                        
                        <?php if ($clave == 'smtp_encryption'): ?>
                            <select name="config_<?php echo $clave; ?>">
                                <option value="tls" <?php echo $valor == 'tls' ? 'selected' : ''; ?>>TLS</option>
                                <option value="ssl" <?php echo $valor == 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                <option value="none" <?php echo $valor == 'none' ? 'selected' : ''; ?>>Sin encriptación</option>
                            </select>
                        <?php elseif ($clave == 'smtp_pass'): ?>
                            <div class="pw-wrapper">
                                <input type="password" id="smtp_pass" name="config_<?php echo $clave; ?>" value="<?php echo htmlspecialchars($valor); ?>">
                                <button type="button" class="pw-toggle" onclick="togglePassword('smtp_pass')">👁️</button>
                            </div>
                        <?php elseif ($clave == 'smtp_port'): ?>
                            <input type="number" name="config_<?php echo $clave; ?>" value="<?php echo htmlspecialchars($valor); ?>" step="1" min="1" max="65535">
                        <?php else: ?>
                            <input type="text" name="config_<?php echo $clave; ?>" value="<?php echo htmlspecialchars($valor); ?>">
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="info-box">
                <p>📧 <strong>Gmail:</strong> Host: smtp.gmail.com | Puerto: 587 | Encriptación: TLS</p>
            </div>
            
            <div class="clearfix">
                <button type="submit" name="guardar_config" class="btn-guardar">💾 Guardar</button>
            </div>
        </form>
    </div>
</div>

<script>
function togglePassword(id) {
    const input = document.getElementById(id);
    const btn = input.nextElementSibling;
    if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = '🙈';
    } else {
        input.type = 'password';
        btn.textContent = '👁️';
    }
}
</script>
<?php $conn->close(); ?>
<?php
require_once '../header.php';
require_once '../conexion.php';

if (!in_array($_SESSION['rol'], ['Super Admin', 'Admin'])) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    
    foreach ($_POST as $clave => $valor) {
        if (strpos($clave, 'config_') === 0) {
            $clave_real = substr($clave, 7);
            
            if ($valor === 'on') {
                $valor = 1;
            }
            
            $stmt = $conn->prepare("UPDATE configuracion SET valor = ?, fecha_actualizacion = NOW() WHERE clave = ?");
            if ($stmt) {
                $stmt->bind_param("ss", $valor, $clave_real);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
    
    $_SESSION['mensaje'] = "✅ Configuración guardada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
   echo '<script>window.location.href = "../configuracion.php";</script>';
    exit;
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

$items = $conn->query("SELECT * FROM configuracion WHERE grupo = 'email' AND visible = 1 ORDER BY orden");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Configuración - Email SMTP</title>
    <link rel="stylesheet" href="../estilo.css">
    <style>
        :root { --primary: #667eea; --secondary: #764ba2; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #f8fafc; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
        
        .config-container { width: 100%; max-width: 1000px; margin: 1rem auto; padding: 0 1rem; }
        @media (min-width: 768px) { .config-container { margin: 2rem auto; padding: 0 2rem; } }
        
        .config-card { background: white; border-radius: 20px; padding: 1.25rem; box-shadow: 0 4px 20px rgba(0,0,0,0.05); width: 100%; }
        @media (min-width: 768px) { .config-card { padding: 2rem; } }
        
        .config-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
        .config-header h2 { font-size: 1.3rem; color: #2d3748; display: flex; align-items: center; gap: 0.5rem; }
        @media (min-width: 768px) { .config-header h2 { font-size: 1.5rem; } }
        
        .btn-volver { padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; font-size: 0.85rem; }
        .btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }
        
        .config-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; }
        @media (min-width: 640px) { .config-grid { grid-template-columns: repeat(2, 1fr); gap: 1.25rem; } }
        
        .config-item { padding: 0.9rem; background: #f8fafc; border-radius: 12px; transition: all 0.3s ease; width: 100%; }
        @media (min-width: 768px) { .config-item { padding: 1rem; } }
        .config-item:hover { background: #edf2f7; transform: translateX(5px); }
        
        .config-label { font-weight: 600; margin-bottom: 0.5rem; color: #2d3748; font-size: 0.9rem; }
        @media (min-width: 768px) { .config-label { font-size: 1rem; } }
        
        .config-desc { font-size: 0.75rem; color: #718096; margin-bottom: 0.5rem; }
        @media (min-width: 768px) { .config-desc { font-size: 0.85rem; } }
        
        .config-input { width: 100%; padding: 0.7rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; transition: all 0.3s; }
        @media (min-width: 768px) { .config-input { padding: 0.8rem; font-size: 0.95rem; } }
        .config-input:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }
        
        .config-select { width: 100%; padding: 0.7rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; background: white; cursor: pointer; }
        @media (min-width: 768px) { .config-select { padding: 0.8rem; font-size: 0.95rem; } }
        .config-select:focus { border-color: var(--primary); outline: none; }
        
        /* Campo de contraseña con ojo */
        .password-wrapper { position: relative; margin-top: 0.5rem; }
        .password-wrapper input { width: 100%; padding: 0.7rem; padding-right: 2.5rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; font-family: monospace; }
        @media (min-width: 768px) { .password-wrapper input { padding: 0.8rem; padding-right: 2.5rem; font-size: 0.95rem; } }
        .password-wrapper input:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }
        .toggle-password { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 1.2rem; background: none; border: none; color: #718096; }
        .toggle-password:hover { color: var(--primary); }
        
        .info-box { background: #e6f7ff; border-left: 4px solid var(--primary); padding: 1rem; border-radius: 8px; margin-top: 1rem; }
        .info-box p { color: #2c5282; font-size: 0.85rem; margin: 0; }
        .info-box a { color: var(--primary); text-decoration: none; }
        .info-box a:hover { text-decoration: underline; }
        
        .btn-guardar { width: 100%; padding: 0.8rem; margin-top: 1.5rem; font-size: 1rem; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; border-radius: 50px; cursor: pointer; transition: all 0.3s; font-weight: 600; }
        @media (min-width: 768px) { .btn-guardar { width: auto; float: right; padding: 0.8rem 2rem; margin-top: 2rem; } }
        .btn-guardar:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
        
        .clearfix::after { content: ""; clear: both; display: table; }
        
        .mensaje { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; word-break: break-word; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-size: 0.85rem; }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        .mensaje.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    </style>
</head>
<body>
    <div class="config-container">
        <div class="config-card">
            <div class="config-header">
                <h2>📧 Configuración de Email SMTP</h2>
                <a href="../configuracion.php" class="btn-volver">← Volver</a>
            </div>
            
            <?php if ($mensaje): ?>
                <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="config-grid">
                    <?php while($item = $items->fetch_assoc()): 
                        $clave = $item['clave'];
                        $etiqueta = $item['etiqueta'] ?? $clave;
                    ?>
                        <div class="config-item">
                            <label class="config-label"><?php echo $etiqueta; ?></label>
                            <div class="config-desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                            
                            <?php if ($clave == 'smtp_encryption'): ?>
                                <select class="config-select" name="config_<?php echo $clave; ?>" style="margin-top: 0.5rem;">
                                    <option value="tls" <?php echo $item['valor'] == 'tls' ? 'selected' : ''; ?>>TLS (Recomendado)</option>
                                    <option value="ssl" <?php echo $item['valor'] == 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                    <option value="none" <?php echo $item['valor'] == 'none' ? 'selected' : ''; ?>>Sin encriptación</option>
                                </select>
                            <?php elseif ($clave == 'smtp_pass'): ?>
                                <div class="password-wrapper">
                                    <input type="password" id="smtp_pass" name="config_<?php echo $clave; ?>" 
                                           value="<?php echo htmlspecialchars($item['valor']); ?>" 
                                           placeholder="Contraseña de aplicación">
                                    <button type="button" class="toggle-password" onclick="togglePassword('smtp_pass')">👁️</button>
                                </div>
                            <?php elseif ($clave == 'smtp_port'): ?>
                                <input type="number" class="config-input" name="config_<?php echo $clave; ?>" 
                                       value="<?php echo htmlspecialchars($item['valor']); ?>" 
                                       step="1" min="1" max="65535" style="margin-top: 0.5rem;">
                            <?php else: ?>
                                <input type="text" class="config-input" name="config_<?php echo $clave; ?>" 
                                       value="<?php echo htmlspecialchars($item['valor']); ?>" 
                                       style="margin-top: 0.5rem;">
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
                
                <div class="info-box">
                    <p>📧 <strong>Configuración para Gmail:</strong><br>
                    - Host: smtp.gmail.com<br>
                    - Puerto: 587 (TLS) o 465 (SSL)<br>
                    - Encriptación: TLS<br>
                    - Usuario: tuemail@gmail.com<br>
                    - Contraseña: <strong>Contraseña de aplicación</strong> (no tu contraseña normal).<br>
                    <a href="https://myaccount.google.com/apppasswords" target="_blank">🔐 Crear contraseña de aplicación</a>
                    </p>
                </div>
                
                <div class="clearfix">
                    <button type="submit" name="guardar_config" class="btn-guardar">
                        💾 Guardar Configuración
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const button = input.nextElementSibling;
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈';
            } else {
                input.type = 'password';
                button.textContent = '👁️';
            }
        }
        
        setTimeout(function() {
            const mensaje = document.querySelector('.mensaje');
            if (mensaje) {
                mensaje.style.opacity = '0';
                setTimeout(() => { if (mensaje) mensaje.remove(); }, 300);
            }
        }, 5000);
    </script>
</body>
</html>
<?php
// ============================================
// CONFIGURACIÓN DE MONEDAS Y TASAS
// Proveedor: activa sus monedas + define tasas
// Admin: selecciona proveedor o modo global + gestionar monedas
// Fuente de verdad: tazas_cambio + proveedor_monedas + proveedor_tasas
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS - SOLO ADMIN Y GERENTE
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente'];
if (!in_array($_SESSION['rol'], $roles_permitidos, true)) {
    $_SESSION['mensaje'] = '❌ No tienes permiso para acceder a la configuración de tasas.';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /configuracion.php');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_actual = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol']);
$es_proveedor = esRolProveedor($_SESSION['rol']);
$es_admin = in_array($_SESSION['rol'], ['Super Admin', 'Gerente']);

// ============================================
// DETERMINAR PROVEEDOR A EDITAR (SOLO ADMIN)
// ============================================
$proveedor_id_editar = 0;
$modo_global = false;

if (isset($_GET['proveedor_id']) && is_numeric($_GET['proveedor_id'])) {
    $proveedor_id_editar = intval($_GET['proveedor_id']);
} elseif (isset($_GET['modo']) && $_GET['modo'] === 'global') {
    $modo_global = true;
}

// Verificar que el proveedor existe
if ($proveedor_id_editar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_editar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/tasas.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// CARGAR MONEDAS DEL SISTEMA (dinámico)
// ============================================
$monedas_sistema = [];
$moneda_predeterminada = 'USD';

$stmt = $conn->prepare("SELECT codigo, nombre, simbolo, tasa, predeterminada 
                        FROM tazas_cambio 
                        WHERE activo = 1 
                        ORDER BY predeterminada DESC, codigo ASC");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $monedas_sistema[$row['codigo']] = $row;
    if ($row['predeterminada'] == 1) {
        $moneda_predeterminada = $row['codigo'];
    }
}
$stmt->close();

// ============================================
// PROCESAR GUARDAR
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_tasas'])) {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/tasas.php");
        exit;
    }
    
    $proveedor_id_guardar = isset($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : 0;
    $guardar_global = isset($_POST['modo_global']) && $_POST['modo_global'] == '1';
    
    if ($es_proveedor) {
        $proveedor_id_guardar = $proveedor_id_actual;
        $guardar_global = false;
    }
    
    // ============================================
    // MODO GLOBAL — dinámico (todas las monedas activas ≠ predeterminada)
    // ============================================
    if ($guardar_global && $es_admin) {
        
        $actualizadas = 0;
        foreach ($monedas_sistema as $codigo => $info) {
            if ($codigo === $moneda_predeterminada) continue;
            
            $campo_post = 'global_tasa_' . $codigo;
            if (!isset($_POST[$campo_post])) continue;
            
            $tasa_post = floatval($_POST[$campo_post]);
            if ($tasa_post <= 0) continue;
            
            $stmt = $conn->prepare("UPDATE tazas_cambio SET tasa = ? WHERE codigo = ?");
            $stmt->bind_param("ds", $tasa_post, $codigo);
            $stmt->execute();
            $stmt->close();
            $actualizadas++;
        }
        
        $_SESSION['mensaje'] = "✅ Tasas globales actualizadas ($actualizadas monedas)";
        $_SESSION['tipo_mensaje'] = "exito";
        header("Location: /configuracion/tasas.php?modo=global");
        exit;
    }
    
    // ============================================
    // MODO PROVEEDOR — dinámico
    // ============================================
    if ($proveedor_id_guardar <= 0) {
        $_SESSION['mensaje'] = '❌ Proveedor inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/tasas.php");
        exit;
    }
    
    // Verificar proveedor
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_guardar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor no existe';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/tasas.php");
        exit;
    }
    $stmt_check->close();
    
    $errores = [];
    
    // Monedas recibidas del formulario (checkboxes: monedas[])
    $monedas_post = isset($_POST['monedas']) && is_array($_POST['monedas']) 
        ? array_map('trim', $_POST['monedas']) 
        : [];
    
    // Validar que todas las monedas recibidas existan en tazas_cambio
    foreach ($monedas_post as $codigo) {
        if (!isset($monedas_sistema[$codigo])) {
            $errores[] = "Moneda desconocida: " . htmlspecialchars($codigo);
        }
    }
    
        // Al menos una moneda activa (cualquiera, no necesariamente USD)
    if (empty($monedas_post)) {
        $errores[] = "Debes tener al menos una moneda de venta activa";
    }
    
    // Nota: el proveedor puede activar/desactivar cualquier moneda (incluida USD).
    // La moneda base solo se usa para conversión interna de precios.
    
    // Validar tasas de monedas NO predeterminadas
    $tasas_a_guardar = [];
    foreach ($monedas_post as $codigo) {
        if ($codigo === $moneda_predeterminada) continue;
        
        $usa_global = isset($_POST["usa_global_$codigo"]) && $_POST["usa_global_$codigo"] == '1' ? 1 : 0;
        $tasa = $usa_global ? 1.0 : floatval($_POST["tasa_$codigo"] ?? 0);
        
        if (!$usa_global && $tasa <= 0) {
            $errores[] = "La tasa de $codigo debe ser mayor a 0";
            continue;
        }
        
        $tasas_a_guardar[$codigo] = [
            'tasa' => $tasa,
            'usa_tasa_global' => $usa_global
        ];
    }
    
    if (empty($errores)) {
        // ============================================
        // GUARDAR EN proveedor_monedas (activo=1 marcadas, activo=0 resto)
        // ============================================
        foreach ($monedas_sistema as $codigo => $info) {
            $activo = in_array($codigo, $monedas_post) ? 1 : 0;
            
            $sql = "INSERT INTO proveedor_monedas (proveedor_id, moneda, activo) 
                    VALUES (?, ?, ?) 
                    ON DUPLICATE KEY UPDATE activo = VALUES(activo)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isi", $proveedor_id_guardar, $codigo, $activo);
            $stmt->execute();
            $stmt->close();
        }
        
        // ============================================
        // GUARDAR TASAS EN proveedor_tasas
        // ============================================
                // La moneda base (USD) siempre existe en proveedor_tasas con tasa=1
        // (para cuando se use como referencia de conversión interna)
        $sql_base = "INSERT INTO proveedor_tasas (proveedor_id, moneda, tasa, usa_tasa_global) 
                     VALUES (?, ?, 1.0000, 1) 
                     ON DUPLICATE KEY UPDATE tasa = 1.0000, usa_tasa_global = 1";
        $stmt = $conn->prepare($sql_base);
        $stmt->bind_param("is", $proveedor_id_guardar, $moneda_predeterminada);
        $stmt->execute();
        $stmt->close();
        
        // Resto de monedas activas
        foreach ($tasas_a_guardar as $codigo => $data) {
            $sql = "INSERT INTO proveedor_tasas (proveedor_id, moneda, tasa, usa_tasa_global) 
                    VALUES (?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE tasa = VALUES(tasa), usa_tasa_global = VALUES(usa_tasa_global)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isdi", $proveedor_id_guardar, $codigo, $data['tasa'], $data['usa_tasa_global']);
            $stmt->execute();
            $stmt->close();
        }
        
        // Borrar tasas de monedas desactivadas (≠ predeterminada)
       // NUEVO: no borrar si la moneda es de adquisición (consultado en BD)
           $monedas_adquisicion_bd = [];
           $stmt_adq = $conn->prepare("SELECT moneda FROM proveedor_monedas WHERE proveedor_id = ? AND permite_adquisicion = 1");
           $stmt_adq->bind_param("i", $proveedor_id_guardar);
           $stmt_adq->execute();
           $res_adq = $stmt_adq->get_result();
      while ($row_adq = $res_adq->fetch_assoc()) {
           $monedas_adquisicion_bd[] = $row_adq['moneda'];
        }
          $stmt_adq->close();

foreach ($monedas_sistema as $codigo => $info) {
    if ($codigo === $moneda_predeterminada) continue;
    if (in_array($codigo, $monedas_post)) continue;
    if (in_array($codigo, $monedas_adquisicion_bd)) continue; // NUEVO
    
    $stmt = $conn->prepare("DELETE FROM proveedor_tasas WHERE proveedor_id = ? AND moneda = ?");
    $stmt->bind_param("is", $proveedor_id_guardar, $codigo);
    $stmt->execute();
    $stmt->close();
}
  }
    
    if (!empty($errores)) {
        $_SESSION['mensaje'] = '❌ ' . implode('<br>', $errores);
        $_SESSION['tipo_mensaje'] = 'error';
    } else {
        $_SESSION['mensaje'] = "✅ Monedas y tasas guardadas correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
    }
    
    $redirect_url = "/configuracion/tasas.php?proveedor_id=" . $proveedor_id_guardar;
    header("Location: " . $redirect_url);
    exit;
}

// ============================================
// RECIBIR MENSAJES DE SESIÓN
// ============================================
$mensaje = '';
$tipo_mensaje = '';
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// OBTENER LISTA DE PROVEEDORES (PARA ADMIN)
// ============================================
$proveedores_list = null;
if ($es_admin) {
    $sql_proveedores = "SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda";
    $proveedores_list = $conn->query($sql_proveedores);
}

// ============================================
// OBTENER DATOS DEL PROVEEDOR
// ============================================
$proveedor_info = null;
$monedas_proveedor = [];
$tasas_proveedor = [];

if ($proveedor_id_editar > 0) {
    // Info básica
    $stmt = $conn->prepare("SELECT id, nombre_tienda FROM proveedores WHERE id = ?");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $proveedor_info = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    // Monedas activas del proveedor (proveedor_monedas)
    $stmt = $conn->prepare("SELECT moneda FROM proveedor_monedas 
                            WHERE proveedor_id = ? AND activo = 1");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $monedas_proveedor[$row['moneda']] = true;
    }
    $stmt->close();
    
        // Sin default — el proveedor elige libremente sus monedas
    
    // Tasas del proveedor (proveedor_tasas)
    $stmt = $conn->prepare("SELECT moneda, tasa, usa_tasa_global 
                            FROM proveedor_tasas WHERE proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $tasas_proveedor[$row['moneda']] = $row;
    }
    $stmt->close();
    
    // Asegurar fila de la predeterminada
    if (!isset($tasas_proveedor[$moneda_predeterminada])) {
        $stmt = $conn->prepare("INSERT INTO proveedor_tasas (proveedor_id, moneda, tasa, usa_tasa_global) 
                                VALUES (?, ?, 1.0000, 1)");
        $stmt->bind_param("is", $proveedor_id_editar, $moneda_predeterminada);
        $stmt->execute();
        $stmt->close();
        $tasas_proveedor[$moneda_predeterminada] = [
            'moneda' => $moneda_predeterminada,
            'tasa' => 1.0000,
            'usa_tasa_global' => 1
        ];
    }
}

require_once '../header.php';
?>
<style>
* { box-sizing: border-box; }
        .container { max-width: 800px; margin: 2rem auto; padding: 0 1rem; }
        @media (max-width: 768px) { .container { margin: 1rem auto; padding: 0 0.8rem; } }
        
        .card { background: white; border-radius: 16px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; }
        @media (max-width: 768px) { .card { padding: 1rem; } }
        
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.8rem; margin-bottom: 1.5rem; }
        .header h2 { font-size: 1.3rem; color: #1e293b; margin: 0; }
        @media (max-width: 768px) { .header h2 { font-size: 1.1rem; } }
        
        .header-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        
        .subtext { color: #475569; font-size: 0.9rem; margin-bottom: 1.5rem; line-height: 1.5; }
        
        .btn-volver, .btn-gestionar {
            padding: 0.5rem 1rem;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.85rem;
            transition: all 0.3s;
            display: inline-block;
        }
        .btn-volver { background: #edf2f7; color: #4a5568; }
        .btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }
        .btn-gestionar { background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2)); color: white; }
        .btn-gestionar:hover { opacity: 0.9; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
        
        .selector-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; align-items: center; gap: 0.8rem; }
        .selector-proveedor label { font-weight: 600; color: #334155; }
        .selector-proveedor select { padding: 0.5rem 1rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; flex: 1; min-width: 200px; background: white; }
        
        .info-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #dbeafe; border-radius: 8px; border: 1px solid #bfdbfe; }
        .info-proveedor strong { color: #1e40af; }
        
        .moneda-card {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 1.2rem;
            margin-bottom: 1rem;
            transition: all 0.3s;
            background: white;
        }
        
        .moneda-card.base { background: #f1f5f9; border-color: #cbd5e1; }
        .moneda-card.desactivada { background: #f8fafc; border-color: #e2e8f0; }
        .moneda-card.desactivada .tasa-config { display: none; }
        
        .moneda-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.8rem;
            flex-wrap: wrap;
            gap: 0.8rem;
        }
        
        .moneda-titulo {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            font-size: 1.05rem;
            font-weight: 600;
            color: #1e293b;
            flex: 1;
        }
        
        .moneda-simbolo {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
            color: white;
            border-radius: 50%;
            font-size: 1.3rem;
            font-weight: bold;
            flex-shrink: 0;
        }
        
        .switch-moneda { position: relative; display: inline-block; width: 52px; height: 28px; flex-shrink: 0; }
        .switch-moneda input { opacity: 0; width: 0; height: 0; }
        .switch-slider {
            position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
            background-color: #cbd5e1; transition: .3s; border-radius: 34px;
        }
        .switch-slider:before {
            position: absolute; content: ""; height: 22px; width: 22px; left: 3px; bottom: 3px;
            background-color: white; transition: .3s; border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .switch-moneda input:checked + .switch-slider { background-color: #10b981; }
        .switch-moneda input:checked + .switch-slider:before { transform: translateX(24px); }
        .switch-moneda input:disabled + .switch-slider { opacity: 0.5; cursor: not-allowed; }
        
        .moneda-info-global {
            font-size: 0.8rem; color: #64748b; background: #f1f5f9;
            padding: 0.3rem 0.6rem; border-radius: 6px;
            display: inline-block; margin-bottom: 0.8rem;
        }
        
        .tasa-config { margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e2e8f0; }
        
        .radio-group { display: flex; flex-direction: column; gap: 0.6rem; }
        .radio-opcion {
            display: flex; align-items: center; gap: 0.6rem;
            padding: 0.6rem; border-radius: 8px; transition: background 0.2s;
        }
        .radio-opcion:hover { background: #f8fafc; }
        .radio-opcion input[type="radio"] {
            width: 18px; height: 18px; accent-color: var(--primary, #667eea);
            cursor: pointer; flex-shrink: 0;
        }
        .radio-opcion label { cursor: pointer; font-size: 0.9rem; color: #334155; flex: 1; }
        .radio-opcion input[type="number"] {
            width: 130px; padding: 0.5rem 0.7rem;
            border: 2px solid #e2e8f0; border-radius: 6px;
            font-size: 0.9rem; flex-shrink: 0;
        }
        .radio-opcion input[type="number"]:focus {
            border-color: var(--primary, #667eea); outline: none;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
        }
        .radio-opcion input[type="number"]:disabled { background: #f1f5f9; color: #94a3b8; }
        
        @media (max-width: 480px) {
            .radio-opcion { flex-wrap: wrap; }
            .radio-opcion input[type="number"] { width: 100%; }
        }
        
        .tasa-base { font-size: 1.1rem; font-weight: 700; color: #1e293b; }
        
        .mensaje {
            position: fixed; top: 20px; right: 20px; left: 20px;
            padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000;
            animation: slideIn 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            font-size: 0.85rem; max-width: 500px; margin: 0 auto;
        }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; margin: 0; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        .mensaje.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        .btn-guardar {
            background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
            color: white; border: none; padding: 0.9rem 2rem; border-radius: 30px;
            font-weight: 600; cursor: pointer; transition: 0.3s; font-size: 1rem;
            width: 100%; margin-top: 1rem;
        }
        .btn-guardar:hover { opacity: 0.9; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
        
        .empty-state { text-align: center; padding: 3rem 1rem; color: #64748b; }
        .empty-state .icono { font-size: 3rem; margin-bottom: 1rem; }
        
        .info-box { background: #dbeafe; padding: 1rem; border-radius: 8px; border: 1px solid #bfdbfe; margin-top: 1rem; }
        .info-box p { color: #1e40af; margin: 0; font-size: 0.85rem; line-height: 1.5; }
        
        .badge-activa { background: #d1fae5; color: #065f46; font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 10px; font-weight: 600; }
        .badge-inactiva { background: #fee2e2; color: #991b1b; font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 10px; font-weight: 600; }
        .badge-base { background: #dbeafe; color: #1e40af; font-size: 0.7rem; padding: 0.2rem 0.5rem; border-radius: 10px; font-weight: 600; }
    </style>

<div class="container">
    <div class="card">
        <div class="header">
            <h2>💱 Monedas y Tasas</h2>
            <div class="header-actions">
                <?php if ($es_admin): ?>
                    <a href="/configuracion/monedas.php" class="btn-gestionar">➕ Gestionar monedas</a>
                <?php endif; ?>
                <a href="../configuracion.php" class="btn-volver">← Volver</a>
            </div>
        </div>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo $mensaje; ?></div>
        <?php endif; ?>
        
        <?php if ($es_admin): ?>
        <div class="selector-proveedor">
            <label for="sel_proveedor"><strong>🏪 Proveedor:</strong></label>
            <select id="sel_proveedor" onchange="window.location.href = this.value">
                <option value="/configuracion/tasas.php" <?php echo (!$proveedor_id_editar && !$modo_global) ? 'selected' : ''; ?>>— Seleccione un proveedor —</option>
                <option value="/configuracion/tasas.php?modo=global" <?php echo $modo_global ? 'selected' : ''; ?>>📊 Configuración Global</option>
                <?php 
                if ($proveedores_list) {
                    $proveedores_list->data_seek(0);
                    while($prov = $proveedores_list->fetch_assoc()): 
                ?>
                    <option value="/configuracion/tasas.php?proveedor_id=<?php echo $prov['id']; ?>" 
                            <?php echo ($proveedor_id_editar == $prov['id']) ? 'selected' : ''; ?>>
                        🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                    </option>
                <?php 
                    endwhile;
                }
                ?>
            </select>
        </div>
        <?php endif; ?>
        
        <?php if ($es_proveedor && $proveedor_info): ?>
        <div class="info-proveedor">
            <strong>🏪 Tu Tienda:</strong> <?php echo htmlspecialchars($proveedor_info['nombre_tienda']); ?>
        </div>
        <?php endif; ?>

        <?php // ============================================ ?>
        <?php // MODO GLOBAL ?>
        <?php // ============================================ ?>
        <?php if ($modo_global && $es_admin): ?>
        
        <div class="subtext">
            Configura las <strong>tasas globales de referencia</strong>. Los proveedores que no personalicen sus tasas usarán estas.
        </div>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="modo_global" value="1">
            
            <?php foreach ($monedas_sistema as $codigo => $info): 
                $es_base = ($codigo === $moneda_predeterminada);
            ?>
            <div class="moneda-card <?php echo $es_base ? 'base' : ''; ?>">
                <div class="moneda-header">
                    <div class="moneda-titulo">
                        <span class="moneda-simbolo"><?php echo htmlspecialchars($info['simbolo']); ?></span>
                        <div>
                            <?php echo htmlspecialchars($info['nombre']); ?>
                            <?php if ($es_base): ?>
                                <span class="badge-base">Predeterminada</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($es_base): ?>
                        <span class="tasa-base">1.0000</span>
                    <?php endif; ?>
                </div>
                
                <?php if ($es_base): ?>
                    <div class="moneda-info-global">Moneda base del sistema — no editable</div>
                <?php else: ?>
                    <div class="radio-group">
                        <div class="radio-opcion">
                            <label>Tasa global (<?php echo htmlspecialchars($codigo); ?> por 1 USD):</label>
                            <input type="number" 
                                   name="global_tasa_<?php echo htmlspecialchars($codigo); ?>" 
                                   value="<?php echo htmlspecialchars($info['tasa']); ?>" 
                                   step="0.0001" min="0.0001" required>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            
            <div class="info-box">
                <p>💡 Estas tasas son las que se usarán por defecto cuando un proveedor no personalice las suyas.</p>
            </div>
            
            <button type="submit" name="guardar_tasas" class="btn-guardar">
                💾 Guardar Tasas Globales
            </button>
        </form>
        
                <?php // ============================================ ?>
        <?php // MODO PROVEEDOR ?>
        <?php // ============================================ ?>
        <?php elseif ($proveedor_info): ?>
        
        <div class="subtext">
            Activa las monedas en las que quieres vender y define sus tasas. Los precios de tus productos están en <strong><?php echo htmlspecialchars($moneda_predeterminada); ?></strong>.
        </div>
        
        <form method="POST" id="form_tasas">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="proveedor_id" value="<?php echo $proveedor_id_editar; ?>">
            
            <?php foreach ($monedas_sistema as $codigo => $info): 
                $es_base = ($codigo === $moneda_predeterminada);
                $esta_activa = isset($monedas_proveedor[$codigo]);
                $usa_global = isset($tasas_proveedor[$codigo]) ? intval($tasas_proveedor[$codigo]['usa_tasa_global']) : 1;
                $tasa_actual = isset($tasas_proveedor[$codigo]) ? floatval($tasas_proveedor[$codigo]['tasa']) : floatval($info['tasa']);
                $global_ref = floatval($info['tasa']);
            ?>
            <div class="moneda-card <?php echo $es_base ? 'base' : ''; ?> <?php echo !$esta_activa ? 'desactivada' : ''; ?>" id="card_<?php echo htmlspecialchars($codigo); ?>">
                <div class="moneda-header">
                    <div class="moneda-titulo">
                        <span class="moneda-simbolo"><?php echo htmlspecialchars($info['simbolo']); ?></span>
                        <div>
                            <?php echo htmlspecialchars($info['nombre']); ?>
                            <?php if ($es_base): ?>
                                <span class="badge-base">Base</span>
                            <?php endif; ?>
                            <span class="badge-<?php echo $esta_activa ? 'activa' : 'inactiva'; ?>" id="badge_<?php echo htmlspecialchars($codigo); ?>">
                                <?php echo $esta_activa ? 'Activa' : 'Inactiva'; ?>
                            </span>
                        </div>
                    </div>
                    <label class="switch-moneda">
                        <input type="checkbox" 
                               name="monedas[]" 
                               value="<?php echo htmlspecialchars($codigo); ?>"
                               id="check_<?php echo htmlspecialchars($codigo); ?>"
                               <?php echo $esta_activa ? 'checked' : ''; ?>
                               onchange="toggleMoneda('<?php echo htmlspecialchars($codigo); ?>')">
                        <span class="switch-slider"></span>
                    </label>
                </div>
                
                <?php if ($es_base): ?>
                    <div class="moneda-info-global">Moneda base interna para precios (puedes activarla o no)</div>
                <?php endif; ?>
                
                <div class="tasa-config" id="config_<?php echo htmlspecialchars($codigo); ?>" style="<?php echo !$esta_activa ? 'display:none;' : ''; ?>">
                    <div class="moneda-info-global">Global: <?php echo number_format($global_ref, 4); ?> <?php echo htmlspecialchars($codigo); ?> por 1 USD</div>
                    <div class="radio-group">
                        <div class="radio-opcion">
                            <input type="radio" 
                                   name="usa_global_<?php echo htmlspecialchars($codigo); ?>" 
                                   id="radio_global_<?php echo htmlspecialchars($codigo); ?>" 
                                   value="1" 
                                   <?php echo $usa_global ? 'checked' : ''; ?>
                                   onchange="toggleTasaInput('<?php echo htmlspecialchars($codigo); ?>')">
                            <label for="radio_global_<?php echo htmlspecialchars($codigo); ?>">
                                Usar tasa global (<?php echo number_format($global_ref, 4); ?>)
                            </label>
                        </div>
                        <div class="radio-opcion">
                            <input type="radio" 
                                   name="usa_global_<?php echo htmlspecialchars($codigo); ?>" 
                                   id="radio_custom_<?php echo htmlspecialchars($codigo); ?>" 
                                   value="0" 
                                   <?php echo !$usa_global ? 'checked' : ''; ?>
                                   onchange="toggleTasaInput('<?php echo htmlspecialchars($codigo); ?>')">
                            <label for="radio_custom_<?php echo htmlspecialchars($codigo); ?>">Personalizar:</label>
                            <input type="number" 
                                   name="tasa_<?php echo htmlspecialchars($codigo); ?>" 
                                   id="input_<?php echo htmlspecialchars($codigo); ?>" 
                                   value="<?php echo htmlspecialchars($tasa_actual); ?>" 
                                   step="0.0001" min="0.0001"
                                   <?php echo $usa_global ? 'disabled' : ''; ?>>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <div class="info-box">
                <p>💡 <strong>Consejo:</strong> Activa solo las monedas en las que quieras vender. Si no personalizas una tasa, se usará la global del sistema.</p>
            </div>
            
            <div id="aviso_sin_moneda" style="display:none; background: #fef3c7; border: 1px solid #fcd34d; padding: 1rem; border-radius: 8px; margin-top: 1rem; color: #92400e; font-size: 0.9rem;">
                ⚠️ Debes activar al menos una moneda de venta para guardar
            </div>
            
            <button type="submit" name="guardar_tasas" class="btn-guardar">
                💾 Guardar Monedas y Tasas
            </button>
        </form>
        
        <?php else: ?>
        
        <div class="empty-state">
            <div class="icono">🏪</div>
            <p>Selecciona un proveedor para editar sus monedas y tasas.</p>
        </div>
        
        <?php endif; ?>
        
    </div>
</div>

<script>
function toggleMoneda(codigo) {
    const checkbox = document.getElementById('check_' + codigo);
    const badge = document.getElementById('badge_' + codigo);
    const card = document.getElementById('card_' + codigo);
    const config = document.getElementById('config_' + codigo);
    
    if (!checkbox || !badge || !card) return;
    
    if (checkbox.checked) {
        badge.textContent = 'Activa';
        badge.className = 'badge-activa';
        card.classList.remove('desactivada');
        if (config) config.style.display = 'block';
    } else {
        badge.textContent = 'Inactiva';
        badge.className = 'badge-inactiva';
        card.classList.add('desactivada');
        if (config) config.style.display = 'none';
    }
    
    validarMonedas();
}

function toggleTasaInput(codigo) {
    const input = document.getElementById('input_' + codigo);
    const radioGlobal = document.getElementById('radio_global_' + codigo);
    
    if (!input) return;
    
    if (radioGlobal && radioGlobal.checked) {
        input.disabled = true;
    } else {
        input.disabled = false;
    }
}

function validarMonedas() {
    const checkboxes = document.querySelectorAll('input[name="monedas[]"]:checked');
    const btn = document.querySelector('.btn-guardar');
    const aviso = document.getElementById('aviso_sin_moneda');
    
    if (checkboxes.length === 0) {
        if (aviso) aviso.style.display = 'block';
        if (btn) {
            btn.style.opacity = '0.5';
            btn.style.cursor = 'not-allowed';
            btn.disabled = true;
        }
    } else {
        if (aviso) aviso.style.display = 'none';
        if (btn) {
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
            btn.disabled = false;
        }
    }
}

// Auto-cerrar mensajes
setTimeout(function() {
    const mensaje = document.querySelector('.mensaje');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(function() {
            if (mensaje) mensaje.remove();
        }, 500);
    }
}, 5000);

document.addEventListener('DOMContentLoaded', function() {
    validarMonedas();
});
</script>

</main>

<?php
$conn->close();
?>
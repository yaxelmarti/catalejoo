<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';

$mensaje = '';
$proveedor_id_test = 3;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $smtp_host = trim($_POST['smtp_host'] ?? '');
    $proveedor_id = intval($_POST['proveedor_id'] ?? 0);
    
    // ============================================
    // PRIMERO: ELIMINAR EL REGISTRO SI EXISTE
    // ============================================
    $sql_delete = "DELETE FROM configuracion WHERE clave = 'smtp_host' AND proveedor_id = ?";
    $stmt = $conn->prepare($sql_delete);
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $stmt->close();
    
    // ============================================
    // SEGUNDO: INSERTAR NUEVO
    // ============================================
    $sql_insert = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
                   VALUES ('smtp_host', 'email', ?, 'texto', 1, ?)";
    $stmt = $conn->prepare($sql_insert);
    $stmt->bind_param("si", $smtp_host, $proveedor_id);
    
    if ($stmt->execute()) {
        $mensaje = "✅ Guardado: smtp_host = '$smtp_host' para proveedor ID: $proveedor_id";
    } else {
        $mensaje = "❌ Error: " . $stmt->error;
    }
    $stmt->close();
}

// ============================================
// OBTENER REGISTROS
// ============================================
$registros = [];
$sql = "SELECT * FROM configuracion WHERE grupo = 'email' AND proveedor_id = ? ORDER BY clave";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $proveedor_id_test);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $registros[] = $row;
}
$stmt->close();

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Test Update</title>
    <style>
        body { font-family: Arial; max-width: 800px; margin: 2rem auto; padding: 0 1rem; }
        .card { background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); margin-bottom: 1rem; }
        .exito { background: #dcfce7; color: #166534; padding: 1rem; border-radius: 8px; }
        .error { background: #fee2e2; color: #991b1b; padding: 1rem; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #e2e8f0; }
        th { background: #f1f5f9; }
        input, button { padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 6px; }
        button { background: #667eea; color: white; border: none; cursor: pointer; }
        .badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.75rem; }
        .badge.azul { background: #dbeafe; color: #1e40af; }
    </style>
</head>
<body>

<h1>🧪 Test Update - DELETE + INSERT</h1>

<div class="card">
    <h2>📝 Guardar SMTP Host</h2>
    
    <?php if ($mensaje): ?>
        <div class="<?php echo strpos($mensaje, '✅') !== false ? 'exito' : 'error'; ?>">
            <?php echo $mensaje; ?>
        </div>
    <?php endif; ?>
    
    <form method="POST">
        <div style="margin-bottom: 1rem;">
            <label><strong>Proveedor ID:</strong></label>
            <input type="number" name="proveedor_id" value="<?php echo $proveedor_id_test; ?>" style="width: 80px;">
        </div>
        <div style="margin-bottom: 1rem;">
            <label><strong>SMTP Host:</strong></label>
            <input type="text" name="smtp_host" value="<?php echo $registros[0]['valor'] ?? ''; ?>" style="width: 300px;">
        </div>
        <button type="submit">💾 Guardar (DELETE + INSERT)</button>
    </form>
</div>

<div class="card">
    <h2>📋 Registros (proveedor_id: <?php echo $proveedor_id_test; ?>)</h2>
    
    <?php if (empty($registros)): ?>
        <p style="color: #94a3b8;">⚠️ No hay registros</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Clave</th>
                    <th>Valor</th>
                    <th>proveedor_id</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($registros as $row): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><strong><?php echo $row['clave']; ?></strong></td>
                    <td><?php echo $row['valor'] ?: '<span style="color: #94a3b8;">(vacío)</span>'; ?></td>
                    <td><span class="badge azul"><?php echo $row['proveedor_id']; ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>
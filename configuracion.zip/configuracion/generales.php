<?php
// ============================================
// CONFIGURACIÓN GENERAL - SOLO GLOBAL
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
if (!in_array($_SESSION['rol'], ['Super Admin', 'Gerente'])) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol']);
$es_proveedor = esRolProveedor($_SESSION['rol']);

// Este archivo es SOLO GLOBAL (no debe ser editado por proveedores)
if ($es_proveedor) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// Validar que el proveedor existe (si aplica)
if ($proveedor_id > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// FUNCIÓN PARA SUBIR ARCHIVOS
// ============================================
function subirArchivo($archivo, $carpeta_destino = '../uploads/') {
    // Crear carpeta si no existe
    if (!file_exists($carpeta_destino)) {
        mkdir($carpeta_destino, 0777, true);
    }
    
    $nombre_archivo = time() . '_' . basename($archivo['name']);
    $ruta_destino = $carpeta_destino . $nombre_archivo;
    
    // Validar tipo de archivo
    $extension = strtolower(pathinfo($nombre_archivo, PATHINFO_EXTENSION));
    $tipos_permitidos = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
    
    if (!in_array($extension, $tipos_permitidos)) {
        return ['success' => false, 'mensaje' => 'Tipo de archivo no permitido'];
    }
    
    // Validar tamaño (máximo 2MB)
    if ($archivo['size'] > 2 * 1024 * 1024) {
        return ['success' => false, 'mensaje' => 'El archivo no puede superar los 2MB'];
    }
    
    if (move_uploaded_file($archivo['tmp_name'], $ruta_destino)) {
        // Devolver la URL relativa
        $url = str_replace('../', '/', $ruta_destino);
        return ['success' => true, 'ruta' => $url];
    }
    
    return ['success' => false, 'mensaje' => 'Error al subir el archivo'];
}

// ============================================
// PROCESAR CONFIGURACIÓN
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    
    // ============================================
    // VERIFICAR CSRF TOKEN
    // ============================================
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/generales.php');
        exit;
    }
    
    // Procesar campos normales
    foreach ($_POST as $clave => $valor) {
        if (strpos($clave, 'config_') === 0) {
            $clave_real = substr($clave, 7);
            
            // Si es boolean y viene como 'on', convertir a 1
            if ($valor === 'on') {
                $valor = 1;
            }
            
            // Determinar tipo
            $tipo = 'texto';
            if ($clave_real == 'moneda_simbolo' || $clave_real == 'sitio_nombre' || $clave_real == 'color_primario') {
                $tipo = 'texto';
            } elseif ($clave_real == 'mantenimiento') {
                $tipo = 'boolean';
                $valor = $valor == 1 ? '1' : '0';
            } elseif ($clave_real == 'logo_url') {
                $tipo = 'imagen';
            }
            
            // Sanitizar
            if ($tipo !== 'boolean') {
                $valor = trim(htmlspecialchars(strip_tags($valor)));
            }
            
            // Guardar con INSERT ... ON DUPLICATE KEY UPDATE
            $sql = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
                    VALUES (?, 'general', ?, ?, 1, 0) 
                    ON DUPLICATE KEY UPDATE valor = VALUES(valor), fecha_actualizacion = NOW()";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sss", $clave_real, $valor, $tipo);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
    
    // ============================================
    // VERIFICAR BOOLEANOS QUE NO LLEGARON EN POST
    // ============================================
    $result_bool = $conn->query("SELECT clave FROM configuracion WHERE grupo = 'general' AND tipo = 'boolean' AND proveedor_id = 0");
    while ($row_bool = $result_bool->fetch_assoc()) {
        $clave_bool = $row_bool['clave'];
        if (!isset($_POST['config_' . $clave_bool])) {
            $sql = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
                    VALUES (?, 'general', '0', 'boolean', 1, 0) 
                    ON DUPLICATE KEY UPDATE valor = '0', fecha_actualizacion = NOW()";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("s", $clave_bool);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
    
    // ============================================
    // PROCESAR SUBIDA DE LOGO
    // ============================================
    if (isset($_FILES['config_logo_url']) && $_FILES['config_logo_url']['error'] == 0) {
        $archivo = $_FILES['config_logo_url'];
        $carpeta = '../uploads/';
        
        if (!file_exists($carpeta)) {
            mkdir($carpeta, 0777, true);
        }
        
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        $tipos_permitidos = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
        
        if (in_array($extension, $tipos_permitidos)) {
            // Validar tamaño (máximo 2MB)
            if ($archivo['size'] <= 2 * 1024 * 1024) {
                $nombre_archivo = time() . '_logo.' . $extension;
                $ruta_destino = $carpeta . $nombre_archivo;
                
                if (move_uploaded_file($archivo['tmp_name'], $ruta_destino)) {
                    $url = str_replace('../', '/', $ruta_destino);
                    
                    $sql = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
                            VALUES ('logo_url', 'general', ?, 'imagen', 1, 0) 
                            ON DUPLICATE KEY UPDATE valor = VALUES(valor), fecha_actualizacion = NOW()";
                    $stmt = $conn->prepare($sql);
                    if ($stmt) {
                        $stmt->bind_param("s", $url);
                        $stmt->execute();
                        $stmt->close();
                    }
                }
            }
        }
    }
    
    // ============================================
    // ELIMINAR LOGO SI SE MARCA LA CASILLA
    // ============================================
    if (isset($_POST['eliminar_logo_url'])) {
        $sql = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
                VALUES ('logo_url', 'general', '', 'imagen', 1, 0) 
                ON DUPLICATE KEY UPDATE valor = '', fecha_actualizacion = NOW()";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->execute();
            $stmt->close();
        }
    }
    
    $_SESSION['mensaje'] = "✅ Configuración guardada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    header('Location: ../configuracion.php');
    exit;
}

// ============================================
// RECIBIR MENSAJES DE SESIÓN
// ============================================
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// OBTENER CONFIGURACIÓN (SOLO GLOBAL)
// ============================================
$items = $conn->query("SELECT * FROM configuracion WHERE grupo = 'general' AND visible = 1 AND proveedor_id = 0 ORDER BY orden");

// ============================================
// INCLUIR HEADER
// ============================================
require_once '../header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Configuración General - Catalejo</title>
    <style>
        :root { --primary: #667eea; --secondary: #764ba2; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #f8fafc; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
        
        .config-container { width: 100%; max-width: 1000px; margin: 1rem auto; padding: 0 1rem; }
        @media (min-width: 768px) { .config-container { margin: 2rem auto; padding: 0 2rem; } }
        
        .config-card { background: white; border-radius: 20px; padding: 1.25rem; box-shadow: 0 4px 20px rgba(0,0,0,0.05); width: 100%; }
        @media (min-width: 768px) { .config-card { padding: 2rem; } }
        
        .config-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
        .config-header h2 { font-size: 1.3rem; color: #2d3748; display: flex; align-items: center; gap: 0.5rem; }
        @media (min-width: 768px) { .config-header h2 { font-size: 1.5rem; } }
        
        .btn-volver { padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; font-size: 0.85rem; display: inline-block; }
        .btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }
        
        .config-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; }
        @media (min-width: 640px) { .config-grid { grid-template-columns: repeat(2, 1fr); gap: 1.25rem; } }
        
        .config-item { padding: 0.9rem; background: #f8fafc; border-radius: 12px; transition: all 0.3s ease; width: 100%; }
        @media (min-width: 768px) { .config-item { padding: 1rem; } }
        .config-item:hover { background: #edf2f7; transform: translateX(5px); }
        
        .config-label { font-weight: 600; margin-bottom: 0.5rem; color: #2d3748; font-size: 0.9rem; display: block; }
        @media (min-width: 768px) { .config-label { font-size: 1rem; } }
        
        .config-desc { font-size: 0.75rem; color: #718096; margin-bottom: 0.5rem; }
        @media (min-width: 768px) { .config-desc { font-size: 0.85rem; } }
        
        .config-input { width: 100%; padding: 0.7rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; transition: all 0.3s; }
        @media (min-width: 768px) { .config-input { padding: 0.8rem; font-size: 0.95rem; } }
        .config-input:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }
        
        .config-color { width: 70px; height: 45px; padding: 0; border: 2px solid #e2e8f0; border-radius: 8px; cursor: pointer; }
        
        .preview-logo { max-width: 150px; max-height: 60px; margin-top: 0.5rem; border-radius: 4px; background: white; padding: 0.25rem; border: 1px solid #e2e8f0; display: block; }
        
        .checkbox-label { display: flex; align-items: center; gap: 0.5rem; margin-top: 0.5rem; cursor: pointer; font-weight: 400; }
        .checkbox-label input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; }
        
        .btn-guardar { width: 100%; padding: 0.8rem; margin-top: 1.5rem; font-size: 1rem; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; border-radius: 50px; cursor: pointer; transition: all 0.3s; font-weight: 600; }
        @media (min-width: 768px) { .btn-guardar { width: auto; float: right; padding: 0.8rem 2rem; margin-top: 2rem; } }
        .btn-guardar:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
        
        .clearfix::after { content: ""; clear: both; display: table; }
        
        .mensaje { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; word-break: break-word; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-size: 0.85rem; }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        .mensaje.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        .info-box { background: #e6f7ff; border-left: 4px solid var(--primary); padding: 1rem; border-radius: 8px; margin-top: 1rem; }
        .info-box p { color: #2c5282; font-size: 0.85rem; margin: 0; }
        
        .file-input-wrapper { margin-top: 0.5rem; }
        .file-input-wrapper input[type="file"] { width: 100%; padding: 0.4rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.8rem; }
        
        .badge-global { display: inline-block; background: #dbeafe; color: #1e40af; padding: 0.15rem 0.6rem; border-radius: 12px; font-size: 0.65rem; font-weight: 600; margin-left: 0.5rem; }
    </style>
</head>
<body>

<div class="config-container">
    <div class="config-card">
        <div class="config-header">
            <h2>⚙️ Configuración General <span class="badge-global">GLOBAL</span></h2>
            <a href="../configuracion.php" class="btn-volver">← Volver</a>
        </div>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div class="config-grid">
                <?php while($item = $items->fetch_assoc()): 
                    $clave = $item['clave'];
                    $etiqueta = $item['etiqueta'] ?? $clave;
                ?>
                    <div class="config-item">
                        <label class="config-label"><?php echo htmlspecialchars($etiqueta); ?></label>
                        <div class="config-desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                        
                        <?php if ($item['tipo'] == 'color'): ?>
                            <input type="color" class="config-color" name="config_<?php echo $clave; ?>" 
                                   value="<?php echo htmlspecialchars($item['valor']); ?>" style="margin-top: 0.5rem;">
                        <?php elseif ($item['tipo'] == 'imagen'): ?>
                            <div class="file-input-wrapper">
                                <input type="file" class="config-input" name="config_<?php echo $clave; ?>" 
                                       accept="image/*" style="padding: 0.4rem;">
                            </div>
                            <?php if (!empty($item['valor'])): ?>
                                <img src="<?php echo htmlspecialchars($item['valor']); ?>" class="preview-logo" alt="Logo">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="eliminar_<?php echo $clave; ?>"> Eliminar imagen
                                </label>
                            <?php endif; ?>
                        <?php elseif ($item['tipo'] == 'boolean'): ?>
                            <label class="checkbox-label">
                                <input type="checkbox" name="config_<?php echo $clave; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>>
                                <span>Activar</span>
                            </label>
                        <?php elseif ($item['tipo'] == 'numero'): ?>
                            <input type="number" class="config-input" name="config_<?php echo $clave; ?>" 
                                   value="<?php echo htmlspecialchars($item['valor']); ?>" 
                                   step="0.01" min="0" style="margin-top: 0.5rem;">
                        <?php else: ?>
                            <input type="text" class="config-input" name="config_<?php echo $clave; ?>" 
                                   value="<?php echo htmlspecialchars($item['valor']); ?>" 
                                   style="margin-top: 0.5rem;">
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
            
            <div class="info-box">
                <p>💡 <strong>Nota:</strong> Esta configuración es <strong>global</strong> y aplica a todo el sistema. Los proveedores no pueden modificar estos valores.</p>
            </div>
            
            <div class="clearfix">
                <button type="submit" name="guardar_config" class="btn-guardar">
                    💾 Guardar Configuración
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Auto-cerrar mensajes
setTimeout(function() {
    const mensaje = document.querySelector('.mensaje');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(function() {
            if (mensaje) mensaje.remove();
        }, 500);
    }
}, 5000);
</script>

<?php
$conn->close();
?>
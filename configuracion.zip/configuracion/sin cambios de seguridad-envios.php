<?php
require_once '../conexion.php';
require_once '../header.php';

if (!in_array($_SESSION['rol'], ['Super Admin', 'Admin'])) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    if ($accion === 'guardar_todo') {
        // Actualizar provincias
        if (isset($_POST['provincia_nombre']) && is_array($_POST['provincia_nombre'])) {
            foreach ($_POST['provincia_nombre'] as $id => $nombre) {
                $id = intval($id);
                $nombre = trim($nombre);
                $activo = isset($_POST['provincia_activo'][$id]) ? 1 : 0;
                $stmt = $conn->prepare("UPDATE provincias SET nombre = ?, activo = ? WHERE id = ?");
                $stmt->bind_param("sii", $nombre, $activo, $id);
                $stmt->execute();
                // Si provincia desactivada, desactivar sus municipios
                if ($activo == 0) {
                    $conn->query("UPDATE costos_envio SET activo = 0 WHERE provincia_id = $id");
                }
            }
        }

        // Actualizar municipios
        if (isset($_POST['municipio_nombre']) && is_array($_POST['municipio_nombre'])) {
            foreach ($_POST['municipio_nombre'] as $id => $nombre) {
                $id = intval($id);
                $nombre = trim($nombre);
                $costo = floatval($_POST['municipio_costo'][$id] ?? 0);
                $activo = isset($_POST['municipio_activo'][$id]) ? 1 : 0;
                $stmt = $conn->prepare("UPDATE costos_envio SET municipio = ?, costo = ?, activo = ? WHERE id = ?");
                $stmt->bind_param("sdii", $nombre, $costo, $activo, $id);
                $stmt->execute();
            }
        }

        $mensaje = "✅ Todos los cambios guardados correctamente";
        $tipo_mensaje = "exito";
        header("Location: envios.php?mensaje=" . urlencode($mensaje) . "&tipo=" . $tipo_mensaje);
        exit;
    }
}

$provincias = $conn->query("SELECT * FROM provincias ORDER BY nombre");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Gestión de Envíos</title>
    <link rel="stylesheet" href="../estilo.css">
    <style>
        body { background: #f1f5f9; font-family: system-ui, -apple-system, sans-serif; }
        .container { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; }
        @media (max-width: 768px) {
            .container { margin: 1rem auto; padding: 0 0.8rem; }
        }
        h2 { font-size: 1.5rem; margin: 0 0 0.5rem 0; color: #1e293b; }
        @media (max-width: 768px) {
            h2 { font-size: 1.2rem; }
        }
        .subtext { color: #475569; margin-bottom: 2rem; font-size: 0.9rem; }
        @media (max-width: 768px) {
            .subtext { margin-bottom: 1rem; font-size: 0.8rem; }
        }
        .btn-success { background: #10b981; color: white; border: none; padding: 0.6rem 1.2rem; border-radius: 30px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        .btn-success:hover { background: #059669; transform: translateY(-2px); }
        .guardar-btn { text-align: right; margin-top: 2rem; }
        @media (max-width: 768px) {
            .guardar-btn { text-align: center; margin-top: 1.5rem; }
            .btn-success { width: 100%; padding: 0.8rem; }
        }
        
        /* Tarjetas */
        .provincia-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
            overflow: hidden;
            border: 1px solid #e2e8f0;
        }
        @media (max-width: 768px) {
            .provincia-card { margin-bottom: 1rem; border-radius: 16px; }
        }
        .card-header {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 0.8rem;
            padding: 1rem 1.2rem;
            background: #fafcff;
            cursor: pointer;
            border-bottom: 1px solid transparent;
            transition: background 0.1s;
        }
        @media (max-width: 768px) {
            .card-header { flex-direction: column; align-items: stretch; padding: 0.8rem 1rem; }
        }
        .card-header:hover {
            background: #f8fafc;
        }
        .provincia-titulo {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            flex: 2;
            min-width: 200px;
        }
        @media (max-width: 768px) {
            .provincia-titulo { justify-content: space-between; flex-wrap: wrap; }
        }
        .provincia-titulo input {
            font-weight: 600;
            font-size: 1rem;
            padding: 0.4rem 0.8rem;
            border: 1px solid #cbd5e1;
            border-radius: 12px;
            width: 220px;
        }
        @media (max-width: 768px) {
            .provincia-titulo input { width: 100%; font-size: 0.9rem; padding: 0.5rem; }
        }
        .provincia-activo {
            display: flex;
            align-items: center;
            gap: 0.4rem;
            font-size: 0.85rem;
            white-space: nowrap;
        }
        @media (max-width: 768px) {
            .provincia-activo { white-space: normal; }
        }
        .toggle-icon {
            font-size: 1.2rem;
            margin-left: 0.5rem;
            color: #64748b;
        }
        .card-body {
            padding: 0;
            display: none;
            border-top: 1px solid #e2e8f0;
        }
        .card-body.open {
            display: block;
        }
        
        /* Tabla de municipios - responsive con scroll horizontal */
        .municipios-table {
            width: 100%;
            border-collapse: collapse;
        }
        @media (max-width: 768px) {
            .card-body {
                overflow-x: auto;
            }
            .municipios-table {
                min-width: 500px;
            }
        }
        .municipios-table th {
            text-align: left;
            padding: 0.75rem 1.2rem;
            background: #f8fafc;
            font-weight: 600;
            font-size: 0.85rem;
            color: #334155;
            border-bottom: 1px solid #e2e8f0;
        }
        @media (max-width: 768px) {
            .municipios-table th { padding: 0.5rem 0.8rem; font-size: 0.75rem; }
            .municipios-table td { padding: 0.5rem 0.8rem; }
        }
        .municipios-table td {
            padding: 0.7rem 1.2rem;
            border-bottom: 1px solid #edf2f7;
            vertical-align: middle;
        }
        .municipio-nombre {
            width: 200px;
            padding: 0.4rem 0.6rem;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
        }
        @media (max-width: 768px) {
            .municipio-nombre { width: 140px; padding: 0.3rem 0.5rem; font-size: 0.8rem; }
            .municipio-costo { width: 80px; padding: 0.3rem 0.5rem; font-size: 0.8rem; }
        }
        .municipio-costo {
            width: 110px;
            padding: 0.4rem 0.6rem;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
        }
        .checkbox-muni {
            transform: scale(1.1);
            margin-left: 0.2rem;
        }
        @media (max-width: 768px) {
            .checkbox-muni { transform: scale(1); }
        }
        .mensaje {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            background: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            z-index: 1000;
            font-weight: 500;
        }
        @media (max-width: 768px) {
            .mensaje { left: 20px; right: 20px; padding: 0.6rem 1rem; font-size: 0.85rem; }
        }
        .mensaje.exito {
            background: #ecfdf5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }
        input:disabled {
            background-color: #f1f5f9;
            opacity: 0.6;
            cursor: not-allowed;
        }
    </style>
    <script>
        function toggleProvincia(id) {
            const body = document.getElementById('provincia-body-' + id);
            body.classList.toggle('open');
            const icon = document.getElementById('toggle-icon-' + id);
            icon.textContent = body.classList.contains('open') ? '▲' : '▼';
        }
        setTimeout(() => {
            const msg = document.querySelector('.mensaje');
            if (msg) msg.remove();
        }, 5000);
    </script>
    <script>
function sincronizarMunicipios(provinciaCheckbox, provinciaId) {
    const estado = provinciaCheckbox.checked;
    const municipios = document.querySelectorAll('.municipio-prov-' + provinciaId);
    municipios.forEach(function(munCheck) {
        munCheck.checked = estado;
        munCheck.disabled = !estado;
    });
}
</script>
</head>
<body>
<div class="container">
    <div class="header">
        <h2>🚚 Costos de envío por municipio</h2>
        <div class="subtext">Edita nombres, costos y activa/desactiva provincias o municipios.</div>
    </div>

    <?php if (isset($_GET['mensaje'])): ?>
        <div class="mensaje <?php echo htmlspecialchars($_GET['tipo']); ?>"><?php echo htmlspecialchars(urldecode($_GET['mensaje'])); ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="accion" value="guardar_todo">

        <?php while($prov = $provincias->fetch_assoc()): 
            $prov_id = $prov['id'];
            $municipios = $conn->query("SELECT * FROM costos_envio WHERE provincia_id = $prov_id ORDER BY municipio");
        ?>
        <div class="provincia-card">
            <div class="card-header" onclick="toggleProvincia(<?php echo $prov_id; ?>)">
                <div class="provincia-titulo">
                    <input type="text" name="provincia_nombre[<?php echo $prov_id; ?>]" value="<?php echo htmlspecialchars($prov['nombre']); ?>" onclick="event.stopPropagation();">
                    <label class="provincia-activo" onclick="event.stopPropagation();">
    <input type="checkbox" name="provincia_activo[<?php echo $prov_id; ?>]" value="1" 
        id="provincia_check_<?php echo $prov_id; ?>"
        data-provincia-id="<?php echo $prov_id; ?>"
        <?php echo $prov['activo'] ? 'checked' : ''; ?> 
        onchange="sincronizarMunicipios(this, <?php echo $prov_id; ?>)"> 
    Activo
</label>
                </div>
                <span class="toggle-icon" id="toggle-icon-<?php echo $prov_id; ?>">▼</span>
            </div>
            <div class="card-body" id="provincia-body-<?php echo $prov_id; ?>">
                <table class="municipios-table">
                    <thead>
                        <tr><th>Municipio</th><th>Costo (USD)</th><th>Activo</th></thead>
                    <tbody>
                        <?php while($mun = $municipios->fetch_assoc()): ?>
                        <tr>
                            <td><input type="text" name="municipio_nombre[<?php echo $mun['id']; ?>]" value="<?php echo htmlspecialchars($mun['municipio']); ?>" class="municipio-nombre"></td>
                            <td><input type="number" name="municipio_costo[<?php echo $mun['id']; ?>]" step="0.01" min="0" value="<?php echo $mun['costo']; ?>" class="municipio-costo"></td>
   <td>
    <input type="checkbox" name="municipio_activo[<?php echo $mun['id']; ?>]" value="1" 
        class="checkbox-muni municipio-prov-<?php echo $prov_id; ?>"
        <?php echo ($mun['activo'] && $prov['activo']) ? 'checked' : ''; ?> 
        <?php echo $prov['activo'] ? '' : 'disabled'; ?>>
</td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endwhile; ?>

        <div class="guardar-btn">
            <button type="submit" class="btn-success">💾 Guardar todos los cambios</button>
        </div>
    </form>
</div>
</body>
</html>
<?php
// ============================================
// CONFIGURACIÓN DE PRODUCTOS Y CATEGORÍAS - SOLO GLOBAL
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol']);
$es_proveedor = esRolProveedor($_SESSION['rol']);

if ($es_proveedor) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// MENSAJES
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// PROCESAR CONFIGURACIÓN DE PRODUCTOS
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/productos.php');
        exit;
    }
    
    $tipos_sql = "SELECT clave, tipo FROM configuracion WHERE grupo = 'productos' AND visible = 1 AND proveedor_id = 0";
    $tipos_result = $conn->query($tipos_sql);
    $tipos_config = [];
    while($row = $tipos_result->fetch_assoc()) {
        $tipos_config[$row['clave']] = $row['tipo'];
    }
    
    foreach ($_POST as $clave => $valor) {
        if (strpos($clave, 'config_') === 0) {
            $clave_real = substr($clave, 7);
            
            if (!isset($tipos_config[$clave_real])) {
                continue;
            }
            
            $tipo = $tipos_config[$clave_real];
            switch ($tipo) {
                case 'numero':
                    $valor = intval($valor);
                    break;
                case 'boolean':
                    $valor = ($valor === 'on' || $valor === '1') ? 1 : 0;
                    break;
                default:
                    $valor = trim(htmlspecialchars(strip_tags($valor)));
                    break;
            }
            
            $sql = "INSERT INTO configuracion (clave, grupo, valor, tipo, visible, proveedor_id) 
                    VALUES (?, 'productos', ?, ?, 1, 0) 
                    ON DUPLICATE KEY UPDATE valor = VALUES(valor), fecha_actualizacion = NOW()";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sss", $clave_real, $valor, $tipo);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
    
    $_SESSION['mensaje'] = "✅ Configuración guardada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    header('Location: /configuracion/productos.php');
    exit;
}

// ============================================
// PROCESAR ACCIONES DE CATEGORÍAS
// ============================================

// Agregar categoría
if (isset($_POST['accion_categoria']) && $_POST['accion_categoria'] === 'agregar') {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/productos.php');
        exit;
    }
    
    $nombre = trim($_POST['nombre']);
    $icono = trim($_POST['icono']);
    
    if (empty($nombre)) {
        $_SESSION['mensaje'] = "❌ El nombre es obligatorio";
        $_SESSION['tipo_mensaje'] = "error";
    } else {
        $orden_result = $conn->query("SELECT MAX(orden) as max_orden FROM categorias");
        $max_orden = $orden_result->fetch_assoc()['max_orden'] ?? 0;
        $nuevo_orden = $max_orden + 1;
        
        $stmt = $conn->prepare("INSERT INTO categorias (nombre, icono, activo, orden) VALUES (?, ?, 1, ?)");
        $stmt->bind_param("ssi", $nombre, $icono, $nuevo_orden);
        
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "✅ Categoría agregada correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
        } else {
            $_SESSION['mensaje'] = "❌ Error al agregar la categoría";
            $_SESSION['tipo_mensaje'] = "error";
        }
    }
    header('Location: /configuracion/productos.php');
    exit;
}

// Editar categoría
if (isset($_POST['accion_categoria']) && $_POST['accion_categoria'] === 'editar') {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/productos.php');
        exit;
    }
    
    $id = intval($_POST['categoria_id']);
    $nombre = trim($_POST['nombre']);
    $icono = trim($_POST['icono']);
    
    $stmt = $conn->prepare("UPDATE categorias SET nombre = ?, icono = ? WHERE id = ?");
    $stmt->bind_param("ssi", $nombre, $icono, $id);
    
    if ($stmt->execute()) {
        $_SESSION['mensaje'] = "✅ Categoría actualizada correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
    } else {
        $_SESSION['mensaje'] = "❌ Error al actualizar la categoría";
        $_SESSION['tipo_mensaje'] = "error";
    }
    header('Location: /configuracion/productos.php');
    exit;
}

// Desactivar categoría
if (isset($_GET['desactivar_categoria']) && isset($_GET['csrf_token'])) {
    if ($_GET['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/productos.php');
        exit;
    }
    
    $id = intval($_GET['desactivar_categoria']);
    $stmt = $conn->prepare("UPDATE categorias SET activo = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $_SESSION['mensaje'] = "✅ Categoría desactivada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    header('Location: /configuracion/productos.php');
    exit;
}

// Activar categoría
if (isset($_GET['activar_categoria']) && isset($_GET['csrf_token'])) {
    if ($_GET['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/productos.php');
        exit;
    }
    
    $id = intval($_GET['activar_categoria']);
    $stmt = $conn->prepare("UPDATE categorias SET activo = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $_SESSION['mensaje'] = "✅ Categoría activada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    header('Location: /configuracion/productos.php');
    exit;
}

// Eliminar categoría
if (isset($_GET['eliminar_categoria']) && isset($_GET['csrf_token'])) {
    if ($_GET['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/productos.php');
        exit;
    }
    
    $id = intval($_GET['eliminar_categoria']);
    
    $check = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE categoria_id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $total = $check->get_result()->fetch_assoc()['total'];
    
    if ($total > 0) {
        $_SESSION['mensaje'] = "❌ No se puede eliminar: tiene $total productos asociados";
        $_SESSION['tipo_mensaje'] = "error";
    } else {
        $stmt = $conn->prepare("DELETE FROM categorias WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $_SESSION['mensaje'] = "✅ Categoría eliminada correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
    }
    header('Location: /configuracion/productos.php');
    exit;
}

// ============================================
// OBTENER DATOS
// ============================================
$items = $conn->query("SELECT * FROM configuracion WHERE grupo = 'productos' AND visible = 1 AND proveedor_id = 0 ORDER BY orden");

$categorias = $conn->query("SELECT c.*, (SELECT COUNT(*) FROM productos WHERE categoria_id = c.id) as total_productos FROM categorias c ORDER BY c.orden ASC, c.nombre ASC");

// ============================================
// INCLUIR HEADER (CONTIENE ESTRUCTURA PRINCIPAL)
// ============================================
require_once $_SERVER['DOCUMENT_ROOT'] . '/header.php';
?>

<!-- ============================================
     ESTILOS ESPECÍFICOS DE PRODUCTOS.PHP
     ============================================ -->
<style>
:root { --primary: #667eea; --secondary: #764ba2; }

.config-container { max-width: 1200px; margin: 1rem auto; padding: 0 1rem; }
@media (min-width: 768px) { .config-container { margin: 2rem auto; padding: 0 2rem; } }

.config-card { background: white; border-radius: 20px; padding: 1.25rem; box-shadow: 0 4px 20px rgba(0,0,0,0.05); margin-bottom: 2rem; }
@media (min-width: 768px) { .config-card { padding: 2rem; } }

.config-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.config-header h2 { font-size: 1.3rem; color: #2d3748; display: flex; align-items: center; gap: 0.5rem; }
@media (min-width: 768px) { .config-header h2 { font-size: 1.5rem; } }

.btn-volver { padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; font-size: 0.85rem; display: inline-block; }
.btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }

.badge-global { display: inline-block; background: #dbeafe; color: #1e40af; padding: 0.15rem 0.6rem; border-radius: 12px; font-size: 0.65rem; font-weight: 600; margin-left: 0.5rem; }

.config-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; }
@media (min-width: 640px) { .config-grid { grid-template-columns: repeat(2, 1fr); gap: 1.25rem; } }

.config-item { padding: 0.9rem; background: #f8fafc; border-radius: 12px; }
@media (min-width: 768px) { .config-item { padding: 1rem; } }

.config-label { font-weight: 600; margin-bottom: 0.5rem; color: #2d3748; display: block; }
.config-desc { font-size: 0.75rem; color: #718096; margin-bottom: 0.5rem; }
@media (min-width: 768px) { .config-desc { font-size: 0.85rem; } }

.config-input { width: 100%; padding: 0.7rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; transition: all 0.3s; }
@media (min-width: 768px) { .config-input { padding: 0.8rem; font-size: 0.95rem; } }
.config-input:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(102,126,234,0.1); }

.info-box { background: #fff3e0; border-left: 4px solid #ecc94b; padding: 1rem; border-radius: 8px; margin-top: 1rem; }
.info-box p { color: #744210; font-size: 0.85rem; margin: 0; }

.btn-guardar { width: 100%; padding: 0.8rem; margin-top: 1.5rem; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; border-radius: 50px; cursor: pointer; font-weight: 600; transition: all 0.3s; }
@media (min-width: 768px) { .btn-guardar { width: auto; float: right; padding: 0.8rem 2rem; } }
.btn-guardar:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }

.clearfix::after { content: ""; clear: both; display: table; }

.mensaje-flotante { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-size: 0.85rem; }
@media (min-width: 768px) { .mensaje-flotante { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; } }
.mensaje-flotante.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
.mensaje-flotante.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

.tabla-categorias { overflow-x: auto; margin-top: 1rem; }
.tabla-categorias table { width: 100%; border-collapse: collapse; }
.tabla-categorias th { background: #f8fafc; padding: 0.6rem 0.8rem; text-align: left; font-weight: 600; border-bottom: 2px solid #e2e8f0; font-size: 0.8rem; }
@media (min-width: 768px) { .tabla-categorias th { padding: 0.8rem; font-size: 0.9rem; } }
.tabla-categorias td { padding: 0.6rem 0.8rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; font-size: 0.85rem; }
@media (min-width: 768px) { .tabla-categorias td { padding: 0.8rem; font-size: 0.95rem; } }

.acciones-categoria { display: flex; gap: 0.3rem; flex-wrap: wrap; }
.btn-editar { background: #4299e1; color: white; border: none; padding: 0.25rem 0.5rem; border-radius: 4px; cursor: pointer; font-size: 0.75rem; }
.btn-desactivar { background: #ecc94b; color: #744210; padding: 0.25rem 0.5rem; border-radius: 4px; text-decoration: none; display: inline-block; font-size: 0.75rem; }
.btn-activar { background: #48bb78; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; text-decoration: none; display: inline-block; font-size: 0.75rem; }
.btn-eliminar { background: #f56565; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; text-decoration: none; display: inline-block; font-size: 0.75rem; }
.btn-eliminar.disabled { opacity: 0.5; cursor: not-allowed; }

.modal { display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
.modal-content { background: white; margin: 10% auto; padding: 1.5rem; border-radius: 16px; max-width: 500px; width: 90%; position: relative; }
@media (max-width: 600px) { .modal-content { margin: 20% auto; padding: 1rem; } }
.close { position: absolute; top: 0.5rem; right: 1rem; font-size: 1.8rem; cursor: pointer; }

.form-group { margin-bottom: 1rem; }
.form-group label { display: block; font-weight: 600; margin-bottom: 0.5rem; }
.form-group input { width: 100%; padding: 0.7rem; border: 2px solid #e2e8f0; border-radius: 8px; }

.form-actions { display: flex; gap: 0.5rem; justify-content: flex-end; margin-top: 1rem; flex-wrap: wrap; }
.btn-primary { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; padding: 0.5rem 1rem; border-radius: 8px; cursor: pointer; }
.btn-secondary { background: #edf2f7; color: #4a5568; border: none; padding: 0.5rem 1rem; border-radius: 8px; cursor: pointer; }

.selector-iconos { display: grid; grid-template-columns: repeat(8, 1fr); gap: 0.5rem; max-height: 250px; overflow-y: auto; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 8px; background: #f8fafc; margin-top: 0.5rem; }
.icono-opcion { font-size: 1.5rem; text-align: center; padding: 0.5rem; cursor: pointer; border-radius: 8px; transition: all 0.2s; }
.icono-opcion:hover { background: #e2e8f0; transform: scale(1.1); }
.icono-opcion.seleccionado { background: var(--primary); color: white; }
.icono-preview { font-size: 1.8rem; width: 50px; text-align: center; }

.form-row { display: flex; flex-wrap: wrap; gap: 0.5rem; }
.form-row input[type="text"] { flex: 2; min-width: 150px; padding: 0.7rem; border: 2px solid #e2e8f0; border-radius: 8px; }
.form-row input[type="text"].icono-input { flex: 1; min-width: 80px; }
.form-row .btn-primary, .form-row .btn-secondary { padding: 0.7rem 1rem; }

@media (max-width: 600px) {
    .config-header h2 { font-size: 1.1rem; }
    .config-card { padding: 0.8rem; }
    .form-row input[type="text"] { flex: 1 1 100%; }
    .form-row .btn-primary, .form-row .btn-secondary { flex: 1; text-align: center; }
    .acciones-categoria { gap: 0.2rem; }
    .acciones-categoria .btn-editar, .acciones-categoria .btn-desactivar, 
    .acciones-categoria .btn-activar, .acciones-categoria .btn-eliminar { font-size: 0.65rem; padding: 0.2rem 0.4rem; }
}
</style>

<!-- ============================================
     CONTENIDO PRINCIPAL
     ============================================ -->

<div class="config-container">
    <?php if ($mensaje): ?>
        <div class="mensaje-flotante <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>
    
    <!-- Configuración de productos -->
    <div class="config-card">
        <div class="config-header">
            <h2>📦 Configuración de Productos <span class="badge-global">GLOBAL</span></h2>
            <a href="../configuracion.php" class="btn-volver">← Volver</a>
        </div>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="config-grid">
                <?php while($item = $items->fetch_assoc()): ?>
                    <div class="config-item">
                        <label class="config-label"><?php echo $item['etiqueta'] ?? $item['clave']; ?></label>
                        <div class="config-desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                        <input type="number" class="config-input" name="config_<?php echo $item['clave']; ?>" 
                               value="<?php echo htmlspecialchars($item['valor']); ?>" step="1" min="0">
                    </div>
                <?php endwhile; ?>
            </div>
            
            <div class="info-box">
                <p>⚠️ Cuando un producto alcance o esté por debajo de este número, aparecerá una alerta en el panel de administración.</p>
            </div>
            
            <div class="clearfix">
                <button type="submit" name="guardar_config" class="btn-guardar">💾 Guardar Configuración</button>
            </div>
        </form>
    </div>
    
    <!-- Gestión de Categorías -->
    <div class="config-card">
        <div class="config-header">
            <h2>🏷️ Gestión de Categorías</h2>
        </div>
        
        <form method="POST" style="margin-bottom: 2rem;">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="accion_categoria" value="agregar">
            <div class="form-row">
                <input type="text" name="nombre" placeholder="Nombre de la categoría" required>
                <input type="text" name="icono" id="nuevo_icono" placeholder="Icono (📦)" class="icono-input">
                <button type="button" onclick="abrirSelectorIconosNuevo()" class="btn-secondary">🎨 Elegir</button>
                <button type="submit" class="btn-primary">➕ Agregar</button>
            </div>
        </form>
        
        <div class="tabla-categorias">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Icono</th>
                        <th>Nombre</th>
                        <th>Productos</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($cat = $categorias->fetch_assoc()): 
                        $icono_mostrar = $cat['icono'];
                        if (strpos($icono_mostrar, '&#x') === 0) {
                            $icono_mostrar = html_entity_decode($icono_mostrar, ENT_QUOTES, 'UTF-8');
                        }
                        if (empty($icono_mostrar)) $icono_mostrar = '📦';
                    ?>
                        <tr>
                            <td><?php echo $cat['id']; ?></td>
                            <td style="font-size: 1.5rem; text-align: center;"><?php echo $icono_mostrar; ?></td>
                            <td><?php echo htmlspecialchars($cat['nombre']); ?></td>
                            <td><?php echo $cat['total_productos']; ?> <?php echo $cat['total_productos'] == 1 ? 'producto' : 'productos'; ?></td>
                            <td><?php echo $cat['activo'] ? '✅ Activo' : '❌ Inactivo'; ?></td>
                            <td class="acciones-categoria">
                                <button onclick="editarCategoria(<?php echo $cat['id']; ?>, '<?php echo addslashes(htmlspecialchars($cat['nombre'])); ?>', '<?php echo addslashes(htmlspecialchars($cat['icono'])); ?>')" class="btn-editar">✏️</button>
                                <?php if ($cat['activo']): ?>
                                    <a href="?desactivar_categoria=<?php echo $cat['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn-desactivar" onclick="return confirm('¿Desactivar esta categoría?')">🔴</a>
                                <?php else: ?>
                                    <a href="?activar_categoria=<?php echo $cat['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn-activar" onclick="return confirm('¿Activar esta categoría?')">🟢</a>
                                <?php endif; ?>
                                <?php if ($cat['total_productos'] == 0): ?>
                                    <a href="?eliminar_categoria=<?php echo $cat['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn-eliminar" onclick="return confirm('¿Eliminar esta categoría?')">🗑️</a>
                                <?php else: ?>
                                    <span class="btn-eliminar disabled" title="No se puede eliminar porque tiene <?php echo $cat['total_productos']; ?> productos">🗑️</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <div class="info-box" style="margin-top: 1rem;">
            <p>💡 Las categorías inactivas no se muestran en la tienda. No se puede eliminar una categoría que tenga productos asociados.</p>
        </div>
    </div>
</div>

<!-- ============================================
     MODALES
     ============================================ -->

<!-- Modal Editar Categoría -->
<div id="modalEditar" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModalEditar()">&times;</span>
        <h3>✏️ Editar Categoría</h3>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="accion_categoria" value="editar">
            <input type="hidden" name="categoria_id" id="edit_id">
            <div class="form-group">
                <label>Nombre</label>
                <input type="text" name="nombre" id="edit_nombre" required>
            </div>
            <div class="form-group">
                <label>Icono</label>
                <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                    <span id="preview_icono" class="icono-preview">📦</span>
                    <input type="text" name="icono" id="edit_icono" style="flex:1; padding:0.7rem; border:2px solid #e2e8f0; border-radius:8px; min-width:80px;" placeholder="Icono">
                    <button type="button" onclick="abrirSelectorIconos()" class="btn-secondary" style="padding: 0.5rem 1rem;">🎨 Elegir</button>
                </div>
                <div id="selectorIconos" class="selector-iconos" style="display: none; margin-top: 0.5rem;"></div>
            </div>
            <div class="form-actions">
                <button type="button" onclick="cerrarModalEditar()" class="btn-secondary">Cancelar</button>
                <button type="submit" class="btn-primary">Guardar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Selector de Iconos para nuevo -->
<div id="modalSelectorNuevo" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <span class="close" onclick="cerrarSelectorNuevo()">&times;</span>
        <h3>🎨 Selecciona un icono</h3>
        <div id="selectorIconosNuevo" class="selector-iconos"></div>
        <div class="form-actions" style="margin-top: 1rem;">
            <button type="button" onclick="cerrarSelectorNuevo()" class="btn-secondary">Cancelar</button>
        </div>
    </div>
</div>

<!-- ============================================
     SCRIPTS
     ============================================ -->
<script>
const listaIconos = [
    '📦', '📱', '💻', '🖥️', '⌚', '📷', '🎧', '🔊',
    '🍔', '🍕', '🥤', '🍎', '🥩', '🍬', '❄️', '🥗',
    '👕', '👖', '👟', '🧥', '👜', '💄', '💍', '⌚',
    '⚽', '🏀', '🎾', '🏈', '🎽', '🏋️', '🚴', '🏊',
    '🔧', '🔨', '🪛', '🪚', '🧹', '🧺', '🚗', '🚲',
    '🏠', '🛋️', '🛏️', '🚿', '🧴', '🧼', '🧽', '🧻',
    '❤️', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎',
    '⭐', '🌟', '🔥', '💧', '🌈', '☀️', '🌙', '⭐'
];

function abrirSelectorIconos() {
    const container = document.getElementById('selectorIconos');
    container.innerHTML = '';
    listaIconos.forEach(icono => {
        const div = document.createElement('div');
        div.className = 'icono-opcion';
        div.textContent = icono;
        div.onclick = () => seleccionarIcono(icono);
        container.appendChild(div);
    });
    container.style.display = 'grid';
}

function abrirSelectorIconosNuevo() {
    const container = document.getElementById('selectorIconosNuevo');
    container.innerHTML = '';
    listaIconos.forEach(icono => {
        const div = document.createElement('div');
        div.className = 'icono-opcion';
        div.textContent = icono;
        div.onclick = () => seleccionarIconoNuevo(icono);
        container.appendChild(div);
    });
    document.getElementById('modalSelectorNuevo').style.display = 'block';
}

function seleccionarIcono(icono) {
    const codePoint = icono.codePointAt(0).toString(16);
    const iconoHtml = `&#x${codePoint};`;
    document.getElementById('edit_icono').value = iconoHtml;
    document.getElementById('preview_icono').innerHTML = icono;
    document.getElementById('selectorIconos').style.display = 'none';
}

function seleccionarIconoNuevo(icono) {
    const codePoint = icono.codePointAt(0).toString(16);
    const iconoHtml = `&#x${codePoint};`;
    document.getElementById('nuevo_icono').value = iconoHtml;
    cerrarSelectorNuevo();
}

function cerrarSelectorNuevo() {
    document.getElementById('modalSelectorNuevo').style.display = 'none';
}

function editarCategoria(id, nombre, icono) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nombre').value = nombre;
    let iconoMostrar = icono;
    if (iconoMostrar && iconoMostrar.indexOf('&#x') === 0) {
        iconoMostrar = html_entity_decode(iconoMostrar, ENT_QUOTES, 'UTF-8');
    }
    document.getElementById('edit_icono').value = icono || '';
    document.getElementById('preview_icono').innerHTML = iconoMostrar || '📦';
    document.getElementById('selectorIconos').style.display = 'none';
    document.getElementById('modalEditar').style.display = 'block';
}

function cerrarModalEditar() {
    document.getElementById('modalEditar').style.display = 'none';
}

window.onclick = function(event) {
    const modalEditar = document.getElementById('modalEditar');
    const modalSelector = document.getElementById('modalSelectorNuevo');
    if (event.target == modalEditar) {
        cerrarModalEditar();
    }
    if (event.target == modalSelector) {
        cerrarSelectorNuevo();
    }
}

setTimeout(function() {
    const mensaje = document.querySelector('.mensaje-flotante');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(function() {
            if (mensaje) mensaje.remove();
        }, 500);
    }
}, 5000);
</script>

<?php
$conn->close();
?>
<?php
// ============================================
// AGREGAR PROVINCIAS Y MUNICIPIOS
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS (SOLO SUPER ADMIN Y GERENTE)
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// OBTENER CONFIGURACIÓN DE MONEDA
// ============================================
$moneda_simbolo = '$';
$config_result = $conn->query("SELECT valor FROM configuracion WHERE clave = 'moneda_simbolo' AND proveedor_id = 0");
if ($config_result && $config_result->num_rows > 0) {
    $moneda_simbolo = $config_result->fetch_assoc()['valor'] ?? '$';
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// PROCESAR GUARDAR
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/mas_provincias.php");
        exit;
    }
    
    // ============================================
    // AGREGAR PROVINCIA CON MUNICIPIOS
    // ============================================
    if (isset($_POST['accion']) && $_POST['accion'] === 'agregar_provincia') {
        
        $provincia_nombre = trim(htmlspecialchars(strip_tags($_POST['provincia_nombre'] ?? '')));
        $municipios = $_POST['municipios'] ?? [];
        $costos = $_POST['costos'] ?? [];
        $municipios_activos = $_POST['municipio_activo'] ?? [];
        
        if (empty($provincia_nombre)) {
            $_SESSION['mensaje'] = '❌ El nombre de la provincia es obligatorio';
            $_SESSION['tipo_mensaje'] = 'error';
            header("Location: /configuracion/mas_provincias.php");
            exit;
        }
        
        if (empty($municipios)) {
            $_SESSION['mensaje'] = '❌ Debes agregar al menos un municipio';
            $_SESSION['tipo_mensaje'] = 'error';
            header("Location: /configuracion/mas_provincias.php");
            exit;
        }
        
        // Verificar si la provincia ya existe
        $check = $conn->prepare("SELECT id FROM provincias WHERE nombre = ?");
        $check->bind_param("s", $provincia_nombre);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $_SESSION['mensaje'] = '❌ La provincia "' . $provincia_nombre . '" ya existe';
            $_SESSION['tipo_mensaje'] = 'error';
            header("Location: /configuracion/mas_provincias.php");
            exit;
        }
        $check->close();
        
        // Iniciar transacción
$conn->begin_transaction();

try {
    // Insertar provincia
    $stmt = $conn->prepare("INSERT INTO provincias (nombre, activo) VALUES (?, 1)");
    $stmt->bind_param("s", $provincia_nombre);
    $stmt->execute();
    $provincia_id = $conn->insert_id;
    $stmt->close();
    
    if ($provincia_id > 0) {
        // Insertar municipios y costos globales
        $insertados = 0;
        foreach ($municipios as $index => $municipio_nombre) {
            $municipio_nombre = trim(htmlspecialchars(strip_tags($municipio_nombre)));
            if (empty($municipio_nombre)) continue;
            
            $costo = isset($costos[$index]) ? floatval($costos[$index]) : 0;
            $costo = max(0, $costo);
            $activo = isset($municipios_activos[$index]) ? 1 : 0;
            
            // Insertar municipio
            $stmt_mun = $conn->prepare("INSERT INTO municipios (provincia_id, nombre, activo) VALUES (?, ?, ?)");
            $stmt_mun->bind_param("isi", $provincia_id, $municipio_nombre, $activo);
            $stmt_mun->execute();
            $municipio_id = $conn->insert_id;
            $stmt_mun->close();
            
            if ($municipio_id > 0) {
                // Insertar costo global
                $stmt_costo = $conn->prepare("
                    INSERT INTO costos_envio (provincia_id, municipio_id, costo, proveedor_id, activo) 
                    VALUES (?, ?, ?, 0, ?)
                ");
                $stmt_costo->bind_param("iidi", $provincia_id, $municipio_id, $costo, $activo);
                $stmt_costo->execute();
                $stmt_costo->close();
                $insertados++;
            }
        }
        
        // Confirmar transacción
        $conn->commit();
        
        $_SESSION['mensaje'] = "✅ Provincia '$provincia_nombre' creada con $insertados municipios";
        $_SESSION['tipo_mensaje'] = "exito";
    } else {
        throw new Exception('Error al crear la provincia');
    }
    
} catch (Exception $e) {
    // Revertir transacción en caso de error
    $conn->rollback();
    $_SESSION['mensaje'] = '❌ Error al crear la provincia: ' . $e->getMessage();
    $_SESSION['tipo_mensaje'] = 'error';
}

header("Location: /configuracion/mas_provincias.php");
exit;
    }
}

// ============================================
// RECIBIR MENSAJES DE SESIÓN
// ============================================
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// INCLUIR HEADER
// ============================================
require_once '../header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Provincias - Catalejo</title>
    <style>
        .container { max-width: 800px; margin: 2rem auto; padding: 0 1rem; }
        @media (max-width: 768px) { .container { margin: 1rem auto; padding: 0 0.8rem; } }
        
        h2 { font-size: 1.5rem; color: #1e293b; margin-bottom: 0.5rem; }
        @media (max-width: 768px) { h2 { font-size: 1.2rem; } }
        
        .subtext { color: #475569; margin-bottom: 2rem; font-size: 0.9rem; }
        @media (max-width: 768px) { .subtext { margin-bottom: 1rem; font-size: 0.8rem; } }
        
        .card { background: white; border-radius: 16px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; margin-bottom: 1.5rem; }
        @media (max-width: 768px) { .card { padding: 1rem; } }
        
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 0.3rem; color: #334155; font-size: 0.9rem; }
        .form-group input, .form-group select { width: 100%; padding: 0.6rem 0.8rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; transition: all 0.3s; }
        .form-group input:focus { border-color: var(--primary); outline: none; }
        
        .btn-success { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; padding: 0.6rem 1.2rem; border-radius: 30px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        .btn-success:hover { opacity: 0.9; transform: translateY(-2px); }
        .btn-danger { background: #ef4444; color: white; border: none; padding: 0.4rem 0.8rem; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 0.8rem; }
        .btn-danger:hover { background: #dc2626; }
        .btn-secondary { background: #f1f5f9; color: #334155; border: 1px solid #e2e8f0; padding: 0.6rem 1.2rem; border-radius: 8px; cursor: pointer; font-weight: 600; }
        .btn-secondary:hover { background: #e2e8f0; }
        
        .municipio-row { display: grid; grid-template-columns: 1fr 1fr auto; gap: 0.5rem; align-items: center; margin-bottom: 0.5rem; padding: 0.5rem; background: #f8fafc; border-radius: 8px; }
        @media (max-width: 768px) { .municipio-row { grid-template-columns: 1fr; gap: 0.3rem; } }
        .municipio-row input[type="text"] { padding: 0.4rem 0.6rem; border: 1px solid #e2e8f0; border-radius: 6px; }
        .municipio-row input[type="number"] { padding: 0.4rem 0.6rem; border: 1px solid #e2e8f0; border-radius: 6px; width: 100px; }
        .municipio-row .checkbox-label { display: flex; align-items: center; gap: 0.3rem; font-size: 0.8rem; white-space: nowrap; }
        
        .btn-agregar-mun { background: #3b82f6; color: white; border: none; padding: 0.6rem 1rem; border-radius: 8px; cursor: pointer; font-weight: 600; margin-top: 0.5rem; }
        .btn-agregar-mun:hover { background: #2563eb; }
        
        .guardar-btn { text-align: right; margin-top: 1.5rem; }
        @media (max-width: 768px) { .guardar-btn { text-align: center; } .btn-success { width: 100%; padding: 0.8rem; } }
        
        .mensaje { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-size: 0.85rem; }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        .mensaje.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        .info-box { background: #dbeafe; padding: 1rem; border-radius: 8px; border: 1px solid #bfdbfe; margin-bottom: 1rem; }
        .info-box p { color: #1e40af; margin: 0; font-size: 0.85rem; }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <h2>🏛️ Agregar Nueva Provincia</h2>
        <p class="subtext">Crea una nueva provincia con sus municipios y costos de envío globales</p>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
        <?php endif; ?>
        
        <div class="info-box">
            <p>⚠️ <strong>Importante:</strong> Los costos que definas aquí serán los <strong>costos globales</strong> que se mostrarán a todos los proveedores. Cada proveedor podrá personalizar sus costos en <strong>"Mis Envíos"</strong>.</p>
        </div>
        
        <form method="POST" id="formProvincia">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="accion" value="agregar_provincia">
            
            <div class="form-group">
                <label for="provincia_nombre">Nombre de la Provincia *</label>
                <input type="text" id="provincia_nombre" name="provincia_nombre" required placeholder="Ej: Camagüey, Holguín, Santiago de Cuba...">
            </div>
            
            <div style="margin-top: 1.5rem; margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
                <h3 style="font-size: 1.1rem; color: #1e293b;">📌 Municipios</h3>
                <button type="button" class="btn-agregar-mun" onclick="agregarMunicipio()">+ Agregar Municipio</button>
            </div>
            
            <div id="municipios-container">
                <!-- Los municipios se agregan con JS -->
            </div>
            
            <div class="guardar-btn">
                <button type="submit" class="btn-success">💾 Crear Provincia con Municipios</button>
            </div>
        </form>
    </div>
</div>

<script>
let municipioCount = 0;

function agregarMunicipio(nombre = '', costo = 0, activo = 1) {
    const container = document.getElementById('municipios-container');
    const row = document.createElement('div');
    row.className = 'municipio-row';
    row.id = 'municipio-' + municipioCount;
    
    row.innerHTML = `
        <input type="text" name="municipios[]" placeholder="Nombre del municipio" value="${nombre}" required>
        <input type="number" name="costos[]" step="0.01" min="0" placeholder="Costo <?php echo $moneda_simbolo; ?>" value="${costo}" style="width: 100%;">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <label class="checkbox-label">
                <input type="checkbox" name="municipio_activo[]" value="1" ${activo ? 'checked' : ''}>
                Activo
            </label>
            <button type="button" class="btn-danger" onclick="eliminarMunicipio(${municipioCount})">✕</button>
        </div>
    `;
    
    container.appendChild(row);
    municipioCount++;
}

function eliminarMunicipio(id) {
    const row = document.getElementById('municipio-' + id);
    if (row && document.querySelectorAll('.municipio-row').length > 1) {
        row.remove();
    } else {
        alert('Debes tener al menos un municipio');
    }
}

// Inicializar con un municipio
document.addEventListener('DOMContentLoaded', function() {
    agregarMunicipio('', 0, 1);
});

setTimeout(function() {
    const mensaje = document.querySelector('.mensaje');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(function() {
            if (mensaje) mensaje.remove();
        }, 500);
    }
}, 5000);
</script>

<?php
$conn->close();
?>
<?php
// ============================================
// GESTIÓN DE MONEDAS DEL SISTEMA
// Super Admin / Gerente: catálogo global + configuración por proveedor
// Proveedor: solo su configuración
// Predeterminada fija: USD
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once '../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor'];
$rol_actual = $_SESSION['rol'] ?? '';
if (!in_array($rol_actual, $roles_permitidos)) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

$es_global = in_array($rol_actual, ['Super Admin', 'Gerente']);
$es_proveedor = ($rol_actual === 'Proveedor');

// ============================================
// DETECTAR PROVEEDOR A CONFIGURAR
// ============================================
$proveedor_id_config = 0;
if ($es_proveedor) {
    $proveedor_id_config = obtenerProveedorId($conn, $_SESSION['usuario_id'] ?? 0, $rol_actual);
    if ($proveedor_id_config <= 0) {
        $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: ../admin.php');
        exit;
    }
} else {
    $proveedor_id_config = intval($_GET['proveedor_id'] ?? $_POST['proveedor_id'] ?? 0);
}

$prov_data = null;
if ($proveedor_id_config > 0) {
    $stmt = $conn->prepare("SELECT id, nombre_tienda FROM proveedores WHERE id = ? AND activo = 1");
    $stmt->bind_param("i", $proveedor_id_config);
    $stmt->execute();
    $prov_data = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$prov_data) {
        $_SESSION['mensaje'] = '❌ Proveedor no encontrado o inactivo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/monedas.php');
        exit;
    }
}

// ============================================
// CSRF
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================
function monedaEstaEnUso($conn, $codigo) {
    $usos = [];

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM proveedor_monedas WHERE moneda = ? AND activo = 1");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($r['total'] > 0) $usos[] = intval($r['total']) . " proveedor(es) en venta";

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM proveedor_monedas WHERE moneda = ? AND permite_adquisicion = 1");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($r['total'] > 0) $usos[] = intval($r['total']) . " proveedor(es) en adquisición";

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM proveedor_tasas WHERE moneda = ?");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($r['total'] > 0) $usos[] = intval($r['total']) . " tasa(s)";

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM pedidos WHERE moneda = ?");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($r['total'] > 0) $usos[] = intval($r['total']) . " pedido(s)";

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM carritos WHERE moneda = ? AND estado = 'pendiente'");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($r['total'] > 0) $usos[] = intval($r['total']) . " carrito(s)";

    return $usos;
}

function proveedoresQueUsanMoneda($conn, $codigo) {
    $lista = [];
    $stmt = $conn->prepare("
        SELECT p.nombre_tienda, pm.activo, pm.permite_adquisicion
        FROM proveedor_monedas pm
        INNER JOIN proveedores p ON p.id = pm.proveedor_id
        WHERE pm.moneda = ?
          AND (pm.activo = 1 OR pm.permite_adquisicion = 1)
          AND p.activo = 1
        ORDER BY p.nombre_tienda ASC
    ");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $lista[] = $row;
    }
    $stmt->close();
    return $lista;
}

function contarMonedasActivas($conn) {
    $r = $conn->query("SELECT COUNT(*) AS total FROM tazas_cambio WHERE activo = 1")->fetch_assoc();
    return intval($r['total']);
}

// ============================================
// PROCESAR ACCIONES POST
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/monedas.php' . ($proveedor_id_config > 0 ? '?proveedor_id=' . $proveedor_id_config : ''));
        exit;
    }

    $accion = $_POST['accion'] ?? '';
    $errores = [];

    // ============================================
    // ACCIONES GLOBALES (solo Super Admin / Gerente)
    // ============================================
    if ($es_global) {

        // CREAR
        if ($accion === 'crear') {
            $codigo = strtoupper(trim($_POST['codigo'] ?? ''));
            $nombre = trim($_POST['nombre'] ?? '');
            $simbolo = trim($_POST['simbolo'] ?? '');
            $tasa = floatval($_POST['tasa'] ?? 1);
            $activo = isset($_POST['activo']) ? 1 : 0;

            if (!preg_match('/^[A-Z]{3}$/', $codigo)) $errores[] = "Código debe ser 3 letras mayúsculas";
            if (strlen($nombre) < 2 || strlen($nombre) > 50) $errores[] = "Nombre entre 2 y 50 caracteres";
            if (strlen($simbolo) < 1 || strlen($simbolo) > 10) $errores[] = "Símbolo entre 1 y 10 caracteres";
            if ($tasa <= 0) $errores[] = "Tasa debe ser mayor a 0";

            if (empty($errores)) {
                $stmt = $conn->prepare("SELECT id FROM tazas_cambio WHERE codigo = ?");
                $stmt->bind_param("s", $codigo);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) $errores[] = "Ya existe la moneda $codigo";
                $stmt->close();
            }

            if (empty($errores)) {
                $stmt = $conn->prepare("INSERT INTO tazas_cambio (codigo, nombre, simbolo, tasa, activo, predeterminada) VALUES (?, ?, ?, ?, ?, 0)");
                $stmt->bind_param("sssdi", $codigo, $nombre, $simbolo, $tasa, $activo);
                if ($stmt->execute()) {
                    $_SESSION['mensaje'] = "✅ Moneda $codigo creada";
                    $_SESSION['tipo_mensaje'] = 'exito';
                } else {
                    $_SESSION['mensaje'] = '❌ Error al crear';
                    $_SESSION['tipo_mensaje'] = 'error';
                }
                $stmt->close();
            } else {
                $_SESSION['mensaje'] = '❌ ' . implode('<br>', $errores);
                $_SESSION['tipo_mensaje'] = 'error';
            }
            header('Location: /configuracion/monedas.php');
            exit;
        }

        // EDITAR
        if ($accion === 'editar') {
            $id = intval($_POST['id'] ?? 0);
            $codigo = strtoupper(trim($_POST['codigo'] ?? ''));
            $nombre = trim($_POST['nombre'] ?? '');
            $simbolo = trim($_POST['simbolo'] ?? '');
            $tasa = floatval($_POST['tasa'] ?? 1);
            $activo = isset($_POST['activo']) ? 1 : 0;

            if ($id <= 0) $errores[] = "ID inválido";
            if (!preg_match('/^[A-Z]{3}$/', $codigo)) $errores[] = "Código debe ser 3 letras mayúsculas";
            if (strlen($nombre) < 2 || strlen($nombre) > 50) $errores[] = "Nombre entre 2 y 50 caracteres";
            if (strlen($simbolo) < 1 || strlen($simbolo) > 10) $errores[] = "Símbolo entre 1 y 10 caracteres";
            if ($tasa <= 0) $errores[] = "Tasa debe ser mayor a 0";

            $moneda_actual = null;
            if (empty($errores)) {
                $stmt = $conn->prepare("SELECT * FROM tazas_cambio WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $moneda_actual = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if (!$moneda_actual) $errores[] = "Moneda no encontrada";
            }

            if (empty($errores) && $codigo !== $moneda_actual['codigo']) {
                $stmt = $conn->prepare("SELECT id FROM tazas_cambio WHERE codigo = ? AND id != ?");
                $stmt->bind_param("si", $codigo, $id);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) $errores[] = "Ya existe $codigo";
                $stmt->close();

                $usos = monedaEstaEnUso($conn, $moneda_actual['codigo']);
                if (!empty($usos)) $errores[] = "No puedes cambiar el código: " . implode(', ', $usos);
            }

            if ($moneda_actual && $moneda_actual['predeterminada'] == 1 && $activo == 0) {
                $errores[] = "No puedes desactivar la moneda predeterminada (USD)";
            }

            if (empty($errores)) {
                $stmt = $conn->prepare("UPDATE tazas_cambio SET codigo = ?, nombre = ?, simbolo = ?, tasa = ?, activo = ? WHERE id = ?");
                $stmt->bind_param("sssdii", $codigo, $nombre, $simbolo, $tasa, $activo, $id);
                if ($stmt->execute()) {
                    $_SESSION['mensaje'] = "✅ Moneda actualizada";
                    $_SESSION['tipo_mensaje'] = 'exito';
                } else {
                    $_SESSION['mensaje'] = '❌ Error al actualizar';
                    $_SESSION['tipo_mensaje'] = 'error';
                }
                $stmt->close();
            } else {
                $_SESSION['mensaje'] = '❌ ' . implode('<br>', $errores);
                $_SESSION['tipo_mensaje'] = 'error';
            }
            header('Location: /configuracion/monedas.php');
            exit;
        }

        // TOGGLE ACTIVO
        if ($accion === 'toggle_activo') {
            $id = intval($_POST['id'] ?? 0);

            $stmt = $conn->prepare("SELECT codigo, activo, predeterminada FROM tazas_cambio WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $moneda = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$moneda) {
                $_SESSION['mensaje'] = '❌ Moneda no encontrada';
                $_SESSION['tipo_mensaje'] = 'error';
                header('Location: /configuracion/monedas.php');
                exit;
            }

            $nuevo_activo = $moneda['activo'] ? 0 : 1;

            if ($nuevo_activo == 0 && $moneda['predeterminada'] == 1) {
                $_SESSION['mensaje'] = '❌ No puedes desactivar la predeterminada';
                $_SESSION['tipo_mensaje'] = 'error';
                header('Location: /configuracion/monedas.php');
                exit;
            }

            if ($nuevo_activo == 0 && contarMonedasActivas($conn) <= 1) {
                $_SESSION['mensaje'] = '❌ Debe haber al menos una moneda activa';
                $_SESSION['tipo_mensaje'] = 'error';
                header('Location: /configuracion/monedas.php');
                exit;
            }

            // Bloquear si algún proveedor la usa para venta o adquisición
            if ($nuevo_activo == 0) {
                $usos_prov = proveedoresQueUsanMoneda($conn, $moneda['codigo']);
                if (!empty($usos_prov)) {
                    $partes = [];
                    foreach ($usos_prov as $u) {
                        $modos = [];
                        if ((int)$u['activo'] === 1) $modos[] = 'venta';
                        if ((int)$u['permite_adquisicion'] === 1) $modos[] = 'adquisición';
                        $partes[] = '🏪 ' . $u['nombre_tienda'] . ' (' . implode(' y ', $modos) . ')';
                    }
                    $_SESSION['mensaje'] = '❌ No puedes desactivar ' . htmlspecialchars($moneda['codigo']) .
                        ': está en uso por: ' . implode(', ', $partes) .
                        '. Desactívala primero en la configuración de cada proveedor.';
                    $_SESSION['tipo_mensaje'] = 'error';
                    header('Location: /configuracion/monedas.php');
                    exit;
                }
            }

            $stmt = $conn->prepare("UPDATE tazas_cambio SET activo = ? WHERE id = ?");
            $stmt->bind_param("ii", $nuevo_activo, $id);
            $stmt->execute();
            $stmt->close();

            $_SESSION['mensaje'] = $nuevo_activo ? "✅ Activada" : "✅ Desactivada";
            $_SESSION['tipo_mensaje'] = 'exito';
            header('Location: /configuracion/monedas.php');
            exit;
        }

        // ELIMINAR
        if ($accion === 'eliminar') {
            $id = intval($_POST['id'] ?? 0);

            $stmt = $conn->prepare("SELECT codigo, predeterminada FROM tazas_cambio WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $moneda = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$moneda) {
                $_SESSION['mensaje'] = '❌ Moneda no encontrada';
                $_SESSION['tipo_mensaje'] = 'error';
                header('Location: /configuracion/monedas.php');
                exit;
            }

            if ($moneda['predeterminada'] == 1) {
                $_SESSION['mensaje'] = '❌ No puedes eliminar la predeterminada (USD)';
                $_SESSION['tipo_mensaje'] = 'error';
                header('Location: /configuracion/monedas.php');
                exit;
            }

            $usos = monedaEstaEnUso($conn, $moneda['codigo']);
            if (!empty($usos)) {
                $_SESSION['mensaje'] = '❌ En uso: ' . implode(', ', $usos);
                $_SESSION['tipo_mensaje'] = 'error';
                header('Location: /configuracion/monedas.php');
                exit;
            }

            $stmt = $conn->prepare("DELETE FROM tazas_cambio WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();

            $_SESSION['mensaje'] = "✅ Eliminada {$moneda['codigo']}";
            $_SESSION['tipo_mensaje'] = 'exito';
            header('Location: /configuracion/monedas.php');
            exit;
        }

    } // fin if ($es_global)

    // ============================================
    // GUARDAR CONFIGURACIÓN DEL PROVEEDOR
    // ============================================
    if ($accion === 'guardar_proveedor') {
        if ($proveedor_id_config <= 0) {
            $_SESSION['mensaje'] = '❌ Proveedor no válido';
            $_SESSION['tipo_mensaje'] = 'error';
            header('Location: /configuracion/monedas.php');
            exit;
        }

        if ($es_proveedor) {
            $propio_id = obtenerProveedorId($conn, $_SESSION['usuario_id'] ?? 0, $rol_actual);
            if ($propio_id != $proveedor_id_config) {
                $_SESSION['mensaje'] = '❌ No tienes permiso para modificar otro proveedor';
                $_SESSION['tipo_mensaje'] = 'error';
                header('Location: /configuracion/monedas.php');
                exit;
            }
        }

        $acepta = $_POST['acepta'] ?? [];
        $usar_global = $_POST['usar_global'] ?? [];
        $tasas = $_POST['tasa'] ?? [];
        $adquisicion = $_POST['adquisicion'] ?? [];

        $monedas_activas = [];
        $stmt = $conn->prepare("SELECT codigo, tasa FROM tazas_cambio WHERE activo = 1");
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $monedas_activas[] = $row;
        }
        $stmt->close();

        $guardadas = 0;

        foreach ($monedas_activas as $m) {
            $codigo = $m['codigo'];
            $tasa_global = (float)$m['tasa'];

            $acepta_moneda = isset($acepta[$codigo]) ? 1 : 0;
            $adquisicion_moneda = isset($adquisicion[$codigo]) ? 1 : 0;
            $usa_global = isset($usar_global[$codigo]) ? 1 : 0;
            $tasa_propia = isset($tasas[$codigo]) ? (float)$tasas[$codigo] : $tasa_global;
            if ($tasa_propia <= 0) $tasa_propia = $tasa_global;

            $stmt = $conn->prepare("SELECT id FROM proveedor_monedas WHERE proveedor_id = ? AND moneda = ?");
            $stmt->bind_param("is", $proveedor_id_config, $codigo);
            $stmt->execute();
            $existe = $stmt->get_result()->num_rows > 0;
            $stmt->close();

            if ($existe) {
                $stmt = $conn->prepare("UPDATE proveedor_monedas SET activo = ?, permite_adquisicion = ? WHERE proveedor_id = ? AND moneda = ?");
                $stmt->bind_param("iiis", $acepta_moneda, $adquisicion_moneda, $proveedor_id_config, $codigo);
                $stmt->execute();
                $stmt->close();
            } elseif ($acepta_moneda == 1 || $adquisicion_moneda == 1) {
                $stmt = $conn->prepare("INSERT INTO proveedor_monedas (proveedor_id, moneda, activo, permite_adquisicion) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("isii", $proveedor_id_config, $codigo, $acepta_moneda, $adquisicion_moneda);
                $stmt->execute();
                $stmt->close();
            }

            if ($acepta_moneda == 1 || $adquisicion_moneda == 1) {
                $stmt = $conn->prepare("SELECT id FROM proveedor_tasas WHERE proveedor_id = ? AND moneda = ?");
                $stmt->bind_param("is", $proveedor_id_config, $codigo);
                $stmt->execute();
                $existe_tasa = $stmt->get_result()->num_rows > 0;
                $stmt->close();

                if ($existe_tasa) {
                    $stmt = $conn->prepare("UPDATE proveedor_tasas SET tasa = ?, usa_tasa_global = ? WHERE proveedor_id = ? AND moneda = ?");
                    $stmt->bind_param("diis", $tasa_propia, $usa_global, $proveedor_id_config, $codigo);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $conn->prepare("INSERT INTO proveedor_tasas (proveedor_id, moneda, tasa, usa_tasa_global) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("isdi", $proveedor_id_config, $codigo, $tasa_propia, $usa_global);
                    $stmt->execute();
                    $stmt->close();
                }
            }

            $guardadas++;
        }

        $_SESSION['mensaje'] = "✅ Configuración de monedas guardada ({$guardadas} monedas revisadas)";
        $_SESSION['tipo_mensaje'] = 'exito';
        header('Location: /configuracion/monedas.php' . ($es_global && $proveedor_id_config > 0 ? '?proveedor_id=' . $proveedor_id_config : ''));
        exit;
    }
}

// ============================================
// MENSAJES
// ============================================
$mensaje = '';
$tipo_mensaje = '';
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// OBTENER MONEDAS
// ============================================
$monedas = [];
$stmt = $conn->prepare("SELECT id, codigo, nombre, simbolo, tasa, activo, predeterminada, fecha_actualizacion FROM tazas_cambio ORDER BY predeterminada DESC, activo DESC, codigo ASC");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $monedas[] = $row;
}
$stmt->close();

$usos_por_moneda = [];
foreach ($monedas as $m) {
    $usos_por_moneda[$m['codigo']] = monedaEstaEnUso($conn, $m['codigo']);
}

// ============================================
// PROVEEDORES (para el selector de Super Admin / Gerente)
// ============================================
$proveedores = [];
if ($es_global) {
    $res = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda");
    while ($row = $res->fetch_assoc()) {
        $proveedores[] = $row;
    }
}

// ============================================
// CONFIGURACIÓN ACTUAL DEL PROVEEDOR SELECCIONADO
// ============================================
$config_proveedor = [];
if ($proveedor_id_config > 0) {
    $stmt = $conn->prepare("SELECT moneda, activo, permite_adquisicion FROM proveedor_monedas WHERE proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_config);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $config_proveedor[$row['moneda']]['activo'] = (int)$row['activo'];
        $config_proveedor[$row['moneda']]['permite_adquisicion'] = (int)$row['permite_adquisicion'];
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT moneda, tasa, usa_tasa_global FROM proveedor_tasas WHERE proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_config);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $config_proveedor[$row['moneda']]['tasa'] = (float)$row['tasa'];
        $config_proveedor[$row['moneda']]['usa_tasa_global'] = (int)$row['usa_tasa_global'];
    }
    $stmt->close();
}

require_once '../header.php';
?>

<style>
/* ============================================ */
/* ESTILOS MONEDAS.PHP                         */
/* ============================================ */
.container-monedas { max-width: 1100px; margin: 2rem auto; padding: 0 1rem; }
.card-monedas { background: white; border-radius: 16px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; margin-bottom: 1.5rem; }

.header-monedas { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.8rem; margin-bottom: 1.5rem; }
.header-monedas h2 { font-size: 1.3rem; color: #1e293b; margin: 0; }

.header-actions-monedas { display: flex; gap: 0.5rem; flex-wrap: wrap; }

.btn-volver-m, .btn-nueva-m {
    padding: 0.5rem 1rem; text-decoration: none; border-radius: 8px;
    font-weight: 600; font-size: 0.85rem; transition: all 0.3s;
    display: inline-block; border: none; cursor: pointer;
}
.btn-volver-m { background: #edf2f7; color: #4a5568; }
.btn-volver-m:hover { background: #e2e8f0; transform: translateY(-2px); }
.btn-nueva-m { background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2)); color: white; }
.btn-nueva-m:hover { opacity: 0.9; transform: translateY(-2px); }

.subtext-m { color: #475569; font-size: 0.9rem; margin-bottom: 1.5rem; line-height: 1.5; }

.tabla-wrapper-m { overflow-x: auto; -webkit-overflow-scrolling: touch; border-radius: 12px; border: 1px solid #e2e8f0; }
table.tabla-monedas { width: 100%; border-collapse: collapse; min-width: 800px; background: white; }
table.tabla-monedas thead { background: #f8fafc; }
table.tabla-monedas th { text-align: left; padding: 0.8rem 1rem; font-size: 0.8rem; color: #475569; font-weight: 700; text-transform: uppercase; border-bottom: 2px solid #e2e8f0; }
table.tabla-monedas td { padding: 0.8rem 1rem; font-size: 0.9rem; color: #1e293b; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
table.tabla-monedas tbody tr:hover { background: #f8fafc; }

.moneda-cell-m { display: flex; align-items: center; gap: 0.6rem; }
.moneda-simbolo-m {
    display: inline-flex; align-items: center; justify-content: center;
    width: 36px; height: 36px;
    background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
    color: white; border-radius: 50%; font-size: 1rem; font-weight: bold; flex-shrink: 0;
}
.moneda-cell-m strong { font-size: 1rem; color: #1e293b; display: block; }
.moneda-cell-m small { color: #64748b; font-size: 0.75rem; }

.badge-m { display: inline-block; font-size: 0.7rem; padding: 0.2rem 0.6rem; border-radius: 10px; font-weight: 600; margin-right: 0.3rem; }
.badge-base-m { background: #dbeafe; color: #1e40af; }

.usos-info-m { font-size: 0.7rem; color: #64748b; margin-top: 0.3rem; }

.acciones-m { display: flex; gap: 0.4rem; flex-wrap: nowrap; align-items: center; }
.btn-mini-m {
    width: 32px; height: 32px;
    display: inline-flex; align-items: center; justify-content: center;
    border-radius: 6px; font-size: 0.85rem; border: none;
    cursor: pointer; transition: all 0.2s; padding: 0;
}
.btn-mini-m.editar { background: #dbeafe; color: #1e40af; }
.btn-mini-m.editar:hover { background: #bfdbfe; }
.btn-mini-m.eliminar { background: #fee2e2; color: #991b1b; }
.btn-mini-m.eliminar:hover { background: #fecaca; }
.btn-mini-m:disabled { opacity: 0.3; cursor: not-allowed; }

.btn-circulo-m {
    width: 22px; height: 22px;
    border-radius: 50%;
    border: 2px solid transparent;
    cursor: pointer;
    padding: 0;
    transition: all 0.2s;
    display: inline-block;
    flex-shrink: 0;
    box-shadow: 0 0 0 2px rgba(0,0,0,0.05);
}
.btn-circulo-m.activo { background: #10b981; border-color: #059669; }
.btn-circulo-m.activo:hover { background: #34d399; transform: scale(1.15); box-shadow: 0 0 0 4px rgba(16,185,129,0.2); }
.btn-circulo-m.inactivo { background: #ef4444; border-color: #dc2626; }
.btn-circulo-m.inactivo:hover { background: #f87171; transform: scale(1.15); box-shadow: 0 0 0 4px rgba(239,68,68,0.2); }
.btn-circulo-m:disabled { opacity: 0.5; cursor: not-allowed; transform: none !important; }

.tr-edicion-m { background: #f0f9ff !important; }
.tr-edicion-m td { padding: 0 !important; border-bottom: 2px solid #3b82f6 !important; }
.form-inline-m { padding: 1rem; background: #f0f9ff; border-left: 4px solid #3b82f6; }
.form-inline-m h4 { margin: 0 0 0.8rem 0; font-size: 0.95rem; color: #1e40af; }
.form-grid-m {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 0.8rem; margin-bottom: 1rem;
}
.form-grid-m .campo-m label {
    display: block; font-size: 0.75rem; font-weight: 700; color: #475569;
    text-transform: uppercase; margin-bottom: 0.3rem;
}
.form-grid-m .campo-m input[type="text"],
.form-grid-m .campo-m input[type="number"] {
    width: 100%; padding: 0.5rem 0.7rem; border: 2px solid #e2e8f0;
    border-radius: 6px; font-size: 0.9rem;
}
.form-grid-m .campo-m input:focus {
    border-color: #3b82f6; outline: none;
    box-shadow: 0 0 0 3px rgba(59,130,246,0.1);
}
.form-grid-m .campo-m.checkbox-m { display: flex; align-items: center; gap: 0.5rem; margin-top: 1.3rem; }
.form-grid-m .campo-m.checkbox-m input { width: 18px; height: 18px; accent-color: #3b82f6; }

.form-acciones-m { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.btn-accion-m {
    padding: 0.6rem 1.2rem; border-radius: 8px; font-weight: 600;
    font-size: 0.85rem; border: none; cursor: pointer; transition: all 0.2s;
}
.btn-accion-m.guardar { background: linear-gradient(135deg, #10b981, #059669); color: white; }
.btn-accion-m.guardar:hover { opacity: 0.9; transform: translateY(-1px); }
.btn-accion-m.cancelar { background: #edf2f7; color: #4a5568; }
.btn-accion-m.cancelar:hover { background: #e2e8f0; }

.nueva-moneda-m {
    background: #f0fdf4; border: 2px dashed #10b981; border-radius: 12px;
    padding: 1.2rem; margin-top: 1rem; display: none;
}
.nueva-moneda-m.activo { display: block; }
.nueva-moneda-m h4 { margin: 0 0 1rem 0; color: #065f46; font-size: 1rem; }

.modal-conf-m {
    display: none; position: fixed; inset: 0;
    background: rgba(15, 23, 42, 0.6); z-index: 99999;
    align-items: center; justify-content: center; padding: 1rem;
}
.modal-conf-m.activo { display: flex; }
.modal-conf-content-m {
    background: white; border-radius: 16px; padding: 1.5rem;
    max-width: 500px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    max-height: 90vh; overflow-y: auto;
}
.modal-conf-content-m h3 { margin: 0 0 0.5rem 0; font-size: 1.15rem; color: #1e293b; }
.modal-conf-content-m .subtitulo-m { color: #64748b; font-size: 0.85rem; margin-bottom: 1rem; }
.diff-m { background: #f8fafc; border-radius: 10px; padding: 1rem; margin-bottom: 1rem; border: 1px solid #e2e8f0; }
.diff-m .fila-diff-m { display: flex; justify-content: space-between; align-items: center; padding: 0.4rem 0; border-bottom: 1px solid #f1f5f9; font-size: 0.85rem; flex-wrap: wrap; gap: 0.5rem; }
.diff-m .fila-diff-m:last-child { border-bottom: none; }
.diff-m .campo-nombre-m { font-weight: 600; color: #475569; min-width: 90px; }
.diff-m .valor-m { display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap; }
.diff-m .valor-viejo-m { color: #991b1b; text-decoration: line-through; background: #fee2e2; padding: 0.1rem 0.4rem; border-radius: 4px; font-size: 0.8rem; }
.diff-m .valor-nuevo-m { color: #065f46; background: #d1fae5; padding: 0.1rem 0.4rem; border-radius: 4px; font-size: 0.8rem; font-weight: 600; }
.modal-conf-acciones-m { display: flex; gap: 0.6rem; flex-wrap: wrap; }
.modal-conf-acciones-m button {
    flex: 1; padding: 0.8rem 1rem; border-radius: 10px;
    font-weight: 600; cursor: pointer; border: none; font-size: 0.9rem;
    min-width: 120px;
}
.btn-cancelar-conf-m { background: #edf2f7; color: #4a5568; }
.btn-confirmar-conf-m { background: linear-gradient(135deg, #10b981, #059669); color: white; }

.mensaje-m {
    position: fixed; top: 140px; right: 20px; left: 20px;
    padding: 0.8rem 1rem; border-radius: 10px; z-index: 99998;
    animation: slideInM 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    font-size: 0.85rem; max-width: 500px; margin: 0 auto;
}
.mensaje-m.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
.mensaje-m.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
@keyframes slideInM { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

.empty-state-m { text-align: center; padding: 3rem 1rem; color: #64748b; }
.empty-state-m .icono-m { font-size: 3rem; margin-bottom: 1rem; }

.info-box-m { background: #dbeafe; padding: 1rem; border-radius: 8px; border: 1px solid #bfdbfe; margin-top: 1.5rem; }
.info-box-m p { color: #1e40af; margin: 0; font-size: 0.85rem; line-height: 1.5; }

.cfg-selector { background:#f8fafc;border-radius:12px;padding:1rem;margin-bottom:1.5rem;border:1px solid #e2e8f0; }
.cfg-selector label { display:block;font-size:0.75rem;font-weight:700;color:#475569;text-transform:uppercase;margin-bottom:0.3rem; }
.cfg-selector select { width:100%;max-width:400px;padding:0.6rem 0.8rem;border:2px solid #e2e8f0;border-radius:8px;font-size:0.9rem; }
.cfg-tabla input[type="number"] { width:120px;padding:0.4rem 0.6rem;border:2px solid #e2e8f0;border-radius:6px;font-size:0.85rem; }
.cfg-tabla input[type="checkbox"] { width:18px;height:18px;accent-color:#3b82f6;cursor:pointer; }
.cfg-tabla input:disabled { background:#f1f5f9;color:#94a3b8; }

@media (max-width: 768px) {
    .container-monedas { margin: 1rem auto; padding: 0 0.7rem; }
    .card-monedas { padding: 1rem; }

    .header-monedas { flex-direction: column; align-items: stretch; gap: 0.7rem; margin-bottom: 1rem; }
    .header-monedas h2 { font-size: 1.05rem; }
    .header-actions-monedas { display: grid; grid-template-columns: 1fr; gap: 0.4rem; }
    .btn-volver-m, .btn-nueva-m { width: 100%; text-align: center; padding: 0.55rem 0.8rem; font-size: 0.85rem; }

    .subtext-m { font-size: 0.85rem; margin-bottom: 1rem; }

    .cfg-selector { padding: 0.8rem; margin-bottom: 1rem; }
    .cfg-selector select { max-width: 100%; font-size: 0.9rem; }

    .tabla-wrapper-m { border: none; overflow-x: visible; border-radius: 0; background: transparent; }
    table.tabla-monedas { min-width: auto; display: block; width: 100%; background: transparent; }
    table.tabla-monedas thead { display: none; }
    table.tabla-monedas tbody { display: block; width: 100%; }

    table.tabla-monedas tr {
        display: grid;
        grid-template-columns: 1fr auto;
        grid-template-areas:
            "moneda  tasa"
            "estado  estado"
            "acciones acciones";
        gap: 0.35rem 0.6rem;
        align-items: center;
        background: #ffffff;
        border: 1px solid #dbe3ec;
        border-left: 4px solid var(--primary, #667eea);
        border-radius: 14px;
        margin-bottom: 0.9rem;
        padding: 0.85rem 0.9rem;
        box-shadow: 0 3px 10px rgba(15, 23, 42, 0.06);
    }
    table.tabla-monedas tr:last-child { margin-bottom: 0; }

    table.tabla-monedas td {
        display: block;
        border: none;
        padding: 0;
        font-size: 0.9rem;
        line-height: 1.35;
        text-align: left;
    }
    table.tabla-monedas td:before { display: none; }

    table.tabla-monedas td:nth-child(1) {
        grid-area: moneda;
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 0.4rem;
        flex-wrap: wrap;
    }
    table.tabla-monedas td:nth-child(1)::before {
        content: "MONEDA";
        font-size: 0.65rem;
        font-weight: 800;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        flex-shrink: 0;
    }

    table.tabla-monedas td:nth-child(3) {
        grid-area: tasa;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 0.35rem;
        white-space: nowrap;
        font-weight: 700;
        color: #1e293b;
        font-size: 0.9rem;
    }
    table.tabla-monedas td:nth-child(3)::before {
        content: "TASA";
        font-size: 0.65rem;
        font-weight: 800;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    table.tabla-monedas td:nth-child(2) { display: none; }

    table.tabla-monedas td:nth-child(4) {
        grid-area: estado;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 0.3rem;
        padding-top: 0.3rem;
        border-top: 1px dashed #e2e8f0;
    }
    table.tabla-monedas td:nth-child(4):empty { display: none; }
    table.tabla-monedas td:nth-child(4) .badge-m {
        font-size: 0.68rem; padding: 0.15rem 0.5rem; margin: 0;
    }
    table.tabla-monedas td:nth-child(4) .usos-info-m {
        font-size: 0.68rem; margin: 0; display: inline; color: #64748b;
    }

    table.tabla-monedas td:nth-child(5) {
        grid-area: acciones;
        justify-self: start;
        padding-top: 0.3rem;
        border-top: 1px dashed #e2e8f0;
        width: 100%;
    }
    table.tabla-monedas .acciones-m {
        display: flex; flex-wrap: nowrap; gap: 0.45rem;
        align-items: center; justify-content: flex-start;
    }
    table.tabla-monedas .btn-mini-m { width: 38px; height: 38px; font-size: 1rem; }
    table.tabla-monedas .btn-circulo-m { width: 28px; height: 28px; }

    table.tabla-monedas .moneda-cell-m {
        display: flex; align-items: center; gap: 0.5rem;
        flex-wrap: nowrap; min-width: 0; flex: 1 1 auto;
    }
    table.tabla-monedas .moneda-simbolo-m {
        width: 34px; height: 34px; font-size: 0.95rem; flex-shrink: 0;
    }
    table.tabla-monedas .moneda-cell-m > div {
        min-width: 0; display: flex; flex-direction: column; line-height: 1.15;
    }
    table.tabla-monedas .moneda-cell-m strong {
        font-size: 0.92rem; white-space: nowrap; overflow: hidden;
        text-overflow: ellipsis; max-width: 100%;
    }
    table.tabla-monedas .moneda-cell-m small { font-size: 0.7rem; color: #64748b; }

    .cfg-tabla table.tabla-monedas tr {
        grid-template-columns: 1fr auto;
        grid-template-areas:
            "moneda   tasaGlob"
            "acepta   adquisicion"
            "tasaProp usar";
        border-left-color: #f59e0b;
    }

    .cfg-tabla table.tabla-monedas td::before {
        display: inline-block !important;
        content: "" !important;
    }

    .cfg-tabla table.tabla-monedas td:nth-child(1) {
        grid-area: moneda;
        display: flex;
        align-items: center;
        gap: 0.4rem;
        min-width: 0;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(1)::before {
        content: "MONEDA" !important;
        display: inline-block !important;
        font-size: 0.65rem;
        font-weight: 800;
        color: #334155;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        flex-shrink: 0;
        margin: 0;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(1) .moneda-cell-m {
        display: flex; align-items: center; gap: 0.45rem;
        min-width: 0; flex: 1 1 auto;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(1) .moneda-simbolo-m {
        width: 30px; height: 30px; font-size: 0.85rem; flex-shrink: 0;
        color: #ffffff;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(1) .moneda-cell-m strong {
        font-size: 0.88rem; color: #1e293b;
        white-space: normal; overflow: visible; text-overflow: clip;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(1) .moneda-cell-m small {
        font-size: 0.68rem; color: #64748b;
    }

    .cfg-tabla table.tabla-monedas td:nth-child(2) {
        grid-area: tasaGlob;
        display: flex; align-items: center; justify-content: flex-end;
        gap: 0.3rem; font-size: 0.85rem; color: #1e293b;
        white-space: nowrap; font-weight: 600;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(2)::before {
        content: "GLOBAL" !important;
        display: inline-block !important;
        font-size: 0.62rem; font-weight: 800; color: #334155;
        text-transform: uppercase; letter-spacing: 0.4px;
        margin: 0;
    }

    .cfg-tabla table.tabla-monedas td:nth-child(3) {
        grid-area: acepta;
        display: flex; align-items: center; gap: 0.4rem;
        padding-top: 0.35rem; border-top: 1px dashed #e2e8f0;
        color: #1e293b;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(3)::before {
        content: "ACEPTA" !important;
        display: inline-block !important;
        font-size: 0.65rem; font-weight: 800; color: #334155;
        text-transform: uppercase; letter-spacing: 0.4px;
        margin: 0;
    }

    .cfg-tabla table.tabla-monedas td:nth-child(4) {
        grid-area: adquisicion;
        display: flex; align-items: center; justify-content: flex-end; gap: 0.4rem;
        padding-top: 0.35rem; border-top: 1px dashed #e2e8f0;
        color: #1e293b;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(4)::before {
        content: "ADQUISICIÓN" !important;
        display: inline-block !important;
        font-size: 0.65rem; font-weight: 800; color: #334155;
        text-transform: uppercase; letter-spacing: 0.4px;
        margin: 0;
    }

    .cfg-tabla table.tabla-monedas td:nth-child(5) {
        grid-area: tasaProp;
        display: flex; align-items: center; justify-content: flex-end;
        gap: 0.4rem;
        padding-top: 0.35rem; border-top: 1px dashed #e2e8f0;
        color: #1e293b;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(5)::before {
        content: "TASA PROPIA" !important;
        display: inline-block !important;
        font-size: 0.65rem; font-weight: 800; color: #334155;
        text-transform: uppercase; letter-spacing: 0.4px;
        margin: 0;
    }

    .cfg-tabla table.tabla-monedas td:nth-child(6) {
        grid-area: usar;
        display: flex; align-items: center; justify-content: flex-end; gap: 0.4rem;
        padding-top: 0.35rem; border-top: 1px dashed #e2e8f0;
        color: #1e293b;
    }
    .cfg-tabla table.tabla-monedas td:nth-child(6)::before {
        content: "USAR GLOBAL" !important;
        display: inline-block !important;
        font-size: 0.65rem; font-weight: 800; color: #334155;
        text-transform: uppercase; letter-spacing: 0.4px;
        margin: 0;
    }

    .cfg-tabla input[type="number"] {
        width: 90px; max-width: 40vw; font-size: 16px; padding: 0.4rem 0.5rem;
        text-align: right; color: #1e293b; background: #fff;
        border: 2px solid #e2e8f0; border-radius: 6px;
    }
    .cfg-tabla input[type="checkbox"] { width: 22px; height: 22px; }

    .tr-edicion-m { display: block !important; border-left-color: #3b82f6 !important; }
    .tr-edicion-m td { display: block !important; }
    .tr-edicion-m td:before { display: none !important; }
    .form-inline-m { padding: 0.8rem; border-left-width: 3px; }
    .form-inline-m h4 { font-size: 0.9rem; margin-bottom: 0.6rem; }

    .form-grid-m { grid-template-columns: 1fr; gap: 0.7rem; }
    .form-grid-m .campo-m label { font-size: 0.72rem; }
    .form-grid-m .campo-m input[type="text"],
    .form-grid-m .campo-m input[type="number"] {
        font-size: 16px; padding: 0.6rem 0.7rem;
    }
    .form-grid-m .campo-m.checkbox-m { margin-top: 0; }

    .form-acciones-m { flex-direction: column; gap: 0.5rem; }
    .btn-accion-m { width: 100%; padding: 0.7rem 1rem; font-size: 0.9rem; }

    .nueva-moneda-m { padding: 0.9rem; border-radius: 14px; }

    .modal-conf-content-m { padding: 1.1rem; }
    .modal-conf-content-m h3 { font-size: 1.05rem; }
    .diff-m { padding: 0.8rem; }
    .diff-m .fila-diff-m { font-size: 0.82rem; }
    .modal-conf-acciones-m { flex-direction: column; }
    .modal-conf-acciones-m button { width: 100%; min-width: 0; padding: 0.7rem; }

    .mensaje-m { top: 120px; right: 12px; left: 12px; max-width: none; margin: 0; font-size: 0.82rem; }

    .empty-state-m { padding: 2rem 1rem; }
    .empty-state-m .icono-m { font-size: 2.2rem; }
    .info-box-m { padding: 0.8rem; margin-top: 1rem; border-radius: 12px; }
    .info-box-m p { font-size: 0.8rem; }
}

@media (max-width: 380px) {
    .container-monedas { padding: 0 0.5rem; }
    .card-monedas { padding: 0.8rem; }
    .header-monedas h2 { font-size: 1rem; }
    .btn-volver-m, .btn-nueva-m { font-size: 0.8rem; padding: 0.5rem 0.7rem; }
    table.tabla-monedas tr { padding: 0.7rem; gap: 0.3rem 0.5rem; }
    .btn-mini-m { width: 34px; height: 34px; font-size: 0.9rem; }
    .btn-circulo-m { width: 24px; height: 24px; }
    .moneda-simbolo-m { width: 30px; height: 30px; font-size: 0.85rem; }
    .moneda-cell-m strong { font-size: 0.88rem; }
    .cfg-tabla input[type="number"] { width: 80px; }
}

@media (min-width: 769px) {
    .mensaje-m { top: 150px; right: 20px; left: auto; max-width: 400px; margin: 0; }
}
</style>

<div class="container-monedas">

    <?php if ($mensaje): ?>
        <div class="mensaje-m <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <div class="card-monedas">
    <div class="header-monedas">
        <h2><?php echo $proveedor_id_config > 0 ? '🏪 Configuración de Monedas por Proveedor' : '🌍 Gestión de Monedas'; ?></h2>
        <div class="header-actions-monedas">
            <?php if ($proveedor_id_config == 0 && $es_global): ?>
                <button type="button" class="btn-nueva-m" onclick="toggleNuevaMoneda()">➕ Nueva moneda</button>
                <a href="/configuracion/tasas.php" class="btn-volver-m">← Monedas y Tasas</a>
                <a href="../configuracion.php" class="btn-volver-m">← Panel</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($es_global): ?>
    <div class="cfg-selector">
        <label for="select_proveedor">Seleccionar proveedor</label>
        <select id="select_proveedor" onchange="cambiarProveedor(this.value)">
            <option value="0" <?php echo $proveedor_id_config == 0 ? 'selected' : ''; ?>>🌍 Global (catálogo de monedas)</option>
            <?php foreach ($proveedores as $prov): ?>
                <option value="<?php echo (int)$prov['id']; ?>" <?php echo $proveedor_id_config == $prov['id'] ? 'selected' : ''; ?>>
                    🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php endif; ?>

    <?php if ($proveedor_id_config == 0 && $es_global): ?>
        <div class="subtext-m">
            Administra las monedas del sistema. <strong>USD</strong> es la moneda base y no se puede eliminar ni desactivar.
        </div>

        <?php if (empty($monedas)): ?>
            <div class="empty-state-m">
                <div class="icono-m">🌍</div>
                <p>No hay monedas registradas.</p>
            </div>
        <?php else: ?>
            <div class="tabla-wrapper-m">
                <table class="tabla-monedas">
                    <thead>
                        <tr>
                            <th>Moneda</th>
                            <th>Código</th>
                            <th>Tasa</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($monedas as $m):
                            $es_base = $m['predeterminada'] == 1;
                            $usos = $usos_por_moneda[$m['codigo']] ?? [];
                            $en_uso = !empty($usos);
                        ?>
                        <tr id="fila_<?php echo $m['id']; ?>">
                            <td data-label="Moneda">
                                <div class="moneda-cell-m">
                                    <span class="moneda-simbolo-m"><?php echo htmlspecialchars($m['simbolo']); ?></span>
                                    <div>
                                        <strong><?php echo htmlspecialchars($m['nombre']); ?></strong>
                                        <small><?php echo htmlspecialchars($m['codigo']); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td data-label="Código"><strong><?php echo htmlspecialchars($m['codigo']); ?></strong></td>
                            <td data-label="Tasa"><?php echo $es_base ? '1.0000' : number_format($m['tasa'], 4); ?></td>
                            <td data-label="Estado">
                                <?php if ($es_base): ?>
                                    <span class="badge-m badge-base-m">Predeterminada</span>
                                <?php endif; ?>
                                <?php if ($en_uso): ?>
                                    <div class="usos-info-m">🔗 En uso: <?php echo htmlspecialchars(implode(', ', $usos)); ?></div>
                                <?php endif; ?>
                            </td>
                            <td data-label="Acciones">
                                <div class="acciones-m">
                                    <button type="button" class="btn-mini-m editar" title="Editar"
                                            data-id="<?php echo $m['id']; ?>"
                                            data-codigo="<?php echo htmlspecialchars($m['codigo']); ?>"
                                            data-nombre="<?php echo htmlspecialchars($m['nombre']); ?>"
                                            data-simbolo="<?php echo htmlspecialchars($m['simbolo']); ?>"
                                            data-tasa="<?php echo $m['tasa']; ?>"
                                            data-activo="<?php echo $m['activo']; ?>"
                                            data-predeterminada="<?php echo $m['predeterminada']; ?>"
                                            onclick="editarInline(this)">✏️</button>

                                    <?php if (!$es_base): ?>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('¿<?php echo $m['activo'] ? 'Desactivar' : 'Activar'; ?> <?php echo htmlspecialchars($m['codigo']); ?>?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                            <input type="hidden" name="accion" value="toggle_activo">
                                            <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                                            <button type="submit" class="btn-circulo-m <?php echo $m['activo'] ? 'activo' : 'inactivo'; ?>" title="<?php echo $m['activo'] ? 'Desactivar' : 'Activar'; ?>"></button>
                                        </form>

                                        <form method="POST" style="display:inline;" onsubmit="return confirm('¿Eliminar <?php echo htmlspecialchars($m['codigo']); ?>? No se puede deshacer.');">
                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                            <input type="hidden" name="accion" value="eliminar">
                                            <input type="hidden" name="id" value="<?php echo $m['id']; ?>">
                                            <button type="submit" class="btn-mini-m eliminar" title="Eliminar" <?php echo $en_uso ? 'disabled' : ''; ?>>🗑️</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <div class="nueva-moneda-m" id="bloque_nueva">
            <h4>➕ Nueva Moneda</h4>
            <form method="POST" id="form_nueva" onsubmit="return confirmarNueva(event)">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="hidden" name="accion" value="crear">
                <div class="form-grid-m">
                    <div class="campo-m">
                        <label>Símbolo</label>
                        <input type="text" name="simbolo" id="n_simbolo" maxlength="10" required placeholder="$">
                    </div>
                    <div class="campo-m">
                        <label>Nombre</label>
                        <input type="text" name="nombre" id="n_nombre" maxlength="50" required placeholder="Peso Mexicano">
                    </div>
                    <div class="campo-m">
                        <label>Código ISO</label>
                        <input type="text" name="codigo" id="n_codigo" maxlength="3" required pattern="[A-Za-z]{3}" style="text-transform: uppercase;" placeholder="MXN">
                    </div>
                    <div class="campo-m">
                        <label>Tasa (por 1 USD)</label>
                        <input type="number" name="tasa" id="n_tasa" step="0.0001" min="0.0001" required value="1.0000">
                    </div>
                    <div class="campo-m checkbox-m">
                        <input type="checkbox" name="activo" id="n_activo" value="1" checked>
                        <label for="n_activo" style="text-transform:none; font-size:0.85rem; margin:0;">Activa</label>
                    </div>
                </div>
                <div class="form-acciones-m">
                    <button type="submit" class="btn-accion-m guardar">💾 Guardar</button>
                    <button type="button" class="btn-accion-m cancelar" onclick="toggleNuevaMoneda()">Cancelar</button>
                </div>
            </form>
        </div>

        <div class="info-box-m">
            <p>💡 <strong>Reglas:</strong> USD es la moneda base (no editable ni eliminable). Una moneda en uso por proveedores, tasas, pedidos o carritos no se puede eliminar.</p>
        </div>

    <?php elseif ($proveedor_id_config > 0): ?>
        <div class="subtext-m">
            Configurando: <strong><?php echo htmlspecialchars($prov_data['nombre_tienda']); ?></strong> (ID <?php echo (int)$proveedor_id_config; ?>)
            <br><small>Marca <strong>Acepta</strong> para las monedas en las que vende y <strong>Adquisición</strong> para las que compra. Puedes marcar ambas.</small>
        </div>

        <?php if (empty($monedas)): ?>
            <div class="empty-state-m"><p>No hay monedas en el catálogo global.</p></div>
        <?php else: ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="hidden" name="accion" value="guardar_proveedor">
                <input type="hidden" name="proveedor_id" value="<?php echo (int)$proveedor_id_config; ?>">

                <div class="tabla-wrapper-m cfg-tabla">
                    <table class="tabla-monedas">
                        <thead>
                            <tr>
                                <th>Moneda</th>
                                <th>Tasa global</th>
                                <th>Acepta (venta)</th>
                                <th>Adquisición</th>
                                <th>Tasa propia</th>
                                <th>Usar global</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($monedas as $m):
                                $codigo = $m['codigo'];
                                $cfg = $config_proveedor[$codigo] ?? [];
                                $acepta = $cfg['activo'] ?? ($codigo === 'USD' ? 1 : 0);
                                $adquisicion = $cfg['permite_adquisicion'] ?? 0;
                                $tasa_propia = $cfg['tasa'] ?? (float)$m['tasa'];
                                $usa_global = $cfg['usa_tasa_global'] ?? 1;
                            ?>
                            <tr>
                                <td data-label="Moneda">
                                    <strong><?php echo htmlspecialchars($codigo); ?></strong>
                                    <?php if ($m['predeterminada'] == 1): ?>
                                        <span class="badge-m badge-base-m">Base</span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="Tasa global"><?php echo number_format((float)$m['tasa'], 4); ?></td>
                                <td data-label="Acepta (venta)">
                                    <input type="checkbox" name="acepta[<?php echo htmlspecialchars($codigo); ?>]" value="1"
                                           <?php echo $acepta ? 'checked' : ''; ?>
                                           <?php echo $codigo === 'USD' ? 'disabled checked' : ''; ?>>
                                    <?php if ($codigo === 'USD'): ?>
                                        <input type="hidden" name="acepta[USD]" value="1">
                                    <?php endif; ?>
                                </td>
                                <td data-label="Adquisición">
                                    <input type="checkbox" name="adquisicion[<?php echo htmlspecialchars($codigo); ?>]" value="1"
                                           <?php echo $adquisicion ? 'checked' : ''; ?>>
                                </td>
                                <td data-label="Tasa propia">
                                    <input type="number" step="0.0001" min="0.0001"
                                           name="tasa[<?php echo htmlspecialchars($codigo); ?>]"
                                           value="<?php echo number_format($tasa_propia, 4, '.', ''); ?>"
                                           <?php echo $usa_global ? 'disabled' : ''; ?>>
                                </td>
                                <td data-label="Usar global">
                                    <input type="checkbox" name="usar_global[<?php echo htmlspecialchars($codigo); ?>]" value="1"
                                           <?php echo $usa_global ? 'checked' : ''; ?>
                                           onchange="toggleTasaPropia(this, '<?php echo htmlspecialchars($codigo); ?>')">
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="form-acciones-m" style="margin-top:1rem;">
                    <button type="submit" class="btn-accion-m guardar">💾 Guardar configuración</button>
                </div>
            </form>
        <?php endif; ?>

    <?php else: ?>
        <div class="empty-state-m">
            <div class="icono-m">🏪</div>
            <p>No hay proveedor asociado.</p>
        </div>
    <?php endif; ?>
</div>

<div class="modal-conf-m" id="modal_conf">
    <div class="modal-conf-content-m">
        <h3 id="conf_titulo">Confirmar</h3>
        <p class="subtitulo-m" id="conf_subtitulo"></p>
        <div class="diff-m" id="conf_diff"></div>
        <div class="modal-conf-acciones-m">
            <button type="button" class="btn-cancelar-conf-m" onclick="cerrarConfirmacion()">Cancelar</button>
            <button type="button" class="btn-confirmar-conf-m" id="conf_btn_confirmar">Confirmar</button>
        </div>
    </div>
</div>

<script>
function editarInline(btn) {
    cerrarEdicion();

    const d = btn.dataset;
    const fila = document.getElementById('fila_' + d.id);
    if (!fila) return;

    const esBase = d.predeterminada == '1';

    const tr = document.createElement('tr');
    tr.className = 'tr-edicion-m';
    tr.id = 'edicion_' + d.id;
    tr.innerHTML = `
        <td colspan="5">
            <div class="form-inline-m">
                <h4>✏️ Editar: ${d.codigo}</h4>
                <form method="POST" onsubmit="return confirmarEdicion(event, ${d.id})" data-form-id="${d.id}">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="hidden" name="accion" value="editar">
                    <input type="hidden" name="id" value="${d.id}">

                    <div class="form-grid-m">
                        <div class="campo-m">
                            <label>Símbolo</label>
                            <input type="text" name="simbolo" id="e_simbolo_${d.id}" value="${d.simbolo}" maxlength="10" required>
                        </div>
                        <div class="campo-m">
                            <label>Nombre</label>
                            <input type="text" name="nombre" id="e_nombre_${d.id}" value="${d.nombre}" maxlength="50" required>
                        </div>
                        <div class="campo-m">
                            <label>Código ISO</label>
                            <input type="text" name="codigo" id="e_codigo_${d.id}" value="${d.codigo}" maxlength="3" required pattern="[A-Za-z]{3}" style="text-transform: uppercase;">
                        </div>
                        <div class="campo-m">
                            <label>Tasa (por 1 USD)</label>
                            <input type="number" name="tasa" id="e_tasa_${d.id}" value="${d.tasa}" step="0.0001" min="0.0001" required>
                        </div>
                        <div class="campo-m checkbox-m">
                            <input type="checkbox" name="activo" id="e_activo_${d.id}" value="1" ${d.activo == '1' ? 'checked' : ''} ${esBase ? 'disabled' : ''}>
                            <label for="e_activo_${d.id}" style="text-transform:none; font-size:0.85rem; margin:0;">Activa</label>
                            ${esBase ? '<input type="hidden" name="activo" value="1">' : ''}
                        </div>
                    </div>

                    <div class="form-acciones-m">
                        <button type="submit" class="btn-accion-m guardar">💾 Guardar</button>
                        <button type="button" class="btn-accion-m cancelar" onclick="cerrarEdicion()">Cancelar</button>
                    </div>
                </form>
            </div>
        </td>
    `;

    fila.parentNode.insertBefore(tr, fila.nextSibling);

    setTimeout(() => {
        const primerInput = tr.querySelector('input[name="simbolo"]');
        if (primerInput) primerInput.focus();
    }, 50);
}

function cerrarEdicion() {
    const existente = document.querySelector('.tr-edicion-m');
    if (existente) existente.remove();
}

document.addEventListener('mousedown', function(e) {
    const edicionAbierta = document.querySelector('.tr-edicion-m');
    if (edicionAbierta) {
        const clickDentroEdicion = e.target.closest('.tr-edicion-m');
        const clickEnBotonEditar = e.target.closest('.btn-mini-m.editar');
        if (!clickDentroEdicion && !clickEnBotonEditar) {
            cerrarEdicion();
        }
    }
    const bloqueNueva = document.getElementById('bloque_nueva');
    if (bloqueNueva && bloqueNueva.classList.contains('activo')) {
        const clickDentroNueva = e.target.closest('#bloque_nueva');
        const clickEnBotonNueva = e.target.closest('.btn-nueva-m');
        if (!clickDentroNueva && !clickEnBotonNueva) {
            toggleNuevaMoneda();
        }
    }
});

function toggleNuevaMoneda() {
    const bloque = document.getElementById('bloque_nueva');
    if (!bloque) return;
    bloque.classList.toggle('activo');
    if (bloque.classList.contains('activo')) {
        setTimeout(() => document.getElementById('n_simbolo')?.focus(), 100);
    }
}

let formPendiente = null;

function confirmarEdicion(event, id) {
    event.preventDefault();

    const form = event.target;
    const codigo = form.querySelector('[name="codigo"]').value.toUpperCase();
    const nombre = form.querySelector('[name="nombre"]').value;
    const simbolo = form.querySelector('[name="simbolo"]').value;
    const tasa = form.querySelector('[name="tasa"]').value;
    const activoCheck = form.querySelector('[name="activo"]');
    const activo = activoCheck && activoCheck.checked ? '1' : '0';

    const btnOriginal = document.querySelector(`.btn-mini-m.editar[data-id="${id}"]`);
    const d = btnOriginal.dataset;

    const diff = [];
    if (simbolo !== d.simbolo) diff.push({ campo: 'Símbolo', viejo: d.simbolo, nuevo: simbolo });
    if (nombre !== d.nombre) diff.push({ campo: 'Nombre', viejo: d.nombre, nuevo: nombre });
    if (codigo !== d.codigo) diff.push({ campo: 'Código', viejo: d.codigo, nuevo: codigo });
    if (parseFloat(tasa) != parseFloat(d.tasa)) diff.push({ campo: 'Tasa', viejo: parseFloat(d.tasa).toFixed(4), nuevo: parseFloat(tasa).toFixed(4) });
    if (activo !== d.activo) diff.push({ campo: 'Activa', viejo: d.activo == '1' ? 'Sí' : 'No', nuevo: activo == '1' ? 'Sí' : 'No' });

    if (diff.length === 0) {
        alert('No has hecho ningún cambio.');
        return false;
    }

    mostrarConfirmacion({
        titulo: `✏️ Modificar moneda ${d.codigo}`,
        subtitulo: 'Revisa los cambios antes de confirmar:',
        diff: diff,
        form: form
    });

    return false;
}

function confirmarNueva(event) {
    event.preventDefault();

    const form = event.target;
    const codigo = form.querySelector('[name="codigo"]').value.toUpperCase();
    const nombre = form.querySelector('[name="nombre"]').value;
    const simbolo = form.querySelector('[name="simbolo"]').value;
    const tasa = parseFloat(form.querySelector('[name="tasa"]').value).toFixed(4);
    const activo = form.querySelector('[name="activo"]').checked ? 'Sí' : 'No';

    const diff = [
        { campo: 'Símbolo', viejo: null, nuevo: simbolo },
        { campo: 'Nombre', viejo: null, nuevo: nombre },
        { campo: 'Código', viejo: null, nuevo: codigo },
        { campo: 'Tasa', viejo: null, nuevo: tasa },
        { campo: 'Activa', viejo: null, nuevo: activo }
    ];

    mostrarConfirmacion({
        titulo: `➕ Crear nueva moneda: ${codigo}`,
        subtitulo: 'Se creará una nueva moneda con estos datos:',
        diff: diff,
        form: form
    });

    return false;
}

function mostrarConfirmacion({ titulo, subtitulo, diff, form }) {
    document.getElementById('conf_titulo').textContent = titulo;
    document.getElementById('conf_subtitulo').textContent = subtitulo;

    let html = '';
    diff.forEach(item => {
        if (item.viejo === null) {
            html += `<div class="fila-diff-m">
                <span class="campo-nombre-m">${item.campo}</span>
                <span class="valor-m"><span class="valor-nuevo-m">${item.nuevo}</span></span>
            </div>`;
        } else {
            html += `<div class="fila-diff-m">
                <span class="campo-nombre-m">${item.campo}</span>
                <span class="valor-m">
                    <span class="valor-viejo-m">${item.viejo}</span>
                    <span style="color:#64748b;">→</span>
                    <span class="valor-nuevo-m">${item.nuevo}</span>
                </span>
            </div>`;
        }
    });

    document.getElementById('conf_diff').innerHTML = html;
    formPendiente = form;
    document.getElementById('modal_conf').classList.add('activo');
}

function cerrarConfirmacion() {
    document.getElementById('modal_conf').classList.remove('activo');
    formPendiente = null;
}

document.getElementById('conf_btn_confirmar')?.addEventListener('click', function() {
    if (formPendiente) formPendiente.submit();
});

document.getElementById('modal_conf')?.addEventListener('click', function(e) {
    if (e.target === this) cerrarConfirmacion();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        cerrarConfirmacion();
        cerrarEdicion();
    }
});

setTimeout(function() {
    const mensaje = document.querySelector('.mensaje-m');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(() => mensaje.remove(), 500);
    }
}, 5000);

function cambiarProveedor(valor) {
    const url = new URL(window.location.href);
    if (valor && valor !== '0') {
        url.searchParams.set('proveedor_id', valor);
    } else {
        url.searchParams.delete('proveedor_id');
    }
    window.location.href = url.toString();
}

function toggleTasaPropia(checkbox, codigo) {
    const input = document.querySelector('input[name="tasa[' + codigo + ']"]');
    if (input) input.disabled = checkbox.checked;
}
</script>

</main>

<?php
$conn->close();
?>
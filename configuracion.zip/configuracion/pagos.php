<?php
// ============================================
// CONFIGURACIÓN DE PAGOS - POR PROVEEDOR
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_actual = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol']);
$es_proveedor = esRolProveedor($_SESSION['rol']);
$es_admin = in_array($_SESSION['rol'], ['Super Admin', 'Gerente']);

if ($es_proveedor && $proveedor_id_actual == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// Validar que el proveedor existe y está activo
if ($proveedor_id_actual > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_actual);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// OBTENER PROVEEDOR A EDITAR
// ============================================
$proveedor_id_editar = 0;

if ($es_proveedor) {
    $proveedor_id_editar = $proveedor_id_actual;
} else {
    if (isset($_GET['proveedor_id']) && is_numeric($_GET['proveedor_id'])) {
        $proveedor_id_editar = intval($_GET['proveedor_id']);
    }
}

// Si es administrador y está editando un proveedor específico, verificar que existe
if ($es_admin && $proveedor_id_editar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_editar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/pagos.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// CARGAR PASARELAS DESDE LA BD (escalable)
// ============================================
$pasarelas_db = [];
$stmt_pas = $conn->prepare("SELECT slug, nombre, tipo, icono, monedas, activo, orden FROM pasarelas WHERE activo = 1 ORDER BY orden");
$stmt_pas->execute();
$res_pas = $stmt_pas->get_result();
while ($row = $res_pas->fetch_assoc()) {
    $pasarelas_db[$row['slug']] = $row;
}
$stmt_pas->close();

// Array para compatibilidad con el resto del código
$pasarelas_con_checkbox = [];
foreach ($pasarelas_db as $slug => $info) {
    $pasarelas_con_checkbox[$slug] = $slug . '_activo';
}

// ============================================
// CARGAR MONEDAS ACTIVAS DEL SISTEMA (escalable)
// ============================================
$monedas_disponibles = [];
$stmt_mon = $conn->prepare("SELECT codigo FROM tazas_cambio WHERE activo = 1 ORDER BY predeterminada DESC, codigo ASC");
$stmt_mon->execute();
$res_mon = $stmt_mon->get_result();
while ($row = $res_mon->fetch_assoc()) {
    $monedas_disponibles[] = $row['codigo'];
}
$stmt_mon->close();

// ============================================
// CARGAR CAMPOS DE PASARELAS DESDE LA BD (escalable)
// ============================================
$todos_los_campos = [];
$stmt_campos = $conn->prepare("
    SELECT pc.clave, pc.tipo, pc.etiqueta, pc.descripcion, pc.opciones, pc.requerido, pc.orden,
           pc.pasarela_slug,
           p.nombre AS grupo_nombre
    FROM pasarelas_campos pc
    INNER JOIN pasarelas p ON p.slug = pc.pasarela_slug
    WHERE p.activo = 1 AND pc.visible = 1
    ORDER BY p.orden, pc.orden
");
$stmt_campos->execute();
$res_campos = $stmt_campos->get_result();
while ($row = $res_campos->fetch_assoc()) {
    $todos_los_campos[$row['clave']] = [
        'tipo' => $row['tipo'],
        'etiqueta' => $row['etiqueta'],
        'descripcion' => $row['descripcion'],
        'grupo' => $row['grupo_nombre'],
        'orden' => $row['orden'],
        'requerido' => $row['requerido'],
        'opciones' => $row['opciones'],
        'pasarela_slug' => $row['pasarela_slug'],
    ];
}
$stmt_campos->close();

// ============================================
// PROCESAR GUARDADO
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/pagos.php" . ($proveedor_id_editar ? "?proveedor_id=$proveedor_id_editar" : ""));
        exit;
    }
    
   $proveedor_id_guardar = isset($_POST['proveedor_id']) && !empty($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : 0;

if ($es_proveedor) {
    $proveedor_id_guardar = $proveedor_id_actual;
}

// Verificar que el proveedor existe (si no es global)
if ($proveedor_id_guardar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_guardar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/pagos.php');
        exit;
    }
    $stmt_check->close();
}
    
        // Desactivar checkboxes que no llegaron
    $stmt = $conn->prepare("SELECT clave FROM configuracion WHERE grupo = 'pagos' AND clave LIKE '%_activo'");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($cb = $result->fetch_assoc()) {
        if (!isset($_POST['config_' . $cb['clave']])) {
            $sql = "INSERT INTO configuracion (clave, valor, grupo, proveedor_id) 
                    VALUES (?, '0', 'pagos', ?) 
                    ON DUPLICATE KEY UPDATE valor = VALUES(valor)";
            $upd = $conn->prepare($sql);
            $upd->bind_param("si", $cb['clave'], $proveedor_id_guardar);
            $upd->execute();
            $upd->close();
        }
    }
    
    // Actualizar valores que llegaron
    foreach ($_POST as $clave => $valor) {
        if (strpos($clave, 'config_') === 0) {
            $clave_real = substr($clave, 7);
            
                        // Saltar campos especiales ya procesados
            if ($clave_real == 'pago_con_entrega_activo' || $clave_real == 'porcentaje_con_entrega' || $clave_real == 'pago_anticipado_activo') {
                continue;
            }
            
                       // Determinar tipo desde el array de campos
            $tipo_campo = null;
            if (isset($todos_los_campos[$clave_real])) {
                $tipo_campo = $todos_los_campos[$clave_real]['tipo'];
            }
            
            if ($tipo_campo) {
                switch ($tipo_campo) {
                    case 'boolean':
                        $valor = ($valor === 'on' || $valor === '1' || $valor === 1) ? '1' : '0';
                        break;
                    case 'numero':
                        $valor = floatval($valor);
                        break;
                    default:
                        $valor = trim(htmlspecialchars(strip_tags($valor)));
                        break;
                }
            }
            
            // Guardar con proveedor_id
            $sql = "INSERT INTO configuracion (clave, valor, grupo, proveedor_id) 
                    VALUES (?, ?, 'pagos', ?) 
                    ON DUPLICATE KEY UPDATE valor = VALUES(valor)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $clave_real, $valor, $proveedor_id_guardar);
            $stmt->execute();
            $stmt->close();
        }
    }
    
        // ===== ACTUALIZAR TIPO Y MONEDAS (SOLO GLOBAL, SOLO ADMIN) =====
    if ($es_admin && $proveedor_id_guardar == 0) {
        foreach ($pasarelas_db as $slug => $info) {
            $clave_activo = $slug . '_activo';
            
            // ----- Tipo -----
            $nombre_checkbox = 'tipo_pasarela_' . $slug;
            $tipo_nuevo = isset($_POST[$nombre_checkbox]) ? 'api' : 'manual';
            
            // Actualizar en `pasarelas` (nueva fuente de verdad)
            $stmt_tipo = $conn->prepare("UPDATE pasarelas SET tipo = ? WHERE slug = ?");
            $stmt_tipo->bind_param("ss", $tipo_nuevo, $slug);
            $stmt_tipo->execute();
            $stmt_tipo->close();
            
            // Retrocompatibilidad: actualizar también en configuracion
            $stmt_tipo_old = $conn->prepare("
                UPDATE configuracion 
                SET tipo_pasarela = ? 
                WHERE clave = ? 
                AND grupo = 'pagos' 
                AND proveedor_id = 0
            ");
            $stmt_tipo_old->bind_param("ss", $tipo_nuevo, $clave_activo);
            $stmt_tipo_old->execute();
            $stmt_tipo_old->close();
            
            // ----- Monedas -----
            $monedas_seleccionadas = [];
            foreach ($monedas_disponibles as $moneda) {
                $nombre_checkbox_mon = 'monedas_' . $slug . '_' . $moneda;
                if (isset($_POST[$nombre_checkbox_mon])) {
                    $monedas_seleccionadas[] = $moneda;
                }
            }
            
            $valor_monedas = !empty($monedas_seleccionadas) 
                ? implode(',', $monedas_seleccionadas) 
                : null;
            
            // Actualizar en `pasarelas` (nueva fuente de verdad)
            if ($valor_monedas === null) {
                $stmt_mon = $conn->prepare("UPDATE pasarelas SET monedas = NULL WHERE slug = ?");
                $stmt_mon->bind_param("s", $slug);
            } else {
                $stmt_mon = $conn->prepare("UPDATE pasarelas SET monedas = ? WHERE slug = ?");
                $stmt_mon->bind_param("ss", $valor_monedas, $slug);
            }
            $stmt_mon->execute();
            $stmt_mon->close();
            
            // Retrocompatibilidad: actualizar también en configuracion
            if ($valor_monedas === null) {
                $stmt_mon_old = $conn->prepare("
                    UPDATE configuracion 
                    SET monedas = NULL 
                    WHERE clave = ? 
                    AND grupo = 'pagos' 
                    AND proveedor_id = 0
                ");
                $stmt_mon_old->bind_param("s", $clave_activo);
            } else {
                $stmt_mon_old = $conn->prepare("
                    UPDATE configuracion 
                    SET monedas = ? 
                    WHERE clave = ? 
                    AND grupo = 'pagos' 
                    AND proveedor_id = 0
                ");
                $stmt_mon_old->bind_param("ss", $valor_monedas, $clave_activo);
            }
            $stmt_mon_old->execute();
            $stmt_mon_old->close();
        }
    }

    // Pago con entrega
    if (isset($_POST['config_pago_con_entrega_activo'])) {
        $valor_activo = '1';
    } else {
        $valor_activo = '0';
    }
    $stmt = $conn->prepare("INSERT INTO configuracion (clave, valor, grupo, proveedor_id) VALUES ('pago_con_entrega_activo', ?, 'general', ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)");
    $stmt->bind_param("si", $valor_activo, $proveedor_id_guardar);
    $stmt->execute();
    
    if (isset($_POST['config_porcentaje_con_entrega'])) {
        $porcentaje = intval($_POST['config_porcentaje_con_entrega']);
        $stmt = $conn->prepare("INSERT INTO configuracion (clave, valor, grupo, proveedor_id) VALUES ('porcentaje_con_entrega', ?, 'general', ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)");
        $stmt->bind_param("si", $porcentaje, $proveedor_id_guardar);
        $stmt->execute();
    }
    
// ⬇️ NUEVO: Pago anticipado (Pagar Todo)
    $valor_anticipado = isset($_POST['config_pago_anticipado_activo']) ? '1' : '0';
    $stmt = $conn->prepare("INSERT INTO configuracion (clave, valor, grupo, proveedor_id) VALUES ('pago_anticipado_activo', ?, 'general', ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)");
    $stmt->bind_param("si", $valor_anticipado, $proveedor_id_guardar);
    $stmt->execute();
    $stmt->close();
    // ⬆️ FIN NUEVO

    $_SESSION['mensaje'] = "✅ Configuración de pagos guardada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    
    $redirect_url = "/configuracion/pagos.php";
    if ($proveedor_id_guardar != 0) {
        $redirect_url .= "?proveedor_id=" . $proveedor_id_guardar;
    }
    header("Location: " . $redirect_url);
    exit;
}

// ============================================
// RECIBIR MENSAJES DE SESIÓN
// ============================================
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// OBTENER LISTA DE PROVEEDORES (PARA ADMIN)
// ============================================
if ($es_admin) {
    $sql_proveedores = "SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda";
    $proveedores_list = $conn->query($sql_proveedores);
}

// ============================================
// OBTENER VALORES GUARDADOS
// ============================================
$valores_guardados = [];

if ($proveedor_id_editar != 0) {
    // Buscar configuración del proveedor
    $stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE grupo = 'pagos' AND proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $valores_guardados[$row['clave']] = $row['valor'];
    }
    $stmt->close();
} else {
    // Buscar configuración global (solo para admin)
    $stmt = $conn->prepare("SELECT clave, valor FROM configuracion WHERE grupo = 'pagos' AND proveedor_id = 0");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $valores_guardados[$row['clave']] = $row['valor'];
    }
    $stmt->close();
}

// ============================================
// OBTENER PAGO CON ENTREGA
// ============================================
$pago_entrega_activo = '0';
$porcentaje_entrega = '40';

// Pago anticipado (Pagar Todo)
$pago_anticipado_activo = '1'; // default
if ($proveedor_id_editar != 0) {
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'pago_anticipado_activo' AND proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $pago_anticipado_activo = $row['valor'];
    }
    $stmt->close();
} else {
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'pago_anticipado_activo' AND proveedor_id = 0");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $pago_anticipado_activo = $row['valor'];
    }
    $stmt->close();
}

if ($proveedor_id_editar != 0) {
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'pago_con_entrega_activo' AND proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $pago_entrega_activo = $row['valor'];
    }
    $stmt->close();
    
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'porcentaje_con_entrega' AND proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_editar);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $porcentaje_entrega = $row['valor'];
    }
    $stmt->close();
} else {
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'pago_con_entrega_activo' AND proveedor_id = 0");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $pago_entrega_activo = $row['valor'];
    }
    $stmt->close();
    
    $stmt = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'porcentaje_con_entrega' AND proveedor_id = 0");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $porcentaje_entrega = $row['valor'];
    }
    $stmt->close();
}

// ============================================
// AGRUPAR CAMPOS POR GRUPO (el orden ya viene del SELECT)
// ============================================
$grupos = [];
foreach ($todos_los_campos as $clave => $campo) {
    $grupo = $campo['grupo'];
    if (!isset($grupos[$grupo])) {
        $grupos[$grupo] = [];
    }
    $campo['clave'] = $clave;
    $campo['valor'] = isset($valores_guardados[$clave]) ? $valores_guardados[$clave] : '';
    $grupos[$grupo][] = $campo;
}

// ============================================
// INCLUIR HEADER
// ============================================
require_once '../header.php';
?>
<style>
        * { box-sizing: border-box; }
        .container { max-width: 1400px; margin: 2rem auto; padding: 0 1rem; }
        @media (max-width: 768px) { .container { margin: 1rem auto; padding: 0 0.8rem; } }
        
        .card { background: white; border-radius: 16px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; margin-bottom: 1.5rem; }
        @media (max-width: 768px) { .card { padding: 1rem; } }
        
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem; }
        .header h2 { font-size: 1.3rem; color: #1e293b; margin: 0; }
        @media (max-width: 768px) { .header h2 { font-size: 1.1rem; } }
        
        .btn-volver { padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 0.85rem; transition: all 0.3s; }
        .btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }
        
        .selector-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; align-items: center; gap: 0.8rem; }
        .selector-proveedor label { font-weight: 600; color: #334155; }
        .selector-proveedor select { padding: 0.5rem 1rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; flex: 1; min-width: 200px; background: white; }
        .selector-proveedor .info { color: #64748b; font-size: 0.85rem; }
        
        .info-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #dbeafe; border-radius: 8px; border: 1px solid #bfdbfe; }
        .info-proveedor strong { color: #1e40af; }
        
        .badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.7rem; font-weight: 600; }
        .badge.global { background: #dbeafe; color: #1e40af; }
        .badge.personalizado { background: #fef3c7; color: #92400e; }
        .badge.sin_config { background: #fee2e2; color: #991b1b; }
        
        .pagos-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; margin-top: 1rem; }
        @media (max-width: 768px) { .pagos-grid { grid-template-columns: 1fr; } }
        
        .pago-columna { background: #f8fafc; border-radius: 12px; padding: 1rem; border: 1px solid #e2e8f0; }
        @media (min-width: 768px) { .pago-columna { padding: 1.2rem; } }
        
        .pago-columna h4 { color: #1e293b; margin-bottom: 0.8rem; padding-bottom: 0.5rem; border-bottom: 2px solid var(--primary); display: flex; align-items: center; gap: 0.5rem; font-size: 0.95rem; }
        
        .pago-item { margin-bottom: 0.8rem; padding: 0.5rem; background: white; border-radius: 8px; border: 1px solid #edf2f7; }
        .pago-item label { font-weight: 600; font-size: 0.8rem; color: #4a5568; display: block; margin-bottom: 0.2rem; }
        .pago-item .desc { font-size: 0.7rem; color: #718096; margin-bottom: 0.3rem; }
        .pago-item input[type="text"], .pago-item input[type="email"], .pago-item input[type="number"] { width: 100%; padding: 0.4rem 0.6rem; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.8rem; }
        .pago-item textarea { width: 100%; padding: 0.4rem 0.6rem; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.8rem; font-family: inherit; min-height: 60px; resize: vertical; }
        .pago-item .checkbox-item { display: flex; align-items: center; gap: 0.5rem; margin: 0.2rem 0; }
        .pago-item .checkbox-item input { width: 18px; height: 18px; margin: 0; }
        .pago-item .checkbox-item label { margin: 0; cursor: pointer; font-weight: 400; }
        
        .empty-campos { color: #94a3b8; font-size: 0.8rem; text-align: center; padding: 0.5rem; }
        
        .btn-guardar { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; padding: 0.8rem 2rem; border-radius: 30px; font-weight: 600; cursor: pointer; transition: 0.3s; float: right; font-size: 0.95rem; }
        .btn-guardar:hover { opacity: 0.9; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
        @media (max-width: 768px) { .btn-guardar { width: 100%; float: none; padding: 0.8rem; } }
        
        .clearfix::after { content: ""; clear: both; display: table; }
        
        .mensaje { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-size: 0.85rem; max-width: 500px; margin: 0 auto; }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; margin: 0; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        .mensaje.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        .info-box { background: #dbeafe; padding: 0.8rem 1rem; border-radius: 8px; border: 1px solid #bfdbfe; margin-top: 1rem; }
        .info-box p { color: #1e40af; margin: 0; font-size: 0.85rem; }
        
        .pago-con-entrega { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 0.8rem 1rem; margin-bottom: 1.5rem; display: flex; flex-wrap: wrap; align-items: center; gap: 1rem; }
        .pago-con-entrega h4 { margin: 0; color: #166534; font-size: 0.95rem; }
        .pago-con-entrega .checkbox-item { margin: 0; }
        .pago-con-entrega .input-group { display: flex; align-items: center; gap: 0.5rem; }
        .pago-con-entrega input[type="number"] { width: 70px; padding: 0.3rem 0.5rem; border: 1px solid #e2e8f0; border-radius: 6px; }
        .pago-con-entrega small { color: #718096; font-size: 0.75rem; }
 </style>

<div class="container">
    <div class="card">
        <div class="header">
            <h2>💳 Configuración de Pagos</h2>
            <a href="../configuracion.php" class="btn-volver">← Volver</a>
        </div>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
        <?php endif; ?>
        
        <?php if ($es_admin): ?>
        <div class="selector-proveedor">
            <label for="sel_proveedor"><strong>🏪 Proveedor:</strong></label>
            <select id="sel_proveedor" onchange="window.location.href = this.value">
                <option value="/configuracion/pagos.php">📊 Global (Sistema)</option>
                <?php 
                if ($proveedores_list) {
                    $proveedores_list->data_seek(0);
                    while($prov = $proveedores_list->fetch_assoc()): 
                ?>
                    <option value="/configuracion/pagos.php?proveedor_id=<?php echo $prov['id']; ?>" 
                            <?php echo ($proveedor_id_editar == $prov['id']) ? 'selected' : ''; ?>>
                        🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                    </option>
                <?php 
                    endwhile;
                }
                ?>
            </select>
            <?php if ($proveedor_id_editar != 0): ?>
                <span class="info">Editando proveedor ID: <?php echo $proveedor_id_editar; ?></span>
            <?php else: ?>
                <span class="info">Editando configuración global</span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php if ($es_proveedor): ?>
        <div class="info-proveedor">
            <strong>🏪 Tu Tienda:</strong> <?php echo htmlspecialchars($proveedor_id_actual); ?>
        </div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <?php if ($proveedor_id_editar): ?>
                <input type="hidden" name="proveedor_id" value="<?php echo $proveedor_id_editar; ?>">
            <?php endif; ?>
            
<!-- ⬇️ NUEVO: Pago anticipado -->
            <div class="pago-con-entrega" style="background:#f0f4ff; border-color:#bfdbfe;">
                <h4>💳 Pago anticipado (Pagar Todo)</h4>
                <div class="checkbox-item">
                    <input type="checkbox" name="config_pago_anticipado_activo" value="1" <?php echo $pago_anticipado_activo == '1' ? 'checked' : ''; ?>>
                    <label>Activar</label>
                </div>
                <small style="color:#718096; font-size:0.75rem;">Permite al cliente pagar el 100% por adelantado.</small>
            </div>
            <!-- ⬆️ FIN NUEVO -->

            <!-- Pago con entrega -->
            <div class="pago-con-entrega">
                <h4>🚚 Pago al entregar</h4>
                <div class="checkbox-item">
                    <input type="checkbox" name="config_pago_con_entrega_activo" value="1" <?php echo $pago_entrega_activo == '1' ? 'checked' : ''; ?>>
                    <label>Activar</label>
                </div>
                <div class="input-group">
                    <label>% al entregar:</label>
                    <input type="number" name="config_porcentaje_con_entrega" value="<?php echo htmlspecialchars($porcentaje_entrega); ?>" min="1" max="100" step="1">
                    <small>Ej: 40% → 40% al entregar, 60% al comprar</small>
                </div>
            </div>
            
            <!-- Métodos de pago -->
                        <div class="pagos-grid">
                                           <?php foreach ($grupos as $nombre_grupo => $campos): 
                    // Detectar slug de la pasarela (ya viene del SELECT)
                    $slug_pasarela = $campos[0]['pasarela_slug'] ?? null;
                    $clave_activo_pasarela = $slug_pasarela ? $slug_pasarela . '_activo' : null;
                    
                    // Leer tipo desde la tabla pasarelas
                    $tipo_actual = 'manual';
                    if ($slug_pasarela && isset($pasarelas_db[$slug_pasarela])) {
                        $tipo_actual = $pasarelas_db[$slug_pasarela]['tipo'];
                    }
                ?>
                                <div class="pago-columna">
                    <h4 style="display: flex; align-items: center; justify-content: space-between;">
                        <span><?php echo htmlspecialchars($nombre_grupo); ?></span>
                        <?php if ($slug_pasarela): ?>
                            <label style="font-weight: 400; font-size: 0.75rem; display: flex; align-items: center; gap: 0.3rem; cursor: <?php echo (!$es_admin || $proveedor_id_editar != 0) ? 'not-allowed' : 'pointer'; ?>; opacity: <?php echo (!$es_admin || $proveedor_id_editar != 0) ? '0.6' : '1'; ?>;">
                                <input type="checkbox" 
                                       name="tipo_pasarela_<?php echo htmlspecialchars($slug_pasarela); ?>" 
                                       value="api"
                                       <?php echo $tipo_actual === 'api' ? 'checked' : ''; ?>
                                       <?php echo (!$es_admin || $proveedor_id_editar != 0) ? 'disabled' : ''; ?>
                                       style="width: 16px; height: 16px; accent-color: var(--primary);">
                                API
                            </label>
                        <?php endif; ?>
                    </h4>
                    
                     <?php if ($slug_pasarela && $es_admin && $proveedor_id_editar == 0): 
                        // Leer monedas desde la tabla pasarelas (nueva fuente de verdad)
                        $monedas_actuales = [];
                        if (isset($pasarelas_db[$slug_pasarela]) && !empty($pasarelas_db[$slug_pasarela]['monedas'])) {
                            $monedas_actuales = array_map('trim', explode(',', $pasarelas_db[$slug_pasarela]['monedas']));
                        }
                    ?>
                        <div style="margin-bottom: 0.8rem; padding: 0.5rem; background: #fff; border-radius: 8px; border: 1px solid #edf2f7;">
                            <label style="font-weight: 600; font-size: 0.75rem; color: #4a5568; display: block; margin-bottom: 0.4rem;">
                                💱 Monedas aceptadas
                            </label>
                            <div style="display: flex; gap: 0.8rem; flex-wrap: wrap;">
                                <?php foreach ($monedas_disponibles as $moneda): ?>
                                    <label style="display: flex; align-items: center; gap: 0.3rem; cursor: pointer; font-weight: 400; font-size: 0.8rem;">
                                        <input type="checkbox" 
                                               name="monedas_<?php echo htmlspecialchars($slug_pasarela); ?>_<?php echo htmlspecialchars($moneda); ?>" 
                                               value="1"
                                               <?php echo in_array($moneda, $monedas_actuales) ? 'checked' : ''; ?>
                                               style="width: 16px; height: 16px; accent-color: var(--primary);">
                                        <?php echo htmlspecialchars($moneda); ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php foreach ($campos as $campo): ?>
                        <div class="pago-item">
                            <label><?php echo htmlspecialchars($campo['etiqueta']); ?></label>
                            <div class="desc"><?php echo htmlspecialchars($campo['descripcion']); ?></div>
                            <?php if ($campo['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item">
                                    <input type="checkbox" name="config_<?php echo $campo['clave']; ?>" <?php echo $campo['valor'] == '1' ? 'checked' : ''; ?>>
                                    <label>Activo</label>
                                </div>
                            <?php elseif ($campo['tipo'] == 'textarea'): ?>
                                <textarea name="config_<?php echo $campo['clave']; ?>" rows="2"><?php echo htmlspecialchars($campo['valor']); ?></textarea>
                            <?php elseif ($campo['tipo'] == 'numero'): ?>
                                <input type="number" name="config_<?php echo $campo['clave']; ?>" value="<?php echo htmlspecialchars($campo['valor']); ?>" step="0.01" min="0">
                            <?php else: ?>
                                <input type="text" name="config_<?php echo $campo['clave']; ?>" value="<?php echo htmlspecialchars($campo['valor']); ?>">
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($campos)): ?>
                        <div class="empty-campos">Sin configuración</div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="info-box">
                <p>💡 <strong>Importante:</strong> Cada proveedor debe configurar sus propias credenciales de pago. Si un proveedor no tiene configuración, no podrá recibir pagos.</p>
            </div>
            
            <div class="clearfix">
                <button type="submit" name="guardar_config" class="btn-guardar">💾 Guardar Configuración</button>
            </div>
        </form>
    </div>
</div>

<script>
setTimeout(function() {
    const mensaje = document.querySelector('.mensaje');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(function() {
            if (mensaje) mensaje.remove();
        }, 500);
    }
}, 5000);
</script>

</main>

<?php
$conn->close();
?>
<?php
require_once '../header.php';
require_once '../conexion.php';

if (!in_array($_SESSION['rol'], ['Super Admin', 'Admin'])) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

$mensaje = '';
$tipo_mensaje = '';

// ============================================
// LISTA COMPLETA DE TODOS LOS CAMPOS QUE DEBE TENER CADA MÉTODO
// ============================================
$todos_los_campos = [
    // PayPal
    ['clave' => 'paypal_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 1, 'etiqueta' => 'PayPal Activo', 'descripcion' => 'Activar/desactivar PayPal'],
    ['clave' => 'paypal_email', 'tipo' => 'texto', 'valor' => '', 'orden' => 2, 'etiqueta' => 'PayPal Email', 'descripcion' => 'Email para pagos manuales'],
    ['clave' => 'paypal_cuenta', 'tipo' => 'texto', 'valor' => '', 'orden' => 3, 'etiqueta' => 'PayPal Cuenta', 'descripcion' => 'Número de cuenta PayPal'],
    ['clave' => 'paypal_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 4, 'etiqueta' => 'PayPal Instrucciones', 'descripcion' => 'Instrucciones para pagar con PayPal'],
    
    // Stripe
    ['clave' => 'stripe_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 10, 'etiqueta' => 'Stripe Activo', 'descripcion' => 'Activar/desactivar Stripe'],
    ['clave' => 'stripe_email', 'tipo' => 'texto', 'valor' => '', 'orden' => 11, 'etiqueta' => 'Stripe Email', 'descripcion' => 'Email para pagos manuales'],
    ['clave' => 'stripe_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 12, 'etiqueta' => 'Stripe Instrucciones', 'descripcion' => 'Instrucciones para pagar con Stripe'],
    
    // Square
    ['clave' => 'square_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 20, 'etiqueta' => 'Square Activo', 'descripcion' => 'Activar/desactivar Square'],
    ['clave' => 'square_email', 'tipo' => 'texto', 'valor' => '', 'orden' => 21, 'etiqueta' => 'Square Email', 'descripcion' => 'Email para pagos manuales'],
    ['clave' => 'square_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 22, 'etiqueta' => 'Square Instrucciones', 'descripcion' => 'Instrucciones para pagar con Square'],
    
    // Amazon Pay
    ['clave' => 'amazon_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 30, 'etiqueta' => 'Amazon Pay Activo', 'descripcion' => 'Activar/desactivar Amazon Pay'],
    ['clave' => 'amazon_email', 'tipo' => 'texto', 'valor' => '', 'orden' => 31, 'etiqueta' => 'Amazon Pay Email', 'descripcion' => 'Email para pagos manuales'],
    ['clave' => 'amazon_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 32, 'etiqueta' => 'Amazon Pay Instrucciones', 'descripcion' => 'Instrucciones para pagar con Amazon Pay'],
    
    // Mercado Pago
    ['clave' => 'mercadopago_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 40, 'etiqueta' => 'Mercado Pago Activo', 'descripcion' => 'Activar/desactivar Mercado Pago'],
    ['clave' => 'mercadopago_email', 'tipo' => 'texto', 'valor' => '', 'orden' => 41, 'etiqueta' => 'Mercado Pago Email', 'descripcion' => 'Email para pagos manuales'],
    ['clave' => 'mercadopago_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 42, 'etiqueta' => 'Mercado Pago Instrucciones', 'descripcion' => 'Instrucciones para pagar con Mercado Pago'],
    
    // Bizum
    ['clave' => 'bizum_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 50, 'etiqueta' => 'Bizum Activo', 'descripcion' => 'Activar/desactivar Bizum'],
    ['clave' => 'bizum_telefono', 'tipo' => 'texto', 'valor' => '', 'orden' => 51, 'etiqueta' => 'Bizum Teléfono', 'descripcion' => 'Número de teléfono para pagos Bizum'],
    ['clave' => 'bizum_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 52, 'etiqueta' => 'Bizum Instrucciones', 'descripcion' => 'Instrucciones para pagar con Bizum'],
    
    // Transferencia USD
    ['clave' => 'transferencia_usd_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 60, 'etiqueta' => 'Transferencia USD Activo', 'descripcion' => 'Activar/desactivar Transferencia USD'],
    ['clave' => 'transferencia_usd_numero', 'tipo' => 'texto', 'valor' => '', 'orden' => 61, 'etiqueta' => 'USD Número de Cuenta', 'descripcion' => 'Número de cuenta para transferencia USD'],
    ['clave' => 'transferencia_usd_beneficiario', 'tipo' => 'texto', 'valor' => '', 'orden' => 62, 'etiqueta' => 'USD Beneficiario', 'descripcion' => 'Nombre del beneficiario'],
    ['clave' => 'transferencia_usd_banco', 'tipo' => 'texto', 'valor' => '', 'orden' => 63, 'etiqueta' => 'USD Banco', 'descripcion' => 'Nombre del banco'],
    ['clave' => 'transferencia_usd_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 64, 'etiqueta' => 'USD Instrucciones', 'descripcion' => 'Instrucciones para transferencia USD'],
    
    // Transferencia Clásica
    ['clave' => 'transferencia_clasica_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 110, 'etiqueta' => 'Transferencia Clásica Activo', 'descripcion' => 'Activar/desactivar Transferencia Clásica'],
    ['clave' => 'transferencia_clasica_numero', 'tipo' => 'texto', 'valor' => '', 'orden' => 111, 'etiqueta' => 'Clásica Número', 'descripcion' => 'Número de tarjeta/cuenta'],
    ['clave' => 'transferencia_clasica_beneficiario', 'tipo' => 'texto', 'valor' => '', 'orden' => 112, 'etiqueta' => 'Clásica Beneficiario', 'descripcion' => 'Nombre del beneficiario'],
    ['clave' => 'transferencia_clasica_banco', 'tipo' => 'texto', 'valor' => '', 'orden' => 113, 'etiqueta' => 'Clásica Banco', 'descripcion' => 'Nombre del banco'],
    ['clave' => 'transferencia_clasica_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 114, 'etiqueta' => 'Clásica Instrucciones', 'descripcion' => 'Instrucciones para transferencia'],
    
    // Zelle
    ['clave' => 'zelle_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 120, 'etiqueta' => 'Zelle Activo', 'descripcion' => 'Activar/desactivar Zelle'],
    ['clave' => 'zelle_email', 'tipo' => 'texto', 'valor' => '', 'orden' => 121, 'etiqueta' => 'Zelle Email', 'descripcion' => 'Email registrado en Zelle'],
    ['clave' => 'zelle_telefono', 'tipo' => 'texto', 'valor' => '', 'orden' => 122, 'etiqueta' => 'Zelle Teléfono', 'descripcion' => 'Teléfono registrado en Zelle'],
    ['clave' => 'zelle_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 123, 'etiqueta' => 'Zelle Instrucciones', 'descripcion' => 'Instrucciones para pagar con Zelle'],
    
    // TropiPay
    ['clave' => 'tropipay_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 130, 'etiqueta' => 'TropiPay Activo', 'descripcion' => 'Activar/desactivar TropiPay'],
    ['clave' => 'tropipay_email', 'tipo' => 'texto', 'valor' => '', 'orden' => 131, 'etiqueta' => 'TropiPay Email', 'descripcion' => 'Email registrado en TropiPay'],
    ['clave' => 'tropipay_instrucciones', 'tipo' => 'texto', 'valor' => '', 'orden' => 132, 'etiqueta' => 'TropiPay Instrucciones', 'descripcion' => 'Instrucciones para pagar con TropiPay'],
    
    // QvaPay
['clave' => 'qvapay_activo', 'tipo' => 'boolean', 'valor' => '0', 'orden' => 140, 'etiqueta' => 'QvaPay Activo', 'descripcion' => 'Activar/desactivar QvaPay'],
['clave' => 'qvapay_usuario', 'tipo' => 'texto', 'valor' => '', 'orden' => 141, 'etiqueta' => 'QvaPay Usuario', 'descripcion' => 'Tu usuario de QvaPay (ej: @tiusuario o email)'],
['clave' => 'qvapay_instrucciones', 'tipo' => 'texto', 'valor' => '1. Abre la app de QvaPay\n2. Busca el usuario: \n3. Realiza el pago por el monto total\n4. Envía el comprobante para confirmar el pedido', 'orden' => 142, 'etiqueta' => 'QvaPay Instrucciones', 'descripcion' => 'Instrucciones para pagar con QvaPay'],
];

// ============================================
// CREAR LOS CAMPOS QUE NO EXISTEN EN LA TABLA
// ============================================
foreach ($todos_los_campos as $campo) {
    $check = $conn->prepare("SELECT id FROM configuracion WHERE clave = ?");
    $check->bind_param("s", $campo['clave']);
    $check->execute();
    $existe = $check->get_result()->num_rows > 0;
    
    if (!$existe) {
        $stmt = $conn->prepare("INSERT INTO configuracion (clave, valor, grupo, orden, visible, tipo, descripcion, etiqueta, fecha_actualizacion) VALUES (?, ?, 'pagos', ?, 1, ?, ?, ?, NOW())");
        $stmt->bind_param("ssisss", $campo['clave'], $campo['valor'], $campo['orden'], $campo['tipo'], $campo['descripcion'], $campo['etiqueta']);
        $stmt->execute();
    }
}

// ============================================
// PROCESAR GUARDADO
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_config'])) {
    
    // Desactivar checkboxes que no llegaron
    $stmt = $conn->prepare("SELECT clave FROM configuracion WHERE grupo = 'pagos' AND tipo = 'boolean'");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($cb = $result->fetch_assoc()) {
        if (!isset($_POST['config_' . $cb['clave']])) {
            $upd = $conn->prepare("UPDATE configuracion SET valor = '0', fecha_actualizacion = NOW() WHERE clave = ?");
            $upd->bind_param("s", $cb['clave']);
            $upd->execute();
        }
    }
    
        // ============================================
    // GUARDAR CONFIGURACIÓN DE PAGO CON ENTREGA
    // ============================================
    // Checkbox pago_con_entrega_activo
    if (isset($_POST['config_pago_con_entrega_activo'])) {
        $valor_activo = '1';
    } else {
        $valor_activo = '0';
    }
    $stmt = $conn->prepare("UPDATE configuracion SET valor = ?, fecha_actualizacion = NOW() WHERE clave = 'pago_con_entrega_activo'");
    $stmt->bind_param("s", $valor_activo);
    $stmt->execute();
    $stmt->close();

    // Porcentaje con entrega
    if (isset($_POST['config_porcentaje_con_entrega'])) {
        $porcentaje = intval($_POST['config_porcentaje_con_entrega']);
        $stmt = $conn->prepare("UPDATE configuracion SET valor = ?, fecha_actualizacion = NOW() WHERE clave = 'porcentaje_con_entrega'");
        $stmt->bind_param("s", $porcentaje);
        $stmt->execute();
        $stmt->close();
    }
    
    // Actualizar o insertar valores que llegaron
    foreach ($_POST as $clave => $valor) {
        if (strpos($clave, 'config_') === 0) {
            $clave_real = substr($clave, 7);
            
            if ($valor === 'on') {
                $valor = 1;
            }
            
            // Verificar si existe
            $check = $conn->prepare("SELECT id FROM configuracion WHERE clave = ?");
            $check->bind_param("s", $clave_real);
            $check->execute();
            $existe = $check->get_result()->num_rows > 0;
            
            if ($existe) {
                $upd = $conn->prepare("UPDATE configuracion SET valor = ?, fecha_actualizacion = NOW() WHERE clave = ?");
                $upd->bind_param("ss", $valor, $clave_real);
                $upd->execute();
            } else {
                $ins = $conn->prepare("INSERT INTO configuracion (clave, valor, grupo, orden, visible, tipo, descripcion, etiqueta, fecha_actualizacion) VALUES (?, ?, 'pagos', 999, 1, 'texto', '', '', NOW())");
                $ins->bind_param("ss", $clave_real, $valor);
                $ins->execute();
            }
        }
    }
    
    $_SESSION['mensaje'] = "✅ Configuración guardada correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>window.location.href = "../configuracion.php";</script>';
    exit;
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// Obtener todos los campos actualizados
$items = $conn->query("SELECT * FROM configuracion WHERE grupo = 'pagos' ORDER BY orden");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Configuración - Pagos</title>
    <link rel="stylesheet" href="../estilo.css">
    <style>
        :root { --primary: #667eea; --secondary: #764ba2; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #f8fafc; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
        
        .config-container { width: 100%; max-width: 1400px; margin: 1rem auto; padding: 0 1rem; }
        @media (min-width: 768px) { .config-container { margin: 2rem auto; padding: 0 2rem; } }
        
        .config-card { background: white; border-radius: 20px; padding: 1.25rem; box-shadow: 0 4px 20px rgba(0,0,0,0.05); width: 100%; }
        @media (min-width: 768px) { .config-card { padding: 2rem; } }
        
        .config-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
        .config-header h2 { font-size: 1.3rem; color: #2d3748; display: flex; align-items: center; gap: 0.5rem; }
        
        .btn-volver { padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-decoration: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; font-size: 0.85rem; }
        .btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }
        
        .pagos-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; margin-top: 1rem; }
        @media (min-width: 768px) { .pagos-grid { grid-template-columns: repeat(4, 1fr); gap: 1.5rem; } }
        
        .pago-columna { background: #f8fafc; border-radius: 12px; padding: 1rem; border: 1px solid #e2e8f0; width: 100%; }
        @media (min-width: 768px) { .pago-columna { padding: 1.2rem; } }
        
        .pago-columna h4 { color: #4a5568; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid var(--primary); display: flex; align-items: center; gap: 0.5rem; font-size: 1rem; }
        
        .pago-item { margin-bottom: 1rem; padding: 0.5rem; background: white; border-radius: 8px; border: 1px solid #edf2f7; }
        .pago-item label { font-weight: 600; font-size: 0.8rem; color: #4a5568; display: block; margin-bottom: 0.3rem; }
        .pago-item .desc { font-size: 0.7rem; color: #718096; margin-bottom: 0.3rem; }
        .pago-item input[type="text"], .pago-item input[type="email"], .pago-item textarea { width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.8rem; font-family: inherit; }
        .pago-item textarea { min-height: 70px; resize: vertical; }
        .checkbox-item { display: flex; align-items: center; gap: 0.5rem; margin: 0.5rem 0; }
        .checkbox-item input { width: 18px; height: 18px; margin: 0; }
        .checkbox-item label { margin: 0; cursor: pointer; }
        
        .btn-guardar { width: 100%; padding: 0.8rem; margin-top: 1.5rem; font-size: 1rem; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; border-radius: 50px; cursor: pointer; transition: all 0.3s; font-weight: 600; }
        @media (min-width: 768px) { .btn-guardar { width: auto; float: right; padding: 0.8rem 2rem; margin-top: 2rem; } }
        .btn-guardar:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }
        
        .clearfix::after { content: ""; clear: both; display: table; }
        
        .mensaje { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; font-size: 0.85rem; }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; max-width: 400px; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    </style>
</head>
<body>
    <div class="config-container">
        <div class="config-card">
            <div class="config-header">
                <h2>💳 Configuración de Pagos</h2>
                <a href="../configuracion.php" class="btn-volver">← Volver</a>
            </div>
            
            <?php if ($mensaje): ?>
                <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <?php
                // Reorganizar los items por método para mostrar
$paypal = []; $stripe = []; $square = []; $amazon = [];
$mercadopago = []; $bizum = []; $tropipay = []; $flowglad = [];
$transferencia_usd = []; $transferencia_clasica = []; $zelle = []; $qvapay = [];

$items->data_seek(0);
while($item = $items->fetch_assoc()) {
    if (strpos($item['clave'], 'paypal') === 0) $paypal[] = $item;
    elseif (strpos($item['clave'], 'stripe') === 0) $stripe[] = $item;
    elseif (strpos($item['clave'], 'square') === 0) $square[] = $item;
    elseif (strpos($item['clave'], 'amazon') === 0) $amazon[] = $item;
    elseif (strpos($item['clave'], 'mercadopago') === 0) $mercadopago[] = $item;
    elseif (strpos($item['clave'], 'bizum') === 0) $bizum[] = $item;
    elseif (strpos($item['clave'], 'tropipay') === 0) $tropipay[] = $item;
    elseif (strpos($item['clave'], 'flowglad') === 0) $flowglad[] = $item;
    elseif (strpos($item['clave'], 'transferencia_usd') === 0) $transferencia_usd[] = $item;
    elseif (strpos($item['clave'], 'transferencia_clasica') === 0) $transferencia_clasica[] = $item;
    elseif (strpos($item['clave'], 'zelle') === 0) $zelle[] = $item;
    elseif (strpos($item['clave'], 'qvapay') === 0) $qvapay[] = $item;
}
 ?>                
                              <!-- PAGO CON ENTREGA (una sola línea) -->
<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:0.8rem 1rem;margin-bottom:1.5rem;display:flex;align-items:center;flex-wrap:wrap;gap:1rem;">
    <h4 style="margin:0;color:#166534;">🚚 Pago al entregar</h4>
    
    <?php
    $pago_entrega_activo = '';
    $porcentaje_entrega = '40';
    
    $res = $conn->query("SELECT valor FROM configuracion WHERE clave = 'pago_con_entrega_activo'");
    if ($row = $res->fetch_assoc()) $pago_entrega_activo = $row['valor'];
    
    $res2 = $conn->query("SELECT valor FROM configuracion WHERE clave = 'porcentaje_con_entrega'");
    if ($row2 = $res2->fetch_assoc()) $porcentaje_entrega = $row2['valor'];
    ?>
    
    <div class="checkbox-item" style="margin:0;">
        <input type="checkbox" name="config_pago_con_entrega_activo" value="1" <?php echo $pago_entrega_activo == '1' ? 'checked' : ''; ?>>
        <label>Activar</label>
    </div>
    
    <div style="display:flex;align-items:center;gap:0.5rem;">
        <label style="margin:0;">% al entregar:</label>
        <input type="number" name="config_porcentaje_con_entrega" value="<?php echo htmlspecialchars($porcentaje_entrega); ?>" min="1" max="99" step="1" style="width:70px;">
    </div>
    
    <small style="color:#718096;">Ej: 40% → paga 40% al entregar, 60% al comprar</small>
</div>
                <div class="pagos-grid">
                    <!-- PayPal -->
                    <div class="pago-columna"><h4>🅿️ PayPal</h4>
                        <?php foreach ($paypal as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Stripe -->
                    <div class="pago-columna"><h4>⚡ Stripe</h4>
                        <?php foreach ($stripe as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Square -->
                    <div class="pago-columna"><h4>🟩 Square</h4>
                        <?php foreach ($square as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Amazon Pay -->
                    <div class="pago-columna"><h4>📦 Amazon Pay</h4>
                        <?php foreach ($amazon as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Mercado Pago -->
                    <div class="pago-columna"><h4>🛒 Mercado Pago</h4>
                        <?php foreach ($mercadopago as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Bizum -->
                    <div class="pago-columna"><h4>📱 Bizum</h4>
                        <?php foreach ($bizum as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- TropiPay -->
                    <div class="pago-columna"><h4>🌍 TropiPay</h4>
                        <?php foreach ($tropipay as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Flowglad -->
                    <div class="pago-columna"><h4>✨ Flowglad</h4>
                        <?php foreach ($flowglad as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Transferencia USD -->
                    <div class="pago-columna"><h4>🏦 Transferencia USD</h4>
                        <?php foreach ($transferencia_usd as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Transferencia Clásica -->
                    <div class="pago-columna"><h4>💳 Transferencia Clásica</h4>
                        <?php foreach ($transferencia_clasica as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Zelle -->
                    <div class="pago-columna"><h4>💸 Zelle</h4>
                        <?php foreach ($zelle as $item): ?>
                            <?php if ($item['tipo'] == 'boolean'): ?>
                                <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
                            <?php else: ?>
                                <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
                                <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                                    <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
                                <?php else: ?>
                                    <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
                                <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- QvaPay -->
<div class="pago-columna"><h4>💳 QvaPay</h4>
    <?php foreach ($qvapay as $item): ?>
        <?php if ($item['tipo'] == 'boolean'): ?>
            <div class="checkbox-item"><input type="checkbox" name="config_<?php echo $item['clave']; ?>" <?php echo $item['valor'] == '1' ? 'checked' : ''; ?>><label><?php echo $item['etiqueta']; ?></label></div>
        <?php else: ?>
            <div class="pago-item"><label><?php echo $item['etiqueta']; ?></label><div class="desc"><?php echo htmlspecialchars($item['descripcion']); ?></div>
            <?php if (strpos($item['clave'], 'instrucciones') !== false): ?>
                <textarea name="config_<?php echo $item['clave']; ?>" rows="3"><?php echo htmlspecialchars($item['valor']); ?></textarea>
            <?php else: ?>
                <input type="text" name="config_<?php echo $item['clave']; ?>" value="<?php echo htmlspecialchars($item['valor']); ?>">
            <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
                </div>
                
                <div class="clearfix">
                    <button type="submit" name="guardar_config" class="btn-guardar">💾 Guardar Configuración</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        setTimeout(function() {
            const mensaje = document.querySelector('.mensaje');
            if (mensaje) {
                mensaje.style.opacity = '0';
                setTimeout(() => { if (mensaje) mensaje.remove(); }, 300);
            }
        }, 5000);
    </script>
</body>
</html>
<?php
// ============================================
// CONFIGURACIÓN DE ENVÍOS - GLOBAL Y PROVEEDORES
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_actual = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol']);
$es_proveedor = esRolProveedor($_SESSION['rol']);
$es_admin = in_array($_SESSION['rol'], ['Super Admin', 'Gerente']);

if ($es_proveedor && $proveedor_id_actual == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// Validar que el proveedor existe y está activo
if ($proveedor_id_actual > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_actual);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// OBTENER PROVEEDOR A EDITAR
// ============================================
$proveedor_id_editar = 0;

if ($es_proveedor) {
    $proveedor_id_editar = $proveedor_id_actual;
} else {
    if (isset($_GET['proveedor_id']) && is_numeric($_GET['proveedor_id'])) {
        $proveedor_id_editar = intval($_GET['proveedor_id']);
    }
}

// Si es administrador y está editando un proveedor específico, verificar que existe
if ($es_admin && $proveedor_id_editar > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_editar);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /configuracion/envios.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// PROCESAR GUARDAR
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_envios'])) {
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header("Location: /configuracion/envios.php" . ($proveedor_id_editar ? "?proveedor_id=$proveedor_id_editar" : ""));
        exit;
    }
    
    $proveedor_id_guardar = isset($_POST['proveedor_id']) && !empty($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : 0;
    
    if ($es_proveedor) {
        $proveedor_id_guardar = $proveedor_id_actual;
    }
    
    // ============================================
    // GUARDAR CONFIGURACIÓN DE PROVEEDOR
    // ============================================
    if ($proveedor_id_guardar != 0) {
        if (isset($_POST['municipio']) && is_array($_POST['municipio'])) {
            foreach ($_POST['municipio'] as $municipio_id => $data) {
                $municipio_id = intval($municipio_id);
                $activo = isset($data['activo']) ? 1 : 0;
                $costo_personalizado = !empty($data['costo']) ? floatval($data['costo']) : null;
                
                // Obtener costo global
                $stmt_global = $conn->prepare("SELECT costo FROM costos_envio WHERE municipio_id = ? AND proveedor_id = 0");
                $stmt_global->bind_param("i", $municipio_id);
                $stmt_global->execute();
                $result_global = $stmt_global->get_result();
                $costo_global = $result_global->num_rows > 0 ? $result_global->fetch_assoc()['costo'] : 0;
                $stmt_global->close();
                
                // Calcular costo final
                $costo_final = ($costo_personalizado !== null && $costo_personalizado > 0) ? $costo_personalizado : $costo_global;
                
                // Insertar o actualizar con costo_final
                $stmt = $conn->prepare("
                    INSERT INTO proveedor_envio_config (proveedor_id, municipio_id, costo_personalizado, activo, costo_final) 
                    VALUES (?, ?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE 
                        costo_personalizado = VALUES(costo_personalizado), 
                        activo = VALUES(activo),
                        costo_final = VALUES(costo_final)
                ");
                $stmt->bind_param("iidid", $proveedor_id_guardar, $municipio_id, $costo_personalizado, $activo, $costo_final);
                $stmt->execute();
                $stmt->close();
            }
        }
        
        $_SESSION['mensaje'] = "✅ Configuración de envíos guardada correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
        header("Location: /configuracion/envios.php?proveedor_id=" . $proveedor_id_guardar);
        exit;
    }
    
    // ============================================
    // GUARDAR CONFIGURACIÓN GLOBAL (Admin)
    // ============================================
    if ($es_admin && $proveedor_id_guardar == 0) {
        // Actualizar provincias
        if (isset($_POST['provincia_nombre']) && is_array($_POST['provincia_nombre'])) {
            foreach ($_POST['provincia_nombre'] as $id => $nombre) {
                $id = intval($id);
                $nombre = trim(htmlspecialchars(strip_tags($nombre)));
                $activo = isset($_POST['provincia_activo'][$id]) ? 1 : 0;
                
                $stmt = $conn->prepare("UPDATE provincias SET nombre = ?, activo = ? WHERE id = ?");
                $stmt->bind_param("sii", $nombre, $activo, $id);
                $stmt->execute();
                
                if ($activo == 0) {
                    $stmt_mun = $conn->prepare("
                        UPDATE costos_envio ce 
                        INNER JOIN municipios m ON ce.municipio_id = m.id 
                        SET ce.activo = 0 
                        WHERE m.provincia_id = ?
                    ");
                    $stmt_mun->bind_param("i", $id);
                    $stmt_mun->execute();
                }
            }
        }

        // Actualizar costos globales
        if (isset($_POST['municipio_costo']) && is_array($_POST['municipio_costo'])) {
            foreach ($_POST['municipio_costo'] as $municipio_id => $costo) {
                $municipio_id = intval($municipio_id);
                $costo = floatval($costo);
                $costo = max(0, $costo);
                $activo = isset($_POST['municipio_activo'][$municipio_id]) ? 1 : 0;
                
                $stmt = $conn->prepare("
                    UPDATE costos_envio 
                    SET costo = ?, activo = ? 
                    WHERE municipio_id = ? AND proveedor_id = 0
                ");
                $stmt->bind_param("dii", $costo, $activo, $municipio_id);
                $stmt->execute();
            }
        }

        $_SESSION['mensaje'] = "✅ Costos globales guardados correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
        header("Location: /configuracion/envios.php");
        exit;
    }
}

// ============================================
// RECIBIR MENSAJES DE SESIÓN
// ============================================
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// OBTENER LISTA DE PROVEEDORES (PARA ADMIN)
// ============================================
if ($es_admin) {
    $sql_proveedores = "SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda";
    $proveedores_list = $conn->query($sql_proveedores);
}

// ============================================
// OBTENER DATOS SEGÚN ROL
// ============================================
$provincias_agrupadas = [];

if ($es_proveedor && $proveedor_id_actual) {
// ============================================
// VISTA PROVEEDOR - SOLO PROVINCIAS CON MUNICIPIOS ACTIVOS
// ============================================
$sql = "
    SELECT 
        p.id as provincia_id,
        p.nombre as provincia_nombre,
        p.activo as provincia_activo,
        m.id as municipio_id,
        m.nombre as municipio_nombre,
        ce.costo as costo_global,
        pec.costo_personalizado,
        IFNULL(pec.activo, 0) as municipio_activo
    FROM provincias p
    INNER JOIN municipios m ON p.id = m.provincia_id
    LEFT JOIN costos_envio ce ON m.id = ce.municipio_id AND ce.proveedor_id = 0
    LEFT JOIN proveedor_envio_config pec ON m.id = pec.municipio_id AND pec.proveedor_id = $proveedor_id_actual
    WHERE p.activo = 1
    AND p.id IN (
        SELECT DISTINCT m2.provincia_id 
        FROM municipios m2
        INNER JOIN proveedor_envio_config pec2 ON m2.id = pec2.municipio_id
        WHERE pec2.proveedor_id = $proveedor_id_actual AND pec2.activo = 1
    )
    ORDER BY p.nombre, m.nombre
";
    
    $municipios_proveedor = $conn->query($sql);
    
    while ($row = $municipios_proveedor->fetch_assoc()) {
        $prov_id = $row['provincia_id'];
        if (!isset($provincias_agrupadas[$prov_id])) {
            $provincias_agrupadas[$prov_id] = [
                'nombre' => $row['provincia_nombre'],
                'activo' => $row['provincia_activo'],
                'municipios' => []
            ];
        }
        $provincias_agrupadas[$prov_id]['municipios'][] = $row;
    }
    
} else {
    // ============================================
    // VISTA ADMIN - TODAS LAS PROVINCIAS (ACTIVAS E INACTIVAS)
    // ============================================
    $sql = "
        SELECT 
            p.id as provincia_id,
            p.nombre as provincia_nombre,
            p.activo as provincia_activo,
            m.id as municipio_id,
            m.nombre as municipio_nombre,
            ce.costo,
            ce.activo as municipio_activo,
            pec.costo_personalizado,
            IFNULL(pec.activo, 0) as proveedor_municipio_activo
        FROM provincias p
        LEFT JOIN municipios m ON p.id = m.provincia_id
        LEFT JOIN costos_envio ce ON m.id = ce.municipio_id AND ce.proveedor_id = 0
        LEFT JOIN proveedor_envio_config pec ON m.id = pec.municipio_id AND pec.proveedor_id = $proveedor_id_editar
        ORDER BY p.activo DESC, p.nombre, m.nombre
    ";
    
    $municipios_globales = $conn->query($sql);
    
    while ($row = $municipios_globales->fetch_assoc()) {
        $prov_id = $row['provincia_id'];
        if (!isset($provincias_agrupadas[$prov_id])) {
            $provincias_agrupadas[$prov_id] = [
                'nombre' => $row['provincia_nombre'],
                'activo' => $row['provincia_activo'],
                'municipios' => []
            ];
        }
        // Solo agregar municipios si existen
        if ($row['municipio_id'] !== null) {
            $provincias_agrupadas[$prov_id]['municipios'][] = $row;
        }
    }
}

// ============================================
// INCLUIR HEADER
// ============================================
require_once '../header.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración de Envíos - Catalejo</title>
    <style>
        * { box-sizing: border-box; }
        .container { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; }
        @media (max-width: 768px) { .container { margin: 1rem auto; padding: 0 0.8rem; } }
        h2 { font-size: 1.5rem; margin: 0 0 0.5rem 0; color: #1e293b; }
        @media (max-width: 768px) { h2 { font-size: 1.2rem; } }
        .subtext { color: #475569; margin-bottom: 2rem; font-size: 0.9rem; }
        @media (max-width: 768px) { .subtext { margin-bottom: 1rem; font-size: 0.8rem; } }
        
        .btn-success { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; padding: 0.6rem 1.2rem; border-radius: 30px; font-weight: 600; cursor: pointer; transition: 0.2s; font-size: 0.9rem; }
        .btn-success:hover { opacity: 0.9; transform: translateY(-2px); }
        .guardar-btn { text-align: right; margin-top: 2rem; }
        @media (max-width: 768px) { .guardar-btn { text-align: center; margin-top: 1.5rem; } .btn-success { width: 100%; padding: 0.8rem; } }
        
        .provincia-card { background: white; border-radius: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 1.5rem; overflow: hidden; border: 1px solid #e2e8f0; }
        @media (max-width: 768px) { .provincia-card { margin-bottom: 1rem; border-radius: 16px; } }
        
        .card-header { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.8rem; padding: 1rem 1.2rem; background: #fafcff; cursor: pointer; transition: background 0.1s; }
        @media (max-width: 768px) { .card-header { flex-direction: column; align-items: stretch; padding: 0.8rem 1rem; } }
        .card-header:hover { background: #f8fafc; }
        
        .provincia-titulo { display: flex; align-items: center; gap: 0.8rem; flex: 2; min-width: 200px; flex-wrap: wrap; }
        @media (max-width: 768px) { .provincia-titulo { justify-content: space-between; flex-wrap: wrap; } }
        .provincia-titulo input[type="text"] { font-weight: 600; font-size: 1rem; padding: 0.4rem 0.8rem; border: 1px solid #cbd5e1; border-radius: 12px; width: 220px; }
        @media (max-width: 768px) { .provincia-titulo input[type="text"] { width: 100%; font-size: 0.9rem; padding: 0.5rem; } }
        
        .provincia-activo { display: flex; align-items: center; gap: 0.4rem; font-size: 0.85rem; white-space: nowrap; }
        @media (max-width: 768px) { .provincia-activo { white-space: normal; } }
        
        .toggle-icon { font-size: 1.2rem; margin-left: 0.5rem; color: #64748b; }
        .card-body { padding: 0; display: none; border-top: 1px solid #e2e8f0; }
        .card-body.open { display: block; }
        
        .municipios-table { width: 100%; border-collapse: collapse; }
        @media (max-width: 768px) { .card-body { overflow-x: auto; } .municipios-table { min-width: 500px; } }
        .municipios-table th { text-align: left; padding: 0.75rem 1.2rem; background: #f8fafc; font-weight: 600; font-size: 0.85rem; color: #334155; border-bottom: 1px solid #e2e8f0; }
        @media (max-width: 768px) { .municipios-table th { padding: 0.5rem 0.8rem; font-size: 0.75rem; } .municipios-table td { padding: 0.5rem 0.8rem; } }
        .municipios-table td { padding: 0.7rem 1.2rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }
        @media (max-width: 768px) { .municipios-table td { padding: 0.5rem 0.8rem; } }
        
        .municipio-nombre { width: 200px; padding: 0.4rem 0.6rem; border: 1px solid #cbd5e1; border-radius: 8px; }
        @media (max-width: 768px) { .municipio-nombre { width: 140px; padding: 0.3rem 0.5rem; font-size: 0.8rem; } }
        .municipio-costo { width: 110px; padding: 0.4rem 0.6rem; border: 1px solid #cbd5e1; border-radius: 8px; }
        @media (max-width: 768px) { .municipio-costo { width: 80px; padding: 0.3rem 0.5rem; font-size: 0.8rem; } }
        .checkbox-muni { transform: scale(1.1); margin-left: 0.2rem; width: 18px; height: 18px; cursor: pointer; }
        @media (max-width: 768px) { .checkbox-muni { transform: scale(1); } }
        
        .mensaje { position: fixed; top: 20px; right: 20px; left: 20px; padding: 0.8rem 1rem; border-radius: 10px; z-index: 1000; animation: slideIn 0.3s ease; word-break: break-word; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-size: 0.85rem; }
        @media (min-width: 768px) { .mensaje { top: 20px; right: 20px; left: auto; padding: 1rem 1.5rem; max-width: 400px; } }
        .mensaje.exito { background: #f0fff4; color: #22543d; border-left: 4px solid #48bb78; }
        .mensaje.error { background: #fff5f5; color: #742a2a; border-left: 4px solid #f56565; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        input:disabled { background-color: #f1f5f9; opacity: 0.6; cursor: not-allowed; }
        
        .badge-costo { display: inline-block; font-size: 0.65rem; padding: 0.15rem 0.5rem; border-radius: 12px; background: #f1f5f9; color: #475569; margin-left: 0.5rem; }
        .badge-costo.global { background: #dbeafe; color: #1e40af; }
        .badge-costo.personalizado { background: #fef3c7; color: #92400e; }
        
        .selector-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; display: flex; flex-wrap: wrap; align-items: center; gap: 0.8rem; }
        .selector-proveedor select { padding: 0.5rem 1rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; background: white; flex: 1; min-width: 200px; }
        .selector-proveedor .info { color: #64748b; font-size: 0.85rem; }
        
        .info-proveedor { margin-bottom: 1.5rem; padding: 1rem; background: #dbeafe; border-radius: 8px; border: 1px solid #bfdbfe; }
        
        .empty-state { padding: 2rem; text-align: center; color: #64748b; }
        @media (max-width: 768px) { .empty-state { padding: 1rem; } }
        
        .text-sm { font-size: 0.85rem; color: #64748b; }

.btn-agregar-provincia {
    background: #3b82f6;
    color: white;
    padding: 0.6rem 1.2rem;
    border-radius: 30px;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.9rem;
    transition: 0.2s;
    display: inline-block;
    white-space: nowrap;
}

.btn-agregar-provincia:hover {
    background: #2563eb;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
}
    </style>
</head>
<body>

<div class="container">
    <div class="header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h2>🚚 <?php echo $es_proveedor ? 'Mis Costos de Envío' : 'Costos de envío'; ?></h2>
            <div class="subtext" style="margin-bottom: 0;">
                <?php if ($es_proveedor): ?>
                    Configura los costos de envío para tu tienda. 
                    <strong>Deja el costo vacío para usar el costo global.</strong>
                <?php else: ?>
                    Selecciona un proveedor para configurar sus envíos.
                <?php endif; ?>
            </div>
        </div>
        <!-- BOTÓN AGREGAR PROVINCIAS - Solo Super Admin y Gerente -->
        <?php if (in_array($_SESSION['rol'], ['Super Admin', 'Gerente'])): ?>
            <a href="/configuracion/mas_provincias.php" class="btn-agregar-provincia">
                🏛️ Agregar Provincia
            </a>
        <?php endif; ?>
    </div>

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <?php if ($es_admin): ?>
    <div class="selector-proveedor">
        <label for="sel_proveedor"><strong>🏪 Proveedor:</strong></label>
        <select id="sel_proveedor" onchange="window.location.href = this.value">
            <option value="/configuracion/envios.php">📊 Global (Sistema)</option>
            <?php 
            if ($proveedores_list) {
                $proveedores_list->data_seek(0);
                while($prov = $proveedores_list->fetch_assoc()): 
            ?>
                <option value="/configuracion/envios.php?proveedor_id=<?php echo $prov['id']; ?>" 
                        <?php echo ($proveedor_id_editar == $prov['id']) ? 'selected' : ''; ?>>
                    🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                </option>
            <?php 
                endwhile;
            }
            ?>
        </select>
        <?php if ($proveedor_id_editar != 0): ?>
            <span class="info">Editando proveedor ID: <?php echo $proveedor_id_editar; ?></span>
        <?php else: ?>
            <span class="info">Editando configuración global</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($es_proveedor): ?>
    <div class="info-proveedor">
        <strong>🏪 Tu Tienda:</strong> <?php echo htmlspecialchars($proveedor_id_actual); ?>
    </div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="hidden" name="proveedor_id" value="<?php echo $proveedor_id_editar; ?>">
        <input type="hidden" name="guardar_envios" value="1">

        <?php if (empty($provincias_agrupadas)): ?>
            <div class="empty-state">
                <?php if ($es_proveedor): ?>
                    <p>📭 No tienes ninguna provincia activa.</p>
                    <p class="text-sm">Contacta al administrador para activar tus envíos.</p>
                <?php else: ?>
                    <p>📭 No hay provincias activas en el sistema.</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <?php foreach ($provincias_agrupadas as $prov_id => $provincia): ?>
            <div class="provincia-card">
                <div class="card-header" onclick="toggleProvincia(<?php echo $prov_id; ?>)">
                    <div class="provincia-titulo">
                        <?php if ($es_admin && $proveedor_id_editar == 0): ?>
                            <input type="text" name="provincia_nombre[<?php echo $prov_id; ?>]" 
                                   value="<?php echo htmlspecialchars($provincia['nombre']); ?>" 
                                   onclick="event.stopPropagation();">
                            <label class="provincia-activo" onclick="event.stopPropagation();">
                                <input type="checkbox" name="provincia_activo[<?php echo $prov_id; ?>]" value="1" 
                                       <?php echo $provincia['activo'] ? 'checked' : ''; ?>>
                                Activo
                            </label>
                        <?php else: ?>
                            <strong><?php echo htmlspecialchars($provincia['nombre']); ?></strong>
                            <span class="badge-costo <?php echo $provincia['activo'] ? 'global' : ''; ?>">
                                <?php echo $provincia['activo'] ? '✅ Activo' : '❌ Inactivo'; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <span class="toggle-icon" id="toggle-icon-<?php echo $prov_id; ?>">▼</span>
                </div>
                <div class="card-body" id="provincia-body-<?php echo $prov_id; ?>">
                    <table class="municipios-table">
                        <thead>
                            <tr>
                                <th>Municipio</th>
                                <th>Costo (<?php echo $moneda_simbolo ?? 'USD'; ?>)</th>
                                <?php if ($proveedor_id_editar != 0): ?>
                                    <th>Costo Global</th>
                                <?php endif; ?>
                                <th>Activo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($provincia['municipios'] as $mun): ?>
                            <tr>
                                <td>
                                    <?php if ($es_admin && $proveedor_id_editar == 0): ?>
                                        <input type="text" name="municipio_nombre[<?php echo $mun['municipio_id']; ?>]" 
                                               value="<?php echo htmlspecialchars($mun['municipio_nombre']); ?>" 
                                               class="municipio-nombre">
                                    <?php else: ?>
                                        <strong><?php echo htmlspecialchars($mun['municipio_nombre']); ?></strong>
                                        <input type="hidden" name="municipio[<?php echo $mun['municipio_id']; ?>][nombre]" 
                                               value="<?php echo htmlspecialchars($mun['municipio_nombre']); ?>">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($proveedor_id_editar != 0): ?>
                                        <input type="number" 
                                               name="municipio[<?php echo $mun['municipio_id']; ?>][costo]" 
                                               step="0.01" min="0" 
                                               value="<?php echo $mun['costo_personalizado'] ?? ''; ?>" 
                                               class="municipio-costo"
                                               placeholder="Personalizado">
                                    <?php else: ?>
                                        <input type="number" 
                                               name="municipio_costo[<?php echo $mun['municipio_id']; ?>]" 
                                               step="0.01" min="0" 
                                               value="<?php echo $mun['costo'] ?? '0.00'; ?>" 
                                               class="municipio-costo">
                                    <?php endif; ?>
                                </td>
                                <?php if ($proveedor_id_editar != 0): ?>
                                    <td>
                                        <span class="text-sm">
                                            <?php echo isset($mun['costo_global']) ? number_format($mun['costo_global'], 2) : '—'; ?>
                                        </span>
                                        <?php if (!empty($mun['costo_personalizado'])): ?>
                                            <span class="badge-costo personalizado">Personalizado</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                                <td>
                                    <?php if ($proveedor_id_editar != 0): ?>
                                        <input type="checkbox" 
                                               name="municipio[<?php echo $mun['municipio_id']; ?>][activo]" 
                                               value="1" 
                                               class="checkbox-muni"
                                               <?php echo ($mun['proveedor_municipio_activo'] ?? $mun['municipio_activo'] ?? 0) ? 'checked' : ''; ?>
                                               <?php echo $provincia['activo'] ? '' : 'disabled'; ?>>
                                    <?php else: ?>
                                        <input type="checkbox" 
                                               name="municipio_activo[<?php echo $mun['municipio_id']; ?>]" 
                                               value="1" 
                                               class="checkbox-muni"
                                               <?php echo ($mun['municipio_activo'] ?? 0) ? 'checked' : ''; ?>
                                               <?php echo $provincia['activo'] ? '' : 'disabled'; ?>>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <div class="guardar-btn">
            <button type="submit" class="btn-success">💾 Guardar todos los cambios</button>
        </div>
    </form>
</div>

<script>
function toggleProvincia(id) {
    const body = document.getElementById('provincia-body-' + id);
    if (body) {
        body.classList.toggle('open');
        const icon = document.getElementById('toggle-icon-' + id);
        if (icon) {
            icon.textContent = body.classList.contains('open') ? '▲' : '▼';
        }
    }
}

// Auto-cerrar mensajes
setTimeout(function() {
    const mensaje = document.querySelector('.mensaje');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(function() {
            if (mensaje) mensaje.remove();
        }, 500);
    }
}, 5000);
</script>

<?php
$conn->close();
?>
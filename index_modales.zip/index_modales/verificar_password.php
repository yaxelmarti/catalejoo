<!-- /index_modales/verificar_password.php -->
<!-- ======================================== -->
<!-- MODAL VERIFICAR CONTRASEÑA PARA VINCULACIÓN -->
<!-- ======================================== -->

<style>
#modalVerificarPasswordVinculacion .input-password {
    width: 100%;
    padding: 0.8rem;
    margin: 1rem 0;
    border: 2px solid #e2e8f0;
    border-radius: var(--radius-md);
    font-size: 1rem;
}

#modalVerificarPasswordVinculacion .btn-verificar {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    transition: all 0.3s;
}

#modalVerificarPasswordVinculacion .btn-verificar:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

#modalVerificarPasswordVinculacion .btn-magic-link {
    width: 100%;
    padding: 1rem;
    background: #48bb78;
    color: white;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1.1rem;
    font-weight: 600;
    transition: all 0.3s;
}

#modalVerificarPasswordVinculacion .btn-magic-link:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(72, 187, 120, 0.3);
}

#modalVerificarPasswordVinculacion .mensaje-info {
    background: #fef5e7;
    border-left: 4px solid #ffc107;
    padding: 1rem;
    border-radius: var(--radius-md);
    margin: 1rem 0;
    color: #744210;
}

#modalVerificarPasswordVinculacion .error-message {
    color: #f56565;
    margin: 0.5rem 0;
    display: none;
    font-size: 0.9rem;
}

#modalVerificarPasswordVinculacion .separador {
    text-align: center;
    margin: 15px 0;
    color: #718096;
    font-size: 0.9rem;
}

#modalVerificarPasswordVinculacion .link-registro {
    text-align: center;
    margin-top: 1rem;
}

#modalVerificarPasswordVinculacion .link-registro a {
    color: var(--primary);
    text-decoration: underline;
    cursor: pointer;
    font-weight: 500;
}

#modalVerificarPasswordVinculacion .magic-link-mensaje {
    margin-top: 10px;
    font-size: 0.8rem;
    display: none;
}

@media (max-width: 768px) {
    #modalVerificarPasswordVinculacion .modal-contenido {
        padding: 1.5rem;
    }
}
</style>

<div class="modal-overlay" id="modalVerificarPasswordVinculacion">
    <div class="modal-contenido" style="max-width: 450px;">
        <span class="close-modal" onclick="cerrarModal('modalVerificarPasswordVinculacion')">&times;</span>
        
        <h2 style="text-align: center; color: #2d3748; margin-bottom: 1rem;">🔐 Verificación de seguridad</h2>
        
        <div id="mensajeVinculacion" class="mensaje-info"></div>
        
        <!-- OPCIÓN 1: VERIFICAR CON CONTRASEÑA -->
        <div id="opcionPassword">
            <input type="password" id="vinculacion_password" class="input-password" placeholder="Contraseña">
            <div id="vinculacion_error" class="error-message"></div>
            <button class="btn-verificar" onclick="verificarPasswordVinculacion()">
                🔐 Verificar con contraseña
            </button>
        </div>
        
        <!-- SEPARADOR -->
        <div class="separador">— o —</div>
        
        <!-- OPCIÓN 2: ENLACE MÁGICO -->
        <button class="btn-magic-link" onclick="enviarEnlaceMagico(event)">
            📧 Enviarme enlace por Email
        </button>
        
        <div id="magicLinkMensaje" class="magic-link-mensaje"></div>
        
        <div class="link-registro">
            <a href="#" onclick="cerrarModal('modalVerificarPasswordVinculacion'); document.getElementById('modalRegistro').style.display='block';">
                Registrar nuevo cliente
            </a>
        </div>
    </div>
</div>

<script>
// ============================================
// VERIFICAR CON CONTRASEÑA
// ============================================
window.verificarPasswordVinculacion = function() {
    const btn = document.querySelector('.btn-verificar');
    const password = document.getElementById('vinculacion_password').value;
    const errorDiv = document.getElementById('vinculacion_error');
    
    if (!password) {
        errorDiv.textContent = 'Ingresa tu contraseña';
        errorDiv.style.display = 'block';
        return;
    }
    
    // ✅ DESHABILITAR BOTÓN PARA EVITAR DOBLE CLIC
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '⏳ Verificando...';
        btn.style.opacity = '0.7';
        btn.style.cursor = 'not-allowed';
    }
    
    errorDiv.style.display = 'none';
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=verificar_password_vinculacion&password=' + encodeURIComponent(password)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const modal = document.getElementById('modalVerificarPasswordVinculacion');
            if (modal) {
                modal.style.display = 'none';
            }
            window.clienteRegistrado = true;
            mostrarNotificacion('✅ Dispositivo vinculado', 'exito');
            setTimeout(function() {
                window.location.reload();
            }, 1500);
        } else {
            errorDiv.textContent = data.mensaje || 'Contraseña incorrecta';
            errorDiv.style.display = 'block';
            // ✅ REHABILITAR BOTÓN EN CASO DE ERROR
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '🔐 Verificar con contraseña';
                btn.style.opacity = '1';
                btn.style.cursor = 'pointer';
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
        errorDiv.textContent = 'Error de conexión';
        errorDiv.style.display = 'block';
        // ✅ REHABILITAR BOTÓN EN CASO DE ERROR
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '🔐 Verificar con contraseña';
            btn.style.opacity = '1';
            btn.style.cursor = 'pointer';
        }
    });
};

// ============================================
// ENVIAR ENLACE MÁGICO
// ============================================
window.enviarEnlaceMagico = function(event) {
    const btn = event.target;
    const mensajeDiv = document.getElementById('magicLinkMensaje');
    
    const email = window.emailPendienteVinculacion;
    
    if (!email) {
        mensajeDiv.innerHTML = '❌ No se pudo identificar tu email.';
        mensajeDiv.style.display = 'block';
        mensajeDiv.style.background = '#fed7d7';
        mensajeDiv.style.padding = '8px';
        mensajeDiv.style.borderRadius = '8px';
        mensajeDiv.style.color = '#c53030';
        return;
    }
    
    console.log('Email a enviar:', email);
    
    btn.disabled = true;
    btn.innerHTML = '⏳ Enviando...';
    
    fetch('includes/enviar_magic_link.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'email=' + encodeURIComponent(email)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mensajeDiv.innerHTML = '✅ ' + data.mensaje;
            mensajeDiv.style.background = '#f0fff4';
            mensajeDiv.style.padding = '8px';
            mensajeDiv.style.borderRadius = '8px';
            mensajeDiv.style.color = '#22543d';
            mensajeDiv.style.display = 'block';
            setTimeout(() => {
                cerrarModal('modalVerificarPasswordVinculacion');
                mostrarNotificacion('📧 Revisa tu email', 'exito');
            }, 2000);
        } else {
            mensajeDiv.innerHTML = '❌ ' + data.mensaje;
            mensajeDiv.style.display = 'block';
            btn.disabled = false;
            btn.innerHTML = '📧 Enviarme enlace por Email';
        }
    })
    .catch(error => {
        mensajeDiv.innerHTML = '❌ Error de conexión: ' + error;
        mensajeDiv.style.display = 'block';
        btn.disabled = false;
        btn.innerHTML = '📧 Enviarme enlace por Email';
    });
};
</script>
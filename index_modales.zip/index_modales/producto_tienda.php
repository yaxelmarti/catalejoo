<!-- MODAL PRODUCTO TIENDA -->
<div id="modalProductoTienda" class="modal-overlay" style="display: none;">
    <div class="modal-contenido" style="max-width: 900px; width: 90%; padding: 1.5rem;">
        <span class="close-modal" onclick="cerrarModalProductoTienda()">&times;</span>
        <div id="contenidoModalProductoTienda">
            <div style="text-align: center; padding: 2rem;">
                <div class="spinner-modal"></div>
                <p>Cargando producto...</p>
            </div>
        </div>
    </div>
</div>

<style>
/* Estilos base del modal */
.spinner-modal {
    width: 40px;
    height: 40px;
    border: 3px solid #e2e8f0;
    border-top-color: var(--primary, #3b82f6);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 1rem;
}
@keyframes spin {
    to { transform: rotate(360deg); }
}

.close-modal {
    position: absolute;
    top: 0.75rem;
    right: 0.75rem;
    font-size: 2.2rem;
    font-weight: bold;
    color: #ef4444;
    background: rgba(255,255,255,0.95);
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    cursor: pointer;
}
.close-modal:hover {
    background: #ef4444;
    color: white;
    transform: scale(1.1);
}

/* Botones de cantidad (base) */
.cantidad-btn {
    width: 40px;
    height: 40px;
    font-size: 1.5rem;
    background: #f3f4f6;
    border: 1px solid #d1d5db;
    border-radius: 30px;
    cursor: pointer;
    transition: background 0.2s;
}
.cantidad-btn:hover {
    background: #e5e7eb;
}
.cantidad-input {
    width: 50px;
    text-align: center;
    font-size: 1rem;
    font-weight: 500;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    padding: 0.3rem;
    background: white;
}
.btn-carrito {
    background: #10b981;
    color: white;
    padding: 0.5rem 1.2rem;
    border-radius: 30px;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    font-size: 0.85rem;
    transition: background 0.2s;
}
.btn-carrito:hover {
    background: #059669;
}

/* Para PC y móvil: botones de cantidad en las tarjetas más pequeños */
.productos-grid .cantidad-btn,
.lista-productos .cantidad-btn {
    width: 28px !important;
    height: 28px !important;
    font-size: 1rem !important;
}

.productos-grid .cantidad-input,
.lista-productos .cantidad-input {
    width: 32px !important;
    font-size: 0.85rem !important;
}
                          
/* === ESTILOS PARA MÓVILES CON BOTONES MÁS PEQUEÑOS === */
@media (max-width: 768px) {
    .modal-contenido {
        padding: 1rem !important;
    }
    #contenidoModalProductoTienda > div {
        grid-template-columns: 1fr !important;
        gap: 0.5rem !important;
    }
    #contenidoModalProductoTienda img {
        margin-bottom: 0.5rem !important;
    }
    #contenidoModalProductoTienda h3 {
        margin-top: 0 !important;
        margin-bottom: 0.3rem !important;
    }
    .close-modal {
        width: 40px;
        height: 40px;
        font-size: 1.8rem;
        top: 0.5rem;
        right: 0.5rem;
    }
    /* Reducción de tamaño de botones + y - */
    .cantidad-btn {
        width: 32px !important;
        height: 32px !important;
        font-size: 1.2rem !important;
    }
    .cantidad-input {
        width: 36px !important;
        font-size: 0.9rem !important;
    }
    .btn-carrito {
        padding: 0.4rem 0.9rem !important;
        font-size: 0.75rem !important;
    }
}
                          /* Botón carrito en tarjetas de producto - más pequeño */
.producto-card .btn-carrito,
.tarjeta-producto .btn-carrito,
[class*="producto"] .btn-carrito {
    padding: 0.35rem 0.9rem !important;
    font-size: 0.75rem !important;
    gap: 0.3rem !important;
    border-radius: 30px !important;
}

/* Ícono dentro del botón (si usas emoji o fuente) */
.producto-card .btn-carrito .carrito-icono,
.tarjeta-producto .btn-carrito .carrito-icono {
    font-size: 0.8rem !important;
}

/* Ajuste para móviles: aún más compacto */
@media (max-width: 768px) {
    .producto-card .btn-carrito,
    .tarjeta-producto .btn-carrito {
        padding: 0.25rem 0.6rem !important;
        font-size: 0.8rem !important;
    }
    .producto-card .btn-carrito .carrito-icono {
        font-size: 0.7rem !important;
    }
}
</style>

<script>
// Variables globales (placeholders)
window.clienteRegistrado = window.clienteRegistrado || false;
window.productoPendiente = null;

if (typeof mostrarNotificacion !== 'function') {
    window.mostrarNotificacion = function(mensaje, tipo = 'success') {
        alert(mensaje);
    };
}
if (typeof actualizarContadorCarrito !== 'function') {
    window.actualizarContadorCarrito = function() {
        console.log('Contador actualizado');
    };
}

window.modalProductoAbierto = false;


function verImagenGrande(url) {
    window.open(url, '_blank');
}

function abrirModalProductoTienda(productoId) {
    const idNumerico = parseInt(productoId);
    if (isNaN(idNumerico) || idNumerico <= 0) {
        console.error('ID inválido');
        mostrarNotificacion('Error: producto no válido', 'error');
        return;
    }
    if (window.modalProductoAbierto) return;
    
    if (!window.location.hash.includes('modal')) {
        window.history.pushState({ modal: true }, '', window.location.pathname + window.location.search + '#modal');
    }
    
    const modal = document.getElementById('modalProductoTienda');
    const contenedor = document.getElementById('contenidoModalProductoTienda');
    
    contenedor.innerHTML = `<div style="text-align:center;padding:2rem;"><div class="spinner-modal"></div><p>Cargando producto...</p></div>`;
    modal.style.display = 'block';
    window.modalProductoAbierto = true;
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    
    fetch('includes/get_producto_modal.php?id=' + idNumerico, { signal: controller.signal })
    .then(response => response.json())
    .then(data => {
        clearTimeout(timeoutId);
        if (data.success) {
            // ============================================
            // 1. REGISTRAR EVENTO DE VISUALIZACIÓN
            // ============================================
            fetch('includes/carrito_ajax.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'accion=registrar_evento&evento=ver_producto&producto_id=' + idNumerico
            }).catch(e => console.error('Error registrando evento:', e));
            
            // ============================================
            // 2. INCREMENTAR CONTADOR DE VISITAS
            // ============================================
            fetch('includes/carrito_ajax.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'accion=incrementar_vistas&tipo=producto&id=' + idNumerico
            }).catch(e => console.error('Error al incrementar vistas:', e));
                const nombreSeguro = escaparHTML(data.nombre);
                const descripcionSegura = escaparHTML(data.descripcion || '').replace(/\n/g, '<br>');
                const marcaSegura = data.marca ? escaparHTML(data.marca) : '';
                const categoriaNombreSeguro = data.categoria_nombre ? escaparHTML(data.categoria_nombre) : '';
                const categoriaIconoSeguro = data.categoria_icono ? escaparHTML(data.categoria_icono) : '';
                const imagenUrl = escaparHTML(data.imagen);
                
                let etiquetasHtml = '';
                if (data.cantidad <= 0) {
                    etiquetasHtml = '<span class="etiqueta-agotado">AGOTADO</span>';
                } else {
                    if (data.es_nuevo) etiquetasHtml += '<span class="etiqueta-nuevo">NUEVO</span>';
                    if (data.tiene_oferta) etiquetasHtml += `<span class="etiqueta-rebaja">-${data.porcentaje_rebaja}%</span>`;
                }
                
                let precioHtml = '';
                if (data.tiene_oferta) {
                    precioHtml = `
                        <span style="text-decoration: line-through; color: #ef4444; margin-right: 0.5rem;">${data.moneda}${data.precio_original} ${data.moneda_codigo}</span>
                        <span style="font-size: 1.8rem; font-weight: 700; color: #10b981;">${data.moneda}${data.precio_final}</span>
                        <span style="font-size: 0.8rem; color: #6b7280; margin-left: 0.2rem;">${data.moneda_codigo}</span>
                    `;
                } else {
                    precioHtml = `
                        <span style="font-size: 1.8rem; font-weight: 700; color: var(--primary, #3b82f6);">${data.moneda}${data.precio_normal}</span>
                        <span style="font-size: 0.8rem; color: #6b7280; margin-left: 0.2rem;">${data.moneda_codigo}</span>
                    `;
                }
                
                const cantidadDeshabilitada = data.cantidad <= 0 ? 'opacity:0.5; pointer-events:none;' : '';
                
                contenedor.innerHTML = `
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                        <div style="text-align: center;">
                            <div class="producto-etiquetas">${etiquetasHtml}</div>
                            <img src="${imagenUrl}" alt="${nombreSeguro}" style="max-width:100%; max-height:300px; object-fit:contain; border-radius:8px; cursor:pointer;" onclick="verImagenGrande('${imagenUrl}')">
                        </div>
                        <div>
                            ${marcaSegura ? `<p style="color:#6b7280; margin-bottom:0.5rem;">${marcaSegura}</p>` : ''}
                            <h3 style="font-size:1.2rem; margin-bottom:0.5rem;">${nombreSeguro}</h3>
                            <div style="margin-bottom:1rem; line-height:1.5;">${descripcionSegura}</div>
                            ${categoriaNombreSeguro ? `<div style="margin-bottom:0.8rem;"><span style="background:#eef2ff; color:#4f46e5; padding:0.3rem 0.8rem; border-radius:20px; font-size:0.75rem;">${categoriaIconoSeguro} ${categoriaNombreSeguro}</span></div>` : ''}
                            <div style="margin-bottom:1.5rem;">${precioHtml}</div>
                            <div style="display:flex; align-items:center; gap:1rem; flex-wrap:wrap;">
                                <div style="display:flex; align-items:center; gap:1rem; ${cantidadDeshabilitada}">
                                    <div class="cantidad-selector">
                                        <button class="cantidad-btn" onclick="cambiarCantidadModal(-1, ${data.id})">−</button>
                                        <input type="text" id="cantidadModal_${data.id}" class="cantidad-input" value="1" readonly>
                                        <button class="cantidad-btn" onclick="cambiarCantidadModal(1, ${data.id})">+</button>
                                    </div>
                                    <button class="btn-carrito" onclick="agregarAlCarritoModal(${data.id})">
                                        <span class="carrito-icono">🛒</span> Agregar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            } else {
                contenedor.innerHTML = `<div style="text-align:center;padding:2rem;color:#ef4444;">❌ ${escaparHTML(data.error)}</div>`;
            }
        })
        .catch(error => {
            clearTimeout(timeoutId);
            contenedor.innerHTML = `<div style="text-align:center;padding:2rem;color:#ef4444;">❌ Error al cargar el producto</div>`;
        });
}

function cerrarModalProductoTienda(reemplazarHash = true) {
    if (reemplazarHash && window.location.hash.includes('modal')) {
        window.history.replaceState({}, '', window.location.pathname + window.location.search);
    }
    const modal = document.getElementById('modalProductoTienda');
    if (modal) modal.style.display = 'none';
    window.modalProductoAbierto = false;
}

function cambiarCantidadModal(delta, productoId) {
    const input = document.getElementById(`cantidadModal_${productoId}`);
    if (!input) return;
    let valor = parseInt(input.value) || 1;
    valor = Math.max(1, Math.min(99, valor + delta));
    input.value = valor;
}

function agregarAlCarritoModal(productoId) {
    const input = document.getElementById(`cantidadModal_${productoId}`);
    const cantidad = input ? parseInt(input.value) : 1;
    
    if (!window.clienteRegistrado) {
        cerrarModalProductoTienda();
        const modalRegistro = document.getElementById('modalRegistro');
        if (modalRegistro) modalRegistro.style.display = 'block';
        window.productoPendiente = { id: productoId, cantidad: cantidad };
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=agregar&producto_id=' + productoId + '&cantidad=' + cantidad
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacion('✅ Producto agregado al carrito');
            actualizarContadorCarrito();
            cerrarModalProductoTienda();
        } else if (data.requiere_registro) {
            cerrarModalProductoTienda();
            const modalRegistro = document.getElementById('modalRegistro');
            if (modalRegistro) modalRegistro.style.display = 'block';
            window.productoPendiente = { id: productoId, cantidad: cantidad };
        } else {
            mostrarNotificacion('❌ ' + (data.mensaje || 'Error desconocido'), 'error');
        }
    })
    .catch(() => mostrarNotificacion('❌ Error de conexión', 'error'));
}

// Cerrar al hacer clic fuera del modal
document.addEventListener('click', function(event) {
    const modal = document.getElementById('modalProductoTienda');
    if (event.target === modal) cerrarModalProductoTienda();
});

// Cerrar con tecla ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && window.modalProductoAbierto) cerrarModalProductoTienda();
});
/*
// Manejar botón atrás del navegador
window.addEventListener('popstate', function() {
    if (window.modalProductoAbierto) cerrarModalProductoTienda();
});   */
</script>
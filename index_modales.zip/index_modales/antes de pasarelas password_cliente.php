<!-- /index_modales/password_cliente.php -->
<!-- ======================================== -->
<!-- MODAL VERIFICAR IDENTIDAD PARA EDITAR DATOS -->
<!-- ======================================== -->

<style>
#modalPasswordCliente .email-no-verificado {
    background: #fed7d7;
    border-left: 4px solid #f56565;
    padding: 1rem;
    margin: 1rem 0;
    border-radius: var(--radius-md);
    color: #c53030;
    font-size: 0.9rem;
}

#modalPasswordCliente .reenviar-link {
    color: #4299e1;
    text-decoration: underline;
    cursor: pointer;
    font-weight: 500;
}

#modalPasswordCliente .btn-password {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    transition: all 0.3s;
}

#modalPasswordCliente .btn-password:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

#modalPasswordCliente .btn-magic {
    width: 100%;
    padding: 1rem;
    background: #48bb78;
    color: white;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    transition: all 0.3s;
}

#modalPasswordCliente .btn-magic:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(72, 187, 120, 0.3);
}

#modalPasswordCliente .input-password {
    width: 100%;
    padding: 0.8rem;
    margin: 1rem 0;
    border: 2px solid #e2e8f0;
    border-radius: var(--radius-md);
    font-size: 1rem;
}

#modalPasswordCliente .error-message {
    color: #f56565;
    margin: 0.5rem 0;
    display: none;
    font-size: 0.9rem;
}

#modalPasswordCliente .separador {
    text-align: center;
    margin: 15px 0;
    color: #718096;
    font-size: 0.9rem;
}

#modalPasswordCliente .info-text {
    text-align: center;
    margin-bottom: 1rem;
    color: #718096;
    font-size: 0.9rem;
}
</style>

<div class="modal-overlay" id="modalPasswordCliente">
    <div class="modal-contenido" style="max-width: 400px;">
        <span class="close-modal" onclick="cerrarModal('modalPasswordCliente')">&times;</span>
        
        <h2 style="text-align: center; margin-bottom: 1.5rem;">🔐 Verificar identidad</h2>
        
        <?php if ($cliente_id > 0 && !$email_verified): ?>
        <div class="email-no-verificado">
            <p><strong>⚠️ Email no verificado</strong></p>
            <p>No has verificado tu dirección de correo electrónico.</p>
            <p><a href="#" onclick="reenviarVerificacionDesdeCliente()" class="reenviar-link">📧 Reenviar enlace de verificación</a></p>
        </div>
        <?php endif; ?>
        
        <!-- OPCIÓN 1: CONTRASEÑA -->
        <div id="opcionPassword">
            <p style="margin-bottom: 0.5rem; color: #4a5568;">Ingresa tu contraseña para editar tus datos:</p>
            <input type="password" id="cliente_password" class="input-password" placeholder="Contraseña">
            <div id="password_error_cliente" class="error-message"></div>
            <button class="btn-password" onclick="verificarPasswordCliente()">
                🔐 Verificar con contraseña
            </button>
        </div>
        
        <!-- SEPARADOR -->
        <div class="separador">— o —</div>
        
        <!-- OPCIÓN 2: ENLACE MÁGICO -->
        <div class="info-text">
            O recibe un enlace mágico a tu email para editar tus datos.
        </div>
        <div id="email_error_cliente" class="error-message"></div>
        <button class="btn-magic" onclick="enviarEnlaceMagicoEditar()">
            📧 Enviarme enlace mágico
        </button>
    </div>
</div>

<script>
// ============================================
// VERIFICAR CON CONTRASEÑA
// ============================================
function verificarPasswordCliente() {
    const password = document.getElementById('cliente_password').value;
    const errorDiv = document.getElementById('password_error_cliente');
    
    if (!password) {
        errorDiv.textContent = 'Ingresa tu contraseña';
        errorDiv.style.display = 'block';
        return;
    }
    
    fetch('includes/cliente_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=verificar_password&password=' + encodeURIComponent(password)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            cerrarModal('modalPasswordCliente');
            if (typeof cargarDatosCliente === 'function') {
                cargarDatosCliente();
            }
        } else {
            errorDiv.textContent = data.mensaje || 'Contraseña incorrecta';
            errorDiv.style.display = 'block';
        }
    });
}

// ============================================
// ENVIAR ENLACE MÁGICO
// ============================================
function enviarEnlaceMagicoEditar() {
    const btn = event.target;
    const errorDiv = document.getElementById('email_error_cliente');
    
    btn.disabled = true;
    btn.innerHTML = '⏳ Enviando...';
    
    // Obtener email del cliente actual desde el servidor
    fetch('includes/cliente_ajax.php?accion=obtener_email')
    .then(response => response.json())
    .then(data => {
        if (data.success && data.email) {
            return fetch('includes/enviar_magic_link_editar_cliente.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'email=' + encodeURIComponent(data.email)
            });
        } else {
            throw new Error('No se pudo obtener tu email');
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            cerrarModal('modalPasswordCliente');
            mostrarNotificacion('📧 Revisa tu email. El enlace expira en 15 minutos.', 'exito');
        } else {
            errorDiv.textContent = data.mensaje;
            errorDiv.style.display = 'block';
            btn.disabled = false;
            btn.innerHTML = '📧 Enviarme enlace mágico';
        }
    })
    .catch(error => {
        errorDiv.textContent = error.message || 'Error de conexión';
        errorDiv.style.display = 'block';
        btn.disabled = false;
        btn.innerHTML = '📧 Enviarme enlace mágico';
    });
}
</script>
<!-- /index_modales/sincronizar.php -->
<!-- ======================================== -->
<!-- MODAL SINCRONIZAR CARRITO -->
<!-- ======================================== -->

<style>
#modalSincronizar .input-email {
    width: 100%;
    padding: 0.8rem;
    margin: 1rem 0;
    border: 2px solid #e2e8f0;
    border-radius: var(--radius-md);
    font-size: 1rem;
}

#modalSincronizar .btn-sincronizar {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    transition: all 0.3s;
}

#modalSincronizar .btn-sincronizar:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

#modalSincronizar .info-texto {
    background: #ebf8ff;
    padding: 1rem;
    border-radius: var(--radius-md);
    margin: 1rem 0;
    color: #2c5282;
    font-size: 0.9rem;
    border-left: 4px solid #4299e1;
}
</style>

<div class="modal-overlay" id="modalSincronizar">
    <div class="modal-contenido">
        <span class="close-modal" onclick="cerrarModal('modalSincronizar')">&times;</span>
        
        <h2 style="text-align: center; margin-bottom: 1rem;">🔄 Sincronizar Carrito</h2>
        
        <div class="info-texto">
            <p style="margin: 0; display: flex; align-items: center; gap: 0.5rem;">
                <span>📱</span>
                <span>Ingresa tu correo para recuperar tu carrito en este dispositivo.</span>
            </p>
        </div>
        
        <form id="formSincronizar" onsubmit="sincronizarCarrito(event)">
            <input type="email" name="email_sync" class="input-email" placeholder="Tu correo electrónico" required>
            
            <button type="submit" class="btn-sincronizar">
                🔄 Sincronizar Carrito
            </button>
        </form>
    </div>
</div>

<script>
(function() {
    window.abrirModalSincronizar = function() {
        document.getElementById('modalSincronizar').style.display = 'block';
    };

    window.sincronizarCarrito = function(event) {
        event.preventDefault();
        const email = event.target.email_sync.value;
        
        fetch('includes/carrito_ajax.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'accion=sincronizar&email=' + encodeURIComponent(email)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                cerrarModal('modalSincronizar');
                mostrarNotificacion('✅ Carrito sincronizado', 'exito');
                actualizarContadorCarrito();
            } else {
                mostrarNotificacion('❌ ' + data.mensaje, 'error');
            }
        });
    };
})();
</script>
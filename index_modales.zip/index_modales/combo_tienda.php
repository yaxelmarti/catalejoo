<!-- ============================================ -->
<!-- MODAL COMBO TIENDA -->
<!-- ============================================ -->
<div id="modalComboTienda" class="modal-overlay" style="display: none;">
    <div class="modal-contenido" style="max-width: 900px; width: 90%; padding: 1.5rem;">
        <span class="close-modal" onclick="window.cerrarModalComboTienda()">&times;</span>
        <div id="contenidoModalComboTienda">
            <div style="text-align: center; padding: 2rem;">
                <div class="spinner-modal"></div>
                <p>Cargando combo...</p>
            </div>
        </div>
    </div>
</div>

<style>
/* ============================================
   ESTILOS MODAL COMBO (IGUAL QUE PRODUCTOS)
   ============================================ */
.spinner-modal {
    width: 40px;
    height: 40px;
    border: 3px solid #e2e8f0;
    border-top-color: var(--primary, #3b82f6);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 1rem;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.close-modal {
    position: absolute;
    top: 0.75rem;
    right: 0.75rem;
    font-size: 2.2rem;
    font-weight: bold;
    color: #ef4444;
    background: rgba(255,255,255,0.95);
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    cursor: pointer;
    z-index: 9999;
}

.close-modal:hover {
    background: #ef4444;
    color: white;
    transform: scale(1.1);
}

.cantidad-btn {
    width: 40px;
    height: 40px;
    font-size: 1.5rem;
    background: #f3f4f6;
    border: 1px solid #d1d5db;
    border-radius: 30px;
    cursor: pointer;
    transition: background 0.2s;
}

.cantidad-btn:hover {
    background: #e5e7eb;
}

.cantidad-input {
    width: 50px;
    text-align: center;
    font-size: 1rem;
    font-weight: 500;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    padding: 0.3rem;
    background: white;
}

.btn-carrito {
    background: #10b981;
    color: white;
    padding: 0.5rem 1.2rem;
    border-radius: 30px;
    border: none;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    font-size: 0.85rem;
    transition: background 0.2s;
}

.btn-carrito:hover {
    background: #059669;
}

.btn-carrito .carrito-icono {
    background: #1a2a4f;
    display: inline-block;
    width: 24px;
    height: 24px;
    line-height: 24px;
    text-align: center;
    border-radius: 50%;
    font-size: 0.9rem;
    margin-left: -0.2rem;
    position: relative;
    left: -0.1rem;
}

/* Responsive móvil */
@media (max-width: 768px) {
    .modal-contenido {
        padding: 1rem !important;
    }
    
    #contenidoModalComboTienda > div {
        grid-template-columns: 1fr !important;
        gap: 0.5rem !important;
    }
    
    #contenidoModalComboTienda img {
        margin-bottom: 0.5rem !important;
    }
    
    #contenidoModalComboTienda h3 {
        margin-top: 0 !important;
        margin-bottom: 0.3rem !important;
    }
    
    .close-modal {
        width: 40px;
        height: 40px;
        font-size: 1.8rem;
        top: 0.5rem;
        right: 0.5rem;
    }
    
    .cantidad-btn {
        width: 32px !important;
        height: 32px !important;
        font-size: 1.2rem !important;
    }
    
    .cantidad-input {
        width: 36px !important;
        font-size: 0.9rem !important;
    }
    
    .btn-carrito {
        padding: 0.4rem 0.9rem !important;
        font-size: 0.75rem !important;
    }
    
    .btn-carrito .carrito-icono {
        width: 28px;
        height: 28px;
        line-height: 28px;
        font-size: 1rem;
        margin-left: -0.25rem;
    }
}

.producto-etiquetas {
    position: absolute;
    top: 10px;
    left: 10px;
    display: flex;
    gap: 6px;
    z-index: 2;
}

.etiqueta-nuevo,
.etiqueta-rebaja,
.etiqueta-agotado {
    padding: 4px 10px;
    border-radius: 30px;
    font-size: 0.7rem;
    font-weight: bold;
    color: white;
}

.etiqueta-nuevo { background: #3b82f6; }
.etiqueta-rebaja { background: #84cc16; color: #1e3a8a; }
.etiqueta-agotado { background: #4b5563; }
</style>

<script>
// ============================================
// VARIABLE GLOBAL
// ============================================
window.modalComboAbierto = false;

// ============================================
// ESCAPAR HTML (SEGURIDAD)
// ============================================
function escaparHTML(str) {
    if (str === null || str === undefined || typeof str !== 'string') {
        return '';
    }
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

// ============================================
// VER IMAGEN GRANDE
// ============================================
function verImagenGrande(url) {
    window.open(url, '_blank');
}

// ============================================
// ABRIR MODAL COMBO
// ============================================
window.abrirModalComboTienda = function(comboId) {
    const idNumerico = parseInt(comboId);
    if (isNaN(idNumerico) || idNumerico <= 0) {
        console.error('ID de combo inválido');
        if (typeof mostrarNotificacion === 'function') {
            mostrarNotificacion('Error: combo no válido', 'error');
        }
        return;
    }
    
    if (window.modalComboAbierto) return;
    
    if (!window.location.hash.includes('modal')) {
        window.history.pushState({ modal: true }, '', window.location.pathname + window.location.search + '#modal');
    }
    
    const modal = document.getElementById('modalComboTienda');
    const contenedor = document.getElementById('contenidoModalComboTienda');
    
    if (!modal || !contenedor) {
        console.error('Elementos del modal no encontrados');
        return;
    }
    
    contenedor.innerHTML = `<div style="text-align:center;padding:2rem;">
        <div class="spinner-modal"></div>
        <p>Cargando combo...</p>
    </div>`;
    modal.style.display = 'block';
    window.modalComboAbierto = true;
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    
    fetch('includes/get_combo_modal.php?id=' + idNumerico, { signal: controller.signal })
    .then(response => {
        clearTimeout(timeoutId);
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            try {
                fetch('includes/carrito_ajax.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'accion=registrar_evento&evento=ver_combo&producto_id=' + idNumerico
                }).catch(e => console.warn('Evento no registrado:', e));
            } catch (e) {
                console.warn('Error registrando evento:', e);
            }
            
            try {
                fetch('includes/carrito_ajax.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'accion=incrementar_vistas&tipo=combo&id=' + idNumerico
                }).catch(e => console.warn('Visita no registrada:', e));
            } catch (e) {
                console.warn('Error incrementando visitas:', e);
            }
            
            renderizarModalCombo(data, contenedor);
        } else {
            contenedor.innerHTML = `<div style="text-align:center;padding:2rem;color:#ef4444;">
                ❌ ${data.error || 'Error al cargar el combo'}
            </div>`;
        }
    })
    .catch(error => {
        clearTimeout(timeoutId);
        console.error('Error:', error);
        contenedor.innerHTML = `<div style="text-align:center;padding:2rem;color:#ef4444;">
            ❌ Error al cargar el combo. Por favor, intenta de nuevo.
        </div>`;
    });
};

// ============================================
// RENDERIZAR MODAL COMBO
// ============================================
function renderizarModalCombo(data, contenedor) {
    if (!data || !data.combo) {
        contenedor.innerHTML = `<div style="text-align:center;padding:2rem;color:#ef4444;">❌ Datos del combo no disponibles</div>`;
        return;
    }
    
    const combo = data.combo;
    const monedaSimbolo = data.moneda_simbolo || '$';
    const monedaCodigo = data.moneda_codigo || 'USD';
    
    const nombreSeguro = escaparHTML(combo.nombre || '');
    const descripcionSegura = combo.descripcion || '';
    const imagenUrl = escaparHTML(combo.imagen_url || '');
    
    contenedor.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
            <div style="text-align: center; position: relative;">
                <div class="producto-etiquetas">
                    ${combo.es_nuevo ? '<span class="etiqueta-nuevo">NUEVO</span>' : ''}
                    ${combo.porcentaje_rebaja > 0 ? `<span class="etiqueta-rebaja">-${combo.porcentaje_rebaja}%</span>` : ''}
                    ${combo.stock_combo <= 0 ? '<span class="etiqueta-agotado">AGOTADO</span>' : ''}
                </div>
                <img src="${imagenUrl}" style="max-width:100%; max-height:300px; object-fit:contain; border-radius:8px; cursor:pointer;" onclick="verImagenGrande('${imagenUrl}')">
            </div>
            <div>
                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">${nombreSeguro}</h3>
                <div style="margin: 0.5rem 0;">${descripcionSegura}</div>
                <div style="font-size: 0.85rem;">🎁 ${combo.total_productos || 0} productos - ${combo.total_unidades || 0} unidades</div>
                <div style="margin: 0.5rem 0;">
                    ${combo.porcentaje_rebaja > 0 ? `
                        <span style="text-decoration: line-through;">${monedaSimbolo}${parseFloat(combo.precio || 0).toFixed(2)}</span>
                        <strong style="font-size: 1.5rem; color: #10b981;">${monedaSimbolo}${parseFloat(combo.precio_final || combo.precio || 0).toFixed(2)}</strong>
                    ` : `<strong style="font-size: 1.5rem;">${monedaSimbolo}${parseFloat(combo.precio || 0).toFixed(2)}</strong>`}
                    <small>${monedaCodigo}</small>
                </div>
                <div style="display: flex; align-items: center; gap: 1rem; ${combo.stock_combo <= 0 ? 'opacity: 0.5; pointer-events: none;' : ''}">
                    <div class="cantidad-selector">
                        <button class="cantidad-btn" onclick="window.cambiarCantidadComboModal(-1, ${combo.id})">−</button>
                        <input type="text" id="cantidadComboModal_${combo.id}" class="cantidad-input" value="1" readonly>
                        <button class="cantidad-btn" onclick="window.cambiarCantidadComboModal(1, ${combo.id})">+</button>
                    </div>
                    <button class="btn-carrito" onclick="window.agregarComboModalAlCarrito(${combo.id})" style="${combo.stock_combo <= 0 ? 'display: none;' : ''}">
                        <span class="carrito-icono">🛒</span> Agregar combo
                    </button>
                </div>
                ${combo.stock_combo <= 0 ? '<div style="color: #ef4444; text-align: center; margin-top: 1rem;">❌ Combo agotado</div>' : ''}
            </div>
        </div>
    `;
}

// ============================================
// CERRAR MODAL COMBO
// ============================================
window.cerrarModalComboTienda = function() {
    if (window.location.hash.includes('modal')) {
        const urlLimpia = window.location.pathname + window.location.search;
        window.history.replaceState({}, '', urlLimpia);
    }
    const modal = document.getElementById('modalComboTienda');
    if (modal) modal.style.display = 'none';
    window.modalComboAbierto = false;
};

// ============================================
// CAMBIAR CANTIDAD EN MODAL COMBO
// ============================================
window.cambiarCantidadComboModal = function(delta, comboId) {
    const input = document.getElementById(`cantidadComboModal_${comboId}`);
    if (!input) return;
    let valor = parseInt(input.value) || 1;
    valor = Math.max(1, Math.min(99, valor + delta));
    input.value = valor;
};

// ============================================
// AGREGAR COMBO AL CARRITO DESDE MODAL
// ============================================
window.agregarComboModalAlCarrito = function(comboId) {
    const input = document.getElementById(`cantidadComboModal_${comboId}`);
    const cantidad = input ? parseInt(input.value) : 1;
    
    if (!window.clienteRegistrado) {
        window.cerrarModalComboTienda();
        const modalRegistro = document.getElementById('modalRegistro');
        if (modalRegistro) modalRegistro.style.display = 'block';
        window.productoPendiente = { combo: true, id: comboId, cantidad: cantidad };
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=agregar_combo&combo_id=' + comboId + '&cantidad=' + cantidad
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (typeof mostrarNotificacion === 'function') {
                mostrarNotificacion('✅ Combo agregado al carrito', 'exito');
            }
            if (typeof actualizarContadorCarrito === 'function') {
                actualizarContadorCarrito();
            }
            window.cerrarModalComboTienda();
        } else {
            if (typeof mostrarNotificacion === 'function') {
                mostrarNotificacion('❌ ' + (data.mensaje || 'Error'), 'error');
            }
        }
    })
    .catch(() => {
        if (typeof mostrarNotificacion === 'function') {
            mostrarNotificacion('❌ Error de conexión', 'error');
        }
    });
};

// ============================================
// CIERRE DEL MODAL COMBO AL HACER CLICK EN OVERLAY
// ============================================
document.addEventListener('click', function(event) {
    if (event.target === document.getElementById('modalComboTienda')) {
        window.cerrarModalComboTienda();
    }
});

// ============================================
// CIERRE CON TECLA ESC
// ============================================
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && window.modalComboAbierto) {
        window.cerrarModalComboTienda();
    }
});
</script>
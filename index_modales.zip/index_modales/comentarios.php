<!-- Modal de Comentarios -->
<div id="modalComentarios" class="modal-overlay" style="display: none;">
    <div class="modal-contenido" style="max-width: 500px;">
        <span class="close-modal" onclick="cerrarModalComentarios()">&times;</span>
        <h3 style="margin-bottom: 1rem;">💬 Deja tu comentario</h3>
        <p style="margin-bottom: 1rem; font-size: 0.85rem; color: #666;">¿Encontraste un error? ¿Tienes una sugerencia? Cuéntanos.</p>
        
        <form id="formComentario">
            <div class="form-group" style="margin-bottom: 0.8rem;">
                <label>Tu nombre (opcional)</label>
                <input type="text" name="nombre" id="comentario_nombre" style="width: 100%; padding: 0.6rem; border: 1px solid #ddd; border-radius: 8px;">
            </div>
            <div class="form-group" style="margin-bottom: 0.8rem;">
                <label>Tu email (opcional)</label>
                <input type="email" name="email" id="comentario_email" style="width: 100%; padding: 0.6rem; border: 1px solid #ddd; border-radius: 8px;">
            </div>
            <div class="form-group" style="margin-bottom: 0.8rem;">
                <label>Tipo de comentario</label>
                <select name="tipo" id="comentario_tipo" style="width: 100%; padding: 0.6rem; border: 1px solid #ddd; border-radius: 8px;">
                    <option value="comentario">💬 Comentario general</option>
                    <option value="bug">🐞 Error o problema</option>
                    <option value="sugerencia">💡 Sugerencia</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom: 1rem;">
                <label>Mensaje *</label>
                <textarea name="mensaje" id="comentario_mensaje" rows="4" required style="width: 100%; padding: 0.6rem; border: 1px solid #ddd; border-radius: 8px;"></textarea>
            </div>
            <button type="submit" class="btn-enviar" style="width: 100%; padding: 0.7rem; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                📤 Enviar comentario
            </button>
        </form>
        <div id="comentarioRespuesta" style="margin-top: 1rem; text-align: center;"></div>
    </div>
</div>

<script>
function abrirModalComentarios() {
    document.getElementById('modalComentarios').style.display = 'block';
    document.getElementById('comentario_nombre').value = '';
    document.getElementById('comentario_email').value = '';
    document.getElementById('comentario_tipo').value = 'comentario';
    document.getElementById('comentario_mensaje').value = '';
    document.getElementById('comentarioRespuesta').innerHTML = '';
}

function cerrarModalComentarios() {
    document.getElementById('modalComentarios').style.display = 'none';
}

document.getElementById('formComentario').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const mensaje = document.getElementById('comentario_mensaje').value.trim();
    if (!mensaje) {
        alert('Por favor, escribe un mensaje');
        return;
    }
    
    const btn = this.querySelector('button[type="submit"]');
    const textoOriginal = btn.innerHTML;
    btn.innerHTML = '⏳ Enviando...';
    btn.disabled = true;
    
    fetch('/guardar_comentario.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            nombre: document.getElementById('comentario_nombre').value,
            email: document.getElementById('comentario_email').value,
            tipo: document.getElementById('comentario_tipo').value,
            mensaje: mensaje,
            url: window.location.href
        })
    })
    .then(response => response.json())
    .then(data => {
        const respuestaDiv = document.getElementById('comentarioRespuesta');
        if (data.success) {
            respuestaDiv.innerHTML = '<span style="color: green;">✅ ' + data.mensaje + '</span>';
            document.getElementById('formComentario').reset();
            setTimeout(() => {
                cerrarModalComentarios();
            }, 2000);
        } else {
            respuestaDiv.innerHTML = '<span style="color: red;">❌ ' + data.mensaje + '</span>';
        }
        btn.innerHTML = textoOriginal;
        btn.disabled = false;
    })
    .catch(error => {
        document.getElementById('comentarioRespuesta').innerHTML = '<span style="color: red;">❌ Error al enviar</span>';
        btn.innerHTML = textoOriginal;
        btn.disabled = false;
    });
});
</script>

<style>
#modalComentarios .modal-contenido {
    max-width: 500px;
    padding: 1.5rem;
}
#modalComentarios .form-group label {
    font-size: 0.8rem;
    font-weight: 600;
    display: block;
    margin-bottom: 0.2rem;
}
</style>
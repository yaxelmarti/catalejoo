<?php
// ============================================
// MARKETING - CARRUSEL DE IMÁGENES
// ============================================

$carrusel_activo = true;
$carrusel_imagenes = [];

// Ruta de la carpeta de imágenes
$carpeta = $_SERVER['DOCUMENT_ROOT'] . '/uploads/config/';

// Orden manual (lista los nombres exactos de las imágenes en el orden que quieras)
$orden_personalizado = [
    'carrusel_categoria_12.webp',
    'carrusel_ofertas_1.webp',     // segundo
    'carrusel_combos_1.webp',      // tercero
    'carrusel_categoria_7.webp',   // primero
    'carrusel_categoria_10.webp',
    'carrusel_combos_1.webp',
    'carrusel_categoria_15.webp',
    'carrusel_categoria_8.webp',
    'carrusel_combos_1.webp',
    'carrusel_categoria_13.webp',
    'carrusel_categoria_1.webp',
    'carrusel_categoria_11.webp',
    'carrusel_combos_1.webp',
    // ... añade todas las que tengas
];

$carrusel_imagenes = [];
foreach ($orden_personalizado as $nombre) {
    $ruta = $carpeta . $nombre;
    if (file_exists($ruta)) {
        $carrusel_imagenes[] = str_replace($_SERVER['DOCUMENT_ROOT'], '', $ruta);
    }
}

// ============================================
// ENLACES DEL CARRUSEL (comentados por defecto)
// ============================================
// Las imágenes deben existir en /uploads/config/
// Descomenta la línea de la imagen que quieras usar

// ============================================
// SLUG DE LA TIENDA INSIGNIA (id 1)
// Se lee de la BD para que sea escalable:
// si cambia el nombre/slug, los enlaces se actualizan solos.
// ============================================
$marketing_tienda_slug = '';
if (isset($conn) && $conn instanceof mysqli) {
    $stmt_mkt = $conn->prepare("SELECT slug FROM proveedores WHERE id = 1 AND activo = 1");
    if ($stmt_mkt) {
        $stmt_mkt->execute();
        $res_mkt = $stmt_mkt->get_result();
        if ($row_mkt = $res_mkt->fetch_assoc()) {
            $marketing_tienda_slug = $row_mkt['slug'];
        }
        $stmt_mkt->close();
    }
}

$enlaces_carrusel = [];

// --- CATEGORÍAS (filtran dentro de la tienda 1) ---
$enlaces_carrusel['carrusel_categoria_1.webp']  = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=1';  // electrodomesticos
$enlaces_carrusel['carrusel_categoria_7.webp']  = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=7';  // alimentos
$enlaces_carrusel['carrusel_categoria_8.webp']  = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=8';  // bebidas
$enlaces_carrusel['carrusel_categoria_10.webp'] = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=10'; // dulces
$enlaces_carrusel['carrusel_categoria_11.webp'] = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=11'; // limpieza
$enlaces_carrusel['carrusel_categoria_12.webp'] = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=12'; // carnicos
$enlaces_carrusel['carrusel_categoria_13.webp'] = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=13'; // higiene
$enlaces_carrusel['carrusel_categoria_15.webp'] = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&categoria=15'; // lacteos

// --- SECCIONES ESPECIALES (filtran dentro de la tienda 1) ---
$enlaces_carrusel['carrusel_ofertas_1.webp'] = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&filtro=ofertas';
$enlaces_carrusel['carrusel_combos_1.webp']  = 'index.php?proveedor=' . urlencode($marketing_tienda_slug) . '&filtro=combos';
// $enlaces_carrusel['carrusel_mas_vendidos_1.webp'] = '/index.php?filtro=mas_vendidos'; // Más vendidos

// --- ENLACES EXTERNOS ---
// $enlaces_carrusel['carrusel_externo_1.webp'] = 'https://ejemplo.com/promo1';
// $enlaces_carrusel['carrusel_externo_2.webp'] = 'https://ejemplo.com/promo2';
// $enlaces_carrusel['carrusel_externo_3.webp'] = 'https://ejemplo.com/promo3';
// $enlaces_carrusel['carrusel_externo_4.webp'] = 'https://ejemplo.com/promo4';

$repeticiones = 8;
$imagenes_infinitas = array_merge(...array_fill(0, $repeticiones, $carrusel_imagenes));

if ($carrusel_activo && count($carrusel_imagenes) > 0):
?>
<style>
.carrusel-container {
    width: 100%;
    overflow: hidden;
    position: relative;
    margin-top: 0rem;
    margin-bottom: 2rem;
}

.carrusel-track {
    display: flex;
    transition: transform 0.5s ease;
    gap: 1rem;
    cursor: grab;
}

.carrusel-track:active {
    cursor: grabbing;
}

.carrusel-slide {
    flex: 0 0 100%;
    min-width: 100%;
}

.carrusel-slide img {
    width: 100%;
    height: 300px;
    object-fit: contain;
    display: block;
    border-radius: 40%;
}

/* PC y tablets (≥550px): dos imágenes */
@media (min-width: 490px) {
    .carrusel-slide {
        flex: 0 0 calc(50% - 0.5rem);
        min-width: calc(50% - 0.5rem);
    }
}

/* Móviles pequeños (<550px): una imagen */
@media (max-width: 489px) {
    .carrusel-slide {
        flex: 0 0 100%;
        min-width: 100%;
    }
}

/* Móviles: borde a borde */
@media (max-width: 768px) {
    .carrusel-container {
        margin-left: -1rem;
        margin-right: -1rem;
        width: calc(100% + 2rem);
    }
    
    .carrusel-slide img {
        height: 180px;
        border-radius: 40%;
    }
}

/* Pantallas muy pequeñas */
@media (max-width: 480px) {
    .carrusel-slide img {
        height: 180px;
    }
}
    
/* Contenedor principal del carrusel */
#carruselContainer {
    position: relative;
    width: 100%;
    min-height: 300px; /* Ajustá según la altura de tu carrusel */
}

/* Capa del carrusel (detrás) */
.carrusel-back {
    position: relative;
    z-index: 1;
    width: 100%;
}

/* Capa de la imagen superpuesta (encima) */
.carrusel-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 2;
    pointer-events: none;
    /* Eliminamos flex y alineaciones que puedan centrar la imagen */
    display: block;
}

/* Imagen con forma de ventana - ajuste automático SIN bordes laterales */
.ventana-imagen {
    width: 100%;
    height: 100%;
    object-fit: cover;  /* Cambiado de 'contain' a 'cover' */
    object-position: top center;
    pointer-events: none;
    display: block;
    margin: 0;
    padding: 0;
    border-radius: 16px;
}
    
  /* Ajustes solo para móviles */
@media (max-width: 768px) {
    .ventana-imagen {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: top center;
        transform: scale(1.10);  /* Amplía un poco la imagen */
        border-radius: 16px;
    }
    
    .carrusel-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
    
    /* NUEVO: Reduce separación del título */
    .carrusel-container {
        margin-top: 0rem !important;
        margin-bottom: 0 !important;
    }
    
    #carruselContainer {
        min-height: auto !important;
        margin-bottom: 0 !important;
    }
}
</style>

<div class="carrusel-container">
    <div class="carrusel-track">
        <?php foreach ($imagenes_infinitas as $img): 
            $nombre_archivo = basename($img);
            $url_destino = isset($enlaces_carrusel[$nombre_archivo]) ? $enlaces_carrusel[$nombre_archivo] : '';
        ?>
            <div class="carrusel-slide">
    <?php if (!empty($url_destino)): ?>
       <a href="javascript:void(0);" onclick="event.preventDefault(); sessionStorage.setItem('no_mostrar_carrito_pendiente', 'true'); window.location.href='<?php echo $url_destino; ?>';">
            <img src="<?php echo $img; ?>" alt="Carrusel" loading="lazy">
        </a>
    <?php else: ?>
        <img src="<?php echo $img; ?>" alt="Carrusel" loading="lazy">
    <?php endif; ?>
</div>
        <?php endforeach; ?>
    </div>
</div>

<script>
(function() {
    const track = document.querySelector('.carrusel-track');
    if (!track) return;
    
    const slides = document.querySelectorAll('.carrusel-slide');
    const totalSlides = slides.length;
    let currentIndex = 0;
    let autoPlayInterval;
    
    function getSlideWidth() {
        return slides[0].offsetWidth + 16;
    }
    
    function updateCarrusel(animate = true) {
        const slideWidth = getSlideWidth();
        if (animate) {
            track.style.transition = 'transform 0.5s ease';
        } else {
            track.style.transition = 'none';
        }
        track.style.transform = 'translateX(-' + (currentIndex * slideWidth) + 'px)';
    }
    
    function nextSlide() {
        currentIndex++;
        
        if (currentIndex >= totalSlides) {
            currentIndex = 0;
            updateCarrusel(false);
            setTimeout(() => {
                currentIndex = 1;
                updateCarrusel(true);
            }, 200);
        } else {
            updateCarrusel(true);
        }
    }
    
    function startAutoPlay() {
        autoPlayInterval = setInterval(nextSlide, 3000);
    }
    
    // ===== DESLIZAR HACIA ATRÁS (TÁCTIL Y MOUSE) =====
    let startX = 0;
    let isDragging = false;
    let dragStarted = false;
    
    function goNext() {
        currentIndex++;
        if (currentIndex >= totalSlides) {
            currentIndex = 0;
            updateCarrusel(false);
            setTimeout(() => {
                currentIndex = 1;
                updateCarrusel(true);
            }, 200);
        } else {
            updateCarrusel(true);
        }
    }
    
    function goPrev() {
        if (currentIndex > 0) {
            currentIndex--;
            updateCarrusel(true);
        } else {
            currentIndex = totalSlides - 1;
            updateCarrusel(true);
        }
    }
    
    track.addEventListener('touchstart', function(e) {
        clearInterval(autoPlayInterval);
        startX = e.touches[0].clientX;
        isDragging = true;
        dragStarted = true;
    });
    
    track.addEventListener('touchmove', function(e) {
        if (!isDragging) return;
        const diff = e.touches[0].clientX - startX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) {
                goPrev();
            } else {
                goNext();
            }
            isDragging = false;
        }
    });
    
    track.addEventListener('touchend', function() {
        isDragging = false;
        if (dragStarted) {
            startAutoPlay();
            dragStarted = false;
        }
    });
    
    track.addEventListener('mousedown', function(e) {
        clearInterval(autoPlayInterval);
        startX = e.clientX;
        isDragging = true;
        dragStarted = true;
        track.style.cursor = 'grabbing';
    });
    
    window.addEventListener('mousemove', function(e) {
        if (!isDragging) return;
        const diff = e.clientX - startX;
        if (Math.abs(diff) > 50) {
            if (diff > 0) {
                goPrev();
            } else {
                goNext();
            }
            isDragging = false;
        }
    });
    
    window.addEventListener('mouseup', function() {
        if (dragStarted) {
            isDragging = false;
            track.style.cursor = 'grab';
            startAutoPlay();
            dragStarted = false;
        }
    });
    
    updateCarrusel(false);
    startAutoPlay();
})();
    
    function cargarContenido(url) {
    // Guardar en sessionStorage para evitar el modal de carrito pendiente
    sessionStorage.setItem('volviendo_de_ayuda', 'true');
    
    // Redirigir normalmente
    window.location.href = url;
}
</script>
<?php endif; ?>
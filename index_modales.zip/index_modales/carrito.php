<!-- /index_modales/carrito.php -->
<!-- ======================================== -->
<!-- MODAL CARRITO PRINCIPAL -->
<!-- ======================================== -->

<style>
#modalCarrito .modal-contenido {
    display: flex;
    flex-direction: column;
    max-height: 90vh;
}

#modalCarrito .tiempo-restante {
    margin-bottom: 1rem;
    padding: 1rem;
    background: #fef5e7;
    border-radius: 8px;
    color: #744210;
    font-weight: 500;
    flex-shrink: 0;
}

#modalCarrito .items-container {
    flex: 1;
    overflow-y: auto;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    margin-bottom: 1rem;
    min-height: 200px;
}

#modalCarrito .item-carrito {
    display: flex;
    gap: 1rem;
    padding: 1rem;
    border-bottom: 1px solid #e2e8f0;
    transition: background 0.3s;
}

#modalCarrito .item-carrito:hover {
    background: #f7fafc;
}

#modalCarrito .item-carrito:last-child {
    border-bottom: none;
}

#modalCarrito .item-imagen {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
}

#modalCarrito .item-info {
    flex: 1;
}

#modalCarrito .item-nombre {
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 0.2rem;
}

#modalCarrito .item-precio {
    color: #718096;
    font-size: 0.9rem;
}

#modalCarrito .item-acciones {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-top: 0.5rem;
}

#modalCarrito .btn-cantidad {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 2px solid var(--primary);
    background: white;
    color: var(--primary);
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
}

#modalCarrito .btn-cantidad:hover {
    background: var(--primary);
    color: white;
}

#modalCarrito .btn-eliminar {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: 2px solid #f56565;
    background: white;
    color: #f56565;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
}

#modalCarrito .btn-eliminar:hover {
    background: #f56565;
    color: white;
}

#modalCarrito .item-subtotal {
    font-weight: bold;
    color: var(--primary);
    min-width: 80px;
    text-align: right;
}

#modalCarrito .resumen-carrito {
    border-top: 2px solid #e2e8f0;
    padding-top: 1rem;
    margin-top: 1rem;
    flex-shrink: 0;
}

#modalCarrito .total-line {
    display: flex;
    justify-content: space-between;
    font-size: 1.2rem;
    margin-bottom: 1rem;
}

#modalCarrito .total-monto {
    color: var(--primary);
    font-weight: bold;
}

#modalCarrito .btn-finalizar {
    width: 100%;
    padding: 06rem;
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

#modalCarrito .btn-finalizar:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(72, 187, 120, 0.3);
}

#modalCarrito .btn-cancelar-carrito {
    flex: 1;
    padding: 1rem;
    background: #f56565;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

#modalCarrito .btn-cancelar-carrito:hover {
    transform: translateY(-2px);
    background: #e53e3e;
    box-shadow: 0 5px 15px rgba(245, 101, 101, 0.3);
}

#modalCarrito .carrito-vacio {
    text-align: center;
    padding: 3rem;
    color: #718096;
}

#modalCarrito .carrito-vacio span {
    font-size: 4rem;
    display: block;
    margin-bottom: 1rem;
}

.botones-accion {
    display: flex;
    gap: 0.8rem;
    margin-top: 1rem;
}
                                
                                /* ===== ESTILOS RESPONSIVE PARA MÓVIL ===== */
@media (max-width: 768px) {
    #modalCarrito .modal-contenido {
        padding: 0.8rem;
        width: 95%;
        max-width: none;
    }
    
    #modalCarrito h2 {
        font-size: 1.2rem;
        margin-bottom: 0.8rem !important;
    }
    
    #modalCarrito .item-carrito {
        gap: 0.5rem;
        padding: 0.6rem;
    }
    
    #modalCarrito .item-imagen {
        width: 45px;
        height: 45px;
    }
    
    #modalCarrito .item-nombre {
        font-size: 0.8rem;
    }
    
    #modalCarrito .item-precio {
        font-size: 0.7rem;
    }
    
    #modalCarrito .btn-cantidad {
        width: 25px;
        height: 25px;
        font-size: 0.8rem;
    }
    
    #modalCarrito .btn-eliminar {
        width: 25px;
        height: 25px;
        font-size: 0.8rem;
    }
    
    #modalCarrito .item-subtotal {
        font-size: 0.8rem;
        min-width: 60px;
    }
    
    #modalCarrito .tiempo-restante {
        padding: 0.6rem;
        font-size: 0.8rem;
    }
    
    #modalCarrito .total-line {
        font-size: 1rem;
    }
    
    #modalCarrito .btn-seguir-comprando,
    #modalCarrito .btn-finalizar,
    #modalCarrito .btn-cancelar-carrito {
        padding: 0.5rem;
        font-size: 0.8rem;
    }
}
                                
  /* Ocultar completamente el modal del carrito hasta que se abra */
#modalCarrito {
    display: none;
}
</style>

<div class="modal-overlay" id="modalCarrito">
    <div class="modal-contenido" style="max-width: 600px; display: flex; flex-direction: column;">
        <span class="close-modal" onclick="cerrarModal('modalCarrito')">&times;</span>
        
        <h2 style="margin-bottom: 1.5rem; flex-shrink: 0;">🛒 Mi Carrito</h2>
        
        <div id="contenidoCarrito" class="items-container"></div>
    </div>
</div>

<script>
// FUNCIONES GLOBALES
window.abrirCarrito = function() {
    fetch('includes/carrito_ajax.php?accion=obtener_carrito')
    .then(response => response.json())
    .then(data => {
        const contenido = document.getElementById('contenidoCarrito');
        
        if (data.success && !data.vacio) {
            const simbolo = data.moneda_simbolo || '$';
            const codigo = data.moneda_codigo || 'USD';
            
            let html = '<div class="tiempo-restante">⏰ Tiempo restante: <strong>' + data.horas_restantes + ' horas</strong></div>';
            
            data.items.forEach(item => {
    if (item.tipo === 'combo') {
        html += `
            <div class="item-carrito" data-tipo="combo" data-id="${item.carrito_combo_id}">
                <img src="${item.imagen}" class="item-imagen">
                <div class="item-info">
                    <div class="item-nombre">🎁 ${item.nombre} (COMBO)</div>
                                        <div class="item-precio">${simbolo}${parseFloat(item.precio_unitario).toFixed(2)} ${codigo} c/u</div>
                    <div class="item-acciones">
                        <button class="btn-cantidad" onclick="actualizarCantidadCombo(${item.carrito_combo_id}, ${item.cantidad - 1})">−</button>
                        <span style="min-width: 30px; text-align: center;">${item.cantidad}</span>
                        <button class="btn-cantidad" onclick="actualizarCantidadCombo(${item.carrito_combo_id}, ${item.cantidad + 1})">+</button>
                        <button class="btn-eliminar" onclick="eliminarCombo(${item.carrito_combo_id})">🗑️</button>
                    </div>
                </div>
                                <div class="item-subtotal">${simbolo}${parseFloat(item.subtotal).toFixed(2)}</div>
            </div>
        `;
    } else {
        html += `
            <div class="item-carrito" data-tipo="producto" data-id="${item.carrito_producto_id}">
                <img src="${item.imagen}" class="item-imagen">
                <div class="item-info">
                    <div class="item-nombre">${item.nombre}</div>
                                        <div class="item-precio">${simbolo}${parseFloat(item.precio).toFixed(2)} ${codigo} c/u</div>
                    <div class="item-acciones">
                        <button class="btn-cantidad" onclick="actualizarCantidadProducto(${item.carrito_producto_id}, ${item.cantidad - 1})">−</button>
                        <span style="min-width: 30px; text-align: center;">${item.cantidad}</span>
                        <button class="btn-cantidad" onclick="actualizarCantidadProducto(${item.carrito_producto_id}, ${item.cantidad + 1})">+</button>
                        <button class="btn-eliminar" onclick="eliminarProductoItem(${item.carrito_producto_id})">🗑️</button>
                    </div>
                </div>
                                <div class="item-subtotal">${simbolo}${parseFloat(item.subtotal).toFixed(2)}</div>
            </div>
        `;
    }
});
            
            html += `
                <div class="resumen-carrito">
                                        <div class="total-line">
                        <span>Total:</span>
                        <span class="total-monto">${simbolo}${data.total.toFixed(2)} ${codigo}</span>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 0.6rem;">
                        <button class="btn-seguir-comprando" onclick="cerrarModal('modalCarrito')" style="width: 100%; padding: 0.6rem; background: #4299e1; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                            🛍️ Seguir Comprando
                        </button>
                        <button class="btn-finalizar" onclick="comprar()" style="width: 100%; padding: 0.6rem; background: linear-gradient(135deg, #48bb78 0%, #38a169 100%); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                            ✅ Finalizar Compra
                        </button>
                        <button class="btn-cancelar-carrito" onclick="cancelarCarritoCliente()" style="width: 100%; padding: 0.6rem; background: #f56565; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                            🗑️ Cancelar Carrito
                        </button>
                    </div>
                </div>
            `;
            
            contenido.innerHTML = html;
        } else {
            contenido.innerHTML = '<div class="carrito-vacio"><span>🛒</span><p>Tu carrito está vacío</p></div>';
        }
        
        document.getElementById('modalCarrito').style.display = 'block';
    });
};

// Funciones para combos en el carrito
window.actualizarCantidadCombo = function(carritoComboId, nuevaCantidad) {
    if (nuevaCantidad < 1) return;
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=actualizar_cantidad&tipo=combo&id=' + carritoComboId + '&cantidad=' + nuevaCantidad
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.abrirCarrito();
            window.actualizarContadorCarrito();
        } else {
            mostrarNotificacion(data.mensaje || '❌ Error al actualizar', 'error');
        }
    });
};

window.eliminarCombo = function(carritoComboId) {
    if (!confirm('¿Eliminar este combo del carrito?')) return;
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=eliminar&tipo=combo&id=' + carritoComboId
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.abrirCarrito();
            window.actualizarContadorCarrito();
        } else {
            mostrarNotificacion(data.mensaje || '❌ Error al eliminar', 'error');
        }
    });
};

// Funciones para productos individuales
window.actualizarCantidadProducto = function(carritoProductoId, nuevaCantidad) {
    if (nuevaCantidad < 0) return;
    
    if (nuevaCantidad === 0) {
        eliminarProductoItem(carritoProductoId);
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=actualizar_cantidad&tipo=producto&id=' + carritoProductoId + '&cantidad=' + nuevaCantidad
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.abrirCarrito();
            window.actualizarContadorCarrito();
        } else {
            mostrarNotificacion(data.mensaje || '❌ Error al actualizar', 'error');
        }
    });
};

window.eliminarProductoItem = function(carritoProductoId) {
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=eliminar&tipo=producto&id=' + carritoProductoId
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.abrirCarrito();
            window.actualizarContadorCarrito();
        } else {
            mostrarNotificacion(data.mensaje || '❌ Error al eliminar', 'error');
        }
    });
};

window.actualizarCantidad = function(productoId, nuevaCantidad) {
    // Mantener compatibilidad con funciones antiguas
    window.actualizarCantidadProducto(productoId, nuevaCantidad);
};

window.eliminarProducto = function(productoId) {
    window.eliminarProductoItem(productoId);
};

window.cancelarCarritoCliente = function() {
    if (!confirm('¿Estás seguro de que deseas cancelar todo el carrito? Se eliminarán todos los productos y combos.')) {
        return;
    }
    
    fetch('includes/carrito_ajax.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'accion=vaciar'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacion('🗑️ Carrito cancelado correctamente', 'exito');
            cerrarModal('modalCarrito');
            window.actualizarContadorCarrito();
            // Actualizar carrito sin recargar
if (typeof cargarContenidoCarritoLateral === 'function') {
    cargarContenidoCarritoLateral();
}
        } else {
            mostrarNotificacion('❌ Error al cancelar el carrito', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarNotificacion('❌ Error al cancelar el carrito', 'error');
    });
};
</script>
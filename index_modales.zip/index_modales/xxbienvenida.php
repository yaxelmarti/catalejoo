<?php
$mensaje_personalizado = "🎉 ¡Bienvenido a CataLejoo!\n\n---------------------\n\nBuscamos 🤝 ganarnos tu confianza\n\n💰 Estamos en mejoras constante\n\n💬 Puedes dejar comentarios\n\nY nos ayudas a mejorar\n\nVive la Expeciencia con Catalejoo";
?>

<style>
#modalBienvenida .modal-contenido {
    max-width: 500px;
    text-align: center;
    padding: 2rem;
}

#modalBienvenida h2 {
    margin: 1rem 0;
    color: #2d3748;
    font-size: 1.1rem;
    line-height: 0.8;
     white-space: normal;
}

#modalBienvenida .btn-empezar {
    width: 100%;
    padding: 0.8rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border: none;
    border-radius: 30px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    margin-top: 1rem;
}

#modalBienvenida .btn-empezar:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102,126,234,0.3);
}
</style>

<div class="modal-overlay" id="modalBienvenida" style="display: none;">
    <div class="modal-contenido">
        <span class="close-modal" onclick="cerrarModalBienvenida()">&times;</span>
        <div style="font-size: 4rem;">🎉</div>
        <h2><?php echo nl2br(htmlspecialchars($mensaje_personalizado)); ?></h2>
        <button class="btn-empezar" onclick="cerrarModalBienvenida()">Comenzar a comprar</button>
    </div>
</div>

<script>
function cerrarModalBienvenida() {
    document.getElementById('modalBienvenida').style.display = 'none';
}

// ============================================
// OPCIÓN 1: localStorage (una sola vez en la vida)
// ============================================
 if (!localStorage.getItem('bienvenida_mostrada')) {
    setTimeout(function() {
        var modal = document.getElementById('modalBienvenida');
        if (modal) modal.style.display = 'block';
        localStorage.setItem('bienvenida_mostrada', 'true');
    }, 1000);
}

// ============================================
// OPCIÓN 2: sessionStorage (cada nueva sesión/pestaña)
// ============================================
/*
if (!sessionStorage.getItem('bienvenida_mostrada')) {
    setTimeout(function() {
        var modal = document.getElementById('modalBienvenida');
        if (modal) modal.style.display = 'block';
        sessionStorage.setItem('bienvenida_mostrada', 'true');
    }, 1000);
}
*/
</script>
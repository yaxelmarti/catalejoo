<!-- /index_modales/password_compra.php -->
<!-- ======================================== -->
<!-- COMPRA SIN VALIDACIÓN DE CONTRASEÑA -->
<!-- ======================================== -->

<style>
#modalPasswordCompra {
    display: none !important;
}
</style>

<div class="modal-overlay" id="modalPasswordCompra" style="display: none;">
</div>

<script>
(function() {
    window.comprar = function() {
        // Cerrar carrito
        cerrarModal('modalCarrito');
        
        // Llamar directamente a la compra sin contraseña
        fetch('includes/carrito_ajax.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'accion=comprar'
        })
        .then(response => response.json())
        .then(data => {
            console.log('Respuesta compra:', data);
            
            if (data.success && data.mostrar_modal_entrega) {
                // Abrir modal de datos de entrega
                var modalEntrega = document.getElementById('modalDatosEntrega');
                if (modalEntrega) {
                    modalEntrega.style.display = 'block';
                    
                    // Actualizar subtotal y total en el modal
                    if (document.getElementById('modal_subtotal')) {
                        document.getElementById('modal_subtotal').dataset.valor = data.subtotal;
                        document.getElementById('modal_subtotal').textContent = parseFloat(data.subtotal).toFixed(2);
                    }
                    if (document.getElementById('modal_total')) {
                        document.getElementById('modal_total').textContent = parseFloat(data.subtotal).toFixed(2);
                    }
                } else {
                    console.error('No se encontró el modal modalDatosEntrega');
                    mostrarNotificacion('Error: No se pudo abrir el formulario de entrega', 'error');
                }
            } else if (!data.success) {
                mostrarNotificacion('❌ ' + (data.mensaje || 'Error al procesar la compra'), 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarNotificacion('❌ Error al conectar con el servidor', 'error');
        });
    };
})();
</script>
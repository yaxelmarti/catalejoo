<!-- /index_modales/editar_cliente.php -->
<!-- ======================================== -->
<!-- MODAL EDITAR DATOS DEL CLIENTE (SEGURO) -->
<!-- ======================================== -->

<?php
// ===== PROCESAR TOKEN DEL ENLACE MÁGICO =====
if (isset($_GET['token'])) {
    session_start();
    require_once dirname(__DIR__) . '/conexion.php';
    
    $token = $_GET['token'];
    
    // Validar token
    $stmt = $conn->prepare("SELECT id FROM clientes WHERE reset_token = ? AND reset_expires > NOW() AND activo = 1");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // Regenerar sesión por seguridad
        session_regenerate_id(true);
        $_SESSION['cliente_id'] = $row['id'];
        
        // Limpiar token (ya usado)
        $stmt = $conn->prepare("UPDATE clientes SET reset_token = NULL, reset_expires = NULL WHERE id = ?");
        $stmt->bind_param("i", $row['id']);
        $stmt->execute();
    }
    
    // Redirigir a la tienda con parámetro
    header('Location: /?abrir_editar=1');
    exit;
}

// ===== GENERAR TOKEN CSRF =====
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
?>

<style>
#modalEditarCliente .campo-doble {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

#modalEditarCliente .campo-doble input {
    flex: 1;
}

#modalEditarCliente input {
    width: 100%;
    padding: 0.8rem;
    margin-bottom: 1rem;
    border: 2px solid #e2e8f0;
    border-radius: var(--radius-md);
    font-size: 1rem;
    transition: all 0.3s;
    box-sizing: border-box;
}

#modalEditarCliente input:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

#modalEditarCliente input.error {
    border-color: #fc8181;
    box-shadow: 0 0 0 3px rgba(252, 129, 129, 0.1);
}

#modalEditarCliente .btn-actualizar {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    transition: all 0.3s;
}

#modalEditarCliente .btn-actualizar:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(72, 187, 120, 0.3);
}

#modalEditarCliente .btn-actualizar:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

#modalEditarCliente .separador {
    border-top: 1px solid #e2e8f0;
    margin: 1.5rem 0;
}

#modalEditarCliente .password-ayuda {
    font-size: 0.8rem;
    color: #718096;
    margin-top: -0.5rem;
    margin-bottom: 1rem;
}

#modalEditarCliente .password-requisitos {
    font-size: 0.75rem;
    color: #718096;
    margin-top: -0.5rem;
    margin-bottom: 0.5rem;
    padding-left: 1rem;
}

#modalEditarCliente .password-requisitos li {
    list-style: none;
    margin: 2px 0;
}

#modalEditarCliente .password-requisitos li.valid {
    color: #48bb78;
}

#modalEditarCliente .password-requisitos li.invalid {
    color: #fc8181;
}

#modalEditarCliente .campo-contraseña {
    margin-top: 1.5rem;
    padding-top: 1rem;
    border-top: 1px solid #e2e8f0;
}

#modalEditarCliente .spinner {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 3px solid rgba(255,255,255,0.3);
    border-radius: 50%;
    border-top-color: #fff;
    animation: spin 0.8s ease-in-out infinite;
    vertical-align: middle;
    margin-right: 8px;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

#modalEditarCliente .mensaje-error {
    color: #fc8181;
    font-size: 0.85rem;
    margin-top: -0.5rem;
    margin-bottom: 1rem;
    display: none;
}

#modalEditarCliente .mensaje-exito {
    color: #48bb78;
    font-size: 0.85rem;
    margin-top: -0.5rem;
    margin-bottom: 1rem;
    display: none;
}
</style>

<div class="modal-overlay" id="modalEditarCliente">
    <div class="modal-contenido" style="max-width: 500px;">
        <span class="close-modal" onclick="cerrarModal('modalEditarCliente')">&times;</span>
        
        <h2 style="margin-bottom: 1.5rem;">✏️ Editar mis datos</h2>
        
        <!-- Mensajes -->
        <div id="edit_mensaje_error" class="mensaje-error"></div>
        <div id="edit_mensaje_exito" class="mensaje-exito"></div>
        
        <form id="formEditarCliente" onsubmit="actualizarDatosCliente(event)" autocomplete="off">
            <!-- CSRF Token -->
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
            
            <!-- Datos personales -->
            <input type="text" name="edit_nombre" id="edit_nombre" placeholder="Nombre completo" required maxlength="100" autocomplete="name">
            
            <input type="email" name="edit_email" id="edit_email" placeholder="Email" required maxlength="100" autocomplete="email">
            
            <input type="tel" name="edit_movil" id="edit_movil" placeholder="Móvil (ej: 5XXXXXXX)" required maxlength="20" autocomplete="tel">
            
            <!-- CAMPO CAMBIAR CONTRASEÑA -->
            <div class="campo-contraseña">
                <h3 style="font-size: 1rem; color: #2d3748; margin-bottom: 0.5rem;">🔐 Cambiar contraseña <span style="font-weight: normal; color: #718096; font-size: 0.8rem;">(opcional)</span></h3>
                
                <input type="password" name="edit_password_new" id="edit_password_new" placeholder="Nueva contraseña" autocomplete="new-password" minlength="6" maxlength="100">
                
                <ul class="password-requisitos" id="passwordRequisitos">
                    <li id="req_longitud">❌ Mínimo 6 caracteres</li>
                    <li id="req_mayuscula">❌ Al menos una mayúscula</li>
                    <li id="req_numero">❌ Al menos un número</li>
                </ul>
                
                <input type="password" name="edit_password_confirm" id="edit_password_confirm" placeholder="Confirmar nueva contraseña" autocomplete="new-password">
                
                <div class="password-ayuda">Déjalo en blanco si no quieres cambiar la contraseña.</div>
            </div>
            
            <button type="submit" class="btn-actualizar" id="btnActualizarDatos">
                Actualizar datos
            </button>
        </form>
    </div>
</div>

<script>
(function() {
    'use strict';
    
    // ===== VALIDACIÓN DE CONTRASEÑA EN TIEMPO REAL =====
    const passwordInput = document.getElementById('edit_password_new');
    const confirmInput = document.getElementById('edit_password_confirm');
    const reqLongitud = document.getElementById('req_longitud');
    const reqMayuscula = document.getElementById('req_mayuscula');
    const reqNumero = document.getElementById('req_numero');
    
    function validarPassword(password) {
        const tieneLongitud = password.length >= 6;
        const tieneMayuscula = /[A-Z]/.test(password);
        const tieneNumero = /[0-9]/.test(password);
        
        // Actualizar requisitos
        reqLongitud.textContent = (tieneLongitud ? '✅' : '❌') + ' Mínimo 6 caracteres';
        reqLongitud.className = tieneLongitud ? 'valid' : 'invalid';
        
        reqMayuscula.textContent = (tieneMayuscula ? '✅' : '❌') + ' Al menos una mayúscula';
        reqMayuscula.className = tieneMayuscula ? 'valid' : 'invalid';
        
        reqNumero.textContent = (tieneNumero ? '✅' : '❌') + ' Al menos un número';
        reqNumero.className = tieneNumero ? 'valid' : 'invalid';
        
        return tieneLongitud && tieneMayuscula && tieneNumero;
    }
    
    passwordInput.addEventListener('input', function() {
        if (this.value.length > 0) {
            document.getElementById('passwordRequisitos').style.display = 'block';
            validarPassword(this.value);
        } else {
            document.getElementById('passwordRequisitos').style.display = 'none';
        }
    });
    
    // ===== CARGAR DATOS DEL CLIENTE =====
    window.cargarDatosCliente = function() {
        const modal = document.getElementById('modalEditarCliente');
        const errorMsg = document.getElementById('edit_mensaje_error');
        const exitoMsg = document.getElementById('edit_mensaje_exito');
        
        // Ocultar mensajes previos
        errorMsg.style.display = 'none';
        exitoMsg.style.display = 'none';
        
        fetch('includes/cliente_ajax.php?accion=obtener_datos')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error de red: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                document.getElementById('edit_nombre').value = data.nombre || '';
                document.getElementById('edit_email').value = data.email || '';
                document.getElementById('edit_movil').value = data.movil || '';
                
                // Limpiar campos de contraseña
                document.getElementById('edit_password_new').value = '';
                document.getElementById('edit_password_confirm').value = '';
                document.getElementById('passwordRequisitos').style.display = 'none';
                
                modal.style.display = 'block';
            } else {
                mostrarNotificacion('❌ No se pudieron cargar los datos', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarNotificacion('❌ Error al cargar los datos del cliente', 'error');
        });
    };
    
    // ===== ACTUALIZAR DATOS DEL CLIENTE =====
    window.actualizarDatosCliente = function(event) {
        event.preventDefault();
        
        const btn = document.getElementById('btnActualizarDatos');
        const errorMsg = document.getElementById('edit_mensaje_error');
        const exitoMsg = document.getElementById('edit_mensaje_exito');
        
        // Ocultar mensajes previos
        errorMsg.style.display = 'none';
        exitoMsg.style.display = 'none';
        
        // Obtener valores
        const nombre = document.getElementById('edit_nombre').value.trim();
        const email = document.getElementById('edit_email').value.trim();
        const movil = document.getElementById('edit_movil').value.trim();
        const password = document.getElementById('edit_password_new').value;
        const confirm = document.getElementById('edit_password_confirm').value;
        const csrfToken = document.querySelector('input[name="csrf_token"]').value;
        
        // ===== VALIDACIONES CLIENTE =====
        // 1. Validar nombre
        if (nombre.length < 2) {
            mostrarError('El nombre debe tener al menos 2 caracteres');
            document.getElementById('edit_nombre').focus();
            return;
        }
        
        // 2. Validar email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            mostrarError('Ingresa un email válido');
            document.getElementById('edit_email').focus();
            return;
        }
        
        // 3. Validar móvil
        const movilRegex = /^[0-9+\-\s]{5,20}$/;
        if (!movilRegex.test(movil)) {
            mostrarError('Ingresa un número de móvil válido');
            document.getElementById('edit_movil').focus();
            return;
        }
        
        // 4. Validar contraseña si se ingresa
        if (password) {
            // Longitud mínima
            if (password.length < 6) {
                mostrarError('La contraseña debe tener al menos 6 caracteres');
                document.getElementById('edit_password_new').focus();
                return;
            }
            
            // Al menos una mayúscula
            if (!/[A-Z]/.test(password)) {
                mostrarError('La contraseña debe tener al menos una mayúscula');
                document.getElementById('edit_password_new').focus();
                return;
            }
            
            // Al menos un número
            if (!/[0-9]/.test(password)) {
                mostrarError('La contraseña debe tener al menos un número');
                document.getElementById('edit_password_new').focus();
                return;
            }
            
            // Confirmar contraseña
            if (password !== confirm) {
                mostrarError('Las contraseñas no coinciden');
                document.getElementById('edit_password_confirm').focus();
                return;
            }
        }
        
        // ===== ENVIAR PETICIÓN =====
        // Deshabilitar botón
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner"></span> Actualizando...';
        
        // Construir datos
        const datos = new URLSearchParams();
        datos.append('accion', 'actualizar_datos');
        datos.append('edit_nombre', nombre);
        datos.append('edit_email', email);
        datos.append('edit_movil', movil);
        datos.append('csrf_token', csrfToken);
        if (password) {
            datos.append('edit_password_new', password);
        }
        
        fetch('includes/cliente_ajax.php', {
            method: 'POST',
            body: datos,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error de red: ' + response.status);
            }
            return response.json();
        })
       .then(data => {
    if (data.success) {
        // ✅ ACTUALIZAR EL TOKEN CSRF
        if (data.csrf_token) {
            document.querySelector('input[name="csrf_token"]').value = data.csrf_token;
        }
        
        // Mostrar éxito
        exitoMsg.textContent = '✅ ' + (data.mensaje || 'Datos actualizados correctamente');
        exitoMsg.style.display = 'block';
        
        // Cerrar modal después de 1.5 segundos
        setTimeout(() => {
            cerrarModal('modalEditarCliente');
            mostrarNotificacion('✅ Datos actualizados correctamente', 'exito');
            
            // Limpiar campos de contraseña
            document.getElementById('edit_password_new').value = '';
            document.getElementById('edit_password_confirm').value = '';
            document.getElementById('passwordRequisitos').style.display = 'none';
        }, 1500);
    } else {
        mostrarError('❌ ' + (data.mensaje || 'Error al actualizar los datos'));
    }
})
        .catch(error => {
            console.error('Error:', error);
            mostrarError('❌ Error de conexión con el servidor. Intenta de nuevo.');
        })
        .finally(() => {
            // Habilitar botón
            btn.disabled = false;
            btn.innerHTML = 'Actualizar datos';
        });
    };
    
    // ===== FUNCIONES AUXILIARES =====
    function mostrarError(mensaje) {
        const errorMsg = document.getElementById('edit_mensaje_error');
        errorMsg.textContent = mensaje;
        errorMsg.style.display = 'block';
        
        // Ocultar después de 5 segundos
        setTimeout(() => {
            errorMsg.style.display = 'none';
        }, 5000);
    }
    
    // ===== AL ENVIAR FORMULARIO CON ENTER =====
    document.getElementById('formEditarCliente').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            this.dispatchEvent(new Event('submit'));
        }
    });
    
    // ===== LIMPIAR AL CERRAR =====
    const modal = document.getElementById('modalEditarCliente');
    const closeBtn = modal.querySelector('.close-modal');
    
    function limpiarModal() {
        // Limpiar campos de contraseña
        document.getElementById('edit_password_new').value = '';
        document.getElementById('edit_password_confirm').value = '';
        document.getElementById('passwordRequisitos').style.display = 'none';
        
        // Ocultar mensajes
        document.getElementById('edit_mensaje_error').style.display = 'none';
        document.getElementById('edit_mensaje_exito').style.display = 'none';
    }
    
    // Al cerrar con X
    closeBtn.addEventListener('click', limpiarModal);
    
    // Al cerrar haciendo clic fuera
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            limpiarModal();
        }
    });
    
})();
</script>
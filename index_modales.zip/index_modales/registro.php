<!-- /index_modales/registro.php -->
<!-- ======================================== -->
<!-- MODAL REGISTRO -->
<!-- ======================================== -->

<?php
// ============================================
// PRESELECCIÓN DE PREFIJO TELEFÓNICO SEGÚN IP
// ============================================
// El header ya calculó $_SESSION['pais_detectado'].
// Si no existe, se usa US por defecto.

$pais_detectado_registro = $_SESSION['pais_detectado'] ?? 'US';

// Mapeo país ISO → prefijo telefónico
$prefijos_por_pais = [
    'CU' => '+53',
    'ES' => '+34',
    'MX' => '+52',
    'AR' => '+54',
    'CL' => '+56',
    'CO' => '+57',
    'PE' => '+51',
    'VE' => '+58',
    'GT' => '+502',
    'SV' => '+503',
    'HN' => '+504',
    'NI' => '+505',
    'CR' => '+506',
    'PA' => '+507',
    'BO' => '+591',
    'EC' => '+593',
    'PY' => '+595',
    'UY' => '+598',
    'BR' => '+55',
    'GB' => '+44',
    'FR' => '+33',
    'DE' => '+49',
    'IT' => '+39',
    'AU' => '+61',
    'JP' => '+81',
    'CN' => '+86',
    'IN' => '+91',
    'US' => '+1',
];

// Prefijo a preseleccionar (con fallback a +1)
$prefijo_preseleccionado = $prefijos_por_pais[$pais_detectado_registro] ?? '+1';
?>

<style>
#modalRegistro .campo-doble {
    display: flex;
    gap: 0.8rem;
    margin-bottom: 0.8rem;
    flex-wrap: wrap;
}

#modalRegistro .campo-doble > div {
    flex: 1;
    min-width: 120px;
}

#modalRegistro label {
    display: block;
    font-size: 0.8rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.2rem;
}

#modalRegistro input {
    width: 100%;
    padding: 0.8rem;
    border: 2px solid #e2e8f0;
    border-radius: 12px;
    font-size: 0.95rem;
    transition: all 0.3s;
}

#modalRegistro input:focus {
    border-color: var(--primary) !important;
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    background: white !important;
}

#modalRegistro .recordarme-box {
    margin: 1rem 0;
    padding: 0.8rem;
    background: #f8fafc;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
}

#modalRegistro .recordarme-box label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    cursor: pointer;
    margin: 0;
}

#modalRegistro .recordarme-box input[type="checkbox"] {
    width: 18px;
    height: 18px;
    accent-color: var(--primary);
}

#modalRegistro .alerta-48h {
    background: #fef5e7;
    border-left: 4px solid #ecc94b;
    padding: 0.8rem;
    border-radius: 8px;
    margin: 1rem 0;
    font-size: 0.9rem;
    color: #744210;
}

#modalRegistro .alerta-email {
    margin: 1rem 0;
    padding: 0.8rem;
    background: #ebf8ff;
    border-left: 4px solid #4299e1;
    border-radius: 8px;
    font-size: 0.85rem;
    color: #2c5282;
}

#modalRegistro .btn-registro {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border: none;
    border-radius: 50px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    margin-top: 1.5rem;
}

#modalRegistro .btn-registro:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
}

#modalRegistro .icono-header {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1rem;
    color: white;
    font-size: 2.5rem;
}

@media (max-width: 480px) {
    #modalRegistro .campo-doble {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    #modalRegistro .modal-contenido {
        padding: 1.5rem !important;
    }
}
</style>

<div class="modal-overlay" id="modalRegistro">
    <div class="modal-contenido" style="max-width: 550px; padding: 2rem;">
        <span class="close-modal" onclick="cerrarModal('modalRegistro')">&times;</span>
        
       <div style="text-align: center; margin-bottom: 0.8rem;">
    <h2 style="color: #2d3748; margin-bottom: 0.2rem; font-size: 1.2rem;">¡Regístrate en Catalejo!</h2>
</div>
            
        <form id="formRegistro" onsubmit="registrarCliente(event)">
       <div style="margin-bottom: 0.8rem;">
    <label>ESCRIBA SU NOMBRE COMPLETO *</label>
    <input type="text" name="nombre_completo" placeholder="Ej: Juan Pérez" required>
</div>
            
            <div style="margin-bottom: 0.8rem;">
                <label>SU CORREO ELECTRONICO (EMAIL) *</label>
                <input type="email" name="email" placeholder="ejemplo@correo.com" required>
            </div>
            
          <div style="margin-bottom: 0.8rem;">
    <label>INTRODUSCA SU NUMERO MOVIL *</label>
    <div style="display: flex; gap: 0.5rem; align-items: center;">
            <select name="codigo_pais" id="codigoPais" style="width: 100px; padding: 0.8rem; border: 2px solid #e2e8f0; border-radius: 12px; font-size: 0.95rem; flex-shrink: 0;">
            <?php
            // Lista de países con prefijo
            $prefijos_select = [
                '+1'   => '🇺🇸 +1',
                '+53'  => '🇨🇺 +53',
                '+34'  => '🇪🇸 +34',
                '+52'  => '🇲🇽 +52',
                '+54'  => '🇦🇷 +54',
                '+56'  => '🇨🇱 +56',
                '+57'  => '🇨🇴 +57',
                '+51'  => '🇵🇪 +51',
                '+58'  => '🇻🇪 +58',
                '+502' => '🇬🇹 +502',
                '+503' => '🇸🇻 +503',
                '+504' => '🇭🇳 +504',
                '+505' => '🇳🇮 +505',
                '+506' => '🇨🇷 +506',
                '+507' => '🇵🇦 +507',
                '+591' => '🇧🇴 +591',
                '+593' => '🇪🇨 +593',
                '+595' => '🇵🇾 +595',
                '+598' => '🇺🇾 +598',
                '+55'  => '🇧🇷 +55',
                '+44'  => '🇬🇧 +44',
                '+33'  => '🇫🇷 +33',
                '+49'  => '🇩🇪 +49',
                '+39'  => '🇮🇹 +39',
                '+61'  => '🇦🇺 +61',
                '+81'  => '🇯🇵 +81',
                '+86'  => '🇨🇳 +86',
                '+91'  => '🇮🇳 +91',
            ];
            foreach ($prefijos_select as $valor => $label):
                $selected = ($valor === $prefijo_preseleccionado) ? 'selected' : '';
            ?>
                <option value="<?php echo htmlspecialchars($valor); ?>" <?php echo $selected; ?>><?php echo htmlspecialchars($label); ?></option>
            <?php endforeach; ?>
        </select>
        <input type="tel" name="movil" id="movilInput" placeholder="Ej: 5XXXXXXX" required style="flex: 1; padding: 0.8rem; border: 2px solid #e2e8f0; border-radius: 12px; font-size: 0.95rem;">
    </div>
</div>
            
            <div style="margin-bottom: 0.8rem;">
    <label>DEFINA CONTRASEÑA * <small style="color: #718096; font-size: 0.75rem;">🔒 Mínimo 6 caracteres</small></label>
    <input type="password" name="password" placeholder="Mínimo 6 caracteres" required minlength="6">
</div>
            
            <div class="recordarme-box">
                <label>
                    <input type="checkbox" name="recordarme" value="1" checked>
                    <span style="font-size: 0.9rem; color: #4a5568;">Recordarme en este dispositivo</span>
                </label>
            </div>
            
            <div class="alerta-48h">
    <p style="margin: 0; display: flex; align-items: center; gap: 0.5rem;">
        <span style="font-size: 1.2rem;">⏰</span>
        <span>Carrito valido por <strong><?php echo $config['tiempo_expiracion'] ?? 30; ?> horas</strong></span>
    </p>
    <p style="margin: 0.5rem 0 0 0; display: flex; align-items: center; gap: 0.5rem; font-size: 0.9rem; color: #2c5282;">
        <span style="font-size: 1rem;">📧</span>
        <span>Se enviara correo de verificación.</span>
    </p>
</div>
            
            <button type="submit" class="btn-registro">
                <span>✨</span> Comenzar a comprar <span>→</span>
            </button>
        </form>
    </div>
</div>

<script>
(function() {
    window.registrarCliente = function(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
const codigoPais = document.getElementById('codigoPais').value;
const movilCliente = formData.get('movil');
// Combinar prefijo + número
const movilCompleto = codigoPais + movilCliente;
formData.append('movil', movilCompleto);
formData.append('codigo_pais', codigoPais);
formData.append('accion', 'registrar_cliente');
        
        fetch('includes/carrito_ajax.php', {
            method: 'POST',
            body: new URLSearchParams(formData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                cerrarModal('modalRegistro');
                mostrarNotificacion('✅ Registro exitoso', 'exito');
                                
                // ACTUALIZAR ESTADO DEL CLIENTE
                window.clienteRegistrado = true;
                
                // Actualizar menús de cliente
if (typeof window.actualizarMenuCliente === 'function') {
    const nombreCompleto = formData.get('nombre_completo');
    const emailCliente = formData.get('email');
   window.actualizarMenuCliente(nombreCompleto, emailCliente, movilCliente);
}
                
               // Procesar producto pendiente si existe
if (window.productoPendiente) {
    const productoId = window.productoPendiente.id;
    const cantidad = window.productoPendiente.cantidad;
    const esCombo = window.productoPendiente.combo || false;
    
    // Función para intentar agregar el producto o combo
    function intentarAgregarProducto(intento) {
        // Elegir la acción correcta
        const accion = esCombo ? 'agregar_combo' : 'agregar';
        const idParam = esCombo ? 'combo_id' : 'producto_id';
        
        fetch('includes/carrito_ajax.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'accion=' + accion + '&' + idParam + '=' + productoId + '&cantidad=' + cantidad
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const tipo = esCombo ? 'Combo' : 'Producto';
                mostrarNotificacion('✅ ' + tipo + ' agregado al carrito', 'exito');
                if (typeof window.actualizarContadorCarrito === 'function') {
                    window.actualizarContadorCarrito();
                }
                window.productoPendiente = null;
            } else {
                // Si es el primer intento, reintentar después de 1 segundo
                if (intento === 1) {
                    console.log('🔄 Reintentando agregar...');
                    setTimeout(function() {
                        intentarAgregarProducto(2);
                    }, 1000);
                } else {
                    const tipo = esCombo ? 'Combo' : 'Producto';
                    mostrarNotificacion('⚠️ ' + tipo + ' pendiente, agrégalo manualmente', 'warning');
                }
            }
        })
        .catch(function(error) {
            console.error('Error al agregar:', error);
            if (intento === 1) {
                setTimeout(function() {
                    intentarAgregarProducto(2);
                }, 1000);
            } else {
                mostrarNotificacion('⚠️ Error al agregar', 'error');
            }
        });
    }
    
    // Esperar 500ms para asegurar que la sesión esté lista
    setTimeout(function() {
        intentarAgregarProducto(1);
    }, 500);
    
} else {
    mostrarNotificacion('🛒 Ya puede comenzar a comprar', 'exito');
}
           } else if (data.requiere_password) {
    cerrarModal('modalRegistro');
    document.getElementById('mensajeVinculacion').innerHTML = data.mensaje;
    window.emailPendienteVinculacion = document.querySelector('#formRegistro input[name="email"]').value;
    document.getElementById('modalVerificarPasswordVinculacion').style.display = 'block';
} else {
    mostrarNotificacion('❌ ' + data.mensaje, 'error');
}
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarNotificacion('❌ Error al conectar con el servidor', 'error');
        });
    };
})();
</script>
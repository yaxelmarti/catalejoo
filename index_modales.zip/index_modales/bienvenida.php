<?php
// ============================================
// MODAL DE BIENVENIDA (diseño landing)
// Se muestra una sola vez (localStorage)
// ============================================
?>

<style>
/* ============================================ */
/* MODAL DE BIENVENIDA - DISEÑO LANDING        */
/* ============================================ */
#modalBienvenida .modal-contenido {
    max-width: 600px;
    padding: 0;
    overflow: hidden;
    border-radius: 20px;
    background: #f8fafc;
    position: relative;
}

#modalBienvenida .bienvenida-landing {
    background: #f8fafc;
    color: #1e293b;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    padding: 2rem 1.8rem;
    text-align: center;
    max-height: 85vh;
    overflow-y: auto;
}

#modalBienvenida .bienvenida-eyebrow {
    color: #64748b;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    font-size: 0.7rem;
    font-weight: 800;
    margin-bottom: 1rem;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

#modalBienvenida .bienvenida-eyebrow::before {
    content: '';
    background: var(--secondary, #764ba2);
    border-radius: 50%;
    width: 8px;
    height: 8px;
    display: inline-block;
}

#modalBienvenida .bienvenida-titulo {
    font-size: clamp(1.2rem, 3.5vw, 1.6rem);
    font-weight: 700;
    letter-spacing: -0.03em;
    line-height: 1.2;
    margin: 0 0 1rem 0;
    color: #1e293b;
    white-space: normal;
}

#modalBienvenida .bienvenida-descripcion {
    color: #475569;
    font-size: 0.9rem;
    line-height: 1.65;
    margin: 0 0 1.2rem 0;
    max-width: 480px;
    margin-left: auto;
    margin-right: auto;
}

#modalBienvenida .bienvenida-ruta {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    margin: 1.2rem 0;
    padding: 0.8rem 0;
    border-top: 1px solid rgba(30, 41, 59, 0.1);
    border-bottom: 1px solid rgba(30, 41, 59, 0.1);
    font-size: 0.6rem;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: #475569;
}

#modalBienvenida .bienvenida-ruta-linea {
    background: var(--secondary, #764ba2);
    width: 30px;
    height: 1px;
}

/* Secciones del modal */
#modalBienvenida .bienvenida-seccion {
    margin-top: 1.2rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(30, 41, 59, 0.1);
    text-align: left;
}

#modalBienvenida .bienvenida-seccion-label {
    color: #64748b;
    letter-spacing: 0.09em;
    text-transform: uppercase;
    font-size: 0.62rem;
    font-weight: 700;
    margin-bottom: 0.4rem;
}

#modalBienvenida .bienvenida-seccion-titulo {
    font-size: 0.95rem;
    font-weight: 700;
    color: #1e293b;
    margin: 0 0 0.4rem 0;
    line-height: 1.25;
    white-space: normal;
}

#modalBienvenida .bienvenida-seccion-texto {
    font-size: 0.8rem;
    color: #475569;
    line-height: 1.55;
    margin: 0;
}

/* Pasos */
#modalBienvenida .bienvenida-pasos {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    margin-top: 0.5rem;
}

#modalBienvenida .bienvenida-paso {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 0.55rem 0.75rem;
    font-size: 0.78rem;
    color: #1e293b;
}

#modalBienvenida .bienvenida-paso-num {
    color: var(--secondary, #764ba2);
    font-weight: 800;
    font-size: 0.6rem;
    letter-spacing: 0.08em;
    margin-right: 0.4rem;
}

#modalBienvenida .bienvenida-paso strong {
    font-weight: 700;
    font-size: 0.82rem;
}

#modalBienvenida .bienvenida-paso p {
    margin: 0.15rem 0 0 0;
    color: #64748b;
    font-size: 0.72rem;
    line-height: 1.4;
}

/* Pagos */
#modalBienvenida .bienvenida-seccion-pagos {
    background: #f0f4ff;
    border-radius: 10px;
    padding: 0.9rem 0.9rem 0.7rem;
    border: 1px solid #dbeafe;
}

#modalBienvenida .bienvenida-pagos-nombres {
    font-size: 0.88rem;
    font-weight: 700;
    color: var(--primary, #667eea);
    margin: 0.3rem 0 0.4rem 0;
    letter-spacing: 0.02em;
}

/* Acciones */
#modalBienvenida .bienvenida-acciones {
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
    margin-top: 1.2rem;
}

#modalBienvenida .btn-empezar {
    width: 100%;
    padding: 0.8rem;
    background: var(--primary, #667eea);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 0.92rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
    font-family: inherit;
}

#modalBienvenida .btn-empezar:hover {
    background: var(--secondary, #764ba2);
    transform: translateY(-2px);
}

#modalBienvenida .btn-comentarios {
    width: 100%;
    padding: 0.8rem;
    background: #e2e8f0;
    color: #1f2937;
    border: none;
    border-radius: 10px;
    font-size: 0.88rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    font-family: inherit;
}

#modalBienvenida .btn-comentarios:hover {
    background: #cbd5e1;
}

#modalBienvenida .bienvenida-gracias {
    text-align: center;
    margin-top: 1rem;
    font-size: 0.75rem;
    color: #64748b;
}

#modalBienvenida .close-modal {
    position: absolute;
    top: 0.8rem;
    right: 1rem;
    font-size: 1.8rem;
    cursor: pointer;
    color: #94a3b8;
    transition: color 0.2s;
    z-index: 10;
    line-height: 1;
}

#modalBienvenida .close-modal:hover {
    color: #1e293b;
}

@media (max-width: 640px) {
    #modalBienvenida .bienvenida-landing {
        padding: 1.4rem 1.1rem;
    }
    #modalBienvenida .bienvenida-ruta {
        font-size: 0.52rem;
        gap: 8px;
    }
    #modalBienvenida .bienvenida-titulo {
        font-size: 1.05rem;
    }
    #modalBienvenida .bienvenida-descripcion {
        font-size: 0.82rem;
    }
}
</style>

<div class="modal-overlay" id="modalBienvenida" style="display: none;">
    <div class="modal-contenido">
        <span class="close-modal" onclick="cerrarModalBienvenida()">&times;</span>

        <div class="bienvenida-landing">
            <div class="bienvenida-eyebrow">Tienda en Producción</div>

            <h2 class="bienvenida-titulo">
                Usted compra desde Estados Unidos y Europa. Nosotros entregamos a quienes más quieres en Cuba. "catalejoo.com" 24 horas trabajando para Ti.
            </h2>

            <p class="bienvenida-descripcion">
                Catalejoo es una tienda online para comprar productos y combos desde donde estés y que sean entregados a familiares y amistades en Cuba. Estamos esperando tu pedido inicial.
            </p>

            <div class="bienvenida-ruta">
                <span>Estados Unidos · Europa</span>
                <span class="bienvenida-ruta-linea"></span>
                <span>Familia y amistades en Cuba</span>
            </div>

            <!-- SECCIÓN: LA IDEA -->
            <div class="bienvenida-seccion">
                <div class="bienvenida-seccion-label">01 · La idea</div>
                <h3 class="bienvenida-seccion-titulo">Estar lejos no impide estar presente.</h3>
                <p class="bienvenida-seccion-texto">
                    Queremos hacer más sencillo elegir una compra en línea para las personas que más quieres. El catálogo de Catalejoo, las opciones de entrega y el total serán su mejor opción en todo el cibercomercio.
                </p>
            </div>

            <!-- SECCIÓN: CÓMO FUNCIONA -->
            <div class="bienvenida-seccion">
                <div class="bienvenida-seccion-label">02 · Una compra clara</div>
                <h3 class="bienvenida-seccion-titulo">Cada detalle, a la vista antes de confirmar.</h3>
                <div class="bienvenida-pasos">
                    <div class="bienvenida-paso">
                        <span class="bienvenida-paso-num">01</span>
                        <strong>Elegir</strong>
                        <p>Los productos publicados mostrarán sus variantes y precios en su moneda.</p>
                    </div>
                    <div class="bienvenida-paso">
                        <span class="bienvenida-paso-num">02</span>
                        <strong>Revisar</strong>
                        <p>Las opciones de pago, todo el proceso de empaquetado, transportación y entregas será informado por email antes del pago.</p>
                    </div>
                    <div class="bienvenida-paso">
                        <span class="bienvenida-paso-num">03</span>
                        <strong>Confirmar</strong>
                        <p>Solo se ofrecerán opciones de pago verificadas. Usted pagará después de que sea entregado su pedido.</p>
                    </div>
                </div>
            </div>

            <!-- SECCIÓN: PAGOS -->
            <div class="bienvenida-seccion bienvenida-seccion-pagos">
                <div class="bienvenida-seccion-label">03 · Pagos</div>
                <h3 class="bienvenida-seccion-titulo">Pagar también debe ser claro.</h3>
                <p class="bienvenida-pagos-nombres">Zelle · Bizum · PayPal</p>
                <p class="bienvenida-seccion-texto">
                    Estos métodos están entre sus opciones. Su disponibilidad dependerá de las políticas vigentes de la plataforma y de las normas aplicables. Confirmaremos únicamente las opciones verificadas.
                </p>
            </div>

            <!-- BOTONES -->
            <div class="bienvenida-acciones">
                <button class="btn-empezar" onclick="cerrarModalBienvenida()">Visitar tienda</button>
                <button class="btn-comentarios" onclick="cerrarModalBienvenida(); if (typeof abrirModalComentarios === 'function') abrirModalComentarios();">💬 Déjanos un comentario</button>
            </div>

            <p class="bienvenida-gracias">¡Gracias por estar aquí!</p>
        </div>
    </div>
</div>

<script>
function cerrarModalBienvenida() {
    var modal = document.getElementById('modalBienvenida');
    if (modal) modal.style.display = 'none';
}

// Mostrar si:
// - No se ha mostrado antes (localStorage)
// - O si la URL tiene ?ver_bienvenida=1 (para probar directamente)
var forzarModal = window.location.search.indexOf('ver_bienvenida=1') !== -1;

if (!localStorage.getItem('bienvenida_mostrada') || forzarModal) {
    setTimeout(function() {
        var modal = document.getElementById('modalBienvenida');
        if (modal) modal.style.display = 'block';
        localStorage.setItem('bienvenida_mostrada', 'true');
    }, 1000);
}
</script>
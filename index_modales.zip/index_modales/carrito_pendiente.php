<!-- /index_modales/carrito_pendiente.php -->
<!-- ======================================== -->
<!-- MODAL CARRITO PENDIENTE SIMPLIFICADO -->
<!-- ======================================== -->

<style>
#modalCarritoPendiente .alerta-email {
    background: #fed7d7;
    border-left: 4px solid #f56565;
    padding: 1rem;
    margin-bottom: 1.5rem;
    border-radius: 8px;
    color: #c53030;
    font-size: 0.9rem;
}

#modalCarritoPendiente .alerta-email a {
    color: #c53030;
    font-weight: 600;
    text-decoration: underline;
}

#modalCarritoPendiente .info-resumen {
    background: #f7fafc;
    padding: 1rem;
    border-radius: 12px;
    text-align: center;
    margin-bottom: 1.5rem;
}

#modalCarritoPendiente .info-resumen p {
    margin: 0.5rem 0;
    font-size: 1rem;
}

#modalCarritoPendiente .info-resumen .cantidad {
    font-size: 1.3rem;
    font-weight: bold;
    color: var(--primary);
}

#modalCarritoPendiente .info-resumen .total {
    font-size: 1.5rem;
    font-weight: bold;
    color: var(--primary);
}

#modalCarritoPendiente .info-resumen .tiempo {
    background: #fef5e7;
    padding: 0.5rem;
    border-radius: 20px;
    display: inline-block;
    font-weight: 600;
    color: #744210;
    margin-top: 0.5rem;
}

#modalCarritoPendiente .btn-ver-carrito {
    flex: 1;
    padding: 0.8rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

#modalCarritoPendiente .btn-continuar {
    flex: 1;
    padding: 0.8rem;
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

#modalCarritoPendiente .btn-nuevo {
    flex: 1;
    padding: 0.8rem;
    background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

#modalCarritoPendiente .btn-ver-carrito:hover,
#modalCarritoPendiente .btn-continuar:hover,
#modalCarritoPendiente .btn-nuevo:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

#modalCarritoPendiente .link-cerrar-sesion {
    text-align: center;
    margin-top: 1.5rem;
    font-size: 0.85rem;
    color: #718096;
}

#modalCarritoPendiente .link-cerrar-sesion a {
    color: var(--primary);
    text-decoration: underline;
    font-weight: 500;
}

@media (max-width: 768px) {
    #modalCarritoPendiente .modal-contenido {
        padding: 1.5rem;
    }
    
    #modalCarritoPendiente .btn-ver-carrito,
    #modalCarritoPendiente .btn-continuar,
    #modalCarritoPendiente .btn-nuevo {
        padding: 0.7rem;
        font-size: 0.85rem;
    }
}
</style>

<div class="modal-overlay" id="modalCarritoPendiente">
    <div class="modal-contenido" style="max-width: 400px;">
        <span class="close-modal" onclick="cerrarModal('modalCarritoPendiente')">&times;</span>
        
        <h2 style="text-align: center; margin-bottom: 1.5rem; font-size: 1.3rem;">🛒 Carrito pendiente</h2>
        
        <!-- Alerta de email no verificado -->
        <?php if ($cliente_id > 0 && !$email_verified): ?>
        <div class="alerta-email">
            <p style="margin: 0; display: flex; align-items: center; gap: 0.5rem;">
                <span style="font-size: 1.2rem;">⚠️</span>
                <span><strong>Email no verificado:</strong> No recibirás notificaciones.</span>
            </p>
            <p style="margin: 0.5rem 0 0 1.7rem;">
                <a href="#" onclick="reenviarVerificacionDesdeCliente()">📧 Reenviar verificación</a>
            </p>
        </div>
        <?php endif; ?>
        
        <div id="infoCarritoPendiente" class="info-resumen">
            <!-- Aquí se carga dinámicamente: cantidad, total y tiempo -->
        </div>
        
        <div style="display: flex; gap: 0.8rem; margin-top: 1rem; flex-wrap: wrap;">
            <button class="btn-ver-carrito" onclick="verCarritoPendiente()">
                🛒 Ver carrito
            </button>
            <button class="btn-continuar" onclick="continuarCompra()">
                ✅ Continuar
            </button>
            <button class="btn-nuevo" onclick="nuevaCompra()">
                🗑️ Nueva compra
            </button>
        </div>
        
        <div class="link-cerrar-sesion">
            ¿No eres tú? <a href="#" onclick="cerrarSesionDispositivo()">Cerrar sesión</a>
        </div>
    </div>
</div>

<script>
(function() {
    // Función para ver el carrito (abre el modal del carrito)
    window.verCarritoPendiente = function() {
    cerrarModal('modalCarritoPendiente');
    
    // ✅ Abrir el menú lateral del carrito (nuevo)
    if (typeof window.abrirCarritoLateral === 'function') {
        window.abrirCarritoLateral();
    } else {
        // Fallback: si no existe, abrir el modal antiguo
        if (typeof window.abrirCarrito === 'function') {
            window.abrirCarrito();
        } else {
            document.getElementById('modalCarrito').style.display = 'block';
        }
    }
};

    window.continuarCompra = function() {
        cerrarModal('modalCarritoPendiente');
        mostrarNotificacion('🛒 Continuando con tu compra', 'exito');
    };

    window.nuevaCompra = function() {
        if (!confirm('¿Cancelar carrito actual y empezar una nueva compra?')) return;
        
        fetch('includes/carrito_ajax.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'accion=nueva_compra'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                cerrarModal('modalCarritoPendiente');
                mostrarNotificacion('🆕 Nueva compra iniciada', 'exito');
                if (typeof actualizarContadorCarrito === 'function') {
                    actualizarContadorCarrito();
                }
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarNotificacion('❌ Error al cancelar carrito', 'error');
        });
    };

    window.cerrarSesionDispositivo = function() {
        if (!confirm('¿Cerrar sesión en este dispositivo? Se eliminará tu carrito actual.')) return;
        
        document.cookie = 'cliente_uuid=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
        location.reload();
    };
})();
</script>
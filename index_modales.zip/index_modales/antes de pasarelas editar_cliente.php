<?php
// Procesar token (si viene del enlace mágico)
if (isset($_GET['token'])) {
    session_start();
    require_once dirname(__DIR__) . '/conexion.php';
    
    $token = $_GET['token'];
    
    $stmt = $conn->prepare("SELECT id FROM clientes WHERE reset_token = ? AND reset_expires > NOW() AND activo = 1");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $_SESSION['cliente_id'] = $row['id'];
        // Limpiar token
        $stmt = $conn->prepare("UPDATE clientes SET reset_token = NULL, reset_expires = NULL WHERE id = ?");
        $stmt->bind_param("i", $row['id']);
        $stmt->execute();
    }
    
    // Redirigir a la tienda con parámetro para abrir modal
header('Location: /?abrir_editar=1');
exit;
}
?>
<!-- /index_modales/editar_cliente.php -->
<!-- ======================================== -->
<!-- MODAL EDITAR DATOS DEL CLIENTE -->
<!-- ======================================== -->

<style>
#modalEditarCliente .campo-doble {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

#modalEditarCliente .campo-doble input {
    flex: 1;
}

#modalEditarCliente input {
    width: 100%;
    padding: 0.8rem;
    margin-bottom: 1rem;
    border: 2px solid #e2e8f0;
    border-radius: var(--radius-md);
    font-size: 1rem;
    transition: all 0.3s;
}

#modalEditarCliente input:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

#modalEditarCliente h3 {
    margin: 1.5rem 0 0.5rem;
    color: #2d3748;
    font-size: 1.1rem;
}

#modalEditarCliente .subtitulo {
    font-size: 0.9rem;
    color: #718096;
    margin-bottom: 1rem;
}

#modalEditarCliente .btn-actualizar {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    transition: all 0.3s;
}

#modalEditarCliente .btn-actualizar:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(72, 187, 120, 0.3);
}

#modalEditarCliente .separador {
    border-top: 1px solid #e2e8f0;
    margin: 1.5rem 0;
}

#modalEditarCliente .password-ayuda {
    font-size: 0.8rem;
    color: #718096;
    margin-top: -0.5rem;
    margin-bottom: 1rem;
}
</style>

<div class="modal-overlay" id="modalEditarCliente">
    <div class="modal-contenido" style="max-width: 500px;">
        <span class="close-modal" onclick="cerrarModal('modalEditarCliente')">&times;</span>
        
        <h2 style="margin-bottom: 1.5rem;">✏️ Editar mis datos</h2>
        
        <form id="formEditarCliente" onsubmit="actualizarDatosCliente(event)">
            <input type="text" name="edit_nombre" id="edit_nombre" placeholder="Nombre completo" required>
            
            <input type="email" name="edit_email" id="edit_email" placeholder="Email" required>
            
      <input type="tel" name="edit_movil" id="edit_movil" placeholder="Móvil" required>
                       
            <button type="submit" class="btn-actualizar">
                Actualizar datos
            </button>
        </form>
    </div>
</div>

<script>
(function() {
    window.cargarDatosCliente = function() {
        fetch('includes/cliente_ajax.php?accion=obtener_datos')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('edit_nombre').value = data.nombre || '';
                document.getElementById('edit_email').value = data.email || '';
                document.getElementById('edit_movil').value = data.movil || '';
                
                document.getElementById('modalEditarCliente').style.display = 'block';
            }
        });
    };

    window.actualizarDatosCliente = function(event) {
        event.preventDefault();
        
        const nombre = document.getElementById('edit_nombre').value;
        const email = document.getElementById('edit_email').value;
        const movil = document.getElementById('edit_movil').value;
        
        const datos = new URLSearchParams();
        datos.append('accion', 'actualizar_datos');
        datos.append('edit_nombre', nombre);
        datos.append('edit_email', email);
        datos.append('edit_movil', movil);
        
        fetch('includes/cliente_ajax.php', {
            method: 'POST',
            body: datos
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                cerrarModal('modalEditarCliente');
                mostrarNotificacion('✅ Datos actualizados correctamente', 'exito');
            } else {
                mostrarNotificacion('❌ ' + data.mensaje, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            mostrarNotificacion('❌ Error de conexión con el servidor', 'error');
        });
    };
})();
</script>
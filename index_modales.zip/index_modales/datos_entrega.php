<?php
// Fallbacks de moneda (el header normalmente ya las define)
if (!isset($moneda_simbolo)) $moneda_simbolo = '$';
if (!isset($moneda_codigo)) $moneda_codigo = 'USD';

// Cargar última dirección del cliente si existe
$ultima_direccion = null;
$ultima_provincia_id = null;
if ($cliente_id > 0) {
    $stmt = $conn->prepare("SELECT d.* 
                            FROM direcciones_envio d 
                            JOIN pedidos p ON d.pedido_id = p.id 
                            WHERE p.cliente_id = ? 
                            ORDER BY p.fecha_pedido DESC LIMIT 1");
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $ultima_direccion = $result->fetch_assoc();
       // Obtener provincia desde el nombre guardado en direcciones_envio
if (!empty($ultima_direccion['provincia'])) {
    $stmt_prov = $conn->prepare("SELECT id FROM provincias WHERE nombre = ?");
    $stmt_prov->bind_param("s", $ultima_direccion['provincia']);
    $stmt_prov->execute();
    $res_prov = $stmt_prov->get_result();
    if ($res_prov->num_rows > 0) {
        $ultima_provincia_id = $res_prov->fetch_assoc()['id'];
    }
}
    }
}
?>
<!-- /index_modales/datos_entrega.php -->
<div class="modal-overlay" id="modalDatosEntrega">
    <div class="modal-contenido">
        <span class="close-modal" onclick="cerrarModal('modalDatosEntrega')">&times;</span>
        <p style="margin-bottom: 1rem; font-size: 0.85rem; color: #000080; font-weight: bold;">PERSONA QUE RECIBE LA COMPRA</p>
        
        <form id="formDatosEntrega" onsubmit="guardarDatosEntrega(event)">
            <div class="form-grid">
                <div class="form-group">
                    <label>Nombre de la persona que recibe *</label>
                    <input type="text" name="nombre" id="entrega_nombre" required placeholder="Nombre y apellidos">
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
                    
   <input type="hidden" name="documento" id="entrega_documento" value="000000">
                    
    <div class="form-group">
        <label>Teléfono a contactar *</label>
        <input type="tel" name="telefono" id="entrega_telefono" required placeholder="Ej: 55551234">
    </div>
</div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
    <div class="form-group">
        <label>Provincia *</label>
        <select name="provincia" id="entrega_provincia" required>
            <option value="" disabled selected>Seleccione provincia</option>
            <?php
            $provincias = $conn->query("SELECT id, nombre FROM provincias WHERE activo = 1 ORDER BY nombre");
            while($prov = $provincias->fetch_assoc()):
                $selected = ($ultima_provincia_id == $prov['id']) ? 'selected' : '';
            ?>
                <option value="<?php echo $prov['id']; ?>" <?php echo $selected; ?>><?php echo htmlspecialchars($prov['nombre']); ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Municipio *</label>
        <select name="municipio" id="entrega_municipio" required>
            <option value="">Seleccione primero provincia</option>
        </select>
    </div>
</div>
                <div class="form-group full-width">
                    <label>Dirección *</label>
                    <input type="text" name="direccion" id="entrega_direccion" required placeholder="Calle, número, reparto">
                </div>
                <div class="form-group full-width">
                    <label>Email (opcional)</label>
                    <input type="email" name="email" id="entrega_email" placeholder="correo@ejemplo.com">
                </div>
            </div>
            <div class="form-group full-width">
    <label>Instrucciones de la direccion(opcional)</label>
    <textarea name="instrucciones" id="entrega_instrucciones" rows="2" placeholder="Ej: Entregar en piso 3, timbre izquierdo..."></textarea>
</div>
            
             <div id="resumenTotal" class="resumen-total" style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
    <div style="color: #3b82f6; font-weight: bold;">Carrito: <?php echo htmlspecialchars($moneda_simbolo); ?><span id="modal_subtotal">0.00</span> <?php echo htmlspecialchars($moneda_codigo); ?></div>
    <div id="costoEnvioInfo" style="display: none; color: #10b981; font-weight: bold;">Envío: <?php echo htmlspecialchars($moneda_simbolo); ?><span id="modal_envio">0.00</span> <?php echo htmlspecialchars($moneda_codigo); ?></div>
    <div style="font-weight: bold;">Total: <?php echo htmlspecialchars($moneda_simbolo); ?><span id="modal_total">0.00</span> <?php echo htmlspecialchars($moneda_codigo); ?></div>
</div>
            
            <button type="submit" class="btn-enviar">✅ Continuar al pago</button>
        </form>
    </div>
</div>

<style>
#modalDatosEntrega .modal-contenido {
    max-width: 550px;
    padding: 1rem;
}
#modalDatosEntrega .form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.5rem;
}
#modalDatosEntrega .form-group {
    margin-bottom: 0;
}
#modalDatosEntrega .form-group.full-width {
    grid-column: span 2;
}
#modalDatosEntrega .form-group input,
#modalDatosEntrega .form-group select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #cbd5e0;
    border-radius: 8px;
    font-size: 0.85rem;
}
#modalDatosEntrega .form-group label {
    font-size: 0.7rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.1rem;
    display: block;
}
#modalDatosEntrega .resumen-total {
    background: #f7fafc;
    padding: 0.5rem;
    border-radius: 8px;
    text-align: center;
    font-size: 0.9rem;
    margin: 0.5rem 0;
}
#modalDatosEntrega .costo-envio-info {
    font-size: 0.8rem;
    color: #3b82f6;
    margin-top: 0.2rem;
}
#modalDatosEntrega .btn-enviar {
    width: 100%;
    padding: 0.7rem;
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    margin-top: 0.5rem;
}
    #modalDatosEntrega .form-group textarea {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #cbd5e0;
    border-radius: 8px;
    font-size: 0.85rem;
    font-family: inherit;
    resize: vertical;
}
/* Responsive móvil */
@media (max-width: 768px) {
    #modalDatosEntrega .modal-contenido {
        width: 95% !important;
        max-width: 95% !important;
        max-height: 90vh !important;
        overflow-y: auto !important;
        padding: 0.8rem !important;
        border-radius: 16px !important;
        top: 55% !important;
        transform: translate(-50%, -50%) !important;
    }
    #modalDatosEntrega .form-grid {
        grid-template-columns: 1fr;
        gap: 0.3rem;
    }
    #modalDatosEntrega .form-group.full-width {
        grid-column: span 1;
    }
    #modalDatosEntrega .form-group input,
    #modalDatosEntrega .form-group select {
        font-size: 15px !important;
        padding: 0.7rem 0.5rem !important;
    }
    #modalDatosEntrega .form-group label {
        font-size: 0.7rem;
    }
    #modalDatosEntrega .btn-enviar {
        padding: 0.7rem !important;
        font-size: 1rem !important;
        margin-top: 0.8rem !important;
    }
    #modalDatosEntrega .resumen-total {
        padding: 0.5rem !important;
        font-size: 0.85rem !important;
    }
    #modalDatosEntrega h3 {
        font-size: 1rem !important;
    }
    /* Mejorar apariencia de selects en móviles */
    #modalDatosEntrega select {
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        background-color: white;
        background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%234a5568" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>');
        background-repeat: no-repeat;
        background-position: right 0.7rem center;
        background-size: 1rem;
        padding-right: 2rem !important;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        font-size: 12px !important;
        -webkit-tap-highlight-color: transparent;
    }
    #modalDatosEntrega select:focus {
        outline: none;
        box-shadow: none;
        background-color: #ffffff;
    }
    #modalDatosEntrega .form-group textarea {
    font-size: 16px !important;
    padding: 0.7rem 0.5rem !important;
}
    #modalDatosEntrega .form-group:has(textarea) {
    margin-bottom: 0 !important;
}
  #modalDatosEntrega textarea {
    margin-bottom: 0 !important;
}
#modalDatosEntrega input[type="email"] {
    margin-top: -0.5rem !important;
}
}
</style>

<script>
// Cargar municipios según provincia
function cargarMunicipios(provinciaId, municipioSeleccionado = null) {
    const municipioSelect = document.getElementById('entrega_municipio');
    if (!provinciaId) {
        municipioSelect.innerHTML = '<option value="">Seleccione primero provincia</option>';
        document.getElementById('costoEnvioInfo').style.display = 'none';
        return;
    }
    const proveedorId = <?php echo isset($_SESSION['carrito_proveedor_id']) ? intval($_SESSION['carrito_proveedor_id']) : 0; ?>;
fetch('includes/obtener_municipios_ajax.php?provincia_id=' + provinciaId + '&proveedor_id=' + proveedorId)
        .then(response => response.json())
        .then(data => {
            municipioSelect.innerHTML = '<option value="" disabled selected>Seleccione municipio</option>';
            data.forEach(mun => {
                const option = document.createElement('option');
                option.value = mun.municipio;
                option.textContent = mun.municipio;
                option.setAttribute('data-costo', mun.costo);
                municipioSelect.appendChild(option);
            });
            if (municipioSeleccionado) {
                municipioSelect.value = municipioSeleccionado;
            }
            actualizarTotalConEnvio();
        })
        .catch(error => {
            console.error('Error al cargar municipios:', error);
            municipioSelect.innerHTML = '<option value="">Error al cargar municipios</option>';
        });
}

// Actualizar total según municipio seleccionado
function actualizarTotalConEnvio() {
    const select = document.getElementById('entrega_municipio');
    const costoEnvioInfo = document.getElementById('costoEnvioInfo');
    const subtotal = parseFloat(document.getElementById('modal_subtotal').textContent || 0);
    if (select.value && select.selectedIndex > 0) {
        const costoEnvio = parseFloat(select.options[select.selectedIndex].dataset.costo || 0);
        const total = subtotal + costoEnvio;
        document.getElementById('modal_envio').textContent = costoEnvio.toFixed(2);
        document.getElementById('modal_total').textContent = total.toFixed(2);
        costoEnvioInfo.style.display = 'block';
    } else {
        document.getElementById('modal_total').textContent = subtotal.toFixed(2);
        costoEnvioInfo.style.display = 'none';
    }
}

// Guardar datos y enviar a pagar.php
function guardarDatosEntrega(event) {
    event.preventDefault();
    const provinciaSelect = document.getElementById('entrega_provincia');
    const municipioSelect = document.getElementById('entrega_municipio');
    const provinciaNombre = provinciaSelect.options[provinciaSelect.selectedIndex]?.text || '';
    const costoEnvio = municipioSelect.selectedIndex > 0 ? parseFloat(municipioSelect.options[municipioSelect.selectedIndex].dataset.costo || 0) : 0;
    const subtotal = parseFloat(document.getElementById('modal_subtotal').textContent || 0);
    const total = subtotal + costoEnvio;
    const datos = {
        nombre: document.getElementById('entrega_nombre').value,
        documento: document.getElementById('entrega_documento')?.value || '000000',
        telefono: document.getElementById('entrega_telefono').value,
        direccion: document.getElementById('entrega_direccion').value,
        municipio: municipioSelect.value,
        provincia: provinciaNombre,
        email: document.getElementById('entrega_email').value,
        instrucciones: document.getElementById('entrega_instrucciones').value 
    };
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/checkout/pagar.php';
    for (const [key, value] of Object.entries(datos)) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = key;
        input.value = value;
        form.appendChild(input);
    }
    const inputCosto = document.createElement('input');
    inputCosto.type = 'hidden';
    inputCosto.name = 'costo_envio';
    inputCosto.value = costoEnvio;
    form.appendChild(inputCosto);
    const inputTotal = document.createElement('input');
    inputTotal.type = 'hidden';
    inputTotal.name = 'total_final';
    inputTotal.value = total;
    form.appendChild(inputTotal);
    document.body.appendChild(form);
    form.submit();
}

// Cargar última dirección al abrir el modal
function cargarUltimaDireccion() {
    <?php if ($ultima_direccion): ?>
        const campos = {
            nombre: '<?php echo addslashes($ultima_direccion['nombre_completo']); ?>',
            telefono: '<?php echo addslashes($ultima_direccion['telefono']); ?>',
            direccion: '<?php echo addslashes($ultima_direccion['direccion']); ?>',
            email: '<?php echo addslashes($ultima_direccion['email'] ?? ''); ?>',
            municipio: '<?php echo addslashes($ultima_direccion['municipio']); ?>',
            instrucciones: '<?php echo addslashes($ultima_direccion['instrucciones'] ?? ''); ?>'  // <--- NUEVO
        };
        if (document.getElementById('entrega_nombre')) document.getElementById('entrega_nombre').value = campos.nombre;
        if (document.getElementById('entrega_telefono')) document.getElementById('entrega_telefono').value = campos.telefono;
        if (document.getElementById('entrega_direccion')) document.getElementById('entrega_direccion').value = campos.direccion;
        if (document.getElementById('entrega_email')) document.getElementById('entrega_email').value = campos.email;
        if (document.getElementById('entrega_instrucciones')) document.getElementById('entrega_instrucciones').value = campos.instrucciones;  // <--- NUEVO
        const provinciaSelect = document.getElementById('entrega_provincia');
        if (provinciaSelect && <?php echo $ultima_provincia_id ?: 'null'; ?>) {
            provinciaSelect.value = <?php echo $ultima_provincia_id; ?>;
            cargarMunicipios(provinciaSelect.value, campos.municipio);
        }
    <?php endif; ?>
}

// Eventos
document.getElementById('entrega_provincia').addEventListener('change', function() {
    cargarMunicipios(this.value);
});
document.getElementById('entrega_municipio').addEventListener('change', function() {
    actualizarTotalConEnvio();
});

// Al abrir el modal, cargar la última dirección si existe
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('modalDatosEntrega');
    if (modal) {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.attributeName === 'style' && modal.style.display === 'block') {
                    cargarUltimaDireccion();
                }
            });
        });
        observer.observe(modal, { attributes: true });
    }
});
</script>
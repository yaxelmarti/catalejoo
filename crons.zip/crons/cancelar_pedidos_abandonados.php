<?php
// ============================================
// CANCELAR PEDIDOS ABANDONADOS
// ============================================
// Este archivo se ejecuta desde el cron job
// Cancela pedidos de pasarelas API sin pagar tras 48h
// Devuelve stock y marca el carrito como cancelado_no_pagado
// ============================================

// ===== CONFIGURACIÓN DE ENTORNO =====
ini_set('display_errors', 0);
ini_set('log_errors', 1);
set_time_limit(30);
header('Content-Type: text/plain; charset=utf-8');

// ===== SEGURIDAD: TOKEN =====
$token_valido = 'catalejoo_7f3a9b2c8d1e4f6a5b7c9d2e4f6a8b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a';
$token_recibido = $_GET['token'] ?? '';

if (php_sapi_name() !== 'cli' && $token_recibido !== $token_valido) {
    http_response_code(403);
    exit('Acceso denegado');
}

// ===== EVITAR EJECUCIÓN SIMULTÁNEA =====
$archivo_lock = __DIR__ . '/.cancelar_lock';
if (file_exists($archivo_lock) && (time() - filemtime($archivo_lock)) < 60) {
    exit('Ya se está ejecutando');
}
if (file_put_contents($archivo_lock, time()) === false) {
    error_log('[cancelar_pedidos] No se pudo crear el lock');
    exit('No se pudo crear el lock');
}

// ===== REGISTRO DE ERRORES DEL CRON =====
// Solo se registra cuando el cron NO puede verificar los pedidos a cancelar.
// NO se registran fallos de negocio (pedido concreto que falla → rollback).
function registrarErrorCron($contexto, $mensaje) {
    $dir = dirname(__DIR__) . '/errores/cron';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $archivo = $dir . '/cancelar_' . $contexto . '_' . date('Y-m-d') . '.txt';
    $bloque  = "============================================\n";
    $bloque .= "ERROR EN CANCELAR PEDIDOS: {$contexto}\n";
    $bloque .= "Fecha: " . date('Y-m-d H:i:s') . "\n";
    $bloque .= "============================================\n\n";
    $bloque .= $mensaje . "\n\n";
    $bloque .= "--------------------------------------------\n\n";
    @file_put_contents($archivo, $bloque, FILE_APPEND | LOCK_EX);
}

// Registra un fatal como error del cron (defensa en profundidad).
// Se registra ANTES de cualquier require_once que pueda fallar.
$GLOBALS['cancelar_contexto_actual'] = 'desconocida';
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_COMPILE_ERROR, E_CORE_ERROR], true)) {
        $contexto = $GLOBALS['cancelar_contexto_actual'] ?? 'desconocida';
        $msg  = "FATAL: {$err['message']}\n";
        $msg .= "Archivo: {$err['file']}:{$err['line']}";
        registrarErrorCron($contexto, $msg);
    }
});

// ===== CONEXIÓN Y ARCHIVOS =====
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cola_correos.php';

echo "============================================\n";
echo "CANCELAR PEDIDOS ABANDONADOS\n";
echo "Fecha: " . date('Y-m-d H:i:s') . "\n";
echo "============================================\n\n";

// ===== 1. OBTENER PASARELAS API ACTIVAS =====
// Lee del catálogo escalable (pasarelas) cruzado con activaciones (configuracion)
// Incluye pasarelas activadas por CUALQUIER proveedor (no solo la global)
$stmt = $conn->prepare("
    SELECT DISTINCT p.slug AS pasarela
    FROM pasarelas p
    INNER JOIN configuracion c 
        ON c.clave = CONCAT(p.slug, '_activo')
        AND c.grupo = 'pagos'
        AND c.valor = 1
    WHERE p.activo = 1
      AND p.tipo = 'api'
    ORDER BY p.orden ASC
");

if (!$stmt) {
    $msg = "Error al preparar consulta de pasarelas: " . $conn->error;
    echo "  ⚠️ $msg\n";
    error_log("[cancelar_pedidos] $msg");
    registrarErrorCron('pasarelas', $msg);
    @unlink($archivo_lock);
    $conn->close();
    exit;
}

$stmt->execute();
$result = $stmt->get_result();

$pasarelas_api = [];
while ($row = $result->fetch_assoc()) {
    $pasarelas_api[] = $row['pasarela'];
}
$stmt->close();

if (empty($pasarelas_api)) {
    echo "No hay pasarelas API configuradas.\n";
    @unlink($archivo_lock);
    $conn->close();
    exit;
}

echo "Pasarelas API: " . implode(', ', $pasarelas_api) . "\n\n";

// ===== 2. BUSCAR PEDIDOS A CANCELAR =====
// Criterios:
// - tipo_pago IN (pasarelas API activas)   → solo pasarelas online
// - estado_pago IN ('pendiente_pago', 'pendiente_parcial')  → nunca pagó nada
// - monto_pagado = 0                       → si ya pagó algo, no es abandono
// - estado_actual NO cancelado/entregado
// - fecha_pedido > 48h atrás
$placeholders = implode(',', array_fill(0, count($pasarelas_api), '?'));
$tipos = str_repeat('s', count($pasarelas_api));

$sql = "
    SELECT id, codigo, carrito_id, cliente_id, tipo_pago, total, fecha_pedido
    FROM pedidos 
    WHERE estado_pago IN ('pendiente', 'pendiente_parcial')
    AND monto_pagado = 0
    AND estado_actual NOT IN ('cancelado', 'entregado')
    AND tipo_pago IN ($placeholders)
    AND fecha_pedido < DATE_SUB(NOW(), INTERVAL 48 HOUR)
    ORDER BY id ASC
    LIMIT 100
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    $msg = "Error al preparar consulta de pedidos: " . $conn->error;
    echo "  ⚠️ $msg\n";
    error_log("[cancelar_pedidos] $msg");
    registrarErrorCron('pedidos', $msg);
    @unlink($archivo_lock);
    $conn->close();
    exit;
}

$stmt->bind_param($tipos, ...$pasarelas_api);

if (!$stmt->execute()) {
    $msg = "Error al ejecutar consulta de pedidos: " . $stmt->error;
    echo "  ⚠️ $msg\n";
    error_log("[cancelar_pedidos] $msg");
    registrarErrorCron('pedidos', $msg);
    $stmt->close();
    @unlink($archivo_lock);
    $conn->close();
    exit;
}

$pedidos = $stmt->get_result();

$pedidos_a_cancelar = [];
while ($p = $pedidos->fetch_assoc()) {
    $pedidos_a_cancelar[] = $p;
}
$stmt->close();

if (empty($pedidos_a_cancelar)) {
    echo "No hay pedidos para cancelar.\n";
    @unlink($archivo_lock);
    $conn->close();
    exit;
}

echo "Pedidos a cancelar: " . count($pedidos_a_cancelar) . "\n\n";

$cancelados = 0;
$errores = 0;
$inicio_ejecucion = time();
$tiempo_max_segundos = 25;

// ===== 3. PROCESAR CADA PEDIDO =====
foreach ($pedidos_a_cancelar as $pedido) {
    $pedido_id = intval($pedido['id']);
    $carrito_id = intval($pedido['carrito_id']);
    
    // Protección de tiempo
    if ((time() - $inicio_ejecucion) >= $tiempo_max_segundos) {
        echo "⏱️ Tiempo máximo alcanzado, quedan pedidos para el próximo cron.\n";
        break;
    }
    
    echo "Procesando pedido #{$pedido_id} ({$pedido['codigo']})...\n";
    
    $conn->begin_transaction();
    
    try {
        // ===== 3.1 DEVOLVER STOCK DE PRODUCTOS =====
        // producto_id > 0: excluye combos (que van con producto_id = 0 y combo_id > 0)
        $stmt_prod = $conn->prepare("
            SELECT producto_id, cantidad 
            FROM pedido_detalles 
            WHERE pedido_id = ? AND producto_id > 0
        ");
        $stmt_prod->bind_param("i", $pedido_id);
        $stmt_prod->execute();
        $productos = $stmt_prod->get_result();
        
        $productos_lista = [];
        while ($row = $productos->fetch_assoc()) {
            $productos_lista[] = $row;
        }
        $stmt_prod->close();
        
        foreach ($productos_lista as $prod) {
            $stmt_upd = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
            $stmt_upd->bind_param("ii", $prod['cantidad'], $prod['producto_id']);
            $stmt_upd->execute();
            $stmt_upd->close();
        }
        
        echo "  - Stock devuelto: " . count($productos_lista) . " productos\n";
        
        // ===== 3.2 DEVOLVER STOCK DE COMBOS =====
        $stmt_combos = $conn->prepare("
            SELECT combo_id, cantidad 
            FROM pedido_detalles 
            WHERE pedido_id = ? AND combo_id IS NOT NULL AND combo_id > 0
        ");
        $stmt_combos->bind_param("i", $pedido_id);
        $stmt_combos->execute();
        $combos = $stmt_combos->get_result();
        
        $combos_lista = [];
        while ($row = $combos->fetch_assoc()) {
            $combos_lista[] = $row;
        }
        $stmt_combos->close();
        
        foreach ($combos_lista as $combo) {
            // Devolver stock del combo
            $stmt_upd_combo = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
            $stmt_upd_combo->bind_param("ii", $combo['cantidad'], $combo['combo_id']);
            $stmt_upd_combo->execute();
            $stmt_upd_combo->close();
            
            // Devolver stock de los productos del combo
            $stmt_prod_combo = $conn->prepare("
                SELECT producto_id, cantidad 
                FROM combo_productos 
                WHERE combo_id = ?
            ");
            $stmt_prod_combo->bind_param("i", $combo['combo_id']);
            $stmt_prod_combo->execute();
            $productos_combo = $stmt_prod_combo->get_result();
            
            $productos_combo_lista = [];
            while ($row = $productos_combo->fetch_assoc()) {
                $productos_combo_lista[] = $row;
            }
            $stmt_prod_combo->close();
            
            foreach ($productos_combo_lista as $pc) {
                $cantidad_devolver = $pc['cantidad'] * $combo['cantidad'];
                $stmt_upd_p = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                $stmt_upd_p->bind_param("ii", $cantidad_devolver, $pc['producto_id']);
                $stmt_upd_p->execute();
                $stmt_upd_p->close();
            }
        }
        
        echo "  - Stock devuelto: " . count($combos_lista) . " combos\n";
        
        // ===== 3.3 CANCELAR PEDIDO =====
        $stmt_cancel = $conn->prepare("
            UPDATE pedidos 
            SET estado_actual = 'cancelado', estado_pago = 'cancelado'
            WHERE id = ?
        ");
        $stmt_cancel->bind_param("i", $pedido_id);
        $stmt_cancel->execute();
        $stmt_cancel->close();
        
        // ===== 3.4 REGISTRAR EN PEDIDO_ESTADOS =====
        $obs = "Pedido cancelado automáticamente por falta de pago (48h).";
        $stmt_estado = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'cancelado', 1, ?)
        ");
        $stmt_estado->bind_param("is", $pedido_id, $obs);
        $stmt_estado->execute();
        $stmt_estado->close();
        
        // ===== 3.5 CAMBIAR ESTADO DEL CARRITO =====
        if ($carrito_id > 0) {
            $stmt_carrito = $conn->prepare("
                UPDATE carritos 
                SET estado = 'cancelado_no_pagado', 
                    fecha_cierre = NOW(),
                    motivo_cancelacion = 'cancelado_por_falta_pago'
                WHERE id = ?
            ");
            $stmt_carrito->bind_param("i", $carrito_id);
            $stmt_carrito->execute();
            $stmt_carrito->close();
        }
        
        // ===== 3.6 ENCOLAR CORREO AL CLIENTE =====
        $stmt_cliente = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
        $stmt_cliente->bind_param("i", $pedido['cliente_id']);
        $stmt_cliente->execute();
        $cliente = $stmt_cliente->get_result()->fetch_assoc();
        $stmt_cliente->close();
        
        if ($cliente && !empty($cliente['email'])) {
            encolarCorreo(
                $conn,
                $cliente['email'],
                'Pedido ' . $pedido['codigo'] . ' cancelado',
                'cancelado',
                null,
                $pedido_id
            );
        }
        
        $conn->commit();
        $cancelados++;
        
        echo "  ✅ Pedido #{$pedido_id} cancelado correctamente\n\n";
        
    } catch (Throwable $e) {
        $conn->rollback();
        $errores++;
        error_log("[cancelar_pedidos] Rollback pedido #{$pedido_id}: " . $e->getMessage());
        echo "  ❌ Error: " . $e->getMessage() . "\n\n";
    }
}

// ===== LIMPIAR LOCK =====
@unlink($archivo_lock);

echo "============================================\n";
echo "Cancelados: $cancelados\n";
echo "Errores:    $errores\n";
echo "Duración:   " . (time() - $inicio_ejecucion) . "s\n";
echo "============================================\n";

$conn->close();
?>
<?php
// ============================================
// CRON: Eliminar carritos vacíos con más de 24 horas
// Ubicación: /crons/eliminar_carritos_vacios.php
// Frecuencia recomendada: cada 1 hora
// Solo ejecutable desde CLI (cron de Hostinger)
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================
// BLOQUEO: solo CLI o localhost
// ============================================
$es_cli = (php_sapi_name() === 'cli');
$es_local = isset($_SERVER['REMOTE_ADDR']) && in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1'], true);

if (!$es_cli && !$es_local) {
    http_response_code(403);
    exit('Acceso no permitido');
}

// ============================================
// INCLUDES
// ============================================
require_once __DIR__ . '/../conexion.php';

// ============================================
// CONFIGURACIÓN
// ============================================
$horas_minimas = 24; // Carritos con más de X horas sin productos
$lote_maximo = 500;  // Máximo de carritos a eliminar por ejecución

$inicio = microtime(true);
$eliminados = 0;

try {
    // ============================================
    // 1) SELECCIONAR CARRITOS VACÍOS
    // ============================================
    $sql_select = "SELECT ca.id
                   FROM carritos ca
                   WHERE ca.estado = 'pendiente'
                     AND ca.fecha_inicio < DATE_SUB(NOW(), INTERVAL ? HOUR)
                     AND NOT EXISTS (SELECT 1 FROM carrito_productos cp WHERE cp.carrito_id = ca.id)
                     AND NOT EXISTS (SELECT 1 FROM carrito_combos cc WHERE cc.carrito_id = ca.id)
                   ORDER BY ca.fecha_inicio ASC
                   LIMIT ?";

    $stmt = $conn->prepare($sql_select);
    if (!$stmt) {
        throw new Exception("prepare select: " . $conn->error);
    }
    $stmt->bind_param("ii", $horas_minimas, $lote_maximo);
    $stmt->execute();
    $res = $stmt->get_result();

    $ids = [];
    while ($row = $res->fetch_assoc()) {
        $ids[] = intval($row['id']);
    }
    $stmt->close();

    if (empty($ids)) {
        error_log("[cron_carritos_vacios] Sin carritos vacíos para eliminar (>{$horas_minimas}h).");
        echo "Sin carritos vacíos con más de {$horas_minimas}h\n";
        exit(0);
    }

    error_log("[cron_carritos_vacios] Encontrados " . count($ids) . " carritos vacíos para eliminar.");

    // ============================================
    // 2) ELIMINAR EN TRANSACCIÓN
    // ============================================
    $conn->begin_transaction();
    try {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $tipos = str_repeat('i', count($ids));

        // 2.1) Borrar historial de cancelaciones (si existe)
        $stmt = $conn->prepare("DELETE FROM historial_carritos_cancelados_productos 
                                WHERE cancelacion_id IN (
                                    SELECT id FROM historial_carritos_cancelados 
                                    WHERE carrito_id IN ($placeholders)
                                )");
        if ($stmt) {
            $stmt->bind_param($tipos, ...$ids);
            $stmt->execute();
            $stmt->close();
        }

        $stmt = $conn->prepare("DELETE FROM historial_carritos_cancelados WHERE carrito_id IN ($placeholders)");
        if ($stmt) {
            $stmt->bind_param($tipos, ...$ids);
            $stmt->execute();
            $stmt->close();
        }

        // 2.2) Borrar los carritos
        $stmt = $conn->prepare("DELETE FROM carritos WHERE id IN ($placeholders)");
        if (!$stmt) {
            throw new Exception("prepare delete carritos: " . $conn->error);
        }
        $stmt->bind_param($tipos, ...$ids);
        $stmt->execute();
        $eliminados = $stmt->affected_rows;
        $stmt->close();

        $conn->commit();

        // Log de auditoría
        $ids_str = implode(',', array_slice($ids, 0, 20));
        if (count($ids) > 20) {
            $ids_str .= '... (y ' . (count($ids) - 20) . ' más)';
        }
        error_log("[cron_carritos_vacios] Eliminados $eliminados carritos. IDs: $ids_str");

    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }

    $duracion = round((microtime(true) - $inicio) * 1000, 2);
    echo "Eliminados $eliminados carritos vacíos en {$duracion}ms\n";

} catch (Throwable $e) {
    error_log("[cron_carritos_vacios] ERROR: " . $e->getMessage() . " | Línea: " . $e->getLine());
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}

if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
}

exit(0);
<?php
// ============================================
// ENVIAR COLA DE CORREOS (CRON JOB)
// ============================================
// Envía los correos pendientes de la tabla cola_correos.
// Robusto: no muere si MySQL o SMTP fallan.
// Registra errores del cron en /errores/cron/.
// ============================================

// ===== CONFIGURACIÓN DE ENTORNO =====
ini_set('display_errors', 0);
ini_set('log_errors', 1);
set_time_limit(30);
header('Content-Type: text/plain; charset=utf-8');

// ===== SEGURIDAD: TOKEN =====
$token_valido = 'catalejoo_7f3a9b2c8d1e4f6a5b7c9d2e4f6a8b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a';
$token_recibido = $_GET['token'] ?? '';

// Permitir solo CLI o token válido
if (php_sapi_name() !== 'cli' && $token_recibido !== $token_valido) {
    http_response_code(403);
    exit('Acceso denegado');
}

// ===== EVITAR EJECUCIÓN SIMULTÁNEA =====
$archivo_lock = __DIR__ . '/.cron_lock';
if (file_exists($archivo_lock) && (time() - filemtime($archivo_lock)) < 60) {
    exit('Ya se está ejecutando');
}
if (file_put_contents($archivo_lock, time()) === false) {
    error_log('[enviar_cola_correos] No se pudo crear el lock');
    exit('No se pudo crear el lock');
}

// ===== REGISTRO DE ERRORES DEL CRON =====
function registrarErrorCronEnvio($contexto, $mensaje) {
    $dir = dirname(__DIR__) . '/errores/cron';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $archivo = $dir . '/envio_correos_' . $contexto . '_' . date('Y-m-d') . '.txt';
    $bloque  = "============================================\n";
    $bloque .= "ERROR EN ENVÍO DE CORREOS: {$contexto}\n";
    $bloque .= "Fecha: " . date('Y-m-d H:i:s') . "\n";
    $bloque .= "============================================\n\n";
    $bloque .= $mensaje . "\n\n";
    $bloque .= "--------------------------------------------\n\n";
    @file_put_contents($archivo, $bloque, FILE_APPEND | LOCK_EX);
}

// Registra fatales no capturables (paridad con otros crons)
$GLOBALS['envio_contexto_actual'] = 'general';
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_COMPILE_ERROR, E_CORE_ERROR], true)) {
        $contexto = $GLOBALS['envio_contexto_actual'] ?? 'general';
        $msg  = "FATAL: {$err['message']}\n";
        $msg .= "Archivo: {$err['file']}:{$err['line']}";
        registrarErrorCronEnvio($contexto, $msg);
    }
});

// ===== CONEXIÓN Y ARCHIVOS =====
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cola_correos.php';
require_once dirname(__DIR__) . '/includes/email_functions.php';
require_once dirname(__DIR__) . '/includes/email_templates.php';

// ===== OBTENER CORREOS PENDIENTES =====
$correos = obtenerCorreosPendientes($conn, 10);

if (empty($correos)) {
    echo "No hay correos pendientes.\n";
    @unlink($archivo_lock);
    @$conn->close();
    exit;
}

$enviados = 0;
$errores = 0;
$inicio_ejecucion = time();
$tiempo_max_segundos = 25; // dejar margen antes del timeout de PHP/Hostinger

foreach ($correos as $correo) {
    // Protección de tiempo
    if ((time() - $inicio_ejecucion) >= $tiempo_max_segundos) {
        echo "⏱️ Tiempo máximo alcanzado, quedan correos pendientes para el próximo cron.\n";
        break;
    }
    
    $correo_id = intval($correo['id'] ?? 0);
    $pedido_id = intval($correo['pedido_id'] ?? 0);
    $destinatario = $correo['destinatario'] ?? '';
    
    // Marcar contexto para el shutdown handler
    $GLOBALS['envio_contexto_actual'] = 'correo_' . $correo_id;
    
    try {
        // ===== Asegurar conexión antes de usarla =====
        if (!asegurarConexionBD($conn)) {
            error_log('[enviar_cola_correos] Sin conexión a BD al procesar correo #' . $correo_id);
            break; // Sin BD no podemos hacer nada más
        }
        
        // Validar email destinatario
        if (!filter_var($destinatario, FILTER_VALIDATE_EMAIL)) {
            marcarCorreoError($conn, $correo_id, 'Email inválido: ' . $destinatario);
            $errores++;
            echo "❌ Email inválido: {$destinatario}\n";
            continue;
        }
        
        // Validar que el pedido exista (excepto si pedido_id = 0 → correos sin pedido)
        if ($pedido_id > 0) {
            $stmt_pedido = $conn->prepare("SELECT id, estado_pago FROM pedidos WHERE id = ?");
            if (!$stmt_pedido) {
                marcarCorreoError($conn, $correo_id, 'Error prepare() consulta pedido');
                $errores++;
                continue;
            }
            $stmt_pedido->bind_param("i", $pedido_id);
            $stmt_pedido->execute();
            $pedido = $stmt_pedido->get_result()->fetch_assoc();
            $stmt_pedido->close();
            
            if (!$pedido) {
                marcarCorreoError($conn, $correo_id, 'Pedido no encontrado');
                $errores++;
                echo "❌ Pedido #{$pedido_id} no encontrado\n";
                continue;
            }
        } else {
            // Correo sin pedido asociado → no se puede enviar
            error_log('[enviar_cola_correos] Correo #' . $correo_id . ' sin pedido_id');
        }
        
                // ===== ENVIAR CORREO =====
        $resultado = false;
        
        if ($pedido_id > 0 && function_exists('enviarNotificacionPedidoConPDF')) {
            // Correo de pedido → función existente (ya carga PHPMailer internamente)
            $accion = !empty($correo['cuerpo']) ? $correo['cuerpo'] : 'pedido_creado';
            $resultado = enviarNotificacionPedidoConPDF($pedido_id, $accion, $destinatario);
        } elseif ($pedido_id > 0) {
            error_log('[enviar_cola_correos] enviarNotificacionPedidoConPDF no existe para pedido #' . $pedido_id);
            $resultado = false;
               } else {
            // Correo general (pedido_id = NULL) → usar enviarCorreoBase
            // (enviarCorreoBase NO soporta adjuntos; si el correo necesita adjunto,
            //  hay que usar una función distinta o ampliar enviarCorreoBase)
            if (function_exists('enviarCorreoBase')) {
                $resultado = enviarCorreoBase(
                    $destinatario,
                    $correo['asunto'] ?? '',
                    $correo['cuerpo'] ?? '',
                    '' // Sin texto plano (usa strip_tags del HTML)
                );
                // Advertir si el correo tenía adjunto pero no se puede enviar
                if (!empty($correo['adjunto'])) {
                    error_log('[enviar_cola_correos] Correo #' . $correo_id . ' tiene adjunto pero enviarCorreoBase no lo soporta. Adjunto ignorado.');
                }
            } else {
                error_log('[enviar_cola_correos] No hay función para enviar correos generales (enviarCorreoBase no existe)');
                $resultado = false;
            }
        }
        
        if ($resultado) {
            marcarCorreoEnviado($conn, $correo_id);
            $enviados++;
            echo "✅ Correo enviado: {$destinatario} (Pedido #{$pedido_id})\n";
        } else {
            marcarCorreoError($conn, $correo_id, 'Error al enviar');
            $errores++;
            echo "❌ Error al enviar: {$destinatario} (Pedido #{$pedido_id})\n";
        }
        
    } catch (Throwable $e) {
        // Throwable captura Exception + Error (TypeError, mysqli_sql_exception, etc.)
        error_log('[enviar_cola_correos] Excepción correo #' . $correo_id . ': ' . $e->getMessage());
        marcarCorreoError($conn, $correo_id, 'Excepción: ' . $e->getMessage());
        $errores++;
        echo "❌ Excepción: " . $e->getMessage() . "\n";
    }
}

// ===== LIMPIAR LOCK =====
@unlink($archivo_lock);

echo "\n";
echo "============================================\n";
echo "Correos enviados: $enviados\n";
echo "Errores: $errores\n";
echo "Duración: " . (time() - $inicio_ejecucion) . "s\n";
echo "============================================\n";

@$conn->close();
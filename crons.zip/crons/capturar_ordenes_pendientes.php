<?php
// ============================================
// CAPTURAR ÓRDENES PENDIENTES - CRON GENÉRICO
// ============================================
// Busca pedidos con orden aprobada pero no capturada
// de CUALQUIER pasarela API y las captura
// Se ejecuta cada 15 minutos
// ============================================

// ===== CONFIGURACIÓN DE ENTORNO =====
ini_set('display_errors', 0);
ini_set('log_errors', 1);
set_time_limit(30);
header('Content-Type: text/plain; charset=utf-8');

// ===== SEGURIDAD: TOKEN =====
$token_valido = 'catalejoo_7f3a9b2c8d1e4f6a5b7c9d2e4f6a8b1c3d5e7f9a1b3c5d7e9f1a3b5c7d9e1f3a';
$token_recibido = $_GET['token'] ?? '';

if (php_sapi_name() !== 'cli' && $token_recibido !== $token_valido) {
    http_response_code(403);
    exit('Acceso denegado');
}

// ===== EVITAR EJECUCIÓN SIMULTÁNEA =====
$archivo_lock = __DIR__ . '/.capturar_pendientes_lock';
if (file_exists($archivo_lock) && (time() - filemtime($archivo_lock)) < 60) {
    exit('Ya se está ejecutando');
}
if (file_put_contents($archivo_lock, time()) === false) {
    error_log('[capturar_pendientes] No se pudo crear el lock');
    exit('No se pudo crear el lock');
}

// ===== REGISTRO DE ERRORES DEL CRON =====
// Solo se registra cuando el cron NO puede verificar los pedidos pendientes
// de una pasarela concreta (archivo faltante, función faltante, error SQL, fatal).
// NO se registran fallos de negocio (capturas fallidas, montos, etc.).
function registrarErrorCron($pasarela, $mensaje) {
    $dir = dirname(__DIR__) . '/errores/cron';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $archivo = $dir . '/cron_' . $pasarela . '_' . date('Y-m-d') . '.txt';
    $bloque  = "============================================\n";
    $bloque .= "ERROR AL VERIFICAR PASARELA: {$pasarela}\n";
    $bloque .= "Fecha: " . date('Y-m-d H:i:s') . "\n";
    $bloque .= "Archivo: api_{$pasarela}.php\n";
    $bloque .= "============================================\n\n";
    $bloque .= $mensaje . "\n\n";
    $bloque .= "--------------------------------------------\n\n";
    @file_put_contents($archivo, $bloque, FILE_APPEND | LOCK_EX);
}

// Registra un fatal como error del cron (defensa en profundidad).
// Se registra ANTES de cualquier require_once que pueda fallar,
// para que si conexion.php o un api_*.php revientan, quede constancia.
$GLOBALS['cron_pasarela_actual'] = 'desconocida';
register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_COMPILE_ERROR, E_CORE_ERROR], true)) {
        $pasarela = $GLOBALS['cron_pasarela_actual'] ?? 'desconocida';
        $msg  = "FATAL: {$err['message']}\n";
        $msg .= "Archivo: {$err['file']}:{$err['line']}";
        registrarErrorCron($pasarela, $msg);
    }
});

// ===== CONEXIÓN Y ARCHIVOS =====
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/checkout/pago/apis/api_webhook_utils.php';

echo "============================================\n";
echo "CAPTURAR ÓRDENES PENDIENTES\n";
echo "Fecha: " . date('Y-m-d H:i:s') . "\n";
echo "============================================\n\n";

// ===== 1. OBTENER PASARELAS API ACTIVAS =====
// Lee del catálogo escalable (pasarelas) cruzado con activaciones (configuracion)
// Incluye pasarelas activadas por CUALQUIER proveedor (no solo la global)
$stmt = $conn->prepare("
    SELECT DISTINCT p.slug AS pasarela
    FROM pasarelas p
    INNER JOIN configuracion c 
        ON c.clave = CONCAT(p.slug, '_activo')
        AND c.grupo = 'pagos'
        AND c.valor = 1
    WHERE p.activo = 1
      AND p.tipo = 'api'
    ORDER BY p.orden ASC
");
$stmt->execute();
$result = $stmt->get_result();

$pasarelas_api = [];
while ($row = $result->fetch_assoc()) {
    $pasarelas_api[] = $row['pasarela'];
}
$stmt->close();

if (empty($pasarelas_api)) {
    echo "No hay pasarelas API configuradas.\n";
    @unlink($archivo_lock);
    $conn->close();
    exit;
}

echo "Pasarelas API: " . implode(', ', $pasarelas_api) . "\n\n";

// ===== 1.1. PRECARGAR APIs =====
// Cada archivo api_*.php debe ser defensivo: no debe incluir SDKs duros
// que puedan faltar. Si un require_once interno falla, el proceso muere y
// register_shutdown_function lo registra en /errores/cron/.
foreach ($pasarelas_api as $p) {
   $archivo = dirname(__DIR__) . '/checkout/pago/apis/api_' . $p . '.php';
    if (!file_exists($archivo)) {
        // Se registra más abajo, dentro del loop, para no duplicar
        continue;
    }
    try {
        require_once $archivo;
    } catch (Throwable $e) {
        $GLOBALS['cron_pasarela_actual'] = $p;
        $msg = "Excepción al precargar api_{$p}.php: " . $e->getMessage();
        error_log("[capturar_pendientes] $msg");
        registrarErrorCron($p, $msg);
    }
}

$total_capturados = 0;
$total_errores = 0;
$total_revisados = 0;
$inicio_ejecucion = time();
$tiempo_max_segundos = 25;

// ===== 2. PROCESAR CADA PASARELA =====
foreach ($pasarelas_api as $pasarela) {
    
    // Marcar pasarela actual (para que register_shutdown_function sepa quién falló)
    $GLOBALS['cron_pasarela_actual'] = $pasarela;
    
    // Protección de tiempo: si ya pasamos el límite, dejar el resto para el próximo cron
    if ((time() - $inicio_ejecucion) >= $tiempo_max_segundos) {
        echo "⏱️ Tiempo máximo alcanzado, quedan pasarelas pendientes para el próximo cron.\n";
        break;
    }
    
    echo "--- Procesando pasarela: $pasarela ---\n";
    
    // 2.1. Verificar que existe el archivo de la pasarela
    $archivo_pasarela = dirname(__DIR__) . '/checkout/pago/apis/api_' . $pasarela . '.php';
    
    if (!file_exists($archivo_pasarela)) {
        $msg = "Archivo no encontrado: $archivo_pasarela";
        echo "  ⚠️ $msg\n";
        error_log("[capturar_pendientes] $msg");
        registrarErrorCron($pasarela, $msg);
        continue;
    }
    
    try {
        require_once $archivo_pasarela;
    } catch (Throwable $e) {
        $msg = "Excepción al incluir api_{$pasarela}.php: " . $e->getMessage();
        echo "  ⚠️ $msg\n";
        error_log("[capturar_pendientes] $msg");
        registrarErrorCron($pasarela, $msg);
        continue;
    }
    
    // 2.2. Verificar que existe la función de captura (CamelCase por convención)
    $partes_slug = explode('_', $pasarela);
    $slug_camel = implode('', array_map('ucfirst', $partes_slug));
    $funcion_capturar = 'capturarOrden' . $slug_camel;
    
    if (!function_exists($funcion_capturar)) {
        $msg = "Función no encontrada: $funcion_capturar";
        echo "  ⚠️ $msg\n";
        error_log("[capturar_pendientes] $msg");
        registrarErrorCron($pasarela, $msg);
        continue;
    }
    
    // 2.3. Buscar pedidos pendientes de captura de esta pasarela
    // - Lee tipo_pago (fuente de verdad del slug, NOT NULL)
    // - referencia_externa = order_id devuelto por la pasarela al crear la orden
    // - transaccion_id NULL = todavía no capturado (lo escribe el webhook al confirmar)
    // - Incluye moneda + total_convertido para validación de moneda
    $stmt = $conn->prepare("
        SELECT id, codigo, cliente_id, moneda, total, total_convertido,
               monto_pagado, monto_pendiente, referencia_externa,
               transaccion_id, estado_pago, fecha_pedido
        FROM pedidos 
        WHERE tipo_pago = ?
        AND referencia_externa IS NOT NULL
        AND referencia_externa != ''
        AND transaccion_id IS NULL
        AND estado_pago NOT IN ('pagado', 'completado', 'cancelado')
        AND estado_actual NOT IN ('cancelado', 'entregado')
        AND fecha_pedido < DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ORDER BY id ASC
        LIMIT 50
    ");
    
    if (!$stmt) {
        $msg = "Error al preparar consulta de pedidos pendientes: " . $conn->error;
        echo "  ⚠️ $msg\n";
        error_log("[capturar_pendientes] $msg");
        registrarErrorCron($pasarela, $msg);
        continue;
    }
    
    $stmt->bind_param("s", $pasarela);
    
    if (!$stmt->execute()) {
        $msg = "Error al ejecutar consulta de pedidos pendientes: " . $stmt->error;
        echo "  ⚠️ $msg\n";
        error_log("[capturar_pendientes] $msg");
        registrarErrorCron($pasarela, $msg);
        $stmt->close();
        continue;
    }
    
    $pedidos = $stmt->get_result();
    
    $pedidos_lista = [];
    while ($p = $pedidos->fetch_assoc()) {
        $pedidos_lista[] = $p;
    }
    $stmt->close();
    
    if (empty($pedidos_lista)) {
        echo "  No hay pedidos pendientes.\n\n";
        continue;
    }
    
    echo "  Pedidos a revisar: " . count($pedidos_lista) . "\n";
    
    // 2.4. Procesar cada pedido
    foreach ($pedidos_lista as $pedido) {
        $pedido_id = intval($pedido['id']);
        $order_id = $pedido['referencia_externa'];
        
        // Protección de tiempo dentro del loop de pedidos
        if ((time() - $inicio_ejecucion) >= $tiempo_max_segundos) {
            echo "  ⏱️ Tiempo máximo alcanzado procesando pedidos.\n";
            break 2;
        }
        
        echo "  → Pedido #{$pedido_id} (order: {$order_id})...\n";
        
        // Obtener proveedor del pedido
        $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
        $stmt_prov->bind_param("i", $pedido_id);
        $stmt_prov->execute();
        $row_prov = $stmt_prov->get_result()->fetch_assoc();
        $proveedor_id = intval($row_prov['proveedor_id'] ?? 0);
        $stmt_prov->close();
        
        if ($proveedor_id <= 0) {
            echo "    ❌ Sin proveedor\n";
            error_log("[capturar_pendientes] Pedido #$pedido_id sin proveedor");
            $total_errores++;
            continue;
        }
        
        $total_revisados++;
        
        // Llamar a la función de captura de la pasarela
        $resultado = $funcion_capturar($conn, $pedido_id, $pedido, $proveedor_id);
        
        if (!is_array($resultado) || !($resultado['success'] ?? false)) {
            $mensaje = is_array($resultado) ? ($resultado['mensaje'] ?? 'Error desconocido') : 'Resultado inválido';
            echo "    ⚠️ No capturado: $mensaje\n";
            error_log("[capturar_pendientes] Pedido #$pedido_id ($pasarela) no capturado: $mensaje");
            $total_errores++;
            continue;
        }
        
        $total_capturados++;
        echo "    ✅ Capturado correctamente\n";
    }
    
    echo "\n";
}

// ===== LIMPIAR LOCK =====
@unlink($archivo_lock);

echo "============================================\n";
echo "Total revisados:  $total_revisados\n";
echo "Total capturados: $total_capturados\n";
echo "Total errores:    $total_errores\n";
echo "Duración:         " . (time() - $inicio_ejecucion) . "s\n";
echo "============================================\n";

$conn->close();
?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/header.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';

// ============================================
// VERIFICACIÓN DE PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor'];
$puede_ver = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_ver) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

// Validar que el proveedor existe y está activo
if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// FUNCIÓN PARA VERIFICAR PROPIEDAD DEL PEDIDO
// ============================================
function verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario) {
    if ($proveedor_id_usuario == 0) {
        return true; // Es administrador, puede ver todo
    }
    
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles WHERE pedido_id = ? AND proveedor_id = ?");
    $stmt->bind_param("ii", $pedido_id, $proveedor_id_usuario);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result['total'] > 0;
}

// ============================================
// PERMISOS DE GESTIÓN (confirmar/cancelar pagos)
// ============================================
$roles_gestion = ['Super Admin', 'Gerente', 'Proveedor', 'Vendedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_gestion);

// ============================================
// PROCESAR ACCIONES
// ============================================
$mensaje = '';
$tipo_mensaje = '';

// Confirmar pago individual
if (isset($_POST['confirmar_pago'])) {
    $pedido_id = intval($_POST['pedido_id']);
    
    // 🔥 Verificar propiedad
    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pago';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }
    
    // Obtener datos del pedido
    $stmt_info = $conn->prepare("SELECT estado_pago, porcentaje_comprometido, total FROM pedidos WHERE id = ?");
    $stmt_info->bind_param("i", $pedido_id);
    $stmt_info->execute();
    $info = $stmt_info->get_result()->fetch_assoc();
    
    // Determinar nuevo estado según el estado actual
    if ($info['estado_pago'] == 'pendiente_parcial') {
        $nuevo_estado_pago = 'pagado_parcial';
        $nuevo_estado_actual = 'pagado_parcial';
        
        // Calcular montos según el porcentaje comprometido
        $porcentaje_comprometido = $info['porcentaje_comprometido'];
        $total = $info['total'];
        $monto_pagado = ($total * $porcentaje_comprometido) / 100;
        $monto_pendiente = $total - $monto_pagado;
        
        // Actualizar pedido con los montos
        $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = ?, estado_actual = ?, porcentaje_pagado = ?, monto_pagado = ?, monto_pendiente = ? WHERE id = ?");
        $stmt->bind_param("ssiddi", $nuevo_estado_pago, $nuevo_estado_actual, $porcentaje_comprometido, $monto_pagado, $monto_pendiente, $pedido_id);
        $stmt->execute();
        
    } else {
        // Pago completo normal
        $nuevo_estado_pago = 'pagado';
        $nuevo_estado_actual = 'pagado';
        
        $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = ?, estado_actual = ?, porcentaje_pagado = 100, monto_pagado = total, monto_pendiente = 0 WHERE id = ?");
        $stmt->bind_param("ssi", $nuevo_estado_pago, $nuevo_estado_actual, $pedido_id);
        $stmt->execute();
    }
    
    $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'pago_confirmado', ?, 'Pago confirmado')");
    $stmt->bind_param("ii", $pedido_id, $_SESSION['usuario_id']);
    $stmt->execute();
    
    require_once dirname(__DIR__) . '/includes/email_config.php';
    enviarFacturaPedido($pedido_id, $nuevo_estado_actual);
    
    $_SESSION['mensaje'] = "✅ Pago confirmado";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// Cancelar pedido individual
if (isset($_GET['cancelar_pedido'])) {
    $pedido_id = intval($_GET['cancelar_pedido']);
    
    // 🔥 Verificar propiedad
    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pago';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }
    
    $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = 'cancelado' WHERE id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    
    $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'pago_cancelado', ?, 'Pago cancelado')");
    $stmt->bind_param("ii", $pedido_id, $_SESSION['usuario_id']);
    $stmt->execute();
    
    $_SESSION['mensaje'] = "✅ Pago cancelado";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// Confirmar múltiples pagos
if (isset($_POST['confirmar_multiple'])) {
    $ids = json_decode($_POST['confirmar_multiple'], true);
    $contador = 0;
    
    // 🔥 Verificar propiedad de todos los pedidos
    if ($proveedor_id_usuario > 0) {
        foreach ($ids as $pedido_id) {
            if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
                $_SESSION['mensaje'] = '❌ No tienes permiso para modificar algunos pagos';
                $_SESSION['tipo_mensaje'] = 'error';
                echo '<script>window.location.href="pagos.php";</script>';
                exit;
            }
        }
    }
    
    foreach ($ids as $pedido_id) {
        // Obtener datos del pedido
        $stmt_info = $conn->prepare("SELECT estado_pago, porcentaje_comprometido, total FROM pedidos WHERE id = ?");
        $stmt_info->bind_param("i", $pedido_id);
        $stmt_info->execute();
        $info = $stmt_info->get_result()->fetch_assoc();
        
        if ($info['estado_pago'] == 'pendiente_parcial') {
            $nuevo_estado_pago = 'pagado_parcial';
            $nuevo_estado_actual = 'pagado_parcial';
            
            $porcentaje_comprometido = $info['porcentaje_comprometido'];
            $total = $info['total'];
            $monto_pagado = ($total * $porcentaje_comprometido) / 100;
            $monto_pendiente = $total - $monto_pagado;
            
            $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = ?, estado_actual = ?, porcentaje_pagado = ?, monto_pagado = ?, monto_pendiente = ? WHERE id = ?");
            $stmt->bind_param("ssiddi", $nuevo_estado_pago, $nuevo_estado_actual, $porcentaje_comprometido, $monto_pagado, $monto_pendiente, $pedido_id);
            $stmt->execute();
            
        } else {
            $nuevo_estado_pago = 'pagado';
            $nuevo_estado_actual = 'pagado';
            
            $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = ?, estado_actual = ?, porcentaje_pagado = 100, monto_pagado = total, monto_pendiente = 0 WHERE id = ?");
            $stmt->bind_param("ssi", $nuevo_estado_pago, $nuevo_estado_actual, $pedido_id);
            $stmt->execute();
        }
        
        $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'pago_confirmado', ?, 'Pago confirmado')");
        $stmt->bind_param("ii", $pedido_id, $_SESSION['usuario_id']);
        $stmt->execute();
        
        $contador++;
    }
    
    require_once dirname(__DIR__) . '/includes/email_config.php';
    foreach ($ids as $pedido_id) {
        enviarFacturaPedido($pedido_id, 'pagado');
    }
    
    $_SESSION['mensaje'] = "✅ $contador pago(s) confirmado(s)";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// Cancelar múltiples pagos
if (isset($_POST['cancelar_multiple'])) {
    $ids = json_decode($_POST['cancelar_multiple'], true);
    $contador = 0;
    
    // 🔥 Verificar propiedad de todos los pedidos
    if ($proveedor_id_usuario > 0) {
        foreach ($ids as $pedido_id) {
            if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
                $_SESSION['mensaje'] = '❌ No tienes permiso para modificar algunos pagos';
                $_SESSION['tipo_mensaje'] = 'error';
                echo '<script>window.location.href="pagos.php";</script>';
                exit;
            }
        }
    }
    
    foreach ($ids as $pedido_id) {
        $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = 'cancelado' WHERE id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        
        $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'pago_cancelado', ?, 'Pago cancelado')");
        $stmt->bind_param("ii", $pedido_id, $_SESSION['usuario_id']);
        $stmt->execute();
        
        $contador++;
    }
    
    $_SESSION['mensaje'] = "✅ $contador pago(s) cancelado(s)";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

// 🔥 FILTRO POR PROVEEDOR (si el usuario es de tienda)
if ($proveedor_id_usuario > 0) {
    $where[] = "p.id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = $proveedor_id_usuario)";
}

$hay_filtros = !empty($_GET['pedido_id']) || !empty($_GET['cliente']) || !empty($_GET['estado_pago']) || !empty($_GET['moneda']) || !empty($_GET['fecha_desde']) || !empty($_GET['fecha_hasta']);

if (!$hay_filtros) {
    $where[] = "p.estado_pago IN ('pendiente', 'pendiente_confirmacion', 'pendiente_parcial', 'pagado_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_pago_final')";
}

if (!empty($_GET['pedido_id'])) {
    $where[] = "p.codigo LIKE ?";
    $params[] = $_GET['pedido_id'] . "%";
    $types .= "s";
}

if (!empty($_GET['cliente'])) {
    $where[] = "(c.nombre LIKE ? OR c.apellidos LIKE ? OR c.email LIKE ?)";
    $search = "%" . $_GET['cliente'] . "%";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= "sss";
}

if (!empty($_GET['estado_pago'])) {
    if ($_GET['estado_pago'] != 'todos') {
        $where[] = "p.estado_pago = ?";
        $params[] = $_GET['estado_pago'];
        $types .= "s";
    }
}

if (!empty($_GET['moneda'])) {
    $where[] = "p.moneda = ?";
    $params[] = $_GET['moneda'];
    $types .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $where[] = "DATE(p.fecha_pedido) >= ?";
    $params[] = $_GET['fecha_desde'];
    $types .= "s";
}

if (!empty($_GET['fecha_hasta'])) {
    $where[] = "DATE(p.fecha_pedido) <= ?";
    $params[] = $_GET['fecha_hasta'];
    $types .= "s";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ===== ORDENAMIENTO =====
$columnas_validas = [
    'id' => "p.id",
    'cliente' => "CONCAT(c.nombre, ' ', c.apellidos)",
    'fecha' => "p.fecha_pedido",
    'total' => "p.total",
    'metodo' => "p.tipo_pago",
    'estado' => "p.estado_pago"
];

$order_by = isset($_GET['order_by']) && array_key_exists($_GET['order_by'], $columnas_validas) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . $columnas_validas[$order_by] . " $order_dir";

// ===== CONTAR TOTAL DE REGISTROS =====
$count_sql = "SELECT COUNT(*) as total FROM pedidos p JOIN clientes c ON p.cliente_id = c.id $sql_where";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_registros = $count_result->fetch_assoc()['total'];

// ===== INCLUIR VARIABLES DE PAGINACIÓN =====
$base_url = 'pagos.php?' . http_build_query(array_filter($_GET));
include __DIR__ . '/../includes/paginacion_vars.php';

// ===== CONSULTA PRINCIPAL =====
$sql = "SELECT p.*, c.nombre, c.apellidos, c.email 
        FROM pedidos p
        JOIN clientes c ON p.cliente_id = c.id
        $sql_where
        $order_sql
        LIMIT $por_pagina OFFSET $offset";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$pedidos = $stmt->get_result();

// Estadísticas con los mismos filtros de la tabla
$stats_sql = "SELECT 
    SUM(CASE WHEN estado_pago = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
    SUM(CASE WHEN estado_pago = 'pendiente_parcial' THEN 1 ELSE 0 END) as pendiente_parcial,
    SUM(CASE WHEN estado_pago = 'pendiente_entrega' THEN 1 ELSE 0 END) as pendiente_entrega,
    SUM(CASE WHEN estado_pago = 'pendiente_entrega_pago' THEN 1 ELSE 0 END) as pendiente_entrega_pago,
    SUM(CASE WHEN estado_pago = 'pendiente_pago_final' THEN 1 ELSE 0 END) as pendiente_pago_final,
    SUM(CASE WHEN estado_pago = 'pagado' THEN 1 ELSE 0 END) as pagados,
    SUM(CASE WHEN estado_pago = 'pagado_parcial' THEN 1 ELSE 0 END) as pagado_parcial,
    SUM(CASE WHEN estado_pago = 'cancelado' THEN 1 ELSE 0 END) as cancelados
    FROM pedidos p
    JOIN clientes c ON p.cliente_id = c.id
    $sql_where";
    
$stats_stmt = $conn->prepare($stats_sql);
if (!empty($params)) {
    $stats_stmt->bind_param($types, ...$params);
}
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}
?>

<!-- ESTILOS -->
<style>
:root {
    --primary: <?php echo $color_primario ?? '#667eea'; ?>;
    --secondary: <?php echo $color_secundario ?? '#764ba2'; ?>;
}

.gestion-container {
    width: 100%;
    max-width: 1400px;
    margin: 1rem auto;
    padding: 0 1rem;
}
@media (min-width: 768px) {
    .gestion-container { margin: 2rem auto; padding: 0 2rem; }
}
.gestion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}
.gestion-header h1 { font-size: 1.5rem; color: #2d3748; margin: 0; }
@media (min-width: 768px) { .gestion-header h1 { font-size: 2rem; } }

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}
@media (min-width: 640px) { .stats-grid { grid-template-columns: repeat(4, 1fr); gap: 1rem; } }
.stat-card {
    background: white;
    border-radius: 12px;
    padding: 0.75rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    text-align: center;
}
.stat-card .label { font-size: 0.65rem; color: #718096; text-transform: uppercase; }
.stat-card .value { font-size: 1.2rem; font-weight: 700; color: #2d3748; }

.filtros-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
@media (min-width: 768px) { .filtros-card { padding: 1.5rem; } }
.filtros-linea {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 0.5rem;
}
.filtro-item { flex: 1; min-width: 0; }
.filtro-item label { display: block; font-size: 0.65rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem; text-transform: uppercase; }
.filtro-item input, .filtro-item select { width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.8rem; }
.filtro-fecha { max-width: 130px; }
.filtros-botones { display: flex; gap: 0.5rem; flex-shrink: 0; }
.btn-filtro { padding: 0.5rem 1rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.8rem; text-decoration: none; display: inline-block; text-align: center; }
.btn-filtro-aplicar { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; }
.btn-filtro-limpiar { background: #edf2f7; color: #4a5568; }

@media (max-width: 768px) {
    .filtros-linea { flex-direction: column; align-items: stretch; gap: 0.75rem; }
    .filtro-item { width: 100%; }
    .filtro-fecha { max-width: none; }
    .filtros-botones { margin-top: 0.5rem; }
    .btn-filtro { flex: 1; text-align: center; }
}

.tabla-pagos {
    background: white;
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
    width: 100%;
}
.tabla-pagos table { width: 100%; min-width: 700px; border-collapse: collapse; font-size: 0.75rem; }
@media (min-width: 768px) { .tabla-pagos table { font-size: 0.9rem; } }
.tabla-pagos th {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.7rem 0.5rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.7rem;
    text-transform: uppercase;
}
.tabla-pagos td { padding: 0.7rem 0.5rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }

.checkbox-col { width: 40px; text-align: center; }
.checkbox-pedido, .select-all-checkbox { width: 18px; height: 18px; cursor: pointer; accent-color: var(--primary); margin: 0 auto; display: block; }

/* Badges de estado de pago */
.badge-estado-pago { padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.7rem; font-weight: 600; display: inline-block; }
.badge-pendiente { background: #fef5e7; color: #c05621; }
.badge-pendiente_parcial { background: #fef5e7; color: #744210; }
.badge-pendiente_entrega { background: #fef5e7; color: #744210; }
.badge-pendiente_entrega_pago { background: #fef5e7; color: #744210; }
.badge-pendiente_pago_final { background: #e9d8fd; color: #6b46c1; }
.badge-pagado { background: #c6f6d5; color: #22543d; }
.badge-pagado_parcial { background: #c6f6d5; color: #22543d; }
.badge-cancelado { background: #fed7d7; color: #c53030; }

.tabla-pagos th a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
}

.btn-accion { padding: 0.3rem 0.6rem; border-radius: 6px; text-decoration: none; font-size: 0.7rem; display: inline-block; border: none; cursor: pointer; margin: 0 0.15rem; }
@media (min-width: 768px) { .btn-accion { padding: 0.4rem 0.8rem; font-size: 0.8rem; } }
.btn-ver { background: #4299e1; color: white; }
.btn-confirmar { background: #48bb78; color: white; }
.btn-cancelar { background: #f56565; color: white; }

/* Botón flotante universal */
.floating-counter {
    position: fixed;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    z-index: 1000;
    transition: all 0.3s ease;
    border: 2px solid white;
    display: none;
    align-items: center;
    justify-content: center;
    gap: 5px;
}
.floating-counter:hover { transform: scale(1.05); }
.floating-counter.show { display: flex; }

/* PC: abajo a la derecha */
@media (min-width: 769px) {
    .floating-counter {
        bottom: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 50px;
        font-size: 1rem;
        min-width: auto;
    }
}
/* Móvil: arriba a la izquierda */
@media (max-width: 768px) {
    .floating-counter {
        top: 70px;
        left: 20px;
        width: 45px;
        height: 45px;
        border-radius: 50%;
        font-size: 1.1rem;
        padding: 0;
    }
}

/* Menú flotante de acciones */
.floating-actions-menu {
    position: fixed;
    background: white;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    z-index: 1000;
    min-width: 200px;
    overflow: hidden;
    display: none;
    border: 1px solid #e2e8f0;
}
.floating-actions-menu.show { display: block; animation: fadeInUp 0.2s ease; }

/* PC: menú abajo a la derecha */
@media (min-width: 769px) {
    .floating-actions-menu {
        bottom: 90px;
        right: 20px;
    }
}
/* Móvil: menú arriba a la izquierda */
@media (max-width: 768px) {
    .floating-actions-menu {
        top: 125px;
        left: 20px;
    }
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
.floating-actions-menu button {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    padding: 12px 16px;
    border: none;
    background: white;
    color: #2d3748;
    font-size: 0.9rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    text-align: left;
}
.floating-actions-menu button:hover { background: #f7fafc; }
.floating-actions-menu hr { margin: 0; border-top: 1px solid #e2e8f0; }

.mensaje { padding: 0.75rem; border-radius: 10px; margin-bottom: 1rem; font-size: 0.85rem; }
.mensaje.exito { background: #f0fff4; color: #22543d; border: 1px solid #48bb78; }
.text-center { text-align: center; }

.modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
}
.modal-content {
    background: white;
    margin: 10% auto;
    padding: 1.25rem;
    border-radius: 16px;
    max-width: 95%;
    width: 95%;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
}
@media (min-width: 768px) { .modal-content { margin: 5% auto; padding: 2rem; max-width: 600px; } }
.close {
    position: absolute;
    top: 0.75rem;
    right: 1rem;
    font-size: 1.8rem;
    cursor: pointer;
    color: #718096;
}
.close:hover { color: #2d3748; }
.btn-confirmar-modal { width: 100%; padding: 0.8rem; background: #48bb78; color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; margin-top: 1rem; }
</style>

<div class="gestion-container">
    <div class="gestion-header">
        <h1>💰 Gestión de Pagos</h1>
    </div>

   <div class="stats-grid">
    <div class="stat-card"><div class="label">Pendientes</div><div class="value"><?php echo $stats['pendientes'] ?? 0; ?></div></div>
    <div class="stat-card"><div class="label">Pendiente Parcial</div><div class="value"><?php echo $stats['pendiente_parcial'] ?? 0; ?></div></div>
    <div class="stat-card"><div class="label">Pendiente Entrega</div><div class="value"><?php echo $stats['pendiente_entrega'] ?? 0; ?></div></div>
    <div class="stat-card"><div class="label">Pendiente Entrega Pago</div><div class="value"><?php echo $stats['pendiente_entrega_pago'] ?? 0; ?></div></div>
    <div class="stat-card"><div class="label">Pendiente Pago Final</div><div class="value"><?php echo $stats['pendiente_pago_final'] ?? 0; ?></div></div>
    <div class="stat-card"><div class="label">Pagados</div><div class="value"><?php echo $stats['pagados'] ?? 0; ?></div></div>
    <div class="stat-card"><div class="label">Pagado Parcial</div><div class="value"><?php echo $stats['pagado_parcial'] ?? 0; ?></div></div>
    <div class="stat-card"><div class="label">Cancelados</div><div class="value"><?php echo $stats['cancelados'] ?? 0; ?></div></div>
</div>

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <div class="filtros-card">
        <form method="GET" class="filtros-form">
            <div class="filtros-linea">
    <div class="filtro-item">
    <label>Código Pedido</label>
    <input type="text" name="pedido_id" value="<?php echo htmlspecialchars($_GET['pedido_id'] ?? ''); ?>" placeholder="260521-0001" onchange="this.form.submit()">
</div>
    <div class="filtro-item">
        <label>Cliente</label>
        <input type="text" name="cliente" value="<?php echo htmlspecialchars($_GET['cliente'] ?? ''); ?>" placeholder="Nombre o email" onchange="this.form.submit()">
    </div>
    <div class="filtro-item">
        <label>Estado pago</label>
       <select name="estado_pago" onchange="this.form.submit()">
    <option value="todos">Todos</option>
    <option value="pendiente" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
    <option value="pendiente_parcial" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_parcial' ? 'selected' : ''; ?>>Pendiente Parcial</option>
    <option value="pendiente_entrega" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_entrega' ? 'selected' : ''; ?>>Pendiente Entrega</option>
    <option value="pendiente_entrega_pago" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_entrega_pago' ? 'selected' : ''; ?>>Pendiente Entrega Pago</option>
    <option value="pendiente_pago_final" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_pago_final' ? 'selected' : ''; ?>>Pendiente Pago Final</option>
    <option value="pagado" <?php echo ($_GET['estado_pago'] ?? '') == 'pagado' ? 'selected' : ''; ?>>Pagado</option>
    <option value="pagado_parcial" <?php echo ($_GET['estado_pago'] ?? '') == 'pagado_parcial' ? 'selected' : ''; ?>>Pagado Parcial</option>
    <option value="cancelado" <?php echo ($_GET['estado_pago'] ?? '') == 'cancelado' ? 'selected' : ''; ?>>Cancelado</option>
</select>
    </div>
    <div class="filtro-item">
        <label>Moneda</label>
        <select name="moneda" onchange="this.form.submit()">
            <option value="">Todas</option>
            <option value="USD" <?php echo ($_GET['moneda'] ?? '') == 'USD' ? 'selected' : ''; ?>>USD</option>
            <option value="CUP" <?php echo ($_GET['moneda'] ?? '') == 'CUP' ? 'selected' : ''; ?>>CUP</option>
        </select>
    </div>
    <div class="filtro-item filtro-fecha">
        <label>Desde</label>
        <input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>" onchange="this.form.submit()">
    </div>
    <div class="filtro-item filtro-fecha">
        <label>Hasta</label>
        <input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>" onchange="this.form.submit()">
    </div>
    <div class="filtros-botones">
        <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
        <a href="pagos.php" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
    </div>
</div>
        </form>
    </div>

    <div class="tabla-pagos">
        <table id="tablaPagos">
           <thead>
    <tr>
        <th class="checkbox-col"><input type="checkbox" class="select-all-checkbox" id="selectAll"></th>
       <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'id', 'order_dir' => ($order_by == 'id' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Código <?php if ($order_by == 'id'): ?><?php echo $order_dir == 'ASC' ? '▲' : '▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'cliente', 'order_dir' => ($order_by == 'cliente' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Cliente<?php if ($order_by == 'cliente'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'fecha', 'order_dir' => ($order_by == 'fecha' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Fecha<?php if ($order_by == 'fecha'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'total', 'order_dir' => ($order_by == 'total' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Total<?php if ($order_by == 'total'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'metodo', 'order_dir' => ($order_by == 'metodo' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Método<?php if ($order_by == 'metodo'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'estado', 'order_dir' => ($order_by == 'estado' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Estado<?php if ($order_by == 'estado'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th>Acciones</th>
    </thead>
            <tbody>
                
                <?php 
// Calcular porcentaje para mostrar en estados parciales
$porcentaje_entrega = 0;
$res_porc = $conn->query("SELECT valor FROM configuracion WHERE clave = 'porcentaje_con_entrega'");
if ($row = $res_porc->fetch_assoc()) {
    $porcentaje_entrega = intval($row['valor']);
}
$porcentaje_ahora = 100 - $porcentaje_entrega;
?>
                <?php if ($pedidos->num_rows > 0): ?>
                    <?php while($p = $pedidos->fetch_assoc()): 
                        $badge_class = '';
                        $estado_texto = '';
                        switch($p['estado_pago']) {
    case 'pendiente':
        $badge_class = 'badge-pendiente';
        $estado_texto = 'Pendiente';
        break;
    case 'pendiente_parcial':
        $badge_class = 'badge-pendiente_parcial';
        $estado_texto = 'Pendiente Parcial';
        break;
    case 'pendiente_entrega':
        $badge_class = 'badge-pendiente_entrega';
        $estado_texto = 'Pendiente Entrega';
        break;
    case 'pendiente_entrega_pago':
        $badge_class = 'badge-pendiente_entrega_pago';
        $estado_texto = 'Pendiente Entrega Pago';
        break;
    case 'pendiente_pago_final':
        $badge_class = 'badge-pendiente_pago_final';
        $estado_texto = 'Pendiente Pago Final';
        break;
    case 'pagado':
        $badge_class = 'badge-pagado';
        $estado_texto = 'Pagado';
        break;
    case 'pagado_parcial':
        $badge_class = 'badge-pagado_parcial';
        $estado_texto = 'Pagado Parcial';
        break;
    case 'cancelado':
        $badge_class = 'badge-cancelado';
        $estado_texto = 'Cancelado';
        break;
    default:
        $badge_class = '';
        $estado_texto = ucfirst(str_replace('_', ' ', $p['estado_pago']));
}
                    ?>
                        <tr>
                            <td class="checkbox-col text-center"><input type="checkbox" class="checkbox-pedido" value="<?php echo $p['id']; ?>"></td>
                           <td style="font-weight: 600; color: #4a5568;"><?php echo $p['codigo']; ?></td>
                            <td><strong><?php echo htmlspecialchars($p['nombre'] . ' ' . $p['apellidos']); ?></strong><br><small><?php echo htmlspecialchars($p['email']); ?></small></td>
                            <td><?php echo date('d/m/Y', strtotime($p['fecha_pedido'])); ?></td>
                            <td>$<?php echo number_format($p['total'], 2); ?> <?php echo $p['moneda']; ?></td>
                            <td><?php echo ucfirst($p['tipo_pago']); ?></td>
                            <td><span class="badge-estado-pago <?php echo $badge_class; ?>"><?php echo $estado_texto; ?></span></td>
                            <td>
    <button onclick="verDetallePedido(<?php echo $p['id']; ?>)" class="btn-accion btn-ver">👁️ Ver</button>
    <?php if ($puede_gestionar): ?>
        <?php if ($p['estado_pago'] == 'pendiente' || $p['estado_pago'] == 'pendiente_parcial' || $p['estado_pago'] == 'pendiente_entrega'): ?>
            <button onclick="mostrarModalConfirmar(<?php echo $p['id']; ?>)" class="btn-accion btn-confirmar">💰 Confirmar</button>
        <?php elseif ($p['estado_pago'] == 'pendiente_pago_final' && $p['estado_actual'] == 'entregado'): ?>
            <button onclick="mostrarModalConfirmar(<?php echo $p['id']; ?>)" class="btn-accion btn-confirmar">💰 Confirmar</button>
        <?php elseif ($p['estado_pago'] == 'pendiente_entrega_pago' && $p['estado_actual'] == 'entregado'): ?>
            <button onclick="mostrarModalConfirmar(<?php echo $p['id']; ?>)" class="btn-accion btn-confirmar">💰 Confirmar</button>
        <?php endif; ?>
        <?php if ($p['estado_pago'] != 'pagado' && $p['estado_pago'] != 'cancelado'): ?>
            <a href="?cancelar_pedido=<?php echo $p['id']; ?>" class="btn-accion btn-cancelar" onclick="return confirm('¿Cancelar este pago?')">❌ Cancelar</a>
        <?php endif; ?>
    <?php endif; ?>
</td>
                        </tr>
                    <?php endwhile; ?>
              <?php else: ?>
    <tr><td colspan="8" class="text-center" style="padding:2rem;">📭 No hay pagos para mostrar</td>
<?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Botones de paginación -->
    <?php include __DIR__ . '/../includes/paginacion_botones.php'; ?>

    <!-- Botón flotante universal -->
    <div id="floatingCounter" class="floating-counter">0</div>

    <!-- Menú flotante de acciones -->
    <div id="floatingActionsMenu" class="floating-actions-menu">
        <button id="btnConfirmarAccion">💰 Confirmar</button>
        <button id="btnCancelarAccion">❌ Cancelar</button>
        <hr>
        <button id="btnLimpiarAccion">✖ Limpiar selección</button>
    </div>
</div>

<!-- Modales -->
<div id="modalConfirmarPago" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalConfirmarPago')">&times;</span>
        <h2>💰 Confirmar Pago</h2>
        <form method="POST">
            <input type="hidden" name="confirmar_pago" value="1">
            <input type="hidden" name="pedido_id" id="confirmar_pago_id">
            <p>¿Confirmar que el pago ha sido recibido?</p>
            <button type="submit" class="btn-confirmar-modal">✓ Sí, confirmar pago</button>
        </form>
    </div>
</div>

<div id="modalDetallePedido" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalDetallePedido')">&times;</span>
        <div id="contenidoDetallePedido">Cargando...</div>
    </div>
</div>

<script>
let seleccionados = new Set();

function guardarSeleccion() { sessionStorage.setItem('pedidosSeleccionados', JSON.stringify([...seleccionados])); }
function cargarSeleccion() {
    const guardados = sessionStorage.getItem('pedidosSeleccionados');
    if (guardados) { seleccionados = new Set(JSON.parse(guardados)); actualizarTodo(); }
}
function actualizarCheckboxes() {
    document.querySelectorAll('.checkbox-pedido').forEach(cb => cb.checked = seleccionados.has(parseInt(cb.value)));
    const total = document.querySelectorAll('.checkbox-pedido').length;
    const seleccionadosEnPagina = document.querySelectorAll('.checkbox-pedido:checked').length;
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.checked = total > 0 && seleccionadosEnPagina === total;
        selectAll.indeterminate = seleccionadosEnPagina > 0 && seleccionadosEnPagina < total;
    }
}
function actualizarContador() {
    const count = seleccionados.size;
    const floatingCounter = document.getElementById('floatingCounter');
    if (floatingCounter) {
        if (count > 0) {
            if (window.innerWidth > 768) {
                floatingCounter.textContent = count + (count === 1 ? ' seleccionado' : ' seleccionados');
            } else {
                floatingCounter.textContent = count;
            }
            floatingCounter.classList.add('show');
        } else {
            floatingCounter.classList.remove('show');
        }
    }
}
function actualizarTodo() { actualizarCheckboxes(); actualizarContador(); }

document.addEventListener('change', function(e) {
    if (e.target.classList.contains('checkbox-pedido')) {
        const id = parseInt(e.target.value);
        e.target.checked ? seleccionados.add(id) : seleccionados.delete(id);
        actualizarTodo(); guardarSeleccion();
    }
    if (e.target.id === 'selectAll') {
        document.querySelectorAll('.checkbox-pedido').forEach(cb => { cb.checked = e.target.checked; const id = parseInt(cb.value); e.target.checked ? seleccionados.add(id) : seleccionados.delete(id); });
        actualizarTodo(); guardarSeleccion();
    }
});

function ejecutarAccion(accion, ids) {
    if (ids.length === 0) return;
    const form = document.createElement('form'); form.method = 'POST'; form.action = 'pagos.php';
    const input = document.createElement('input'); input.type = 'hidden'; input.name = accion; input.value = JSON.stringify(ids);
    form.appendChild(input); document.body.appendChild(form); form.submit();
}

// Eventos del menú flotante
document.getElementById('btnConfirmarAccion')?.addEventListener('click', () => {
    if (seleccionados.size && confirm(`¿Confirmar ${seleccionados.size} pedido(s)?`)) ejecutarAccion('confirmar_multiple', [...seleccionados]);
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('btnCancelarAccion')?.addEventListener('click', () => {
    if (seleccionados.size && confirm(`¿Cancelar ${seleccionados.size} pedido(s)?`)) ejecutarAccion('cancelar_multiple', [...seleccionados]);
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('btnLimpiarAccion')?.addEventListener('click', () => {
    seleccionados.clear(); actualizarTodo(); guardarSeleccion();
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});

// Mostrar/ocultar menú
document.getElementById('floatingCounter')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('floatingActionsMenu')?.classList.toggle('show');
});
document.addEventListener('click', (e) => {
    if (!e.target.closest('#floatingCounter') && !e.target.closest('#floatingActionsMenu')) {
        document.getElementById('floatingActionsMenu')?.classList.remove('show');
    }
});

function verDetallePedido(pedidoId) {
    const modal = document.getElementById('modalDetallePedido');
    const contenido = document.getElementById('contenidoDetallePedido');
    modal.style.display = 'block';
    contenido.innerHTML = '<div style="text-align:center;padding:2rem;">🔄 Cargando...</div>';
    fetch('detalle_pedido_json.php?id=' + pedidoId).then(r => r.text()).then(html => contenido.innerHTML = html).catch(() => contenido.innerHTML = '<div style="text-align:center;padding:2rem;color:#f56565;">❌ Error</div>');
}
function mostrarModalConfirmar(pedidoId) { document.getElementById('confirmar_pago_id').value = pedidoId; document.getElementById('modalConfirmarPago').style.display = 'block'; }
function cerrarModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

document.addEventListener('DOMContentLoaded', () => { cargarSeleccion(); });
document.querySelector('.filtros-form')?.addEventListener('submit', () => guardarSeleccion());
document.querySelectorAll('.btn-pagina').forEach(link => link.addEventListener('click', () => guardarSeleccion()));
window.onclick = (event) => { if (event.target.classList.contains('modal')) event.target.style.display = 'none'; };
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') document.querySelectorAll('.modal').forEach(m => m.style.display = 'none'); });
window.addEventListener('resize', () => actualizarContador());
</script>

<?php $conn->close(); ?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    exit('<p>No autorizado</p>');
}

$rol_actual = $_SESSION['rol'] ?? '';
$usuario_id = $_SESSION['usuario_id'];

// ============================================
// ROLES PERMITIDOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor', 'Empaquetador', 'Transportista'];
if (!in_array($rol_actual, $roles_permitidos)) {
    http_response_code(403);
    exit('<p>Sin permiso</p>');
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id, $rol_actual));

// ============================================
// VALIDAR PEDIDO
// ============================================
$pedido_id = intval($_GET['id'] ?? 0);
if ($pedido_id <= 0) {
    http_response_code(400);
    exit('<p>ID de pedido no válido</p>');
}

// Verificar propiedad
if ($proveedor_id_usuario > 0) {
    $stmt_prop = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles WHERE pedido_id = ? AND proveedor_id = ?");
    $stmt_prop->bind_param("ii", $pedido_id, $proveedor_id_usuario);
    $stmt_prop->execute();
    $prop = $stmt_prop->get_result()->fetch_assoc();
    $stmt_prop->close();
    
    if ($prop['total'] == 0) {
        http_response_code(403);
        exit('<p>No tienes permiso para ver este pedido</p>');
    }
}

$modo = $_GET['productos'] ?? $_GET['resumen'] ?? '';

// ============================================
// MODO: SOLO PRODUCTOS
// ============================================
if ($modo == 'productos') {
    $stmt = $conn->prepare("
        SELECT pd.*, 
               COALESCE(p.nombre, CONCAT('Combo #', pd.combo_id)) as nombre
        FROM pedido_detalles pd 
        LEFT JOIN productos p ON pd.producto_id = p.id 
        WHERE pd.pedido_id = ?
    ");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $productos = [];
    while ($row = $result->fetch_assoc()) {
        $productos[] = [
            'producto_id' => $row['producto_id'],
            'combo_id' => $row['combo_id'],
            'nombre' => $row['nombre'],
            'cantidad' => $row['cantidad']
        ];
    }
    $stmt->close();
    
    echo json_encode($productos);
    exit;
}

// ============================================
// MODO: RESUMEN
// ============================================
if ($modo == 'resumen') {
    $stmt = $conn->prepare("
        SELECT p.*, c.nombre, c.apellidos, c.email, c.movil,
               (SELECT COUNT(*) FROM pedido_detalles WHERE pedido_id = p.id) as total_productos,
               (SELECT SUM(cantidad) FROM pedido_detalles WHERE pedido_id = p.id) as total_items
        FROM pedidos p
        JOIN clientes c ON p.cliente_id = c.id
        WHERE p.id = ?
    ");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$pedido) {
        echo json_encode(['error' => 'Pedido no encontrado']);
        exit;
    }
    
    echo json_encode([
        'cliente' => $pedido['nombre'] . ' ' . $pedido['apellidos'],
        'email' => $pedido['email'],
        'movil' => $pedido['movil'],
        'total' => number_format($pedido['total'], 2) . ' ' . $pedido['moneda'],
        'productos' => $pedido['total_productos'] . ' productos (' . $pedido['total_items'] . ' items)',
        'direccion' => 'Pendiente de implementar'
    ]);
    exit;
}

// ============================================
// DETALLE COMPLETO
// ============================================
$stmt = $conn->prepare("
    SELECT p.*, c.nombre, c.apellidos, c.email, c.movil 
    FROM pedidos p 
    JOIN clientes c ON p.cliente_id = c.id 
    WHERE p.id = ?
");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pedido) {
    exit('<p>Pedido no encontrado</p>');
}

// Obtener productos (con combos)
$stmt = $conn->prepare("
    SELECT pd.*, 
           COALESCE(p.nombre, CONCAT('Combo #', pd.combo_id)) as nombre
    FROM pedido_detalles pd 
    LEFT JOIN productos p ON pd.producto_id = p.id 
    WHERE pd.pedido_id = ?
");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$productos = $stmt->get_result();
$stmt->close();

// Obtener dirección de entrega
$stmt_dir = $conn->prepare("SELECT * FROM direcciones_envio WHERE pedido_id = ?");
$stmt_dir->bind_param("i", $pedido_id);
$stmt_dir->execute();
$direccion = $stmt_dir->get_result()->fetch_assoc();
$stmt_dir->close();

// Obtener historial de estados
$stmt = $conn->prepare("
    SELECT pe.*, u.nombre_completo as usuario_nombre 
    FROM pedido_estados pe 
    LEFT JOIN usuarios u ON pe.usuario_id = u.id 
    WHERE pe.pedido_id = ? 
    ORDER BY pe.fecha DESC
");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$estados = $stmt->get_result();
$stmt->close();

// Obtener incidencias
$stmt = $conn->prepare("
    SELECT pi.*, u.nombre_completo as usuario_nombre, p.nombre as producto_nombre 
    FROM pedido_incidencias pi 
    LEFT JOIN usuarios u ON pi.usuario_id = u.id 
    LEFT JOIN productos p ON pi.producto_id = p.id 
    WHERE pi.pedido_id = ? 
    ORDER BY pi.fecha DESC
");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$incidencias = $stmt->get_result();
$stmt->close();
?>

<div style="padding: 1rem;">
    <h2>📦 Pedido #<?php echo intval($pedido['id']); ?></h2>
    
    <!-- Info del cliente -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 1rem 0; padding: 1rem; background: #f7fafc; border-radius: 8px;">
        <div>
            <p><strong>Cliente:</strong> <?php echo htmlspecialchars($pedido['nombre'] . ' ' . $pedido['apellidos']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($pedido['email']); ?></p>
            <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($pedido['movil'] ?? ''); ?></p>
        </div>
        <div>
            <p><strong>Fecha pedido:</strong> <?php echo date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])); ?></p>
            <p><strong>Subtotal:</strong> $<?php echo number_format($pedido['subtotal'], 2); ?> USD</p>
            <p><strong>Envío:</strong> $<?php echo number_format($pedido['envio'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></p>
            <p><strong>Total:</strong> $<?php echo number_format($pedido['total_convertido'] ?? $pedido['total'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></p>
            <?php if ($pedido['moneda'] == 'CUP' && !empty($pedido['tipo_cambio_usado'])): ?>
                <p><small>($<?php echo number_format($pedido['total'], 2); ?> USD - 1 USD = <?php echo number_format($pedido['tipo_cambio_usado'], 2); ?> CUP)</small></p>
            <?php endif; ?>
            <p><strong>Método pago:</strong> <?php echo ucfirst(htmlspecialchars($pedido['tipo_pago'])); ?></p>
            <p><strong>Estado actual:</strong> 
                <span class="badge-estado badge-<?php echo htmlspecialchars($pedido['estado_actual']); ?>">
                    <?php echo ucfirst(str_replace('_', ' ', $pedido['estado_actual'])); ?>
                </span>
            </p>
            <p><strong>Estado pago:</strong> 
                <span class="badge-estado badge-<?php echo htmlspecialchars($pedido['estado_pago']); ?>">
                    <?php echo ucfirst(str_replace('_', ' ', $pedido['estado_pago'])); ?>
                </span>
            </p>
            <?php if (floatval($pedido['monto_pagado'] ?? 0) > 0): ?>
                <p><strong>Pagado:</strong> $<?php echo number_format($pedido['monto_pagado'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></p>
            <?php endif; ?>
            <?php if (floatval($pedido['monto_pendiente'] ?? 0) > 0): ?>
                <p><strong>Pendiente:</strong> <span style="color: #f56565;">$<?php echo number_format($pedido['monto_pendiente'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></span></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Dirección de entrega -->
    <?php if ($direccion): ?>
    <h3>📍 Dirección de Entrega</h3>
    <div style="background: #f7fafc; border-radius: 8px; padding: 1rem; margin: 1rem 0;">
        <p><strong><?php echo htmlspecialchars($direccion['nombre_completo']); ?></strong></p>
        <p>Documento: <?php echo htmlspecialchars($direccion['documento']); ?></p>
        <p>Teléfono: <?php echo htmlspecialchars($direccion['telefono']); ?></p>
        <p>Dirección: <?php echo htmlspecialchars($direccion['direccion']); ?></p>
        <?php if (!empty($direccion['municipio'])): ?>
            <p>Municipio: <?php echo htmlspecialchars($direccion['municipio']); ?></p>
        <?php endif; ?>
        <?php if (!empty($direccion['provincia'])): ?>
            <p>Provincia: <?php echo htmlspecialchars($direccion['provincia']); ?></p>
        <?php endif; ?>
        <?php if (!empty($direccion['email'])): ?>
            <p>Email: <?php echo htmlspecialchars($direccion['email']); ?></p>
        <?php endif; ?>
        <?php if (!empty($direccion['instrucciones'])): ?>
            <p style="margin-top: 0.5rem; font-style: italic;">📝 <?php echo htmlspecialchars($direccion['instrucciones']); ?></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Productos -->
    <h3>Productos</h3>
    <table style="width:100%; border-collapse:collapse; margin-top:1rem;">
        <thead>
            <tr style="background: #edf2f7;">
                <th style="padding:0.8rem; text-align:left;">Producto</th>
                <th style="padding:0.8rem; text-align:right;">Precio Unit.</th>
                <th style="padding:0.8rem; text-align:center;">Cantidad</th>
                <th style="padding:0.8rem; text-align:right;">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total_usd = 0;
            $total_convertido = 0;
            while($item = $productos->fetch_assoc()): 
                $total_usd += $item['subtotal'];
                $total_convertido += $item['subtotal_convertido'] ?? $item['subtotal'];
            ?>
            <tr style="border-bottom:1px solid #e2e8f0;">
                <td style="padding:0.8rem;"><?php echo htmlspecialchars($item['nombre']); ?></td>
                <td style="padding:0.8rem; text-align:right;">
                    $<?php echo number_format($item['precio_unitario'], 2); ?> USD
                    <?php if ($pedido['moneda'] !== 'USD' && !empty($item['precio_convertido'])): ?>
                        <br><small style="color: #718096;"><?php echo number_format($item['precio_convertido'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></small>
                    <?php endif; ?>
                </td>
                <td style="padding:0.8rem; text-align:center;"><?php echo intval($item['cantidad']); ?></td>
                <td style="padding:0.8rem; text-align:right;">
                    $<?php echo number_format($item['subtotal'], 2); ?> USD
                    <?php if ($pedido['moneda'] !== 'USD' && !empty($item['subtotal_convertido'])): ?>
                        <br><small style="color: #718096;"><?php echo number_format($item['subtotal_convertido'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></small>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr style="background: #f7fafc; font-weight:bold;">
                <td colspan="3" style="padding:0.8rem; text-align:right;">Subtotal USD:</td>
                <td style="padding:0.8rem; text-align:right;">$<?php echo number_format($total_usd, 2); ?> USD</td>
            </tr>
            <tr style="background: #f7fafc; font-weight:bold;">
                <td colspan="3" style="padding:0.8rem; text-align:right;">Envío (<?php echo htmlspecialchars($pedido['moneda']); ?>):</td>
                <td style="padding:0.8rem; text-align:right;">$<?php echo number_format($pedido['envio'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></td>
            </tr>
            <tr style="background: #f0fff4; font-weight:bold;">
                <td colspan="3" style="padding:0.8rem; text-align:right;">Total (<?php echo htmlspecialchars($pedido['moneda']); ?>):</td>
                <td style="padding:0.8rem; text-align:right;">$<?php echo number_format($pedido['total_convertido'] ?? $pedido['total'], 2); ?> <?php echo htmlspecialchars($pedido['moneda']); ?></td>
            </tr>
        </tfoot>
    </table>

    <!-- Historial de estados -->
    <h3 style="margin-top: 2rem;">📋 Historial</h3>
    <div style="background: #f7fafc; border-radius: 8px; padding: 1rem;">
        <?php if ($estados->num_rows > 0): ?>
            <?php while($est = $estados->fetch_assoc()): ?>
                <div style="display: flex; gap: 1rem; padding: 0.5rem; border-left: 3px solid <?php 
                    echo $est['estado'] == 'pago_confirmado' ? '#4299e1' : 
                        ($est['estado'] == 'empaquetado' ? '#ecc94b' : 
                        ($est['estado'] == 'entregado' ? '#48bb78' : 
                        ($est['estado'] == 'cancelado' ? '#f56565' : '#718096'))); ?>; margin-bottom: 0.5rem;">
                    <div style="min-width: 120px; font-weight: 600;"><?php echo ucfirst(str_replace('_', ' ', $est['estado'])); ?></div>
                    <div style="flex: 1;"><?php echo htmlspecialchars($est['observaciones'] ?? ''); ?></div>
                    <div style="min-width: 150px; color: #718096;">
                        <?php echo date('d/m/Y H:i', strtotime($est['fecha'])); ?>
                        <?php if ($est['usuario_nombre']): ?>
                            <br><small>por <?php echo htmlspecialchars($est['usuario_nombre']); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Sin historial</p>
        <?php endif; ?>
    </div>

    <!-- Incidencias -->
    <?php if ($incidencias->num_rows > 0): ?>
    <h3 style="margin-top: 2rem;">⚠️ Incidencias</h3>
    <div style="background: #fed7d7; border-radius: 8px; padding: 1rem;">
        <?php while($inc = $incidencias->fetch_assoc()): ?>
            <div style="padding: 0.5rem; border-bottom: 1px solid #feb2b2;">
                <p><strong><?php echo ucfirst(htmlspecialchars($inc['tipo'])); ?></strong> 
                   <?php if ($inc['producto_nombre']): ?>- <?php echo htmlspecialchars($inc['producto_nombre']); ?><?php endif; ?></p>
                <p><?php echo htmlspecialchars($inc['descripcion']); ?></p>
                <small style="color: #c53030;">
                    <?php echo date('d/m/Y H:i', strtotime($inc['fecha'])); ?> 
                    por <?php echo htmlspecialchars($inc['usuario_nombre'] ?? 'Sistema'); ?>
                </small>
            </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>

    <!-- Botón cerrar -->
    <div style="margin-top: 2rem; text-align:right;">
        <button onclick="window.parent.cerrarModal('modalDetallePedido')" 
                style="background:#718096; color:white; border:none; padding:0.5rem 1rem; border-radius:8px; cursor:pointer;">
            Cerrar
        </button>
    </div>
</div>

<style>
.badge-estado { padding: 2px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; display: inline-block; }
.badge-pendiente_pago { background: #fef5e7; color: #c05621; }
.badge-pendiente_parcial { background: #fef5e7; color: #744210; }
.badge-pendiente_entrega { background: #fef5e7; color: #744210; }
.badge-pendiente_entrega_pago { background: #fef5e7; color: #744210; }
.badge-pendiente_verificacion { background: #fef5e7; color: #744210; }
.badge-pendiente_pago_final { background: #e9d8fd; color: #6b46c1; }
.badge-empaquetado { background: #feebc8; color: #c05621; }
.badge-transporte { background: #e9d8fd; color: #6b46c1; }
.badge-entregado { background: #c6f6d5; color: #22543d; }
.badge-cancelado { background: #fed7d7; color: #c53030; }
.badge-incidencia { background: #fed7d7; color: #c05621; }
.badge-pendiente { background: #fef5e7; color: #c05621; }
.badge-pagado { background: #c6f6d5; color: #22543d; }
</style>
<?php
// ============================================
// HISTORIAL DE CARRITO CANCELADO (JSON/HTML)
// ============================================
// Devuelve HTML con el historial de cancelaciones de un carrito.
// Seguridad: sesión + rol + propiedad por proveedor + escape HTML.
// ============================================

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once '../includes/proveedor_utils.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    exit('<p>No autorizado</p>');
}

$rol = trim($_SESSION['rol'] ?? '');
$usuario_id = intval($_SESSION['usuario_id'] ?? 0);
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id, $rol));

// ============================================
// VALIDAR ROL
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor'];
if (!in_array($rol, $roles_permitidos, true)) {
    http_response_code(403);
    exit('<p>Sin permiso</p>');
}

// ============================================
// VALIDAR CARRITO_ID
// ============================================
$carrito_id = intval($_GET['id'] ?? 0);
if ($carrito_id <= 0) {
    http_response_code(400);
    exit('<div style="text-align:center; padding:2rem;">❌ ID de carrito inválido</div>');
}

// ============================================
// VALIDAR PROPIEDAD DEL CARRITO (si es proveedor)
// ============================================
if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT 1 FROM carritos WHERE id = ? AND proveedor_id = ? LIMIT 1");
    if (!$stmt_check) {
        http_response_code(500);
        exit('<p>Error de BD</p>');
    }
    $stmt_check->bind_param("ii", $carrito_id, $proveedor_id_usuario);
    $stmt_check->execute();
    $tiene_permiso = $stmt_check->get_result()->num_rows > 0;
    $stmt_check->close();

    if (!$tiene_permiso) {
        http_response_code(403);
        exit('<div style="text-align:center; padding:2rem;">❌ No tienes permiso para ver este carrito</div>');
    }
}

// ============================================
// BUSCAR HISTORIAL DE CANCELACIONES
// ============================================
$sql = "SELECT h.*, c.nombre, c.apellidos, c.email 
        FROM historial_carritos_cancelados h
        JOIN clientes c ON h.cliente_id = c.id
        WHERE h.carrito_id = ? 
        ORDER BY h.fecha_cancelacion DESC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    exit('<p>Error de BD</p>');
}
$stmt->bind_param("i", $carrito_id);
$stmt->execute();
$historial = $stmt->get_result();
$stmt->close();

if ($historial->num_rows === 0) {
    echo '<div style="text-align:center; padding:2rem;">📭 No hay historial de cancelaciones para este carrito</div>';
    exit;
}

while ($h = $historial->fetch_assoc()):
    $cancelacion_id = intval($h['id']);
    $h_nombre = $h['nombre'] ?? '';
    $h_apellidos = $h['apellidos'] ?? '';
    $h_email = $h['email'] ?? '';
    $h_fecha = $h['fecha_cancelacion'] ?? '';
    $h_motivo = $h['motivo'] ?? '';
    $h_total = floatval($h['total'] ?? 0);

    // Obtener productos de esta cancelación
    $sql_prod = "SELECT * FROM historial_carritos_cancelados_productos WHERE cancelacion_id = ?";
    $stmt_prod = $conn->prepare($sql_prod);
    if (!$stmt_prod) {
        echo '<p>Error al cargar productos</p>';
        continue;
    }
    $stmt_prod->bind_param("i", $cancelacion_id);
    $stmt_prod->execute();
    $productos = $stmt_prod->get_result();
    $stmt_prod->close();

    // Motivo legible
    $motivo_texto = 'Desconocido';
        switch ($h_motivo) {
        case 'cancelado_cliente':
            $motivo_texto = 'Cancelado por el cliente';
            break;
        case 'expirado_automatico':
            $motivo_texto = 'Expirado automático';
            break;
        case 'cancelado_admin':
        case 'cancelado_por_admin':
            $motivo_texto = 'Cancelado por administrador';
            break;
        case 'cancelado_no_pagado':
            $motivo_texto = 'Cancelado por falta de pago';
            break;
        default:
            $motivo_texto = $h_motivo;
    }
?>
    <div style="border-bottom: 1px solid #e2e8f0; margin-bottom: 1rem; padding-bottom: 1rem;">
        <h3 style="margin: 0 0 0.5rem 0; color: #2d3748;">📅 Cancelación #<?php echo $cancelacion_id; ?></h3>
        
        <!-- Información del cliente -->
        <div style="background: #f7fafc; padding: 0.8rem; border-radius: 8px; margin-bottom: 0.8rem;">
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; font-size: 0.85rem;">
                <div><strong>👤 Cliente:</strong> <?php echo htmlspecialchars($h_nombre . ' ' . $h_apellidos, ENT_QUOTES, 'UTF-8'); ?></div>
                <div><strong>📧 Email:</strong> <?php echo htmlspecialchars($h_email, ENT_QUOTES, 'UTF-8'); ?></div>
                <div><strong>📅 Fecha:</strong> <?php echo htmlspecialchars(date('d/m/Y H:i:s', strtotime($h_fecha)), ENT_QUOTES, 'UTF-8'); ?></div>
                <div><strong>⚠️ Motivo:</strong> <?php echo htmlspecialchars($motivo_texto, ENT_QUOTES, 'UTF-8'); ?></div>
                <div><strong>💰 Total cancelado:</strong> <span style="color: #f56565; font-weight: bold;">$<?php echo number_format($h_total, 2); ?></span></div>
            </div>
        </div>
        
        <!-- Tabla de productos -->
        <table style="width: 100%; border-collapse: collapse; font-size: 0.8rem;">
            <thead>
                <tr style="background: #edf2f7;">
                    <th style="padding: 0.5rem; text-align: left;">Producto</th>
                    <th style="padding: 0.5rem; text-align: center;">Cantidad</th>
                    <th style="padding: 0.5rem; text-align: right;">Precio</th>
                    <th style="padding: 0.5rem; text-align: right;">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                                <?php 
                $subtotal_total = 0;
                while($prod = $productos->fetch_assoc()): 
                    $prod_nombre = $prod['nombre'] ?? '';
                    $prod_cantidad = intval($prod['cantidad'] ?? 0);
                    $prod_precio = floatval($prod['precio_unitario'] ?? 0);
                    $prod_subtotal = floatval($prod['subtotal'] ?? 0);
                    $es_combo = !empty($prod['combo_id']);
                    $subtotal_total += $prod_subtotal;
                ?>
                <tr style="border-bottom: 1px solid #edf2f7;">
                    <td style="padding: 0.5rem;">
                        <?php if ($es_combo): ?>
                            🎁 <strong>Combo:</strong>
                        <?php endif; ?>
                        <?php echo htmlspecialchars($prod_nombre, ENT_QUOTES, 'UTF-8'); ?>
                    </td>
                    <td style="padding: 0.5rem; text-align: center;"><?php echo $prod_cantidad; ?></td>
                    <td style="padding: 0.5rem; text-align: right;">$<?php echo number_format($prod_precio, 2); ?></td>
                    <td style="padding: 0.5rem; text-align: right;">$<?php echo number_format($prod_subtotal, 2); ?></td>
                </tr>
                <?php endwhile; ?>
                                <tr style="background: #f7fafc; font-weight: bold;">
                    <td colspan="3" style="padding: 0.5rem; text-align: right;">TOTAL:</td>
                    <td style="padding: 0.5rem; text-align: right;">$<?php echo number_format($h_total, 2); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
<?php endwhile; ?>

<?php $conn->close(); ?>
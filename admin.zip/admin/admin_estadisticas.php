<?php
// ============================================
// ESTADÍSTICAS DE LA TIENDA (Analytics)
// Versión 27 Oct 2026
// Ubicación: /admin/admin_estadisticas.php
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';
require_once __DIR__ . '/../header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

$rol_actual = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

// ============================================
// PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    error_log("[admin_estadisticas] Permiso denegado. Rol: $rol_actual, usuario: $usuario_id_actual");
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// FECHAS
// ============================================
$hoy = date('Y-m-d');
$ayer = date('Y-m-d', strtotime('-1 day'));
$semana = date('Y-m-d', strtotime('-7 days'));
$mes = date('Y-m-d', strtotime('-30 days'));

// ============================================
// 1. VISITAS
// ============================================
$visitas_hoy = 0;
$visitas_ayer = 0;
$visitas_semana = 0;
$visitas_mes = 0;

$stmt = $conn->prepare("SELECT COUNT(DISTINCT session_id) as total FROM visitas WHERE DATE(fecha) = ?");
if ($stmt) {
    $stmt->bind_param("s", $hoy);
    $stmt->execute();
    $visitas_hoy = intval($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();
} else {
    error_log("[admin_estadisticas] prepare visitas_hoy: " . $conn->error);
}

$stmt = $conn->prepare("SELECT COUNT(DISTINCT session_id) as total FROM visitas WHERE DATE(fecha) = ?");
if ($stmt) {
    $stmt->bind_param("s", $ayer);
    $stmt->execute();
    $visitas_ayer = intval($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();
}

$stmt = $conn->prepare("SELECT COUNT(DISTINCT session_id) as total FROM visitas WHERE DATE(fecha) >= ?");
if ($stmt) {
    $stmt->bind_param("s", $semana);
    $stmt->execute();
    $visitas_semana = intval($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();
}

$stmt = $conn->prepare("SELECT COUNT(DISTINCT session_id) as total FROM visitas WHERE DATE(fecha) >= ?");
if ($stmt) {
    $stmt->bind_param("s", $mes);
    $stmt->execute();
    $visitas_mes = intval($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();
}

// ============================================
// 2. EMBUDO DE CONVERSIÓN (HOY)
// ============================================
$embudo_hoy = [
    'vieron_producto' => 0,
    'vieron_combo' => 0,
    'agregaron_carrito' => 0,
    'iniciaron_checkout' => 0,
    'completaron_pago' => 0
];

$stmt = $conn->prepare("SELECT 
    COUNT(DISTINCT CASE WHEN evento = 'ver_producto' THEN session_id END) as vieron_producto,
    COUNT(DISTINCT CASE WHEN evento = 'ver_combo' THEN session_id END) as vieron_combo,
    COUNT(DISTINCT CASE WHEN evento = 'agregar_carrito' THEN session_id END) as agregaron_carrito,
    COUNT(DISTINCT CASE WHEN evento = 'iniciar_checkout' THEN session_id END) as iniciaron_checkout,
    COUNT(DISTINCT CASE WHEN evento = 'completar_pago' THEN session_id END) as completaron_pago
    FROM eventos_conversion WHERE DATE(fecha) = ?");
if ($stmt) {
    $stmt->bind_param("s", $hoy);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row) {
        $embudo_hoy = [
            'vieron_producto' => intval($row['vieron_producto'] ?? 0),
            'vieron_combo' => intval($row['vieron_combo'] ?? 0),
            'agregaron_carrito' => intval($row['agregaron_carrito'] ?? 0),
            'iniciaron_checkout' => intval($row['iniciaron_checkout'] ?? 0),
            'completaron_pago' => intval($row['completaron_pago'] ?? 0),
        ];
    }
    $stmt->close();
} else {
    error_log("[admin_estadisticas] prepare embudo_hoy: " . $conn->error);
}

// ============================================
// 3. EMBUDO DE CONVERSIÓN (ESTA SEMANA)
// ============================================
$embudo_semana = [
    'vieron_producto' => 0,
    'vieron_combo' => 0,
    'agregaron_carrito' => 0,
    'iniciaron_checkout' => 0,
    'completaron_pago' => 0
];

$stmt = $conn->prepare("SELECT 
    COUNT(DISTINCT CASE WHEN evento = 'ver_producto' THEN session_id END) as vieron_producto,
    COUNT(DISTINCT CASE WHEN evento = 'ver_combo' THEN session_id END) as vieron_combo,
    COUNT(DISTINCT CASE WHEN evento = 'agregar_carrito' THEN session_id END) as agregaron_carrito,
    COUNT(DISTINCT CASE WHEN evento = 'iniciar_checkout' THEN session_id END) as iniciaron_checkout,
    COUNT(DISTINCT CASE WHEN evento = 'completar_pago' THEN session_id END) as completaron_pago
    FROM eventos_conversion WHERE DATE(fecha) >= ?");
if ($stmt) {
    $stmt->bind_param("s", $semana);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row) {
        $embudo_semana = [
            'vieron_producto' => intval($row['vieron_producto'] ?? 0),
            'vieron_combo' => intval($row['vieron_combo'] ?? 0),
            'agregaron_carrito' => intval($row['agregaron_carrito'] ?? 0),
            'iniciaron_checkout' => intval($row['iniciaron_checkout'] ?? 0),
            'completaron_pago' => intval($row['completaron_pago'] ?? 0),
        ];
    }
    $stmt->close();
} else {
    error_log("[admin_estadisticas] prepare embudo_semana: " . $conn->error);
}

// ============================================
// 4. PÁGINAS MÁS VISITADAS
// ============================================
$paginas = $conn->query("SELECT pagina, COUNT(*) as total FROM visitas GROUP BY pagina ORDER BY total DESC LIMIT 10");
if (!$paginas) {
    error_log("[admin_estadisticas] query paginas: " . $conn->error);
}

// ============================================
// 5. EVENTOS POR DÍA (ÚLTIMOS 7 DÍAS)
// ============================================
$eventos_diarios = $conn->query("
    SELECT 
        DATE(fecha) as dia,
        COUNT(DISTINCT CASE WHEN evento = 'ver_producto' THEN session_id END) as productos,
        COUNT(DISTINCT CASE WHEN evento = 'ver_combo' THEN session_id END) as combos,
        COUNT(DISTINCT CASE WHEN evento = 'agregar_carrito' THEN session_id END) as carritos,
        COUNT(DISTINCT CASE WHEN evento = 'iniciar_checkout' THEN session_id END) as checkout,
        COUNT(DISTINCT CASE WHEN evento = 'completar_pago' THEN session_id END) as pagos
    FROM eventos_conversion 
    WHERE DATE(fecha) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY DATE(fecha)
    ORDER BY dia DESC
");
if (!$eventos_diarios) {
    error_log("[admin_estadisticas] query eventos_diarios: " . $conn->error);
}

// ============================================
// 6. TASA DE CONVERSIÓN
// ============================================
$tasa_conversion = 0;
if ($embudo_hoy['vieron_producto'] > 0) {
    $tasa_conversion = round(($embudo_hoy['completaron_pago'] / $embudo_hoy['vieron_producto']) * 100, 1);
}

// Diferencia de visitas
$dif_visitas = $visitas_hoy - $visitas_ayer;
?>

<style>
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}
.stat-card {
    background: white;
    padding: clamp(1rem, 3vw, 1.2rem);
    border-radius: 16px;
    text-align: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    border-top: 3px solid var(--primary, #667eea);
}
.stat-number {
    font-size: clamp(1.5rem, 5vw, 2rem);
    font-weight: bold;
    color: var(--primary, #667eea);
}
.stat-label {
    color: #666;
    margin-top: 0.3rem;
    font-size: 0.8rem;
}
.stat-tendencia {
    font-size: 0.7rem;
    margin-top: 0.3rem;
}
.tendencia-up { color: #10b981; }
.tendencia-down { color: #ef4444; }

.embudo {
    display: flex;
    justify-content: space-between;
    gap: 0.5rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}
.embudo-item {
    flex: 1;
    background: #f8fafc;
    padding: 1rem;
    border-radius: 12px;
    text-align: center;
    min-width: 100px;
}
.embudo-numero {
    font-size: clamp(1.2rem, 4vw, 1.5rem);
    font-weight: bold;
    color: var(--primary, #667eea);
}
.embudo-label {
    font-size: 0.7rem;
    color: #666;
    margin-top: 0.3rem;
}
.embudo-flecha {
    font-size: 1.2rem;
    color: #cbd5e1;
    display: flex;
    align-items: center;
}

.section-title {
    margin: 1.5rem 0 1rem;
    font-size: clamp(1.05rem, 3.5vw, 1.2rem);
    color: #2d3748;
    border-left: 4px solid var(--primary, #667eea);
    padding-left: 0.8rem;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}
th, td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid #e2e8f0;
}
th {
    background: #f1f5f9;
    color: #334155;
    font-weight: 600;
    font-size: 0.8rem;
}
tr:hover td {
    background: #f8fafc;
}

.tasa-card {
    background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
    color: white;
    padding: clamp(1rem, 3vw, 1.2rem);
    border-radius: 16px;
    text-align: center;
    margin-bottom: 1.5rem;
}
.tasa-number {
    font-size: clamp(2rem, 7vw, 2.5rem);
    font-weight: bold;
}
.tasa-label {
    font-size: 0.8rem;
    opacity: 0.9;
}

.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

@media (max-width: 768px) {
    .container { padding: 0 1rem; }
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
    .embudo { flex-direction: column; }
    .embudo-flecha { transform: rotate(90deg); justify-content: center; }
    .embudo-item { min-width: auto; }
    th, td { padding: 0.5rem; font-size: 0.8rem; }
}
</style>

<div class="container">
    <h1>📊 Estadísticas de la Tienda</h1>
    <p style="color: #718096; margin-bottom: 2rem;">Monitorea el comportamiento de los clientes y la conversión</p>

    <!-- Tasa de conversión -->
    <div class="tasa-card">
        <div class="tasa-number"><?php echo htmlspecialchars((string)$tasa_conversion); ?>%</div>
        <div class="tasa-label">Tasa de conversión (hoy)</div>
        <div style="font-size: 0.7rem; margin-top: 0.3rem;">
            <?php echo intval($embudo_hoy['completaron_pago']); ?> compras de <?php echo intval($embudo_hoy['vieron_producto']); ?> visitantes que vieron productos
        </div>
    </div>

    <!-- Visitas -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><?php echo number_format($visitas_hoy); ?></div>
            <div class="stat-label">Visitas hoy (personas únicas)</div>
            <?php 
            $clase = $dif_visitas >= 0 ? 'tendencia-up' : 'tendencia-down';
            $signo = $dif_visitas >= 0 ? '+' : '';
            ?>
            <div class="stat-tendencia <?php echo $clase; ?>"><?php echo $signo . number_format($dif_visitas); ?> vs ayer</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?php echo number_format($visitas_semana); ?></div>
            <div class="stat-label">Visitas últimos 7 días</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?php echo number_format($visitas_mes); ?></div>
            <div class="stat-label">Visitas últimos 30 días</div>
        </div>
    </div>

    <!-- Embudo HOY -->
    <div class="section-title">🎯 Embudo de Conversión - Hoy</div>
    <div class="embudo">
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_hoy['vieron_producto']); ?></div>
            <div class="embudo-label">👁️ Vieron producto</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_hoy['vieron_combo']); ?></div>
            <div class="embudo-label">🎁 Vieron combo</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_hoy['agregaron_carrito']); ?></div>
            <div class="embudo-label">🛒 Agregaron al carrito</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_hoy['iniciaron_checkout']); ?></div>
            <div class="embudo-label">📋 Iniciaron checkout</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_hoy['completaron_pago']); ?></div>
            <div class="embudo-label">✅ Completaron pago</div>
        </div>
    </div>

    <!-- Embudo SEMANA -->
    <div class="section-title">📈 Embudo de Conversión - Últimos 7 días</div>
    <div class="embudo">
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_semana['vieron_producto']); ?></div>
            <div class="embudo-label">👁️ Vieron producto</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_semana['vieron_combo']); ?></div>
            <div class="embudo-label">🎁 Vieron combo</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_semana['agregaron_carrito']); ?></div>
            <div class="embudo-label">🛒 Agregaron al carrito</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_semana['iniciaron_checkout']); ?></div>
            <div class="embudo-label">📋 Iniciaron checkout</div>
        </div>
        <div class="embudo-flecha">→</div>
        <div class="embudo-item">
            <div class="embudo-numero"><?php echo number_format($embudo_semana['completaron_pago']); ?></div>
            <div class="embudo-label">✅ Completaron pago</div>
        </div>
    </div>

    <!-- Eventos por día -->
    <div class="section-title">📅 Eventos por día (últimos 7 días)</div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Productos vistos</th>
                    <th>Combos vistos</th>
                    <th>Agregados al carrito</th>
                    <th>Checkout iniciado</th>
                    <th>Pagos completados</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($eventos_diarios && $eventos_diarios->num_rows > 0): ?>
                    <?php while($row = $eventos_diarios->fetch_assoc()): 
                        $ts = strtotime($row['dia'] ?? '');
                        $fecha_str = ($ts !== false) ? date('d/m/Y', $ts) : '—';
                    ?>
                    <tr>
                        <td><?php echo $fecha_str; ?></td>
                        <td><?php echo intval($row['productos'] ?? 0); ?></td>
                        <td><?php echo intval($row['combos'] ?? 0); ?></td>
                        <td><?php echo intval($row['carritos'] ?? 0); ?></td>
                        <td><?php echo intval($row['checkout'] ?? 0); ?></td>
                        <td><strong><?php echo intval($row['pagos'] ?? 0); ?></strong></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align:center; color:#718096;">No hay eventos registrados en los últimos 7 días.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Páginas más visitadas -->
    <div class="section-title">📄 Páginas más visitadas</div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr><th>Página</th><th>Visitas</th></tr>
            </thead>
            <tbody>
                <?php if ($paginas && $paginas->num_rows > 0): ?>
                    <?php while($row = $paginas->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['pagina'] ?? ''); ?></td>
                        <td><?php echo intval($row['total'] ?? 0); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="2" style="text-align:center; color:#718096;">No hay visitas registradas.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
// No cerramos $conn (footer.php puede necesitarlo)
require_once __DIR__ . '/../footer.php';
?>
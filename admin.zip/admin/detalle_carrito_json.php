<?php
// ============================================
// DETALLE DE CARRITO (JSON/HTML)
// ============================================
// Devuelve HTML con el detalle de un carrito.
// - Ver: todos los roles permitidos.
// - Eliminar/cancelar: solo Super Admin y Proveedor.
// Seguridad: sesión + rol + propiedad por proveedor + escape HTML + CSRF.
// Moneda: usa la moneda real del carrito (carritos.moneda).
// ============================================

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../conexion.php';
require_once '../includes/proveedor_utils.php';
require_once '../includes/csrf.php';
require_once '../includes/moneda_funciones.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    exit('<p>No autorizado</p>');
}

$rol = trim($_SESSION['rol'] ?? '');
$usuario_id = intval($_SESSION['usuario_id'] ?? 0);
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id, $rol));

// ============================================
// VALIDAR ROL (ver)
// ============================================
$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor'];
if (!in_array($rol, $roles_ver, true)) {
    http_response_code(403);
    exit('<p>Sin permiso</p>');
}

// ============================================
// ¿PUEDE GESTIONAR? (eliminar/cancelar)
// Solo Super Admin y Proveedor.
// ============================================
$roles_gestion = ['Super Admin', 'Proveedor'];
$puede_gestionar = in_array($rol, $roles_gestion, true);

// ============================================
// VALIDAR CARRITO_ID
// ============================================
$carrito_id = intval($_GET['id'] ?? 0);
if ($carrito_id <= 0) {
    http_response_code(400);
    exit('<p>ID de carrito no válido</p>');
}

// ============================================
// OBTENER CARRITO (con filtro de proveedor)
// ============================================
if ($proveedor_id_usuario > 0) {
    $stmt = $conn->prepare("
        SELECT ca.*, c.nombre, c.apellidos, c.email, c.movil 
        FROM carritos ca 
        JOIN clientes c ON ca.cliente_id = c.id 
        WHERE ca.id = ? AND ca.proveedor_id = ?
    ");
    if (!$stmt) {
        http_response_code(500);
        exit('<p>Error de BD</p>');
    }
    $stmt->bind_param("ii", $carrito_id, $proveedor_id_usuario);
} else {
    $stmt = $conn->prepare("
        SELECT ca.*, c.nombre, c.apellidos, c.email, c.movil 
        FROM carritos ca 
        JOIN clientes c ON ca.cliente_id = c.id 
        WHERE ca.id = ?
    ");
    if (!$stmt) {
        http_response_code(500);
        exit('<p>Error de BD</p>');
    }
    $stmt->bind_param("i", $carrito_id);
}

$stmt->execute();
$carrito = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$carrito) {
    http_response_code(404);
    exit('<p>Carrito no encontrado</p>');
}

// ============================================
// MONEDA DEL CARRITO
// ============================================
$moneda_carrito = strtoupper($carrito['moneda'] ?? 'USD');
$simbolo_carrito = getSimboloPorMoneda($moneda_carrito);
$proveedor_id_carrito = intval($carrito['proveedor_id'] ?? 0);

// ============================================
// OBTENER PRODUCTOS
// ============================================
$stmt = $conn->prepare("
    SELECT cp.*, p.nombre, p.cantidad as stock_actual 
    FROM carrito_productos cp 
    JOIN productos p ON cp.producto_id = p.id 
    WHERE cp.carrito_id = ? AND (cp.es_combo = 0 OR cp.es_combo IS NULL)
");
if (!$stmt) {
    http_response_code(500);
    exit('<p>Error de BD</p>');
}
$stmt->bind_param("i", $carrito_id);
$stmt->execute();
$productos = $stmt->get_result();
$stmt->close();

// ============================================
// OBTENER COMBOS
// ============================================
$stmt = $conn->prepare("
    SELECT cc.*, c.nombre as nombre_combo, c.stock_combo
    FROM carrito_combos cc 
    JOIN combos c ON cc.combo_id = c.id 
    WHERE cc.carrito_id = ?
");
if (!$stmt) {
    http_response_code(500);
    exit('<p>Error de BD</p>');
}
$stmt->bind_param("i", $carrito_id);
$stmt->execute();
$combos = $stmt->get_result();
$stmt->close();

// ============================================
// CSRF TOKEN
// ============================================
$csrf_token_actual = $_SESSION['csrf_token'] ?? '';

// ============================================
// HELPER: Precio convertido a la moneda del carrito
// ============================================
function calcularPrecioConvertido($item, $moneda_carrito, $conn, $proveedor_id) {
    $precio_convertido = floatval($item['precio_convertido'] ?? 0);
    if ($precio_convertido > 0) {
        return $precio_convertido;
    }
    $tasa = floatval($item['tasa_aplicada'] ?? 0);
    if ($tasa <= 0) {
        $tasa = getTasaProveedor($conn, $proveedor_id, $moneda_carrito);
    }
    if ($tasa > 0) {
        return floatval($item['precio_unitario'] ?? $item['precio_total'] ?? 0) * $tasa;
    }
    return floatval($item['precio_unitario'] ?? $item['precio_total'] ?? 0);
}
?>

<div style="padding: 1rem;">
    <h2>🛒 Carrito #<?php echo intval($carrito['id']); ?></h2>
    
    <!-- Info del cliente -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 1rem 0; padding: 1rem; background: #f7fafc; border-radius: 8px;">
        <div>
            <p><strong>Cliente:</strong> <?php echo htmlspecialchars($carrito['nombre'] . ' ' . $carrito['apellidos'], ENT_QUOTES, 'UTF-8'); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($carrito['email'], ENT_QUOTES, 'UTF-8'); ?></p>
            <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($carrito['movil'] ?? '', ENT_QUOTES, 'UTF-8'); ?></p>
        </div>
        <div>
            <p><strong>Inicio:</strong> <?php echo date('d/m/Y H:i', strtotime($carrito['fecha_inicio'])); ?></p>
            <p><strong>Expira:</strong> <?php echo $carrito['fecha_expiracion'] ? date('d/m/Y H:i', strtotime($carrito['fecha_expiracion'])) : '-'; ?></p>
            <p><strong>Moneda:</strong> <?php echo htmlspecialchars($moneda_carrito, ENT_QUOTES, 'UTF-8'); ?></p>
            <p><strong>Estado:</strong> 
                <span class="badge-estado badge-<?php echo htmlspecialchars($carrito['estado'], ENT_QUOTES, 'UTF-8'); ?>">
                    <?php echo htmlspecialchars(ucfirst($carrito['estado']), ENT_QUOTES, 'UTF-8'); ?>
                </span>
            </p>
        </div>
    </div>

    <!-- PRODUCTOS -->
    <h3>Productos</h3>
    
    <?php if ($productos->num_rows > 0): ?>
    <table style="width:100%; border-collapse:collapse; margin-top:1rem;">
        <thead>
            <tr style="background: #edf2f7;">
                <th style="padding:0.8rem; text-align:left;">Producto</th>
                <th style="padding:0.8rem; text-align:right;">Precio</th>
                <th style="padding:0.8rem; text-align:center;">Cantidad</th>
                <th style="padding:0.8rem; text-align:right;">Subtotal</th>
                <th style="padding:0.8rem; text-align:center;">Stock</th>
                <?php if ($carrito['estado'] == 'pendiente' && $puede_gestionar): ?>
                    <th style="padding:0.8rem; text-align:center;">Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total_productos = 0;
            while($p = $productos->fetch_assoc()): 
                $precio_unitario_mostrar = calcularPrecioConvertido($p, $moneda_carrito, $conn, $proveedor_id_carrito);
                $subtotal = $p['cantidad'] * $precio_unitario_mostrar;
                $total_productos += $subtotal;
            ?>
            <tr style="border-bottom:1px solid #e2e8f0;">
                <td style="padding:0.8rem;"><?php echo htmlspecialchars($p['nombre'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td style="padding:0.8rem; text-align:right;">
                    <?php echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8'); ?><?php echo number_format($precio_unitario_mostrar, 2); ?>
                    <?php if ($moneda_carrito !== 'USD'): ?>
                        <br><small style="color:#718096;">$<?php echo number_format($p['precio_unitario'], 2); ?> USD</small>
                    <?php endif; ?>
                </td>
                <td style="padding:0.8rem; text-align:center;"><?php echo intval($p['cantidad']); ?></td>
                <td style="padding:0.8rem; text-align:right;"><?php echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8'); ?><?php echo number_format($subtotal, 2); ?></td>
                <td style="padding:0.8rem; text-align:center;"><?php echo intval($p['stock_actual']); ?></td>
                
                <?php if ($carrito['estado'] == 'pendiente' && $puede_gestionar): ?>
                    <td style="padding:0.8rem; text-align:center;">
                        <form method="POST" action="carritos_gestion.php" style="display:inline;" onsubmit="return confirm('¿Eliminar producto del carrito? Se devolverá el stock.')">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token_actual, ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="accion" value="eliminar_producto">
                            <input type="hidden" name="carrito_id" value="<?php echo intval($carrito_id); ?>">
                            <input type="hidden" name="producto_id" value="<?php echo intval($p['producto_id']); ?>">
                            <button type="submit" style="background:#f56565; color:white; padding:0.3rem 0.6rem; border-radius:4px; border:none; cursor:pointer;">🗑️</button>
                        </form>
                    </td>
                <?php endif; ?>
            </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr style="background:#f7fafc; font-weight:bold;">
                <td colspan="3" style="padding:0.8rem; text-align:right;">Total productos:</td>
                <td style="padding:0.8rem; text-align:right;"><?php echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8'); ?><?php echo number_format($total_productos, 2); ?></td>
                <td colspan="<?php echo ($carrito['estado'] == 'pendiente' && $puede_gestionar) ? 2 : 1; ?>"></td>
            </tr>
        </tfoot>
    </table>
    <?php else: ?>
        <p>No hay productos en este carrito.</p>
    <?php endif; ?>

    <!-- COMBOS -->
    <?php if ($combos->num_rows > 0): ?>
    <h3 style="margin-top: 2rem;">Combos</h3>
    
    <table style="width:100%; border-collapse:collapse; margin-top:1rem;">
        <thead>
            <tr style="background: #edf2f7;">
                <th style="padding:0.8rem; text-align:left;">Combo</th>
                <th style="padding:0.8rem; text-align:right;">Precio unitario</th>
                <th style="padding:0.8rem; text-align:center;">Cantidad</th>
                <th style="padding:0.8rem; text-align:right;">Subtotal</th>
                <th style="padding:0.8rem; text-align:center;">Stock</th>
                <?php if ($carrito['estado'] == 'pendiente' && $puede_gestionar): ?>
                    <th style="padding:0.8rem; text-align:center;">Acciones</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total_combos = 0;
            while($c = $combos->fetch_assoc()): 
                $precio_total_convertido = calcularPrecioConvertido($c, $moneda_carrito, $conn, $proveedor_id_carrito);
                $cantidad_combo = max(1, intval($c['cantidad']));
                $precio_unitario_combo = $precio_total_convertido / $cantidad_combo;
                $subtotal = $precio_total_convertido;
                $total_combos += $subtotal;
            ?>
            <tr style="border-bottom:1px solid #e2e8f0;">
                <td style="padding:0.8rem;">📦 <?php echo htmlspecialchars($c['nombre_combo'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td style="padding:0.8rem; text-align:right;">
                    <?php echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8'); ?><?php echo number_format($precio_unitario_combo, 2); ?>
                    <?php if ($moneda_carrito !== 'USD'): ?>
                        <br><small style="color:#718096;">$<?php echo number_format($c['precio_total'], 2); ?> USD (total)</small>
                    <?php endif; ?>
                </td>
                <td style="padding:0.8rem; text-align:center;"><?php echo intval($c['cantidad']); ?></td>
                <td style="padding:0.8rem; text-align:right;"><?php echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8'); ?><?php echo number_format($subtotal, 2); ?></td>
                <td style="padding:0.8rem; text-align:center;"><?php echo intval($c['stock_combo']); ?></td>
                
                <?php if ($carrito['estado'] == 'pendiente' && $puede_gestionar): ?>
                    <td style="padding:0.8rem; text-align:center;">
                        <form method="POST" action="carritos_gestion.php" style="display:inline;" onsubmit="return confirm('¿Eliminar combo del carrito? Se devolverá el stock.')">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token_actual, ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="accion" value="eliminar_combo">
                            <input type="hidden" name="carrito_id" value="<?php echo intval($carrito_id); ?>">
                            <input type="hidden" name="combo_id" value="<?php echo intval($c['combo_id']); ?>">
                            <button type="submit" style="background:#f56565; color:white; padding:0.3rem 0.6rem; border-radius:4px; border:none; cursor:pointer;">🗑️</button>
                        </form>
                    </td>
                <?php endif; ?>
            </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr style="background:#f7fafc; font-weight:bold;">
                <td colspan="3" style="padding:0.8rem; text-align:right;">Total combos:</td>
                <td style="padding:0.8rem; text-align:right;"><?php echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8'); ?><?php echo number_format($total_combos, 2); ?></td>
                <td colspan="<?php echo ($carrito['estado'] == 'pendiente' && $puede_gestionar) ? 2 : 1; ?>"></td>
            </tr>
        </tfoot>
    </table>
    <?php endif; ?>

    <!-- TOTAL GENERAL -->
    <?php 
    $total_general = ($total_productos ?? 0) + ($total_combos ?? 0);
    ?>
    <div style="margin-top: 1.5rem; padding: 1rem; background: #f0fff4; border-radius: 8px; font-size: 1.2rem; font-weight: bold; text-align: right;">
        Total: <?php echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8'); ?><?php echo number_format($total_general, 2); ?> <?php echo htmlspecialchars($moneda_carrito, ENT_QUOTES, 'UTF-8'); ?>
    </div>

    <?php if ($carrito['estado'] == 'pendiente' && $puede_gestionar): ?>
    <div style="margin-top: 1rem;">
        <form method="POST" action="carritos_gestion.php" style="display:inline;" onsubmit="return confirm('¿Cancelar todo el carrito? Se devolverá el stock de todos los productos y combos.')">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token_actual, ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" name="accion" value="cancelar_carrito">
            <input type="hidden" name="carrito_id" value="<?php echo intval($carrito['id']); ?>">
            <button type="submit" style="background:#f56565; color:white; padding:0.5rem 1rem; border-radius:4px; border:none; cursor:pointer; font-size:1rem;">❌ Cancelar Carrito</button>
        </form>
    </div>
    <?php endif; ?>
</div>

<style>
.badge-pendiente { background: #ecc94b; padding: 2px 8px; border-radius: 12px; color: white; }
.badge-comprado { background: #48bb78; padding: 2px 8px; border-radius: 12px; color: white; }
.badge-cancelado { background: #f56565; padding: 2px 8px; border-radius: 12px; color: white; }
.badge-expirado { background: #a0aec0; padding: 2px 8px; border-radius: 12px; color: white; }
</style>
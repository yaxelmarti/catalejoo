<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}

// ============================================
// CONFIGURACIÓN DE SESIÓN SEGURA
// ============================================
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/moneda_funciones.php';
require_once __DIR__ . '/../../header.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$rol_actual = $_SESSION['rol'] ?? '';
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor', 'Inventario'];
if (!in_array($rol_actual, $roles_permitidos)) {
    header('Location: /admin.php?error=permiso');
    exit;
}

$es_super_admin = ($rol_actual === 'Super Admin');
$proveedor_id_filtro = intval(obtenerProveedorId($conn, $_SESSION['usuario_id'], $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_filtro == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// ============================================
// OBTENER COLORES DE CONFIGURACIÓN
// ============================================
$stmt_color = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario'");
$stmt_color->execute();
$result_color = $stmt_color->get_result();
$color_primario = $result_color->num_rows > 0 ? $result_color->fetch_assoc()['valor'] : '#667eea';
$stmt_color->close();

$stmt_color2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario'");
$stmt_color2->execute();
$result_color2 = $stmt_color2->get_result();
$color_secundario = $result_color2->num_rows > 0 ? $result_color2->fetch_assoc()['valor'] : '#764ba2';
$stmt_color2->close();

// ============================================
// OBTENER CATEGORÍAS Y PROVEEDORES
// ============================================
$categorias = $conn->query("SELECT id, nombre, icono FROM categorias WHERE activo = 1 ORDER BY nombre");
$proveedores = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda");

// ============================================
// CACHÉ DE MONEDAS POR PROVEEDOR (ADQUISICIÓN)
// ============================================
$monedas_cache = [];
$obtener_monedas_proveedor = function($conn, $proveedor_id) use (&$monedas_cache) {
    $proveedor_id = intval($proveedor_id);
    if (!isset($monedas_cache[$proveedor_id])) {
        $monedas = getMonedasParaAdquisicion($conn, $proveedor_id);
        $monedas_cache[$proveedor_id] = $monedas;
    }
    return $monedas_cache[$proveedor_id];
};

// ============================================
// PARÁMETROS DE PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100]) ? $por_pagina : 25;

$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// CONTAR TOTAL DE PRODUCTOS
// ============================================
if ($proveedor_id_filtro > 0) {
    $stmt_count = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE activo = 1 AND proveedor_id = ?");
    $stmt_count->bind_param("i", $proveedor_id_filtro);
    $stmt_count->execute();
    $total_registros = $stmt_count->get_result()->fetch_assoc()['total'];
    $stmt_count->close();
} else {
    $count_result = $conn->query("SELECT COUNT(*) as total FROM productos WHERE activo = 1");
    $total_registros = $count_result->fetch_assoc()['total'];
}

$total_paginas = max(1, ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// OBTENER PRODUCTOS
// ============================================
if ($proveedor_id_filtro > 0) {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 AND p.proveedor_id = ?
            ORDER BY p.id ASC
            LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $proveedor_id_filtro, $por_pagina, $offset);
} else {
    $sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono
            FROM productos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            WHERE p.activo = 1 
            ORDER BY p.id ASC
            LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $por_pagina, $offset);
}

$stmt->execute();
$productos = $stmt->get_result();
$stmt->close();

// ============================================
// TASAS GLOBALES DE MONEDAS (para cálculo en vivo)
// ============================================
$tasas_masivo = ['USD' => 1.00];

$productos->data_seek(0);
while ($p_tmp = $productos->fetch_assoc()) {
    $prov_id = intval($p_tmp['proveedor_id'] ?? 0);
    $mon_prod = strtoupper($p_tmp['moneda_adquisicion'] ?? 'USD');
    if ($mon_prod === 'USD') {
        $tasas_masivo['USD'] = 1.00;
        continue;
    }
    if ($mon_prod !== '' && !isset($tasas_masivo[$mon_prod])) {
        $tasa = getTasaProveedor($conn, $prov_id, $mon_prod);
        $tasas_masivo[$mon_prod] = ($tasa > 0) ? $tasa : 0;
    }
}
$productos->data_seek(0);

// ============================================
// CSRF TOKEN
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Edición Masiva - Productos</title>
    <style>
        :root {
            --primary: <?php echo $color_primario; ?>;
            --secondary: <?php echo $color_secundario; ?>;
            --danger: #ef4444;
            --success: #22c55e;
            --gray: #6b7280;
            --light-gray: #f3f4f6;
            --border: #e2e8f0;
            --radius: 10px;
            --shadow: 0 2px 8px rgba(0,0,0,0.06);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #f8fafc;
            padding-top: 130px;
            color: #1f2937;
            line-height: 1.5;
        }

        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 0 1rem 2rem;
        }

        @media (min-width: 768px) {
            .container { padding: 0 2rem 2rem; }
        }

        .header-edicion {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border);
        }

        .header-edicion h1 {
            font-size: 1.5rem;
            color: #1f2937;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        @media (min-width: 768px) {
            .header-edicion h1 { font-size: 1.8rem; }
        }

        .header-actions {
            display: flex;
            gap: 0.8rem;
            flex-wrap: wrap;
            align-items: center;
        }

        .btn {
            padding: 0.6rem 1.2rem;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
        }

        @media (min-width: 768px) {
            .btn { padding: 0.7rem 1.5rem; font-size: 0.9rem; }
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: #16a34a;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(34, 197, 94, 0.3);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: var(--light-gray);
            color: #374151;
            border: 1px solid var(--border);
        }

        .btn-secondary:hover { background: #e5e7eb; }

        .btn-volver {
            background: var(--light-gray);
            color: #374151;
            border: 1px solid var(--border);
        }

        .btn-volver:hover { background: #e5e7eb; transform: translateY(-2px); }

        .btn-upload {
            background: #4299e1;
            color: white;
            padding: 0.3rem 0.6rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.65rem;
            font-weight: 600;
            white-space: nowrap;
        }

        .btn-upload:hover { background: #3182ce; }

        .paginacion-controls {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            align-items: center;
            margin-bottom: 1.5rem;
            background: white;
            padding: 0.8rem 1rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
        }

        .paginacion-controls label {
            font-size: 0.85rem;
            font-weight: 600;
            color: #4a5568;
        }

        .paginacion-controls select {
            padding: 0.4rem 0.8rem;
            border: 2px solid var(--border);
            border-radius: 8px;
            font-size: 0.85rem;
            background: white;
            cursor: pointer;
        }

        .paginacion-controls select:focus {
            outline: none;
            border-color: var(--primary);
        }

        .paginacion-info {
            font-size: 0.85rem;
            color: #6b7280;
            margin-left: auto;
        }

        @media (max-width: 640px) {
            .paginacion-info { width: 100%; text-align: center; }
        }

        .paginacion-botones {
            display: flex;
            gap: 0.3rem;
            flex-wrap: wrap;
        }

        .paginacion-botones a,
        .paginacion-botones span {
            padding: 0.3rem 0.7rem;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.3s;
            border: 1px solid var(--border);
            background: white;
            color: #374151;
            min-width: 35px;
            text-align: center;
        }

        .paginacion-botones a:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .paginacion-botones .active {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-color: var(--primary);
        }

        .paginacion-botones .disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        .tabla-wrapper {
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            overflow: hidden;
            width: 100%;
            max-width: 100%;
        }

        .tabla-scroll {
            overflow-x: visible;
            padding: 0 0.5rem;
        }

        @media (min-width: 768px) {
            .tabla-scroll { padding: 0 1rem; }
        }

        .tabla-edicion {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.75rem;
            table-layout: fixed;
        }

        @media (min-width: 768px) {
            .tabla-edicion { font-size: 0.85rem; }
        }

        .tabla-edicion th {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 0.6rem 0.3rem;
            text-align: left;
            font-weight: 600;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        @media (min-width: 768px) {
            .tabla-edicion th { padding: 0.8rem 0.5rem; font-size: 0.75rem; }
        }

        .tabla-edicion td {
            padding: 0.4rem 0.2rem;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
            max-width: 100%;
            overflow: hidden;
        }

        @media (min-width: 768px) {
            .tabla-edicion td { padding: 0.5rem 0.4rem; }
        }

        .tabla-edicion tr:hover { background: #f8fafc; }

        .tabla-edicion input[type="text"],
        .tabla-edicion input[type="number"],
        .tabla-edicion select {
            width: 100%;
            padding: 0.3rem 0.4rem;
            border: 2px solid var(--border);
            border-radius: 6px;
            font-size: 0.7rem;
            transition: all 0.3s;
            background: white;
            min-width: 0;
            box-sizing: border-box;
        }

        @media (min-width: 768px) {
            .tabla-edicion input[type="text"],
            .tabla-edicion input[type="number"],
            .tabla-edicion select {
                padding: 0.4rem 0.6rem;
                font-size: 0.8rem;
                min-width: 0;
            }
        }

        .tabla-edicion input:focus,
        .tabla-edicion select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .tabla-edicion input.changed,
        .tabla-edicion select.changed {
            border-color: var(--success);
            background: #f0fff4;
        }

        .tabla-edicion input[readonly] {
            background: #f7fafc !important;
            cursor: not-allowed !important;
        }

        .tabla-edicion .checkbox-cell { text-align: center; }

        .tabla-edicion input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
            cursor: pointer;
        }

        .badge-categoria {
            background: #eef2ff;
            color: #4f46e5;
            padding: 0.1rem 0.4rem;
            border-radius: 12px;
            font-size: 0.6rem;
            white-space: nowrap;
        }

        @media (min-width: 768px) {
            .badge-categoria { padding: 0.15rem 0.5rem; font-size: 0.7rem; }
        }

        .img-preview {
            width: 45px;
            height: 45px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
            max-width: 100%;
        }

        .img-preview-empty {
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f3f4f6;
            border-radius: 6px;
            border: 1px dashed #d1d5db;
            color: #9ca3af;
            font-size: 0.6rem;
        }

        .upload-group {
            display: flex;
            gap: 0.3rem;
            align-items: center;
            flex-wrap: nowrap;
        }

        .upload-group input[type="file"] { display: none; }
        .upload-group input[type="text"] { min-width: 0 !important; flex: 1; }

        .proveedor-fijo {
            padding: 0.3rem 0.4rem;
            background: #f7fafc;
            border: 2px solid var(--border);
            border-radius: 6px;
            font-size: 0.7rem;
            color: #4a5568;
            display: block;
            min-width: 0;
        }

        @media (min-width: 768px) {
            .proveedor-fijo { padding: 0.4rem 0.6rem; font-size: 0.8rem; }
        }

        .tabla-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            padding: 1rem;
            background: #f8fafc;
            border-top: 1px solid var(--border);
        }

        .tabla-footer .info {
            font-size: 0.8rem;
            color: #6b7280;
        }

        .tabla-footer .btn-guardar {
            padding: 0.7rem 2rem;
            font-size: 0.9rem;
        }

        @media (min-width: 768px) {
            .tabla-footer .btn-guardar { padding: 0.8rem 2.5rem; font-size: 1rem; }
        }

        .toast-container {
            position: fixed;
            top: 90px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
            width: 90%;
        }

        .toast {
            background: white;
            border-radius: 10px;
            padding: 0.8rem 1rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            margin-bottom: 0.8rem;
            border-left: 4px solid var(--success);
            animation: slideIn 0.3s ease;
            font-size: 0.85rem;
        }

        .toast.error { border-left-color: var(--danger); }
        .toast.info { border-left-color: var(--primary); }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @media (max-width: 768px) {
            .header-edicion { flex-direction: column; align-items: stretch; text-align: center; }
            .header-actions { justify-content: center; }
            .paginacion-controls { flex-direction: column; align-items: stretch; text-align: center; }
            .paginacion-botones { justify-content: center; }
            .tabla-footer { flex-direction: column; text-align: center; }
            .tabla-edicion td { padding: 0.3rem 0.1rem; }
            .tabla-edicion input[type="text"],
            .tabla-edicion input[type="number"],
            .tabla-edicion select {
                font-size: 0.65rem;
                padding: 0.2rem 0.3rem;
                min-width: 0;
            }
            .img-preview { width: 30px; height: 30px; }
            .img-preview-empty { width: 30px; height: 30px; font-size: 0.5rem; }
            .tabla-scroll { overflow-x: auto; -webkit-overflow-scrolling: touch; }
            .tabla-edicion { min-width: 900px; }
            .proveedor-fijo { font-size: 0.6rem; padding: 0.2rem 0.3rem; }
        }

        @media (max-width: 480px) {
            .tabla-edicion { font-size: 0.6rem; min-width: 800px; }
            .tabla-edicion th { font-size: 0.55rem; padding: 0.3rem 0.1rem; }
            .tabla-edicion input[type="text"],
            .tabla-edicion input[type="number"],
            .tabla-edicion select {
                font-size: 0.6rem;
                padding: 0.15rem 0.2rem;
                min-width: 0;
            }
        }

        .text-center { text-align: center; }
    </style>
</head>
<body>

<div class="container">
    <div class="header-edicion">
        <h1>📊 Edición Masiva de Productos</h1>
        <div class="header-actions">
            <button type="button" class="btn btn-primary" onclick="agregarProductoVacio()" style="background: linear-gradient(135deg, #22c55e, #16a34a);">
                ➕ Nuevo Producto
            </button>
            <a href="/admin.php" class="btn btn-volver">← Volver al Panel</a>
        </div>
    </div>

    <div class="paginacion-controls">
        <label for="por_pagina">Mostrar:</label>
        <select id="por_pagina" onchange="cambiarPorPagina()">
            <option value="25" <?php echo $por_pagina == 25 ? 'selected' : ''; ?>>25</option>
            <option value="50" <?php echo $por_pagina == 50 ? 'selected' : ''; ?>>50</option>
            <option value="100" <?php echo $por_pagina == 100 ? 'selected' : ''; ?>>100</option>
        </select>
        <span style="font-size:0.85rem; color:#6b7280;">productos por página</span>

        <div class="paginacion-info">
            Mostrando <?php echo ($offset + 1); ?> - <?php echo min($offset + $por_pagina, $total_registros); ?> de <?php echo $total_registros; ?> productos
        </div>

        <div class="paginacion-botones">
            <?php if ($pagina_actual > 1): ?>
                <a href="?pagina=1&por_pagina=<?php echo $por_pagina; ?>">«</a>
                <a href="?pagina=<?php echo $pagina_actual - 1; ?>&por_pagina=<?php echo $por_pagina; ?>">‹</a>
            <?php else: ?>
                <span class="disabled">«</span>
                <span class="disabled">‹</span>
            <?php endif; ?>

            <?php
            $rango = 3;
            $inicio = max(1, $pagina_actual - $rango);
            $fin = min($total_paginas, $pagina_actual + $rango);

            if ($inicio > 1) {
                echo '<a href="?pagina=1&por_pagina=' . $por_pagina . '">1</a>';
                if ($inicio > 2) echo '<span>…</span>';
            }

            for ($i = $inicio; $i <= $fin; $i++) {
                if ($i == $pagina_actual) {
                    echo '<span class="active">' . $i . '</span>';
                } else {
                    echo '<a href="?pagina=' . $i . '&por_pagina=' . $por_pagina . '">' . $i . '</a>';
                }
            }

            if ($fin < $total_paginas) {
                if ($fin < $total_paginas - 1) echo '<span>…</span>';
                echo '<a href="?pagina=' . $total_paginas . '&por_pagina=' . $por_pagina . '">' . $total_paginas . '</a>';
            }
            ?>

            <?php if ($pagina_actual < $total_paginas): ?>
                <a href="?pagina=<?php echo $pagina_actual + 1; ?>&por_pagina=<?php echo $por_pagina; ?>">›</a>
                <a href="?pagina=<?php echo $total_paginas; ?>&por_pagina=<?php echo $por_pagina; ?>">»</a>
            <?php else: ?>
                <span class="disabled">›</span>
                <span class="disabled">»</span>
            <?php endif; ?>
        </div>
    </div>

    <form id="formEdicionMasiva" method="POST" action="guardar_masivo.php">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        <input type="hidden" name="por_pagina" value="<?php echo $por_pagina; ?>">
        <input type="hidden" name="pagina" value="<?php echo $pagina_actual; ?>">

        <div class="tabla-wrapper">
            <div class="tabla-scroll">
                <table class="tabla-edicion">
                    <thead>
                        <tr>
                            <th style="width:12%; font-size:0.65rem; text-align:center;">
                                Imagen<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">URL Imagen</span>
                            </th>
                            <th style="width:14%; font-size:0.65rem;">
                                Nombre<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">Peso</span>
                            </th>
                            <th style="width:14%; font-size:0.65rem;">
                                Descripción<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">Proveedor</span>
                            </th>
                            <th style="width:10%; font-size:0.65rem;">
                                Marca<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">Moneda</span>
                            </th>
                            <th style="width:10%; font-size:0.65rem;">
                                Categoría<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">Precio Adq.</span>
                            </th>
                            <th style="width:10%; font-size:0.65rem;">
                                Stock<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">% Ganancia</span>
                            </th>
                            <th style="width:10%; font-size:0.65rem;">
                                Costo USD<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">Precio Venta</span>
                            </th>
                            <th style="width:10%; font-size:0.65rem;">
                                Rebaja %<br><span style="font-weight:400; font-size:0.55rem; opacity:0.8;">Activo</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($productos && $productos->num_rows > 0): ?>
                            <?php while($p = $productos->fetch_assoc()): ?>
                                <tr style="border-bottom: none;">
                                    <input type="hidden" name="productos[<?php echo $p['id']; ?>][id]" value="<?php echo $p['id']; ?>">
                                    
                                    <td style="text-align:center;">
                                        <?php if (!empty($p['imagen_url'])): ?>
                                            <?php 
                                            $imagen_url = $p['imagen_url'];
                                            if (strpos($imagen_url, '/') !== 0) {
                                                $imagen_url = '/' . $imagen_url;
                                            }
                                            ?>
                                            <img src="<?php echo htmlspecialchars($imagen_url); ?>" 
                                                 alt="<?php echo htmlspecialchars($p['nombre']); ?>" 
                                                 class="img-preview"
                                                 onerror="this.style.display='none'; this.parentElement.innerHTML='<span class=\'img-preview-empty\'>📷</span>'">
                                        <?php else: ?>
                                            <span class="img-preview-empty">📷</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <input type="text" name="productos[<?php echo $p['id']; ?>][nombre]" 
                                               value="<?php echo htmlspecialchars($p['nombre']); ?>" 
                                               placeholder="Nombre" style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <input type="text" name="productos[<?php echo $p['id']; ?>][descripcion]" 
                                               value="<?php echo htmlspecialchars($p['descripcion'] ?? ''); ?>" 
                                               placeholder="Descripción" style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <input type="text" name="productos[<?php echo $p['id']; ?>][marca]" 
                                               value="<?php echo htmlspecialchars($p['marca'] ?? ''); ?>" 
                                               placeholder="Marca" style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <select name="productos[<?php echo $p['id']; ?>][categoria_id]" style="width:100%;">
                                            <option value="">Sin categoría</option>
                                            <?php 
                                            $categorias->data_seek(0);
                                            while($cat = $categorias->fetch_assoc()): 
                                                $selected = ($p['categoria_id'] == $cat['id']) ? 'selected' : '';
                                            ?>
                                                <option value="<?php echo $cat['id']; ?>" <?php echo $selected; ?>>
                                                    <?php echo $cat['icono'] ?? '📦'; ?> <?php echo htmlspecialchars($cat['nombre']); ?>
                                                </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </td>
                                    
                                    <td>
                                        <input type="number" name="productos[<?php echo $p['id']; ?>][cantidad]" 
                                               step="1" min="0" value="<?php echo $p['cantidad']; ?>" 
                                               placeholder="0" style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <input type="number" name="productos[<?php echo $p['id']; ?>][precio_costo]" 
                                               step="0.01" min="0" value="<?php echo $p['precio_costo']; ?>" 
                                               class="precio-costo-calculado"
                                               data-producto-id="<?php echo $p['id']; ?>"
                                               readonly
                                               style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <input type="number" name="productos[<?php echo $p['id']; ?>][porcentaje_rebaja]" 
                                               step="1" min="0" max="100" value="<?php echo $p['porcentaje_rebaja']; ?>" 
                                               class="calc-porc-rebaja"
                                               data-producto-id="<?php echo $p['id']; ?>"
                                               placeholder="0" style="width:100%;">
                                    </td>
                                </tr>
                                
                                <tr style="border-bottom: 3px solid #000000;">
                                    
                                    <td>
                                        <div class="upload-group">
                                            <input type="text" name="productos[<?php echo $p['id']; ?>][imagen_url]" 
                                                   value="<?php echo htmlspecialchars($p['imagen_url'] ?? ''); ?>" 
                                                   placeholder="/uploads/productos/..." style="flex:1; min-width:60px;">
                                            <input type="file" id="file_<?php echo $p['id']; ?>" 
                                                   accept="image/*" style="display:none;">
                                            <button type="button" class="btn-upload" onclick="document.getElementById('file_<?php echo $p['id']; ?>').click();">
                                                📤
                                            </button>
                                        </div>
                                    </td>
                                    
                                    <td>
                                        <input type="number" name="productos[<?php echo $p['id']; ?>][peso]" 
                                               step="0.001" min="0" value="<?php echo $p['peso']; ?>" 
                                               placeholder="0.000" style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <?php if ($es_super_admin): ?>
                                            <select name="productos[<?php echo $p['id']; ?>][proveedor_id]" style="width:100%;">
                                                <option value="">Sin proveedor</option>
                                                <?php 
                                                $proveedores->data_seek(0);
                                                while($prov = $proveedores->fetch_assoc()): 
                                                    $selected = ($p['proveedor_id'] == $prov['id']) ? 'selected' : '';
                                                ?>
                                                    <option value="<?php echo $prov['id']; ?>" <?php echo $selected; ?>>
                                                        <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                        <?php else: ?>
                                            <?php 
                                            $nombre_prov_actual = 'Sin proveedor';
                                            if ($proveedor_id_filtro > 0) {
                                                $stmt_pn = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                                                $stmt_pn->bind_param("i", $proveedor_id_filtro);
                                                $stmt_pn->execute();
                                                $row_pn = $stmt_pn->get_result()->fetch_assoc();
                                                if ($row_pn) $nombre_prov_actual = $row_pn['nombre_tienda'];
                                                $stmt_pn->close();
                                            }
                                            ?>
                                            <span class="proveedor-fijo">🏪 <?php echo htmlspecialchars($nombre_prov_actual); ?></span>
                                            <input type="hidden" name="productos[<?php echo $p['id']; ?>][proveedor_id]" value="<?php echo $proveedor_id_filtro; ?>">
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <select name="productos[<?php echo $p['id']; ?>][moneda_adquisicion]" 
                                                class="calc-moneda"
                                                data-producto-id="<?php echo $p['id']; ?>"
                                                style="width:100%;">
                                            <?php 
                                            $monedas_p = $obtener_monedas_proveedor($conn, $p['proveedor_id'] ?? 0);
                                            foreach ($monedas_p as $mon_p): 
                                                $sel_mon = ($p['moneda_adquisicion'] === $mon_p) ? 'selected' : '';
                                            ?>
                                                <option value="<?php echo htmlspecialchars($mon_p); ?>" <?php echo $sel_mon; ?>>
                                                    <?php echo htmlspecialchars($mon_p); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    
                                    <td>
                                        <input type="number" name="productos[<?php echo $p['id']; ?>][precio_adquisicion]" 
                                               step="0.01" min="0" value="<?php echo $p['precio_adquisicion']; ?>" 
                                               class="calc-precio-adq"
                                               data-producto-id="<?php echo $p['id']; ?>"
                                               placeholder="0.00" style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <input type="number" name="productos[<?php echo $p['id']; ?>][porcentaje_ganancia]" 
                                               step="0.01" min="0" max="999" value="<?php echo $p['porcentaje_ganancia']; ?>" 
                                               class="calc-porc-ganancia"
                                               data-producto-id="<?php echo $p['id']; ?>"
                                               placeholder="0" style="width:100%;">
                                    </td>
                                    
                                    <td>
                                        <input type="number" name="productos[<?php echo $p['id']; ?>][precio]" 
                                               step="0.01" min="0" value="<?php echo $p['precio']; ?>" 
                                               class="precio-venta-calculado"
                                               data-producto-id="<?php echo $p['id']; ?>"
                                               readonly
                                               style="width:100%;">
                                    </td>
                                    
                                    <td class="checkbox-cell" style="text-align:center;">
                                        <input type="checkbox" name="productos[<?php echo $p['id']; ?>][activo]" 
                                               value="1" <?php echo $p['activo'] ? 'checked' : ''; ?>>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center" style="padding: 2rem; color: #9ca3af;">
                                    📭 No hay productos disponibles
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="tabla-footer">
                <div class="info">
                    <?php if ($productos && $productos->num_rows > 0): ?>
                        <?php echo $productos->num_rows; ?> productos en esta página
                    <?php else: ?>
                        No hay productos
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-success btn-guardar">
                    💾 Guardar todos los cambios
                </button>
            </div>
        </div>
    </form>
</div>

<div id="toastContainer" class="toast-container"></div>

<script>
// ============================================
// TASAS DE MONEDAS (desde PHP)
// ============================================
window.TASAS_MONEDAS_MASIVO = <?php echo json_encode($tasas_masivo, JSON_UNESCAPED_UNICODE); ?>;

// ============================================
// CÁLCULO AUTOMÁTICO DE PRECIOS EN VIVO
// ============================================
function recalcularFilaMasiva(productoId) {
    const moneda = document.querySelector(`.calc-moneda[data-producto-id="${productoId}"]`);
    if (!moneda) return;
    
    const monedaVal = moneda.value;
    const precioAdq = parseFloat(document.querySelector(`.calc-precio-adq[data-producto-id="${productoId}"]`)?.value) || 0;
    const porcGanancia = parseFloat(document.querySelector(`.calc-porc-ganancia[data-producto-id="${productoId}"]`)?.value) || 0;
    const porcRebaja = parseFloat(document.querySelector(`.calc-porc-rebaja[data-producto-id="${productoId}"]`)?.value) || 0;
    
    const tasa = (monedaVal === 'USD') ? 1 : (window.TASAS_MONEDAS_MASIVO[monedaVal] || 0);
    
    // Si no hay tasa, no calcular
    if (monedaVal !== 'USD' && tasa <= 0) {
        const inputCosto = document.querySelector(`.precio-costo-calculado[data-producto-id="${productoId}"]`);
        const inputVenta = document.querySelector(`.precio-venta-calculado[data-producto-id="${productoId}"]`);
        if (inputCosto) inputCosto.value = '';
        if (inputVenta) inputVenta.value = '';
        return;
    }
    
    const precioCostoUsd = (monedaVal === 'USD') ? precioAdq : (precioAdq / tasa);
    const precioVenta = precioCostoUsd * (1 + porcGanancia / 100);
    
    let precioFinal = precioVenta;
    if (porcRebaja > 0) {
        precioFinal = precioVenta * (100 - porcRebaja) / 100;
    }
    
    const inputCosto = document.querySelector(`.precio-costo-calculado[data-producto-id="${productoId}"]`);
    const inputVenta = document.querySelector(`.precio-venta-calculado[data-producto-id="${productoId}"]`);
    
    if (inputCosto) inputCosto.value = precioCostoUsd.toFixed(2);
    if (inputVenta) inputVenta.value = precioFinal.toFixed(2);
}

function mostrarToast(mensaje, tipo = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${tipo}`;
    toast.innerHTML = mensaje;
    
    const btnCerrar = document.createElement('span');
    btnCerrar.innerHTML = ' ✕';
    btnCerrar.style.cssText = `
        float: right;
        cursor: pointer;
        font-weight: bold;
        margin-left: 10px;
        padding: 0 5px;
        color: #666;
        font-size: 16px;
    `;
    btnCerrar.onclick = function() {
        toast.remove();
    };
    
    toast.appendChild(btnCerrar);
    container.appendChild(toast);
}

function cambiarPorPagina() {
    const valor = document.getElementById('por_pagina').value;
    window.location.href = '?por_pagina=' + valor + '&pagina=1';
}

document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('.tabla-edicion input, .tabla-edicion select');
    inputs.forEach(input => {
        let valorOriginal = input.value;
        if (input.type === 'checkbox') {
            valorOriginal = input.checked ? '1' : '0';
        }
        
        input.addEventListener('change', function() {
            let valorActual = this.value;
            if (this.type === 'checkbox') {
                valorActual = this.checked ? '1' : '0';
            }
            
            if (valorActual !== valorOriginal) {
                this.classList.add('changed');
            } else {
                this.classList.remove('changed');
            }
        });
    });
    
    // Asignar eventos de cálculo
    document.querySelectorAll('.calc-moneda, .calc-precio-adq, .calc-porc-ganancia, .calc-porc-rebaja').forEach(el => {
        el.addEventListener('input', function() {
            const pid = this.getAttribute('data-producto-id');
            if (pid) recalcularFilaMasiva(pid);
        });
        el.addEventListener('change', function() {
            const pid = this.getAttribute('data-producto-id');
            if (pid) recalcularFilaMasiva(pid);
        });
    });
    
    // Calcular al cargar
    document.querySelectorAll('.calc-moneda').forEach(el => {
        const pid = el.getAttribute('data-producto-id');
        if (pid) recalcularFilaMasiva(pid);
    });
    
    document.querySelectorAll('input[type="file"]').forEach(function(input) {
        input.addEventListener('change', function(e) {
            const file = this.files[0];
            if (!file) return;
            
            const id = this.id.replace('file_', '');
            const urlInput = document.querySelector('input[name="productos[' + id + '][imagen_url]"]');
            const nombreInput = document.querySelector('input[name="productos[' + id + '][nombre]"]');
            
            if (!urlInput) {
                mostrarToast('❌ Error: No se encontró el campo de URL', 'error');
                this.value = '';
                return;
            }
            
            const formData = new FormData();
            formData.append('imagen', file);
            formData.append('producto_id', id);
            
            if (nombreInput && nombreInput.value.trim() !== '') {
                formData.append('nombre_producto', nombreInput.value.trim());
            } else {
                formData.append('nombre_producto', file.name.replace(/\.[^.]+$/, ''));
            }
            
            mostrarToast('⏳ Subiendo imagen...', 'info');
            
            fetch('upload_imagen_masiva.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    urlInput.value = data.url;
                    mostrarToast('✅ Imagen subida: ' + data.filename, 'success');
                    
                    const fila1 = this.closest('tr').previousElementSibling;
                    if (fila1) {
                        const celdaImagen = fila1.querySelector('td:first-child');
                        if (celdaImagen) {
                            celdaImagen.innerHTML = '<img src="' + data.url + '" alt="Producto" class="img-preview" onerror="this.style.display=\'none\'">';
                        }
                    }
                } else {
                    mostrarToast('❌ Error: ' + (data.error || 'desconocido'), 'error');
                }
            })
            .catch(function(error) {
                console.error('Error:', error);
                mostrarToast('❌ Error de conexión', 'error');
            });
            
            this.value = '';
        });
    });
});
    
<?php if (isset($_SESSION['mensaje_masivo'])): ?>
    mostrarToast('<?php echo addslashes($_SESSION['mensaje_masivo']); ?>', '<?php echo $_SESSION['tipo_mensaje_masivo'] ?? 'success'; ?>');
    <?php unset($_SESSION['mensaje_masivo']); unset($_SESSION['tipo_mensaje_masivo']); ?>
<?php endif; ?>

let contadorNuevos = 0;

function agregarProductoVacio() {
    contadorNuevos++;
    const idTemp = 'nuevo_' + contadorNuevos + '_' + Date.now();
    
    const tbody = document.querySelector('.tabla-edicion tbody');
    if (!tbody) return;
    
    const fila1 = document.createElement('tr');
    fila1.style.borderBottom = 'none';
    fila1.style.background = '#f0fdf4';
    
    const fila2 = document.createElement('tr');
    fila2.style.borderBottom = '3px solid #000000';
    fila2.style.background = '#f0fdf4';
    
    fila1.innerHTML = `
        <input type="hidden" name="productos[${idTemp}][id]" value="${idTemp}">
        <td style="text-align:center;">
            <span class="img-preview-empty">📷</span>
        </td>
        <td>
            <input type="text" name="productos[${idTemp}][nombre]" 
                   placeholder="Nombre" style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <input type="text" name="productos[${idTemp}][descripcion]" 
                   placeholder="Descripción" style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <input type="text" name="productos[${idTemp}][marca]" 
                   placeholder="Marca" style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <select name="productos[${idTemp}][categoria_id]" style="width:100%; border-color: #22c55e;">
                <option value="">Sin categoría</option>
                <?php 
                $categorias->data_seek(0);
                while($cat = $categorias->fetch_assoc()): 
                ?>
                    <option value="<?php echo $cat['id']; ?>">
                        <?php echo $cat['icono'] ?? '📦'; ?> <?php echo htmlspecialchars($cat['nombre']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </td>
        <td>
            <input type="number" name="productos[${idTemp}][cantidad]" 
                   step="1" min="0" placeholder="0" style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <input type="number" name="productos[${idTemp}][precio_costo]" 
                   step="0.01" min="0" placeholder="0.00"
                   class="precio-costo-calculado"
                   data-producto-id="${idTemp}"
                   readonly
                   style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <input type="number" name="productos[${idTemp}][porcentaje_rebaja]" 
                   step="1" min="0" max="100" placeholder="0"
                   class="calc-porc-rebaja"
                   data-producto-id="${idTemp}"
                   style="width:100%; border-color: #22c55e;">
        </td>
    `;
    
    fila2.innerHTML = `
        <td>
            <div class="upload-group">
                <input type="text" name="productos[${idTemp}][imagen_url]" 
                       placeholder="/uploads/productos/..." style="flex:1; min-width:60px; border-color: #22c55e;">
                <input type="file" id="file_${idTemp}" accept="image/*" style="display:none;">
                <button type="button" class="btn-upload" onclick="document.getElementById('file_${idTemp}').click();">
                    📤
                </button>
            </div>
        </td>
        <td>
            <input type="number" name="productos[${idTemp}][peso]" 
                   step="0.001" min="0" placeholder="0.000" style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <?php if ($es_super_admin): ?>
            <select name="productos[${idTemp}][proveedor_id]" style="width:100%; border-color: #22c55e;">
                <option value="">Sin proveedor</option>
                <?php 
                $proveedores->data_seek(0);
                while($prov = $proveedores->fetch_assoc()): 
                ?>
                    <option value="<?php echo $prov['id']; ?>">
                        <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <?php else: ?>
            <span class="proveedor-fijo">🏪 <?php 
                $nombre_prov_actual2 = 'Sin proveedor';
                if ($proveedor_id_filtro > 0) {
                    $stmt_pn2 = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                    $stmt_pn2->bind_param("i", $proveedor_id_filtro);
                    $stmt_pn2->execute();
                    $row_pn2 = $stmt_pn2->get_result()->fetch_assoc();
                    if ($row_pn2) $nombre_prov_actual2 = $row_pn2['nombre_tienda'];
                    $stmt_pn2->close();
                }
                echo htmlspecialchars($nombre_prov_actual2);
            ?></span>
            <input type="hidden" name="productos[${idTemp}][proveedor_id]" value="<?php echo $proveedor_id_filtro; ?>">
            <?php endif; ?>
        </td>
        <td>
            <select name="productos[${idTemp}][moneda_adquisicion]" 
                    class="calc-moneda"
                    data-producto-id="${idTemp}"
                    style="width:100%; border-color: #22c55e;">
                <?php 
                $monedas_new = $obtener_monedas_proveedor($conn, $proveedor_id_filtro);
                foreach ($monedas_new as $mon_n): 
                ?>
                    <option value="<?php echo htmlspecialchars($mon_n); ?>">
                        <?php echo htmlspecialchars($mon_n); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </td>
        <td>
            <input type="number" name="productos[${idTemp}][precio_adquisicion]" 
                   step="0.01" min="0" placeholder="0.00"
                   class="calc-precio-adq"
                   data-producto-id="${idTemp}"
                   style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <input type="number" name="productos[${idTemp}][porcentaje_ganancia]" 
                   step="0.01" min="0" max="999" placeholder="0"
                   class="calc-porc-ganancia"
                   data-producto-id="${idTemp}"
                   style="width:100%; border-color: #22c55e;">
        </td>
        <td>
            <input type="number" name="productos[${idTemp}][precio]" 
                   step="0.01" min="0" placeholder="0.00"
                   class="precio-venta-calculado"
                   data-producto-id="${idTemp}"
                   readonly
                   style="width:100%; border-color: #22c55e;">
        </td>
        <td class="checkbox-cell" style="text-align:center;">
            <input type="checkbox" name="productos[${idTemp}][activo]" value="1" checked>
        </td>
    `;
    
    const ultimoTR = tbody.querySelector('tr:last-child');
    if (ultimoTR && ultimoTR.querySelector('td[colspan]')) {
        tbody.innerHTML = '';
        tbody.appendChild(fila1);
        tbody.appendChild(fila2);
    } else {
        tbody.appendChild(fila1);
        tbody.appendChild(fila2);
    }
    
    const fila1Ref = fila1;
    const fila2Ref = fila2;
    
    // Asignar eventos de cálculo al nuevo producto
    fila1Ref.querySelectorAll('.calc-porc-rebaja').forEach(el => {
        el.addEventListener('input', function() {
            recalcularFilaMasiva(idTemp);
        });
        el.addEventListener('change', function() {
            recalcularFilaMasiva(idTemp);
        });
    });
    
    fila2Ref.querySelectorAll('.calc-moneda, .calc-precio-adq, .calc-porc-ganancia').forEach(el => {
        el.addEventListener('input', function() {
            recalcularFilaMasiva(idTemp);
        });
        el.addEventListener('change', function() {
            recalcularFilaMasiva(idTemp);
        });
    });
    
    const fileInput = fila2.querySelector('input[type="file"]');
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            const file = this.files[0];
            if (!file) return;
            
            const idTemp2 = this.id.replace('file_', '');
            const urlInput = fila2Ref.querySelector('input[name="productos[' + idTemp2 + '][imagen_url]"]');
            const nombreInput = fila1Ref.querySelector('input[name="productos[' + idTemp2 + '][nombre]"]');
            
            const formData = new FormData();
            formData.append('imagen', file);
            formData.append('producto_id', idTemp2);
            
            if (nombreInput && nombreInput.value.trim() !== '') {
                formData.append('nombre_producto', nombreInput.value.trim());
            } else {
                formData.append('nombre_producto', file.name.replace(/\.[^.]+$/, ''));
            }
            
            mostrarToast('⏳ Subiendo imagen...', 'info');
            
            fetch('upload_imagen_masiva.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    let urlImagen = data.url;
                    if (urlImagen && urlImagen.indexOf('/') !== 0) {
                        urlImagen = '/' + urlImagen;
                    }
                    
                    if (urlInput) {
                        urlInput.value = urlImagen;
                    }
                    
                    mostrarToast('✅ Imagen subida: ' + data.filename, 'success');
                    
                    const previewCell = fila1Ref.querySelector('td:first-child');
                    if (previewCell) {
                        previewCell.innerHTML = '<img src="' + urlImagen + '" alt="Producto" class="img-preview" onerror="this.style.display=\'none\'">';
                    }
                } else {
                    mostrarToast('❌ Error: ' + (data.error || 'desconocido'), 'error');
                }
            })
            .catch(function(error) {
                console.error('Error:', error);
                mostrarToast('❌ Error de conexión', 'error');
            });
            
            this.value = '';
        });
    }
    
    fila1.scrollIntoView({ behavior: 'smooth', block: 'center' });
    actualizarContadorFooter();
}

function actualizarContadorFooter() {
    const productos = document.querySelectorAll('.tabla-edicion tbody input[name$="[id]"]').length;
    const infoFooter = document.querySelector('.tabla-footer .info');
    if (infoFooter) {
        infoFooter.textContent = productos + ' productos en esta página';
    }
}

document.getElementById('formEdicionMasiva').addEventListener('submit', function(e) {
    console.log('Enviando formulario con productos...');
});
</script>

</body>
</html>
<?php $conn->close(); ?>
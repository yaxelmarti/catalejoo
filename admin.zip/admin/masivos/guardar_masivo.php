<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}

// ============================================
// CONFIGURACIÓN DE SESIÓN SEGURA
// ============================================
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/moneda_funciones.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/historial.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/admin/stock/actualizar_precio_combos.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor', 'Inventario'];
$rol_actual = $_SESSION['rol'] ?? '';
if (!in_array($rol_actual, $roles_permitidos)) {
    error_log("[guardar_masivo] Permiso denegado. Rol: $rol_actual");
    $_SESSION['mensaje_masivo'] = '❌ No tienes permisos para realizar esta acción';
    $_SESSION['tipo_mensaje_masivo'] = 'error';
    header('Location: edicion_masiva.php');
    exit;
}

$es_super_admin = ($rol_actual === 'Super Admin');
$proveedor_id_filtro = intval(obtenerProveedorId($conn, $_SESSION['usuario_id'] ?? 0, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_filtro == 0) {
    error_log("[guardar_masivo] Proveedor sin tienda. Usuario: " . ($_SESSION['usuario_id'] ?? 0));
    $_SESSION['mensaje_masivo'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje_masivo'] = 'error';
    header('Location: edicion_masiva.php');
    exit;
}

// ============================================
// VERIFICAR CSRF TOKEN (hash_equals)
// ============================================
$token_post = $_POST['csrf_token'] ?? '';
$token_sesion = $_SESSION['csrf_token'] ?? '';
if (empty($token_post) || empty($token_sesion) || !hash_equals($token_sesion, (string)$token_post)) {
    error_log("[guardar_masivo] CSRF inválido. Usuario: " . ($_SESSION['usuario_id'] ?? 0));
    $_SESSION['mensaje_masivo'] = '❌ Token de seguridad inválido';
    $_SESSION['tipo_mensaje_masivo'] = 'error';
    header('Location: edicion_masiva.php');
    exit;
}

// ============================================
// RECIBIR DATOS
// ============================================
$productos = isset($_POST['productos']) && is_array($_POST['productos']) ? $_POST['productos'] : [];
$por_pagina = isset($_POST['por_pagina']) ? intval($_POST['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100]) ? $por_pagina : 25;
$pagina = isset($_POST['pagina']) ? max(1, intval($_POST['pagina'])) : 1;

if (empty($productos)) {
    $_SESSION['mensaje_masivo'] = '⚠️ No hay productos para actualizar';
    $_SESSION['tipo_mensaje_masivo'] = 'info';
    header('Location: edicion_masiva.php?por_pagina=' . $por_pagina . '&pagina=' . $pagina);
    exit;
}

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

// ============================================
// HELPERS LOCALES
// ============================================

/**
 * Devuelve true si el producto $producto_id pertenece al $proveedor_id (o si es Super Admin).
 * Regla: producto_id <= 0 → false. proveedor_id === 0 → true (acceso total).
 */
function productoPermitidoParaMasivo($conn, $producto_id, $proveedor_id, $es_super_admin) {
    $producto_id = intval($producto_id);
    $proveedor_id = intval($proveedor_id);
    if ($producto_id <= 0) return false;
    if ($es_super_admin || $proveedor_id === 0) return true;
    $stmt = $conn->prepare("SELECT id FROM productos WHERE id = ? AND proveedor_id = ? LIMIT 1");
    if (!$stmt) return false;
    $stmt->bind_param("ii", $producto_id, $proveedor_id);
    $stmt->execute();
    $ok = ($stmt->get_result()->num_rows > 0);
    $stmt->close();
    return $ok;
}

/**
 * Calcula los precios en servidor (Opción B).
 * No confía en $precio del POST.
 * Devuelve array con: precio_costo, precio_venta, precio_final, precio_original.
 */
function calcularPreciosOpcionB($conn, $proveedor_id, $moneda, $costo_local, $porcentaje_ganancia, $porcentaje_rebaja) {
    $proveedor_id = intval($proveedor_id);
    $costo_local = floatval($costo_local);
    $porcentaje_ganancia = floatval($porcentaje_ganancia);
    $porcentaje_rebaja = intval($porcentaje_rebaja);

    $moneda = strtoupper(trim((string)$moneda));
    if ($moneda === '') $moneda = 'USD';

    if ($moneda === 'USD') {
        $precio_costo = $costo_local;
    } else {
        $tasa = getTasaProveedor($conn, $proveedor_id, $moneda);
        $tasa = ($tasa !== null) ? floatval($tasa) : 0;

        // Si no hay tasa configurada, devolver error (no guardar con precio_costo = 0)
        if ($tasa <= 0) {
            return [
                'success' => false,
                'error' => "No hay tasa de cambio configurada para {$moneda}. Ve a Configuración → Monedas para definir una tasa propia o usar la global.",
                'precio_costo' => 0,
                'precio_venta' => 0,
                'precio_final' => 0,
                'precio_original' => 0,
            ];
        }

        $precio_costo = $costo_local / $tasa;
    }

    $precio_venta = $precio_costo * (1 + ($porcentaje_ganancia / 100));

    if ($porcentaje_rebaja > 0) {
        $precio_final = $precio_venta * (100 - $porcentaje_rebaja) / 100;
        $precio_original = $precio_venta;
    } else {
        $precio_final = $precio_venta;
        $precio_original = 0;
    }

    return [
        'success' => true,
        'precio_costo' => round($precio_costo, 2),
        'precio_venta' => round($precio_venta, 2),
        'precio_final' => round($precio_final, 2),
        'precio_original' => round($precio_original, 2),
    ];
}

/**
 * Al desactivar productos desde la edición masiva:
 * - Libera reservado_por_combos y actualiza en_combo en `productos`
 * - Deja cantidad = 0 en `combo_productos` (sin borrar la fila)
 * - Recalcula los combos afectados (y desactiva los que queden sin productos activos)
 *
 * @param mysqli $conn
 * @param array $producto_ids
 * @param int $proveedor_id_operacion
 * @return array Lista de IDs de combos afectados
 */

// ============================================
// INICIAR TRANSACCIÓN
// ============================================
$conn->begin_transaction();

try {
    $actualizados = 0;
    $creados = 0;
    $errores = [];
    $productos_ids = array_keys($productos);

    // Separar IDs numéricos (existentes) de temporales (nuevos)
    $ids_numericos = [];
    $ids_temporales = [];
    foreach ($productos_ids as $pid) {
        if (is_numeric($pid) && intval($pid) > 0) {
            $ids_numericos[] = intval($pid);
        } else {
            $ids_temporales[] = $pid;
        }
    }

    // ============================================
    // OBTENER PRODUCTOS EXISTENTES PARA COMPARAR (incluye moneda_adquisicion y %ganancia)
    // ============================================
    $productos_actuales_dict = [];
    if (!empty($ids_numericos)) {
        $ids_placeholder = implode(',', array_fill(0, count($ids_numericos), '?'));
        $sql_sel = "SELECT id, nombre, marca, descripcion, precio, precio_costo, precio_original, precio_adquisicion, moneda_adquisicion,
                           porcentaje_ganancia, porcentaje_rebaja, cantidad, peso, categoria_id, activo, imagen_url, proveedor_id
                    FROM productos WHERE id IN ($ids_placeholder) FOR UPDATE";
        $stmt_sel = $conn->prepare($sql_sel);
        if ($stmt_sel) {
            $tipos_sel = str_repeat('i', count($ids_numericos));
            if (strlen($tipos_sel) !== count($ids_numericos)) {
                throw new Exception("SELECT: string de tipos tiene " . strlen($tipos_sel) . " caracteres, debe tener " . count($ids_numericos));
            }
            $stmt_sel->bind_param($tipos_sel, ...$ids_numericos);
            $stmt_sel->execute();
            $res_sel = $stmt_sel->get_result();
            while ($row = $res_sel->fetch_assoc()) {
                $productos_actuales_dict[intval($row['id'])] = $row;
            }
            $stmt_sel->close();
        }
    }

    // ============================================
    // RECORRER PRODUCTOS
    // ============================================
    foreach ($productos as $id => $datos) {
        if (!is_array($datos)) {
            continue;
        }

        $es_nuevo = !is_numeric($id) || intval($id) <= 0;
        $id_int = $es_nuevo ? 0 : intval($id);

        // Sanitizar
        $nombre = trim((string)($datos['nombre'] ?? ''));
        $marca = trim((string)($datos['marca'] ?? ''));
        $descripcion = trim((string)($datos['descripcion'] ?? ''));
        $imagen_url = trim((string)($datos['imagen_url'] ?? ''));
        $cantidad = intval($datos['cantidad'] ?? 0);
        $peso = floatval($datos['peso'] ?? 0);
        $porcentaje_rebaja = intval($datos['porcentaje_rebaja'] ?? 0);
        $porcentaje_ganancia = floatval($datos['porcentaje_ganancia'] ?? 0);
        $categoria_id = !empty($datos['categoria_id']) ? intval($datos['categoria_id']) : null;
        $activo = isset($datos['activo']) ? 1 : 0;
        $precio_adquisicion = floatval($datos['precio_adquisicion'] ?? 0);
        $moneda_adquisicion = strtoupper(trim((string)($datos['moneda_adquisicion'] ?? 'USD')));
        if ($moneda_adquisicion === '') $moneda_adquisicion = 'USD';

        // Proveedor: Super Admin del POST; resto forzado al suyo
        if ($es_super_admin) {
            $proveedor_id = !empty($datos['proveedor_id']) ? intval($datos['proveedor_id']) : 0;
        } else {
            $proveedor_id = $proveedor_id_filtro;
        }

        // URL con barra inicial
        if ($imagen_url !== '' && strpos($imagen_url, '/') !== 0) {
            $imagen_url = '/' . $imagen_url;
        }

        // ============================================
        // VALIDACIONES
        // ============================================
        if ($nombre === '') {
            $errores[] = "❌ " . ($es_nuevo ? 'Nuevo producto' : "Producto ID $id") . ": El nombre es obligatorio";
            continue;
        }
        if ($porcentaje_rebaja < 0 || $porcentaje_rebaja > 100) {
            $errores[] = "❌ \"$nombre\": % rebaja debe estar entre 0 y 100";
            continue;
        }
        if ($porcentaje_ganancia < 0) {
            $errores[] = "❌ \"$nombre\": % ganancia no puede ser negativo";
            continue;
        }
        if ($precio_adquisicion < 0) {
            $errores[] = "❌ \"$nombre\": precio de adquisición no puede ser negativo";
            continue;
        }
        if ($cantidad < 0) {
            $errores[] = "❌ \"$nombre\": cantidad no puede ser negativa";
            continue;
        }
        if ($peso < 0) {
            $errores[] = "❌ \"$nombre\": peso no puede ser negativo";
            continue;
        }

                // Validar moneda contra las de adquisición del proveedor (incluye USD)
        $monedas_validas = getMonedasParaAdquisicion($conn, $proveedor_id);
        if (!in_array($moneda_adquisicion, $monedas_validas, true)) {
            $errores[] = "❌ \"$nombre\": moneda '$moneda_adquisicion' no permitida para adquisición";
            continue;
        }

        // Verificar propiedad por fila (excepto nuevos, que se crearán con el proveedor validado)
        if (!$es_nuevo && !productoPermitidoParaMasivo($conn, $id_int, $proveedor_id_filtro, $es_super_admin)) {
            $errores[] = "❌ Producto ID $id_int: no tienes permiso para editarlo";
            continue;
        }

        // Si Super Admin crea nuevo, el proveedor debe existir y estar activo
        if ($es_nuevo && $es_super_admin && $proveedor_id <= 0) {
            $errores[] = "❌ \"$nombre\": debes asignar un proveedor válido";
            continue;
        }
        if ($es_nuevo && $es_super_admin && $proveedor_id > 0) {
            $stmt_prov = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1 LIMIT 1");
            if ($stmt_prov) {
                $stmt_prov->bind_param("i", $proveedor_id);
                $stmt_prov->execute();
                $prov_ok = ($stmt_prov->get_result()->num_rows > 0);
                $stmt_prov->close();
                if (!$prov_ok) {
                    $errores[] = "❌ \"$nombre\": el proveedor seleccionado no está activo";
                    continue;
                }
            }
        }

        // ============================================
        // CALCULAR PRECIOS EN SERVIDOR (Opción B)
        // ============================================
        $calc = calcularPreciosOpcionB($conn, $proveedor_id, $moneda_adquisicion, $precio_adquisicion, $porcentaje_ganancia, $porcentaje_rebaja);

        if (empty($calc['success'])) {
            $errores[] = "❌ \"$nombre\": " . ($calc['error'] ?? 'Error al calcular precios');
            continue;
        }

        $precio_costo = $calc['precio_costo'];
        $precio_final = $calc['precio_final'];
        $precio_original = $calc['precio_original'];

        // Validación: precio final >= costo
        if ($precio_final < $precio_costo) {
            $errores[] = "❌ \"$nombre\": el precio final ($" . number_format($precio_final, 2) . ") no puede ser menor al costo USD ($" . number_format($precio_costo, 2) . ")";
            continue;
        }

        // ============================================
        // INSERT (producto nuevo)
        // ============================================
        if ($es_nuevo) {
                        $sql_insert = "INSERT INTO productos 
                (nombre, descripcion, marca, peso, cantidad,
                 precio_costo, precio, precio_original, porcentaje_rebaja, porcentaje_ganancia,
                 precio_adquisicion, moneda_adquisicion,
                 categoria_id, activo, imagen_url, proveedor_id)
                VALUES (?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?,  ?, ?, ?, ?)";

            $stmt_ins = $conn->prepare($sql_insert);
            if (!$stmt_ins) {
                throw new Exception("INSERT: " . $conn->error);
            }

            // 17 tipos: nombre(s) desc(s) marca(s) peso(d) cant(i)
            //            costo(d) precio(d) original(d) rebaja(i) ganancia(d)
            //            adq(d) moneda(s)
            //            cat(i|null) activo(i) imagen(s) proveedor(i|null)
            $tipos_insert = 's' . 's' . 's' . 'd' . 'i'
                          . 'd' . 'd' . 'd' . 'i' . 'd'
                          . 'd' . 's'
                          . 'i' . 'i' . 's' . 'i';
            // Contamos: 5 + 5 + 2 + 4 = 16 → pero categoria_id y proveedor_id son nullable con 'i'
            // Nota: bind_param no acepta NULL con 'i' de forma directa si la columna es nullable;
            // usamos variables con valor null y PHP lo manda como NULL.
            if (strlen($tipos_insert) !== 16) {
                throw new Exception("INSERT: string de tipos tiene " . strlen($tipos_insert) . " caracteres, debe tener 16");
            }

            // categoria_id y proveedor_id: preparar null-safe
            $cat_param = ($categoria_id === null) ? 0 : intval($categoria_id);
$prov_param = ($proveedor_id === null) ? 0 : intval($proveedor_id);

            $stmt_ins->bind_param(
                $tipos_insert,
                $nombre,
                $descripcion,
                $marca,
                $peso,
                $cantidad,
                $precio_costo,
                $precio_final,
                $precio_original,
                $porcentaje_rebaja,
                $porcentaje_ganancia,
                $precio_adquisicion,
                $moneda_adquisicion,
                $cat_param,
                $activo,
                $imagen_url,
                $prov_param
            );

                       if (!$stmt_ins->execute()) {
                $errores[] = "❌ Nuevo producto \"$nombre\": " . $stmt_ins->error;
                $stmt_ins->close();
                continue;
            }
            $nuevo_id = intval($conn->insert_id);
            $stmt_ins->close();

            // Reset fecha_agotado si cantidad > 0
            if ($cantidad > 0) {
                $stmt_fa = $conn->prepare("UPDATE productos SET fecha_agotado = NULL WHERE id = ?");
                if ($stmt_fa) {
                    $stmt_fa->bind_param("i", $nuevo_id);
                    $stmt_fa->execute();
                    $stmt_fa->close();
                }
            }

                        // Si el producto nuevo está activo, recalcular combos (por si acaso)
            if ($activo === 1 && function_exists('actualizarCombosPorProducto')) {
                try {
                    actualizarCombosPorProducto($conn, $nuevo_id, $proveedor_id);
                } catch (Throwable $e_combos) {
                    error_log("[guardar_masivo] Error al actualizar combos para producto nuevo ID $nuevo_id: " . $e_combos->getMessage());
                }
            }

            // Historial
            $cambios_crear = [
                'nombre' => $nombre,
                'descripcion' => $descripcion,
                'marca' => $marca,
                'peso' => $peso,
                'cantidad' => $cantidad,
                'precio_costo' => $precio_costo,
                'precio' => $precio_final,
                'precio_original' => $precio_original,
                'porcentaje_rebaja' => $porcentaje_rebaja,
                'porcentaje_ganancia' => $porcentaje_ganancia,
                'precio_adquisicion' => $precio_adquisicion,
                'moneda_adquisicion' => $moneda_adquisicion,
                'categoria_id' => $categoria_id,
                'activo' => $activo,
                'imagen_url' => $imagen_url,
                'proveedor_id' => $proveedor_id,
            ];
            registrarCambioProducto($conn, $nuevo_id, 'crear', $cambios_crear);

            $creados++;
            error_log("[guardar_masivo][crear] Usuario {$usuario_id_actual} creó producto ID {$nuevo_id} para proveedor {$proveedor_id}");
            continue;
        }

        // ============================================
        // UPDATE (producto existente)
        // ============================================
        // Proveedor final: si Super Admin lo cambió, respetar; si no, el actual del producto
        $proveedor_id_final = $proveedor_id;
        if ($es_super_admin && $proveedor_id <= 0 && isset($productos_actuales_dict[$id_int])) {
            $proveedor_id_final = intval($productos_actuales_dict[$id_int]['proveedor_id'] ?? 0);
        }

        $sql_update = "UPDATE productos SET
            nombre = ?, marca = ?, descripcion = ?,
            precio = ?, precio_costo = ?, precio_original = ?,
            porcentaje_rebaja = ?, porcentaje_ganancia = ?,
            precio_adquisicion = ?, moneda_adquisicion = ?,
            cantidad = ?, peso = ?,
            categoria_id = ?, activo = ?, imagen_url = ?, proveedor_id = ?
            WHERE id = ?";

        $stmt_upd = $conn->prepare($sql_update);
        if (!$stmt_upd) {
            throw new Exception("UPDATE: " . $conn->error);
        }

        // 17 tipos: nombre(s) marca(s) desc(s)
        //            precio(d) costo(d) original(d)
        //            rebaja(i) ganancia(d)
        //            adq(d) moneda(s)
        //            cantidad(i) peso(d)
        //            cat(i|null) activo(i) imagen(s) proveedor(i|null)
        //            id(i)
        $tipos_update = 's' . 's' . 's'
                      . 'd' . 'd' . 'd'
                      . 'i' . 'd'
                      . 'd' . 's'
                      . 'i' . 'd'
                      . 'i' . 'i' . 's' . 'i'
                      . 'i';
        // Contamos: 3 + 3 + 2 + 2 + 2 + 4 + 1 = 17
        if (strlen($tipos_update) !== 17) {
            throw new Exception("UPDATE: string de tipos tiene " . strlen($tipos_update) . " caracteres, debe tener 17");
        }

        $cat_param = ($categoria_id === null) ? 0 : intval($categoria_id);
$prov_param = ($proveedor_id === null) ? 0 : intval($proveedor_id);

        $stmt_upd->bind_param(
            $tipos_update,
            $nombre,
            $marca,
            $descripcion,
            $precio_final,
            $precio_costo,
            $precio_original,
            $porcentaje_rebaja,
            $porcentaje_ganancia,
            $precio_adquisicion,
            $moneda_adquisicion,
            $cantidad,
            $peso,
            $cat_param,
            $activo,
            $imagen_url,
            $prov_param,
            $id_int
        );

        if (!$stmt_upd->execute()) {
            $errores[] = "❌ \"$nombre\" (ID: $id_int): " . $stmt_upd->error;
            $stmt_upd->close();
            continue;
        }
        $stmt_upd->close();

        // Reset fecha_agotado si cantidad > 0
        if ($cantidad > 0) {
            $stmt_fa = $conn->prepare("UPDATE productos SET fecha_agotado = NULL WHERE id = ?");
            if ($stmt_fa) {
                $stmt_fa->bind_param("i", $id_int);
                $stmt_fa->execute();
                $stmt_fa->close();
            }
        }

        // ============================================
        // ACTUALIZAR COMBOS
        // ============================================
        if ($activo === 0) {
            // Producto desactivado → liberar reservas y recalcular combos
            desactivarProductosEnCombosYRecalcular($conn, [$id_int], $proveedor_id_final);
        } else {
            // Producto activo → solo recalcular precios de combos
            if (function_exists('actualizarCombosPorProducto')) {
                actualizarCombosPorProducto($conn, $id_int, $proveedor_id_final);
            }
        }

        // Historial de cambios
        if (isset($productos_actuales_dict[$id_int])) {
            $prod_actual = $productos_actuales_dict[$id_int];
            $cambios = [];
            $comparar = [
                'nombre' => $nombre,
                'marca' => $marca,
                'descripcion' => $descripcion,
                'precio' => $precio_final,
                'precio_costo' => $precio_costo,
                'precio_original' => $precio_original,
                'porcentaje_rebaja' => $porcentaje_rebaja,
                'porcentaje_ganancia' => $porcentaje_ganancia,
                'precio_adquisicion' => $precio_adquisicion,
                'moneda_adquisicion' => $moneda_adquisicion,
                'cantidad' => $cantidad,
                'peso' => $peso,
                'categoria_id' => $categoria_id,
                'activo' => $activo,
                'imagen_url' => $imagen_url,
                'proveedor_id' => $proveedor_id_final,
            ];
            foreach ($comparar as $campo => $valor_nuevo) {
                $valor_ant = $prod_actual[$campo] ?? '';
                if ($valor_ant === null) $valor_ant = '';
                if ($valor_nuevo === null) $valor_nuevo = '';
                if (is_numeric($valor_ant)) $valor_ant = (string)$valor_ant;
                if (is_numeric($valor_nuevo)) $valor_nuevo = (string)$valor_nuevo;
                if ((string)$valor_ant !== (string)$valor_nuevo) {
                    $cambios[$campo] = ['antes' => $valor_ant, 'despues' => $valor_nuevo];
                }
            }
            if (!empty($cambios)) {
                registrarCambioProducto($conn, $id_int, 'editar', $cambios);
            }
        }

        $actualizados++;
        error_log("[guardar_masivo][editar] Usuario {$usuario_id_actual} editó producto ID {$id_int} proveedor {$proveedor_id_final}");
    }

    // ============================================
    // COMMIT O ROLLBACK
    // ============================================
    if (empty($errores)) {
        $conn->commit();
        $_SESSION['mensaje_masivo'] = "✅ $creados creado(s) y $actualizados actualizado(s) correctamente";
        $_SESSION['tipo_mensaje_masivo'] = "success";
    } else {
        $conn->rollback();
        $mensaje_error = "❌ Se encontraron errores en " . count($errores) . " producto(s):<br><br>" . implode("<br>", array_slice($errores, 0, 20));
        if (count($errores) > 20) {
            $mensaje_error .= "<br><br>... y " . (count($errores) - 20) . " errores más";
        }
        $_SESSION['mensaje_masivo'] = $mensaje_error;
        $_SESSION['tipo_mensaje_masivo'] = "error";
    }

} catch (Throwable $e) {
    if ($conn->in_transaction) {
        $conn->rollback();
    }
    error_log("[guardar_masivo] Excepción: " . $e->getMessage() . " | Línea: " . $e->getLine());
    $_SESSION['mensaje_masivo'] = "❌ Error inesperado: " . $e->getMessage();
    $_SESSION['tipo_mensaje_masivo'] = "error";
}

// ============================================
// REDIRIGIR
// ============================================
header('Location: edicion_masiva.php?por_pagina=' . $por_pagina . '&pagina=' . $pagina);
exit;
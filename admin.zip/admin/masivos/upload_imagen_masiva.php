<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}

// ============================================
// CONFIGURACIÓN DE SESIÓN SEGURA
// ============================================
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

// Respuesta siempre JSON
header('Content-Type: application/json; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$rol_actual = $_SESSION['rol'] ?? '';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor', 'Inventario'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    error_log("[upload_imagen_masiva] Permiso denegado. Rol: $rol_actual, usuario: $usuario_id_actual");
    echo json_encode(['success' => false, 'error' => 'No tienes permisos']);
    exit;
}

$es_super_admin = ($rol_actual === 'Super Admin');
$proveedor_id_filtro = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_filtro == 0) {
    echo json_encode(['success' => false, 'error' => 'No se encontró una tienda asociada a tu usuario']);
    exit;
}

// ============================================
// VERIFICAR CSRF TOKEN
// ============================================
$token_post = $_POST['csrf_token'] ?? '';
$token_sesion = $_SESSION['csrf_token'] ?? '';
if (empty($token_post) || empty($token_sesion) || !hash_equals($token_sesion, (string)$token_post)) {
    error_log("[upload_imagen_masiva] CSRF inválido. Usuario: $usuario_id_actual");
    echo json_encode(['success' => false, 'error' => 'Token de seguridad inválido']);
    exit;
}

// ============================================
// VERIFICAR ARCHIVO RECIBIDO
// ============================================
if (!isset($_FILES['imagen']) || !is_array($_FILES['imagen'])) {
    echo json_encode(['success' => false, 'error' => 'No se recibió ninguna imagen']);
    exit;
}

$archivo = $_FILES['imagen'];

if (($archivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    $mapa_errores = [
        UPLOAD_ERR_INI_SIZE   => 'La imagen excede el tamaño máximo permitido por el servidor',
        UPLOAD_ERR_FORM_SIZE  => 'La imagen excede el tamaño máximo del formulario',
        UPLOAD_ERR_PARTIAL    => 'La imagen se subió parcialmente',
        UPLOAD_ERR_NO_FILE    => 'No se recibió ningún archivo',
        UPLOAD_ERR_NO_TMP_DIR => 'Falta la carpeta temporal del servidor',
        UPLOAD_ERR_CANT_WRITE => 'No se pudo escribir el archivo en el servidor',
        UPLOAD_ERR_EXTENSION  => 'Una extensión del servidor bloqueó la subida',
    ];
    $msg = $mapa_errores[$archivo['error']] ?? 'Error desconocido al subir la imagen';
    echo json_encode(['success' => false, 'error' => $msg]);
    exit;
}

if (!is_uploaded_file($archivo['tmp_name'])) {
    error_log("[upload_imagen_masiva] tmp_name no es archivo subido. Usuario: $usuario_id_actual");
    echo json_encode(['success' => false, 'error' => 'Archivo no válido']);
    exit;
}

// ============================================
// VALIDAR TIPO MIME REAL (finfo) + EXTENSIÓN
// ============================================
$extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
$mimes_permitidos = [
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png'  => 'image/png',
    'gif'  => 'image/gif',
    'webp' => 'image/webp',
];

$extension = strtolower(pathinfo((string)$archivo['name'], PATHINFO_EXTENSION));
if (!in_array($extension, $extensiones_permitidas, true)) {
    echo json_encode(['success' => false, 'error' => 'Formato no permitido. Usa: JPG, PNG, GIF, WEBP']);
    exit;
}

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime_real = $finfo->file($archivo['tmp_name']) ?: '';
if (!in_array($mime_real, array_values($mimes_permitidos), true)) {
    error_log("[upload_imagen_masiva] MIME no permitido: $mime_real. Usuario: $usuario_id_actual");
    echo json_encode(['success' => false, 'error' => 'El archivo no es una imagen válida']);
    exit;
}

// Verificar coherencia extensión ↔ MIME
if ($mimes_permitidos[$extension] !== $mime_real) {
    // Permitir jpg ↔ jpeg (ambos image/jpeg)
    $compat = [
        'jpg'  => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png'  => ['image/png'],
        'gif'  => ['image/gif'],
        'webp' => ['image/webp'],
    ];
    if (!in_array($mime_real, $compat[$extension] ?? [], true)) {
        error_log("[upload_imagen_masiva] MIME/extensión incoherentes: $extension vs $mime_real");
        echo json_encode(['success' => false, 'error' => 'La extensión no coincide con el contenido de la imagen']);
        exit;
    }
}

// getimagesize como segunda barrera
$check = @getimagesize($archivo['tmp_name']);
if ($check === false) {
    echo json_encode(['success' => false, 'error' => 'El archivo no es una imagen válida']);
    exit;
}

// Límite de tamaño (5 MB)
$max_bytes = 5 * 1024 * 1024;
if (($archivo['size'] ?? 0) > $max_bytes) {
    echo json_encode(['success' => false, 'error' => 'La imagen no debe pesar más de 5MB']);
    exit;
}

// ============================================
// VALIDAR producto_id (si viene)
// ============================================
$producto_id_raw = $_POST['producto_id'] ?? '';
$producto_id_int = 0;
$es_producto_nuevo = false;

if ($producto_id_raw !== '' && $producto_id_raw !== null) {
    if (is_numeric($producto_id_raw) && intval($producto_id_raw) > 0) {
        $producto_id_int = intval($producto_id_raw);
    } else {
        // id temporal tipo "nuevo_1_1730000000"
        $es_producto_nuevo = true;
    }
}

// Si es producto existente, verificar propiedad ANTES de tocar nada
if (!$es_producto_nuevo && $producto_id_int > 0) {
    if (!$es_super_admin && $proveedor_id_filtro > 0) {
        $stmt_chk = $conn->prepare("SELECT id FROM productos WHERE id = ? AND proveedor_id = ? LIMIT 1");
        if ($stmt_chk) {
            $stmt_chk->bind_param("ii", $producto_id_int, $proveedor_id_filtro);
            $stmt_chk->execute();
            if ($stmt_chk->get_result()->num_rows === 0) {
                $stmt_chk->close();
                error_log("[upload_imagen_masiva] Intento de editar producto ajeno. Producto: $producto_id_int, proveedor: $proveedor_id_filtro, usuario: $usuario_id_actual");
                echo json_encode(['success' => false, 'error' => 'No tienes permiso para modificar este producto']);
                exit;
            }
            $stmt_chk->close();
        }
    } elseif (!$es_super_admin) {
        echo json_encode(['success' => false, 'error' => 'No tienes permiso para modificar este producto']);
        exit;
    }
}

// ============================================
// NOMBRE DEL PRODUCTO (para nombre de archivo)
// ============================================
$nombre_producto = '';

if (!$es_producto_nuevo && $producto_id_int > 0) {
    $stmt_n = $conn->prepare("SELECT nombre FROM productos WHERE id = ? LIMIT 1");
    if ($stmt_n) {
        $stmt_n->bind_param("i", $producto_id_int);
        $stmt_n->execute();
        if ($row = $stmt_n->get_result()->fetch_assoc()) {
            $nombre_producto = $row['nombre'];
        }
        $stmt_n->close();
    }
}

if ($nombre_producto === '') {
    $nombre_post = trim((string)($_POST['nombre_producto'] ?? ''));
    if ($nombre_post !== '') {
        $nombre_producto = $nombre_post;
    }
}

if ($nombre_producto === '') {
    $nombre_producto = pathinfo((string)$archivo['name'], PATHINFO_FILENAME);
}

// ============================================
// NOMBRE DE ARCHIVO LIMPIO Y ÚNICO
// ============================================
$nombre_limpio = strtolower($nombre_producto);
// Normalizar tildes: quitar diacríticos (requiere intl o fallback)
if (function_exists('iconv')) {
    $tmp = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $nombre_limpio);
    if ($tmp !== false) $nombre_limpio = $tmp;
}
$nombre_limpio = preg_replace('/[^a-z0-9]+/i', '_', $nombre_limpio);
$nombre_limpio = trim((string)$nombre_limpio, '_');

if ($nombre_limpio === '') {
    $nombre_limpio = 'producto_' . time();
}

// Limitar longitud del nombre base
$nombre_limpio = substr($nombre_limpio, 0, 60);

// Sufijo único para evitar colisiones en el mismo segundo
$nombre_final = $nombre_limpio . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $extension;

// ============================================
// CARPETA DESTINO
// ============================================
$target_dir = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/uploads/productos/';

if (!is_dir($target_dir)) {
    if (!@mkdir($target_dir, 0755, true) && !is_dir($target_dir)) {
        error_log("[upload_imagen_masiva] No se pudo crear carpeta destino: $target_dir");
        echo json_encode(['success' => false, 'error' => 'No se pudo preparar la carpeta de destino']);
        exit;
    }
}

$target_file = $target_dir . $nombre_final;

// ============================================
// MOVER ARCHIVO
// ============================================
if (!move_uploaded_file($archivo['tmp_name'], $target_file)) {
    error_log("[upload_imagen_masiva] move_uploaded_file falló. Destino: $target_file. Usuario: $usuario_id_actual");
    echo json_encode(['success' => false, 'error' => 'Error al mover la imagen al servidor']);
    exit;
}

@chmod($target_file, 0644);
$url_imagen = '/uploads/productos/' . $nombre_final;

// ============================================
// ACTUALIZAR producto_id EN BD (si aplica)
// ============================================
$producto_actualizado = null;
if (!$es_producto_nuevo && $producto_id_int > 0) {
    $stmt_upd = $conn->prepare("UPDATE productos SET imagen_url = ? WHERE id = ?");
    if ($stmt_upd) {
        $stmt_upd->bind_param("si", $url_imagen, $producto_id_int);
        if ($stmt_upd->execute()) {
            $producto_actualizado = $producto_id_int;
            error_log("[upload_imagen_masiva] Imagen actualizada. Usuario: $usuario_id_actual, producto: $producto_id_int, archivo: $nombre_final");
        } else {
            error_log("[upload_imagen_masiva] UPDATE imagen_url falló. Producto: $producto_id_int - " . $conn->error);
        }
        $stmt_upd->close();
    }
}

// ============================================
// RESPONDER
// ============================================
echo json_encode([
    'success' => true,
    'url' => $url_imagen,
    'filename' => $nombre_final,
    'producto_id' => $producto_actualizado,
    'es_nuevo' => $es_producto_nuevo,
    'message' => 'Imagen subida correctamente como: ' . $nombre_final
]);
exit;
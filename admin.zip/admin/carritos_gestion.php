<?php
// ============================================
// GESTIÓN DE CARRITOS
// Versión 27 Oct 2026
// Ubicación: /admin/carritos_gestion.php
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/moneda_funciones.php';
require_once __DIR__ . '/../header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

$rol_actual = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

// ============================================
// PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    error_log("[carritos_gestion] Permiso denegado. Rol: $rol_actual, usuario: $usuario_id_actual");
    header('Location: /admin.php?error=permiso');
    exit;
}

$roles_gestion = ['Super Admin', 'Proveedor'];
$puede_gestionar = in_array($rol_actual, $roles_gestion, true);

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// ============================================
// COLORES DE CONFIGURACIÓN
// ============================================
$color_primario = '#667eea';
$color_secundario = '#764ba2';

$stmt_c = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario' LIMIT 1");
if ($stmt_c) {
    $stmt_c->execute();
    $row_c = $stmt_c->get_result()->fetch_assoc();
    if ($row_c && !empty($row_c['valor'])) $color_primario = $row_c['valor'];
    $stmt_c->close();
}
$stmt_c2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario' LIMIT 1");
if ($stmt_c2) {
    $stmt_c2->execute();
    $row_c2 = $stmt_c2->get_result()->fetch_assoc();
    if ($row_c2 && !empty($row_c2['valor'])) $color_secundario = $row_c2['valor'];
    $stmt_c2->close();
}

// ============================================
// LISTA DE PROVEEDORES (solo Super Admin / Gerente)
// ============================================
$lista_proveedores = [];
$puede_filtrar_proveedor = in_array($rol_actual, ['Super Admin', 'Gerente'], true);

if ($puede_filtrar_proveedor) {
    $res_prov = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda ASC");
    if ($res_prov) {
        while ($p = $res_prov->fetch_assoc()) {
            $lista_proveedores[] = $p;
        }
        $res_prov->free();
    }
}

$proveedor_filtro_get = 0;
if ($puede_filtrar_proveedor && !empty($_GET['proveedor_id'])) {
    $proveedor_filtro_get = intval($_GET['proveedor_id']);
}

// ============================================
// ORDENAMIENTO
// ============================================
$columnas_validas = [
    'id'            => 'ca.id',
    'cliente'       => 'cliente_nombre',
    'email'         => 'c.email',
    'inicio'        => 'ca.fecha_inicio',
    'expira'        => 'ca.fecha_expiracion',
    'estado'        => 'ca.estado',
    'productos'     => 'total_productos',
    'items'         => 'total_items',
    'total'         => 'total_monto_convertido',
];
$order_by = isset($_GET['order_by']) && isset($columnas_validas[$_GET['order_by']]) ? $_GET['order_by'] : 'inicio';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) === 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . $columnas_validas[$order_by] . " " . $order_dir;

// ============================================
// HELPER: verificar si un carrito contiene productos del proveedor
// ============================================
function carritoContieneProductosDeProveedor($conn, $carrito_id, $proveedor_id) {
    $carrito_id = intval($carrito_id);
    $proveedor_id = intval($proveedor_id);
    if ($carrito_id <= 0) return false;
    if ($proveedor_id === 0) return true;
    $stmt = $conn->prepare("SELECT 1 FROM carritos WHERE id = ? AND proveedor_id = ? LIMIT 1");
    if (!$stmt) return false;
    $stmt->bind_param("ii", $carrito_id, $proveedor_id);
    $stmt->execute();
    $ok = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $ok;
}

// ============================================
// PROCESAR ACCIONES (POST con CSRF)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!function_exists('csrf_validar') || !csrf_validar($token)) {
        error_log("[carritos_gestion] CSRF inválido. Usuario: $usuario_id_actual");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/carritos_gestion.php');
        exit;
    }

    $accion = $_POST['accion'] ?? '';
    $carrito_id = isset($_POST['carrito_id']) ? intval($_POST['carrito_id']) : 0;

    if ($carrito_id <= 0) {
        header('Location: /admin/carritos_gestion.php');
        exit;
    }

    if (!carritoContieneProductosDeProveedor($conn, $carrito_id, $proveedor_id_usuario)) {
        error_log("[carritos_gestion] Intento de tocar carrito ajeno. Usuario: $usuario_id_actual, carrito: $carrito_id");
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este carrito';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/carritos_gestion.php');
        exit;
    }

    // ---- Actualizar cantidad
    if ($accion === 'actualizar_cantidad' && $puede_gestionar) {
        $producto_id = isset($_POST['producto_id']) ? intval($_POST['producto_id']) : 0;
        $nueva_cantidad = isset($_POST['cantidad']) ? intval($_POST['cantidad']) : 0;
        if ($nueva_cantidad < 0) $nueva_cantidad = 0;

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ? FOR UPDATE");
            if (!$stmt) throw new Exception("prepare select: " . $conn->error);
            $stmt->bind_param("ii", $carrito_id, $producto_id);
            $stmt->execute();
            $actual = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($actual) {
                $diferencia = $nueva_cantidad - intval($actual['cantidad']);

                if ($diferencia > 0) {
                    $stmt = $conn->prepare("SELECT cantidad FROM productos WHERE id = ? FOR UPDATE");
                    if (!$stmt) throw new Exception("prepare stock: " . $conn->error);
                    $stmt->bind_param("i", $producto_id);
                    $stmt->execute();
                    $stock = intval($stmt->get_result()->fetch_assoc()['cantidad'] ?? 0);
                    $stmt->close();

                    if ($diferencia > $stock) {
                        throw new Exception("Stock insuficiente. Disponible: $stock");
                    }

                    $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad - ? WHERE id = ?");
                    if (!$stmt) throw new Exception("prepare stock update: " . $conn->error);
                    $stmt->bind_param("ii", $diferencia, $producto_id);
                    $stmt->execute();
                    $stmt->close();

                    $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE carrito_id = ? AND producto_id = ?");
                    if (!$stmt) throw new Exception("prepare carrito update: " . $conn->error);
                    $stmt->bind_param("iii", $nueva_cantidad, $carrito_id, $producto_id);
                    $stmt->execute();
                    $stmt->close();
                } elseif ($diferencia < 0) {
                    $dif_abs = abs($diferencia);
                    $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                    if (!$stmt) throw new Exception("prepare stock update: " . $conn->error);
                    $stmt->bind_param("ii", $dif_abs, $producto_id);
                    $stmt->execute();
                    $stmt->close();

                    if ($nueva_cantidad == 0) {
                        $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
                        if (!$stmt) throw new Exception("prepare carrito delete: " . $conn->error);
                        $stmt->bind_param("ii", $carrito_id, $producto_id);
                        $stmt->execute();
                        $stmt->close();
                    } else {
                        $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE carrito_id = ? AND producto_id = ?");
                        if (!$stmt) throw new Exception("prepare carrito update: " . $conn->error);
                        $stmt->bind_param("iii", $nueva_cantidad, $carrito_id, $producto_id);
                        $stmt->execute();
                        $stmt->close();
                    }
                }

                $conn->commit();
                $_SESSION['mensaje'] = "✅ Cantidad actualizada";
                $_SESSION['tipo_mensaje'] = "exito";
                error_log("[carritos_gestion] actualizar_cantidad OK. Usuario: $usuario_id_actual, carrito: $carrito_id, producto: $producto_id, nueva: $nueva_cantidad");
            } else {
                $conn->rollback();
                $_SESSION['mensaje'] = "❌ Producto no encontrado en el carrito";
                $_SESSION['tipo_mensaje'] = "error";
            }
        } catch (Throwable $e) {
            $conn->rollback();
            error_log("[carritos_gestion] actualizar_cantidad error: " . $e->getMessage());
            $_SESSION['mensaje'] = "❌ " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "error";
        }
        header('Location: /admin/carritos_gestion.php?' . http_build_query($_GET));
        exit;
    }

    // ---- Eliminar producto
    if ($accion === 'eliminar_producto' && $puede_gestionar) {
        $producto_id = isset($_POST['producto_id']) ? intval($_POST['producto_id']) : 0;
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ? FOR UPDATE");
            if (!$stmt) throw new Exception("prepare select: " . $conn->error);
            $stmt->bind_param("ii", $carrito_id, $producto_id);
            $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($item) {
                $cant = intval($item['cantidad']);
                $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                if (!$stmt) throw new Exception("prepare stock update: " . $conn->error);
                $stmt->bind_param("ii", $cant, $producto_id);
                $stmt->execute();
                $stmt->close();

                $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
                if (!$stmt) throw new Exception("prepare delete: " . $conn->error);
                $stmt->bind_param("ii", $carrito_id, $producto_id);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                $_SESSION['mensaje'] = "✅ Producto eliminado del carrito";
                $_SESSION['tipo_mensaje'] = "exito";
                error_log("[carritos_gestion] eliminar_producto OK. Usuario: $usuario_id_actual, carrito: $carrito_id, producto: $producto_id");
            } else {
                $conn->rollback();
                $_SESSION['mensaje'] = "❌ Producto no encontrado";
                $_SESSION['tipo_mensaje'] = "error";
            }
        } catch (Throwable $e) {
            $conn->rollback();
            error_log("[carritos_gestion] eliminar_producto error: " . $e->getMessage());
            $_SESSION['mensaje'] = "❌ " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "error";
        }
        header('Location: /admin/carritos_gestion.php?' . http_build_query($_GET));
        exit;
    }

    // ---- Cancelar carrito completo
    if ($accion === 'cancelar_carrito' && $puede_gestionar) {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT cliente_id, estado FROM carritos WHERE id = ? FOR UPDATE");
            if (!$stmt) throw new Exception("prepare carrito: " . $conn->error);
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $carrito = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$carrito) throw new Exception("Carrito no encontrado");
            if ($carrito['estado'] !== 'pendiente') throw new Exception("Solo se pueden cancelar carritos pendientes");

            $cliente_id_carrito = intval($carrito['cliente_id']);

                        $stmt = $conn->prepare("
                SELECT 
                    (SELECT COALESCE(SUM(cp.cantidad * cp.precio_unitario), 0) FROM carrito_productos cp WHERE cp.carrito_id = ?) +
                    (SELECT COALESCE(SUM(cc.precio_total), 0) FROM carrito_combos cc WHERE cc.carrito_id = ?) as total
            ");
            if (!$stmt) throw new Exception("prepare total: " . $conn->error);
            $stmt->bind_param("ii", $carrito_id, $carrito_id);
            $stmt->execute();
            $total_carrito = floatval($stmt->get_result()->fetch_assoc()['total'] ?? 0);
            $stmt->close();

            $fecha_actual = date('Y-m-d H:i:s');
            $motivo = 'cancelado_por_admin';

            $stmt = $conn->prepare("INSERT INTO historial_carritos_cancelados (carrito_id, cliente_id, fecha_cancelacion, motivo, total) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt) throw new Exception("prepare historial: " . $conn->error);
            $stmt->bind_param("iissd", $carrito_id, $cliente_id_carrito, $fecha_actual, $motivo, $total_carrito);
            $stmt->execute();
            $cancelacion_id = intval($conn->insert_id);
            $stmt->close();

                       // ============================================
            // 1. DEVOLVER STOCK DE PRODUCTOS INDIVIDUALES
            // ============================================
            $stmt = $conn->prepare("SELECT cp.producto_id, cp.cantidad, cp.precio_unitario, p.nombre FROM carrito_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.carrito_id = ?");
            if (!$stmt) throw new Exception("prepare productos historial: " . $conn->error);
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $productos_historial = $stmt->get_result();

            while ($item = $productos_historial->fetch_assoc()) {
                $prod_id = intval($item['producto_id']);
                $cant = intval($item['cantidad']);
                $precio = floatval($item['precio_unitario']);
                $nombre = $item['nombre'];
                $subtotal = $cant * $precio;

                $stmt_h = $conn->prepare("INSERT INTO historial_carritos_cancelados_productos (cancelacion_id, producto_id, nombre, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
                if (!$stmt_h) throw new Exception("prepare historial prod: " . $conn->error);
                $stmt_h->bind_param("iisidd", $cancelacion_id, $prod_id, $nombre, $cant, $precio, $subtotal);
                $stmt_h->execute();
                $stmt_h->close();

                $stmt_s = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                if (!$stmt_s) throw new Exception("prepare stock: " . $conn->error);
                $stmt_s->bind_param("ii", $cant, $prod_id);
                $stmt_s->execute();
                $stmt_s->close();
            }
                        // ============================================
            // 2. GUARDAR COMBOS EN EL HISTORIAL
            // ============================================
            $stmt = $conn->prepare("SELECT cc.combo_id, cc.cantidad, cc.precio_total, c.nombre FROM carrito_combos cc JOIN combos c ON cc.combo_id = c.id WHERE cc.carrito_id = ?");
            if (!$stmt) throw new Exception("prepare combos historial: " . $conn->error);
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $combos_hist = $stmt->get_result();
            $stmt->close();

            while ($combo_item = $combos_hist->fetch_assoc()) {
                $combo_id_h = intval($combo_item['combo_id']);
                $cant_combo_h = intval($combo_item['cantidad']);
                $precio_total_h = floatval($combo_item['precio_total']);
                $nombre_combo_h = $combo_item['nombre'];
                $precio_unitario_h = ($cant_combo_h > 0) ? ($precio_total_h / $cant_combo_h) : 0;
                $subtotal_h = $precio_total_h;

                $stmt_hc = $conn->prepare("INSERT INTO historial_carritos_cancelados_productos (cancelacion_id, producto_id, combo_id, nombre, cantidad, precio_unitario, subtotal) VALUES (?, NULL, ?, ?, ?, ?, ?)");
                if (!$stmt_hc) throw new Exception("prepare historial combo: " . $conn->error);
                $stmt_hc->bind_param("iisidd", $cancelacion_id, $combo_id_h, $nombre_combo_h, $cant_combo_h, $precio_unitario_h, $subtotal_h);
                $stmt_hc->execute();
                $stmt_hc->close();
            }

            // ============================================
            // 3. DEVOLVER STOCK DE COMBOS
            // ============================================
            $stmt = $conn->prepare("SELECT cc.combo_id, cc.cantidad, c.nombre FROM carrito_combos cc JOIN combos c ON cc.combo_id = c.id WHERE cc.carrito_id = ?");
            if (!$stmt) throw new Exception("prepare combos historial: " . $conn->error);
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $combos_historial = $stmt->get_result();

            while ($combo_item = $combos_historial->fetch_assoc()) {
                $combo_id = intval($combo_item['combo_id']);
                $cant_combo = intval($combo_item['cantidad']);

                // 2a. Devolver stock del combo
                $stmt_cs = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                if (!$stmt_cs) throw new Exception("prepare stock combo: " . $conn->error);
                $stmt_cs->bind_param("ii", $cant_combo, $combo_id);
                $stmt_cs->execute();
                $stmt_cs->close();

                // 2b. Devolver stock de productos internos del combo
                $stmt_cp = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                if (!$stmt_cp) throw new Exception("prepare combo_productos: " . $conn->error);
                $stmt_cp->bind_param("i", $combo_id);
                $stmt_cp->execute();
                $prod_internos = $stmt_cp->get_result();
                $stmt_cp->close();

                while ($pi = $prod_internos->fetch_assoc()) {
                    $stock_devolver = intval($pi['cantidad']) * $cant_combo;
                    $stmt_pi = $conn->prepare("
                        UPDATE productos 
                        SET cantidad = cantidad + ?,
                            reservado_por_combos = reservado_por_combos + ?,
                            fecha_actualizacion_reserva = NOW(),
                            en_combo = 1,
                            fecha_agotado = NULL
                        WHERE id = ?
                    ");
                    if (!$stmt_pi) throw new Exception("prepare stock producto: " . $conn->error);
                    $stmt_pi->bind_param("iii", $stock_devolver, $stock_devolver, $pi['producto_id']);
                    $stmt_pi->execute();
                    $stmt_pi->close();
                }
            }
            $stmt->close();

            // ============================================
            // 4. BORRAR PRODUCTOS Y COMBOS DEL CARRITO
            // ============================================
            $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ?");
            if (!$stmt) throw new Exception("prepare delete: " . $conn->error);
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM carrito_combos WHERE carrito_id = ?");
            if (!$stmt) throw new Exception("prepare delete combos: " . $conn->error);
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("UPDATE carritos SET estado = 'cancelado', fecha_cierre = NOW(), motivo_cancelacion = 'cancelado_por_admin' WHERE id = ?");
            if (!$stmt) throw new Exception("prepare update estado: " . $conn->error);
            $stmt->bind_param("i", $carrito_id);
            $stmt->execute();
            $stmt->close();

                        $conn->commit();
            $_SESSION['mensaje'] = "✅ Carrito cancelado correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
            error_log("[carritos_gestion] cancelar_carrito OK. Usuario: $usuario_id_actual, carrito: $carrito_id");
        } catch (Throwable $e) {
            $conn->rollback();
            error_log("[carritos_gestion] cancelar_carrito error: " . $e->getMessage());
            $_SESSION['mensaje'] = "❌ " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "error";
        }
        header('Location: /admin/carritos_gestion.php?' . http_build_query($_GET));
        exit;
    }

        // ---- Eliminar combo
    if ($accion === 'eliminar_combo' && $puede_gestionar) {
        $combo_id = isset($_POST['combo_id']) ? intval($_POST['combo_id']) : 0;
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("SELECT cantidad FROM carrito_combos WHERE carrito_id = ? AND combo_id = ? FOR UPDATE");
            if (!$stmt) throw new Exception("prepare select combo: " . $conn->error);
            $stmt->bind_param("ii", $carrito_id, $combo_id);
            $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($item) {
                $cant_combo = intval($item['cantidad']);

                // 1. Devolver stock del combo
                $stmt = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                if (!$stmt) throw new Exception("prepare stock combo: " . $conn->error);
                $stmt->bind_param("ii", $cant_combo, $combo_id);
                $stmt->execute();
                $stmt->close();

                // 2. Devolver stock de productos internos del combo
                $stmt = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                if (!$stmt) throw new Exception("prepare combo_productos: " . $conn->error);
                $stmt->bind_param("i", $combo_id);
                $stmt->execute();
                $prod_internos = $stmt->get_result();
                $stmt->close();

                while ($pi = $prod_internos->fetch_assoc()) {
                    $stock_devolver = intval($pi['cantidad']) * $cant_combo;
                    $stmt_pi = $conn->prepare("
                        UPDATE productos 
                        SET cantidad = cantidad + ?,
                            reservado_por_combos = reservado_por_combos + ?,
                            fecha_actualizacion_reserva = NOW(),
                            en_combo = 1,
                            fecha_agotado = NULL
                        WHERE id = ?
                    ");
                    if (!$stmt_pi) throw new Exception("prepare stock producto: " . $conn->error);
                    $stmt_pi->bind_param("iii", $stock_devolver, $stock_devolver, $pi['producto_id']);
                    $stmt_pi->execute();
                    $stmt_pi->close();
                }

                // 3. Eliminar del carrito
                $stmt = $conn->prepare("DELETE FROM carrito_combos WHERE carrito_id = ? AND combo_id = ?");
                if (!$stmt) throw new Exception("prepare delete combo: " . $conn->error);
                $stmt->bind_param("ii", $carrito_id, $combo_id);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                $_SESSION['mensaje'] = "✅ Combo eliminado del carrito y stock devuelto";
                $_SESSION['tipo_mensaje'] = "exito";
                error_log("[carritos_gestion] eliminar_combo OK. Usuario: $usuario_id_actual, carrito: $carrito_id, combo: $combo_id");
            } else {
                $conn->rollback();
                $_SESSION['mensaje'] = "❌ Combo no encontrado";
                $_SESSION['tipo_mensaje'] = "error";
            }
        } catch (Throwable $e) {
            $conn->rollback();
            error_log("[carritos_gestion] eliminar_combo error: " . $e->getMessage());
            $_SESSION['mensaje'] = "❌ " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "error";
        }
        header('Location: /admin/carritos_gestion.php?' . http_build_query($_GET));
        exit;
    }
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if ($proveedor_id_usuario > 0) {
    $where[] = "ca.proveedor_id = ?";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
} elseif ($proveedor_filtro_get > 0) {
    $where[] = "ca.proveedor_id = ?";
    $params[] = $proveedor_filtro_get;
    $types .= "i";
}

if (!empty($_GET['carrito_id'])) {
    $where[] = "ca.id = ?";
    $params[] = intval($_GET['carrito_id']);
    $types .= "i";
}

if (!empty($_GET['cliente'])) {
    $where[] = "(c.nombre LIKE ? OR c.apellidos LIKE ? OR c.email LIKE ?)";
    $search = "%" . $_GET['cliente'] . "%";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= "sss";
}

if (!empty($_GET['estado'])) {
    $where[] = "ca.estado = ?";
    $params[] = $_GET['estado'];
    $types .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $where[] = "DATE(ca.fecha_inicio) >= ?";
    $params[] = $_GET['fecha_desde'];
    $types .= "s";
}

if (!empty($_GET['fecha_hasta'])) {
    $where[] = "DATE(ca.fecha_inicio) <= ?";
    $params[] = $_GET['fecha_hasta'];
    $types .= "s";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// CONTAR TOTAL
// ============================================
$count_sql = "SELECT COUNT(*) as total FROM carritos ca JOIN clientes c ON ca.cliente_id = c.id $sql_where";
$total_registros = 0;
$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($params)) $count_stmt->bind_param($types, ...$params);
    $count_stmt->execute();
    $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $count_stmt->close();
} else {
    error_log("[carritos_gestion] prepare count: " . $conn->error);
}

$total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA PRINCIPAL
// ============================================
$sql = "SELECT 
            ca.*,
            ca.moneda AS carrito_moneda,
            c.nombre,
            c.apellidos,
            c.email,
            CONCAT(c.nombre, ' ', c.apellidos) AS cliente_nombre,
            (
                (SELECT COUNT(*) FROM carrito_productos WHERE carrito_id = ca.id) +
                (SELECT COUNT(*) FROM carrito_combos WHERE carrito_id = ca.id)
            ) as total_productos,
            (
                (SELECT COALESCE(SUM(cantidad), 0) FROM carrito_productos WHERE carrito_id = ca.id) +
                (SELECT COALESCE(SUM(cantidad), 0) FROM carrito_combos WHERE carrito_id = ca.id)
            ) as total_items,
            (
                (SELECT COALESCE(SUM(COALESCE(precio_convertido, cantidad * precio_unitario)), 0) FROM carrito_productos WHERE carrito_id = ca.id) +
                (SELECT COALESCE(SUM(COALESCE(precio_convertido, precio_total)), 0) FROM carrito_combos WHERE carrito_id = ca.id)
            ) as total_monto_convertido,
            (
                (SELECT COALESCE(SUM(cantidad * precio_unitario), 0) FROM carrito_productos WHERE carrito_id = ca.id) +
                (SELECT COALESCE(SUM(precio_total), 0) FROM carrito_combos WHERE carrito_id = ca.id)
            ) as total_monto_usd
        FROM carritos ca
        JOIN clientes c ON ca.cliente_id = c.id
        $sql_where
        $order_sql
        LIMIT ? OFFSET ?";

$params_select = $params;
$types_select = $types . 'ii';
$params_select[] = $por_pagina;
$params_select[] = $offset;

$carritos = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param($types_select, ...$params_select);
    $stmt->execute();
    $carritos = $stmt->get_result();
    $stmt->close();
} else {
    error_log("[carritos_gestion] prepare select: " . $conn->error);
}

// ============================================
// ESTADÍSTICAS (con el mismo filtro)
// ============================================
$stats = ['total' => 0, 'pendientes' => 0, 'comprados' => 0, 'cancelados' => 0, 'expirados' => 0];
$stats_where = "";
$stats_params = [];
$stats_types = "";

if ($proveedor_id_usuario > 0) {
    $stats_where = " WHERE ca.proveedor_id = ?";
    $stats_params[] = $proveedor_id_usuario;
    $stats_types .= "i";
} elseif ($proveedor_filtro_get > 0) {
    $stats_where = " WHERE ca.proveedor_id = ?";
    $stats_params[] = $proveedor_filtro_get;
    $stats_types .= "i";
}

$stats_sql = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
    SUM(CASE WHEN estado = 'comprado' THEN 1 ELSE 0 END) as comprados,
    SUM(CASE WHEN estado = 'cancelado' THEN 1 ELSE 0 END) as cancelados,
    SUM(CASE WHEN estado = 'expirado' THEN 1 ELSE 0 END) as expirados
    FROM carritos ca $stats_where";

$stats_stmt = $conn->prepare($stats_sql);
if ($stats_stmt) {
    if (!empty($stats_params)) $stats_stmt->bind_param($stats_types, ...$stats_params);
    $stats_stmt->execute();
    $row = $stats_stmt->get_result()->fetch_assoc();
    if ($row) {
        $stats = [
            'total' => intval($row['total'] ?? 0),
            'pendientes' => intval($row['pendientes'] ?? 0),
            'comprados' => intval($row['comprados'] ?? 0),
            'cancelados' => intval($row['cancelados'] ?? 0),
            'expirados' => intval($row['expirados'] ?? 0),
        ];
    }
    $stats_stmt->close();
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
} else {
    $mensaje = '';
    $tipo_mensaje = 'info';
}

// Helper para link de ordenamiento
function linkOrden($campo, $order_by, $order_dir, $label) {
    $query = $_GET;
    $query['order_by'] = $campo;
    if ($order_by === $campo) {
        $query['order_dir'] = ($order_dir === 'ASC') ? 'DESC' : 'ASC';
    } else {
        $query['order_dir'] = 'ASC';
    }
    $arrow = '';
    if ($order_by === $campo) {
        $arrow = ($order_dir === 'ASC') ? ' ▲' : ' ▼';
    }
    return '<a href="?' . htmlspecialchars(http_build_query($query)) . '" style="color:white; text-decoration:none; white-space:nowrap;">' . htmlspecialchars($label) . $arrow . '</a>';
}
?>

<style>
:root {
    --primary: <?php echo htmlspecialchars($color_primario); ?>;
    --secondary: <?php echo htmlspecialchars($color_secundario); ?>;
}

* { box-sizing: border-box; }

.gestion-container {
    width: 100%;
    max-width: 1400px;
    margin: 1rem auto;
    padding: 0 1rem;
}
@media (min-width: 768px) {
    .gestion-container { margin: 2rem auto; padding: 0 2rem; }
}

.gestion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}
@media (max-width: 640px) {
    .gestion-header { justify-content: center; text-align: center; }
}
.gestion-header h1 {
    font-size: clamp(1.3rem, 5vw, 2rem);
    color: #2d3748;
    margin: 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}
@media (min-width: 640px) {
    .stats-grid { grid-template-columns: repeat(5, 1fr); gap: 1rem; }
}
.stat-card {
    background: white;
    border-radius: 10px;
    padding: 0.75rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    text-align: center;
}
@media (min-width: 768px) {
    .stat-card { padding: 1rem; }
}
.stat-card.pendiente { border-top: 3px solid #ecc94b; }
.stat-card.comprado { border-top: 3px solid #48bb78; }
.stat-card.cancelado { border-top: 3px solid #f56565; }
.stat-card.expirado { border-top: 3px solid #9ca3af; }
.stat-card .label {
    font-size: 0.65rem;
    color: #718096;
    text-transform: uppercase;
}
.stat-card .value {
    font-size: clamp(1rem, 4vw, 1.5rem);
    font-weight: 700;
    color: #2d3748;
}

.filtros-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
@media (min-width: 768px) { .filtros-card { padding: 1.5rem; } }
.filtros-linea {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 0.5rem;
}
.filtro-item { flex: 1; min-width: 0; }
.filtro-item label {
    display: block;
    font-size: 0.65rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.2rem;
    text-transform: uppercase;
}
.filtro-item input,
.filtro-item select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 16px;
    min-height: 44px;
}
.filtro-fecha { min-width: 0; max-width: 130px; }
@media (max-width: 768px) {
    .filtros-linea { flex-direction: column; align-items: stretch; gap: 0.75rem; }
    .filtro-fecha { max-width: none; }
}
.filtros-botones { display: flex; gap: 0.5rem; flex-shrink: 0; }
.btn-filtro {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.8rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 44px;
}
.btn-filtro-aplicar {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
}
.btn-filtro-limpiar { background: #edf2f7; color: #4a5568; }

.tabla-carritos {
    background: white;
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    margin-bottom: 1.5rem;
    width: 100%;
}
.tabla-carritos table {
    width: 100%;
    min-width: 900px;
    border-collapse: collapse;
    font-size: 0.75rem;
}
@media (min-width: 768px) { .tabla-carritos table { font-size: 0.85rem; } }
.tabla-carritos th {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
    padding: 0.7rem 0.5rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.7rem;
    text-transform: uppercase;
    white-space: nowrap;
}
.tabla-carritos td {
    padding: 0.7rem 0.5rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: middle;
}

.badge-estado {
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.7rem;
    color: white;
    display: inline-block;
    white-space: nowrap;
}
.badge-pendiente { background: #ecc94b; }
.badge-comprado { background: #48bb78; }
.badge-cancelado { background: #f56565; }
.badge-expirado { background: #9ca3af; }

.btn-accion {
    padding: 0.3rem 0.6rem;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.75rem;
    margin: 0 0.15rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: none;
    cursor: pointer;
    color: white;
    min-height: 32px;
}
.btn-ver { background: #4299e1; }
.btn-cancelar { background: #f56565; }
.btn-historial { background: #9c27b0; }

.mensaje {
    padding: 0.75rem;
    border-radius: 10px;
    margin-bottom: 1rem;
    font-size: 0.85rem;
}
.mensaje.exito { background: #f0fff4; color: #22543d; border: 1px solid #48bb78; }
.mensaje.error { background: #fff5f5; color: #742a2a; border: 1px solid #f56565; }

.text-right { text-align: right; }
.text-center { text-align: center; }
.sin-datos { padding: 2rem !important; text-align: center; color: #a0aec0; }

.modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
}
.modal-content {
    background: white;
    margin: 10% auto;
    padding: 1.25rem;
    border-radius: 12px;
    max-width: 95%;
    width: 95%;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
    animation: slideDown 0.3s;
}
@media (min-width: 768px) {
    .modal-content { margin: 5% auto; padding: 2rem; max-width: 900px; }
}
@keyframes slideDown {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
.close {
    position: absolute;
    top: 0.75rem;
    right: 1rem;
    font-size: 1.8rem;
    cursor: pointer;
    color: #718096;
}
.close:hover { color: #2d3748; }

.paginacion-container {
    display: flex;
    justify-content: center;
    gap: 0.3rem;
    flex-wrap: wrap;
    margin-top: 1.5rem;
}
.paginacion-container a,
.paginacion-container span {
    padding: 0.4rem 0.8rem;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
    border: 1px solid #e2e8f0;
    background: white;
    color: #374151;
    min-width: 40px;
    min-height: 44px;
    text-align: center;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
.paginacion-container a:hover {
    background: var(--primary, #667eea);
    color: white;
    border-color: var(--primary, #667eea);
}
.paginacion-container .active {
    background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
    color: white;
    border-color: var(--primary, #667eea);
}
.paginacion-container .disabled { opacity: 0.4; cursor: not-allowed; }
</style>

<div class="gestion-container">
    <div class="gestion-header">
        <h1>🛒 Gestión de Carritos</h1>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Total Carritos</div>
            <div class="value"><?php echo number_format($stats['total']); ?></div>
        </div>
        <div class="stat-card pendiente">
            <div class="label">Pendientes</div>
            <div class="value"><?php echo number_format($stats['pendientes']); ?></div>
        </div>
        <div class="stat-card comprado">
            <div class="label">Completados</div>
            <div class="value"><?php echo number_format($stats['comprados']); ?></div>
        </div>
        <div class="stat-card cancelado">
            <div class="label">Cancelados</div>
            <div class="value"><?php echo number_format($stats['cancelados']); ?></div>
        </div>
        <div class="stat-card expirado">
            <div class="label">Expirados</div>
            <div class="value"><?php echo number_format($stats['expirados']); ?></div>
        </div>
    </div>

    <?php if (!empty($mensaje)): ?>
        <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <div class="filtros-card">
        <form method="GET" class="filtros-form" id="formFiltros">
            <div class="filtros-linea">
                <?php if ($puede_filtrar_proveedor && !empty($lista_proveedores)): ?>
                <div class="filtro-item" style="flex: 1.5;">
                    <label>🏪 Proveedor</label>
                    <select name="proveedor_id" class="filtro-auto">
                        <option value="">Todos los proveedores</option>
                        <?php foreach ($lista_proveedores as $prov): ?>
                            <option value="<?php echo intval($prov['id']); ?>" 
                                <?php echo ($proveedor_filtro_get === intval($prov['id'])) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="filtro-item">
                    <label>ID</label>
                    <input type="number" name="carrito_id" class="filtro-auto" value="<?php echo htmlspecialchars($_GET['carrito_id'] ?? ''); ?>" placeholder="123" min="0">
                </div>
                <div class="filtro-item">
                    <label>Cliente</label>
                    <input type="text" name="cliente" class="filtro-auto" value="<?php echo htmlspecialchars($_GET['cliente'] ?? ''); ?>" placeholder="Nombre o email">
                </div>
                <div class="filtro-item">
                    <label>Estado</label>
                    <select name="estado" class="filtro-auto">
                        <option value="">Todos</option>
                        <option value="pendiente" <?php echo ($_GET['estado'] ?? '') === 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                        <option value="comprado" <?php echo ($_GET['estado'] ?? '') === 'comprado' ? 'selected' : ''; ?>>Comprado</option>
                        <option value="cancelado" <?php echo ($_GET['estado'] ?? '') === 'cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                        <option value="expirado" <?php echo ($_GET['estado'] ?? '') === 'expirado' ? 'selected' : ''; ?>>Expirado</option>
                    </select>
                </div>
                <div class="filtro-item filtro-fecha">
                    <label>Desde</label>
                    <input type="date" name="fecha_desde" class="filtro-auto" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>">
                </div>
                <div class="filtro-item filtro-fecha">
                    <label>Hasta</label>
                    <input type="date" name="fecha_hasta" class="filtro-auto" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>">
                </div>
                <div class="filtros-botones">
                    <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
                    <a href="/admin/carritos_gestion.php" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
                </div>
            </div>
        </form>
    </div>

    <div class="tabla-carritos">
        <table>
            <thead>
                <tr>
                    <th><?php echo linkOrden('id', $order_by, $order_dir, 'ID'); ?></th>
                    <th><?php echo linkOrden('cliente', $order_by, $order_dir, 'Cliente'); ?></th>
                    <th><?php echo linkOrden('email', $order_by, $order_dir, 'Email'); ?></th>
                    <th><?php echo linkOrden('inicio', $order_by, $order_dir, 'Inicio'); ?></th>
                    <th><?php echo linkOrden('expira', $order_by, $order_dir, 'Expira'); ?></th>
                    <th><?php echo linkOrden('estado', $order_by, $order_dir, 'Estado'); ?></th>
                    <th><?php echo linkOrden('productos', $order_by, $order_dir, 'Prod'); ?></th>
                    <th><?php echo linkOrden('items', $order_by, $order_dir, 'Items'); ?></th>
                    <th><?php echo linkOrden('total', $order_by, $order_dir, 'Total'); ?></th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($carritos && $carritos->num_rows > 0): ?>
                    <?php while($c = $carritos->fetch_assoc()): 
                        $estado_class = 'badge-pendiente';
                        $estado_texto = ucfirst($c['estado'] ?? '');
                        if ($c['estado'] === 'pendiente') { $estado_class = 'badge-pendiente'; $estado_texto = 'Pendiente'; }
                        elseif ($c['estado'] === 'comprado') { $estado_class = 'badge-comprado'; $estado_texto = 'Comprado'; }
                        elseif ($c['estado'] === 'cancelado') { $estado_class = 'badge-cancelado'; $estado_texto = 'Cancelado'; }
                        elseif ($c['estado'] === 'expirado') { $estado_class = 'badge-expirado'; $estado_texto = 'Expirado'; }

                        $ts_ini = strtotime($c['fecha_inicio'] ?? '');
                        $fecha_ini = ($ts_ini !== false) ? date('d/m/Y H:i', $ts_ini) : '—';
                        $fecha_exp = '-';
                        if (!empty($c['fecha_expiracion'])) {
                            $ts_exp = strtotime($c['fecha_expiracion']);
                            if ($ts_exp !== false) $fecha_exp = date('d/m/Y H:i', $ts_exp);
                        }
                    ?>
                    <tr>
                        <td>#<?php echo intval($c['id']); ?></td>
                        <td><strong><?php echo htmlspecialchars(trim(($c['nombre'] ?? '') . ' ' . ($c['apellidos'] ?? ''))); ?></strong></td>
                        <td><?php echo htmlspecialchars($c['email'] ?? ''); ?></td>
                        <td><?php echo $fecha_ini; ?></td>
                        <td><?php echo $fecha_exp; ?></td>
                        <td><span class="badge-estado <?php echo $estado_class; ?>"><?php echo htmlspecialchars($estado_texto); ?></span></td>
                        <td class="text-center"><?php echo intval($c['total_productos'] ?? 0); ?></td>
                        <td class="text-center"><?php echo intval($c['total_items'] ?? 0); ?></td>
                        <td class="text-right">
    <?php 
    $moneda_carrito = strtoupper($c['carrito_moneda'] ?? 'USD');
    $simbolo_carrito = getSimboloPorMoneda($moneda_carrito);
    $total_mostrar = floatval($c['total_monto_convertido'] ?? 0);
    if ($total_mostrar <= 0) {
        $total_mostrar = floatval($c['total_monto_usd'] ?? 0);
    }
    echo htmlspecialchars($simbolo_carrito, ENT_QUOTES, 'UTF-8') . number_format($total_mostrar, 2);
    if ($moneda_carrito !== 'USD'):
    ?>
        <br><small style="color:#718096;">$<?php echo number_format(floatval($c['total_monto_usd'] ?? 0), 2); ?> USD</small>
    <?php endif; ?>
</td>
                        <td>
                            <button onclick="verDetalleCarrito(<?php echo intval($c['id']); ?>)" class="btn-accion btn-ver" title="Ver">👁️</button>
                            <button onclick="verHistorialCarrito(<?php echo intval($c['id']); ?>)" class="btn-accion btn-historial" title="Historial">📜</button>
                            <?php if ($puede_gestionar && $c['estado'] === 'pendiente'): ?>
                                <form method="POST" action="/admin/carritos_gestion.php?<?php echo http_build_query($_GET); ?>" style="display:inline; margin:0;" onsubmit="return confirm('¿Cancelar este carrito? Se devolverá el stock.')">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="accion" value="cancelar_carrito">
                                    <input type="hidden" name="carrito_id" value="<?php echo intval($c['id']); ?>">
                                    <button type="submit" class="btn-accion btn-cancelar" title="Cancelar">❌</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10" class="text-center sin-datos">📭 No hay carritos para mostrar</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($total_paginas > 1): 
        $query_params = $_GET;
    ?>
    <div class="paginacion-container">
        <?php if ($pagina_actual > 1): ?>
            <?php $query_params['pagina'] = 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">«</a>
            <?php $query_params['pagina'] = $pagina_actual - 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
        <?php else: ?>
            <span class="disabled">«</span>
            <span class="disabled">‹</span>
        <?php endif; ?>

        <?php
        $rango = 3;
        $inicio = max(1, $pagina_actual - $rango);
        $fin = min($total_paginas, $pagina_actual + $rango);

        if ($inicio > 1) {
            $query_params['pagina'] = 1;
            echo '<a href="?' . http_build_query($query_params) . '">1</a>';
            if ($inicio > 2) echo '<span>…</span>';
        }

        for ($i = $inicio; $i <= $fin; $i++) {
            if ($i == $pagina_actual) {
                echo '<span class="active">' . $i . '</span>';
            } else {
                $query_params['pagina'] = $i;
                echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
            }
        }

        if ($fin < $total_paginas) {
            if ($fin < $total_paginas - 1) echo '<span>…</span>';
            $query_params['pagina'] = $total_paginas;
            echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
        }
        ?>

        <?php if ($pagina_actual < $total_paginas): ?>
            <?php $query_params['pagina'] = $pagina_actual + 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">›</a>
            <?php $query_params['pagina'] = $total_paginas; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">»</a>
        <?php else: ?>
            <span class="disabled">›</span>
            <span class="disabled">»</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<div id="modalDetalleCarrito" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalDetalleCarrito')">&times;</span>
        <div id="contenidoDetalleCarrito">Cargando...</div>
    </div>
</div>

<div id="modalHistorialCarrito" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <span class="close" onclick="cerrarModal('modalHistorialCarrito')">&times;</span>
        <div id="contenidoHistorialCarrito">Cargando...</div>
    </div>
</div>

<script>
// ===== Auto-submit de filtros (debounce) =====
(function() {
    const form = document.getElementById('formFiltros');
    if (!form) return;

    let timer = null;
    const debounce = 500; // ms

    function submitForm() {
        // Resetear página al cambiar filtros
        const paginaInput = form.querySelector('input[name="pagina"]');
        if (!paginaInput) {
            const hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'pagina';
            hidden.value = '1';
            form.appendChild(hidden);
        } else {
            paginaInput.value = '1';
        }
        form.submit();
    }

    form.querySelectorAll('.filtro-auto').forEach(function(el) {
        if (el.tagName === 'SELECT') {
            el.addEventListener('change', function() {
                submitForm();
            });
        } else if (el.type === 'date') {
            el.addEventListener('change', function() {
                submitForm();
            });
        } else {
            el.addEventListener('input', function() {
                clearTimeout(timer);
                timer = setTimeout(submitForm, debounce);
            });
        }
    });
})();

function verDetalleCarrito(carritoId) {
    const modal = document.getElementById('modalDetalleCarrito');
    const contenido = document.getElementById('contenidoDetalleCarrito');
    modal.style.display = 'block';
    contenido.innerHTML = '<div style="text-align:center; padding:2rem;">🔄 Cargando...</div>';
    fetch('/admin/detalle_carrito_json.php?id=' + encodeURIComponent(carritoId))
        .then(r => r.text())
        .then(html => { contenido.innerHTML = html; })
        .catch(() => { contenido.innerHTML = '<div style="text-align:center; padding:2rem; color:#f56565;">❌ Error al cargar</div>'; });
}

function verHistorialCarrito(carritoId) {
    const modal = document.getElementById('modalHistorialCarrito');
    const contenido = document.getElementById('contenidoHistorialCarrito');
    modal.style.display = 'block';
    contenido.innerHTML = '<div style="text-align:center; padding:2rem;">🔄 Cargando historial...</div>';
    fetch('/admin/historial_carrito_json.php?id=' + encodeURIComponent(carritoId))
        .then(r => r.text())
        .then(html => { contenido.innerHTML = html; })
        .catch(() => { contenido.innerHTML = '<div style="text-align:center; padding:2rem; color:#f56565;">❌ Error al cargar historial</div>'; });
}

function cerrarModal(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        cerrarModal('modalDetalleCarrito');
        cerrarModal('modalHistorialCarrito');
    }
});

window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
});
</script>

<?php
require_once __DIR__ . '/../footer.php';
?>
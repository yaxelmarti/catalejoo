<?php
require_once '../header.php';
require_once '../conexion.php';

if (!isset($permisos['crear']) || !$permisos['crear']) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

$carrito_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$carrito_id) {
    header('Location: reportes_carritos.php');
    exit;
}

// Obtener información del carrito y cliente
$stmt = $conn->prepare("
    SELECT ca.*, 
           c.nombre, c.apellidos, c.email, c.documento, c.movil,
           (SELECT SUM(cantidad * precio_unitario) FROM carrito_productos WHERE carrito_id = ca.id) as total
    FROM carritos ca
    JOIN clientes c ON ca.cliente_id = c.id
    WHERE ca.id = ?
");
$stmt->bind_param("i", $carrito_id);
$stmt->execute();
$carrito = $stmt->get_result()->fetch_assoc();

if (!$carrito) {
    header('Location: reportes_carritos.php');
    exit;
}

// Obtener productos del carrito
$stmt = $conn->prepare("
    SELECT cp.*, p.nombre, p.descripcion, p.imagen_url
    FROM carrito_productos cp
    JOIN productos p ON cp.producto_id = p.id
    WHERE cp.carrito_id = ?
");
$stmt->bind_param("i", $carrito_id);
$stmt->execute();
$productos = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Carrito #<?php echo $carrito_id; ?></title>
    <link rel="stylesheet" href="../estilo.css">
    <style>
        .cliente-info {
            background: #f8fafc;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
        }
        
        .info-item .label {
            font-size: 0.8rem;
            color: #718096;
            text-transform: uppercase;
        }
        
        .info-item .value {
            font-size: 1rem;
            font-weight: 600;
        }
        
        .tabla-productos {
            margin-top: 2rem;
        }
        
        .producto-imagen {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
        }
        
        .total-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem;
            border-radius: 10px;
            margin-top: 2rem;
            text-align: right;
        }
        
        .total-card .total-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .total-card .total-value {
            font-size: 2rem;
            font-weight: 600;
        }
        
        .btn-secondary {
            background: #edf2f7;
            color: #4a5568;
            padding: 0.6rem 1.2rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
        }
        
        .btn-secondary:hover {
            background: #e2e8f0;
        }
        
        .text-right { text-align: right; }
        .text-center { text-align: center; }
    </style>
</head>
<body>
    <div class="container" style="margin-top: 2rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h1>🛒 Detalle del Carrito #<?php echo $carrito_id; ?></h1>
            <a href="../reportes.php?tab=carritos" class="btn-volver">← Volver a Carritos</a>
        </div>
        
        <!-- Información del cliente -->
        <div class="cliente-info">
            <h3>👤 Información del Cliente</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="label">Nombre</span>
                    <span class="value"><?php echo htmlspecialchars($carrito['nombre'] . ' ' . $carrito['apellidos']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Email</span>
                    <span class="value"><?php echo htmlspecialchars($carrito['email']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Documento</span>
                    <span class="value"><?php echo htmlspecialchars($carrito['documento']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Móvil</span>
                    <span class="value"><?php echo htmlspecialchars($carrito['movil']); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Información del carrito -->
        <div class="cliente-info">
            <h3>📦 Información del Carrito</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="label">Estado</span>
                    <span class="value"><?php echo ucfirst($carrito['estado']); ?></span>
                </div>
                <div class="info-item">
                    <span class="label">Fecha inicio</span>
                    <span class="value"><?php echo date('d/m/Y H:i', strtotime($carrito['fecha_inicio'])); ?></span>
                </div>
                <?php if ($carrito['fecha_cierre']): ?>
                <div class="info-item">
                    <span class="label">Fecha cierre</span>
                    <span class="value"><?php echo date('d/m/Y H:i', strtotime($carrito['fecha_cierre'])); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($carrito['motivo_cancelacion']): ?>
                <div class="info-item">
                    <span class="label">Motivo cancelación</span>
                    <span class="value"><?php echo $carrito['motivo_cancelacion']; ?></span>
                </div>
                <?php endif; ?>
                <?php if ($carrito['tiempo_proceso']): ?>
                <div class="info-item">
                    <span class="label">Tiempo en proceso</span>
                    <span class="value"><?php echo round($carrito['tiempo_proceso'] / 60, 1); ?> horas</span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Productos -->
        <div class="tabla-clientes">
            <h3>📋 Productos</h3>
            <table>
                <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Producto</th>
                        <th>Precio unitario</th>
                        <th>Cantidad</th>
                        <th>Subtotal</th>
                        <th>Stock al momento</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $subtotal = 0;
                    while($p = $productos->fetch_assoc()): 
                        $subtotal += $p['cantidad'] * $p['precio_unitario'];
                    ?>
                    <tr>
                        <td>
                            <?php if ($p['imagen_url']): ?>
                                <img src="<?php echo htmlspecialchars($p['imagen_url']); ?>" class="producto-imagen"
                                     onerror="this.onerror=null; this.src=''; this.alt='Sin imagen'">
                            <?php else: ?>
                                <span>📦</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo htmlspecialchars($p['nombre']); ?></strong></td>
                        <td class="text-right">$<?php echo number_format($p['precio_unitario'], 2); ?></td>
                        <td class="text-center"><?php echo $p['cantidad']; ?></td>
                        <td class="text-right">$<?php echo number_format($p['cantidad'] * $p['precio_unitario'], 2); ?></td>
                        <td class="text-center"><?php echo $p['inventario_disponible']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Total -->
        <div class="total-card">
            <div class="total-label">TOTAL DEL CARRITO</div>
            <div class="total-value">$<?php echo number_format($subtotal, 2); ?></div>
        </div>
    </div>
    
    <?php include '../footer.php'; ?>
</body>
</html>
<?php $conn->close(); ?>
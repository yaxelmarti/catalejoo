<?php
require_once '../header.php';
require_once '../conexion.php';
require_once '../includes/obtener_proveedor_usuario.php';

// ============================================
// VERIFICACIÓN DE PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor'];
$puede_ver = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_ver) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// OBTENER PROVEEDOR DEL USUARIO
// ============================================
$proveedor_data = obtenerProveedorDeUsuario($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$proveedor_id_usuario = $proveedor_data ? $proveedor_data['id'] : 0;

// ============================================
// PERMISOS DE GESTIÓN (cancelar carritos)
// ============================================
$roles_gestion = ['Super Admin', 'Gerente', 'Proveedor', 'Vendedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_gestion);

// ============================================
// PROCESAR ACCIONES
// ============================================
$mensaje = '';
$tipo_mensaje = '';

// Actualizar cantidad de un producto en el carrito
if (isset($_POST['actualizar_cantidad'])) {
    $carrito_id = intval($_POST['carrito_id']);
    $producto_id = intval($_POST['producto_id']);
    $nueva_cantidad = intval($_POST['cantidad']);
    
    $stmt = $conn->prepare("SELECT cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
    $stmt->bind_param("ii", $carrito_id, $producto_id);
    $stmt->execute();
    $actual = $stmt->get_result()->fetch_assoc();
    
    if ($actual) {
        $diferencia = $nueva_cantidad - $actual['cantidad'];
        
        if ($diferencia > 0) {
            $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad - ? WHERE id = ?");
            $stmt->bind_param("ii", $diferencia, $producto_id);
            $stmt->execute();
            
            $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE carrito_id = ? AND producto_id = ?");
            $stmt->bind_param("iii", $nueva_cantidad, $carrito_id, $producto_id);
            $stmt->execute();
            
        } elseif ($diferencia < 0) {
            $diferencia_abs = abs($diferencia);
            $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
            $stmt->bind_param("ii", $diferencia_abs, $producto_id);
            $stmt->execute();
            
            if ($nueva_cantidad == 0) {
                $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
                $stmt->bind_param("ii", $carrito_id, $producto_id);
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("UPDATE carrito_productos SET cantidad = ? WHERE carrito_id = ? AND producto_id = ?");
                $stmt->bind_param("iii", $nueva_cantidad, $carrito_id, $producto_id);
                $stmt->execute();
            }
        }
        
        $_SESSION['mensaje'] = "✅ Cantidad actualizada";
        $_SESSION['tipo_mensaje'] = "exito";
    }
    
    header('Location: carritos_gestion.php?reload=1');
    exit;
}

// Eliminar producto del carrito
if (isset($_GET['eliminar_producto'])) {
    $carrito_id = intval($_GET['carrito_id']);
    $producto_id = intval($_GET['eliminar_producto']);
    
    $stmt = $conn->prepare("SELECT cantidad FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
    $stmt->bind_param("ii", $carrito_id, $producto_id);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    
    if ($item) {
        $stmt = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
        $stmt->bind_param("ii", $item['cantidad'], $producto_id);
        $stmt->execute();
        
        $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ? AND producto_id = ?");
        $stmt->bind_param("ii", $carrito_id, $producto_id);
        $stmt->execute();
        
        $_SESSION['mensaje'] = "✅ Producto eliminado del carrito";
        $_SESSION['tipo_mensaje'] = "exito";
    }
    
    header('Location: carritos_gestion.php?reload=1');
    exit;
}

// Cancelar carrito completo (manual)
if (isset($_GET['cancelar_carrito'])) {
    $carrito_id = intval($_GET['cancelar_carrito']);
    
    // ===== NUEVO: GUARDAR HISTORIAL ANTES DE CANCELAR =====
    // Calcular total del carrito
    $stmt_total = $conn->prepare("SELECT SUM(cp.cantidad * cp.precio_unitario) as total 
                                  FROM carrito_productos cp 
                                  WHERE cp.carrito_id = ?");
    $stmt_total->bind_param("i", $carrito_id);
    $stmt_total->execute();
    $total_result = $stmt_total->get_result()->fetch_assoc();
    $total_carrito = $total_result['total'] ?? 0;
    
    // Obtener cliente_id del carrito
    $stmt_cliente = $conn->prepare("SELECT cliente_id FROM carritos WHERE id = ?");
    $stmt_cliente->bind_param("i", $carrito_id);
    $stmt_cliente->execute();
    $cliente_id_result = $stmt_cliente->get_result()->fetch_assoc();
    $cliente_id_carrito = $cliente_id_result['cliente_id'] ?? 0;
    
    $fecha_actual = date('Y-m-d H:i:s');
    $motivo = 'cancelado_admin';
    
    // Insertar en historial_carritos_cancelados
    $stmt_historial = $conn->prepare("INSERT INTO historial_carritos_cancelados (carrito_id, cliente_id, fecha_cancelacion, motivo, total) VALUES (?, ?, ?, ?, ?)");
    $stmt_historial->bind_param("iissd", $carrito_id, $cliente_id_carrito, $fecha_actual, $motivo, $total_carrito);
    $stmt_historial->execute();
    $cancelacion_id = $conn->insert_id;
    
    // Obtener productos del carrito para guardar en historial
    $stmt_prod = $conn->prepare("SELECT cp.producto_id, cp.cantidad, cp.precio_unitario, p.nombre 
                                 FROM carrito_productos cp 
                                 JOIN productos p ON cp.producto_id = p.id 
                                 WHERE cp.carrito_id = ?");
    $stmt_prod->bind_param("i", $carrito_id);
    $stmt_prod->execute();
    $productos_historial = $stmt_prod->get_result();
    
    while ($item = $productos_historial->fetch_assoc()) {
        $subtotal = $item['cantidad'] * $item['precio_unitario'];
        $stmt_historial_prod = $conn->prepare("INSERT INTO historial_carritos_cancelados_productos (cancelacion_id, producto_id, nombre, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt_historial_prod->bind_param("iisidd", $cancelacion_id, $item['producto_id'], $item['nombre'], $item['cantidad'], $item['precio_unitario'], $subtotal);
        $stmt_historial_prod->execute();
    }
    
    // ===== CÓDIGO ORIGINAL (sin modificar) =====
    $stmt = $conn->prepare("SELECT producto_id, cantidad FROM carrito_productos WHERE carrito_id = ?");
    $stmt->bind_param("i", $carrito_id);
    $stmt->execute();
    $productos = $stmt->get_result();
    
    while ($item = $productos->fetch_assoc()) {
        $stmt2 = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
        $stmt2->bind_param("ii", $item['cantidad'], $item['producto_id']);
        $stmt2->execute();
    }
    
    $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE carrito_id = ?");
    $stmt->bind_param("i", $carrito_id);
    $stmt->execute();
    
    $stmt = $conn->prepare("UPDATE carritos SET estado = 'cancelado', fecha_cierre = NOW(), motivo_cancelacion = 'cancelado_por_admin' WHERE id = ?");
    $stmt->bind_param("i", $carrito_id);
    $stmt->execute();
    
    $_SESSION['mensaje'] = "✅ Carrito cancelado correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    
    header('Location: carritos_gestion.php?reload=1');
    exit;
}

// ============================================
// REDIRECCIÓN FORZADA SI HAY PARÁMETRO RELOAD
// ============================================
if (isset($_GET['reload'])) {
    header('Location: carritos_gestion.php');
    exit;
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

// 🔥 FILTRO POR PROVEEDOR (si el usuario es de tienda)
if ($proveedor_id_usuario > 0) {
    $where[] = "ca.id IN (SELECT DISTINCT carrito_id FROM carrito_productos WHERE proveedor_id = $proveedor_id_usuario)";
}

if (!empty($_GET['carrito_id'])) {
    $where[] = "ca.id = ?";
    $params[] = $_GET['carrito_id'];
    $types .= "i";
}

if (!empty($_GET['cliente'])) {
    $where[] = "(c.nombre LIKE ? OR c.apellidos LIKE ? OR c.email LIKE ?)";
    $search = "%" . $_GET['cliente'] . "%";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= "sss";
}

if (!empty($_GET['estado'])) {
    $where[] = "ca.estado = ?";
    $params[] = $_GET['estado'];
    $types .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $where[] = "DATE(ca.fecha_inicio) >= ?";
    $params[] = $_GET['fecha_desde'];
    $types .= "s";
}

if (!empty($_GET['fecha_hasta'])) {
    $where[] = "DATE(ca.fecha_inicio) <= ?";
    $params[] = $_GET['fecha_hasta'];
    $types .= "s";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ===== CONTAR TOTAL DE REGISTROS =====
$count_sql = "SELECT COUNT(*) as total FROM carritos ca JOIN clientes c ON ca.cliente_id = c.id $sql_where";
$count_result = $conn->query($count_sql);
$total_registros = $count_result->fetch_assoc()['total'];

// ===== INCLUIR VARIABLES DE PAGINACIÓN =====
$base_url = 'carritos_gestion.php?' . http_build_query(array_filter($_GET));
include __DIR__ . '/../includes/paginacion_vars.php';

// ============================================
// CONSULTA PRINCIPAL
// ============================================
$sql = "SELECT 
            ca.*,
            c.nombre,
            c.apellidos,
            c.email,
            (SELECT COUNT(*) FROM carrito_productos WHERE carrito_id = ca.id) as total_productos,
            (SELECT SUM(cantidad) FROM carrito_productos WHERE carrito_id = ca.id) as total_items,
            (SELECT SUM(cantidad * precio_unitario) FROM carrito_productos WHERE carrito_id = ca.id) as total_monto
        FROM carritos ca
        JOIN clientes c ON ca.cliente_id = c.id
        $sql_where
        ORDER BY ca.fecha_inicio DESC
        LIMIT $por_pagina OFFSET $offset";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$carritos = $stmt->get_result();

// ===== ESTADÍSTICAS =====
$stats_where = "";
if ($proveedor_id_usuario > 0) {
    $stats_where = " WHERE id IN (SELECT DISTINCT carrito_id FROM carrito_productos WHERE proveedor_id = $proveedor_id_usuario)";
}
$stats = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
    SUM(CASE WHEN estado = 'comprado' THEN 1 ELSE 0 END) as comprados,
    SUM(CASE WHEN estado = 'cancelado' THEN 1 ELSE 0 END) as cancelados,
    SUM(CASE WHEN estado = 'expirado' THEN 1 ELSE 0 END) as expirados
    FROM carritos$stats_where")->fetch_assoc();

// Mostrar mensajes de sesión
if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}
?>

<!-- ============================================ -->
<!-- ESTILOS RESPONSIVE -->
<!-- ============================================ -->
<style>

* {
    box-sizing: border-box;
}

.gestion-container {
    width: 100%;
    max-width: 1400px;
    margin: 1rem auto;
    padding: 0 1rem;
}

@media (min-width: 768px) {
    .gestion-container {
        margin: 2rem auto;
        padding: 0 2rem;
    }
}

.gestion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

@media (max-width: 640px) {
    .gestion-header {
        justify-content: center;
        text-align: center;
    }
}

.gestion-header h1 {
    font-size: 1.5rem;
    color: #2d3748;
    margin: 0;
}

@media (min-width: 768px) {
    .gestion-header h1 {
        font-size: 2rem;
    }
}

/* Estadísticas */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}

@media (min-width: 640px) {
    .stats-grid {
        grid-template-columns: repeat(5, 1fr);
        gap: 1rem;
    }
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: 0.75rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    text-align: center;
}

@media (min-width: 768px) {
    .stat-card {
        padding: 1rem;
    }
}

.stat-card.pendiente { border-top: 3px solid #ecc94b; }
.stat-card.comprado { border-top: 3px solid #48bb78; }
.stat-card.cancelado { border-top: 3px solid #f56565; }
.stat-card.expirado { border-top: 3px solid #9ca3af; }

.stat-card .label {
    font-size: 0.65rem;
    color: #718096;
    text-transform: uppercase;
}

@media (min-width: 768px) {
    .stat-card .label {
        font-size: 0.8rem;
    }
}

.stat-card .value {
    font-size: 1.2rem;
    font-weight: 700;
    color: #2d3748;
}

@media (min-width: 768px) {
    .stat-card .value {
        font-size: 1.5rem;
    }
}

/* FILTROS - UNA SOLA LÍNEA */
.filtros-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    width: 100%;
}

@media (min-width: 768px) {
    .filtros-card {
        padding: 1.5rem;
    }
}

.filtros-form {
    width: 100%;
}

.filtros-linea {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 0.5rem;
}

.filtro-item {
    flex: 1;
    min-width: 0;
}

.filtro-item label {
    display: block;
    font-size: 0.65rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.2rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.filtro-item input,
.filtro-item select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 0.8rem;
}

/* Fechas más pequeñas */
.filtro-fecha {
    min-width: 0;
    max-width: 130px;
}

.filtro-fecha input {
    padding: 0.5rem;
    font-size: 0.75rem;
}

/* Botones al lado */
.filtros-botones {
    display: flex;
    gap: 0.5rem;
    flex-shrink: 0;
}

.btn-filtro {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.8rem;
    text-decoration: none;
    display: inline-block;
    text-align: center;
    white-space: nowrap;
}

.btn-filtro-aplicar {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
}

.btn-filtro-limpiar {
    background: #edf2f7;
    color: #4a5568;
}

/* Responsive móvil - apilar en vertical */
@media (max-width: 768px) {
    .filtros-linea {
        flex-direction: column;
        align-items: stretch;
        gap: 0.75rem;
    }
    
    .filtro-item {
        width: 100%;
    }
    
    .filtro-fecha {
        max-width: none;
    }
    
    .filtros-botones {
        margin-top: 0.5rem;
    }
    
    .btn-filtro {
        flex: 1;
        text-align: center;
    }
}

/* Tabla con scroll horizontal */
.tabla-carritos {
    background: white;
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    margin-bottom: 1.5rem;
    width: 100%;
}

.tabla-carritos table {
    width: 100%;
    min-width: 700px;
    border-collapse: collapse;
    font-size: 0.75rem;
}

@media (min-width: 768px) {
    .tabla-carritos table {
        font-size: 0.85rem;
    }
}

.tabla-carritos th {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.7rem 0.5rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.7rem;
    text-transform: uppercase;
    white-space: nowrap;
}

@media (min-width: 768px) {
    .tabla-carritos th {
        padding: 0.8rem;
        font-size: 0.75rem;
    }
}

.tabla-carritos td {
    padding: 0.7rem 0.5rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: middle;
}

@media (min-width: 768px) {
    .tabla-carritos td {
        padding: 0.8rem;
    }
}

/* Badges de estado */
.badge-estado {
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.7rem;
    color: white;
    display: inline-block;
    white-space: nowrap;
}

.badge-pendiente { background: #ecc94b; }
.badge-comprado { background: #48bb78; }
.badge-cancelado { background: #f56565; }
.badge-expirado { background: #9ca3af; }

.btn-accion {
    padding: 0.3rem 0.6rem;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.75rem;
    margin: 0 0.15rem;
    display: inline-block;
    border: none;
    cursor: pointer;
}

@media (min-width: 768px) {
    .btn-accion {
        padding: 0.3rem 0.8rem;
        font-size: 0.8rem;
    }
}

.btn-ver {
    background: #4299e1;
    color: white;
}

.btn-cancelar {
    background: #f56565;
    color: white;
}

.mensaje {
    padding: 0.75rem;
    border-radius: 10px;
    margin-bottom: 1rem;
    font-size: 0.85rem;
}

@media (min-width: 768px) {
    .mensaje {
        padding: 1rem;
    }
}

.mensaje.exito {
    background: #f0fff4;
    color: #22543d;
    border: 1px solid #48bb78;
}

.mensaje.error {
    background: #fff5f5;
    color: #742a2a;
    border: 1px solid #f56565;
}

.text-right { text-align: right; }
.text-center { text-align: center; }

.sin-datos {
    padding: 2rem !important;
    text-align: center;
    color: #a0aec0;
}

/* Modal */
.modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
}

.modal-content {
    background: white;
    margin: 10% auto;
    padding: 1.25rem;
    border-radius: 12px;
    max-width: 95%;
    width: 95%;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
    animation: slideDown 0.3s;
}

@media (min-width: 768px) {
    .modal-content {
        margin: 5% auto;
        padding: 2rem;
        max-width: 900px;
        width: 95%;
    }
}

@keyframes slideDown {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.close {
    position: absolute;
    top: 0.75rem;
    right: 1rem;
    font-size: 1.8rem;
    cursor: pointer;
    color: #718096;
}

@media (min-width: 768px) {
    .close {
        top: 1rem;
        right: 1.5rem;
        font-size: 2rem;
    }
}

.close:hover {
    color: #2d3748;
}
</style>

<!-- ============================================ -->
<!-- CONTENIDO -->
<!-- ============================================ -->
<div class="gestion-container">
    <!-- CABECERA -->
    <div class="gestion-header">
        <h1>🛒 Gestión de Carritos</h1>
    </div>

    <!-- ESTADÍSTICAS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Total Carritos</div>
            <div class="value"><?php echo $stats['total']; ?></div>
        </div>
        <div class="stat-card pendiente">
            <div class="label">Pendientes</div>
            <div class="value"><?php echo $stats['pendientes']; ?></div>
        </div>
        <div class="stat-card comprado">
            <div class="label">Completados</div>
            <div class="value"><?php echo $stats['comprados']; ?></div>
        </div>
        <div class="stat-card cancelado">
            <div class="label">Cancelados</div>
            <div class="value"><?php echo $stats['cancelados']; ?></div>
        </div>
        <div class="stat-card expirado">
            <div class="label">Expirados</div>
            <div class="value"><?php echo $stats['expirados'] ?? 0; ?></div>
        </div>
    </div>

    <!-- MENSAJE -->
    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <!-- FILTROS - UNA SOLA LÍNEA -->
    <div class="filtros-card">
        <form method="GET" class="filtros-form">
            <div class="filtros-linea">
                <div class="filtro-item">
                    <label>ID</label>
                    <input type="number" name="carrito_id" value="<?php echo htmlspecialchars($_GET['carrito_id'] ?? ''); ?>" placeholder="123">
                </div>
                
                <div class="filtro-item">
                    <label>Cliente</label>
                    <input type="text" name="cliente" value="<?php echo htmlspecialchars($_GET['cliente'] ?? ''); ?>" placeholder="Nombre o email">
                </div>
                
                <div class="filtro-item">
                    <label>Estado</label>
                    <select name="estado">
                        <option value="">Todos</option>
                        <option value="pendiente" <?php echo ($_GET['estado'] ?? '') == 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                        <option value="comprado" <?php echo ($_GET['estado'] ?? '') == 'comprado' ? 'selected' : ''; ?>>Comprado</option>
                        <option value="cancelado" <?php echo ($_GET['estado'] ?? '') == 'cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                        <option value="expirado" <?php echo ($_GET['estado'] ?? '') == 'expirado' ? 'selected' : ''; ?>>Expirado</option>
                    </select>
                </div>
                
                <div class="filtro-item filtro-fecha">
                    <label>Desde</label>
                    <input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>">
                </div>
                
                <div class="filtro-item filtro-fecha">
                    <label>Hasta</label>
                    <input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>">
                </div>
                
                <div class="filtros-botones">
                    <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
                    <a href="carritos_gestion.php" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
                </div>
            </div>
        </form>
    </div>

    <!-- TABLA DE CARRITOS -->
    <div class="tabla-carritos">
         <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Email</th>
                    <th>Inicio</th>
                    <th>Expira</th>
                    <th>Estado</th>
                    <th>Prod</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </thead>
            <tbody>
                <?php if ($carritos->num_rows > 0): ?>
                    <?php while($c = $carritos->fetch_assoc()): 
                        $estado_class = '';
                        $estado_texto = '';
                        if ($c['estado'] == 'pendiente') {
                            $estado_class = 'badge-pendiente';
                            $estado_texto = 'Pendiente';
                        } elseif ($c['estado'] == 'comprado') {
                            $estado_class = 'badge-comprado';
                            $estado_texto = 'Comprado';
                        } elseif ($c['estado'] == 'cancelado') {
                            $estado_class = 'badge-cancelado';
                            $estado_texto = 'Cancelado';
                        } elseif ($c['estado'] == 'expirado') {
                            $estado_class = 'badge-expirado';
                            $estado_texto = 'Expirado';
                        } else {
                            $estado_class = 'badge-pendiente';
                            $estado_texto = ucfirst($c['estado']);
                        }
                    ?>
                    <tr>
                        <td>#<?php echo $c['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($c['nombre'] . ' ' . $c['apellidos']); ?></strong></td>
                        <td><?php echo htmlspecialchars($c['email']); ?></td>
                        <td class="fecha-cell"><?php echo date('d/m/Y H:i', strtotime($c['fecha_inicio'])); ?></td>
						<td class="fecha-cell"><?php echo $c['fecha_expiracion'] ? date('d/m/Y H:i', strtotime($c['fecha_expiracion'])) : '-'; ?></td>
                        <td><span class="badge-estado <?php echo $estado_class; ?>"><?php echo $estado_texto; ?></span></td>
                        <td class="text-center"><?php echo $c['total_productos']; ?></td>
                        <td class="text-center"><?php echo $c['total_items']; ?></td>
                        <td class="text-right">$<?php echo number_format($c['total_monto'] ?? 0, 2); ?></td>
                        <td>
    <button onclick="verDetalleCarrito(<?php echo $c['id']; ?>)" class="btn-accion btn-ver">👁️ Ver</button>
<button onclick="verHistorialCarrito(<?php echo $c['id']; ?>)" class="btn-accion" style="background: #9c27b0; color: white;">📜</button>
<?php if ($puede_gestionar && $c['estado'] == 'pendiente'): ?>
    <a href="?cancelar_carrito=<?php echo $c['id']; ?>" class="btn-accion btn-cancelar" onclick="return confirm('¿Cancelar este carrito? Se devolverá el stock.')">❌</a>
<?php endif; ?>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10" class="text-center sin-datos">📭 No hay carritos para mostrar</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
       </div>
</div>

<?php
// ===== BOTONES DE PAGINACIÓN =====
include __DIR__ . '/../includes/paginacion_botones.php';
?>

<!-- Modal para ver detalle del carrito -->
<div id="modalDetalleCarrito" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModalCarrito()">&times;</span>
        <div id="contenidoDetalleCarrito">
            Cargando...
        </div>
    </div>
</div>

<!-- Modal para historial de cancelaciones -->
<div id="modalHistorialCarrito" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <span class="close" onclick="cerrarModalHistorial()">&times;</span>
        <div id="contenidoHistorialCarrito">
            Cargando...
        </div>
    </div>
</div>

<script>
function verDetalleCarrito(carritoId) {
    const modal = document.getElementById('modalDetalleCarrito');
    const contenido = document.getElementById('contenidoDetalleCarrito');
    
    modal.style.display = 'block';
    contenido.innerHTML = '<div style="text-align:center; padding:2rem;">🔄 Cargando...</div>';
    
    fetch('detalle_carrito_json.php?id=' + carritoId)
        .then(response => response.text())
        .then(html => {
            contenido.innerHTML = html;
        })
        .catch(error => {
            contenido.innerHTML = '<div style="text-align:center; padding:2rem; color:#f56565;">❌ Error al cargar el detalle</div>';
        });
}

function cerrarModalCarrito() {
    document.getElementById('modalDetalleCarrito').style.display = 'none';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        cerrarModalCarrito();
    }
});

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
    
    function verHistorialCarrito(carritoId) {
    const modal = document.getElementById('modalHistorialCarrito');
    const contenido = document.getElementById('contenidoHistorialCarrito');
    
    modal.style.display = 'block';
    contenido.innerHTML = '<div style="text-align:center; padding:2rem;">🔄 Cargando historial...</div>';
    
    fetch('historial_carrito_json.php?id=' + carritoId)
        .then(response => response.text())
        .then(html => {
            contenido.innerHTML = html;
        })
        .catch(error => {
            contenido.innerHTML = '<div style="text-align:center; padding:2rem; color:#f56565;">❌ Error al cargar el historial</div>';
        });
}

function cerrarModalHistorial() {
    document.getElementById('modalHistorialCarrito').style.display = 'none';
}
</script>

<?php
$conn->close();
include '../footer.php';
?>
<?php
require_once '../header.php';
require_once '../conexion.php';

if (!isset($permisos['crear']) || !$permisos['crear']) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

$cliente_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$cliente_id) {
    echo '<div style="padding:2rem; text-align:center;">';
    echo '<h2>❌ No se especificó un cliente</h2>';
    echo '<a href="../reportes_clientes.php" style="background:#667eea; color:white; padding:0.5rem 1rem; text-decoration:none; border-radius:5px;">Volver</a>';
    echo '</div>';
    include '../footer.php';
    exit;
}

// Obtener información del cliente
$stmt = $conn->prepare("SELECT nombre, apellidos, email, documento, movil FROM clientes WHERE id = ?");
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$cliente = $stmt->get_result()->fetch_assoc();

if (!$cliente) {
    echo '<div style="padding:2rem; text-align:center;">';
    echo '<h2>❌ Cliente no encontrado</h2>';
    echo '<a href="../reportes_clientes.php" style="background:#667eea; color:white; padding:0.5rem 1rem; text-decoration:none; border-radius:5px;">Volver</a>';
    echo '</div>';
    include '../footer.php';
    exit;
}

// Obtener historial de cambios
$stmt = $conn->prepare("SELECT * FROM historial_clientes_cambios WHERE cliente_id = ? ORDER BY fecha DESC");
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$historial = $stmt->get_result();

$total_cambios = $historial->num_rows;
?>

<style>
:root {
    --primary: #667eea;
    --secondary: #764ba2;
}

.historial-container {
    max-width: 1400px;
    margin: 2rem auto;
    padding: 0 2rem;
}

.historial-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.historial-header h1 {
    font-size: 2rem;
    color: #2d3748;
    margin: 0;
}

.cliente-info {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 1.5rem;
    border-radius: 10px;
    margin-bottom: 2rem;
}

.cliente-info h2 {
    margin-bottom: 0.5rem;
    font-size: 1.5rem;
}

.cliente-info p {
    opacity: 0.9;
    margin: 0.2rem 0;
}

.stats-card {
    background: white;
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 2rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    display: inline-block;
}

.tabla-historial {
    background: white;
    border-radius: 8px;
    padding: 1rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
}

.tabla-historial table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
}

.tabla-historial th {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.8rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.tabla-historial td {
    padding: 0.8rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: top;
}

.campo-modificado {
    font-weight: 600;
    color: #4a5568;
    text-transform: uppercase;
    font-size: 0.75rem;
}

.valor-anterior {
    color: #f56565;
    font-size: 0.9rem;
    max-width: 200px;
    word-break: break-word;
}

.valor-nuevo {
    color: #48bb78;
    font-size: 0.9rem;
    max-width: 200px;
    word-break: break-word;
}

.dispositivo-info {
    font-size: 0.75rem;
    color: #718096;
    max-width: 200px;
    word-break: break-word;
}

.fecha-cell {
    white-space: nowrap;
    font-size: 0.8rem;
}

.ip-cell {
    font-family: monospace;
    font-size: 0.8rem;
    color: #718096;
}

.btn-volver {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-volver:hover {
    background: #e2e8f0;
    transform: translateY(-2px);
}

.sin-cambios {
    text-align: center;
    padding: 3rem;
    color: #a0aec0;
}

@media (max-width: 768px) {
    .historial-container {
        padding: 0 1rem;
    }
    
    .tabla-historial {
        font-size: 0.75rem;
    }
    
    .tabla-historial th,
    .tabla-historial td {
        padding: 0.5rem;
    }
    
    .valor-anterior,
    .valor-nuevo {
        max-width: 100px;
    }
}
</style>

<div class="historial-container">
    <!-- CABECERA -->
    <div class="historial-header">
        <h1>📋 Historial de Cambios del Cliente</h1>
        <a href="../reportes.php?tab=clientes" class="btn-volver">← Volver a Clientes</a>
    </div>

    <!-- INFORMACIÓN DEL CLIENTE -->
    <div class="cliente-info">
        <h2><?php echo htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellidos']); ?></h2>
        <p>📧 <?php echo htmlspecialchars($cliente['email']); ?></p>
        <p>📄 Documento: <?php echo htmlspecialchars($cliente['documento']); ?></p>
        <p>📱 Móvil: <?php echo htmlspecialchars($cliente['movil']); ?></p>
    </div>

    <!-- ESTADÍSTICA -->
    <div class="stats-card">
        <strong>Total de cambios registrados:</strong> <?php echo $total_cambios; ?>
    </div>

    <!-- TABLA DE HISTORIAL -->
    <?php if ($total_cambios > 0): ?>
    <div class="tabla-historial">
        <table>
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Campo modificado</th>
                    <th>Valor anterior</th>
                    <th>Valor nuevo</th>
                    <th>IP</th>
                    <th>Dispositivo</th>
                </tr>
            </thead>
            <tbody>
                <?php while($cambio = $historial->fetch_assoc()): ?>
                <tr>
                    <td class="fecha-cell"><?php echo date('d/m/Y H:i:s', strtotime($cambio['fecha'])); ?></td>
                    <td>
                        <span class="campo-modificado">
                            <?php 
                            $nombre_campo = '';
                            if ($cambio['campo_modificado'] == 'nombre') $nombre_campo = 'Nombre';
                            elseif ($cambio['campo_modificado'] == 'apellidos') $nombre_campo = 'Apellidos';
                            elseif ($cambio['campo_modificado'] == 'email') $nombre_campo = 'Email';
                            elseif ($cambio['campo_modificado'] == 'documento') $nombre_campo = 'Documento';
                            elseif ($cambio['campo_modificado'] == 'movil') $nombre_campo = 'Móvil';
                            else $nombre_campo = $cambio['campo_modificado'];
                            echo $nombre_campo;
                            ?>
                        </span>
                    </td>
                    <td class="valor-anterior"><?php echo htmlspecialchars($cambio['valor_anterior'] ?: '—'); ?></td>
                    <td class="valor-nuevo"><?php echo htmlspecialchars($cambio['valor_nuevo'] ?: '—'); ?></td>
                    <td class="ip-cell"><?php echo $cambio['ip_address'] ?: '—'; ?></td>
                    <td class="dispositivo-info"><?php echo htmlspecialchars(substr($cambio['dispositivo_info'], 0, 100)) . '...'; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="sin-cambios">
        📭 Este cliente no tiene cambios registrados en su historial.
    </div>
    <?php endif; ?>
</div>

<?php
$conn->close();
include '../footer.php';
?>
<?php
// ============================================
// GESTIÓN DE CLIENTES
// Versión 27 Oct 2026
// Ubicación: /admin/clientes.php
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

$rol_actual = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

// ============================================
// PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    error_log("[clientes] Permiso denegado. Rol: $rol_actual, usuario: $usuario_id_actual");
    header('Location: /admin.php?error=permiso');
    exit;
}

$roles_gestion = ['Super Admin', 'Gerente'];
$puede_gestionar = in_array($rol_actual, $roles_gestion, true);

// ============================================
// COLORES DE CONFIGURACIÓN
// ============================================
$color_primario = '#667eea';
$color_secundario = '#764ba2';

$stmt_color = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario' LIMIT 1");
if ($stmt_color) {
    $stmt_color->execute();
    $row_color = $stmt_color->get_result()->fetch_assoc();
    if ($row_color && !empty($row_color['valor'])) {
        $color_primario = $row_color['valor'];
    }
    $stmt_color->close();
}

$stmt_color2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario' LIMIT 1");
if ($stmt_color2) {
    $stmt_color2->execute();
    $row_color2 = $stmt_color2->get_result()->fetch_assoc();
    if ($row_color2 && !empty($row_color2['valor'])) {
        $color_secundario = $row_color2['valor'];
    }
    $stmt_color2->close();
}

// ============================================
// CLIENTES ONLINE
// ============================================
$conn->query("DELETE FROM clientes_online WHERE ultima_actividad < DATE_SUB(NOW(), INTERVAL 2 MINUTE)");

$online_ids = [];
$res_online = $conn->query("SELECT DISTINCT cliente_id FROM clientes_online");
if ($res_online) {
    while($row = $res_online->fetch_assoc()) {
        $cid = intval($row['cliente_id'] ?? 0);
        if ($cid > 0) $online_ids[] = $cid;
    }
}
$online_count = count($online_ids);

$online_info = [];
$res_info = $conn->query("SELECT cliente_id, pagina_actual, ip_address, user_agent, ultima_actividad FROM clientes_online ORDER BY ultima_actividad DESC");
if ($res_info) {
    while($row = $res_info->fetch_assoc()) {
        $online_info[intval($row['cliente_id'])] = $row;
    }
}

// ============================================
// PROCESAR ACCIONES (POST con CSRF)
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!function_exists('csrf_validar') || !csrf_validar($token)) {
        error_log("[clientes] CSRF inválido. Usuario: $usuario_id_actual");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/clientes.php');
        exit;
    }

    $accion_post = $_POST['accion'] ?? '';
    $id_post = isset($_POST['cliente_id']) ? intval($_POST['cliente_id']) : 0;

    // ---- Editar cliente
    if ($accion_post === 'editar_cliente' && $id_post > 0 && $puede_gestionar) {
        $nombre = trim($_POST['nombre'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $movil = trim($_POST['movil'] ?? '');
        $nueva_password = trim($_POST['nueva_password'] ?? '');

        if ($nombre === '' || $email === '') {
            $_SESSION['mensaje'] = "❌ Nombre y email son obligatorios";
            $_SESSION['tipo_mensaje'] = "error";
        } elseif ($nueva_password !== '' && strlen($nueva_password) < 6) {
            $_SESSION['mensaje'] = "❌ La contraseña debe tener al menos 6 caracteres";
            $_SESSION['tipo_mensaje'] = "error";
        } else {
            if ($nueva_password === '') {
                $stmt = $conn->prepare("UPDATE clientes SET nombre = ?, email = ?, movil = ? WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param("sssi", $nombre, $email, $movil, $id_post);
                    if ($stmt->execute()) {
                        $_SESSION['mensaje'] = "✅ Cliente actualizado correctamente";
                        $_SESSION['tipo_mensaje'] = "exito";
                        error_log("[clientes] editar OK. Usuario: $usuario_id_actual, cliente: $id_post");
                    } else {
                        $_SESSION['mensaje'] = "❌ Error al actualizar";
                        $_SESSION['tipo_mensaje'] = "error";
                    }
                    $stmt->close();
                }
            } else {
                $password_hash = password_hash($nueva_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE clientes SET nombre = ?, email = ?, movil = ?, password = ? WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param("ssssi", $nombre, $email, $movil, $password_hash, $id_post);
                    if ($stmt->execute()) {
                        $_SESSION['mensaje'] = "✅ Cliente actualizado (contraseña cambiada)";
                        $_SESSION['tipo_mensaje'] = "exito";
                        error_log("[clientes] editar+pass OK. Usuario: $usuario_id_actual, cliente: $id_post");
                    } else {
                        $_SESSION['mensaje'] = "❌ Error al actualizar";
                        $_SESSION['tipo_mensaje'] = "error";
                    }
                    $stmt->close();
                }
            }
        }
        header('Location: /admin/clientes.php');
        exit;
    }

    // ---- Eliminar dispositivo
    if ($accion_post === 'eliminar_dispositivo' && $id_post > 0 && $puede_gestionar) {
        $campo = $_POST['campo'] ?? '';
        if (in_array($campo, ['uuid', 'uuid2', 'uuid3'], true)) {
            $stmt = $conn->prepare("UPDATE clientes SET $campo = NULL WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $id_post);
                if ($stmt->execute()) {
                    $_SESSION['mensaje'] = "✅ Dispositivo eliminado";
                    $_SESSION['tipo_mensaje'] = "exito";
                    error_log("[clientes] eliminar_dispositivo OK. Usuario: $usuario_id_actual, cliente: $id_post, campo: $campo");
                }
                $stmt->close();
            }
        }
        header('Location: /admin/clientes.php');
        exit;
    }

    // ---- Toggle activo
    if ($accion_post === 'toggle_activo' && $id_post > 0 && $puede_gestionar) {
        $estado = isset($_POST['estado']) ? intval($_POST['estado']) : 0;
        $estado = ($estado === 1) ? 1 : 0;

        $stmt = $conn->prepare("UPDATE clientes SET activo = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ii", $estado, $id_post);
            if ($stmt->execute()) {
                $_SESSION['mensaje'] = "✅ Estado del cliente actualizado";
                $_SESSION['tipo_mensaje'] = "exito";
                error_log("[clientes] toggle_activo OK. Usuario: $usuario_id_actual, cliente: $id_post, estado: $estado");
            }
            $stmt->close();
        }
        header('Location: /admin/clientes.php');
        exit;
    }

    // ---- Eliminar cliente
    if ($accion_post === 'eliminar' && $id_post > 0 && $puede_gestionar) {
        $check = $conn->prepare("SELECT COUNT(*) as total FROM carritos WHERE cliente_id = ?");
        $carritos = 0;
        if ($check) {
            $check->bind_param("i", $id_post);
            $check->execute();
            $carritos = intval($check->get_result()->fetch_assoc()['total'] ?? 0);
            $check->close();
        }

        if ($carritos > 0) {
            $_SESSION['mensaje'] = "❌ No se puede eliminar: el cliente tiene $carritos carrito(s) asociados";
            $_SESSION['tipo_mensaje'] = "error";
        } else {
            $stmt = $conn->prepare("DELETE FROM clientes WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $id_post);
                if ($stmt->execute()) {
                    $_SESSION['mensaje'] = "✅ Cliente eliminado correctamente";
                    $_SESSION['tipo_mensaje'] = "exito";
                    error_log("[clientes] eliminar OK. Usuario: $usuario_id_actual, cliente: $id_post");
                }
                $stmt->close();
            }
        }
        header('Location: /admin/clientes.php');
        exit;
    }
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "(c.nombre LIKE ? OR c.apellidos LIKE ?)";
    $search = "%" . $_GET['nombre'] . "%";
    $params[] = $search;
    $params[] = $search;
    $types .= "ss";
}

if (!empty($_GET['email'])) {
    $where[] = "c.email LIKE ?";
    $params[] = "%" . $_GET['email'] . "%";
    $types .= "s";
}

if (!empty($_GET['documento'])) {
    $where[] = "c.documento LIKE ?";
    $params[] = "%" . $_GET['documento'] . "%";
    $types .= "s";
}

if (!empty($_GET['movil'])) {
    $where[] = "c.movil LIKE ?";
    $params[] = "%" . $_GET['movil'] . "%";
    $types .= "s";
}

if (isset($_GET['activo']) && $_GET['activo'] !== '') {
    $where[] = "c.activo = ?";
    $params[] = intval($_GET['activo']);
    $types .= "i";
}

if (isset($_GET['online']) && $_GET['online'] !== '' && !empty($online_ids)) {
    $ids_validos = array_map('intval', $online_ids);
    $placeholders = implode(',', array_fill(0, count($ids_validos), '?'));
    if ($_GET['online'] == '1') {
        $where[] = "c.id IN ($placeholders)";
        foreach ($ids_validos as $oid) {
            $params[] = $oid;
            $types .= "i";
        }
    } elseif ($_GET['online'] == '0') {
        $where[] = "c.id NOT IN ($placeholders)";
        foreach ($ids_validos as $oid) {
            $params[] = $oid;
            $types .= "i";
        }
    }
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// CONTAR TOTAL
// ============================================
$count_sql = "SELECT COUNT(*) as total FROM clientes c $sql_where";
$total_registros = 0;
$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $count_stmt->close();
} else {
    error_log("[clientes] prepare count: " . $conn->error);
}

$total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA PRINCIPAL
// ============================================
$sql = "SELECT c.*, 
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id) as total_carritos,
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id AND estado = 'pendiente') as carritos_pendientes,
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id AND estado = 'comprado') as compras_realizadas
        FROM clientes c
        $sql_where
        ORDER BY c.fecha_registro DESC
        LIMIT ? OFFSET ?";

$params_select = $params;
$types_select = $types . 'ii';
$params_select[] = $por_pagina;
$params_select[] = $offset;

$clientes = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param($types_select, ...$params_select);
    $stmt->execute();
    $clientes = $stmt->get_result();
    $stmt->close();
} else {
    error_log("[clientes] prepare select: " . $conn->error);
}

// ============================================
// ESTADÍSTICAS
// ============================================
$stats = ['total' => 0, 'activos' => 0, 'inactivos' => 0];
$res_stats = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(activo) as activos,
    SUM(CASE WHEN activo = 0 THEN 1 ELSE 0 END) as inactivos
    FROM clientes");
if ($res_stats) {
    $row_stats = $res_stats->fetch_assoc();
    if ($row_stats) {
        $stats = [
            'total' => intval($row_stats['total'] ?? 0),
            'activos' => intval($row_stats['activos'] ?? 0),
            'inactivos' => intval($row_stats['inactivos'] ?? 0),
        ];
    }
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}
?>

<style>
:root {
    --primary: <?php echo htmlspecialchars($color_primario); ?>;
    --secondary: <?php echo htmlspecialchars($color_secundario); ?>;
}

.gestion-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 0 1rem;
}

@media (min-width: 768px) {
    .gestion-container {
        margin: 2rem auto;
        padding: 0 2rem;
    }
}

.gestion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

@media (max-width: 640px) {
    .gestion-header {
        justify-content: center;
        text-align: center;
    }
}

.gestion-header h1 {
    font-size: clamp(1.3rem, 5vw, 2rem);
    color: #2d3748;
    margin: 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}

@media (min-width: 640px) {
    .stats-grid {
        grid-template-columns: repeat(4, 1fr);
        gap: 1rem;
    }
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: 0.75rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    text-align: center;
}

.stat-card .label {
    font-size: 0.65rem;
    color: #718096;
    text-transform: uppercase;
}

.stat-card .value {
    font-size: clamp(1rem, 4vw, 1.2rem);
    font-weight: 700;
    color: #2d3748;
}

.filtros-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    width: 100%;
}

@media (min-width: 768px) {
    .filtros-card {
        padding: 1.5rem;
    }
}

.filtros-linea {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 0.5rem;
}

.filtro-item {
    flex: 1;
    min-width: 0;
}

.filtro-item label {
    display: block;
    font-size: 0.65rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.2rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.filtro-item input,
.filtro-item select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 16px;
    min-height: 44px;
}

.btn-online {
    background: #48bb78;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    cursor: pointer;
    font-weight: bold;
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 0.8rem;
    white-space: nowrap;
    min-height: 44px;
}

.filtros-botones {
    display: flex;
    gap: 0.5rem;
    flex-shrink: 0;
}

.btn-filtro {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.8rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    white-space: nowrap;
    min-height: 44px;
}

.btn-filtro-aplicar {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
}

.btn-filtro-limpiar {
    background: #edf2f7;
    color: #4a5568;
}

@media (max-width: 768px) {
    .filtros-linea {
        flex-direction: column;
        align-items: stretch;
        gap: 0.75rem;
    }
    
    .filtro-item {
        width: 100%;
    }
    
    .btn-online {
        justify-content: center;
    }
    
    .filtros-botones {
        margin-top: 0.5rem;
    }
    
    .btn-filtro {
        flex: 1;
        text-align: center;
    }
}

.tabla-clientes {
    background: white;
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    width: 100%;
}

.tabla-clientes table {
    width: 100%;
    min-width: 900px;
    border-collapse: collapse;
    font-size: 0.75rem;
}

@media (min-width: 768px) {
    .tabla-clientes table {
        font-size: 0.85rem;
        min-width: 1000px;
    }
}

.tabla-clientes th {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
    padding: 0.7rem 0.5rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.7rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.tabla-clientes td {
    padding: 0.7rem 0.5rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: middle;
}

.online-indicator {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-right: 5px;
}

.online {
    background-color: #48bb78;
    box-shadow: 0 0 5px #48bb78;
}

.offline {
    background-color: #cbd5e0;
}

.email-verificado {
    color: #48bb78;
    font-weight: 600;
}

.email-no-verificado {
    color: #f56565;
    font-weight: 600;
}

.badge-estado {
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.65rem;
    color: white;
    display: inline-block;
    white-space: nowrap;
}

.badge-activo { background: #48bb78; }
.badge-inactivo { background: #f56565; }

.acciones-container {
    display: flex;
    gap: 0.2rem;
    flex-wrap: wrap;
}

.btn-accion {
    width: 32px;
    height: 32px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.8rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: none;
    cursor: pointer;
    transition: all 0.2s;
    color: white;
    flex-shrink: 0;
}

.btn-editar { background: #4299e1; }
.btn-dispositivos { background: #9f7aea; }
.btn-historial { background: #48bb78; }
.btn-activar { background: #48bb78; }
.btn-desactivar { background: #ed8936; }
.btn-eliminar { background: #f56565; }

.mensaje {
    padding: 0.75rem;
    border-radius: 10px;
    margin-bottom: 1rem;
    font-size: 0.85rem;
}

.mensaje.exito {
    background: #f0fff4;
    color: #22543d;
    border: 1px solid #48bb78;
}

.mensaje.error {
    background: #fff5f5;
    color: #742a2a;
    border: 1px solid #f56565;
}

.modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
}

.modal-content {
    background: white;
    margin: 10% auto;
    padding: 1.25rem;
    border-radius: 16px;
    max-width: 95%;
    width: 95%;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
    animation: slideDown 0.3s;
}

@media (min-width: 768px) {
    .modal-content {
        margin: 5% auto;
        padding: 2rem;
        max-width: 500px;
    }
}

.close {
    position: absolute;
    top: 0.75rem;
    right: 1rem;
    font-size: 1.8rem;
    cursor: pointer;
    color: #718096;
}

.close:hover {
    color: #2d3748;
}

.dispositivo-card {
    background: #f8fafc;
    border-radius: 8px;
    padding: 0.8rem;
    margin-bottom: 0.8rem;
    border-left: 4px solid var(--primary, #667eea);
}

.dispositivo-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.5rem;
}

.dispositivo-nombre {
    font-weight: 600;
    color: #2d3748;
    font-size: 0.9rem;
}

.dispositivo-uuid {
    font-family: monospace;
    font-size: 0.7rem;
    color: #718096;
    word-break: break-all;
}

.btn-eliminar-dispositivo {
    background: #f56565;
    color: white;
    padding: 0.2rem 0.5rem;
    border-radius: 4px;
    text-decoration: none;
    font-size: 0.7rem;
    border: none;
    cursor: pointer;
}

.text-right { text-align: right; }
.text-center { text-align: center; }
.sin-datos { padding: 2rem; text-align: center; color: #a0aec0; }

.paginacion-container {
    display: flex;
    justify-content: center;
    gap: 0.3rem;
    flex-wrap: wrap;
    margin-top: 1.5rem;
}
.paginacion-container a,
.paginacion-container span {
    padding: 0.4rem 0.8rem;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
    border: 1px solid #e2e8f0;
    background: white;
    color: #374151;
    min-width: 40px;
    min-height: 44px;
    text-align: center;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
.paginacion-container a:hover {
    background: var(--primary, #667eea);
    color: white;
    border-color: var(--primary, #667eea);
}
.paginacion-container .active {
    background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
    color: white;
    border-color: var(--primary, #667eea);
}
.paginacion-container .disabled {
    opacity: 0.4;
    cursor: not-allowed;
}
</style>

<div class="gestion-container">
    <div class="gestion-header">
        <h1>👥 Gestión de Clientes</h1>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Total Clientes</div>
            <div class="value"><?php echo number_format($stats['total']); ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Activos</div>
            <div class="value"><?php echo number_format($stats['activos']); ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Inactivos</div>
            <div class="value"><?php echo number_format($stats['inactivos']); ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Online</div>
            <div class="value"><?php echo number_format($online_count); ?></div>
        </div>
    </div>

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <div class="filtros-card">
        <form method="GET" class="filtros-form">
            <div class="filtros-linea">
                <div class="filtro-item">
                    <label>Nombre</label>
                    <input type="text" name="nombre" value="<?php echo htmlspecialchars($_GET['nombre'] ?? ''); ?>" placeholder="Buscar...">
                </div>
                <div class="filtro-item">
                    <label>Email</label>
                    <input type="text" name="email" value="<?php echo htmlspecialchars($_GET['email'] ?? ''); ?>" placeholder="correo@ejemplo.com">
                </div>
                <div class="filtro-item">
                    <label>Documento</label>
                    <input type="text" name="documento" value="<?php echo htmlspecialchars($_GET['documento'] ?? ''); ?>" placeholder="12345678">
                </div>
                <div class="filtro-item">
                    <label>Móvil</label>
                    <input type="text" name="movil" value="<?php echo htmlspecialchars($_GET['movil'] ?? ''); ?>" placeholder="555-1234">
                </div>
                <div class="filtro-item">
                    <label>Estado</label>
                    <select name="activo">
                        <option value="">Todos</option>
                        <option value="1" <?php echo ($_GET['activo'] ?? '') === '1' ? 'selected' : ''; ?>>Activos</option>
                        <option value="0" <?php echo ($_GET['activo'] ?? '') === '0' ? 'selected' : ''; ?>>Inactivos</option>
                    </select>
                </div>
                <button type="button" class="btn-online" onclick="verClientesOnline()">🟢 <span id="contadorOnline"><?php echo intval($online_count); ?></span></button>
                <div class="filtros-botones">
                    <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
                    <a href="/admin/clientes.php" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
                </div>
            </div>
        </form>
    </div>

    <div class="tabla-clientes">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Doc.</th>
                    <th>Móvil</th>
                    <th>Registro</th>
                    <th>Estado</th>
                    <th>Carros</th>
                    <th>Disp.</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($clientes && $clientes->num_rows > 0): ?>
                    <?php while($c = $clientes->fetch_assoc()): 
                        $dispositivos = 0;
                        if (!empty($c['uuid'])) $dispositivos++;
                        if (!empty($c['uuid2'])) $dispositivos++;
                        if (!empty($c['uuid3'])) $dispositivos++;
                        $online_actual = in_array(intval($c['id']), $online_ids, true);
                        $ts_reg = strtotime($c['fecha_registro'] ?? '');
                        $fecha_reg = ($ts_reg !== false) ? date('d/m/y', $ts_reg) : '—';
                        $email_str = (string)($c['email'] ?? '');
                        $email_corto = htmlspecialchars(substr($email_str, 0, 15)) . (strlen($email_str) > 15 ? '...' : '');
                        $nombre_js = htmlspecialchars(json_encode(($c['nombre'] ?? '') . ' ' . ($c['apellidos'] ?? '')), ENT_QUOTES, 'UTF-8');
                    ?>
                    <tr>
                        <td>#<?php echo intval($c['id']); ?></td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 0.2rem;">
                                <span class="online-indicator <?php echo $online_actual ? 'online' : 'offline'; ?>" title="<?php echo $online_actual ? 'Online' : 'Offline'; ?>"></span>
                                <strong><?php echo htmlspecialchars(trim(($c['nombre'] ?? '') . ' ' . ($c['apellidos'] ?? ''))); ?></strong>
                            </div>
                        </td>
                        <td>
                            <?php if (!empty($c['email_verified'])): ?>
                                <span class="email-verificado" title="Email verificado">✓ <?php echo $email_corto; ?></span>
                            <?php else: ?>
                                <span class="email-no-verificado" title="Email no verificado">⚠️ <?php echo $email_corto; ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars(substr((string)($c['documento'] ?? ''), 0, 8)); ?></td>
                        <td><?php echo htmlspecialchars(substr((string)($c['movil'] ?? ''), 0, 8)); ?></td>
                        <td><?php echo $fecha_reg; ?></td>
                        <td><span class="badge-estado <?php echo !empty($c['activo']) ? 'badge-activo' : 'badge-inactivo'; ?>"><?php echo !empty($c['activo']) ? 'Act' : 'Inact'; ?></span></td>
                        <td class="text-center"><?php echo intval($c['total_carritos'] ?? 0); ?></td>
                        <td class="text-center"><?php echo intval($dispositivos); ?></td>
                        <td>
                            <div class="acciones-container">
                                <?php if ($puede_gestionar): ?>
                                    <button onclick='editarCliente(<?php echo intval($c['id']); ?>, <?php echo htmlspecialchars(json_encode($c['nombre'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($c['email'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($c['movil'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>)' class="btn-accion btn-editar" title="Editar">✏️</button>
                                <?php endif; ?>
                                <button onclick='verDispositivos(<?php echo intval($c['id']); ?>, <?php echo htmlspecialchars(json_encode(($c['nombre'] ?? '') . ' ' . ($c['apellidos'] ?? '')), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($c['uuid'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($c['uuid2'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>, <?php echo htmlspecialchars(json_encode($c['uuid3'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>)' class="btn-accion btn-dispositivos" title="Dispositivos">📱</button>
                                <a href="/admin/historial_cliente_cambios.php?id=<?php echo intval($c['id']); ?>" class="btn-accion btn-historial" title="Historial">📋</a>
                                <?php if ($puede_gestionar): ?>
                                    <form method="POST" action="/admin/clientes.php" style="display:inline; margin:0;" onsubmit="return confirm('¿<?php echo !empty($c['activo']) ? 'Desactivar' : 'Activar'; ?> cliente?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="accion" value="toggle_activo">
                                        <input type="hidden" name="cliente_id" value="<?php echo intval($c['id']); ?>">
                                        <input type="hidden" name="estado" value="<?php echo !empty($c['activo']) ? 0 : 1; ?>">
                                        <button type="submit" class="btn-accion <?php echo !empty($c['activo']) ? 'btn-desactivar' : 'btn-activar'; ?>" title="<?php echo !empty($c['activo']) ? 'Desactivar' : 'Activar'; ?>"><?php echo !empty($c['activo']) ? '🔴' : '🟢'; ?></button>
                                    </form>
                                    <?php if (intval($c['total_carritos'] ?? 0) == 0): ?>
                                        <form method="POST" action="/admin/clientes.php" style="display:inline; margin:0;" onsubmit="return confirm('¿Eliminar cliente?')">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="accion" value="eliminar">
                                            <input type="hidden" name="cliente_id" value="<?php echo intval($c['id']); ?>">
                                            <button type="submit" class="btn-accion btn-eliminar" title="Eliminar">🗑️</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="10" class="sin-datos">📭 No hay clientes</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($total_paginas > 1): 
        $query_params = $_GET;
    ?>
    <div class="paginacion-container">
        <?php if ($pagina_actual > 1): ?>
            <?php $query_params['pagina'] = 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">«</a>
            <?php $query_params['pagina'] = $pagina_actual - 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
        <?php else: ?>
            <span class="disabled">«</span>
            <span class="disabled">‹</span>
        <?php endif; ?>

        <?php
        $rango = 3;
        $inicio = max(1, $pagina_actual - $rango);
        $fin = min($total_paginas, $pagina_actual + $rango);

        if ($inicio > 1) {
            $query_params['pagina'] = 1;
            echo '<a href="?' . http_build_query($query_params) . '">1</a>';
            if ($inicio > 2) echo '<span>…</span>';
        }

        for ($i = $inicio; $i <= $fin; $i++) {
            if ($i == $pagina_actual) {
                echo '<span class="active">' . $i . '</span>';
            } else {
                $query_params['pagina'] = $i;
                echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
            }
        }

        if ($fin < $total_paginas) {
            if ($fin < $total_paginas - 1) echo '<span>…</span>';
            $query_params['pagina'] = $total_paginas;
            echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
        }
        ?>

        <?php if ($pagina_actual < $total_paginas): ?>
            <?php $query_params['pagina'] = $pagina_actual + 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">›</a>
            <?php $query_params['pagina'] = $total_paginas; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">»</a>
        <?php else: ?>
            <span class="disabled">›</span>
            <span class="disabled">»</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<!-- MODALES -->
<div id="modalEditarCliente" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalEditarCliente')">&times;</span>
        <h2 style="font-size: 1.3rem;">✏️ Editar Cliente</h2>
        <form method="POST" action="/admin/clientes.php" id="formEditarCliente">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="accion" value="editar_cliente">
            <input type="hidden" name="cliente_id" id="edit_id">
            
            <div style="margin-bottom: 0.8rem;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Nombre</label>
                <input type="text" name="nombre" id="edit_nombre" required style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px; min-height:44px; font-size:16px;">
            </div>
            
            <div style="margin-bottom: 0.8rem;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Email</label>
                <input type="email" name="email" id="edit_email" required style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px; min-height:44px; font-size:16px;">
            </div>
            
            <div style="margin-bottom: 0.8rem;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Móvil</label>
                <input type="text" name="movil" id="edit_movil" required style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px; min-height:44px; font-size:16px;">
            </div>
            
            <div style="margin-bottom: 1rem; padding-top: 0.5rem; border-top: 1px solid #e2e8f0;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Nueva Contraseña</label>
                <input type="password" name="nueva_password" id="edit_password" style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px; min-height:44px; font-size:16px;" placeholder="Dejar en blanco para no cambiar">
                <small style="color: #718096; font-size:0.7rem;">🔒 Mínimo 6 caracteres</small>
            </div>
            
            <button type="submit" style="width:100%; padding:0.8rem; background:linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color:white; border:none; border-radius:4px; cursor:pointer; min-height:44px;">Actualizar Datos</button>
        </form>
    </div>
</div>

<div id="modalDispositivos" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalDispositivos')">&times;</span>
        <h2 style="font-size: 1.3rem;">📱 Dispositivos</h2>
        <div id="contenidoDispositivos"></div>
    </div>
</div>

<div id="modalClientesOnline" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <span class="close" onclick="cerrarModal('modalClientesOnline')">&times;</span>
        <h2 style="font-size: 1.3rem;">👥 Clientes Online</h2>
        <div style="overflow-x: auto;">
            <table style="width:100%; border-collapse:collapse; min-width:600px;">
                <thead>
                    <tr style="background:#f8fafc;">
                        <th style="padding:0.5rem; text-align:left;">Cliente</th>
                        <th style="padding:0.5rem; text-align:left;">Página</th>
                        <th style="padding:0.5rem; text-align:left;">Actividad</th>
                        <th style="padding:0.5rem; text-align:left;">IP</th>
                    </tr>
                </thead>
                <tbody id="listaClientesOnline">
                    <tr><td colspan="4" style="text-align:center; padding:1rem;">Cargando...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function editarCliente(id, nombre, email, movil) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nombre').value = nombre;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_movil').value = movil;
    document.getElementById('edit_password').value = '';
    document.getElementById('modalEditarCliente').style.display = 'block';
}

function verDispositivos(id, nombre, uuid, uuid2, uuid3) {
    let html = '<p><strong>' + escapeHtml(nombre) + '</strong></p>';
    const dispositivos = [
        { nombre: 'Principal', uuid: uuid, campo: 'uuid' },
        { nombre: 'Dispositivo 2', uuid: uuid2, campo: 'uuid2' },
        { nombre: 'Dispositivo 3', uuid: uuid3, campo: 'uuid3' }
    ];
    dispositivos.forEach(function(disp) {
        if (disp.uuid) {
            const uuidCorto = escapeHtml(disp.uuid.substring(0, 20)) + '...';
            html += '<div class="dispositivo-card">' +
                '<div class="dispositivo-header">' +
                '<span class="dispositivo-nombre">' + escapeHtml(disp.nombre) + '</span>' +
                '<form method="POST" action="/admin/clientes.php" style="display:inline; margin:0;" onsubmit="return confirm(\'¿Eliminar este dispositivo?\')">' +
                '<input type="hidden" name="csrf_token" value="' + escapeHtml(getCsrfToken()) + '">' +
                '<input type="hidden" name="accion" value="eliminar_dispositivo">' +
                '<input type="hidden" name="cliente_id" value="' + id + '">' +
                '<input type="hidden" name="campo" value="' + escapeHtml(disp.campo) + '">' +
                '<button type="submit" class="btn-eliminar-dispositivo">Eliminar</button>' +
                '</form>' +
                '</div>' +
                '<div class="dispositivo-uuid">' + uuidCorto + '</div>' +
                '</div>';
        } else {
            html += '<div class="dispositivo-card" style="opacity:0.5;"><span class="dispositivo-nombre">' + escapeHtml(disp.nombre) + '</span><br><span style="color:#a0aec0;">Vacío</span></div>';
        }
    });
    document.getElementById('contenidoDispositivos').innerHTML = html;
    document.getElementById('modalDispositivos').style.display = 'block';
}

function getCsrfToken() {
    const input = document.querySelector('input[name="csrf_token"]');
    return input ? input.value : '';
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function verClientesOnline() {
    document.getElementById('modalClientesOnline').style.display = 'block';
    cargarClientesOnline();
}

function cargarClientesOnline() {
    fetch('/admin/clientes_online_json.php')
        .then(function(response) { return response.json(); })
        .then(function(data) {
            let html = '';
            if (!data || data.length === 0) {
                html = '<tr><td colspan="4" style="text-align:center;">📭 No hay clientes online</td></tr>';
            } else {
                data.forEach(function(c) {
                    const pagina = (c.pagina_actual || '');
                    const paginaCorta = pagina.length > 25 ? pagina.substring(0, 25) + '...' : pagina;
                    html += '<tr>' +
                        '<td><strong>' + escapeHtml((c.nombre || '') + ' ' + (c.apellidos || '')) + '</strong></td>' +
                        '<td>' + escapeHtml(paginaCorta) + '</td>' +
                        '<td>' + escapeHtml(c.tiempo || '') + '</td>' +
                        '<td>' + escapeHtml(c.ip_address || '') + '</td>' +
                        '</tr>';
                });
            }
            document.getElementById('listaClientesOnline').innerHTML = html;
            document.getElementById('contadorOnline').innerHTML = data.length;
        })
        .catch(function() {
            document.getElementById('listaClientesOnline').innerHTML = '<tr><td colspan="4" style="text-align:center;color:#f56565;">Error</td></tr>';
        });
}

function cerrarModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

setInterval(function() {
    if (document.getElementById('modalClientesOnline').style.display === 'block') {
        cargarClientesOnline();
    }
}, 30000);

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>

<?php
require_once __DIR__ . '/../footer.php';
?>
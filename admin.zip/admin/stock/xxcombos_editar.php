<?php
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

$roles_permitidos = ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_gestionar) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

// Validar que el proveedor existe y está activo
if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$es_edicion = ($id > 0);
$combo = null;
$productos_seleccionados = [];

if ($es_edicion) {
    $stmt = $conn->prepare("SELECT * FROM combos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $combo = $stmt->get_result()->fetch_assoc();
    
    if (!$combo) {
        header('Location: combos.php?error=no_encontrado');
        exit;
    }

if ($es_edicion && $combo) {
    // Verificar que el combo pertenece al proveedor
    if ($proveedor_id_usuario > 0 && $combo['proveedor_id'] != $proveedor_id_usuario) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para editar este combo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
}
    
    $stmt_prod = $conn->prepare("SELECT cp.producto_id, cp.cantidad, p.nombre, p.precio_costo, p.precio, p.categoria_id, c.nombre as categoria_nombre, c.icono as categoria_icono
                                 FROM combo_productos cp 
                                 JOIN productos p ON cp.producto_id = p.id 
                                 LEFT JOIN categorias c ON p.categoria_id = c.id
                                 WHERE cp.combo_id = ?");
    $stmt_prod->bind_param("i", $id);
    $stmt_prod->execute();
    $result_prod = $stmt_prod->get_result();
    while ($row = $result_prod->fetch_assoc()) {
        $productos_seleccionados[] = $row;
    }
}

// Obtener configuración de moneda
$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion WHERE clave IN ('moneda_simbolo', 'moneda_codigo')");
while($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}
$moneda_simbolo = $config['moneda_simbolo'] ?? '$';
$moneda_codigo = $config['moneda_codigo'] ?? 'USD';
?>

<style>
:root {
    --primary: <?php echo $color_primario; ?>;
    --secondary: <?php echo $color_secundario; ?>;
}

.form-container {
    background: white;
    border-radius: 16px;
    padding: 1.5rem;
    margin-top: 1rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.form-group {
    margin-bottom: 0.75rem;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 0.25rem;
    color: #2d3748;
    font-size: 0.8rem;
}

.form-control {
    width: 100%;
    padding: 0.5rem 0.75rem;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 0.85rem;
    transition: all 0.3s;
}

.form-control:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
}

/* Fila de 3 columnas */
.row-3 {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    gap: 1rem;
    align-items: end;
}

/* Tabla de productos */
.productos-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 0.5rem;
    font-size: 0.8rem;
}

.productos-table th {
    text-align: left;
    padding: 0.5rem;
    background: #f7fafc;
    font-weight: 600;
    font-size: 0.75rem;
    border-bottom: 2px solid #e2e8f0;
}

.productos-table td {
    padding: 0.5rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: middle;
}

.btn-agregar {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.4rem 0.8rem;
    border: none;
    border-radius: 6px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.3rem;
    font-size: 0.75rem;
}

.btn-eliminar {
    background: #ef4444;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 0.2rem 0.5rem;
    cursor: pointer;
    font-size: 0.7rem;
}

.btn-eliminar:hover {
    background: #dc2626;
}

.btn-guardar {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-guardar:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102,126,234,0.3);
}

.btn-cancelar {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}

.btn-cancelar:hover {
    background: #e2e8f0;
}

.btn-acciones {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
    justify-content: flex-end;
}

/* Resumen de totales - Una sola línea */
.resumen-linea {
    background: #f7fafc;
    border-radius: 10px;
    padding: 0.5rem 1rem;
    margin: 0.75rem 0;
}

.resumen-items {
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.resumen-item {
    text-align: center;
    padding: 0.25rem 0.5rem;
}

.resumen-label {
    font-size: 0.65rem;
    text-transform: uppercase;
    color: #718096;
    margin-bottom: 0.15rem;
}

.resumen-valor {
    font-size: 0.9rem;
    font-weight: 700;
    color: #2d3748;
}

/* Barra azul inferior - texto en negro */
.barra-precio {
    background: linear-gradient(135deg, <?php echo $color_primario; ?> 0%, <?php echo $color_secundario; ?> 100%);
    border-radius: 10px;
    padding: 0.5rem 1rem;
    margin: 0.75rem 0;
}

.barra-precio .resumen-label {
    color: rgba(0,0,0,0.7);
}

.barra-precio .resumen-valor {
    color: #000000;
    font-weight: 800;
}

/* Modal compacto */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
    z-index: 2000;
    justify-content: center;
    align-items: center;
}

.modal-contenido {
    background: white;
    border-radius: 12px;
    padding: 1.25rem;
    max-width: 450px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
}

.close-modal {
    position: absolute;
    top: 0.5rem;
    right: 1rem;
    font-size: 1.2rem;
    cursor: pointer;
    color: #a0aec0;
}

.autocomplete-container {
    position: relative;
}

.autocomplete-list {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: white;
    border: 1px solid #e2e8f0;
    border-top: none;
    border-radius: 0 0 8px 8px;
    max-height: 200px;
    overflow-y: auto;
    z-index: 1000;
    display: none;
}

.autocomplete-list.show {
    display: block;
}

.autocomplete-item {
    padding: 0.4rem 0.6rem;
    cursor: pointer;
    border-bottom: 1px solid #edf2f7;
    font-size: 0.8rem;
}

.autocomplete-item:hover {
    background: #f7fafc;
}

.autocomplete-item .nombre {
    font-weight: 600;
}

.autocomplete-item .detalle {
    font-size: 0.65rem;
    color: #718096;
    margin-left: 0.5rem;
}

.text-right {
    text-align: right;
}

.cantidad-producto {
    width: 60px;
    padding: 0.2rem;
    text-align: center;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
}

/* ============================================ */
/* FORMULARIO DE COMBO - RESPONSIVE             */
/* ============================================ */
.combo-form-grid {
    display: grid;
    grid-template-columns: 1.5fr 1fr;
    gap: 1rem;
    align-items: stretch;
}

.combo-form-izquierda {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.combo-form-fila {
    display: grid;
    grid-template-columns: 2fr 1.2fr;
    gap: 1rem;
}

.combo-form-derecha {
    display: flex;
    flex-direction: column;
}

.combo-form-derecha .form-group {
    height: 100%;
}

.combo-form-derecha textarea {
    height: 280px;
    min-height: 280px;
    max-height: 400px;
    resize: vertical;
}

/* ============================================ */
/* RESPONSIVE                                   */
/* ============================================ */
@media (max-width: 768px) {
    .combo-form-grid {
        grid-template-columns: 1fr;
        gap: 0.8rem;
    }
    
    .combo-form-fila {
        grid-template-columns: 1fr 1fr;
        gap: 0.8rem;
    }
    
    .combo-form-derecha textarea {
        min-height: 120px;
    }
    
    .form-group {
        margin-bottom: 0.5rem;
    }
}

@media (max-width: 480px) {
    .combo-form-fila {
        grid-template-columns: 1fr;
        gap: 0.5rem;
    }
    
    .combo-form-derecha textarea {
        min-height: 100px;
    }
}
</style>

<main class="main-content">
    <div class="form-container">
        <h2 style="margin-bottom: 1rem; font-size: 1.3rem;"><?php echo $es_edicion ? '✏️ Editar Combo' : '➕ Crear Nuevo Combo'; ?></h2>
        
        <form method="POST" action="combos_guardar.php" id="formCombo">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input type="hidden" name="productos_json" id="productos_json" value="">
            
<!-- ============================================ -->
<!-- FORMULARIO DE EDICIÓN DE COMBO               -->
<!-- ============================================ -->

<!-- Fila principal: Campos izquierda + Descripción -->
<div class="combo-form-grid">
    
    <!-- Columna izquierda: Nombre, Proveedor, Stock, Rebaja, Imagen, Estado -->
    <div class="combo-form-izquierda">
        <!-- Nombre + Proveedor -->
        <div class="combo-form-fila">
            <div class="form-group">
                <label>📝 Nombre del Combo *</label>
                <input type="text" name="nombre" class="form-control" required value="<?php echo htmlspecialchars($combo['nombre'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>🏪 Proveedor</label>
                <select name="proveedor_id" class="form-control" <?php echo $proveedor_id_usuario > 0 ? 'disabled' : ''; ?>>
    <?php if ($proveedor_id_usuario > 0): ?>
        <!-- Si es proveedor, forzar su ID y ocultar el select -->
        <option value="<?php echo $proveedor_id_usuario; ?>" selected>
            🏪 <?php echo htmlspecialchars(obtenerNombreTienda($conn, $proveedor_id_usuario)); ?>
        </option>
    <?php else: ?>
        <option value="">Sin proveedor</option>
        <?php
        $proveedores_result = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda");
        while($prov = $proveedores_result->fetch_assoc()):
            $selected = (isset($combo['proveedor_id']) && $combo['proveedor_id'] == $prov['id']) ? 'selected' : '';
        ?>
            <option value="<?php echo $prov['id']; ?>" <?php echo $selected; ?>>
                🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
            </option>
        <?php endwhile; ?>
    <?php endif; ?>
</select>
<?php if ($proveedor_id_usuario > 0): ?>
    <input type="hidden" name="proveedor_id" value="<?php echo $proveedor_id_usuario; ?>">
<?php endif; ?>
            </div>
        </div>
        
        <!-- Stock + Rebaja -->
        <div class="combo-form-fila">
            <div class="form-group">
                <label>📦 Stock</label>
                <input type="number" name="stock_combo" class="form-control" min="0" value="<?php echo $combo['stock_combo'] ?? 0; ?>" required>
            </div>
            <div class="form-group">
                <label>💰 Rebaja (%)</label>
                <input type="number" name="porcentaje_rebaja" id="porcentaje_rebaja" class="form-control" min="0" max="100" step="1" value="<?php echo $combo['porcentaje_rebaja'] ?? 0; ?>" oninput="calcularTotales()">
            </div>
        </div>
        
        <!-- Imagen URL + Estado -->
        <div class="combo-form-fila">
            <div class="form-group" style="margin-bottom: 0;">
                <label>🖼️ Imagen URL</label>
                <input type="text" name="imagen_url" class="form-control" placeholder="/uploads/combos/imagen.jpg" value="<?php echo htmlspecialchars($combo['imagen_url'] ?? ''); ?>">
            </div>
            <div class="form-group" style="margin-bottom: 0;">
                <label>⚡ Estado</label>
                <select name="activo" class="form-control">
                    <option value="1" <?php echo (isset($combo['activo']) && $combo['activo'] == 1) ? 'selected' : ''; ?>>✅ Activo</option>
                    <option value="0" <?php echo (isset($combo['activo']) && $combo['activo'] == 0) ? 'selected' : ''; ?>>❌ Inactivo</option>
                </select>
            </div>
        </div>
    </div>
    
    <!-- Columna derecha: Descripción (alta, ocupa toda la altura) -->
    <div class="combo-form-derecha">
        <div class="form-group" style="height: 100%; display: flex; flex-direction: column; margin-bottom: 0;">
            <label>📄 Descripción</label>
            <textarea name="descripcion" class="form-control" rows="8" style="resize: vertical; height: 100%; min-height: 200px; width: 100%;"><?php echo htmlspecialchars($combo['descripcion'] ?? ''); ?></textarea>
        </div>
    </div>
</div>
            
            <h3 style="margin: 0.75rem 0 0.5rem; font-size: 1rem;">📦 Productos del Combo</h3>
            
            <!-- Botón agregar arriba -->
            <div style="margin-bottom: 0.5rem; text-align: right;">
                <button type="button" class="btn-agregar" onclick="abrirModalAgregarProducto()">➕ Agregar Producto</button>
            </div>
            
            <div style="overflow-x: auto;">
                <table class="productos-table" id="tablaProductos">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Cant</th>
                            <th>Costo</th>
                            <th>Venta</th>
                            <th>Imp.Costo</th>
                            <th>Imp.Venta</th>
                            <th>Gan.</th>
                            <th></th>
                        </thead>
                    </thead>
                    <tbody id="tablaProductosBody">
                        <?php foreach($productos_seleccionados as $item): ?>
                        <tr data-producto-id="<?php echo $item['producto_id']; ?>" data-precio-costo="<?php echo $item['precio_costo']; ?>" data-precio-venta="<?php echo $item['precio']; ?>">
                            <td><?php echo htmlspecialchars($item['nombre']); ?></td>
                            <td><?php echo ($item['categoria_icono'] ?? '📦') . ' ' . htmlspecialchars(substr($item['categoria_nombre'] ?? 'Sin cat.', 0, 15)); ?></td>
                            <td><input type="number" class="cantidad-producto" value="<?php echo $item['cantidad']; ?>" min="1" style="width: 55px;" onchange="actualizarFila(this)"></td>
                            <td class="text-right"><?php echo $moneda_simbolo; ?><?php echo number_format($item['precio_costo'], 2); ?></td>
                            <td class="text-right"><?php echo $moneda_simbolo; ?><?php echo number_format($item['precio'], 2); ?></td>
                            <td class="importe-costo text-right"><?php echo $moneda_simbolo; ?><?php echo number_format($item['precio_costo'] * $item['cantidad'], 2); ?></td>
                            <td class="importe-venta text-right"><?php echo $moneda_simbolo; ?><?php echo number_format($item['precio'] * $item['cantidad'], 2); ?></td>
                            <td class="ganancia text-right"><?php echo $moneda_simbolo; ?><?php echo number_format(($item['precio'] - $item['precio_costo']) * $item['cantidad'], 2); ?></td>
                            <td><button type="button" class="btn-eliminar" onclick="eliminarProducto(this)">🗑️</button></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Botón agregar abajo -->
            <div style="margin-top: 0.5rem; text-align: right;">
                <button type="button" class="btn-agregar" onclick="abrirModalAgregarProducto()">➕ Agregar Producto</button>
            </div>
            
            <!-- Resumen de totales - Una sola línea -->
            <div class="resumen-linea">
                <div class="resumen-items">
                    <div class="resumen-item"><div class="resumen-label">📦 PROD</div><div class="resumen-valor" id="totalProductosDistintos">0</div></div>
                    <div class="resumen-item"><div class="resumen-label">🔢 UNID</div><div class="resumen-valor" id="totalUnidades">0</div></div>
                    <div class="resumen-item"><div class="resumen-label">💰 T-COSTO</div><div class="resumen-valor" id="totalCosto"><?php echo $moneda_simbolo; ?>0.00</div></div>
                    <div class="resumen-item"><div class="resumen-label">💵 T-VENTA</div><div class="resumen-valor" id="totalVenta"><?php echo $moneda_simbolo; ?>0.00</div></div>
                    <div class="resumen-item"><div class="resumen-label">📈 GAN.</div><div class="resumen-valor" id="totalGanancia"><?php echo $moneda_simbolo; ?>0.00</div></div>
                </div>
            </div>
            
            <!-- Barra azul inferior con precio final -->
            <div class="barra-precio">
                <div class="resumen-items">
                    <div class="resumen-item"><div class="resumen-label">💰 SIN REBAJA</div><div class="resumen-valor" id="precioSinRebaja"><?php echo $moneda_simbolo; ?>0.00</div></div>
                    <div class="resumen-item"><div class="resumen-label">🎁 REBAJA</div><div class="resumen-valor" id="rebajaAplicada">0%</div></div>
                    <div class="resumen-item"><div class="resumen-label">💎 PRECIO FINAL</div><div class="resumen-valor" id="precioFinalCombo" style="font-size: 1.1rem;"><?php echo $moneda_simbolo; ?>0.00</div></div>
                </div>
            </div>
            
            <div class="btn-acciones">
                <a href="combos.php" class="btn-cancelar">❌ Cancelar</a>
                <button type="submit" class="btn-guardar">💾 Guardar Combo</button>
            </div>
        </form>
    </div>
</main>

<!-- MODAL PARA AGREGAR PRODUCTO (compacto) -->
<div id="modalAgregarProducto" class="modal-overlay">
    <div class="modal-contenido">
        <span class="close-modal" onclick="cerrarModalAgregar()">&times;</span>
        <h3 style="margin-bottom: 0.75rem; font-size: 1rem;">➕ Agregar Producto</h3>
        
        <div class="form-group">
            <label>🔍 Producto</label>
            <div class="autocomplete-container">
                <input type="text" id="buscarProducto" class="form-control" placeholder="Escribe para buscar..." autocomplete="off" style="padding: 0.4rem 0.6rem;">
                <div id="autocompleteLista" class="autocomplete-list"></div>
            </div>
        </div>
        
        <div class="form-group">
            <label>🔢 Cantidad</label>
            <input type="number" id="cantidadProductoModal" class="form-control" value="1" min="1" step="1" style="padding: 0.4rem 0.6rem;">
        </div>
        
        <div id="infoProductoSeleccionado" style="background: #f7fafc; padding: 0.5rem; border-radius: 6px; margin-bottom: 0.75rem; display: none; font-size: 0.75rem;">
            <div><strong>Producto:</strong> <span id="infoNombre"></span></div>
            <div><strong>Categoría:</strong> <span id="infoCategoria"></span></div>
            <div><strong>Precio:</strong> <span id="infoPrecioVenta"></span> | <strong>Stock:</strong> <span id="infoStock"></span></div>
        </div>
        
        <div style="display: flex; gap: 0.5rem; justify-content: flex-end;">
            <button type="button" class="btn-cancelar" onclick="cerrarModalAgregar()" style="padding: 0.4rem 0.8rem;">Cancelar</button>
            <button type="button" class="btn-guardar" onclick="agregarProductoATabla()" style="padding: 0.4rem 0.8rem;">Aceptar</button>
        </div>
    </div>
</div>

<!-- MODAL ELIMINAR (opcional) -->

<script>
let productoSeleccionado = null;
let monedaSimbolo = '<?php echo $moneda_simbolo; ?>';
let productosDB = [];

// Cargar productos
fetch('combos_get_productos.php')
    .then(response => response.json())
    .then(data => {
        productosDB = data;
    })
    .catch(error => console.error('Error:', error));

// ============================================
// AUTOCOMPLETE
// ============================================
const inputBuscar = document.getElementById('buscarProducto');
const autocompleteList = document.getElementById('autocompleteLista');

inputBuscar.addEventListener('input', function() {
    const termino = this.value.toLowerCase().trim();
    if (termino.length < 2) {
        autocompleteList.classList.remove('show');
        return;
    }
    
    const resultados = productosDB.filter(p => p.nombre.toLowerCase().includes(termino)).slice(0, 8);
    
    if (resultados.length > 0) {
        autocompleteList.innerHTML = '';
        resultados.forEach(p => {
            const item = document.createElement('div');
            item.className = 'autocomplete-item';
            item.innerHTML = `<span class="nombre">${p.nombre}</span><span class="detalle">${p.categoria_nombre || 'Sin cat.'} | Stock:${p.cantidad} | $${p.precio}</span>`;
            item.addEventListener('click', () => seleccionarProducto(p));
            autocompleteList.appendChild(item);
        });
        autocompleteList.classList.add('show');
    } else {
        autocompleteList.classList.remove('show');
    }
});

function seleccionarProducto(producto) {
    productoSeleccionado = producto;
    inputBuscar.value = producto.nombre;
    autocompleteList.classList.remove('show');
    
    document.getElementById('infoProductoSeleccionado').style.display = 'block';
    document.getElementById('infoNombre').textContent = producto.nombre;
    document.getElementById('infoCategoria').textContent = producto.categoria_nombre || 'Sin categoría';
    document.getElementById('infoPrecioVenta').textContent = monedaSimbolo + parseFloat(producto.precio).toFixed(2);
    document.getElementById('infoStock').textContent = producto.cantidad;
    document.getElementById('cantidadProductoModal').value = 1;
    document.getElementById('cantidadProductoModal').max = producto.cantidad;
}

document.addEventListener('click', function(e) {
    if (!inputBuscar?.contains(e.target) && !autocompleteList?.contains(e.target)) {
        autocompleteList?.classList.remove('show');
    }
});

// ============================================
// MODAL
// ============================================
function abrirModalAgregarProducto() {
    productoSeleccionado = null;
    inputBuscar.value = '';
    document.getElementById('cantidadProductoModal').value = 1;
    document.getElementById('infoProductoSeleccionado').style.display = 'none';
    document.getElementById('modalAgregarProducto').style.display = 'flex';
}

function cerrarModalAgregar() {
    document.getElementById('modalAgregarProducto').style.display = 'none';
}

function agregarProductoATabla() {
    if (!productoSeleccionado) {
        alert('Selecciona un producto primero');
        return;
    }
    
    const cantidad = parseInt(document.getElementById('cantidadProductoModal').value) || 1;
    const maxStock = parseInt(productoSeleccionado.cantidad);
    
    if (cantidad > maxStock) {
        alert(`Stock insuficiente. Solo hay ${maxStock} unidades.`);
        return;
    }
    
    const existingRow = document.querySelector(`#tablaProductosBody tr[data-producto-id="${productoSeleccionado.id}"]`);
    if (existingRow) {
        alert('Este producto ya está agregado.');
        cerrarModalAgregar();
        return;
    }
    
    const precioCosto = parseFloat(productoSeleccionado.precio_costo) || 0;
    const precioVenta = parseFloat(productoSeleccionado.precio) || 0;
    const importeCosto = precioCosto * cantidad;
    const importeVenta = precioVenta * cantidad;
    const ganancia = importeVenta - importeCosto;
    
    const nuevaFila = `
        <tr data-producto-id="${productoSeleccionado.id}" data-precio-costo="${precioCosto}" data-precio-venta="${precioVenta}">
            <td>${escapeHtml(productoSeleccionado.nombre)}</td>
            <td>${escapeHtml(productoSeleccionado.categoria_nombre?.substring(0, 15) || 'Sin cat.')}</td>
            <td><input type="number" class="cantidad-producto" value="${cantidad}" min="1" max="${productoSeleccionado.cantidad}" style="width: 55px;" onchange="actualizarFila(this)"></td>
            <td class="text-right">${monedaSimbolo}${precioCosto.toFixed(2)}</td>
            <td class="text-right">${monedaSimbolo}${precioVenta.toFixed(2)}</td>
            <td class="importe-costo text-right">${monedaSimbolo}${importeCosto.toFixed(2)}</td>
            <td class="importe-venta text-right">${monedaSimbolo}${importeVenta.toFixed(2)}</td>
            <td class="ganancia text-right">${monedaSimbolo}${ganancia.toFixed(2)}</td>
            <td><button type="button" class="btn-eliminar" onclick="eliminarProducto(this)">🗑️</button></td>
        </tr>
    `;
    
    document.getElementById('tablaProductosBody').insertAdjacentHTML('beforeend', nuevaFila);
    cerrarModalAgregar();
    calcularTotales();
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function actualizarFila(input) {
    const fila = input.closest('tr');
    const cantidad = parseInt(input.value) || 1;
    const precioCosto = parseFloat(fila.getAttribute('data-precio-costo'));
    const precioVenta = parseFloat(fila.getAttribute('data-precio-venta'));
    const maxStock = parseInt(input.getAttribute('max'));
    
    if (cantidad > maxStock) {
        alert(`Stock insuficiente. Solo hay ${maxStock} unidades.`);
        input.value = maxStock;
        calcularTotales();
        return;
    }
    
    const importeCosto = precioCosto * cantidad;
    const importeVenta = precioVenta * cantidad;
    const ganancia = importeVenta - importeCosto;
    
    fila.querySelector('.importe-costo').textContent = `${monedaSimbolo}${importeCosto.toFixed(2)}`;
    fila.querySelector('.importe-venta').textContent = `${monedaSimbolo}${importeVenta.toFixed(2)}`;
    fila.querySelector('.ganancia').textContent = `${monedaSimbolo}${ganancia.toFixed(2)}`;
    
    calcularTotales();
}

function eliminarProducto(btn) {
    if (confirm('¿Eliminar este producto del combo?')) {
        btn.closest('tr').remove();
        calcularTotales();
    }
}

function calcularTotales() {
    let productosDistintos = 0;
    let unidadesTotales = 0;
    let totalCosto = 0;
    let totalVenta = 0;
    
    document.querySelectorAll('#tablaProductosBody tr').forEach(fila => {
        productosDistintos++;
        const cantidad = parseInt(fila.querySelector('.cantidad-producto').value) || 1;
        const precioCosto = parseFloat(fila.getAttribute('data-precio-costo'));
        const precioVenta = parseFloat(fila.getAttribute('data-precio-venta'));
        
        unidadesTotales += cantidad;
        totalCosto += precioCosto * cantidad;
        totalVenta += precioVenta * cantidad;
    });
    
    const gananciaTotal = totalVenta - totalCosto;
    const rebajaPorcentaje = parseFloat(document.getElementById('porcentaje_rebaja').value) || 0;
    const precioFinalCombo = totalVenta * (1 - rebajaPorcentaje / 100);
    
    document.getElementById('totalProductosDistintos').textContent = productosDistintos;
    document.getElementById('totalUnidades').textContent = unidadesTotales;
    document.getElementById('totalCosto').textContent = `${monedaSimbolo}${totalCosto.toFixed(2)}`;
    document.getElementById('totalVenta').textContent = `${monedaSimbolo}${totalVenta.toFixed(2)}`;
    document.getElementById('totalGanancia').textContent = `${monedaSimbolo}${gananciaTotal.toFixed(2)}`;
    document.getElementById('precioSinRebaja').textContent = `${monedaSimbolo}${totalVenta.toFixed(2)}`;
    document.getElementById('rebajaAplicada').textContent = `${rebajaPorcentaje}%`;
    document.getElementById('precioFinalCombo').textContent = `${monedaSimbolo}${precioFinalCombo.toFixed(2)}`;
    
    // Actualizar JSON para guardar
    const productos = [];
    document.querySelectorAll('#tablaProductosBody tr').forEach(fila => {
        productos.push({
            id: parseInt(fila.getAttribute('data-producto-id')),
            cantidad: parseInt(fila.querySelector('.cantidad-producto').value) || 1
        });
    });
    document.getElementById('productos_json').value = JSON.stringify(productos);
}

document.addEventListener('DOMContentLoaded', calcularTotales);
</script>

<?php
$conn->close();
include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';
?>
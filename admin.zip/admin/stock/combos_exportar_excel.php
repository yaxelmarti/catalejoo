<?php
// ============================================
// COMBOS EXPORTAR EXCEL - CSV
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($_SESSION['rol'], $roles_ver)) {
    http_response_code(403);
    exit('Acceso denegado');
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

if ($es_proveedor && $proveedor_id_usuario == 0) {
    http_response_code(403);
    exit('No se encontró una tienda asociada a tu usuario');
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        http_response_code(403);
        exit('Tu tienda no está activa');
    }
    $stmt_check->close();
    
    // Forzar filtro por su proveedor
    $_GET['proveedor_id'] = $proveedor_id_usuario;
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "c.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['estado'])) {
    if ($_GET['estado'] == 'activos') {
        $where[] = "c.activo = 1";
    } elseif ($_GET['estado'] == 'inactivos') {
        $where[] = "c.activo = 0";
    }
}

if (!empty($_GET['proveedor_id'])) {
    $where[] = "c.proveedor_id = ?";
    $params[] = intval($_GET['proveedor_id']);
    $types .= "i";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// CONSULTA (TODOS LOS COMBOS, SIN PAGINACIÓN)
// ============================================
$sql = "SELECT c.*, 
               (SELECT COUNT(*) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as productos_distintos,
               (SELECT COALESCE(SUM(cp.cantidad), 0) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as unidades_totales,
               (SELECT COALESCE(SUM(p.precio_costo * cp.cantidad), 0) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as importe_costo,
               pr.nombre_tienda
        FROM combos c 
        LEFT JOIN proveedores pr ON c.proveedor_id = pr.id
        $sql_where 
        ORDER BY c.id DESC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$combos = $stmt->get_result();

// ============================================
// CABECERAS HTTP PARA DESCARGA CSV
// ============================================
$fecha_archivo = date('Y-m-d_His');
$nombre_archivo = 'combos_' . $fecha_archivo . '.csv';

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $nombre_archivo . '"');
header('Pragma: no-cache');
header('Expires: 0');

// ============================================
// ABRIR SALIDA
// ============================================
$output = fopen('php://output', 'w');

// BOM UTF-8 (para que Excel muestre tildes y ñ correctamente)
fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

// ============================================
// CABECERAS DEL CSV
// ============================================
fputcsv($output, [
    'ID',
    'Nombre',
    'Proveedor',
    'Productos',
    'Unidades',
    'Importe Costo',
    'Precio sin Rebaja',
    'Rebaja (%)',
    'Precio Venta',
    'Stock',
    'Stock Calc.',
    'Estado',
    'Fecha Creación'
], ';');

// ============================================
// FILAS
// ============================================
while ($combo = $combos->fetch_assoc()) {
    fputcsv($output, [
        $combo['id'],
        $combo['nombre'],
        $combo['nombre_tienda'] ?? '',
        'P-' . intval($combo['productos_distintos']),
        'U-' . intval($combo['unidades_totales']),
        number_format($combo['importe_costo'], 2, '.', ''),
        number_format($combo['precio'], 2, '.', ''),
        $combo['porcentaje_rebaja'] . '%',
        number_format($combo['precio_final'], 2, '.', ''),
        intval($combo['stock_combo']),
        intval($combo['stock_calculado']),
        $combo['activo'] ? 'Activo' : 'Inactivo',
        date('d/m/Y', strtotime($combo['fecha_creacion']))
    ], ';');
}

fclose($output);

// ============================================
// CERRAR
// ============================================
$stmt->close();
$conn->close();
exit;
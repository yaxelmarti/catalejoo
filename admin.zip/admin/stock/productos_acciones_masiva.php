<?php
// ============================================
// PRODUCTOS ACCIONES MASIVAS
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/csrf.php';
require_once __DIR__ . '/../../includes/historial.php';
require_once __DIR__ . '/../../includes/moneda_funciones.php';

header('Content-Type: application/json');

// ===== VERIFICAR PERMISOS =====
$rol_actual = $_SESSION['rol'] ?? '';

$roles_gestionar = ['Super Admin', 'Gerente', 'Proveedor', 'Inventario'];
if (!in_array($rol_actual, $roles_gestionar)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Permiso denegado']);
    exit;
}

$roles_eliminar = ['Super Admin', 'Gerente', 'Proveedor'];
$puede_eliminar = in_array($rol_actual, $roles_eliminar);

$es_super_admin = ($rol_actual === 'Super Admin');
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $_SESSION['usuario_id'], $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo json_encode(['success' => false, 'error' => 'No se encontró una tienda asociada a tu usuario']);
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'Tu tienda no está activa']);
        exit;
    }
    $stmt_check->close();
}

$data = json_decode(file_get_contents('php://input'), true);
$accion = $data['accion'] ?? '';
$productos = $data['productos'] ?? [];

// ============================================
// VALIDACIÓN CSRF
// ============================================
$token_csrf = $data['csrf_token'] ?? ($_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? ''));
if (!function_exists('csrf_validar') || !csrf_validar($token_csrf)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Token de seguridad inválido. Recarga la página e intenta de nuevo.']);
    exit;
}

// ============================================
// DETERMINAR PROVEEDOR DE OPERACIÓN
// - Proveedor/Inventario: su proveedor
// - Super Admin: del GET ?proveedor_id=X (obligatorio)
// ============================================
$proveedor_id_operacion = 0;

if ($es_super_admin) {
    $prov_get = isset($_GET['proveedor_id']) ? intval($_GET['proveedor_id']) : 0;
    if ($prov_get <= 0) {
        echo json_encode(['success' => false, 'error' => 'Debes seleccionar un proveedor primero']);
        exit;
    }
    // Validar que el proveedor existe y está activo
    $stmt_prov = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1 LIMIT 1");
    $stmt_prov->bind_param("i", $prov_get);
    $stmt_prov->execute();
    if ($stmt_prov->get_result()->num_rows === 0) {
        $stmt_prov->close();
        echo json_encode(['success' => false, 'error' => 'Proveedor no válido o inactivo']);
        exit;
    }
    $stmt_prov->close();
    $proveedor_id_operacion = $prov_get;
} else {
    $proveedor_id_operacion = $proveedor_id_usuario;
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================

/**
 * Verifica las dependencias de un producto
 */
function verificarDependenciasProducto($conn, $producto_id) {
    $dependencias = [];

    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM historial_producto WHERE producto_id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res['total'] > 0) $dependencias['historial_mov'] = intval($res['total']);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM historial_productos_cambios WHERE producto_id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res['total'] > 0) $dependencias['historial_cambios'] = intval($res['total']);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos cp 
                            JOIN carritos c ON cp.carrito_id = c.id 
                            WHERE cp.producto_id = ? AND c.fecha_expiracion > NOW()");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res['total'] > 0) $dependencias['carritos'] = intval($res['total']);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles pd 
                            JOIN pedidos p ON pd.pedido_id = p.id 
                            WHERE pd.producto_id = ? AND p.estado_actual NOT IN ('cancelado', 'devuelto')");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res['total'] > 0) $dependencias['pedidos'] = intval($res['total']);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM combo_productos cp 
                            JOIN combos c ON cp.combo_id = c.id 
                            WHERE cp.producto_id = ? AND c.activo = 1 AND cp.cantidad > 0");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res['total'] > 0) $dependencias['combos'] = intval($res['total']);
    $stmt->close();

    return $dependencias;
}

/**
 * Obtiene combos activos que contienen alguno de los productos indicados
 */
function obtenerCombosActivosPorProductos($conn, array $producto_ids) {
    $ids = array_values(array_unique(array_filter(array_map('intval', $producto_ids), function ($v) {
        return $v > 0;
    })));
    if (empty($ids)) {
        return [];
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql = "SELECT DISTINCT c.id, c.nombre
            FROM combos c
            INNER JOIN combo_productos cp ON cp.combo_id = c.id
            WHERE cp.producto_id IN ($placeholders)
              AND c.activo = 1
              AND cp.cantidad > 0
            ORDER BY c.nombre ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmt->execute();
    $res = $stmt->get_result();

    $combos = [];
    while ($row = $res->fetch_assoc()) {
        $combos[] = [
            'id' => intval($row['id']),
            'nombre' => (string) $row['nombre']
        ];
    }
    $stmt->close();

    return $combos;
}

/**
 * Recalcula precio, precio_final, rebaja, costo, totales y stock_calculado
 * ignorando productos inactivos (p.activo = 0) o con cantidad <= 0.
 * Si el combo queda sin productos activos/válidos, lo pasa a activo = 0.
 */
function recalcularCombo($conn, $combo_id) {
    $combo_id = intval($combo_id);
    if ($combo_id <= 0) return;

    $sql_calc = "SELECT
                    COUNT(CASE WHEN p.activo = 1 AND cp.cantidad > 0 THEN 1 END) AS productos_distintos,
                    COALESCE(SUM(CASE WHEN p.activo = 1 AND cp.cantidad > 0 THEN cp.cantidad ELSE 0 END), 0) AS unidades_totales,
                    COALESCE(SUM(CASE WHEN p.activo = 1 AND cp.cantidad > 0 THEN cp.cantidad * p.precio ELSE 0 END), 0) AS total_precio_final,
                    COALESCE(SUM(CASE WHEN p.activo = 1 AND cp.cantidad > 0 THEN cp.cantidad * COALESCE(NULLIF(p.precio_original, 0), p.precio) ELSE 0 END), 0) AS total_precio_base,
                    COALESCE(SUM(CASE WHEN p.activo = 1 AND cp.cantidad > 0 THEN cp.cantidad * p.precio_costo ELSE 0 END), 0) AS total_costo,
                    COALESCE(SUM(CASE WHEN p.activo = 1 AND cp.cantidad > 0 AND p.porcentaje_rebaja > 0 AND COALESCE(NULLIF(p.precio_original, 0), p.precio) > p.precio THEN p.porcentaje_rebaja ELSE 0 END), 0) AS suma_porc,
                    COALESCE(SUM(CASE WHEN p.activo = 1 AND cp.cantidad > 0 AND p.porcentaje_rebaja > 0 AND COALESCE(NULLIF(p.precio_original, 0), p.precio) > p.precio THEN 1 ELSE 0 END), 0) AS count_con_rebaja
                 FROM combo_productos cp
                 INNER JOIN productos p ON cp.producto_id = p.id
                 WHERE cp.combo_id = ?";
    $stmt = $conn->prepare($sql_calc);
    $stmt->bind_param("i", $combo_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $productos_distintos = intval($row['productos_distintos'] ?? 0);
    $unidades_totales = intval($row['unidades_totales'] ?? 0);
    $nuevo_precio_final = floatval($row['total_precio_final'] ?? 0);
    $nuevo_precio = floatval($row['total_precio_base'] ?? 0);
    $nuevo_costo = floatval($row['total_costo'] ?? 0);

    $suma_porc = floatval($row['suma_porc'] ?? 0);
    $count_con_rebaja = intval($row['count_con_rebaja'] ?? 0);
    $nuevo_porcentaje_rebaja = ($productos_distintos > 0 && $count_con_rebaja > 0)
        ? (int) round($suma_porc / $count_con_rebaja)
        : 0;

    $stock_calculado = 0;
    if ($productos_distintos > 0) {
        $stmt_p = $conn->prepare("
            SELECT cp.cantidad, p.cantidad AS stock_total, p.reservado_por_combos
            FROM combo_productos cp
            INNER JOIN productos p ON cp.producto_id = p.id
            WHERE cp.combo_id = ? AND p.activo = 1 AND cp.cantidad > 0
        ");
        $stmt_p->bind_param("i", $combo_id);
        $stmt_p->execute();
        $res_p = $stmt_p->get_result();

        $min_combos = PHP_INT_MAX;
        $hay_item = false;
        while ($prod = $res_p->fetch_assoc()) {
            $hay_item = true;
            $cant_combo = intval($prod['cantidad']);
            if ($cant_combo <= 0) continue;
            $stock_disp = max(0, intval($prod['stock_total']) - intval($prod['reservado_por_combos']));
            $posibles = (int) floor($stock_disp / $cant_combo);
            if ($posibles < $min_combos) {
                $min_combos = $posibles;
            }
        }
        $stmt_p->close();

        if ($hay_item && $min_combos !== PHP_INT_MAX) {
            $stock_calculado = max(0, $min_combos);
        }
    }

    $fecha_actual = date('Y-m-d H:i:s');
    if ($productos_distintos === 0) {
        $stmt_upd = $conn->prepare("UPDATE combos SET
            precio = 0,
            precio_final = 0,
            porcentaje_rebaja = 0,
            costo = 0,
            productos_distintos = 0,
            unidades_totales = 0,
            stock_combo = 0,
            stock_calculado = 0,
            activo = 0,
            fecha_actualizacion_stock = ?
            WHERE id = ?");
        $stmt_upd->bind_param("si", $fecha_actual, $combo_id);
    } else {
        $stmt_upd = $conn->prepare("UPDATE combos SET
            precio = ?,
            precio_final = ?,
            porcentaje_rebaja = ?,
            costo = ?,
            productos_distintos = ?,
            unidades_totales = ?,
            stock_combo = LEAST(stock_combo, ?),
            stock_calculado = ?,
            fecha_actualizacion_stock = ?
            WHERE id = ?");
        $stmt_upd->bind_param(
            "ddidiiiisi",
            $nuevo_precio,
            $nuevo_precio_final,
            $nuevo_porcentaje_rebaja,
            $nuevo_costo,
            $productos_distintos,
            $unidades_totales,
            $stock_calculado,
            $stock_calculado,
            $fecha_actual,
            $combo_id
        );
    }
    $stmt_upd->execute();
    $stmt_upd->close();
}

/**
 * Al desactivar productos:
 * - Libera reservado_por_combos y actualiza en_combo en `productos`
 * - Deja cantidad = 0 en `combo_productos` (sin borrar la fila)
 * - Recalcula los combos afectados (y desactiva los que queden sin productos activos)
 */
function desactivarProductosEnCombosYRecalcular($conn, array $producto_ids, $proveedor_id_operacion = 0) {
    $ids = array_values(array_unique(array_filter(array_map('intval', $producto_ids), function ($v) {
        return $v > 0;
    })));
    if (empty($ids)) {
        return [];
    }

    $fecha_actual = date('Y-m-d H:i:s');
    $combos_afectados = [];

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql_filas = "SELECT cp.combo_id, cp.producto_id, cp.cantidad
                  FROM combo_productos cp
                  WHERE cp.producto_id IN ($placeholders) AND cp.cantidad > 0";
    $stmt_filas = $conn->prepare($sql_filas);
    $stmt_filas->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmt_filas->execute();
    $res_filas = $stmt_filas->get_result();

    $filas = [];
    while ($row = $res_filas->fetch_assoc()) {
        $filas[] = [
            'combo_id' => intval($row['combo_id']),
            'producto_id' => intval($row['producto_id']),
            'cantidad' => intval($row['cantidad'])
        ];
        $combos_afectados[intval($row['combo_id'])] = true;
    }
    $stmt_filas->close();

    if (empty($filas)) {
        return [];
    }

    $stmt_liberar = $conn->prepare("UPDATE productos
        SET reservado_por_combos = GREATEST(0, reservado_por_combos - ?),
            fecha_actualizacion_reserva = ?
        WHERE id = ?");

    $stmt_cero = $conn->prepare("UPDATE combo_productos
        SET cantidad = 0
        WHERE combo_id = ? AND producto_id = ?");

    foreach ($filas as $f) {
        if ($f['cantidad'] > 0) {
            $stmt_liberar->bind_param("isi", $f['cantidad'], $fecha_actual, $f['producto_id']);
            $stmt_liberar->execute();
        }
        $stmt_cero->bind_param("ii", $f['combo_id'], $f['producto_id']);
        $stmt_cero->execute();
    }
    $stmt_liberar->close();
    $stmt_cero->close();

    $stmt_flag = $conn->prepare("UPDATE productos p
        SET p.en_combo = CASE
            WHEN EXISTS (
                SELECT 1 FROM combo_productos cp
                INNER JOIN combos c ON c.id = cp.combo_id
                WHERE cp.producto_id = p.id AND cp.cantidad > 0 AND c.activo = 1
            ) THEN 1 ELSE 0
        END
        WHERE p.id IN ($placeholders)");
    $stmt_flag->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmt_flag->execute();
    $stmt_flag->close();

    $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
    if (file_exists($ruta_combos)) {
        include_once $ruta_combos;
        if (function_exists('actualizarCombosPorProducto')) {
            foreach ($ids as $pid) {
                actualizarCombosPorProducto($conn, $pid, $proveedor_id_operacion);
            }
        }
    }

    return array_keys($combos_afectados);
}

/**
 * Recalcula el precio de venta de un producto (Opción B)
 */
function recalcularPrecioProducto($conn, $producto_id, $proveedor_id_operacion) {
    $stmt = $conn->prepare("SELECT id, precio_adquisicion, moneda_adquisicion, porcentaje_ganancia, porcentaje_rebaja FROM productos WHERE id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $prod = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$prod) return false;

    $moneda = strtoupper($prod['moneda_adquisicion'] ?? 'USD');
    $costo = floatval($prod['precio_adquisicion'] ?? 0);
    $porcentaje_ganancia = floatval($prod['porcentaje_ganancia'] ?? 0);
    $porcentaje_rebaja = floatval($prod['porcentaje_rebaja'] ?? 0);

    if ($moneda === 'USD') {
        $precio_costo = $costo;
    } else {
        $tasa = getTasaProveedor($conn, $proveedor_id_operacion, $moneda);
        $precio_costo = ($tasa > 0) ? ($costo / $tasa) : 0;
    }

    $precio_venta = $precio_costo * (1 + $porcentaje_ganancia / 100);
    $precio_final = ($porcentaje_rebaja > 0) 
        ? $precio_venta * (100 - $porcentaje_rebaja) / 100 
        : $precio_venta;
    $precio_original = ($porcentaje_rebaja > 0) ? $precio_venta : 0;

    $stmt = $conn->prepare("UPDATE productos SET precio_costo = ?, precio = ?, precio_original = ? WHERE id = ?");
    $stmt->bind_param("dddi", $precio_costo, $precio_final, $precio_original, $producto_id);
    $stmt->execute();
    $stmt->close();

    if (function_exists('registrarCambioProducto')) {
        registrarCambioProducto($conn, $producto_id, 'editar', [
            'precio_costo' => $precio_costo,
            'precio' => $precio_final,
            'precio_original' => $precio_original
        ]);
    }

    // Actualizar combos
    $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
    if (file_exists($ruta_combos)) {
        include_once $ruta_combos;
        if (function_exists('actualizarCombosPorProducto')) {
            actualizarCombosPorProducto($conn, $producto_id);
        }
    }

    return true;
}

// ============================================
// ACCIÓN: ELIMINAR
// ============================================
if ($accion == 'eliminar') {
    if (!$puede_eliminar) {
        echo json_encode(['success' => false, 'error' => 'No tienes permiso para eliminar productos']);
        exit;
    }

    if (empty($productos_ids = array_map('intval', $productos))) {
        echo json_encode(['success' => false, 'error' => 'No hay productos seleccionados']);
        exit;
    }

    $producto_id = $productos_ids[0];

    // Verificar que el producto pertenezca al proveedor de operación
    $stmt = $conn->prepare("SELECT id FROM productos WHERE id = ? AND proveedor_id = ?");
    $stmt->bind_param("ii", $producto_id, $proveedor_id_operacion);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => 'Este producto no pertenece al proveedor seleccionado']);
        exit;
    }
    $stmt->close();

    $deps = verificarDependenciasProducto($conn, $producto_id);
    $tiene_carritos_pedidos = isset($deps['carritos']) || isset($deps['pedidos']);
    $tiene_combos = isset($deps['combos']);

    if ($tiene_carritos_pedidos) {
        echo json_encode([
            'success' => false,
            'error' => 'No se puede eliminar el producto: está en carritos activos o pedidos en curso'
        ]);
        exit;
    }

    if ($tiene_combos) {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE productos SET activo = 0 WHERE id = ?");
            $stmt->bind_param("i", $producto_id);
            $stmt->execute();
            $stmt->close();

            desactivarProductosEnCombosYRecalcular($conn, [$producto_id]);
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[productos_acciones_masiva] Error desactivar por eliminar #' . $producto_id . ': ' . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Error al desactivar el producto']);
            exit;
        }
        echo json_encode([
            'success' => true,
            'desactivado' => true,
            'mensaje' => 'El producto está en combos activos. Ha sido desactivado y ajustado en los combos.'
        ]);
        exit;
    }

    // Sin carritos, sin pedidos, sin combos → DELETE
    $stmt = $conn->prepare("DELETE FROM productos WHERE id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true, 'eliminado' => true, 'mensaje' => 'Producto eliminado correctamente']);
    exit;
}

// ============================================
// ACCIÓN: ELIMINAR FORZAR (SOLO SUPER ADMIN)
// ============================================
if ($accion == 'eliminar_forzar') {
    if (!$es_super_admin) {
        echo json_encode(['success' => false, 'error' => 'Solo Super Admin puede eliminar forzadamente']);
        exit;
    }

    if (empty($productos_ids = array_map('intval', $productos))) {
        echo json_encode(['success' => false, 'error' => 'No hay productos seleccionados']);
        exit;
    }

    $producto_id = $productos_ids[0];

    // Verificar que el producto pertenezca al proveedor de operación
    $stmt = $conn->prepare("SELECT id FROM productos WHERE id = ? AND proveedor_id = ?");
    $stmt->bind_param("ii", $producto_id, $proveedor_id_operacion);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => 'Este producto no pertenece al proveedor seleccionado']);
        exit;
    }
    $stmt->close();

    // Verificar pedidos en curso (bloquean)
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles pd 
                            JOIN pedidos p ON pd.pedido_id = p.id 
                            WHERE pd.producto_id = ? 
                            AND p.estado_actual NOT IN ('cancelado', 'devuelto')");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $pedidos = intval($stmt->get_result()->fetch_assoc()['total']);
    $stmt->close();

    if ($pedidos > 0) {
        echo json_encode([
            'success' => false,
            'error' => 'No se puede eliminar un producto que tiene pedidos en curso (no cancelados).'
        ]);
        exit;
    }

    // Obtener combos afectados ANTES de borrar
    $stmt = $conn->prepare("SELECT DISTINCT combo_id FROM combo_productos WHERE producto_id = ?");
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $res_combos = $stmt->get_result();
    $combos_afectados = [];
    while ($row = $res_combos->fetch_assoc()) {
        $combos_afectados[] = intval($row['combo_id']);
    }
    $stmt->close();

    $conn->begin_transaction();
    try {
        // Quitar el producto de los carritos (SIN borrar el carrito)
        $stmt = $conn->prepare("DELETE FROM carrito_productos WHERE producto_id = ?");
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stmt->close();

        // Limpiar carritos huérfanos (sin productos)
        $conn->query("DELETE FROM carritos WHERE id NOT IN (SELECT DISTINCT carrito_id FROM carrito_productos)");

        // Borrar historial
        $stmt = $conn->prepare("DELETE FROM historial_producto WHERE producto_id = ?");
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM historial_productos_cambios WHERE producto_id = ?");
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stmt->close();

        // Borrar de combo_productos
        $stmt = $conn->prepare("DELETE FROM combo_productos WHERE producto_id = ?");
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stmt->close();

        // Borrar producto
        $stmt = $conn->prepare("DELETE FROM productos WHERE id = ?");
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $stmt->close();

        // Recalcular combos afectados
        foreach ($combos_afectados as $combo_id) {
            recalcularCombo($conn, $combo_id);
        }

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[productos_acciones_masiva] Error eliminar_forzar #' . $producto_id . ': ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Error al eliminar el producto']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'eliminado' => true,
        'mensaje' => 'Producto eliminado permanentemente (combos recalculados)'
    ]);
    exit;
}

// ============================================
// ACCIÓN: ACTIVAR / DESACTIVAR
// ============================================
if ($accion == 'activar' || $accion == 'desactivar') {
    $productos_ids = array_values(array_unique(array_filter(array_map('intval', (array) $productos), function ($v) {
        return $v > 0;
    })));

    if (empty($productos_ids)) {
        echo json_encode(['success' => false, 'error' => 'No hay productos seleccionados']);
        exit;
    }

    // Verificar que todos los productos pertenezcan al proveedor de operación
    $placeholders = implode(',', array_fill(0, count($productos_ids), '?'));
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE id IN ($placeholders) AND proveedor_id = ?");
    $types = str_repeat('i', count($productos_ids)) . 'i';
    $params = array_merge($productos_ids, [$proveedor_id_operacion]);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $total_propios = intval($stmt->get_result()->fetch_assoc()['total']);
    $stmt->close();

    if ($total_propios !== count($productos_ids)) {
        echo json_encode(['success' => false, 'error' => 'Uno o más productos no pertenecen al proveedor seleccionado']);
        exit;
    }

    $confirmar_desactivar = !empty($data['confirmar_desactivar']);

    if ($accion === 'desactivar' && !$confirmar_desactivar) {
        $combos_afectados = obtenerCombosActivosPorProductos($conn, $productos_ids);
        if (!empty($combos_afectados)) {
            echo json_encode([
                'success' => false,
                'requires_confirmation' => true,
                'combos_afectados' => $combos_afectados,
                'error' => 'El/los producto(s) están en combos activos.'
            ]);
            exit;
        }
    }

    $nuevo_estado = ($accion == 'activar') ? 1 : 0;

    $conn->begin_transaction();
    try {
        // Obtener estados anteriores
        $estados_anteriores = [];
        $stmt = $conn->prepare("SELECT id, activo FROM productos WHERE id IN ($placeholders)");
        $stmt->bind_param(str_repeat('i', count($productos_ids)), ...$productos_ids);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $estados_anteriores[intval($row['id'])] = intval($row['activo']);
        }
        $stmt->close();

        // Actualizar estado
        $stmt = $conn->prepare("UPDATE productos SET activo = ? WHERE id IN ($placeholders)");
        $types = 'i' . str_repeat('i', count($productos_ids));
        $params = array_merge([$nuevo_estado], $productos_ids);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $stmt->close();

        if ($nuevo_estado === 0) {
            desactivarProductosEnCombosYRecalcular($conn, $productos_ids, $proveedor_id_operacion);
        }

        // Historial
        $usuario_id = $_SESSION['usuario_id'];
        $usuario_nombre = $_SESSION['nombre'] ?? '';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        $stmt_historial = $conn->prepare("INSERT INTO historial_productos_cambios 
                (producto_id, usuario_id, usuario_nombre, accion, cambios, ip_address, user_agent) 
                VALUES (?, ?, ?, 'editar', ?, ?, ?)");

        foreach ($productos_ids as $producto_id) {
            $estado_anterior = $estados_anteriores[$producto_id] ?? ($nuevo_estado == 1 ? 0 : 1);
            $cambios = json_encode(['activo' => ['antes' => $estado_anterior, 'despues' => $nuevo_estado]]);
            $stmt_historial->bind_param("iissss", $producto_id, $usuario_id, $usuario_nombre, $cambios, $ip, $user_agent);
            $stmt_historial->execute();
        }
        $stmt_historial->close();

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[productos_acciones_masiva] Error activar/desactivar: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Error al actualizar el estado de los productos']);
        exit;
    }

    echo json_encode(['success' => true, 'actualizados' => count($productos_ids)]);
    exit;
}

// ============================================
// ACCIÓN: CALCULAR VENTA (productos seleccionados)
// ============================================
if ($accion == 'calcular_venta') {
    if (empty($productos_ids = array_map('intval', $productos))) {
        echo json_encode(['success' => false, 'error' => 'No hay productos seleccionados']);
        exit;
    }

    // Verificar que todos los productos pertenezcan al proveedor de operación
    $placeholders = implode(',', array_fill(0, count($productos_ids), '?'));
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE id IN ($placeholders) AND proveedor_id = ?");
    $types = str_repeat('i', count($productos_ids)) . 'i';
    $params = array_merge($productos_ids, [$proveedor_id_operacion]);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $total_propios = intval($stmt->get_result()->fetch_assoc()['total']);
    $stmt->close();

    if ($total_propios !== count($productos_ids)) {
        echo json_encode(['success' => false, 'error' => 'Uno o más productos no pertenecen al proveedor seleccionado']);
        exit;
    }

    $actualizados = 0;
    $productos_actualizados = [];

    foreach ($productos_ids as $producto_id) {
        if (recalcularPrecioProducto($conn, $producto_id, $proveedor_id_operacion)) {
            $actualizados++;

            $stmt2 = $conn->prepare("SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono 
                                     FROM productos p 
                                     LEFT JOIN categorias c ON p.categoria_id = c.id 
                                     WHERE p.id = ?");
            $stmt2->bind_param("i", $producto_id);
            $stmt2->execute();
            $productos_actualizados[] = $stmt2->get_result()->fetch_assoc();
            $stmt2->close();
        }
    }

    echo json_encode([
        'success' => true,
        'actualizados' => $actualizados,
        'productos_actualizados' => $productos_actualizados
    ]);
    exit;
}

// ============================================
// ACCIÓN: CALCULAR VENTA TODOS (todos los productos del proveedor)
// ============================================
if ($accion == 'calcular_venta_todos') {
    $stmt = $conn->prepare("SELECT id FROM productos WHERE proveedor_id = ?");
    $stmt->bind_param("i", $proveedor_id_operacion);
    $stmt->execute();
    $res = $stmt->get_result();
    $todos_ids = [];
    while ($row = $res->fetch_assoc()) {
        $todos_ids[] = intval($row['id']);
    }
    $stmt->close();

    if (empty($todos_ids)) {
        echo json_encode(['success' => false, 'error' => 'El proveedor no tiene productos']);
        exit;
    }

    $actualizados = 0;
    $productos_actualizados = [];

    foreach ($todos_ids as $producto_id) {
        if (recalcularPrecioProducto($conn, $producto_id, $proveedor_id_operacion)) {
            $actualizados++;

            $stmt2 = $conn->prepare("SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono 
                                     FROM productos p 
                                     LEFT JOIN categorias c ON p.categoria_id = c.id 
                                     WHERE p.id = ?");
            $stmt2->bind_param("i", $producto_id);
            $stmt2->execute();
            $productos_actualizados[] = $stmt2->get_result()->fetch_assoc();
            $stmt2->close();
        }
    }

    echo json_encode([
        'success' => true,
        'actualizados' => $actualizados,
        'productos_actualizados' => $productos_actualizados,
        'mensaje' => "Se recalcularon {$actualizados} producto(s) del proveedor"
    ]);
    exit;
}

// ============================================
// ACCIÓN: APLICAR REBAJA MASIVA
// ============================================
if ($accion == 'aplicar_rebaja') {
    if (empty($productos_ids = array_map('intval', $productos))) {
        echo json_encode(['success' => false, 'error' => 'No hay productos seleccionados']);
        exit;
    }

    $porcentaje_rebaja = floatval($data['porcentaje_rebaja'] ?? 0);

    if ($porcentaje_rebaja < 0 || $porcentaje_rebaja > 100) {
        echo json_encode(['success' => false, 'error' => 'Porcentaje inválido (0-100)']);
        exit;
    }

    // Verificar que todos los productos pertenezcan al proveedor de operación
    $placeholders = implode(',', array_fill(0, count($productos_ids), '?'));
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE id IN ($placeholders) AND proveedor_id = ?");
    $types = str_repeat('i', count($productos_ids)) . 'i';
    $params = array_merge($productos_ids, [$proveedor_id_operacion]);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $total_propios = intval($stmt->get_result()->fetch_assoc()['total']);
    $stmt->close();

    if ($total_propios !== count($productos_ids)) {
        echo json_encode(['success' => false, 'error' => 'Uno o más productos no pertenecen al proveedor seleccionado']);
        exit;
    }

    $actualizados = 0;
    $productos_actualizados = [];

    foreach ($productos_ids as $producto_id) {
        $stmt = $conn->prepare("SELECT precio, precio_original, porcentaje_rebaja FROM productos WHERE id = ?");
        $stmt->bind_param("i", $producto_id);
        $stmt->execute();
        $producto = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($producto) {
            $precio_base = !empty($producto['precio_original']) 
                           ? floatval($producto['precio_original']) 
                           : floatval($producto['precio']);

            $precio_final = ($porcentaje_rebaja > 0) 
                            ? $precio_base * (100 - $porcentaje_rebaja) / 100 
                            : $precio_base;

            $precio_original_guardar = ($porcentaje_rebaja > 0) ? $precio_base : null;

            $stmt_update = $conn->prepare("UPDATE productos SET 
                porcentaje_rebaja = ?,
                precio = ?,
                precio_original = ?
                WHERE id = ?");
            $stmt_update->bind_param("didi", $porcentaje_rebaja, $precio_final, $precio_original_guardar, $producto_id);

            if ($stmt_update->execute()) {
                $stmt_update->close();
                $actualizados++;

                // Actualizar combos
                $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
                if (file_exists($ruta_combos)) {
                    include_once $ruta_combos;
                    if (function_exists('actualizarCombosPorProducto')) {
                        actualizarCombosPorProducto($conn, $producto_id);
                    }
                }

                $stmt_get = $conn->prepare("SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono 
                                            FROM productos p 
                                            LEFT JOIN categorias c ON p.categoria_id = c.id 
                                            WHERE p.id = ?");
                $stmt_get->bind_param("i", $producto_id);
                $stmt_get->execute();
                $productos_actualizados[] = $stmt_get->get_result()->fetch_assoc();
                $stmt_get->close();
            } else {
                $stmt_update->close();
            }
        }
    }

    echo json_encode([
        'success' => true,
        'actualizados' => $actualizados,
        'productos_actualizados' => $productos_actualizados
    ]);
    exit;
}

echo json_encode(['success' => false, 'error' => 'Acción no válida']);
$conn->close();
?>
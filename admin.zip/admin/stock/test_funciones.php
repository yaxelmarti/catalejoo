<?php
// ============================================
// TEST DE FUNCIONES - DIAGNÓSTICO
// Ejecutar: /admin/stock/test_funciones.php
// Borrar después de usar.
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

session_start();

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/moneda_funciones.php';
require_once __DIR__ . '/../../includes/historial.php';

header('Content-Type: text/plain; charset=UTF-8');

echo "========================================\n";
echo "TEST DE FUNCIONES - " . date('Y-m-d H:i:s') . "\n";
echo "========================================\n\n";

echo "PHP Version: " . phpversion() . "\n";
echo "Usuario ID: " . ($_SESSION['usuario_id'] ?? 'NO LOGUEADO') . "\n";
echo "Rol: " . ($_SESSION['rol'] ?? 'N/A') . "\n\n";

// ============================================
// TEST 1: obtenerProveedorId
// ============================================
echo "--- TEST 1: obtenerProveedorId() ---\n";
try {
    $usuario_id = $_SESSION['usuario_id'] ?? 1;
    $rol = $_SESSION['rol'] ?? 'Super Admin';
    $prov_id = obtenerProveedorId($conn, $usuario_id, $rol);
    echo "✅ obtenerProveedorId({$usuario_id}, '{$rol}') = " . var_export($prov_id, true) . "\n";
} catch (Throwable $e) {
    echo "❌ FALLO: " . $e->getMessage() . "\n";
    echo "   Archivo: " . $e->getFile() . "\n";
    echo "   Línea: " . $e->getLine() . "\n";
}
echo "\n";

// ============================================
// TEST 2: getMonedasDelProveedor
// ============================================
echo "--- TEST 2: getMonedasDelProveedor() ---\n";
$proveedores_test = [0, 1, 2, 3, 4, 5];
foreach ($proveedores_test as $pid) {
    try {
        $monedas = getMonedasDelProveedor($conn, $pid);
        echo "✅ getMonedasDelProveedor({$pid}) = " . json_encode($monedas) . "\n";
    } catch (Throwable $e) {
        echo "❌ FALLO con proveedor_id={$pid}: " . $e->getMessage() . "\n";
        echo "   Archivo: " . $e->getFile() . "\n";
        echo "   Línea: " . $e->getLine() . "\n";
    }
}
echo "\n";

// ============================================
// TEST 3: getTasaProveedor
// ============================================
echo "--- TEST 3: getTasaProveedor() ---\n";
$monedas_test = ['USD', 'CUP', 'EUR', 'MXN'];
foreach ($proveedores_test as $pid) {
    foreach ($monedas_test as $mon) {
        try {
            $tasa = getTasaProveedor($conn, $pid, $mon);
            echo "✅ getTasaProveedor({$pid}, '{$mon}') = " . var_export($tasa, true) . "\n";
        } catch (Throwable $e) {
            echo "❌ FALLO con proveedor_id={$pid}, moneda={$mon}: " . $e->getMessage() . "\n";
            echo "   Archivo: " . $e->getFile() . "\n";
            echo "   Línea: " . $e->getLine() . "\n";
        }
    }
}
echo "\n";

// ============================================
// TEST 4: productoPerteneceAProveedor
// ============================================
echo "--- TEST 4: productoPerteneceAProveedor() ---\n";
$res_prod = $conn->query("SELECT id, proveedor_id FROM productos LIMIT 5");
if ($res_prod && $res_prod->num_rows > 0) {
    while ($p = $res_prod->fetch_assoc()) {
        try {
            $pertenece = productoPerteneceAProveedor($conn, $p['id'], $p['proveedor_id']);
            echo "✅ productoPerteneceAProveedor(id={$p['id']}, prov={$p['proveedor_id']}) = " . var_export($pertenece, true) . "\n";
        } catch (Throwable $e) {
            echo "❌ FALLO producto id={$p['id']}: " . $e->getMessage() . "\n";
            echo "   Archivo: " . $e->getFile() . "\n";
            echo "   Línea: " . $e->getLine() . "\n";
        }
    }
} else {
    echo "⚠️ No hay productos en la BD para probar\n";
}
echo "\n";

// ============================================
// TEST 5: registrarCambioProducto
// ============================================
echo "--- TEST 5: registrarCambioProducto() ---\n";
$res_prod2 = $conn->query("SELECT id FROM productos LIMIT 1");
if ($res_prod2 && $res_prod2->num_rows > 0) {
    $p = $res_prod2->fetch_assoc();
    try {
        registrarCambioProducto($conn, $p['id'], 'test', ['test' => 'valor_test']);
        echo "✅ registrarCambioProducto(id={$p['id']}) = OK\n";
    } catch (Throwable $e) {
        echo "❌ FALLO registrarCambioProducto: " . $e->getMessage() . "\n";
        echo "   Archivo: " . $e->getFile() . "\n";
        echo "   Línea: " . $e->getLine() . "\n";
    }
} else {
    echo "⚠️ No hay productos para probar\n";
}
echo "\n";

// ============================================
// TEST 6: INSERT directo de producto (el que falla)
// ============================================
echo "--- TEST 6: INSERT directo de producto (simulado) ---\n";
try {
    $nombre = 'TEST_PRODUCTO_' . time();
    $descripcion = 'Producto de prueba';
    $marca = 'TEST';
    $peso = 0.500;
    $cantidad = 5;
    $precio_costo = 10.00;
    $precio_final = 13.00;
    $porcentaje_rebaja = 0;
    $precio_original_param = 0.00;
    $imagen_url = '/uploads/productos/test.jpg';
    $categoria_id_param = 0;
    $precio_adquisicion = 0.00;
    $moneda_adquisicion = 'USD';
    $porcentaje_ganancia = 30.00;
    $proveedor_id_param = 1;
    
    $sql = "INSERT INTO productos (
                nombre, descripcion, marca, peso, cantidad, 
                precio_costo, precio, porcentaje_rebaja, precio_original, 
                imagen_url, categoria_id, precio_adquisicion, moneda_adquisicion, 
                porcentaje_ganancia, proveedor_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Error al preparar INSERT: " . $conn->error);
    }
    
    $tipos = 's' . 's' . 's' . 'd' . 'i' . 'd' . 'd' . 'i' . 'd' . 's' . 'i' . 'd' . 's' . 'd' . 'i';
    echo "Tipos: '{$tipos}' (strlen=" . strlen($tipos) . ")\n";
    echo "Variables: 15\n";
    
    $stmt->bind_param(
        $tipos,
        $nombre,
        $descripcion,
        $marca,
        $peso,
        $cantidad,
        $precio_costo,
        $precio_final,
        $porcentaje_rebaja,
        $precio_original_param,
        $imagen_url,
        $categoria_id_param,
        $precio_adquisicion,
        $moneda_adquisicion,
        $porcentaje_ganancia,
        $proveedor_id_param
    );
    
    echo "✅ bind_param del INSERT = OK\n";
    
    if ($stmt->execute()) {
        $nuevo_id = $conn->insert_id;
        echo "✅ INSERT ejecutado = OK (id={$nuevo_id})\n";
        
        // Limpiar: borrar el producto de prueba
        $conn->query("DELETE FROM productos WHERE id = {$nuevo_id}");
        echo "🧹 Producto de prueba eliminado\n";
    } else {
        echo "❌ execute() falló: " . $stmt->error . "\n";
    }
    $stmt->close();
    
} catch (Throwable $e) {
    echo "❌ FALLO INSERT: " . $e->getMessage() . "\n";
    echo "   Archivo: " . $e->getFile() . "\n";
    echo "   Línea: " . $e->getLine() . "\n";
}
echo "\n";

// ============================================
// TEST 7: UPDATE directo de producto (el que falla)
// ============================================
echo "--- TEST 7: UPDATE directo de producto (simulado) ---\n";
$res_prod3 = $conn->query("SELECT id FROM productos LIMIT 1");
if ($res_prod3 && $res_prod3->num_rows > 0) {
    $p = $res_prod3->fetch_assoc();
    try {
        $nombre = 'TEST_UPDATE_' . time();
        $descripcion = 'Producto de prueba UPDATE';
        $marca = 'TEST';
        $peso = 0.500;
        $cantidad = 5;
        $precio_costo = 10.00;
        $precio_final = 13.00;
        $porcentaje_rebaja = 0;
        $precio_original_param = 0.00;
        $imagen_url = '/uploads/productos/test.jpg';
        $categoria_id_param = 0;
        $precio_adquisicion = 0.00;
        $moneda_adquisicion = 'USD';
        $porcentaje_ganancia = 30.00;
        $proveedor_id_param = 1;
        $id_editar_post = $p['id'];
        
        $sql = "UPDATE productos SET 
                    nombre = ?, descripcion = ?, marca = ?, peso = ?, cantidad = ?, 
                    precio_costo = ?, precio = ?, porcentaje_rebaja = ?, precio_original = ?, 
                    imagen_url = ?, categoria_id = ?, precio_adquisicion = ?, moneda_adquisicion = ?, 
                    porcentaje_ganancia = ?, proveedor_id = ?
                WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error al preparar UPDATE: " . $conn->error);
        }
        
        $tipos = 's' . 's' . 's' . 'd' . 'i' . 'd' . 'd' . 'i' . 'd' . 's' . 'i' . 'd' . 's' . 'd' . 'i' . 'i';
        echo "Tipos: '{$tipos}' (strlen=" . strlen($tipos) . ")\n";
        echo "Variables: 16\n";
        
        $stmt->bind_param(
            $tipos,
            $nombre,
            $descripcion,
            $marca,
            $peso,
            $cantidad,
            $precio_costo,
            $precio_final,
            $porcentaje_rebaja,
            $precio_original_param,
            $imagen_url,
            $categoria_id_param,
            $precio_adquisicion,
            $moneda_adquisicion,
            $porcentaje_ganancia,
            $proveedor_id_param,
            $id_editar_post
        );
        
        echo "✅ bind_param del UPDATE = OK\n";
        
        // NO ejecutamos el UPDATE para no modificar el producto real
        echo "ℹ️  UPDATE NO ejecutado (solo se probó el bind_param)\n";
        $stmt->close();
        
    } catch (Throwable $e) {
        echo "❌ FALLO UPDATE: " . $e->getMessage() . "\n";
        echo "   Archivo: " . $e->getFile() . "\n";
        echo "   Línea: " . $e->getLine() . "\n";
    }
} else {
    echo "⚠️ No hay productos para probar\n";
}
echo "\n";

echo "========================================\n";
echo "FIN DEL TEST\n";
echo "========================================\n";
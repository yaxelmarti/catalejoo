<?php
// ============================================
// PRODUCTOS ACCIONES - CREAR/EDITAR/ELIMINAR
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
ob_start();

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/historial.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/csrf.php';
require_once __DIR__ . '/../../includes/moneda_funciones.php';

// ============================================
// VALIDAR SESIÓN ACTIVA
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

// ============================================
// DEFINIR PERMISOS DEL USUARIO
// ============================================
$rol_actual = trim($_SESSION['rol'] ?? '');
$es_super_admin = ($rol_actual === 'Super Admin');
$usuario_id_actual = intval($_SESSION['usuario_id']);

$permisos = [
    'editar' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Inventario', 'Proveedor']),
    'eliminar' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Proveedor']),
    'crear' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'])
];

$accion = $_GET['accion'] ?? ($_POST['accion'] ?? '');
$id = isset($_GET['id']) ? intval($_GET['id']) : (isset($_POST['id']) ? intval($_POST['id']) : 0);
$mensaje = '';
$tipo_mensaje = '';

// ============================================
// VERIFICAR PERMISOS
// ============================================
if ($accion == 'crear' && !$permisos['crear']) {
    error_log("[productos_acciones] Usuario {$usuario_id_actual} intentó CREAR sin permiso");
    $_SESSION['mensaje'] = '❌ No tienes permiso para CREAR productos';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'editar' && !$permisos['editar']) {
    error_log("[productos_acciones] Usuario {$usuario_id_actual} intentó EDITAR sin permiso (id={$id})");
    $_SESSION['mensaje'] = '❌ No tienes permiso para EDITAR productos';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'eliminar' && !$permisos['eliminar']) {
    error_log("[productos_acciones] Usuario {$usuario_id_actual} intentó ELIMINAR sin permiso (id={$id})");
    $_SESSION['mensaje'] = '❌ No tienes permiso para ELIMINAR productos';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'eliminar_confirmado' && $rol_actual != 'Super Admin') {
    error_log("[productos_acciones] Usuario {$usuario_id_actual} intentó eliminar_confirmado sin ser Super Admin (id={$id})");
    header('Location: /admin/stock/productos.php?error=permiso');
    exit;
}
if ($accion == 'toggle_estado' && !$permisos['editar']) {
    error_log("[productos_acciones] Usuario {$usuario_id_actual} intentó toggle_estado sin permiso (id={$id})");
    $_SESSION['mensaje'] = '❌ No tienes permiso para cambiar el estado del producto';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'eliminar_imagen' && !$permisos['editar']) {
    error_log("[productos_acciones] Usuario {$usuario_id_actual} intentó eliminar_imagen sin permiso (id={$id})");
    $_SESSION['mensaje'] = '❌ No tienes permiso para modificar la imagen del producto';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}

// ============================================
// VALIDACIÓN CSRF
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar'])) {
    if (!function_exists('csrf_validar') || !csrf_validar($_POST['csrf_token'] ?? '')) {
        error_log("[productos_acciones] CSRF inválido en guardar (usuario={$usuario_id_actual})");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/stock/productos.php');
        exit;
    }
}

$token_csrf = $_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? '');
if (in_array($accion, ['toggle_estado', 'eliminar', 'eliminar_imagen'], true)) {
    if (!function_exists('csrf_validar') || !csrf_validar($token_csrf)) {
        error_log("[productos_acciones] CSRF inválido en {$accion} (usuario={$usuario_id_actual}, id={$id})");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/stock/productos.php');
        exit;
    }
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_filtro = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_filtro == 0) {
    error_log("[productos_acciones] Proveedor sin tienda asociada (usuario={$usuario_id_actual})");
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_filtro > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_filtro);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $stmt_check->close();
        error_log("[productos_acciones] Tienda inactiva (usuario={$usuario_id_actual}, proveedor={$proveedor_id_filtro})");
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// PROVEEDOR SELECCIONADO
// ============================================
$proveedor_id_seleccionado = $proveedor_id_filtro;

if ($es_super_admin) {
    if (isset($_POST['proveedor_id']) && $_POST['proveedor_id'] !== '') {
        $proveedor_id_seleccionado = intval($_POST['proveedor_id']);
    } elseif (isset($_GET['proveedor_id']) && $_GET['proveedor_id'] !== '') {
        $proveedor_id_seleccionado = intval($_GET['proveedor_id']);
    }
}

// ============================================
// CARGAR PRODUCTO PRIMERO (para saber su proveedor y moneda)
// ============================================
$producto = null;
if ($accion == 'editar' && $id > 0) {
    $stmt_prod = $conn->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt_prod->bind_param("i", $id);
    $stmt_prod->execute();
    $producto = $stmt_prod->get_result()->fetch_assoc();
    $stmt_prod->close();
    
    if (!$producto) {
        error_log("[productos_acciones] producto no encontrado (usuario={$usuario_id_actual}, id={$id})");
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: /admin/stock/productos.php');
        exit;
    }
    
    if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_filtro)) {
        error_log("[productos_acciones] editar sin permiso (usuario={$usuario_id_actual}, id={$id}, proveedor={$proveedor_id_filtro})");
        $_SESSION['mensaje'] = "❌ No tienes permiso para editar este producto (no pertenece a tu tienda)";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: /admin/stock/productos.php');
        exit;
    }
    
    // Si es Super Admin y no seleccionó proveedor, usar el del producto
    if ($es_super_admin && $proveedor_id_seleccionado == 0) {
        $proveedor_id_seleccionado = intval($producto['proveedor_id'] ?? 0);
    }
}

// ============================================
// LISTA DE PROVEEDORES (solo Super Admin)
// ============================================
$lista_proveedores = [];
if ($es_super_admin) {
    $res_prov = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda ASC");
    if ($res_prov) {
        while ($p = $res_prov->fetch_assoc()) {
            $lista_proveedores[] = $p;
        }
        $res_prov->free();
    }
}

// ============================================
// MONEDAS DISPONIBLES (adquisición)
// ============================================
$proveedor_para_monedas = $es_super_admin ? $proveedor_id_seleccionado : $proveedor_id_filtro;
$monedas_disponibles = getMonedasParaAdquisicion($conn, $proveedor_para_monedas);

// ============================================
// ACTIVAR / DESACTIVAR PRODUCTO
// ============================================
if ($accion == 'toggle_estado' && $id > 0) {
    if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_filtro)) {
        error_log("[productos_acciones] toggle_estado sin permiso (usuario={$usuario_id_actual}, id={$id}, proveedor={$proveedor_id_filtro})");
        $_SESSION['mensaje'] = "❌ No tienes permiso para modificar este producto (no pertenece a tu tienda)";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: /admin/stock/productos.php');
        exit;
    }
    
    $estado_actual = isset($_GET['estado']) ? intval($_GET['estado']) : (isset($_POST['estado']) ? intval($_POST['estado']) : 1);
    $nuevo_estado = $estado_actual ? 0 : 1;
    
    $stmt = $conn->prepare("SELECT nombre FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($producto) {
        $stmt = $conn->prepare("UPDATE productos SET activo = ? WHERE id = ?");
        $stmt->bind_param("ii", $nuevo_estado, $id);
        
        if ($stmt->execute()) {
            $stmt->close();
            $cambios = ['activo' => ['antes' => $estado_actual, 'despues' => $nuevo_estado]];
            registrarCambioProducto($conn, $id, 'editar', $cambios);

            try {
                $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
                if (file_exists($ruta_combos)) {
                    include_once $ruta_combos;
                    if (function_exists('actualizarCombosPorProducto')) {
                        actualizarCombosPorProducto($conn, $id, $proveedor_id_filtro);
                    }
                }
            } catch (Throwable $e_combos) {
                error_log('[productos_acciones toggle_estado actualizar_combos] ' . $e_combos->getMessage());
            }
            
            error_log("[productos_acciones] toggle_estado OK (usuario={$usuario_id_actual}, id={$id}, nuevo_estado={$nuevo_estado})");
            $_SESSION['mensaje'] = "✅ Producto '{$producto['nombre']}' " . ($nuevo_estado ? 'activado' : 'desactivado') . " correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
        } else {
            $stmt->close();
            error_log("[productos_acciones] toggle_estado error SQL: " . $conn->error);
            $_SESSION['mensaje'] = "❌ Error al cambiar estado: " . $conn->error;
            $_SESSION['tipo_mensaje'] = "error";
        }
    } else {
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    $redirect = '/admin/stock/productos.php';
    if (isset($_GET['filtro_estado'])) {
        $redirect .= '?filtro_estado=' . urlencode($_GET['filtro_estado']);
    }
    
    if (!headers_sent()) {
        header('Location: ' . $redirect);
        exit;
    } else {
        echo '<script>window.location.href = "' . $redirect . '";</script>';
        exit;
    }
}

// ============================================
// ELIMINACIÓN CONFIRMADA (SUPER ADMIN)
// ============================================
if ($accion == 'eliminar_confirmado' && $id > 0 && $rol_actual == 'Super Admin') {
    $check = $conn->prepare("SELECT id, nombre, imagen_url FROM productos WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $producto_eliminar = $check->get_result()->fetch_assoc();
    $check->close();
    
    if ($producto_eliminar) {
        $stmt_carritos = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos WHERE producto_id = ?");
        $stmt_carritos->bind_param("i", $id);
        $stmt_carritos->execute();
        $total_carritos = $stmt_carritos->get_result()->fetch_assoc()['total'];
        $stmt_carritos->close();
        
        $stmt_pedidos = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles pd 
                                        JOIN pedidos p ON pd.pedido_id = p.id 
                                        WHERE pd.producto_id = ? 
                                        AND p.estado_actual NOT IN ('cancelado', 'devuelto')");
        $stmt_pedidos->bind_param("i", $id);
        $stmt_pedidos->execute();
        $total_pedidos = $stmt_pedidos->get_result()->fetch_assoc()['total'];
        $stmt_pedidos->close();
        
        if ($total_carritos > 0 || $total_pedidos > 0) {
            $_SESSION['mensaje'] = "❌ No se puede eliminar '{$producto_eliminar['nombre']}': está en $total_carritos carrito(s) y $total_pedidos pedido(s) en curso. Desactívalo en su lugar.";
            $_SESSION['tipo_mensaje'] = "error";
            header('Location: /admin/stock/productos.php');
            exit;
        }
        
        $conn->begin_transaction();
        try {
            $stmt_del = $conn->prepare("DELETE FROM historial_producto WHERE producto_id = ?");
            $stmt_del->bind_param("i", $id);
            $stmt_del->execute();
            $stmt_del->close();
            
            $stmt_del = $conn->prepare("DELETE FROM historial_productos_cambios WHERE producto_id = ?");
            $stmt_del->bind_param("i", $id);
            $stmt_del->execute();
            $stmt_del->close();
            
            $stmt_del = $conn->prepare("DELETE FROM movimientos_inventario WHERE producto_id = ?");
            $stmt_del->bind_param("i", $id);
            $stmt_del->execute();
            $stmt_del->close();
            
            if (!empty($producto_eliminar['imagen_url'])) {
                $ruta_imagen = $_SERVER['DOCUMENT_ROOT'] . $producto_eliminar['imagen_url'];
                if (file_exists($ruta_imagen)) {
                    unlink($ruta_imagen);
                }
            }
            
            $stmt = $conn->prepare("DELETE FROM productos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            registrarCambioProducto($conn, $id, 'eliminar', ['nombre' => $producto_eliminar['nombre']]);
            
            $conn->commit();
            error_log("[productos_acciones] eliminar_confirmado OK (usuario={$usuario_id_actual}, id={$id})");
            $_SESSION['mensaje'] = "✅ Producto '{$producto_eliminar['nombre']}' eliminado permanentemente";
            $_SESSION['tipo_mensaje'] = "exito";
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[productos_acciones eliminar_confirmado] ' . $e->getMessage() . ' | Línea: ' . $e->getLine());
            $_SESSION['mensaje'] = "❌ No se pudo eliminar: " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "error";
        }
    } else {
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    header('Location: /admin/stock/productos.php');
    exit;
}

// ============================================
// ELIMINAR PRODUCTO (CON VERIFICACIÓN)
// ============================================
if ($accion == 'eliminar' && $id > 0) {
    $check = $conn->prepare("SELECT id, nombre, imagen_url, proveedor_id FROM productos WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $producto_eliminar = $check->get_result()->fetch_assoc();
    $check->close();
    
    if ($producto_eliminar) {
        if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_filtro)) {
            error_log("[productos_acciones] eliminar sin permiso (usuario={$usuario_id_actual}, id={$id}, proveedor={$proveedor_id_filtro})");
            $_SESSION['mensaje'] = "❌ No tienes permiso para eliminar este producto (no pertenece a tu tienda)";
            $_SESSION['tipo_mensaje'] = "error";
            header('Location: /admin/stock/productos.php');
            exit;
        }
        
        if (!empty($producto_eliminar['imagen_url'])) {
            $ruta_imagen = $_SERVER['DOCUMENT_ROOT'] . $producto_eliminar['imagen_url'];
            if (file_exists($ruta_imagen)) {
                unlink($ruta_imagen);
            }
        }

        $stmt_carritos = $conn->prepare("SELECT cp.*, c.id as carrito_id, c.fecha_expiracion, c.estado 
                                         FROM carrito_productos cp 
                                         JOIN carritos c ON cp.carrito_id = c.id 
                                         WHERE cp.producto_id = ?");
        $stmt_carritos->bind_param("i", $id);
        $stmt_carritos->execute();
        $carritos_result = $stmt_carritos->get_result();
        $carritos = $carritos_result->num_rows;
        $stmt_carritos->close();
        
        $stmt_pedidos = $conn->prepare("SELECT pd.*, p.id as pedido_id, p.estado_actual, p.fecha_pedido 
                                        FROM pedido_detalles pd 
                                        JOIN pedidos p ON pd.pedido_id = p.id 
                                        WHERE pd.producto_id = ? 
                                        AND p.estado_actual NOT IN ('cancelado', 'devuelto')");
        $stmt_pedidos->bind_param("i", $id);
        $stmt_pedidos->execute();
        $pedidos_result = $stmt_pedidos->get_result();
        $pedidos = $pedidos_result->num_rows;
        $stmt_pedidos->close();
        
        $stmt_hist = $conn->prepare("SELECT COUNT(*) as total FROM historial_producto WHERE producto_id = ?");
        $stmt_hist->bind_param("i", $id);
        $stmt_hist->execute();
        $historial_mov = $stmt_hist->get_result()->fetch_assoc()['total'];
        $stmt_hist->close();
        
        $stmt_hist = $conn->prepare("SELECT COUNT(*) as total FROM historial_productos_cambios WHERE producto_id = ?");
        $stmt_hist->bind_param("i", $id);
        $stmt_hist->execute();
        $historial_cambios = $stmt_hist->get_result()->fetch_assoc()['total'];
        $stmt_hist->close();
        
        $tiene_historial = ($historial_mov > 0 || $historial_cambios > 0);
        
        if ($carritos > 0 || $pedidos > 0) {
            $mensaje_html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>No se puede eliminar</title><link rel="stylesheet" href="/estilo.css"><style>*{box-sizing:border-box}body{font-family:Arial,sans-serif;background:#f8fafc;padding:1rem;margin:0}.card{max-width:600px;margin:2rem auto;background:#fff;border-radius:12px;padding:1.5rem;box-shadow:0 4px 12px rgba(0,0,0,0.1)}@media(min-width:768px){.card{padding:2rem}}.warning{color:#f56565;font-size:3rem;margin-bottom:1rem;text-align:center}h2{color:#2d3748;margin-bottom:1rem;text-align:center;font-size:1.3rem}@media(min-width:768px){h2{font-size:1.5rem}}.info{background:#fef5e7;padding:1rem;border-radius:8px;margin:1.5rem 0;word-break:break-word}.btn-group{display:flex;gap:1rem;justify-content:center;margin-top:1.5rem;flex-wrap:wrap}.btn{padding:0.75rem 1.5rem;border-radius:8px;text-decoration:none;font-weight:600;transition:all 0.3s;display:inline-block;text-align:center}.btn-secondary{background:#edf2f7;color:#4a5568}.btn-secondary:hover{background:#e2e8f0;transform:translateY(-2px)}ul{margin:0.5rem 0 0 1.5rem;padding:0}li{margin:0.3rem 0;word-break:break-word}@media(max-width:480px){.btn{width:100%}}</style></head><body><div class="card"><div class="warning">⛔</div><h2>No se puede eliminar el producto</h2><p>El producto <strong>' . htmlspecialchars($producto_eliminar['nombre']) . '</strong> está en uso:</p><div class="info">';
            
            if ($carritos > 0) {
                $mensaje_html .= "<strong>🛒 Carritos activos ($carritos):</strong><ul>";
                $carritos_result->data_seek(0);
                while($c = $carritos_result->fetch_assoc()) {
                    $mensaje_html .= "<li>Carrito ID: {$c['carrito_id']} (expira: " . date('d/m/Y H:i', strtotime($c['fecha_expiracion'])) . ")</li>";
                }
                $mensaje_html .= "</ul>";
            }
            
            if ($pedidos > 0) {
                $mensaje_html .= "<strong>📋 Pedidos en curso ($pedidos):</strong><ul>";
                $pedidos_result->data_seek(0);
                while($p = $pedidos_result->fetch_assoc()) {
                    $mensaje_html .= "<li>Pedido #{$p['pedido_id']} - Estado: {$p['estado_actual']} - Fecha: " . date('d/m/Y', $p['fecha_pedido']) . "</li>";
                }
                $mensaje_html .= "</ul>";
            }
            
            $mensaje_html .= '</div><div class="btn-group"><a href="/admin/stock/productos.php" class="btn btn-secondary">Cancelar</a></div></div></body></html>';
            
            echo $mensaje_html;
            exit;
        }
        
        if ($tiene_historial) {
            if ($rol_actual == 'Super Admin') {
                echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Confirmar eliminación</title><link rel="stylesheet" href="/estilo.css"><style>*{box-sizing:border-box}body{font-family:Arial,sans-serif;background:#f8fafc;padding:1rem;margin:0}.confirm-card{max-width:500px;margin:2rem auto;background:#fff;border-radius:12px;padding:1.5rem;box-shadow:0 4px 12px rgba(0,0,0,0.1);text-align:center}@media(min-width:768px){.confirm-card{padding:2rem}}.warning{color:#f56565;font-size:3rem;margin-bottom:1rem}h2{color:#2d3748;margin-bottom:1rem;font-size:1.3rem}@media(min-width:768px){h2{font-size:1.5rem}}p{color:#4a5568;margin-bottom:1.5rem;line-height:1.5}.btn-group{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap}.btn{padding:0.75rem 1.5rem;border-radius:8px;text-decoration:none;font-weight:600;transition:all 0.3s;display:inline-block;text-align:center}.btn-danger{background:#f56565;color:#fff}.btn-danger:hover{background:#e53e3e;transform:translateY(-2px)}.btn-secondary{background:#edf2f7;color:#4a5568}.btn-secondary:hover{background:#e2e8f0;transform:translateY(-2px)}.historial-info{background:#fef5e7;padding:1rem;border-radius:8px;margin:1.5rem 0;text-align:left;word-break:break-word}@media(max-width:480px){.btn{width:100%}}</style></head><body><div class="confirm-card"><div class="warning">⚠️</div><h2>¿Eliminar permanentemente?</h2><p>El producto <strong>' . htmlspecialchars($producto_eliminar['nombre']) . '</strong> tiene registros en el historial:</p><div class="historial-info"><p>📜 Movimientos de inventario: <strong>' . $historial_mov . '</strong></p><p>📝 Cambios registrados: <strong>' . $historial_cambios . '</strong></p></div><p style="color:#c53030"><strong>Esta acción NO SE PUEDE DESHACER.</strong></p><div class="btn-group"><a href="/admin/stock/productos_acciones.php?accion=eliminar_confirmado&id=' . $id . '&csrf_token=' . urlencode($_SESSION['csrf_token'] ?? '') . '" class="btn btn-danger">🗑️ Eliminar permanentemente</a><a href="/admin/stock/productos.php" class="btn btn-secondary">Cancelar</a></div></div></body></html>';
                exit;
            } else {
                $stmt = $conn->prepare("UPDATE productos SET activo = 0 WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $stmt->close();

                try {
                    $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
                    if (file_exists($ruta_combos)) {
                        include_once $ruta_combos;
                        if (function_exists('actualizarCombosPorProducto')) {
                            actualizarCombosPorProducto($conn, $id, $proveedor_id_filtro);
                        }
                    }
                } catch (Throwable $e_combos) {
                    error_log('[productos_acciones eliminar historial actualizar_combos] ' . $e_combos->getMessage());
                }

                error_log("[productos_acciones] eliminar desactivado por historial (usuario={$usuario_id_actual}, id={$id})");
                $_SESSION['mensaje'] = "⚠️ Producto '{$producto_eliminar['nombre']}' ha sido DESACTIVADO (tiene historial). Solo Super Admin puede eliminarlo permanentemente.";
                $_SESSION['tipo_mensaje'] = "info";
                header('Location: /admin/stock/productos.php');
                exit;
            }
        }
        
        if ($rol_actual == 'Super Admin') {
            if (!empty($producto_eliminar['imagen_url']) && strpos($producto_eliminar['imagen_url'], 'uploads/') === 0) {
                $ruta_imagen = __DIR__ . '/' . $producto_eliminar['imagen_url'];
                if (file_exists($ruta_imagen)) {
                    unlink($ruta_imagen);
                }
            }
            
            $stmt = $conn->prepare("DELETE FROM productos WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                $stmt->close();
                registrarCambioProducto($conn, $id, 'eliminar', ['nombre' => $producto_eliminar['nombre']]);
                error_log("[productos_acciones] eliminar OK (usuario={$usuario_id_actual}, id={$id})");
                $_SESSION['mensaje'] = "✅ Producto '{$producto_eliminar['nombre']}' eliminado permanentemente";
                $_SESSION['tipo_mensaje'] = "exito";
            } else {
                $stmt->close();
                error_log("[productos_acciones] eliminar error SQL: " . $conn->error);
                $_SESSION['mensaje'] = "❌ Error al eliminar: " . $conn->error;
                $_SESSION['tipo_mensaje'] = "error";
            }
        } else {
            $stmt = $conn->prepare("UPDATE productos SET activo = 0 WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();

            try {
                $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
                if (file_exists($ruta_combos)) {
                    include_once $ruta_combos;
                    if (function_exists('actualizarCombosPorProducto')) {
                        actualizarCombosPorProducto($conn, $id, $proveedor_id_filtro);
                    }
                }
            } catch (Throwable $e_combos) {
                error_log('[productos_acciones eliminar desactivado actualizar_combos] ' . $e_combos->getMessage());
            }

            error_log("[productos_acciones] eliminar desactivado (usuario={$usuario_id_actual}, id={$id})");
            $_SESSION['mensaje'] = "✅ Producto '{$producto_eliminar['nombre']}' ha sido DESACTIVADO";
            $_SESSION['tipo_mensaje'] = "exito";
        }
    } else {
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    header('Location: /admin/stock/productos.php');
    exit;
}

// ============================================
// ELIMINAR IMAGEN
// ============================================
if ($accion == 'eliminar_imagen' && $id > 0) {
    if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_filtro)) {
        error_log("[productos_acciones] eliminar_imagen sin permiso (usuario={$usuario_id_actual}, id={$id})");
        $_SESSION['mensaje'] = "❌ No tienes permiso para modificar este producto";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: /admin/stock/productos.php');
        exit;
    }
    
    $stmt = $conn->prepare("SELECT imagen_url FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($producto && !empty($producto['imagen_url'])) {
        if (strpos($producto['imagen_url'], 'uploads/') === 0) {
            $ruta_imagen = __DIR__ . '/' . $producto['imagen_url'];
            if (file_exists($ruta_imagen)) {
                unlink($ruta_imagen);
            }
        }
        
        $stmt = $conn->prepare("UPDATE productos SET imagen_url = NULL WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $stmt->close();
            error_log("[productos_acciones] eliminar_imagen OK (usuario={$usuario_id_actual}, id={$id})");
            $_SESSION['mensaje'] = "✅ Imagen eliminada correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
        } else {
            $stmt->close();
            error_log("[productos_acciones] eliminar_imagen error SQL: " . $conn->error);
            $_SESSION['mensaje'] = "❌ Error al eliminar imagen: " . $conn->error;
            $_SESSION['tipo_mensaje'] = "error";
        }
    } else {
        $_SESSION['mensaje'] = "❌ El producto no tiene imagen";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    header('Location: /admin/stock/productos_acciones.php?accion=editar&id=' . $id);
    exit;
}

// ============================================
// CATEGORÍAS (PARA EL FORMULARIO)
// ============================================
$categorias = $conn->query("SELECT * FROM categorias WHERE activo = 1 ORDER BY nombre");

$proveedor_id_usuario = $proveedor_id_filtro;

// ============================================
// GUARDAR (CREAR O EDITAR)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar'])) {
    
    // Verificar propiedad ANTES de la transacción
    if ($accion == 'editar' && isset($_POST['id'])) {
        $id_editar = intval($_POST['id']);
        if (!productoPerteneceAProveedor($conn, $id_editar, $proveedor_id_filtro)) {
            error_log("[productos_acciones] guardar editar sin permiso (usuario={$usuario_id_actual}, id={$id_editar})");
            $_SESSION['mensaje'] = "❌ No tienes permiso para editar este producto (no pertenece a tu tienda)";
            $_SESSION['tipo_mensaje'] = "error";
            header('Location: /admin/stock/productos.php');
            exit;
        }
    }
    
    // Datos del formulario
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $marca = trim($_POST['marca'] ?? '');
    $peso = floatval($_POST['peso'] ?? 0);
    $cantidad = intval($_POST['cantidad'] ?? 0);
    $porcentaje_rebaja = intval($_POST['porcentaje_rebaja'] ?? 0);
    $categoria_id = !empty($_POST['categoria_id']) ? intval($_POST['categoria_id']) : null;
    $eliminar_imagen = isset($_POST['eliminar_imagen']) ? true : false;
    
    $moneda_adquisicion = strtoupper(trim($_POST['moneda_adquisicion'] ?? 'USD'));
    $costo = floatval($_POST['costo'] ?? 0);
    $porcentaje_ganancia = floatval($_POST['porcentaje_ganancia'] ?? 0);
    
    // Imagen
    $imagen_url = '';
    if (is_array($producto) && !empty($producto['imagen_url'])) {
        $imagen_url = $producto['imagen_url'];
    }
    
    if ($eliminar_imagen && $accion == 'editar') {
        if (is_array($producto) && !empty($producto['imagen_url']) && strpos($producto['imagen_url'], 'uploads/') === 0) {
            $ruta_imagen = __DIR__ . '/' . $producto['imagen_url'];
            if (file_exists($ruta_imagen)) {
                unlink($ruta_imagen);
            }
        }
        $imagen_url = null;
    }
    
    if (isset($_FILES['imagen_archivo']) && $_FILES['imagen_archivo']['error'] == 0) {
        $target_dir = $_SERVER['DOCUMENT_ROOT'] . "/uploads/productos/";
        
        if ($accion == 'editar' && is_array($producto) && !empty($producto['imagen_url']) && strpos($producto['imagen_url'], 'uploads/') === 0) {
            $ruta_anterior = __DIR__ . '/' . $producto['imagen_url'];
            if (file_exists($ruta_anterior)) {
                unlink($ruta_anterior);
            }
        }
        
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $extension = strtolower(pathinfo($_FILES["imagen_archivo"]["name"], PATHINFO_EXTENSION));
        $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array($extension, $extensiones_permitidas)) {
            $errores[] = "Solo se permiten imágenes JPG, JPEG, PNG, GIF o WEBP";
        } elseif ($_FILES["imagen_archivo"]["size"] > 2 * 1024 * 1024) {
            $errores[] = "La imagen no debe pesar más de 2MB";
        } else {
            $check = getimagesize($_FILES["imagen_archivo"]["tmp_name"]);
            if ($check !== false) {
                $nombre_unico = time() . '_' . uniqid() . '.' . $extension;
                $target_file = $target_dir . $nombre_unico;
                
                if (move_uploaded_file($_FILES["imagen_archivo"]["tmp_name"], $target_file)) {
                    $imagen_url = "/uploads/productos/" . $nombre_unico;
                } else {
                    $errores[] = "Error al subir la imagen";
                }
            } else {
                $errores[] = "El archivo no es una imagen válida";
            }
        }
    } elseif (!empty($_POST['imagen_url']) && !$eliminar_imagen) {
        $imagen_url = trim($_POST['imagen_url']);
        if (filter_var($imagen_url, FILTER_VALIDATE_URL)) {
            // URL válida
        } elseif (preg_match('/^\/[a-zA-Z0-9\/_\-\.]+\.(jpg|jpeg|png|gif|webp|svg)$/i', $imagen_url)) {
            // Ruta válida
        } else {
            $errores[] = "La URL o ruta de la imagen no es válida.";
        }
    } elseif ($accion == 'crear' && empty($imagen_url) && !$eliminar_imagen) {
        $errores[] = "Debes subir una imagen o proporcionar una URL";
    }
    
    // Si hay errores, mostrarlos
    if (!empty($errores)) {
        $mensaje = "❌ " . implode("<br>❌ ", $errores);
        $tipo_mensaje = "error";
    } else {
        
        $precio_original = $porcentaje_rebaja > 0 ? $precio_venta : 0;
        $precio_original_param = $precio_original;
        $categoria_id_param = $categoria_id ?? 0;
        $producto_id_actual = 0;
        
        $conn->begin_transaction();
        try {
            
            // ============================================
            // DETERMINAR PROVEEDOR (DENTRO DE LA TRANSACCIÓN)
            // ============================================
            $proveedor_id_param = 0;
            
            if ($es_super_admin) {
                $prov_post = isset($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : 0;
                
                if ($prov_post > 0) {
                    // Validar proveedor dentro de la transacción (evita race condition)
                    $stmt_prov_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1 FOR UPDATE");
                    $stmt_prov_check->bind_param("i", $prov_post);
                    $stmt_prov_check->execute();
                    $prov_valido = ($stmt_prov_check->get_result()->num_rows > 0);
                    $stmt_prov_check->close();
                    
                    if ($prov_valido) {
                        $proveedor_id_param = $prov_post;
                    }
                }
                
                if ($proveedor_id_param == 0 && $accion == 'crear') {
                    throw new Exception("Debes seleccionar un proveedor válido para el producto");
                }
                
                // En editar, si no seleccionó proveedor, usar el del producto original
                if ($proveedor_id_param == 0 && $accion == 'editar' && is_array($producto)) {
                    $proveedor_id_param = intval($producto['proveedor_id'] ?? 0);
                }
            } else {
                $proveedor_id_param = $proveedor_id_filtro;
            }
            
            // ============================================
            // CALCULAR PRECIOS CON EL PROVEEDOR CORRECTO
            // ============================================
            $prov_para_tasa = $proveedor_id_param > 0 ? $proveedor_id_param : $proveedor_id_filtro;
            
            $monedas_validas = getMonedasParaAdquisicion($conn, $prov_para_tasa);

             if (!in_array($moneda_adquisicion, $monedas_validas)) {
              $moneda_adquisicion = 'USD';
             }
            
            // precio_adquisicion SIEMPRE tiene el valor en moneda local (o USD si moneda = USD)
$precio_adquisicion = $costo;

if ($moneda_adquisicion === 'USD') {
    $precio_costo = $costo;
} else {
    $tasa = getTasaProveedor($conn, $prov_para_tasa, $moneda_adquisicion);
    if ($tasa <= 0) {
        throw new Exception("No hay tasa de cambio configurada para {$moneda_adquisicion}. Ve a Configuración → Monedas para definir una tasa propia o usar la global.");
    }
    $precio_costo = $costo / $tasa;
}
            
            $precio_venta = $precio_costo * (1 + $porcentaje_ganancia / 100);
            
            $precio_final = $precio_venta;
            if ($porcentaje_rebaja > 0) {
                $precio_final = $precio_venta * (100 - $porcentaje_rebaja) / 100;
            }
            
            // Recalcular precio_original
            $precio_original = $porcentaje_rebaja > 0 ? $precio_venta : 0;
            $precio_original_param = $precio_original;
            
            if ($accion == 'crear') {
                $sql = "INSERT INTO productos (
                            nombre, descripcion, marca, peso, cantidad, 
                            precio_costo, precio, porcentaje_rebaja, precio_original, 
                            imagen_url, categoria_id, precio_adquisicion, moneda_adquisicion, 
                            porcentaje_ganancia, proveedor_id
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    throw new Exception("Error al preparar INSERT: " . $conn->error);
                }
                
                $tipos_insert = 's' . 's' . 's' . 'd' . 'i' . 'd' . 'd' . 'i' . 'd' . 's' . 'i' . 'd' . 's' . 'd' . 'i';
                if (strlen($tipos_insert) !== 15) {
                    throw new Exception("INSERT: string de tipos tiene " . strlen($tipos_insert) . " caracteres, debe tener 15");
                }
                
                $stmt->bind_param(
                    $tipos_insert,
                    $nombre,
                    $descripcion,
                    $marca,
                    $peso,
                    $cantidad,
                    $precio_costo,
                    $precio_final,
                    $porcentaje_rebaja,
                    $precio_original_param,
                    $imagen_url,
                    $categoria_id_param,
                    $precio_adquisicion,
                    $moneda_adquisicion,
                    $porcentaje_ganancia,
                    $proveedor_id_param
                );
                
                if (!$stmt->execute()) {
                    throw new Exception("Error al ejecutar INSERT: " . $stmt->error);
                }
                
                $nuevo_id = $conn->insert_id;
                $stmt->close();
                $mensaje_exito = "creado";
                $producto_id_actual = $nuevo_id;
                
                $cambios = [
                    'nombre' => $nombre,
                    'descripcion' => $descripcion,
                    'marca' => $marca,
                    'peso' => $peso,
                    'cantidad' => $cantidad,
                    'precio_costo' => $precio_costo,
                    'precio_venta' => $precio_venta,
                    'porcentaje_rebaja' => $porcentaje_rebaja,
                    'categoria_id' => $categoria_id,
                    'imagen_url' => $imagen_url,
                    'precio_adquisicion' => $precio_adquisicion,
                    'moneda_adquisicion' => $moneda_adquisicion,
                    'porcentaje_ganancia' => $porcentaje_ganancia,
                    'proveedor_id' => $proveedor_id_param
                ];
                registrarCambioProducto($conn, $nuevo_id, 'crear', $cambios);
                
            } else {
                $id_editar_post = intval($_POST['id']);
                
                $sql = "UPDATE productos SET 
                            nombre = ?, descripcion = ?, marca = ?, peso = ?, cantidad = ?, 
                            precio_costo = ?, precio = ?, porcentaje_rebaja = ?, precio_original = ?, 
                            imagen_url = ?, categoria_id = ?, precio_adquisicion = ?, moneda_adquisicion = ?, 
                            porcentaje_ganancia = ?, proveedor_id = ?
                        WHERE id = ?";
                
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    throw new Exception("Error al preparar UPDATE: " . $conn->error);
                }
                
                $tipos_update = 's' . 's' . 's' . 'd' . 'i' . 'd' . 'd' . 'i' . 'd' . 's' . 'i' . 'd' . 's' . 'd' . 'i' . 'i';
                if (strlen($tipos_update) !== 16) {
                    throw new Exception("UPDATE: string de tipos tiene " . strlen($tipos_update) . " caracteres, debe tener 16");
                }
                
                $stmt->bind_param(
                    $tipos_update,
                    $nombre,
                    $descripcion,
                    $marca,
                    $peso,
                    $cantidad,
                    $precio_costo,
                    $precio_final,
                    $porcentaje_rebaja,
                    $precio_original_param,
                    $imagen_url,
                    $categoria_id_param,
                    $precio_adquisicion,
                    $moneda_adquisicion,
                    $porcentaje_ganancia,
                    $proveedor_id_param,
                    $id_editar_post
                );
                
                if (!$stmt->execute()) {
                    throw new Exception("Error al ejecutar UPDATE: " . $stmt->error);
                }
                
                $stmt->close();
                $mensaje_exito = "actualizado";
                $producto_id_actual = $id_editar_post;
                
                $cambios = [];
                $campos_comparar = [
                    'nombre' => 'nombre',
                    'descripcion' => 'descripcion',
                    'marca' => 'marca',
                    'peso' => 'peso',
                    'cantidad' => 'cantidad',
                    'precio_costo' => 'precio_costo',
                    'precio' => 'precio_venta',
                    'porcentaje_rebaja' => 'porcentaje_rebaja',
                    'categoria_id' => 'categoria_id',
                    'imagen_url' => 'imagen_url',
                    'precio_adquisicion' => 'precio_adquisicion',
                    'moneda_adquisicion' => 'moneda_adquisicion',
                    'porcentaje_ganancia' => 'porcentaje_ganancia',
                    'proveedor_id' => 'proveedor_id_param'
                ];
                
                foreach ($campos_comparar as $campo_bd => $campo_var) {
                    $valor_anterior = $producto[$campo_bd] ?? '';
                    $valor_nuevo = $$campo_var ?? '';
                    
                    if (is_numeric($valor_anterior)) $valor_anterior = (string)$valor_anterior;
                    if (is_numeric($valor_nuevo)) $valor_nuevo = (string)$valor_nuevo;
                    
                    if (empty($valor_anterior) && empty($valor_nuevo)) continue;
                    
                    if ($valor_anterior != $valor_nuevo) {
                        $cambios[$campo_bd] = ['antes' => $valor_anterior, 'despues' => $valor_nuevo];
                    }
                }
                
                if (!empty($cambios)) {
                    registrarCambioProducto($conn, $id_editar_post, 'editar', $cambios);
                }
            }
            
            if ($cantidad > 0 && $accion == 'editar' && !empty($_POST['id'])) {
                $id_para_agotado = intval($_POST['id']);
                $stmt_agotado = $conn->prepare("UPDATE productos SET fecha_agotado = NULL WHERE id = ?");
                $stmt_agotado->bind_param("i", $id_para_agotado);
                $stmt_agotado->execute();
                $stmt_agotado->close();
            }
            
            $conn->commit();
            
            error_log("[productos_acciones] guardar OK (usuario={$usuario_id_actual}, accion={$accion}, producto_id={$producto_id_actual}, proveedor_id={$proveedor_id_param})");
            
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[productos_acciones guardar] ' . $e->getMessage() . ' | Línea: ' . $e->getLine() . ' | Usuario: ' . $usuario_id_actual . ' | Accion: ' . $accion);
            $_SESSION['mensaje'] = "❌ Error al guardar: " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "error";
            if (ob_get_level()) ob_end_clean();
            header('Location: /admin/stock/productos.php');
            exit;
        }
        
        try {
            $ruta_combos = $_SERVER['DOCUMENT_ROOT'] . '/admin/stock/actualizar_precio_combos.php';
            if (file_exists($ruta_combos)) {
                include_once $ruta_combos;
                if (function_exists('actualizarCombosPorProducto') && $producto_id_actual > 0) {
                    actualizarCombosPorProducto($conn, $producto_id_actual, $proveedor_id_param);
                }
            }
        } catch (Throwable $e_combos) {
            error_log('[productos_acciones actualizar_combos] ' . $e_combos->getMessage());
        }
        
        $_SESSION['mensaje'] = "✅ Producto '{$nombre}' {$mensaje_exito} correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
        
        if (ob_get_level()) ob_end_clean();
        header('Location: /admin/stock/productos.php');
        exit;
    }
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}

// ============================================
// INCLUIR header.php
// ============================================
require_once __DIR__ . '/../../header.php';
?>

<style>
/* ============================================ */
/* RESPONSIVE FORMULARIO PRODUCTOS              */
/* ============================================ */
.form-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 1rem;
}

@media (max-width: 768px) {
    .form-grid {
        grid-template-columns: 1fr !important;
        gap: 0.8rem !important;
    }
    .form-group input,
    .form-group select,
    .form-group textarea {
        font-size: 16px !important;
        min-height: 44px;
    }
    .btn {
        min-height: 44px;
        font-size: 1rem;
    }
    .container {
        padding: 0 0.5rem;
    }
    .card {
        padding: 1rem;
    }
    .card h2 {
        font-size: 1.2rem;
    }
    .info-rebaja {
        font-size: 0.85rem;
        padding: 0.75rem;
    }
}

@media (max-width: 480px) {
    .form-actions {
        flex-direction: column;
        gap: 0.5rem;
    }
    .form-actions .btn {
        width: 100%;
        text-align: center;
    }
    .card h2 {
        font-size: 1.1rem;
    }
}
</style>

<!-- ============================================ -->
<!-- CONTENIDO PRINCIPAL                          -->
<!-- ============================================ -->
<div class="container">
    <div class="card">
        <h2><?php echo $accion == 'crear' ? '➕ Crear Nuevo Producto' : '✏️ Editar Producto'; ?></h2>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data" class="form-admin" id="formProducto">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="guardar" value="1">
            <input type="hidden" name="accion" value="<?php echo htmlspecialchars($accion); ?>">
            <?php if ($accion == 'editar' && $producto): ?>
                <input type="hidden" name="id" value="<?php echo intval($producto['id']); ?>">
            <?php endif; ?>
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="nombre">📝 Nombre del Producto *</label>
                    <input type="text" id="nombre" name="nombre" required 
                           value="<?php echo htmlspecialchars($_POST['nombre'] ?? ($producto['nombre'] ?? '')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="categoria_id">📌 Categoría</label>
                    <select id="categoria_id" name="categoria_id">
                        <option value="">-- Sin categoría --</option>
                        <?php 
                        if ($categorias) {
                            $categorias->data_seek(0);
                            while($cat = $categorias->fetch_assoc()): 
                                $selected = false;
                                if (isset($_POST['categoria_id']) && $_POST['categoria_id'] == $cat['id']) $selected = true;
                                elseif (isset($producto['categoria_id']) && $producto['categoria_id'] == $cat['id']) $selected = true;
                            ?>
                                <option value="<?php echo intval($cat['id']); ?>" <?php echo $selected ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['icono'] ?? ''); ?> <?php echo htmlspecialchars($cat['nombre']); ?>
                                </option>
                            <?php endwhile; 
                        } ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="descripcion">📄 Descripción *</label>
                <textarea id="descripcion" name="descripcion" required rows="4"><?php echo htmlspecialchars($_POST['descripcion'] ?? ($producto['descripcion'] ?? '')); ?></textarea>
            </div>
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="cantidad">🔢 Cantidad en Stock *</label>
                    <input type="number" id="cantidad" name="cantidad" min="0" required
                           value="<?php echo htmlspecialchars($_POST['cantidad'] ?? ($producto['cantidad'] ?? 0)); ?>">
                </div>
                
                <div class="form-group">
                    <label for="marca">🏷️ Marca</label>
                    <input type="text" id="marca" name="marca" 
                           value="<?php echo htmlspecialchars($_POST['marca'] ?? ($producto['marca'] ?? '')); ?>"
                           placeholder="Ej: Coca-Cola, Nestlé, etc.">
                </div>
                
                <div class="form-group">
                    <label for="peso">⚖️ Peso (kg)</label>
                    <input type="number" id="peso" name="peso" step="0.001" min="0" 
                           value="<?php echo htmlspecialchars($_POST['peso'] ?? ($producto['peso'] ?? 0)); ?>"
                           placeholder="0.000">
                    <small class="campo-opcional">Peso en kilogramos (ej: 0.500 = 500g)</small>
                </div>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label for="proveedor_id">🏪 Proveedor *</label>
                    <?php if ($es_super_admin): ?>
                        <select id="proveedor_id" name="proveedor_id" required onchange="recargarMonedasProveedor(this.value)" style="width: 100%; padding: 0.7rem; border: 1px solid #e2e8f0; border-radius: 8px;">
                            <option value="">-- Seleccionar proveedor --</option>
                            <?php foreach ($lista_proveedores as $prov): ?>
                                <option value="<?php echo intval($prov['id']); ?>" 
                                    <?php echo ($proveedor_id_seleccionado == $prov['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($prov['nombre_tienda']); ?> (ID: <?php echo intval($prov['id']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="campo-opcional">Como Super Admin puedes asignar el producto a cualquier proveedor.</small>
                    <?php else: ?>
                        <input type="text" id="proveedor_id" name="proveedor_id" 
                               value="<?php 
                                   $proveedor_nombre_tmp = 'Sin proveedor';
                                   if ($accion == 'crear') {
                                       $proveedor_id_tmp = intval($proveedor_id_filtro ?? 0);
                                       if ($proveedor_id_tmp > 0) {
                                           $stmt_prov = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                                           $stmt_prov->bind_param("i", $proveedor_id_tmp);
                                           $stmt_prov->execute();
                                           $result_prov = $stmt_prov->get_result();
                                           $prov_tmp = $result_prov->fetch_assoc();
                                           $stmt_prov->close();
                                           $proveedor_nombre_tmp = $prov_tmp ? $prov_tmp['nombre_tienda'] : 'Sin proveedor';
                                       } else {
                                           $proveedor_nombre_tmp = 'Sin proveedor (admin global)';
                                       }
                                   } elseif ($accion == 'editar') {
                                       $proveedor_id_tmp = intval($producto['proveedor_id'] ?? 0);
                                       if ($proveedor_id_tmp > 0) {
                                           $stmt_prov = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                                           $stmt_prov->bind_param("i", $proveedor_id_tmp);
                                           $stmt_prov->execute();
                                           $result_prov = $stmt_prov->get_result();
                                           $prov_tmp = $result_prov->fetch_assoc();
                                           $stmt_prov->close();
                                           $proveedor_nombre_tmp = $prov_tmp ? $prov_tmp['nombre_tienda'] : 'Sin proveedor';
                                       }
                                   }
                                   echo htmlspecialchars($proveedor_nombre_tmp);
                               ?>" 
                               readonly 
                               style="background: #f7fafc; cursor: not-allowed; width: 100%; padding: 0.7rem; border: 1px solid #e2e8f0; border-radius: 8px;">
                        <small style="color: #718096; font-size: 0.7rem;">El proveedor se asigna automáticamente según tu usuario.</small>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php
            $moneda_actual = $_POST['moneda_adquisicion'] ?? ($producto['moneda_adquisicion'] ?? 'USD');

// Opción B: precio_adquisicion SIEMPRE tiene el valor en moneda local (o USD si moneda = USD)
if ($accion == 'editar') {
    $costo_actual = $_POST['costo'] ?? ($producto['precio_adquisicion'] ?? 0);
} else {
    $costo_actual = $_POST['costo'] ?? 0;
}

$precio_costo_actual = $accion == 'editar' ? ($producto['precio_costo'] ?? 0) : 0;
$porcentaje_ganancia_actual = $_POST['porcentaje_ganancia'] ?? ($producto['porcentaje_ganancia'] ?? 0);
$precio_venta_actual = $_POST['precio_venta'] ?? ($producto['precio'] ?? 0);
$porcentaje_rebaja_actual = $_POST['porcentaje_rebaja'] ?? ($producto['porcentaje_rebaja'] ?? 0);
            ?>
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="moneda_adquisicion">💱 Moneda del Costo *</label>
                    <select id="moneda_adquisicion" name="moneda_adquisicion" required onchange="recalcularPrecio()">
                        <?php foreach ($monedas_disponibles as $moneda): ?>
                            <option value="<?php echo htmlspecialchars($moneda); ?>" <?php echo ($moneda === $moneda_actual) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($moneda); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="campo-opcional">Moneda en la que compraste el producto</small>
                </div>
                
                <div class="form-group">
    <label for="costo">💰 Precio Adquisición *</label>
    <input type="number" id="costo" name="costo" step="0.01" min="0" required
           value="<?php echo htmlspecialchars($costo_actual); ?>"
           onchange="recalcularPrecio()">
    <small class="campo-opcional">Costo en la moneda seleccionada</small>
</div>

<div class="form-group">
    <label for="precio_costo_mostrar">💵 Costo en USD (calculado)</label>
    <input type="number" id="precio_costo_mostrar" step="0.01" readonly
           value="<?php echo htmlspecialchars($precio_costo_actual); ?>"
           style="background: #f7fafc; cursor: not-allowed;">
    <small class="campo-opcional">Calculado según la tasa</small>
</div>

<div class="form-group">
    <label for="porcentaje_ganancia">📈 % Ganancia *</label>
    <input type="number" id="porcentaje_ganancia" name="porcentaje_ganancia" step="0.01" min="0" max="999" required
           value="<?php echo htmlspecialchars($porcentaje_ganancia_actual); ?>"
           onchange="recalcularPrecio()">
    <small class="campo-opcional">Porcentaje de ganancia sobre el costo</small>
</div>
                
                <div class="form-group">
                    <label for="precio_venta">💵 Precio de Venta (USD) *</label>
                    <input type="number" id="precio_venta" name="precio_venta" step="0.01" min="0" readonly
                           value="<?php echo htmlspecialchars($precio_venta_actual); ?>"
                           style="background: #f7fafc; cursor: not-allowed;">
                    <small class="campo-opcional">Calculado automáticamente</small>
                </div>
                
                <div class="form-group">
                    <label for="porcentaje_rebaja">🏷️ % Rebaja</label>
                    <input type="number" id="porcentaje_rebaja" name="porcentaje_rebaja" step="1" min="0" max="100" 
                           value="<?php echo htmlspecialchars($porcentaje_rebaja_actual); ?>"
                           onchange="recalcularPrecio()">
                    <small class="campo-opcional">0 = sin rebaja</small>
                </div>
            </div>
            
            <div class="info-rebaja" id="infoRebaja">
    <p style="margin: 0;">
        <strong>📊 Información:</strong><br>
        Tasa: <span id="tasa_mostrar">1.00 USD</span> |
        Costo en USD: <span id="costo_usd_mostrar">$0.00</span> |
        Precio venta sin rebaja: <span id="precio_sin_rebaja_mostrar">$0.00</span> |
        Precio final con rebaja: <span id="precio_final_mostrar">$0.00</span>
    </p>
</div>
            
            <div class="seccion-imagen">
                <h3>🖼️ Imagen del Producto</h3>
                
                <?php if ($accion == 'editar' && !empty($producto['imagen_url'])): ?>
                <div class="eliminar-imagen-container">
                    <label>
                        <input type="checkbox" name="eliminar_imagen" value="1"> 
                        <span>Eliminar imagen actual</span>
                    </label>
                    <small style="color: #856404; display: block; margin-top: 0.25rem;">Si marcas esta opción, la imagen se eliminará.</small>
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="imagen_archivo">📁 Subir imagen desde tu PC:</label>
                    <input type="file" id="imagen_archivo" name="imagen_archivo" accept="image/*" onchange="previewFile()">
                    <div class="campo-opcional">Máximo 2MB. Formatos: JPG, PNG, GIF, WEBP</div>
                </div>
                
                <div class="separador-o">— O —</div>
                
                <div class="form-group">
                    <label for="imagen_url">🌐 URL o ruta de la imagen:</label>
                    <input type="text" id="imagen_url" name="imagen_url" 
                           value="<?php 
                           if (!empty($_POST['imagen_url'])) {
                               echo htmlspecialchars($_POST['imagen_url']);
                           } elseif (!empty($producto['imagen_url']) && strpos($producto['imagen_url'], 'uploads/') !== 0) {
                               echo htmlspecialchars($producto['imagen_url']);
                           }
                           ?>" placeholder="https://ejemplo.com/imagen.jpg  o  /uploads/logo.png" onchange="previewURL()">
                    <small class="campo-opcional">Puedes usar una URL completa (https://...) o una ruta local que empiece con / (ej: /uploads/logo.png)</small>
                </div>
                
                <div style="text-align: center; margin-top: 1rem;">
                    <p><strong>Vista previa:</strong></p>
                    <img id="preview" class="preview-imagen <?php echo (!empty($producto['imagen_url']) || !empty($_POST['imagen_url'])) ? 'visible' : ''; ?>" 
                         style="max-width: 120px; max-height: 120px; object-fit: contain;"
                         src="<?php 
                             if (!empty($_POST['imagen_url'])) {
                                 echo htmlspecialchars($_POST['imagen_url']);
                             } elseif (!empty($producto['imagen_url'])) {
                                 echo htmlspecialchars($producto['imagen_url']);
                             }
                         ?>" 
                         alt="Vista previa" 
                         onerror="this.style.display='none'">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <?php echo $accion == 'crear' ? '✨ Crear Producto' : '💾 Actualizar Producto'; ?>
                </button>
                <a href="/admin/stock/productos.php" class="btn btn-secondary">↩️ Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
    const TASAS_MONEDAS = <?php echo json_encode(
    array_combine(
        $monedas_disponibles,
        array_map(function($m) use ($conn, $proveedor_para_monedas) {
            if ($m === 'USD') return 1.00;
            $tasa = getTasaProveedor($conn, $proveedor_para_monedas, $m);
            return ($tasa > 0) ? $tasa : 0;
        }, $monedas_disponibles)
    )
); ?>;

// ============================================
// RECARGAR MONEDAS Y TASAS AL CAMBIAR PROVEEDOR
// ============================================
async function recargarMonedasProveedor(proveedorId) {
    const selectMoneda = document.getElementById('moneda_adquisicion');
    if (!selectMoneda) return;
    
    try {
        const resp = await fetch(`/admin/stock/admin_ajax_productos.php?monedas_proveedor=${proveedorId || 0}`, {
            credentials: 'same-origin'
        });
        const data = await resp.json();
        
        if (!data.success) {
            console.error('Error al cargar monedas:', data.error);
            return;
        }
        
        const valorActual = selectMoneda.value;
        selectMoneda.innerHTML = '';
        data.monedas.forEach(mon => {
            const opt = document.createElement('option');
            opt.value = mon;
            opt.textContent = mon;
            selectMoneda.appendChild(opt);
        });
        
        if (data.monedas.includes(valorActual)) {
            selectMoneda.value = valorActual;
        } else {
            selectMoneda.value = 'USD';
        }
        
        // Actualizar tasas globales del formulario
        window.TASAS_MONEDAS = data.tasas;
        
        if (typeof recalcularPrecio === 'function') {
            recalcularPrecio();
        }
    } catch (error) {
        console.error('Error en recargarMonedasProveedor:', error);
    }
}
    
    function recalcularPrecio() {
    const moneda = document.getElementById('moneda_adquisicion').value;
    const costo = parseFloat(document.getElementById('costo').value) || 0;
    const porcentajeGanancia = parseFloat(document.getElementById('porcentaje_ganancia').value) || 0;
    const porcentajeRebaja = parseFloat(document.getElementById('porcentaje_rebaja').value) || 0;

    const tasa = (moneda === 'USD') ? 1 : (TASAS_MONEDAS[moneda] || 0);

    // Si no hay tasa para la moneda elegida, mostrar advertencia y no calcular
    if (moneda !== 'USD' && tasa <= 0) {
        document.getElementById('precio_costo_mostrar').value = '';
        document.getElementById('precio_venta').value = '';
        document.getElementById('tasa_mostrar').textContent = '⚠️ Sin tasa';
        document.getElementById('costo_usd_mostrar').textContent = '—';
        document.getElementById('precio_sin_rebaja_mostrar').textContent = '—';
        document.getElementById('precio_final_mostrar').textContent = '—';
        const btn = document.querySelector('button[type="submit"]');
        if (btn) { btn.disabled = true; btn.style.opacity = '0.5'; }
        return;
    }

    // Rehabilitar botón si estaba deshabilitado
    const btnSubmit = document.querySelector('button[type="submit"]');
    if (btnSubmit) { btnSubmit.disabled = false; btnSubmit.style.opacity = '1'; }

    const precioCostoUsd = (moneda === 'USD') ? costo : (costo / tasa);
    const precioVenta = precioCostoUsd * (1 + porcentajeGanancia / 100);

    let precioFinal = precioVenta;
    if (porcentajeRebaja > 0) {
        precioFinal = precioVenta * (100 - porcentajeRebaja) / 100;
    }

    document.getElementById('precio_costo_mostrar').value = precioCostoUsd.toFixed(2);
    document.getElementById('precio_venta').value = precioVenta.toFixed(2);
    document.getElementById('tasa_mostrar').textContent = tasa.toFixed(2) + ' ' + moneda;
    document.getElementById('costo_usd_mostrar').textContent = '$' + precioCostoUsd.toFixed(2);
    document.getElementById('precio_sin_rebaja_mostrar').textContent = '$' + precioVenta.toFixed(2);
    document.getElementById('precio_final_mostrar').textContent = '$' + precioFinal.toFixed(2);
}
    
    document.addEventListener('DOMContentLoaded', function() {
    <?php if ($es_super_admin): ?>
    const proveedorSel = document.getElementById('proveedor_id');
    if (proveedorSel && proveedorSel.value) {
        recargarMonedasProveedor(proveedorSel.value).then(() => {
            recalcularPrecio();
        });
    } else {
        recalcularPrecio();
    }
    <?php else: ?>
    recalcularPrecio();
    <?php endif; ?>
});
    
    function previewFile() {
        const preview = document.getElementById('preview');
        const file = document.getElementById('imagen_archivo').files[0];
        const reader = new FileReader();
        reader.onloadend = function() {
            preview.src = reader.result;
            preview.classList.add('visible');
        }
        if (file) reader.readAsDataURL(file);
    }
    
    function previewURL() {
        const preview = document.getElementById('preview');
        const url = document.getElementById('imagen_url').value;
        if (url) {
            preview.src = url;
            preview.classList.add('visible');
        }
    }
</script>

<?php
$ruta_footer = __DIR__ . '/../../footer.php';
if (file_exists($ruta_footer)) {
    require_once $ruta_footer;
} else {
    echo '</main></body></html>';
}

if (ob_get_level()) {
    ob_end_flush();
}
$conn->close();
?>
<?php
// ============================================
// admin_ajax_productos.php - Devuelve tabla y paginación de productos (vía AJAX)
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/csrf.php';

// ============================================
// ENDPOINT: monedas y tasas de un proveedor (solo Super Admin)
// GET ?monedas_proveedor=X
// ============================================
if (isset($_GET['monedas_proveedor'])) {
    ob_clean();
    header('Content-Type: application/json; charset=UTF-8');
    
    require_once __DIR__ . '/../../includes/moneda_funciones.php';
    
    if (!isset($_SESSION['usuario_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Sesión expirada']);
        exit;
    }
    
    $rol_json = trim($_SESSION['rol'] ?? '');
    if ($rol_json !== 'Super Admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Solo Super Admin']);
        exit;
    }
    
    $prov_json = intval($_GET['monedas_proveedor']);
    
    if ($prov_json <= 0) {
        echo json_encode([
            'success' => true,
            'monedas' => ['USD'],
            'tasas' => ['USD' => 1.00]
        ]);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1 LIMIT 1");
    $stmt->bind_param("i", $prov_json);
    $stmt->execute();
    $prov_ok = ($stmt->get_result()->num_rows > 0);
    $stmt->close();
    
    if (!$prov_ok) {
        echo json_encode(['success' => false, 'error' => 'Proveedor no válido']);
        exit;
    }
    
        $monedas_json = getMonedasParaAdquisicion($conn, $prov_json);

    $tasas_json = ['USD' => 1.00];
    foreach ($monedas_json as $mon_j) {
        if ($mon_j === 'USD') continue;
        $tasa_j = getTasaProveedor($conn, $prov_json, $mon_j);
        $tasas_json[$mon_j] = ($tasa_j > 0) ? $tasa_j : 0;
    }
    
    echo json_encode([
        'success' => true,
        'monedas' => $monedas_json,
        'tasas' => $tasas_json
    ]);
    exit;
}

// Inicializar variable para el filtro de proveedor
$proveedor_id_filtro = 0;

// Roles que pueden ENTRAR a productos.php
$rol_actual = $_SESSION['rol'] ?? '';
$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($rol_actual, $roles_ver)) {
    http_response_code(403);
    echo "Acceso denegado";
    exit;
}

// Roles que pueden GESTIONAR (crear, editar, activar/desactivar, importar)
$roles_gestionar = ['Super Admin', 'Gerente', 'Proveedor', 'Inventario'];
$puede_gestionar = in_array($rol_actual, $roles_gestionar);

// Roles que pueden ELIMINAR
$roles_eliminar = ['Super Admin', 'Gerente', 'Proveedor'];
$puede_eliminar = in_array($rol_actual, $roles_eliminar);

// 🔥 DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
$proveedor_id_filtro = obtenerProveedorId($conn, $_SESSION['usuario_id'], $rol_actual);
$es_rol_proveedor = esRolProveedor($rol_actual);

if ($es_rol_proveedor && $proveedor_id_filtro == 0) {
    echo "No tienes un proveedor asignado";
    exit;
}

if ($proveedor_id_filtro > 0) {
    // Forzar el filtro por proveedor
    $_GET['proveedor_id'] = $proveedor_id_filtro;
}

// ============================================
// FILTROS (exactamente igual que en admin.php)
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "p.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['precio_costo']) && isset($_GET['costo_operador'])) {
    $operador = $_GET['costo_operador'];
    if (in_array($operador, ['=', '<', '>'])) {
        $where[] = "p.precio_costo $operador ?";
        $params[] = $_GET['precio_costo'];
        $types .= "d";
    }
}

if (!empty($_GET['filtro_imagen'])) {
    if ($_GET['filtro_imagen'] == 'sin_imagen') {
        $where[] = "(p.imagen_url IS NULL OR p.imagen_url = '')";
    } elseif ($_GET['filtro_imagen'] == 'con_imagen') {
        $where[] = "(p.imagen_url IS NOT NULL AND p.imagen_url != '')";
    }
}

if (!empty($_GET['filtro_estado'])) {
    if ($_GET['filtro_estado'] == 'activos') {
        $where[] = "p.activo = 1";
    } elseif ($_GET['filtro_estado'] == 'inactivos') {
        $where[] = "p.activo = 0";
    }
}

if (!empty($_GET['filtro_rebaja'])) {
    if ($_GET['filtro_rebaja'] == 'con_rebaja') {
        $where[] = "p.porcentaje_rebaja > 0";
    } elseif ($_GET['filtro_rebaja'] == 'sin_rebaja') {
        $where[] = "(p.porcentaje_rebaja IS NULL OR p.porcentaje_rebaja = 0)";
    }
}

if (!empty($_GET['categoria_id'])) {
    $where[] = "p.categoria_id = ?";
    $params[] = $_GET['categoria_id'];
    $types .= "i";
}

if (!empty($_GET['proveedor_id'])) {
    $where[] = "p.proveedor_id = ?";
    $params[] = $_GET['proveedor_id'];
    $types .= "i";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ===== ORDENAMIENTO =====
$columnas_validas = [
    'nombre' => "p.nombre",
    'marca' => "p.marca",
    'categoria' => "c.nombre",
    'proveedor' => "pr.nombre_tienda",
    'cantidad' => "p.cantidad",
    'peso' => "p.peso",
    'precio_costo' => "p.precio_costo",
    'precio' => "p.precio",
    'fecha' => "p.fecha_creacion",
    'estado' => "p.activo",
    'rebaja' => "p.porcentaje_rebaja",
    'importe_costo' => "(p.precio_costo * p.cantidad)",
    'importe_venta' => "(p.precio * p.cantidad)"
];

$order_by = isset($_GET['order_by']) && array_key_exists($_GET['order_by'], $columnas_validas) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . $columnas_validas[$order_by] . " $order_dir";

// Contar total de registros
$count_sql = "SELECT COUNT(*) as total FROM productos p $sql_where";
$count_stmt = $conn->prepare($count_sql);
if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_registros = $count_result->fetch_assoc()['total'];

// ============================================
// PAGINACIÓN (usando valor de la tabla configuración)
// ============================================
// Obtener productos por página desde configuración
$result_config = $conn->query("SELECT valor FROM configuracion WHERE clave = 'productos_por_pagina'");
$row_config = $result_config->fetch_assoc();
$por_pagina = $row_config ? intval($row_config['valor']) : 30;

$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA PRINCIPAL
// ============================================
$sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono, pr.nombre_tienda
        FROM productos p 
        LEFT JOIN categorias c ON p.categoria_id = c.id 
        LEFT JOIN proveedores pr ON p.proveedor_id = pr.id
        $sql_where 
        $order_sql
        LIMIT ? OFFSET ?";

$params_limit = $params;
$params_limit[] = $por_pagina;
$params_limit[] = $offset;
$types_limit = $types . "ii";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types_limit, ...$params_limit);
$stmt->execute();
$productos = $stmt->get_result();

$total_costo = 0;
$total_venta = 0;
?>

<!-- ============================================ -->
<!-- TABLA DE PRODUCTOS (exactamente igual que en admin.php) -->
<!-- ============================================ -->
<div class="printable-area">
    <div class="encabezado-impresion" style="display: none;">
        <h1>LISTA DE PRODUCTOS</h1>
        <?php 
            $nombre_tienda = 'Catalejoo';
            if ($proveedor_id_filtro > 0) {
                $stmt_tienda = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                $stmt_tienda->bind_param("i", $proveedor_id_filtro);
                $stmt_tienda->execute();
                $result_tienda = $stmt_tienda->get_result();
                if ($row_tienda = $result_tienda->fetch_assoc()) {
                    $nombre_tienda = $row_tienda['nombre_tienda'];
                }
                $stmt_tienda->close();
            }
        ?>
        <p><strong>Tienda:</strong> <?php echo htmlspecialchars($nombre_tienda); ?></p>
        <p>Generado por: <?php echo htmlspecialchars($_SESSION['nombre'] ?? 'Usuario'); ?></p>
        <p>Fecha: <?php echo date('d/m/Y H:i:s'); ?></p>
        <p>Filtros: <?php echo htmlspecialchars(implode(' | ', array_filter([$_GET['nombre'] ?? '', $_GET['filtro_estado'] ?? '']))); ?></p>
    </div>

    <?php
// ============================================
// CONSTRUIR TEXTO DE FILTROS APLICADOS
// ============================================
$texto_filtros_temp = [];
if (!empty($_GET['nombre'])) $texto_filtros_temp[] = "Nombre: " . $_GET['nombre'];
if (!empty($_GET['precio_costo'])) $texto_filtros_temp[] = "Precio Costo: " . ($_GET['costo_operador'] ?? '=') . " $" . $_GET['precio_costo'];
if (!empty($_GET['filtro_imagen'])) {
    $texto_imagen = $_GET['filtro_imagen'] == 'sin_imagen' ? 'Sin imagen' : 'Con imagen';
    $texto_filtros_temp[] = "Imagen: " . $texto_imagen;
}
if (!empty($_GET['filtro_estado'])) {
    $texto_estado = $_GET['filtro_estado'] == 'activos' ? 'Activos' : 'Inactivos';
    $texto_filtros_temp[] = "Estado: " . $texto_estado;
}
if (!empty($_GET['filtro_rebaja'])) {
    $texto_rebaja = $_GET['filtro_rebaja'] == 'con_rebaja' ? 'Con rebaja' : 'Sin rebaja';
    $texto_filtros_temp[] = "Rebaja: " . $texto_rebaja;
}
if (!empty($_GET['categoria_id'])) {
    $cat_id = intval($_GET['categoria_id']);
    $stmt_cat = $conn->prepare("SELECT nombre FROM categorias WHERE id = ?");
    $stmt_cat->bind_param("i", $cat_id);
    $stmt_cat->execute();
    $cat_data = $stmt_cat->get_result()->fetch_assoc();
    $stmt_cat->close();
    $cat_nombre = $cat_data ? $cat_data['nombre'] : 'Categoría';
    $texto_filtros_temp[] = "Categoría: " . $cat_nombre;
}
$texto_filtros = !empty($texto_filtros_temp) ? implode(', ', $texto_filtros_temp) : 'todos';
?>
    
    <div class="productos-table-card">
        <div class="table-header">
           <h3>📋 Lista de Productos <span style="font-size: 0.8rem; color: #718096; font-weight: normal;">(<?php echo $total_registros; ?> <?php echo $texto_filtros; ?>)</span></h3>
            <div class="table-header-right">
                <?php if ($puede_gestionar): ?>
		<a href="/admin/masivos/edicion_masiva.php" class="btn-primary btn">📊 Edición Masiva</a>
                <a href="productos_acciones.php?accion=crear" class="btn-primary btn">➕ Nuevo Producto</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="table-wrapper">
            <div class="table-responsive" id="tableContainer">
                <table class="tabla-moderna" id="tablaProductos">
                   <thead>
    <tr>
        <th>ID</th>
        <th class="checkbox-col">
            <input type="checkbox" class="select-all-checkbox" id="selectAll" title="Seleccionar todos">
        </th>
        <th class="no-print">Imagen</th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'nombre', 'order_dir' => ($order_by == 'nombre' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Nombre<?php if ($order_by == 'nombre'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'proveedor', 'order_dir' => ($order_by == 'proveedor' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Proveedor<?php if ($order_by == 'proveedor'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'cantidad', 'order_dir' => ($order_by == 'cantidad' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Cantid<?php if ($order_by == 'cantidad'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'peso', 'order_dir' => ($order_by == 'peso' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Peso (kg)<?php if ($order_by == 'peso'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'precio_costo', 'order_dir' => ($order_by == 'precio_costo' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Costo<?php if ($order_by == 'precio_costo'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'precio', 'order_dir' => ($order_by == 'precio' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Venta<?php if ($order_by == 'precio'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'rebaja', 'order_dir' => ($order_by == 'rebaja' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Rebaja<?php if ($order_by == 'rebaja'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'fecha', 'order_dir' => ($order_by == 'fecha' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" class="ajax-link">Fecha<?php if ($order_by == 'fecha'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
        <th class="no-print">Acciones</th>
    </thead>
                    <tbody>
                        <?php if ($productos->num_rows > 0): ?>
                            <?php while($p = $productos->fetch_assoc()): 
                                $importe_costo = $p['precio_costo'] * $p['cantidad'];
                                $importe_venta = $p['precio'] * $p['cantidad'];
                                $tiene_rebaja = $p['porcentaje_rebaja'] > 0;
                            ?>
                            <tr style="<?php echo $p['activo'] ? '' : 'opacity: 0.7; background: #fff5f5;'; ?>">
                                <td>#<?php echo $p['id']; ?></td>
                                <td class="checkbox-col text-center">
                                    <input type="checkbox" class="checkbox-producto" value="<?php echo $p['id']; ?>" data-id="<?php echo $p['id']; ?>">
                                </td>
                                <td class="no-print">
                                    <?php if (!empty($p['imagen_url'])): ?>
                                        <img src="<?php echo htmlspecialchars($p['imagen_url']); ?>" alt="<?php echo htmlspecialchars($p['nombre']); ?>" class="img-thumbnail">
                                    <?php else: ?>
                                        <div class="sin-imagen" title="Sin imagen">❌</div>
                                    <?php endif; ?>
                                </td>
                              <td>
    <strong><?php echo htmlspecialchars($p['nombre']); ?></strong><br>
    <span style="font-size: 0.7rem; color: #718096;">
        <?php if (!empty($p['categoria_nombre'])): ?>
            <?php echo $p['categoria_icono'] ?? '📦'; ?> <?php echo htmlspecialchars($p['categoria_nombre']); ?>
        <?php else: ?>
            📦 Sin categoría
        <?php endif; ?>
    </span>
</td>
                                <td>
    <?php if (!empty($p['nombre_tienda'])): ?>
        <?php echo htmlspecialchars($p['nombre_tienda']); ?>
    <?php else: ?>
        <span style="color: #9ca3af;">—</span>
    <?php endif; ?>
</td>
                                <td class="text-center">
                                    <span class="badge-cantidad <?php echo $p['cantidad'] == 0 ? 'sin-stock' : ($p['cantidad'] < 5 ? 'bajo-stock' : ''); ?>"><?php echo $p['cantidad']; ?></span>
                                </td>
                                <td class="text-right"><?php echo number_format($p['peso'] ?? 0, 3); ?></td>
   <td class="text-right">
    <strong>P-: $<?php echo number_format($p['precio_costo'], 2); ?></strong><br>
    <span style="font-size: 0.7rem; color: #718096;">Imp: $<?php echo number_format($importe_costo, 2); ?></span>
</td>
                                <td class="text-right">
    <?php if ($tiene_rebaja): ?>
        <span style="text-decoration: line-through; color: #9ca3af; font-size: 0.7rem;">P: $<?php echo number_format($p['precio_original'] ?? $p['precio'], 2); ?></span><br>
        <span style="color: #10b981; font-weight: bold;">P: $<?php echo number_format($p['precio'], 2); ?></span>
        <br>
        <span style="font-size: 0.7rem; color: #718096;">I: $<?php echo number_format($importe_venta, 2); ?></span>
    <?php else: ?>
        <strong>P: $<?php echo number_format($p['precio'], 2); ?></strong><br>
        <span style="font-size: 0.7rem; color: #718096;">Imp: $<?php echo number_format($importe_venta, 2); ?></span>
    <?php endif; ?>
</td>
<td class="text-center">
    <?php if ($tiene_rebaja): ?>
        <span class="badge-rebaja">-<?php echo $p['porcentaje_rebaja']; ?>%</span>
    <?php else: ?>
        <span style="color: #9ca3af;">—</span>
    <?php endif; ?>
</td>
<td>
    <?php echo date('d/m/Y', strtotime($p['fecha_creacion'])); ?><br>
    <span class="badge-estado <?php echo $p['activo'] ? 'badge-activo' : 'badge-inactivo'; ?>">
        <?php echo $p['activo'] ? '✅ Activo' : '❌ Inactivo'; ?>
    </span>
</td>
                               <td class="no-print acciones" style="text-align: right;">
    <a href="/admin/stock/ver_producto.php?id=<?php echo $p['id']; ?>" class="btn-icono" title="Ver detalles">👁️</a>
    <a href="/admin/stock/historial_producto.php?id=<?php echo $p['id']; ?>" class="btn-icono" title="Historial">📋</a>
    <?php if ($puede_gestionar): ?>
    <button type="button"
        class="btn-icono ajax-toggle-estado"
        data-id="<?php echo intval($p['id']); ?>"
        data-estado="<?php echo intval($p['activo']); ?>"
        title="<?php echo $p['activo'] ? 'Desactivar' : 'Activar'; ?>"
        style="border:none; background:none; cursor:pointer;">
    <?php echo $p['activo'] ? '🔴' : '🟢'; ?>
</button>
        <button type="button" class="btn-icono btn-editar-producto" 
    data-id="<?php echo $p['id']; ?>"
    data-nombre='<?php echo htmlspecialchars($p['nombre'], ENT_QUOTES); ?>'
    data-marca='<?php echo htmlspecialchars($p['marca'] ?? '', ENT_QUOTES); ?>'
    data-descripcion='<?php echo htmlspecialchars($p['descripcion'] ?? '', ENT_QUOTES); ?>'
    data-precio_costo="<?php echo $p['precio_costo']; ?>"
    data-precio="<?php echo $p['precio']; ?>"
    data-precio_original="<?php echo $p['precio_original'] ?? 0; ?>"
    data-porcentaje_rebaja="<?php echo $p['porcentaje_rebaja'] ?? 0; ?>"
    data-cantidad="<?php echo $p['cantidad']; ?>"
    data-peso="<?php echo $p['peso']; ?>"
    data-categoria_id="<?php echo $p['categoria_id']; ?>"
    data-proveedor_id="<?php echo $p['proveedor_id']; ?>"
    data-imagen_url='<?php echo htmlspecialchars($p['imagen_url'] ?? '', ENT_QUOTES); ?>'
    data-precio_adquisicion="<?php echo $p['precio_adquisicion'] ?? 0; ?>"
    data-moneda_adquisicion="<?php echo htmlspecialchars($p['moneda_adquisicion'] ?? 'USD'); ?>"
    data-porcentaje_ganancia="<?php echo $p['porcentaje_ganancia'] ?? 0; ?>"
    title="Editar producto">✏️</button>
        <?php if ($puede_eliminar): ?>
    <a href="#" class="btn-icono" onclick="eliminarProductoIndividual(<?php echo $p['id']; ?>, '<?php echo addslashes($p['nombre']); ?>'); return false;">🗑️</a>
<?php endif; ?>
    <?php endif; ?>
</td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="16" class="text-center sin-datos">📭 No se encontraron productos con los filtros seleccionados</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ============================================ -->
    <!-- PAGINACIÓN (usando tu archivo original) -->
    <!-- ============================================ -->
    <?php
// Construir URL base con todos los parámetros actuales excepto 'pagina'
$parametros_url = $_GET;
unset($parametros_url['pagina']);
$base_url = '?' . http_build_query($parametros_url);
if (!empty($parametros_url)) {
    $base_url .= '&';
}
include __DIR__ . '/../../includes/paginacion_botones.php';
?>
</div>

<div class="pie-impresion" style="display: none;">
    <p>Generado por: <?php echo htmlspecialchars($_SESSION['nombre'] ?? 'Usuario'); ?> | Fecha: <?php echo date('d/m/Y H:i:s'); ?></p>
</div>

<form method="POST" id="formAccionMasiva" style="display: none;">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="accion_masiva" id="accion_masiva" value="">
    <input type="hidden" name="productos" id="productos_seleccionados" value="">
    <?php foreach($_GET as $key => $value): ?>
        <?php if ($key === 'csrf_token') continue; ?>
        <input type="hidden" name="<?php echo htmlspecialchars($key); ?>" value="<?php echo htmlspecialchars($value); ?>">
    <?php endforeach; ?>
</form>

<?php
$stmt->close();
$conn->close();
?>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

// ============================================
// VERIFICACIÓN DE PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor', 'Inventario'];
$puede_ver = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_ver) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

// Validar que el proveedor existe y está activo
if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// PERMISOS DE GESTIÓN (crear, editar, eliminar)
// ============================================
$roles_gestion = ['Super Admin', 'Gerente', 'Proveedor', 'Vendedor', 'Inventario'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_gestion);

// ============================================
// FILTRO DE PROVEEDOR PARA EL SELECT
// ============================================
$filtro_proveedor_js = '';
if ($proveedor_id_usuario > 0) {
    $filtro_proveedor_js = 'document.getElementById("filtro_proveedor").value = ' . $proveedor_id_usuario . ';';
    $filtro_proveedor_js .= 'document.getElementById("filtro_proveedor").disabled = true;';
}
?>

<style>
:root {
    --primary: <?php echo $color_primario; ?>;
    --secondary: <?php echo $color_secundario; ?>;
}

.combos-container {
    padding: 1rem 0;
}

.btn-nuevo-combo {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.9rem;
    font-weight: 600;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-nuevo-combo:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102,126,234,0.3);
}

.filtros-card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.acciones-superiores {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
    justify-content: flex-end;
    flex-wrap: wrap;
}

.btn-accion-superior {
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.2s;
    border: none;
    color: white;
}

.btn-imprimir { background: #4299e1; }
.btn-excel { background: #48bb78; }

.floating-actions-btn {
    position: fixed;
    top: 20px;
    left: 20px;
    z-index: 1001;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    width: 45px;
    height: 45px;
    border-radius: 50%;
    display: none;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    border: 2px solid white;
}

@media (max-width: 768px) {
    .acciones-superiores { display: none; }
    .floating-actions-btn { display: flex; }
}

.actions-floating-menu {
    position: fixed;
    top: 75px;
    left: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    z-index: 1000;
    min-width: 200px;
    overflow: hidden;
    display: none;
}

.actions-floating-menu.show { display: block; }

.actions-floating-menu a, .actions-floating-menu button {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    padding: 12px 16px;
    border: none;
    background: white;
    text-decoration: none;
    color: #2d3748;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.2s;
}

.actions-floating-menu a:hover, .actions-floating-menu button:hover {
    background: #f7fafc;
    color: var(--primary);
}

/* Contador flotante */
.floating-counter {
    position: fixed;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    z-index: 1000;
    transition: all 0.3s ease;
    border: 2px solid white;
    display: none;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.floating-counter:hover {
    transform: scale(1.05);
}

.floating-counter.show {
    display: flex;
}

@media (min-width: 769px) {
    .floating-counter {
        bottom: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 50px;
        font-size: 1rem;
        min-width: auto;
    }
}

@media (max-width: 768px) {
    .floating-counter {
        top: 70px;
        left: 20px;
        width: 45px;
        height: 45px;
        border-radius: 50%;
        font-size: 1.1rem;
        padding: 0;
    }
}

.floating-actions-menu-pc {
    position: fixed;
    background: white;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    z-index: 1000;
    min-width: 200px;
    overflow: hidden;
    display: none;
    border: 1px solid #e2e8f0;
}

.floating-actions-menu-pc.show {
    display: block;
    animation: fadeInUp 0.2s ease;
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.floating-actions-menu-pc button {
    display: flex;
    align-items: center;
    gap: 12px;
    width: 100%;
    padding: 12px 16px;
    border: none;
    background: white;
    color: #2d3748;
    font-size: 0.9rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    text-align: left;
}

.floating-actions-menu-pc button:hover {
    background: #f7fafc;
}

.floating-actions-menu-pc hr {
    margin: 0;
    border-top: 1px solid #e2e8f0;
}

@media (min-width: 769px) {
    .floating-actions-menu-pc {
        bottom: 90px;
        right: 20px;
    }
}

@media (max-width: 768px) {
    .floating-actions-menu-pc {
        top: 125px;
        left: 20px;
    }
}
    
    /* ============================================ */
/* ESTILOS PARA LA TABLA DE COMBOS */
/* ============================================ */
.productos-table-card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    width: 100%;
    margin-top: 1rem;
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.table-header h3 {
    font-size: 1.1rem;
    color: #4a5568;
    margin: 0;
}

.table-header-right {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    width: 100%;
    scroll-behavior: smooth;
}

.tabla-moderna {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    min-width: 800px;
}

.tabla-moderna th {
    text-align: left;
    padding: 0.7rem 0.5rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    font-weight: 600;
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    border-bottom: 2px solid #e2e8f0;
    white-space: nowrap;
}

.tabla-moderna th a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 4px;
}

.tabla-moderna td {
    padding: 0.7rem 0.5rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: middle;
    white-space: nowrap;
}

.checkbox-col {
    width: 40px;
    text-align: center;
}

.checkbox-combo, .select-all-checkbox {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: var(--primary);
}

.btn-icono {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 0;
    margin: 0;
    text-decoration: none;
    border-radius: 6px;
    transition: all 0.2s;
    font-size: 0.85rem;
}

.btn-icono:hover {
    background: #edf2f7;
    transform: scale(1.1);
}

.badge-estado {
    display: inline-block;
    padding: 0.2rem 0.6rem;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
    text-align: center;
    white-space: nowrap;
}

.badge-activo {
    background: #f0fff4;
    color: #22543d;
    border: 1px solid #9ae6b4;
}

.badge-inactivo {
    background: #fff5f5;
    color: #742a2a;
    border: 1px solid #feb2b2;
}

.badge-rebaja {
    background: #ef4444;
    color: white;
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
    display: inline-block;
}

.text-right {
    text-align: right;
}

.text-center {
    text-align: center;
}

.img-thumbnail {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
}

.sin-imagen {
    width: 45px;
    height: 45px;
    background: #f7fafc;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #a0aec0;
    font-size: 1.2rem;
    border: 1px solid #e2e8f0;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 600;
    transition: all 0.2s;
    display: inline-block;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102,126,234,0.3);
}

.no-print {
    /* para impresión */
}

@media print {
    .no-print {
        display: none !important;
    }
}
    
    @media (max-width: 768px) {
    .floating-actions-btn {
        display: none !important;
    }
}
</style>

<main class="main-content">
    <div class="combos-container">
        <div class="acciones-superiores">
            <button class="btn-accion-superior btn-imprimir" onclick="window.print()">🖨️ Imprimir</button>
            <button class="btn-accion-superior btn-excel" onclick="exportarExcel()">📊 Exportar Excel</button>
            <?php if ($puede_gestionar): ?>
            <a href="combos_editar.php" class="btn-nuevo-combo">➕ Nuevo Combo</a>
            <?php endif; ?>
        </div>

        <div class="floating-actions-btn" onclick="toggleActionsMenu()">☰</div>
        <div class="actions-floating-menu" id="actionsMenu">
            <button onclick="window.print()">🖨️ Imprimir</button>
            <button onclick="exportarExcel()">📊 Exportar Excel</button>
            <?php if ($puede_gestionar): ?>
            <a href="combos_editar.php">➕ Nuevo Combo</a>
            <?php endif; ?>
        </div>

        <div class="filtros-card">
            <h3 style="margin-bottom: 1rem; font-size: 1rem; color: #4a5568;">🎁 Filtrar Combos</h3>
            <div style="display: flex; gap: 0.8rem; align-items: flex-end; flex-wrap: wrap;">
                <div style="flex: 2; min-width: 180px;">
                    <label style="display: block; font-size: 0.7rem; font-weight: 600; margin-bottom: 0.2rem;">📝 Nombre</label>
                    <input type="text" id="filtro_nombre" placeholder="Buscar combo..." style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
                </div>
                <div style="flex: 1; min-width: 100px;">
                    <label style="display: block; font-size: 0.7rem; font-weight: 600; margin-bottom: 0.2rem;">⚡ Estado</label>
                    <select id="filtro_estado" style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
                        <option value="">Todos</option>
                        <option value="activos">Activos</option>
                        <option value="inactivos">Inactivos</option>
                    </select>
                </div>

<div style="flex: 1; min-width: 140px;">
    <label style="display: block; font-size: 0.7rem; font-weight: 600; margin-bottom: 0.2rem;">🏪 Proveedor</label>
    <select id="filtro_proveedor" style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
    <option value="">Todos</option>
    <?php
    // 🔥 FILTRAR PROVEEDORES VISIBLES SEGÚN ROL
    if ($proveedor_id_usuario > 0) {
        // Usuario de tienda: solo ver su proveedor
        $sql_proveedores = "SELECT id, nombre_tienda FROM proveedores WHERE id = $proveedor_id_usuario AND activo = 1";
    } else {
        // Administrador: ver todos los proveedores
        $sql_proveedores = "SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda";
    }
    $proveedores_filtro = $conn->query($sql_proveedores);
    while($prov = $proveedores_filtro->fetch_assoc()):
    ?>
        <option value="<?php echo $prov['id']; ?>">🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?></option>
    <?php endwhile; ?>
</select>
</div>

                <div style="display: flex; gap: 0.5rem;">
                    <button id="btnFiltrar" style="padding: 0.5rem 1rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">Filtrar</button>
                    <button id="btnLimpiar" style="padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">Limpiar</button>
                </div>
            </div>
        </div>

        <div id="tabla-combos-container">
            <div style="text-align: center; padding: 2rem;">🔄 Cargando combos...</div>
        </div>
    </div>
</main>

<!-- Contador flotante -->
<div id="floatingCounter" class="floating-counter">0</div>

<!-- 🔥 PROVEEDOR ID OCULTO PARA JAVASCRIPT -->
<input type="hidden" id="proveedor_id_usuario" value="<?php echo $proveedor_id_usuario; ?>">

<!-- Menú flotante de acciones -->
<div id="floatingActionsMenuPC" class="floating-actions-menu-pc">
    <button id="btnActivarMasivo">🟢 Activar seleccionados</button>
    <button id="btnDesactivarMasivo">🔴 Desactivar seleccionados</button>
    <?php if ($_SESSION['rol_nivel'] >= 2): ?>
    <hr>
    <button id="btnEliminarMasivo">🗑️ Eliminar seleccionados</button>
    <?php endif; ?>
    <hr>
    <button id="btnLimpiarSeleccion">✖ Limpiar selección</button>
</div>

<form method="POST" id="formAccionMasiva" action="combos_acciones.php?accion=masiva" style="display: none;">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="hidden" name="accion_masiva" id="accion_masiva" value="">
    <input type="hidden" name="combos" id="combos_seleccionados" value="">
</form>

<script>
// Variables globales
let seleccionados = new Set();

function toggleActionsMenu() {
    document.getElementById('actionsMenu').classList.toggle('show');
}

document.addEventListener('click', function(event) {
    const menu = document.getElementById('actionsMenu');
    const btn = document.querySelector('.floating-actions-btn');
    if (btn && !btn.contains(event.target) && !menu.contains(event.target)) {
        menu.classList.remove('show');
    }
});

function exportarExcel() {
    const params = new URLSearchParams();
    const nombre = document.getElementById('filtro_nombre')?.value;
    const estado = document.getElementById('filtro_estado')?.value;
    const proveedor_id = document.getElementById('filtro_proveedor')?.value;
    if (nombre) params.append('nombre', nombre);
    if (estado) params.append('estado', estado);
    if (proveedor_id) params.append('proveedor_id', proveedor_id);
    window.location.href = 'combos_exportar_excel.php?' + params.toString();
}

// ============================================
// FUNCIÓN PRINCIPAL PARA CARGAR COMBOS
// ============================================
function cargarCombos() {
    const url = '/admin/stock/combos_ajax.php?proveedor_id=<?php echo $proveedor_id_usuario; ?>&_=' + Date.now();
    
    console.log('🔍 URL:', url);
    
    const contenedor = document.getElementById('tabla-combos-container');
    contenedor.innerHTML = '<div style="text-align: center; padding: 2rem;">🔄 Cargando combos...</div>';
    
    fetch(url, { 
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        credentials: 'same-origin'
    })
    .then(response => response.text())
    .then(html => {
        contenedor.innerHTML = html;
        reinicializarEventos();
        cargarSeleccion();
    })
    .catch(error => {
        console.error('Error:', error);
        contenedor.innerHTML = '<div style="text-align: center; padding: 2rem;">❌ Error al cargar combos</div>';
    });
}

function reinicializarEventos() {
    document.querySelectorAll('.ajax-toggle-estado').forEach(btn => {
        btn.removeEventListener('click', handleToggleEstado);
        btn.addEventListener('click', handleToggleEstado);
    });
    
    document.querySelectorAll('.checkbox-combo').forEach(cb => {
        cb.removeEventListener('change', handleCheckboxChange);
        cb.addEventListener('change', handleCheckboxChange);
    });
    
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.removeEventListener('change', handleSelectAll);
        selectAll.addEventListener('change', handleSelectAll);
    }
    
    document.querySelectorAll('.ordenar-link').forEach(link => {
        link.removeEventListener('click', handleOrdenar);
        link.addEventListener('click', handleOrdenar);
    });
}

function handleToggleEstado(e) {
    e.preventDefault();
    const btn = e.currentTarget;
    const comboId = btn.getAttribute('data-id');
    const estadoActual = btn.getAttribute('data-estado');
    
    if (confirm(`¿${estadoActual == '1' ? 'Desactivar' : 'Activar'} este combo?`)) {
        fetch(`combos_acciones.php?accion=toggle_estado&id=${comboId}&estado=${estadoActual}`, {
            method: 'GET',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(() => {
            cargarCombos();
        })
        .catch(error => console.error('Error:', error));
    }
}

function handleCheckboxChange(e) {
    const id = parseInt(e.target.value);
    if (e.target.checked) {
        seleccionados.add(id);
    } else {
        seleccionados.delete(id);
    }
    actualizarTodo();
    guardarSeleccion();
}

function handleSelectAll(e) {
    document.querySelectorAll('.checkbox-combo').forEach(cb => {
        cb.checked = e.target.checked;
        const id = parseInt(cb.value);
        if (e.target.checked) {
            seleccionados.add(id);
        } else {
            seleccionados.delete(id);
        }
    });
    actualizarTodo();
    guardarSeleccion();
}

function handleOrdenar(e) {
    e.preventDefault();
    const orderBy = e.currentTarget.getAttribute('data-order');
    const params = new URLSearchParams(window.location.search);
    const currentOrder = params.get('order_by');
    const currentDir = params.get('order_dir');
    let newDir = 'ASC';
    if (currentOrder === orderBy && currentDir === 'ASC') {
        newDir = 'DESC';
    }
    params.set('order_by', orderBy);
    params.set('order_dir', newDir);
    cargarCombosConParams(params);
}

function cargarCombosConParams(params) {
    const url = '/admin/stock/combos_ajax.php?' + params.toString() + '&_=' + Date.now();
    
    console.log('🔍 URL:', url);
    
    const contenedor = document.getElementById('tabla-combos-container');
    contenedor.innerHTML = '<div style="text-align: center; padding: 2rem;">🔄 Cargando combos...</div>';
    
    fetch(url, { 
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        credentials: 'same-origin'
    })
    .then(response => response.text())
    .then(html => {
        contenedor.innerHTML = html;
        reinicializarEventos();
        cargarSeleccion();
    })
    .catch(error => {
        console.error('Error:', error);
        contenedor.innerHTML = '<div style="text-align: center; padding: 2rem;">❌ Error al cargar combos</div>';
    });
}

// ============================================
// SELECCIÓN MÚLTIPLE
// ============================================
function guardarSeleccion() {
    sessionStorage.setItem('combosSeleccionados', JSON.stringify([...seleccionados]));
}

function cargarSeleccion() {
    const guardados = sessionStorage.getItem('combosSeleccionados');
    if (guardados) {
        seleccionados = new Set(JSON.parse(guardados));
        actualizarTodo();
    }
}

function actualizarCheckboxes() {
    document.querySelectorAll('.checkbox-combo').forEach(cb => {
        cb.checked = seleccionados.has(parseInt(cb.value));
    });
    const total = document.querySelectorAll('.checkbox-combo').length;
    const seleccionadosEnPagina = document.querySelectorAll('.checkbox-combo:checked').length;
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.checked = total > 0 && seleccionadosEnPagina === total;
        selectAll.indeterminate = seleccionadosEnPagina > 0 && seleccionadosEnPagina < total;
    }
}

function actualizarContador() {
    const count = seleccionados.size;
    const floatingCounter = document.getElementById('floatingCounter');
    if (floatingCounter) {
        if (count > 0) {
            if (window.innerWidth > 768) {
                floatingCounter.textContent = count + (count === 1 ? ' seleccionado' : ' seleccionados');
            } else {
                floatingCounter.textContent = count;
            }
            floatingCounter.classList.add('show');
        } else {
            floatingCounter.classList.remove('show');
        }
    }
}

function actualizarTodo() {
    actualizarCheckboxes();
    actualizarContador();
}

function ejecutarAccionMasiva(accion) {
    const ids = [...seleccionados];
    if (ids.length === 0) {
        mostrarNotificacion('❌ No hay combos seleccionados', 'error');
        return;
    }
    
    let mensaje = '';
    if (accion === 'activar') mensaje = `¿Activar ${ids.length} combo(s)?`;
    else if (accion === 'desactivar') mensaje = `¿Desactivar ${ids.length} combo(s)?`;
    else if (accion === 'eliminar') mensaje = `⚠️ ¿Eliminar ${ids.length} combo(s)? Esta acción no se puede deshacer.`;
    
    if (confirm(mensaje)) {
        document.getElementById('accion_masiva').value = accion;
        document.getElementById('combos_seleccionados').value = JSON.stringify(ids);
        document.getElementById('formAccionMasiva').submit();
    }
}

function limpiarSeleccion() {
    seleccionados.clear();
    actualizarTodo();
    guardarSeleccion();
    document.getElementById('floatingActionsMenuPC')?.classList.remove('show');
}

function mostrarNotificacion(mensaje, tipo) {
    alert(mensaje);
}

// ============================================
// EVENTOS
// ============================================
document.getElementById('btnFiltrar')?.addEventListener('click', cargarCombos);
document.getElementById('btnLimpiar')?.addEventListener('click', function() {
    document.getElementById('filtro_nombre').value = '';
    document.getElementById('filtro_estado').value = '';
    document.getElementById('filtro_proveedor').value = '';
    cargarCombos();
});
document.getElementById('filtro_nombre')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') cargarCombos();
});
document.getElementById('filtro_estado')?.addEventListener('change', cargarCombos);

document.getElementById('btnActivarMasivo')?.addEventListener('click', () => ejecutarAccionMasiva('activar'));
document.getElementById('btnDesactivarMasivo')?.addEventListener('click', () => ejecutarAccionMasiva('desactivar'));
document.getElementById('btnEliminarMasivo')?.addEventListener('click', () => ejecutarAccionMasiva('eliminar'));
document.getElementById('btnLimpiarSeleccion')?.addEventListener('click', limpiarSeleccion);

document.getElementById('floatingCounter')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('floatingActionsMenuPC')?.classList.toggle('show');
});

document.addEventListener('click', (e) => {
    if (!e.target.closest('#floatingCounter') && !e.target.closest('#floatingActionsMenuPC')) {
        document.getElementById('floatingActionsMenuPC')?.classList.remove('show');
    }
});

// ============================================
// INICIALIZAR
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    cargarCombos();
    cargarSeleccion();
});
</script>

<?php
$conn->close();
include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';
?>
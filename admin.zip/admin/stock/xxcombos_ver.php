<?php
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    header('Location: combos.php');
    exit;
}

// Obtener datos del combo con proveedor y cálculos
$stmt = $conn->prepare("SELECT c.*, pr.nombre_tienda,
                               (SELECT COUNT(*) FROM combo_productos WHERE combo_id = c.id) as productos_distintos,
                               (SELECT SUM(cantidad) FROM combo_productos WHERE combo_id = c.id) as unidades_totales
                        FROM combos c 
                        LEFT JOIN proveedores pr ON c.proveedor_id = pr.id 
                        WHERE c.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$combo = $stmt->get_result()->fetch_assoc();

if (!$combo) {
    header('Location: combos.php?error=no_encontrado');
    exit;
}

// Obtener productos del combo
$stmt_prod = $conn->prepare("
    SELECT cp.*, p.nombre, p.imagen_url, p.precio 
    FROM combo_productos cp 
    JOIN productos p ON cp.producto_id = p.id 
    WHERE cp.combo_id = ?
");
$stmt_prod->bind_param("i", $id);
$stmt_prod->execute();
$productos = $stmt_prod->get_result();

// Obtener configuración de moneda
$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion WHERE clave IN ('moneda_simbolo', 'moneda_codigo')");
while($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}
$moneda_simbolo = $config['moneda_simbolo'] ?? '$';
$moneda_codigo = $config['moneda_codigo'] ?? 'USD';
?>

<style>
:root {
    --primary: <?php echo $color_primario; ?>;
    --secondary: <?php echo $color_secundario; ?>;
}

.combo-detalle {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    margin-top: 1rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.combo-header {
    display: flex;
    gap: 2rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}

.combo-imagen {
    flex: 0 0 200px;
    text-align: center;
}

.combo-imagen img {
    max-width: 100%;
    max-height: 200px;
    border-radius: 12px;
    object-fit: contain;
}

.combo-info {
    flex: 1;
}

.combo-nombre {
    font-size: 1.8rem;
    margin-bottom: 0.5rem;
    color: #2d3748;
}

.combo-descripcion {
    color: #718096;
    line-height: 1.6;
    margin-bottom: 1rem;
}

.combo-stats {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    margin-bottom: 1rem;
}

.combo-stat {
    background: #f7fafc;
    padding: 0.5rem 1rem;
    border-radius: 8px;
}

.combo-precio {
    margin-bottom: 1rem;
}

.precio-original {
    text-decoration: line-through;
    color: #ef4444;
    margin-right: 0.5rem;
}

.precio-final {
    font-size: 1.5rem;
    font-weight: 700;
    color: #10b981;
}

.precio-normal {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--primary);
}

.badge-estado {
    display: inline-block;
    padding: 0.2rem 0.6rem;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
}

.badge-activo {
    background: #f0fff4;
    color: #22543d;
    border: 1px solid #9ae6b4;
}

.badge-inactivo {
    background: #fff5f5;
    color: #742a2a;
    border: 1px solid #feb2b2;
}

.productos-tabla {
    margin-top: 2rem;
}

.productos-tabla table {
    width: 100%;
    border-collapse: collapse;
}

.productos-tabla th {
    text-align: left;
    padding: 0.75rem;
    background: #f7fafc;
    font-weight: 600;
}

.productos-tabla td {
    padding: 0.75rem;
    border-bottom: 1px solid #edf2f7;
}

.btn-volver {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.btn-volver:hover {
    background: #e2e8f0;
}
</style>

<main class="main-content">
    <a href="combos.php" class="btn-volver">← Volver a la lista</a>
    
    <div class="combo-detalle">
        <div class="combo-header">
            <div class="combo-imagen">
                <?php if (!empty($combo['imagen_url'])): ?>
                    <img src="<?php echo htmlspecialchars($combo['imagen_url']); ?>" alt="<?php echo htmlspecialchars($combo['nombre']); ?>">
                <?php else: ?>
                    <div style="width: 200px; height: 200px; background: #f7fafc; display: flex; align-items: center; justify-content: center; border-radius: 12px; font-size: 3rem;">🎁</div>
                <?php endif; ?>
            </div>
           <div class="combo-info">
    <h1 class="combo-nombre"><?php echo htmlspecialchars($combo['nombre']); ?></h1>
    <div class="combo-descripcion"><?php echo nl2br(htmlspecialchars($combo['descripcion'] ?? '')); ?></div>
    
    <div style="margin-bottom: 0.5rem;">
    <span style="font-weight: 600; color: #4a5568;">🏪 Proveedor:</span>
    <span style="color: #2d3748;">
        <?php if (!empty($combo['nombre_tienda'])): ?>
            <?php echo htmlspecialchars($combo['nombre_tienda']); ?>
        <?php else: ?>
            <span style="color: #9ca3af;">—</span>
        <?php endif; ?>
    </span>
</div>
    
    <div class="combo-stats">
                    <div class="combo-stat">📦 <?php echo $combo['productos_distintos']; ?> productos distintos</div>
                    <div class="combo-stat">📦 <?php echo $combo['unidades_totales']; ?> unidades totales</div>
                    <div class="combo-stat">⚡ <?php echo $combo['activo'] ? 'Activo' : 'Inactivo'; ?></div>
                </div>
                <div class="combo-precio">
                    <?php if ($combo['porcentaje_rebaja'] > 0): ?>
                        <span class="precio-original"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio'], 2); ?></span>
                        <span class="precio-final"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio_final'], 2); ?></span>
                        <small style="color: #718096;"> (<?php echo $combo['porcentaje_rebaja']; ?>% de descuento)</small>
                    <?php else: ?>
                        <span class="precio-normal"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio'], 2); ?></span>
                    <?php endif; ?>
                    <small><?php echo $moneda_codigo; ?></small>
                </div>
                <div>
                    <a href="combos_editar.php?id=<?php echo $combo['id']; ?>" class="btn-guardar" style="padding: 0.5rem 1rem; font-size: 0.9rem; text-decoration: none;">✏️ Editar Combo</a>
                </div>
            </div>
        </div>
        
        <div class="productos-tabla">
            <h3>📦 Productos incluidos</h3>
            <table>
                <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Precio unitario</th>
                        <th>Subtotal</th>
                    </thead>
                </thead>
                <tbody>
                    <?php 
                    $total_productos = 0;
                    while($item = $productos->fetch_assoc()): 
                        $subtotal = $item['precio'] * $item['cantidad'];
                        $total_productos += $subtotal;
                    ?>
                        <tr>
                            <td>
                                <?php if (!empty($item['imagen_url'])): ?>
                                    <img src="<?php echo htmlspecialchars($item['imagen_url']); ?>" style="width: 40px; height: 40px; object-fit: cover; border-radius: 6px;">
                                <?php else: ?>
                                    <div style="width: 40px; height: 40px; background: #f7fafc; display: flex; align-items: center; justify-content: center; border-radius: 6px;">📦</div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($item['nombre']); ?></strong></td>
                            <td>x<?php echo $item['cantidad']; ?></td>
                            <td><?php echo $moneda_simbolo; ?><?php echo number_format($item['precio'], 2); ?></td>
                            <td><?php echo $moneda_simbolo; ?><?php echo number_format($subtotal, 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot>
                    <tr style="background: #f7fafc;">
                        <td colspan="4" style="text-align: right; font-weight: 600;">Total en productos:</td>
                        <td style="font-weight: 600;"><?php echo $moneda_simbolo; ?><?php echo number_format($total_productos, 2); ?></td>
                    </tr>
                    <?php if ($combo['porcentaje_rebaja'] > 0): ?>
                    <tr>
                        <td colspan="4" style="text-align: right;">Descuento (<?php echo $combo['porcentaje_rebaja']; ?>%):</td>
                        <td style="color: #ef4444;">-<?php echo $moneda_simbolo; ?><?php echo number_format($total_productos - $combo['precio_final'], 2); ?></td>
                    </tr>
                    <tr style="background: #f0fff4;">
                        <td colspan="4" style="text-align: right; font-weight: 600;">Precio final del combo:</td>
                        <td style="font-weight: 600; color: #10b981;"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio_final'], 2); ?></td>
                    </tr>
                    <?php endif; ?>
                </tfoot>
            </table>
        </div>
    </div>
</main>

<?php
$conn->close();
include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';
?>
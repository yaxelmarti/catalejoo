<?php
// ============================================
// COMBOS GUARDAR - CREAR/EDITAR COMBO CON RESERVA
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/csrf.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$rol_actual = $_SESSION['rol'] ?? '';
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$roles_permitidos = ['Super Admin', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($rol_actual, $roles_permitidos, true);

if (!$puede_gestionar || $usuario_id_actual <= 0) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// VALIDAR CSRF
// ============================================
if (!function_exists('csrf_validar') || !csrf_validar($_POST['csrf_token'] ?? '')) {
    $_SESSION['mensaje'] = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: combos.php');
    exit;
}

// ============================================
// DATOS DEL FORMULARIO
// ============================================
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$es_edicion = ($id > 0);

$nombre = trim($_POST['nombre'] ?? '');
$proveedor_id = isset($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : 0;
// La descripción se reconstruye desde los productos (no se confía en el POST)
$descripcion = '';
// (se reconstruye después de filtrar productos, más abajo)
$imagen_url = trim($_POST['imagen_url'] ?? '');
$porcentaje_rebaja = intval($_POST['porcentaje_rebaja'] ?? 0);
$stock_combo_manual = max(0, intval($_POST['stock_combo'] ?? 0));
$activo = (isset($_POST['activo']) && intval($_POST['activo']) === 0) ? 0 : 1;

// Si es proveedor, forzar su ID
if ($proveedor_id_usuario > 0) {
    $proveedor_id = $proveedor_id_usuario;
}

// ============================================
// VALIDACIONES BÁSICAS
// ============================================
if (empty($nombre)) {
    $_SESSION['mensaje'] = "❌ El nombre del combo es obligatorio";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

if ($proveedor_id <= 0) {
    $_SESSION['mensaje'] = "❌ Debes seleccionar un proveedor";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

if ($porcentaje_rebaja < 0 || $porcentaje_rebaja > 100) {
    $_SESSION['mensaje'] = "❌ El porcentaje de rebaja debe estar entre 0 y 100";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

// Validar proveedor existe y activo
$stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
$stmt_check->bind_param("i", $proveedor_id);
$stmt_check->execute();
if ($stmt_check->get_result()->num_rows === 0) {
    $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}
$stmt_check->close();

// ============================================
// VERIFICAR PROPIEDAD DEL COMBO (SI ES EDICIÓN)
// ============================================
if ($id > 0 && $proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT proveedor_id FROM combos WHERE id = ?");
    $stmt_check->bind_param("i", $id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    if ($row_check = $result_check->fetch_assoc()) {
        if ($row_check['proveedor_id'] != $proveedor_id_usuario) {
            $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este combo';
            $_SESSION['tipo_mensaje'] = 'error';
            header('Location: combos.php');
            exit;
        }
    }
    $stmt_check->close();
}

// ============================================
// PROCESAR PRODUCTOS DEL JSON
// ============================================
$productos_json = $_POST['productos_json'] ?? '[]';
$productos = json_decode($productos_json, true);

if (json_last_error() !== JSON_ERROR_NONE || !is_array($productos)) {
    $productos = [];
}

$productos_activos_combo = [];
$productos_persistir_combo = [];
$suma_precios = 0.0;
$suma_precios_base = 0.0;
$suma_costos = 0.0;
$suma_porc = 0.0;
$count_con_rebaja = 0;

foreach ($productos as $item) {
    if (!is_array($item)) {
        continue;
    }

    $prod_id = intval($item['id'] ?? 0);
    $cantidad_solicitada = max(0, intval($item['cantidad'] ?? 0));

    if ($prod_id <= 0) {
        continue;
    }

    $stmt = $conn->prepare("SELECT nombre, activo, precio, precio_original, porcentaje_rebaja, precio_costo, proveedor_id, cantidad, reservado_por_combos FROM productos WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $prod_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        $_SESSION['mensaje'] = "❌ El producto con ID {$prod_id} no existe.";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
        exit;
    }

    if (intval($row['proveedor_id']) !== $proveedor_id) {
        $nombre_prod = $row['nombre'] ?: "ID $prod_id";
        $_SESSION['mensaje'] = "❌ '{$nombre_prod}' no pertenece a este proveedor.";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
        exit;
    }

    $esta_activo = (intval($row['activo']) === 1);

    // Conservar en combo_productos con cantidad = 0 si el producto está inactivo o su cantidad es 0
    if (!$esta_activo || $cantidad_solicitada <= 0) {
        $productos_persistir_combo[$prod_id] = 0;
        continue;
    }

    $precio_venta = round(floatval($row['precio']), 2);
    $precio_original = round(floatval($row['precio_original'] ?? 0), 2);
    $precio_costo = round(floatval($row['precio_costo']), 2);
    $porc_rebaja = intval($row['porcentaje_rebaja'] ?? 0);
    $precio_base = $precio_original > 0 ? $precio_original : $precio_venta;

    $productos_persistir_combo[$prod_id] = $cantidad_solicitada;
    $productos_activos_combo[] = [
        'id' => $prod_id,
        'nombre' => $row['nombre'],
        'cantidad' => $cantidad_solicitada,
        'precio' => $precio_venta,
        'precio_costo' => $precio_costo
    ];

    $suma_precios = round($suma_precios + ($precio_venta * $cantidad_solicitada), 2);
    $suma_precios_base = round($suma_precios_base + ($precio_base * $cantidad_solicitada), 2);
    $suma_costos = round($suma_costos + ($precio_costo * $cantidad_solicitada), 2);

    if ($porc_rebaja > 0 && $precio_base > $precio_venta) {
        $suma_porc += $porc_rebaja;
        $count_con_rebaja++;
    }
}

if (empty($productos_activos_combo)) {
    $_SESSION['mensaje'] = "❌ Debe haber al menos un producto activo con cantidad mayor a 0 en el combo.";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

// Reconstruir descripción desde los productos activos con cantidad > 0
$lineas_descripcion = [];
foreach ($productos_activos_combo as $prod) {
    $lineas_descripcion[] = $prod['cantidad'] . '- ' . $prod['nombre'];
}
$descripcion = implode("\n", $lineas_descripcion);

// ============================================
// LEER PRODUCTOS ANTERIORES (SI ES EDICIÓN)
// ============================================
$productos_anteriores = [];
if ($id > 0) {
    $stmt_old = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
    $stmt_old->bind_param("i", $id);
    $stmt_old->execute();
    $result_old = $stmt_old->get_result();
    while ($old = $result_old->fetch_assoc()) {
        $productos_anteriores[intval($old['producto_id'])] = max(0, intval($old['cantidad']));
    }
    $stmt_old->close();
}

// ============================================
// CALCULAR STOCK DISPONIBLE Y STOCK CALCULADO
// ============================================
$stock_calculado = PHP_INT_MAX;

foreach ($productos_activos_combo as $prod) {
    $stmt = $conn->prepare("SELECT cantidad, reservado_por_combos FROM productos WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $prod['id']);
    $stmt->execute();
    $row_prod = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row_prod) {
        $stock_calculado = 0;
        break;
    }

    $stock_disponible = intval($row_prod['cantidad']) - intval($row_prod['reservado_por_combos']);
    if ($id > 0 && isset($productos_anteriores[$prod['id']])) {
        $stock_disponible += $productos_anteriores[$prod['id']];
    }

    $stock_disponible = max(0, $stock_disponible);
    $combos_posibles = ($prod['cantidad'] > 0) ? (int) floor($stock_disponible / $prod['cantidad']) : 0;

    if ($combos_posibles < $stock_calculado) {
        $stock_calculado = $combos_posibles;
    }
}

if ($stock_calculado === PHP_INT_MAX) {
    $stock_calculado = 0;
}
$stock_calculado = max(0, $stock_calculado);

// ============================================
// VALIDAR STOCK DEL COMBO
// ============================================
if ($stock_combo_manual === 0) {
    $stock_combo_manual = $stock_calculado;
}

if ($stock_combo_manual > $stock_calculado) {
    $producto_limitante = null;
    $stock_limitante = PHP_INT_MAX;

    foreach ($productos_activos_combo as $prod) {
        $stmt = $conn->prepare("SELECT nombre, cantidad, reservado_por_combos FROM productos WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $prod['id']);
        $stmt->execute();
        $row_p = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$row_p) {
            continue;
        }

        $stock_disponible = intval($row_p['cantidad']) - intval($row_p['reservado_por_combos']);
        if ($id > 0 && isset($productos_anteriores[$prod['id']])) {
            $stock_disponible += $productos_anteriores[$prod['id']];
        }
        $stock_disponible = max(0, $stock_disponible);
        $combos_posibles = ($prod['cantidad'] > 0) ? (int) floor($stock_disponible / $prod['cantidad']) : 0;

        if ($combos_posibles < $stock_limitante) {
            $stock_limitante = $combos_posibles;
            $producto_limitante = $row_p['nombre'];
        }
    }

    $_SESSION['mensaje'] = $producto_limitante
        ? "⚠️ Stock insuficiente: '{$producto_limitante}' solo permite armar {$stock_calculado} combo(s)."
        : "⚠️ Stock insuficiente: solo puedes armar {$stock_calculado} combo(s).";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

// ============================================
// CALCULAR PRECIO FINAL Y TOTALES (PRECISIÓN DECIMAL)
// ============================================
$precio_tachado = round($suma_precios_base, 2);
$precio_final = round($suma_precios, 2);
$suma_costos = round($suma_costos, 2);
$porcentaje_rebaja = ($count_con_rebaja > 0)
    ? (int) round($suma_porc / $count_con_rebaja)
    : 0;
$productos_distintos = count($productos_activos_combo);
$unidades_totales = array_sum(array_column($productos_activos_combo, 'cantidad'));

// ============================================
// INICIAR TRANSACCIÓN
// ============================================
$conn->begin_transaction();

try {
    $fecha_actual = date('Y-m-d H:i:s');

    // ============================================
        // ============================================
    // 1. GUARDAR/ACTUALIZAR EL COMBO
    // ============================================
    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE combos SET
            nombre = ?,
            proveedor_id = ?,
            descripcion = ?,
            imagen_url = ?,
            costo = ?,
            precio = ?,
            porcentaje_rebaja = ?,
            precio_final = ?,
            productos_distintos = ?,
            unidades_totales = ?,
            stock_combo = ?,
            stock_calculado = ?,
            fecha_actualizacion_stock = ?,
            activo = ?
            WHERE id = ?");

        $porcentaje_rebaja = (int) $porcentaje_rebaja;
        $productos_distintos = (int) $productos_distintos;
        $unidades_totales = (int) $unidades_totales;
        $stock_combo_manual = (int) $stock_combo_manual;
        $stock_calculado = (int) $stock_calculado;
        $activo = (int) $activo;
        $id = (int) $id;

        // Tipos: s=string, i=integer, d=double/decimal
        // Orden: nombre(s), proveedor_id(i), descripcion(s), imagen_url(s),
        // costo(d), precio(d), porcentaje_rebaja(i), precio_final(d),
        // productos_distintos(i), unidades_totales(i), stock_combo(i),
        // stock_calculado(i), fecha_actualizacion_stock(s), activo(i), id(i)
        $stmt->bind_param("sisssdidiiiisii",
            $nombre,
            $proveedor_id,
            $descripcion,
            $imagen_url,
            $suma_costos,
            $precio_tachado,
            $porcentaje_rebaja,
            $precio_final,
            $productos_distintos,
            $unidades_totales,
            $stock_combo_manual,
            $stock_calculado,
            $fecha_actual,
            $activo,
            $id
        );
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt = $conn->prepare("INSERT INTO combos
            (nombre, proveedor_id, descripcion, imagen_url, costo, precio, porcentaje_rebaja, precio_final, productos_distintos, unidades_totales, stock_combo, stock_calculado, fecha_actualizacion_stock, activo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $porcentaje_rebaja = (int) $porcentaje_rebaja;
        $productos_distintos = (int) $productos_distintos;
        $unidades_totales = (int) $unidades_totales;
        $stock_combo_manual = (int) $stock_combo_manual;
        $stock_calculado = (int) $stock_calculado;
        $activo = (int) $activo;

        // Tipos: s=string, i=integer, d=double/decimal
        // Orden: nombre(s), proveedor_id(i), descripcion(s), imagen_url(s),
        // costo(d), precio(d), porcentaje_rebaja(i), precio_final(d),
        // productos_distintos(i), unidades_totales(i), stock_combo(i),
        // stock_calculado(i), fecha_actualizacion_stock(s), activo(i)
        $stmt->bind_param("sisssdidiiiis",
            $nombre,
            $proveedor_id,
            $descripcion,
            $imagen_url,
            $suma_costos,
            $precio_tachado,
            $porcentaje_rebaja,
            $precio_final,
            $productos_distintos,
            $unidades_totales,
            $stock_combo_manual,
            $stock_calculado,
            $fecha_actual,
            $activo
        );
        $stmt->execute();
        $id = $conn->insert_id;
        $stmt->close();
    }

    // ============================================
    // 2. SINCRONIZAR COMBO_PRODUCTOS PRIMERO
    // (conserva inactivos / cantidad 0; solo borra eliminados explícitamente)
    // ============================================
    $stmt_prod = $conn->prepare("INSERT INTO combo_productos (combo_id, producto_id, cantidad)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE cantidad = VALUES(cantidad)");
    foreach ($productos_persistir_combo as $prod_id => $cant_guardar) {
        $cant_segura = max(0, intval($cant_guardar));
        $stmt_prod->bind_param("iii", $id, $prod_id, $cant_segura);
        $stmt_prod->execute();
    }
    $stmt_prod->close();

    foreach ($productos_anteriores as $prod_ant_id => $cant_ant) {
        if (!array_key_exists($prod_ant_id, $productos_persistir_combo)) {
            $stmt_del = $conn->prepare("DELETE FROM combo_productos WHERE combo_id = ? AND producto_id = ?");
            $stmt_del->bind_param("ii", $id, $prod_ant_id);
            $stmt_del->execute();
            $stmt_del->close();
        }
    }

    // ============================================
    // 3. ACTUALIZAR RESERVAS Y FLAG EN_COMBO
    // ============================================
    $todos_productos = array_unique(array_merge(
        array_keys($productos_anteriores),
        array_keys($productos_persistir_combo)
    ));

    foreach ($todos_productos as $prod_id) {
        $cant_anterior = $productos_anteriores[$prod_id] ?? 0;
        $cant_nueva = ($activo === 1) ? ($productos_persistir_combo[$prod_id] ?? 0) : 0;
        $diff = $cant_nueva - $cant_anterior;

        if ($diff !== 0) {
            $stmt_res = $conn->prepare("UPDATE productos
                SET reservado_por_combos = GREATEST(0, reservado_por_combos + ?),
                    fecha_actualizacion_reserva = ?
                WHERE id = ?");
            $stmt_res->bind_param("isi", $diff, $fecha_actual, $prod_id);
            $stmt_res->execute();
            $stmt_res->close();
        }

        $stmt_flag = $conn->prepare("UPDATE productos p
            SET p.en_combo = CASE
                WHEN EXISTS (
                    SELECT 1 FROM combo_productos cp
                    INNER JOIN combos c ON c.id = cp.combo_id
                    WHERE cp.producto_id = p.id AND cp.cantidad > 0 AND c.activo = 1
                ) THEN 1 ELSE 0
            END
            WHERE p.id = ?");
        $stmt_flag->bind_param("i", $prod_id);
        $stmt_flag->execute();
        $stmt_flag->close();
    }

    $conn->commit();

    $_SESSION['mensaje'] = $es_edicion
        ? "✅ Combo actualizado correctamente"
        : "✅ Combo creado correctamente";
    $_SESSION['tipo_mensaje'] = "exito";

} catch (Throwable $e) {
    $conn->rollback();
    error_log('[combos_guardar] Error: ' . $e->getMessage());
    $_SESSION['mensaje'] = "❌ Error al guardar el combo. Inténtalo de nuevo.";
    $_SESSION['tipo_mensaje'] = "error";
    $conn->close();
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

$conn->close();
header('Location: combos.php?t=' . time());
exit;
?>
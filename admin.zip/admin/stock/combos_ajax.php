<?php
// ============================================
// COMBOS AJAX - CARGA DE COMBOS VÍA AJAX
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================
// CABECERAS ANTI-CACHÉ
// ============================================
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/csrf.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$rol_actual = $_SESSION['rol'] ?? '';
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($rol_actual, $roles_ver, true) || $usuario_id_actual <= 0) {
    http_response_code(403);
    echo "Acceso denegado";
    exit;
}

// ============================================
// PERMISOS
// ============================================
$roles_gestionar = ['Super Admin', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($rol_actual, $roles_gestionar, true);

$roles_eliminar = ['Super Admin', 'Proveedor'];
$puede_eliminar = in_array($rol_actual, $roles_eliminar, true);

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($proveedor_id_usuario > 0) {
    $_GET['proveedor_id'] = $proveedor_id_usuario;
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "c.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['estado'])) {
    if ($_GET['estado'] == 'activos') {
        $where[] = "c.activo = 1";
    } elseif ($_GET['estado'] == 'inactivos') {
        $where[] = "c.activo = 0";
    }
}

if (!empty($_GET['proveedor_id'])) {
    $where[] = "c.proveedor_id = ?";
    $params[] = intval($_GET['proveedor_id']);
    $types .= "i";
}

if (!empty($_GET['nombre_tienda'])) {
    $where[] = "pr.nombre_tienda LIKE ?";
    $params[] = "%" . $_GET['nombre_tienda'] . "%";
    $types .= "s";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// ORDENAMIENTO
// ============================================
$columnas_validas = [
    'id' => "c.id",
    'nombre' => "c.nombre",
    'nombre_tienda' => "pr.nombre_tienda",
    'precio' => "c.precio",
    'precio_final' => "c.precio_final",
    'rebaja' => "c.porcentaje_rebaja",
    'productos' => "(SELECT COUNT(*) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1)",
    'unidades' => "(SELECT COALESCE(SUM(cp.cantidad), 0) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1)",
    'importe_costo' => "importe_costo",
    'stock_combo' => "c.stock_combo",
    'stock_calculado' => "c.stock_calculado",
    'estado' => "c.activo",
    'fecha' => "c.fecha_creacion"
];

$order_by = isset($_GET['order_by']) && array_key_exists($_GET['order_by'], $columnas_validas) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . ($order_by == 'importe_costo' ? "importe_costo" : $columnas_validas[$order_by]) . " $order_dir";

// ============================================
// CONTAR TOTAL
// ============================================
$count_sql = "SELECT COUNT(*) as total FROM combos c $sql_where";
$count_stmt = $conn->prepare($count_sql);

if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_registros = $count_result ? $count_result->fetch_assoc()['total'] : 0;
$count_stmt->close();

// ============================================
// PAGINACIÓN
// ============================================
$result_config = $conn->query("SELECT valor FROM configuracion WHERE clave = 'productos_por_pagina'");
$row_config = $result_config->fetch_assoc();
$por_pagina = $row_config ? intval($row_config['valor']) : 30;

$por_pagina = max(1, $por_pagina);
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($pagina_actual - 1) * $por_pagina;
$total_paginas = ($total_registros > 0) ? (int) ceil($total_registros / $por_pagina) : 1;

// ============================================
// CONSULTA PRINCIPAL
// ============================================
$sql = "SELECT c.*, 
               (SELECT COUNT(*) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as productos_distintos,
               (SELECT COALESCE(SUM(cp.cantidad), 0) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as unidades_totales,
               (SELECT COALESCE(SUM(p.precio_costo * cp.cantidad), 0) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as importe_costo,
               pr.nombre_tienda
        FROM combos c 
        LEFT JOIN proveedores pr ON c.proveedor_id = pr.id
        $sql_where 
        $order_sql
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $params[] = $por_pagina;
    $params[] = $offset;
    $types = $types . "ii";
    $stmt->bind_param($types, ...$params);
} else {
    $stmt->bind_param("ii", $por_pagina, $offset);
}
$stmt->execute();
$combos = $stmt->get_result();
?>

<!-- ============================================ -->
<!-- TABLA DE COMBOS -->
<!-- ============================================ -->
<div class="productos-table-card">
    <div class="table-header">
        <h3>🎁 Lista de Combos <span style="font-size: 0.8rem; color: #718096; font-weight: normal;">(<?php echo $total_registros; ?> combos)</span></h3>
        <div class="table-header-right">
            <?php if ($puede_gestionar): ?>
            <a href="combos_editar.php" class="btn-primary btn">➕ Nuevo Combo</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="table-wrapper">
        <div class="table-responsive" id="tableContainer">
            <table class="tabla-moderna" id="tablaCombos">
                <thead>
                    <tr>
                        <th style="display: none;">ID</th>
                        <th class="checkbox-col">
                            <input type="checkbox" class="select-all-checkbox" id="selectAll" title="Seleccionar todos">
                        </th>
                        <th class="no-print">Imagen</th>
                        <th><a href="#" data-order="nombre" class="ordenar-link">Nombre <?php echo $order_by == 'nombre' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="nombre_tienda" class="ordenar-link">Proveedor <?php echo $order_by == 'nombre_tienda' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="productos" class="ordenar-link">Prod/Unid <?php echo $order_by == 'productos' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="importe_costo" class="ordenar-link">Importe Costo <?php echo $order_by == 'importe_costo' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="precio" class="ordenar-link">Precio Venta <?php echo $order_by == 'precio' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="rebaja" class="ordenar-link">Rebaja <?php echo $order_by == 'rebaja' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="stock_combo" class="ordenar-link">Stock <?php echo $order_by == 'stock_combo' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="stock_calculado" class="ordenar-link">Stock Calc. <?php echo $order_by == 'stock_calculado' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="fecha" class="ordenar-link">Fecha/Estado <?php echo $order_by == 'fecha' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th class="no-print">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($combos->num_rows > 0): ?>
                        <?php while($combo = $combos->fetch_assoc()): 
                            $tiene_rebaja = $combo['porcentaje_rebaja'] > 0;
                        ?>
                        <tr style="<?php echo $combo['activo'] ? '' : 'opacity: 0.7; background: #fff5f5;'; ?>">
                            <td style="display: none;">#<?php echo $combo['id']; ?></td>
                            <td class="checkbox-col text-center">
                                <?php if ($puede_gestionar): ?>
                                <input type="checkbox" class="checkbox-combo" value="<?php echo $combo['id']; ?>" data-id="<?php echo $combo['id']; ?>">
                                <?php endif; ?>
                            </td>
                            <td class="no-print">
                                <?php if (!empty($combo['imagen_url'])): ?>
                                    <img src="<?php echo htmlspecialchars($combo['imagen_url']); ?>" alt="<?php echo htmlspecialchars($combo['nombre']); ?>" class="img-thumbnail" style="width: 45px; height: 45px; object-fit: cover; border-radius: 8px;">
                                <?php else: ?>
                                    <div class="sin-imagen" title="Sin imagen">🎁</div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($combo['nombre']); ?></strong></td>
                            <td><?php echo htmlspecialchars($combo['nombre_tienda'] ?? '—'); ?></td>
                            <td class="text-center">
                                <div style="font-size: 0.75rem; color: #718096;">P-<?php echo intval($combo['productos_distintos']); ?></div>
                                <div style="font-size: 0.75rem; color: #718096;">U-<?php echo intval($combo['unidades_totales']); ?></div>
                            </td>
                            <td class="text-right">$<?php echo number_format($combo['importe_costo'], 2); ?></td>
                            <td class="text-right">
    <?php if ($combo['precio'] > $combo['precio_final'] && $combo['porcentaje_rebaja'] > 0): ?>
        <div style="text-decoration: line-through; color: #ef4444; font-size: 0.75rem; line-height: 1.2;">
            $<?php echo number_format($combo['precio'], 2); ?>
        </div>
        <div style="color: #10b981; font-weight: 600; line-height: 1.2;">
            $<?php echo number_format($combo['precio_final'], 2); ?>
        </div>
    <?php else: ?>
        <div style="color: #10b981; font-weight: 600; line-height: 1.2;">
            $<?php echo number_format($combo['precio_final'], 2); ?>
        </div>
    <?php endif; ?>
</td>
                            <td class="text-center">
                                <?php if ($tiene_rebaja): ?>
                                    <span class="badge-rebaja">-<?php echo $combo['porcentaje_rebaja']; ?>%</span>
                                <?php else: ?>
                                    <span style="color: #9ca3af;">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?php echo intval($combo['stock_combo']); ?></td>
                            <td class="text-center"><?php echo intval($combo['stock_calculado']); ?></td>
                            <td class="text-center">
    <div style="font-size: 0.75rem; color: #718096;"><?php echo date('d/m/Y', strtotime($combo['fecha_creacion'])); ?></div>
    <div class="estado-combo" style="font-weight: 600; font-size: 0.8rem; color: <?php echo $combo['activo'] ? '#38a169' : '#e53e3e'; ?>;">
        <?php echo $combo['activo'] ? 'Activo' : 'Inactivo'; ?>
    </div>
</td>
                            <td class="no-print acciones">
                                <a href="combos_ver.php?id=<?php echo $combo['id']; ?>" class="btn-icono" title="Ver detalles">👁️</a>
                                <?php if ($puede_gestionar): ?>
                                    <a href="#" class="btn-icono ajax-toggle-estado" 
                                       data-id="<?php echo $combo['id']; ?>" 
                                       data-estado="<?php echo $combo['activo']; ?>"
                                       title="<?php echo $combo['activo'] ? 'Desactivar' : 'Activar'; ?>">
                                        <?php echo $combo['activo'] ? '🔴' : '🟢'; ?>
                                    </a>
                                    <a href="combos_editar.php?id=<?php echo $combo['id']; ?>" class="btn-icono">✏️</a>
                                    <?php if ($puede_eliminar): ?>
                                    <form method="POST" action="combos_acciones.php?accion=eliminar&id=<?php echo $combo['id']; ?>" style="display:inline; margin:0;" onsubmit="return confirm('¿Eliminar combo <?php echo addslashes($combo['nombre']); ?>?')">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn-icono" style="border:none; background:none; cursor:pointer;">🗑️</button>
                                    </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="13" class="text-center sin-datos">📭 No se encontraron combos con los filtros seleccionados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- PAGINACIÓN -->
<!-- ============================================ -->
<?php
$base_url = '#';
$total_registros = $total_registros;
$por_pagina = $por_pagina;
$pagina_actual = $pagina_actual;
$total_paginas = $total_paginas;
include $_SERVER['DOCUMENT_ROOT'] . '/includes/paginacion_botones.php';
?>

<?php
$stmt->close();
$conn->close();
?>
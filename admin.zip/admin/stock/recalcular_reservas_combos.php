<?php
// ============================================
// RECALCULAR RESERVAS DE COMBOS (CRON)
// ============================================
// Recalcula:
// - productos.reservado_por_combos
// - productos.en_combo
// - combos.stock_calculado
// - fechas de actualización
//
// Uso:
// - Cron: php /ruta/recalcular_reservas_combos.php
// - URL: /admin/stock/recalcular_reservas_combos.php?token=XXX
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================
// TOKEN DE SEGURIDAD
// ============================================
// Cambia este token por uno largo y aleatorio
$CRON_TOKEN = '9f3a7c2e1b8d5a4f6e9c0d2b7a3f8e1c5d9b2a6f4e7c1d8b3a5f9e2c6d0b7a4f';

// Permitir ejecución solo si:
// - Es por CLI (cron)
// - O viene con ?token= correcto
$es_cli = (php_sapi_name() === 'cli');
$token_valido = isset($_GET['token']) && hash_equals($CRON_TOKEN, $_GET['token']);

if (!$es_cli && !$token_valido) {
    http_response_code(403);
    exit('Acceso denegado');
}

// ============================================
// CONEXIÓN
// ============================================
require_once __DIR__ . '/../../conexion.php';

$modo_debug = isset($_GET['debug']) || $es_cli;
$inicio = microtime(true);

// ============================================
// FUNCIÓN PARA LOG
// ============================================
function log_msg($msg, $modo_debug = false) {
    if ($modo_debug) {
        echo $msg . "\n";
    }
    error_log('[recalcular_reservas_combos] ' . $msg);
}

// ============================================
// 1. RECALCULAR reservado_por_combos Y en_combo
// ============================================
// Para cada producto:
// - reservado_por_combos = SUM(combo_productos.cantidad) de combos ACTIVOS que lo contienen
// - en_combo = 1 si reservado_por_combos > 0, 0 si no
// ============================================
$sql_reserva = "
    UPDATE productos p
    LEFT JOIN (
        SELECT cp.producto_id, 
               SUM(cp.cantidad) as total_reservado
        FROM combo_productos cp
        INNER JOIN combos c ON cp.combo_id = c.id
        WHERE c.activo = 1
        GROUP BY cp.producto_id
    ) AS reservas ON p.id = reservas.producto_id
    SET 
        p.reservado_por_combos = COALESCE(reservas.total_reservado, 0),
        p.en_combo = CASE WHEN COALESCE(reservas.total_reservado, 0) > 0 THEN 1 ELSE 0 END,
        p.fecha_actualizacion_reserva = NOW()
";

if (!$conn->query($sql_reserva)) {
    log_msg('❌ Error al recalcular reservas: ' . $conn->error, $modo_debug);
    exit(1);
}

$productos_actualizados = $conn->affected_rows;
log_msg("✅ Reservas recalculadas. Productos afectados: $productos_actualizados", $modo_debug);

// ============================================
// 2. RECALCULAR combos.stock_calculado
// ============================================
// Para cada combo ACTIVO:
// - stock_calculado = MIN( stock_disponible / cantidad_por_combo ) de sus productos
// ============================================
$sql_combos = "
    SELECT c.id, c.stock_combo
    FROM combos c
    WHERE c.activo = 1
";

$result_combos = $conn->query($sql_combos);
$total_combos = 0;
$combos_actualizados = 0;

if ($result_combos) {
    while ($combo = $result_combos->fetch_assoc()) {
        $combo_id = intval($combo['id']);
        $stock_combo = intval($combo['stock_combo']);
        $total_combos++;
        
        // Obtener productos del combo
        $stmt_prod = $conn->prepare("
            SELECT cp.producto_id, cp.cantidad, p.cantidad as stock_total, p.reservado_por_combos
            FROM combo_productos cp
            INNER JOIN productos p ON cp.producto_id = p.id
            WHERE cp.combo_id = ?
        ");
        $stmt_prod->bind_param("i", $combo_id);
        $stmt_prod->execute();
        $res_prod = $stmt_prod->get_result();
        
        $stock_calculado = PHP_INT_MAX;
        $tiene_productos = false;
        
        while ($prod = $res_prod->fetch_assoc()) {
            $cant_prod = intval($prod['cantidad']);
            if ($cant_prod <= 0) {
                continue;
            }

            $tiene_productos = true;
            $stock_disponible = intval($prod['stock_total']) - intval($prod['reservado_por_combos']);
            // Para calcular correctamente, el producto no debería restarse a sí mismo
            // La reserva ya incluye este combo, así que sumamos la cantidad de este combo
            $stock_disponible += $cant_prod;
            
            if ($stock_disponible < 0) $stock_disponible = 0;
            
            $combos_posibles = floor($stock_disponible / $cant_prod);
            
            if ($combos_posibles < $stock_calculado) {
                $stock_calculado = $combos_posibles;
            }
        }
        $stmt_prod->close();
        
        if (!$tiene_productos) {
            $stock_calculado = 0;
        }
        
        if ($stock_calculado == PHP_INT_MAX) {
            $stock_calculado = 0;
        }
        
        $stock_calculado = max(0, intval($stock_calculado));
        
        // Actualizar combos.stock_calculado
        $stmt_update = $conn->prepare("
            UPDATE combos 
            SET stock_calculado = ?, 
                fecha_actualizacion_stock = NOW()
            WHERE id = ?
        ");
        $stmt_update->bind_param("ii", $stock_calculado, $combo_id);
        $stmt_update->execute();
        
        if ($stmt_update->affected_rows > 0) {
            $combos_actualizados++;
        }
        $stmt_update->close();
    }
}

log_msg("✅ Stock calculado recalculado. Combos procesados: $total_combos, actualizados: $combos_actualizados", $modo_debug);

// ============================================
// 3. (OPCIONAL) SI STOCK_COMBO > STOCK_CALCULADO, AJUSTAR
// ============================================
// Si el stock_combo manual es mayor que el stock_calculado,
// significa que el combo no se puede armar. Ajustar stock_combo = stock_calculado.
$sql_ajuste = "
    UPDATE combos 
    SET stock_combo = stock_calculado
    WHERE activo = 1 
    AND stock_combo > stock_calculado
";

if ($conn->query($sql_ajuste)) {
    $combos_ajustados = $conn->affected_rows;
    if ($combos_ajustados > 0) {
        log_msg("⚠️ Ajustados $combos_ajustados combos con stock_combo > stock_calculado", $modo_debug);
    }
} else {
    log_msg('❌ Error al ajustar stock_combo: ' . $conn->error, $modo_debug);
}

// ============================================
// RESUMEN FINAL
// ============================================
$fin = microtime(true);
$duracion = round($fin - $inicio, 3);

log_msg("🏁 Cron completado en {$duracion}s", $modo_debug);

$conn->close();
exit(0);
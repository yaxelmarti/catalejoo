<?php
define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}
    
require_once __DIR__ . '/../../header.php';
require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/moneda_funciones.php';

// ============================================
// CARGAR COLORES DESDE CONFIGURACIÓN
// ============================================
$color_primario = '#667eea';
$color_secundario = '#764ba2';

$stmt_color = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario' LIMIT 1");
if ($stmt_color) {
    $stmt_color->execute();
    $r = $stmt_color->get_result();
    if ($row = $r->fetch_assoc()) $color_primario = $row['valor'];
    $stmt_color->close();
}

$stmt_color2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario' LIMIT 1");
if ($stmt_color2) {
    $stmt_color2->execute();
    $r = $stmt_color2->get_result();
    if ($row = $r->fetch_assoc()) $color_secundario = $row['valor'];
    $stmt_color2->close();
}

// ============================================
// ASEGURAR CSRF TOKEN
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================
// VERIFICACIÓN DE PERMISOS
// ============================================
$rol_actual = $_SESSION['rol'] ?? '';

// Roles que pueden ENTRAR
$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($rol_actual, $roles_ver)) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// Roles que pueden GESTIONAR
$roles_gestionar = ['Super Admin', 'Gerente', 'Proveedor', 'Inventario'];
$puede_gestionar = in_array($rol_actual, $roles_gestionar);

// Roles que pueden ELIMINAR
$roles_eliminar = ['Super Admin', 'Gerente', 'Proveedor'];
$puede_eliminar = in_array($rol_actual, $roles_eliminar);

// Roles que ven todos los proveedores (con selector)
$roles_ver_todos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
$puede_ver_todos = in_array($rol_actual, $roles_ver_todos);

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_filtro = obtenerProveedorId($conn, $_SESSION['usuario_id'], $rol_actual);
$es_rol_proveedor = esRolProveedor($rol_actual);

// Validar que el proveedor existe y está activo
if ($es_rol_proveedor && $proveedor_id_filtro == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_filtro > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_filtro);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// PROCESAR ACTIVACIÓN MASIVA
// ============================================
if (isset($_GET['activar_todos']) && $_GET['activar_todos'] == 1 && $puede_gestionar) {
    // Validar CSRF
    if (!function_exists('csrf_validar') || !csrf_validar($_GET['csrf_token'] ?? '')) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/stock/productos.php');
        exit;
    }
    if ($proveedor_id_filtro > 0) {
        $stmt_act = $conn->prepare("UPDATE productos SET activo = 1 WHERE activo = 0 AND proveedor_id = ?");
        $stmt_act->bind_param("i", $proveedor_id_filtro);
        $stmt_act->execute();
        $stmt_act->close();
    } else {
        $conn->query("UPDATE productos SET activo = 1 WHERE activo = 0");
    }
    $_SESSION['mensaje'] = "✅ Todos los productos inactivos han sido activados";
    $_SESSION['tipo_mensaje'] = "exito";
    header('Location: admin.php?filtro_estado=inactivos');
    exit;
}

// ============================================
// ============================================
// PROCESAR ACCIÓN MASIVA POR SELECCIÓN
// ============================================
if (isset($_POST['accion_masiva']) && $puede_gestionar) {
    // Validar CSRF
    if (!function_exists('csrf_validar') || !csrf_validar($_POST['csrf_token'] ?? '')) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/stock/productos.php');
        exit;
    }
    
    $accion = $_POST['accion_masiva'];
    $productos_json = isset($_POST['productos']) ? $_POST['productos'] : '[]';
    $productos = json_decode($productos_json, true);
    
    if (!empty($productos) && is_array($productos)) {
        $productos_ids = array_map('intval', $productos);
        
        // SEGURIDAD: verificar propiedad si es rol de tienda
        if ($proveedor_id_filtro > 0) {
            $placeholders_check = implode(',', array_fill(0, count($productos_ids), '?'));
            $stmt_check = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE id IN ($placeholders_check) AND proveedor_id = ?");
            $types_check = str_repeat('i', count($productos_ids) + 1);
            $params_check = array_merge($productos_ids, [$proveedor_id_filtro]);
            $stmt_check->bind_param($types_check, ...$params_check);
            $stmt_check->execute();
            $total_propios = $stmt_check->get_result()->fetch_assoc()['total'];
            $stmt_check->close();
            
            if ($total_propios != count($productos_ids)) {
                $_SESSION['mensaje'] = "❌ No tienes permiso para modificar algunos productos";
                $_SESSION['tipo_mensaje'] = "error";
                $query_string = http_build_query(array_filter($_GET));
                header('Location: admin.php' . ($query_string ? '?' . $query_string : ''));
                exit;
            }
        }
        
        $ids = implode(',', $productos_ids);
        $nuevo_estado = ($accion == 'activar') ? 1 : 0;
        
        $estados_anteriores = [];
        $result = $conn->query("SELECT id, activo FROM productos WHERE id IN ($ids)");
        while($row = $result->fetch_assoc()) {
            $estados_anteriores[$row['id']] = $row['activo'];
        }
        
        // Preparar la consulta segura
        $placeholders = implode(',', array_fill(0, count($productos_ids), '?'));
        $stmt_update = $conn->prepare("UPDATE productos SET activo = ? WHERE id IN ($placeholders)");
        $types = str_repeat('i', count($productos_ids) + 1);
        $params = array_merge([$nuevo_estado], $productos_ids);
        $stmt_update->bind_param($types, ...$params);
        $stmt_update->execute();
        $stmt_update->close();
        
        $usuario_id = $_SESSION['usuario_id'];
$usuario_nombre = $_SESSION['nombre'] ?? '';
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

$stmt_hist = $conn->prepare("
    INSERT INTO historial_productos_cambios 
    (producto_id, usuario_id, usuario_nombre, accion, cambios, ip_address, user_agent) 
    VALUES (?, ?, ?, 'editar', ?, ?, ?)
");

foreach ($productos_ids as $producto_id) {
    $estado_anterior = isset($estados_anteriores[$producto_id]) ? $estados_anteriores[$producto_id] : ($nuevo_estado == 1 ? 0 : 1);
    $cambios = json_encode(['activo' => ['antes' => $estado_anterior, 'despues' => $nuevo_estado]]);
    $stmt_hist->bind_param("iissss", $producto_id, $usuario_id, $usuario_nombre, $cambios, $ip, $user_agent);
    $stmt_hist->execute();
}
$stmt_hist->close();
        
        $mensaje_accion = ($accion == 'activar') ? 'activados' : 'desactivados';
        $_SESSION['mensaje'] = "✅ " . count($productos_ids) . " productos $mensaje_accion correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
    } else {
        $_SESSION['mensaje'] = "❌ No seleccionaste ningún producto";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    $query_string = http_build_query(array_filter($_GET));
    header('Location: admin.php' . ($query_string ? '?' . $query_string : ''));
    exit;
}

// ============================================
// PROCESAR IMPORTACIÓN
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($puede_gestionar && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['archivo_importar'])) {
    $archivo = $_FILES['archivo_importar'];
    
    if ($archivo['error'] == 0) {
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        
        if ($extension == 'csv') {
            $file = fopen($archivo['tmp_name'], 'r');
            $cabeceras = fgetcsv($file);
            $contador = 0;
            $errores = [];
            
            while (($datos = fgetcsv($file)) !== FALSE) {
                $datos_procesados = [];
                foreach ($datos as $campo) {
                    $encoding = mb_detect_encoding($campo, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
                    if ($encoding && $encoding != 'UTF-8') {
                        $campo = mb_convert_encoding($campo, 'UTF-8', $encoding);
                    }
                    $datos_procesados[] = $campo;
                }
                
                $nombre = $conn->real_escape_string($datos_procesados[0] ?? '');
                $descripcion = $conn->real_escape_string($datos_procesados[1] ?? '');
                $marca = $conn->real_escape_string($datos_procesados[2] ?? '');
                $peso = floatval($datos_procesados[3] ?? 0);
                $cantidad = intval($datos_procesados[4] ?? 0);
                $precio_costo = floatval($datos_procesados[5] ?? 0);
                $precio_venta = floatval($datos_procesados[6] ?? 0);
                $categoria = $conn->real_escape_string($datos_procesados[7] ?? '');
                $imagen = $conn->real_escape_string($datos_procesados[8] ?? '');
                
                if (empty($nombre)) continue;
                
                $stmt_cat = $conn->prepare("SELECT id FROM categorias WHERE nombre LIKE ? LIMIT 1");
$param_cat = "%$categoria%";
$stmt_cat->bind_param("s", $param_cat);
$stmt_cat->execute();
$cat_result = $stmt_cat->get_result();
                $categoria_id = $cat_result->num_rows > 0 ? $cat_result->fetch_assoc()['id'] : null;
                
               $proveedor_id_insert = $proveedor_id_filtro > 0 ? $proveedor_id_filtro : null;
$stmt_insert = $conn->prepare("INSERT INTO productos (nombre, descripcion, marca, peso, cantidad, precio_costo, precio, imagen_url, categoria_id, proveedor_id, activo) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
$stmt_insert->bind_param("sssiddddsii", $nombre, $descripcion, $marca, $peso, $cantidad, $precio_costo, $precio_venta, $imagen, $categoria_id, $proveedor_id_insert);
                
                if ($stmt_insert->execute()) {
                    $producto_id = $conn->insert_id;
                    
                    $stmt_update = $conn->prepare("UPDATE productos SET activo = 0 WHERE id = ?");
                    $stmt_update->bind_param("i", $producto_id);
                    $stmt_update->execute();
                    
                    $contador++;
                } else {
                    $errores[] = "Error en fila " . ($contador + 2) . ": " . $conn->error;
                }
            }
            fclose($file);
            
            $_SESSION['mensaje'] = "✅ Se importaron $contador productos (INACTIVOS por defecto)";
            if (!empty($errores)) {
                $_SESSION['mensaje'] .= "<br>❌ " . implode("<br>❌ ", $errores);
                $_SESSION['tipo_mensaje'] = "advertencia";
            } else {
                $_SESSION['tipo_mensaje'] = "exito";
            }
            header('Location: admin.php?filtro_estado=inactivos');
            exit;
        } elseif ($extension == 'xlsx' || $extension == 'xls') {
            $mensaje = "⚠️ Para archivos Excel, usa el botón de exportar y luego importa CSV";
            $tipo_mensaje = "info";
        }
    } else {
        $mensaje = "❌ Error al subir el archivo";
        $tipo_mensaje = "error";
    }
}

// ============================================
// PROCESAR FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "p.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['precio_costo']) && isset($_GET['costo_operador'])) {
    $operador = $_GET['costo_operador'];
    if (in_array($operador, ['=', '<', '>'])) {
        $where[] = "p.precio_costo $operador ?";
        $params[] = $_GET['precio_costo'];
        $types .= "d";
    }
}

if (!empty($_GET['filtro_imagen'])) {
    if ($_GET['filtro_imagen'] == 'sin_imagen') {
        $where[] = "(p.imagen_url IS NULL OR p.imagen_url = '')";
    } elseif ($_GET['filtro_imagen'] == 'con_imagen') {
        $where[] = "(p.imagen_url IS NOT NULL AND p.imagen_url != '')";
    }
}

if (!empty($_GET['filtro_estado'])) {
    if ($_GET['filtro_estado'] == 'activos') {
        $where[] = "p.activo = 1";
    } elseif ($_GET['filtro_estado'] == 'inactivos') {
        $where[] = "p.activo = 0";
    }
}

if (!empty($_GET['filtro_rebaja'])) {
    if ($_GET['filtro_rebaja'] == 'con_rebaja') {
        $where[] = "p.porcentaje_rebaja > 0";
    } elseif ($_GET['filtro_rebaja'] == 'sin_rebaja') {
        $where[] = "(p.porcentaje_rebaja IS NULL OR p.porcentaje_rebaja = 0)";
    }
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// Filtrar por proveedor automáticamente
if ($proveedor_id_filtro > 0) {
    if (!empty($where)) {
        $sql_where .= " AND p.proveedor_id = $proveedor_id_filtro";
    } else {
        $sql_where = "WHERE p.proveedor_id = $proveedor_id_filtro";
    }
}

// ============================================
// OBTENER DATOS ESTÁTICOS (FILTRADOS POR PROVEEDOR)
// ============================================
$stats = [];

// Si es proveedor, filtrar por su proveedor_id
$stats_proveedor_id = $proveedor_id_filtro > 0 ? $proveedor_id_filtro : (isset($_GET['proveedor_id']) ? intval($_GET['proveedor_id']) : 0);

// Stats con bind_param
$productos_autocomplete_arr = [];

if ($stats_proveedor_id > 0) {
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE proveedor_id = ?");
    $stmt->bind_param("i", $stats_proveedor_id);
    $stmt->execute();
    $stats['total_productos'] = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $stmt->close();
    
    $stmt = $conn->prepare("SELECT SUM(precio_costo * cantidad) as total FROM productos WHERE proveedor_id = ?");
    $stmt->bind_param("i", $stats_proveedor_id);
    $stmt->execute();
    $stats['costo_inventario'] = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $stmt->close();
    
    $stmt = $conn->prepare("SELECT SUM(precio * cantidad) as total FROM productos WHERE proveedor_id = ?");
    $stmt->bind_param("i", $stats_proveedor_id);
    $stmt->execute();
    $stats['venta_inventario'] = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $stmt->close();
    
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE activo = 0 AND proveedor_id = ?");
    $stmt->bind_param("i", $stats_proveedor_id);
    $stmt->execute();
    $inactivos = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $stmt->close();
    
    $stmt = $conn->prepare("SELECT id, nombre FROM productos WHERE proveedor_id = ? ORDER BY nombre LIMIT 100");
    $stmt->bind_param("i", $stats_proveedor_id);
    $stmt->execute();
    $res_auto = $stmt->get_result();
    while ($row = $res_auto->fetch_assoc()) {
        $productos_autocomplete_arr[] = $row;
    }
    $stmt->close();
} else {
    $result = $conn->query("SELECT COUNT(*) as total FROM productos");
    $stats['total_productos'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT SUM(precio_costo * cantidad) as total FROM productos");
    $stats['costo_inventario'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT SUM(precio * cantidad) as total FROM productos");
    $stats['venta_inventario'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM productos WHERE activo = 0");
    $inactivos = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT id, nombre FROM productos ORDER BY nombre LIMIT 100");
    while ($row = $result->fetch_assoc()) {
        $productos_autocomplete_arr[] = $row;
    }
}

$filtros_aplicados = [];
if (!empty($_GET['nombre'])) $filtros_aplicados[] = "Nombre: " . $_GET['nombre'];
if (!empty($_GET['precio_costo'])) $filtros_aplicados[] = "Precio Costo: " . ($_GET['costo_operador'] ?? '=') . " $" . $_GET['precio_costo'];
if (!empty($_GET['filtro_imagen'])) {
    $texto_imagen = $_GET['filtro_imagen'] == 'sin_imagen' ? 'Sin imagen' : 'Con imagen';
    $filtros_aplicados[] = "Imagen: " . $texto_imagen;
}
if (!empty($_GET['filtro_estado'])) {
    $texto_estado = $_GET['filtro_estado'] == 'activos' ? 'Activos' : 'Inactivos';
    $filtros_aplicados[] = "Estado: " . $texto_estado;
}
if (!empty($_GET['filtro_rebaja'])) {
    $texto_rebaja = $_GET['filtro_rebaja'] == 'con_rebaja' ? 'Con rebaja' : 'Sin rebaja';
    $filtros_aplicados[] = "Rebaja: " . $texto_rebaja;
}
$texto_filtros = !empty($filtros_aplicados) ? implode(' | ', $filtros_aplicados) : 'Sin filtros';
?>

<!-- ESTILOS (todos tus estilos, se mantienen igual) -->
<style>
/* ============================================ */
/* TUS ESTILOS ORIGINALES COMPLETOS */
/* ============================================ */
:root {
    --primary: <?php echo $color_primario; ?>;
    --secondary: <?php echo $color_secundario; ?>;
    --danger: #f56565;
}

.acciones-superiores { display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; justify-content: flex-end; }
.btn-accion-superior { padding: 0.6rem 1.2rem; border-radius: 8px; font-weight: 600; font-size: 0.9rem; cursor: pointer; transition: all 0.2s; border: none; color: white; }
.btn-imprimir { background: #4299e1; }
.btn-excel { background: #48bb78; }
.btn-importar { background: #9f7aea; }
.btn-accion-superior:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.2); }

.floating-actions-btn {
    position: fixed; top: 20px; left: 20px; z-index: 1001;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white; width: 45px; height: 45px; border-radius: 50%;
    display: none; align-items: center; justify-content: center; font-size: 1.3rem;
    cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.2); border: 2px solid white;
    transition: all 0.3s ease;
}
@media (max-width: 768px) { .acciones-superiores { display: none; } .floating-actions-btn { display: flex; } }
.floating-actions-btn:hover { transform: scale(1.1); }

.actions-floating-menu {
    position: fixed; top: 75px; left: 20px; background: white; border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15); z-index: 1000; min-width: 200px;
    overflow: hidden; display: none;
}
.actions-floating-menu.show { display: block; }
.actions-floating-menu a, .actions-floating-menu button {
    display: flex; align-items: center; gap: 10px; width: 100%; padding: 12px 16px;
    border: none; background: white; text-decoration: none; color: #2d3748;
    font-size: 0.9rem; font-weight: 500; cursor: pointer; transition: all 0.2s; text-align: left;
}
.actions-floating-menu a:hover, .actions-floating-menu button:hover { background: #f7fafc; color: var(--primary); }
.actions-floating-menu hr { margin: 0; border-top: 1px solid #e2e8f0; }

.dashboard-mini { margin-bottom: 2rem; margin-top: 2rem; }
.stats-grid-mini { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; }
.stat-card-mini {
    background: white; border-radius: 12px; padding: 0.8rem 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    display: flex; align-items: center; gap: 0.8rem; transition: all 0.2s;
}
.stat-card-mini:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.stat-icon { font-size: 1.8rem; line-height: 1; }
.stat-content { flex: 1; }
.stat-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.5px; color: #718096; font-weight: 600; }
.stat-value { font-size: 1.1rem; font-weight: 700; color: #2d3748; line-height: 1.2; }

.filtros-card { background: white; border-radius: 12px; padding: 1.5rem; margin-bottom: 2rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
.search-container { position: relative; width: 100%; }
.autocomplete-list {
    position: absolute; top: 100%; left: 0; right: 0; background: white;
    border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;
    max-height: 300px; overflow-y: auto; z-index: 1000; box-shadow: 0 10px 15px rgba(0,0,0,0.1);
    display: none;
}
.autocomplete-list.show { display: block; }
.autocomplete-item {
    padding: 0.8rem 1rem; cursor: pointer; transition: all 0.2s; border-bottom: 1px solid #f0f0f0;
}
.autocomplete-item:hover { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
.autocomplete-item:last-child { border-bottom: none; }
.autocomplete-item strong { font-weight: 600; }
.autocomplete-item small { margin-left: 0.5rem; color: #a0aec0; }

.productos-table-card { background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.05); width: 100%; }
.table-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.table-header h3 { font-size: 1.1rem; color: #4a5568; }
.table-header-right { display: flex; gap: 0.5rem; align-items: center; }
.table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; width: 100%; scroll-behavior: smooth; }

.tabla-moderna { width: 100%; border-collapse: collapse; font-size: 0.85rem; min-width: 1300px; }
.tabla-moderna th {
    text-align: left; padding: 0.7rem 0.5rem;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white; font-weight: 600; font-size: 0.7rem; text-transform: uppercase;
    letter-spacing: 0.3px; border-bottom: 2px solid #e2e8f0; white-space: nowrap;
}
.tabla-moderna th a { color: white; text-decoration: none; display: flex; align-items: center; gap: 4px; }
.tabla-moderna td { padding: 0.7rem 0.5rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; white-space: normal; word-wrap: break-word; }

.img-thumbnail { width: 45px; height: 45px; object-fit: cover; border-radius: 8px; border: 1px solid #e2e8f0; }
.sin-imagen { width: 45px; height: 45px; background: #fed7d7; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #c53030; font-size: 1.2rem; border: 1px solid #feb2b2; }

.badge-categoria { background: #f0f4f8; padding: 0.2rem 0.5rem; border-radius: 20px; font-size: 0.7rem; white-space: normal; }
.badge-cantidad { display: inline-block; padding: 0.2rem 0.5rem; border-radius: 20px; background: #e2e8f0; font-weight: 600; min-width: 35px; text-align: center; font-size: 0.75rem; }
.badge-cantidad.sin-stock { background: #fed7d7; color: #c53030; }
.badge-cantidad.bajo-stock { background: #feebc8; color: #c05621; }

.badge-estado { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.7rem; font-weight: 600; text-align: center; white-space: nowrap; }
.badge-activo { background: #f0fff4; color: #22543d; border: 1px solid #9ae6b4; }
.badge-inactivo { background: #fff5f5; color: #742a2a; border: 1px solid #feb2b2; }
.badge-rebaja { background: #ef4444; color: white; padding: 0.2rem 0.5rem; border-radius: 20px; font-size: 0.7rem; font-weight: 600; display: inline-block; }

.text-right { text-align: right; }
.text-center { text-align: center; }

.acciones { white-space: nowrap; display: flex; gap: 0.2rem; justify-content: flex-end; align-items: center; }
.btn-icono { display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; padding: 0; margin: 0; text-decoration: none; border-radius: 6px; transition: all 0.2s; font-size: 0.85rem; }
.btn-icono:hover { background: #edf2f7; transform: scale(1.1); }

.sin-datos { padding: 3rem; color: #a0aec0; font-size: 1rem; text-align: center; }
.btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-size: 0.9rem; font-weight: 600; transition: all 0.2s; }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(102,126,234,0.3); }

/* Modal de importación */
.modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(5px); z-index: 2000; animation: fadeIn 0.3s ease; }
.modal-contenido { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 2.5rem; border-radius: 16px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 30px rgba(0,0,0,0.2); animation: slideUp 0.3s ease; }
@keyframes slideUp { from { transform: translate(-50%, -30%); opacity: 0; } to { transform: translate(-50%, -50%); opacity: 1; } }
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
.close-modal { position: absolute; top: 1rem; right: 1.5rem; font-size: 2rem; cursor: pointer; color: #a0aec0; transition: color 0.3s; }
.close-modal:hover { color: #2d3748; }
.btn-plantilla { display: inline-block; background: #4299e1; color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-size: 0.9rem; font-weight: 600; margin-bottom: 1rem; text-align: center; width: 100%; }
.btn-plantilla:hover { background: #3182ce; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(66,153,225,0.3); }

.toast-container { position: fixed; top: 20px; right: 20px; z-index: 3000; }
.toast-notificacion { position: relative; min-width: 300px; max-width: 450px; margin-bottom: 10px; padding: 15px 20px; background: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); display: flex; align-items: center; justify-content: space-between; animation: slideIn 0.3s ease; border-left: 4px solid; font-weight: 500; }
.toast-notificacion.exito { border-left-color: #48bb78; background: #f0fff4; color: #22543d; }
.toast-notificacion.error { border-left-color: #f56565; background: #fff5f5; color: #742a2a; }
.toast-notificacion.info { border-left-color: #4299e1; background: #ebf8ff; color: #2c5282; }
.toast-cerrar { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #718096; padding: 0 5px; margin-left: 10px; line-height: 1; }
.toast-cerrar:hover { color: #2d3748; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

/* ===== ESTILOS PARA SELECCIÓN MÚLTIPLE ===== */
.checkbox-col { width: 40px; text-align: center; padding: 0.5rem !important; }
.checkbox-producto, .select-all-checkbox { width: 18px; height: 18px; cursor: pointer; accent-color: var(--primary); margin: 0 auto; display: block; }

/* Barra de desplazamiento horizontal fija */
.horizontal-scroll-container { position: fixed; bottom: 20px; left: 0; right: 0; z-index: 1000; display: none; justify-content: center; pointer-events: none; }
.horizontal-scroll-bar { width: 80%; max-width: 800px; height: 8px; background: #e2e8f0; border-radius: 4px; cursor: pointer; pointer-events: auto; position: relative; }
.horizontal-scroll-thumb { width: 100px; height: 8px; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); border-radius: 4px; cursor: pointer; transition: width 0.1s; position: relative; }
.horizontal-scroll-thumb:hover { background: var(--primary); height: 10px; margin-top: -1px; }
.table-responsive::-webkit-scrollbar { height: 6px; }
.table-responsive::-webkit-scrollbar-track { background: #e2e8f0; border-radius: 3px; }
.table-responsive::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 3px; }

/* ESTILOS PARA IMPRESIÓN */
@media print {
    @page { size: letter landscape; margin: 0.5cm; }
    body * { visibility: hidden; }
    .printable-area, .printable-area * { visibility: visible; }
    .printable-area { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 0; }
    .table-responsive { overflow: visible !important; width: 100% !important; }
    .tabla-moderna { width: 100% !important; min-width: 0 !important; font-size: 8pt; border-collapse: collapse; }
    .tabla-moderna th, .tabla-moderna td { border: 1px solid #000; padding: 4px; white-space: normal !important; word-wrap: break-word; }
    .no-print, .floating-actions-btn, .actions-floating-menu, .acciones-superiores, .dashboard-mini,
    .filtros-card, .table-header, .btn-icono, .modal-overlay, .toast-container, .img-thumbnail,
    .sin-imagen, .badge-estado, .checkbox-col, .horizontal-scroll-container, .btn-primary {
        display: none !important;
    }
    .encabezado-impresion { display: block !important; text-align: center; margin-bottom: 15px; }
    .encabezado-impresion h1 { font-size: 14pt; margin: 0 0 5px 0; font-weight: bold; }
    .encabezado-impresion p { font-size: 9pt; margin: 2px 0; color: #000; }
    .pie-impresion { display: block !important; margin-top: 15px; font-size: 8pt; text-align: right; border-top: 1px solid #000; padding-top: 8px; }
    .badge-categoria, .badge-cantidad { display: inline-block !important; background: transparent !important; color: #000 !important; padding: 0 !important; border: none !important; font-size: 8pt !important; }
}

/* Botón flotante universal */
.floating-counter { position: fixed; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; font-weight: bold; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 1000; transition: all 0.3s ease; border: 2px solid white; display: none; align-items: center; justify-content: center; gap: 5px; }
.floating-counter:hover { transform: scale(1.05); }
.floating-counter.show { display: flex; }
@media (min-width: 769px) { .floating-counter { bottom: 20px; right: 20px; padding: 12px 20px; border-radius: 50px; font-size: 1rem; min-width: auto; } }
@media (max-width: 768px) { .floating-counter { top: 150px; left: 20px; width: 45px; height: 45px; border-radius: 50%; font-size: 1.1rem; padding: 0; } }
 @media (max-width: 768px) {
    .floating-actions-btn {
        display: none !important;
    }
}   

/* Menú flotante de acciones */
.floating-actions-menu-pc {
    position: fixed; background: white; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    z-index: 1000; min-width: 200px; overflow: hidden; display: none; border: 1px solid #e2e8f0;
}
.floating-actions-menu-pc.show { display: block; animation: fadeInUp 0.2s ease; }
@keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.floating-actions-menu-pc button {
    display: flex; align-items: center; gap: 12px; width: 100%; padding: 12px 16px;
    border: none; background: white; color: #2d3748; font-size: 0.9rem; font-weight: 500;
    cursor: pointer; transition: all 0.2s; text-align: left;
}
.floating-actions-menu-pc button:hover { background: #f7fafc; }
.floating-actions-menu-pc hr { margin: 0; border-top: 1px solid #e2e8f0; }
@media (min-width: 769px) { .floating-actions-menu-pc { bottom: 90px; right: 20px; } }
@media (max-width: 768px) { .floating-actions-menu-pc { top: 125px; left: 20px; } }

@media (max-width: 768px) {
    .stats-grid-mini { grid-template-columns: 1fr; }
    .table-header { flex-direction: column; align-items: flex-start; }
    .toast-notificacion { min-width: 250px; max-width: 300px; }
    .floating-actions-btn { width: 40px; height: 40px; font-size: 1.1rem; top: 15px; left: 15px; display: flex; }
    .actions-floating-menu { top: 65px; left: 15px; min-width: 180px; }
    .actions-floating-menu a, .actions-floating-menu button { padding: 10px 14px; font-size: 0.85rem; }
}
body { padding-top: 130px !important; }

/* FORZAR ANCHOS DIFERENTES POR COLUMNA */
.tabla-moderna { table-layout: fixed !important; width: 100% !important; }

/* Columna 1: ID (oculta) */
.tabla-moderna th:nth-child(1) { display: none; }
.tabla-moderna td:nth-child(1) { display: none; }

/* Columna 2: Checkbox */
.tabla-moderna th:nth-child(2) { width: 30px !important; }
.tabla-moderna td:nth-child(2) { width: 30px !important; text-align: center; }

/* Columna 3: Imagen */
.tabla-moderna th:nth-child(3) { width: 45px !important; }
.tabla-moderna td:nth-child(3) { width: 45px !important; }

/* Columna 4: Nombre + Marca */
.tabla-moderna th:nth-child(4) { width: 150px !important; }
.tabla-moderna td:nth-child(4) { width: 150px !important; }

/* Columna 5: Categoría */
.tabla-moderna th:nth-child(5) { width: 100px !important; }
.tabla-moderna td:nth-child(5) { width: 100px !important; }

/* Columna 6: Cantidad */
.tabla-moderna th:nth-child(6) { width: 60px !important; }
.tabla-moderna td:nth-child(6) { width: 60px !important; }

/* Columna 7: Peso (kg) */
.tabla-moderna th:nth-child(7) { width: 50px !important; }
.tabla-moderna td:nth-child(7) { width: 50px !important; }

/* Columna 8: P. Costo + I. Costo */
.tabla-moderna th:nth-child(8) { width: 80px !important; }
.tabla-moderna td:nth-child(8) { width: 80px !important; }

/* Columna 9: P. Venta + I. Venta */
.tabla-moderna th:nth-child(9) { width: 80px !important; }
.tabla-moderna td:nth-child(9) { width: 80px !important; }

/* Columna 10: Rebaja */
.tabla-moderna th:nth-child(10) { width: 50px !important; }
.tabla-moderna td:nth-child(10) { width: 50px !important; }

/* Columna 11: Estado */
.tabla-moderna th:nth-child(11) { width: 80px !important; }
.tabla-moderna td:nth-child(11) { width: 80px !important; }

/* Columna 12: Fecha */
.tabla-moderna th:nth-child(12) { width: 90px !important; }
.tabla-moderna td:nth-child(12) { width: 90px !important; }

/* Columna 13: Acciones - solo contenido alineado a la derecha */
.tabla-moderna td:nth-child(13) { 
    width: 100px !important; 
    text-align: right !important;
}
.tabla-moderna td:nth-child(13) .acciones {
    justify-content: flex-end;
    width: 100%;
}

/* Cabecera de acciones se mantiene centrada */
.tabla-moderna th:nth-child(13) { 
    width: 100px !important; 
    text-align: center !important;
}

.tabla-moderna th:first-child, .tabla-moderna td:first-child { display: none; }
    
    /* Modal de edición */
.modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
    z-index: 2000;
    animation: fadeIn 0.3s ease;
}

.modal-contenido {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 2rem;
    border-radius: 16px;
    max-width: 700px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 30px rgba(0,0,0,0.2);
}

/* Estilos responsive para móvil */
@media (max-width: 640px) {
    .modal-contenido {
        width: 95%;
        padding: 1rem;
    }
    
    .modal-contenido h2 {
        font-size: 1.2rem;
        margin-bottom: 1rem;
    }
    
    /* Campos en una sola columna en móvil */
    .modal-contenido .form-grid {
        grid-template-columns: 1fr !important;
        gap: 0.8rem !important;
    }
    
    /* Botones a ancho completo en móvil */
    .modal-contenido .form-actions {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .modal-contenido .btn {
        width: 100%;
        margin: 0;
    }
    
    /* Evitar zoom en iOS al hacer foco */
    .modal-contenido input,
    .modal-contenido select,
    .modal-contenido textarea {
        font-size: 16px !important;
    }
    
    /* Cerrar modal más grande para touch */
    .close-modal {
        top: 0.5rem;
        right: 1rem;
        font-size: 1.8rem;
    }
}
    
    /* Ajuste general para todas las celdas */
.tabla-moderna td {
    white-space: normal;
    word-wrap: break-word;
}

/* Acciones y checkbox se mantienen en una línea */
.tabla-moderna td:last-child,
.tabla-moderna td.checkbox-col {
    white-space: nowrap;
}
</style>

<!-- CONTENIDO PRINCIPAL -->
<div class="acciones-superiores">
    <button class="btn-accion-superior btn-imprimir" onclick="window.print()">🖨️ Imprimir</button>
    <button class="btn-accion-superior btn-excel" <button onclick="window.location.href='exportar_excel_productos.php?<?php echo http_build_query($_GET); ?>'">📊 Exportar Excel</button>
    <?php if ($puede_gestionar): ?>
    <button class="btn-accion-superior btn-importar" onclick="abrirModalImportar()">📤 Importar CSV</button>
    <?php endif; ?>
</div>

<div class="floating-actions-btn" onclick="toggleActionsMenu()">☰</div>
<div class="actions-floating-menu" id="actionsMenu">
    <button onclick="window.print()">🖨️ Imprimir</button>
    <button onclick="window.location.href='exportar_excel_productos.php?<?php echo http_build_query($_GET); ?>'">📊 Exportar Excel</button>
    <?php if ($puede_gestionar): ?>
        <button onclick="abrirModalImportar()">📤 Importar CSV</button>
    <?php endif; ?>
    <?php if (($_GET['filtro_estado'] ?? '') == 'inactivos' && $inactivos > 0 && $puede_gestionar): ?>
        <hr>
        <a href="?activar_todos=1&filtro_estado=inactivos&csrf_token=<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>" onclick="return confirm('¿Activar todos los productos inactivos? (<?php echo $inactivos; ?> productos)')">✅ Activar todos (<?php echo $inactivos; ?>)</a>
    <?php endif; ?>
</div>

<div class="dashboard-mini">
    <div class="stats-grid-mini">
        <div class="stat-card-mini"><div class="stat-icon">📦</div><div class="stat-content"><div class="stat-label">Total Productos</div><div class="stat-value"><?php echo $stats['total_productos']; ?></div></div></div>
        <div class="stat-card-mini"><div class="stat-icon">💰</div><div class="stat-content"><div class="stat-label">Costo Inventario</div><div class="stat-value">$<?php echo number_format($stats['costo_inventario'], 2); ?></div></div></div>
        <div class="stat-card-mini"><div class="stat-icon">💵</div><div class="stat-content"><div class="stat-label">Venta Inventario</div><div class="stat-value">$<?php echo number_format($stats['venta_inventario'], 2); ?></div></div></div>
    </div>
</div>

<div class="filtros-card">
    <h3 style="margin-bottom: 1rem; font-size: 1rem; color: #4a5568;">🔍 Filtrar Productos</h3>
    <form method="GET" class="filtros-form" id="filtrosForm">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <div style="display: flex; gap: 0.8rem; align-items: flex-end; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 140px; position: relative;">
    <label style="display: block; font-size: 0.7rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem;">📝 Nombre</label>
    <div class="search-container">
        <input type="text" id="busqueda_vivo" name="nombre" value="<?php echo htmlspecialchars($_GET['nombre'] ?? ''); ?>" placeholder="Buscar..." style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem;">
        <div id="autocomplete_list" class="autocomplete-list"></div>
    </div>
</div>

<div style="flex: 1; min-width: 140px;">
    <label style="display: block; font-size: 0.7rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem;">📂 Categoría</label>
    <select name="categoria_id" id="filtro_categoria" style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
        <option value="">Todas</option>
        <?php
        $categorias_filtro = $conn->query("SELECT id, nombre, icono FROM categorias ORDER BY nombre");
        while($cat = $categorias_filtro->fetch_assoc()):
            $selected = (isset($_GET['categoria_id']) && $_GET['categoria_id'] == $cat['id']) ? 'selected' : '';
        ?>
            <option value="<?php echo $cat['id']; ?>" <?php echo $selected; ?>>
                <?php echo $cat['icono'] ?? '📦'; ?> <?php echo htmlspecialchars($cat['nombre']); ?>
            </option>
        <?php endwhile; ?>
    </select>
</div>
            
           <!-- FILTRO PROVEEDOR - SOLO PARA SUPER ADMIN Y GERENTE -->
<?php if (in_array($rol_actual, ['Super Admin', 'Gerente', 'Supervisor', 'Contador'])): ?>
<div style="flex: 1; min-width: 140px;">
    <label style="display: block; font-size: 0.7rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem;">🏪 Proveedor</label>
    <select name="proveedor_id" id="filtro_proveedor" style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
        <option value="">Todos</option>
        <?php
        $proveedores_filtro = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda");
        while($prov = $proveedores_filtro->fetch_assoc()):
            $selected = (isset($_GET['proveedor_id']) && $_GET['proveedor_id'] == $prov['id']) ? 'selected' : '';
        ?>
            <option value="<?php echo $prov['id']; ?>" <?php echo $selected; ?>>
                🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
            </option>
        <?php endwhile; ?>
    </select>
</div>
<?php endif; ?>
            
            <div style="flex: 1.5; min-width: 160px;">
                <label style="display: block; font-size: 0.7rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem;">💰 Precio Costo</label>
                <div style="display: flex; gap: 0.3rem;">
                    <select name="costo_operador" id="costo_operador" style="width: 70px; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
                        <option value="=" <?php echo ($_GET['costo_operador'] ?? '') == '=' ? 'selected' : ''; ?>>=</option>
                        <option value="<" <?php echo ($_GET['costo_operador'] ?? '') == '<' ? 'selected' : ''; ?>>&lt;</option>
                        <option value=">" <?php echo ($_GET['costo_operador'] ?? '') == '>' ? 'selected' : ''; ?>>></option>
                    </select>
                    <input type="number" name="precio_costo" id="precio_costo" step="0.01" value="<?php echo htmlspecialchars($_GET['precio_costo'] ?? ''); ?>" placeholder="0.00" style="flex: 1; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
                </div>
            </div>
            <div style="flex: 1; min-width: 100px;">
                <label style="display: block; font-size: 0.7rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem;">🖼️ Imagen</label>
                <select name="filtro_imagen" id="filtro_imagen" style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
                    <option value="">Todos</option>
                    <option value="sin_imagen" <?php echo ($_GET['filtro_imagen'] ?? '') == 'sin_imagen' ? 'selected' : ''; ?>>Sin imagen</option>
                    <option value="con_imagen" <?php echo ($_GET['filtro_imagen'] ?? '') == 'con_imagen' ? 'selected' : ''; ?>>Con imagen</option>
                </select>
            </div>
            <div style="flex: 1; min-width: 100px;">
                <label style="display: block; font-size: 0.7rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem;">⚡ Estado</label>
                <select name="filtro_estado" id="filtro_estado" style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
                    <option value="">Todos</option>
                    <option value="activos" <?php echo ($_GET['filtro_estado'] ?? '') == 'activos' ? 'selected' : ''; ?>>Activos</option>
                    <option value="inactivos" <?php echo ($_GET['filtro_estado'] ?? '') == 'inactivos' ? 'selected' : ''; ?>>Inactivos</option>
                </select>
            </div>
            <div style="flex: 1; min-width: 100px;">
                <label style="display: block; font-size: 0.7rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem;">🏷️ Rebaja</label>
                <select name="filtro_rebaja" id="filtro_rebaja" style="width: 100%; padding: 0.5rem; border: 2px solid #e2e8f0; border-radius: 8px;">
                    <option value="">Todos</option>
                    <option value="con_rebaja" <?php echo ($_GET['filtro_rebaja'] ?? '') == 'con_rebaja' ? 'selected' : ''; ?>>Con rebaja</option>
                    <option value="sin_rebaja" <?php echo ($_GET['filtro_rebaja'] ?? '') == 'sin_rebaja' ? 'selected' : ''; ?>>Sin rebaja</option>
                </select>
            </div>
            <div style="display: flex; gap: 0.5rem;">
                <button type="submit" id="btnFiltrarAjax" style="padding: 0.5rem 1rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">Filtrar</button>
                <a href="admin.php" id="btnLimpiarAjax" style="padding: 0.5rem 1rem; background: #edf2f7; color: #4a5568; text-align: center; text-decoration: none; border-radius: 8px; font-weight: 600;">Limpiar</a>
            </div>
        </div>
    </form>
</div>

<!-- CONTENEDOR DE TABLA (se carga dinámicamente) -->
<div id="tabla-contenedor">
    <div class="loading-spinner" style="text-align:center; padding:2rem;">🔄 Cargando productos...</div>
</div>

<!-- Botón flotante universal -->
<div id="floatingCounter" class="floating-counter">0</div>

<!-- Menú flotante de acciones -->
<div id="floatingActionsMenuPC" class="floating-actions-menu-pc">
    <button id="btnActivarMasivo">🟢 Activar seleccionados</button>
    <button id="btnDesactivarMasivo">🔴 Desactivar seleccionados</button>
    <button id="btnAplicarRebaja">🏷️ Aplicar rebaja</button>
    <hr>
    <button id="btnCalcularVenta">💵 Calcular Venta (seleccionados)</button>
    <button id="btnCalcularVentaTodos">🔄 Recalcular TODO (proveedor actual)</button>
    <hr>
    <button id="btnLimpiarSeleccion">✖ Limpiar selección</button>
</div>

<!-- Modal de importación -->
<div class="modal-overlay" id="modalImportar">
    <div class="modal-contenido" style="max-width: 900px;">
        <span class="close-modal" onclick="cerrarModalImportar()">&times;</span>
        <?php include __DIR__ . '/importar_productos.php'; ?>
    </div>
</div>

<div class="toast-container" id="toast-container"></div>

<!-- Barra de desplazamiento horizontal fija -->
<div class="horizontal-scroll-container" id="horizontalScrollContainer">
    <div class="horizontal-scroll-bar" id="scrollBar">
        <div class="horizontal-scroll-thumb" id="scrollThumb"></div>
    </div>
</div>

<!-- ============================================ -->
<!-- MODAL PARA APLICAR REBAJA MASIVA -->
<!-- ============================================ -->
<div id="modalRebajaMasiva" class="modal-overlay" style="display: none;">
    <div class="modal-contenido" style="max-width: 400px; text-align: center;">
        <span class="close-modal" onclick="cerrarModalRebajaMasiva()">&times;</span>
        <h3 style="margin-bottom: 1rem;">🏷️ Aplicar Rebaja Masiva</h3>
        <p style="color: #4a5568; margin-bottom: 1rem;">
            Productos seleccionados: <strong id="contadorRebajaMasiva">0</strong>
        </p>
        <div style="margin-bottom: 1rem;">
            <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">Porcentaje de rebaja (%)</label>
            <input type="number" id="inputPorcentajeRebaja" min="0" max="100" step="0.01" 
                   style="width: 100%; padding: 0.8rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem; text-align: center;"
                   placeholder="Ej: 15">
            <small style="color: #6b7280; font-size: 0.7rem;">0 = eliminar rebaja</small>
        </div>
        <div style="display: flex; gap: 0.5rem; justify-content: center;">
            <button onclick="cerrarModalRebajaMasiva()" style="padding: 0.6rem 1.5rem; background: #edf2f7; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Cancelar</button>
            <button id="btnConfirmarRebajaMasiva" style="padding: 0.6rem 1.5rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">✅ Aplicar</button>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- MODAL DE CONFIRMACIÓN: PRODUCTO EN COMBOS -->
<!-- ============================================ -->
<div id="modalConfirmarDesactivarCombos" class="modal-overlay" style="display: none;">
    <div class="modal-contenido" style="max-width: 450px; text-align: left;">
        <span class="close-modal" onclick="cerrarModalDesactivarCombos()">&times;</span>
        <h3 style="margin-bottom: 0.5rem; color: #2d3748;">⚠️ Producto en combos activos</h3>
        <p style="color: #4a5568; font-size: 0.9rem; margin-bottom: 0.75rem;">
            Al desactivar, se liberará su reserva en estos combos, quedará con cantidad <strong>0</strong> (opaco) y se recalcularán los combos:
        </p>
        <div id="listaCombosAfectadosDesactivar" style="background: #fef5e7; border-radius: 8px; padding: 0.75rem; margin-bottom: 1rem; font-size: 0.85rem; max-height: 180px; overflow-y: auto;"></div>
        <div style="display: flex; gap: 0.5rem; justify-content: flex-end;">
            <button type="button" onclick="cerrarModalDesactivarCombos()" style="padding: 0.55rem 1.2rem; background: #edf2f7; color: #4a5568; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                Cancelar
            </button>
            <button type="button" id="btnConfirmarDesactivarCombos" style="padding: 0.55rem 1.2rem; background: #e53e3e; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                🔒 Desactivar
            </button>
        </div>
    </div>
</div>

<script>
const productosDB = [
    <?php foreach ($productos_autocomplete_arr as $p): ?>
        { id: <?php echo intval($p['id']); ?>, nombre: '<?php echo addslashes($p['nombre']); ?>' },
    <?php endforeach; ?>
];

// ============================================
// ROL ACTUAL (desde PHP)
// ============================================
const ROL_ACTUAL_JS = '<?php echo addslashes($rol_actual); ?>';
const ES_SUPER_ADMIN_JS = (ROL_ACTUAL_JS === 'Super Admin');
const ES_ROL_PROVEEDOR_JS = ['Proveedor', 'Inventario', 'Vendedor', 'Empaquetador', 'Transportista'].includes(ROL_ACTUAL_JS);

const busquedaInput = document.getElementById('busqueda_vivo');
const autocompleteList = document.getElementById('autocomplete_list');
let timeoutId = null;
let busquedaTimeout = null;

// ============================================
// FUNCIONES DE CARGA AJAX
// ============================================
function cargarTabla(params = {}) {
    const currentUrl = new URL(window.location.href);
    const searchParams = new URLSearchParams(currentUrl.search);
    
    // Actualizar o eliminar parámetros según lo recibido
    for (let [key, value] of Object.entries(params)) {
        if (value !== null && value !== undefined && value !== '') {
            searchParams.set(key, value);
        } else {
            searchParams.delete(key);
        }
    }
    
    // Si no se especifica página, resetear a 1 (evita páginas vacías al filtrar)
    if (!params.hasOwnProperty('pagina')) {
        searchParams.delete('pagina');
    }
    
    // Eliminar parámetros vacíos que puedan quedar
    for (let [key, value] of searchParams.entries()) {
        if (value === '' || value === null) {
            searchParams.delete(key);
        }
    }
    
    // 👇 AGREGAR ESTA LÍNEA: Asegurar que i=1 existe
    if (!searchParams.has('i')) {
        searchParams.set('i', '1');
    }
    
    const queryString = searchParams.toString();
    const url = 'admin_ajax_productos.php?' + queryString;
    
    const contenedor = document.getElementById('tabla-contenedor');
    if (!contenedor) return;
    contenedor.innerHTML = '<div class="loading-spinner" style="text-align:center; padding:2rem;">🔄 Cargando productos...</div>';
    
    fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(response => response.text())
        .then(html => {
            contenedor.innerHTML = html;
            reinicializarEventosTabla();
        })
        .catch(error => {
            console.error('Error:', error);
            contenedor.innerHTML = '<div class="sin-datos" style="padding:2rem;">❌ Error al cargar los productos</div>';
        });
}
    
function reinicializarEventosTabla() {
    document.querySelectorAll('.ajax-link').forEach(link => {
        link.removeEventListener('click', handleAjaxLink);
        link.addEventListener('click', handleAjaxLink);
    });
    document.querySelectorAll('.btn-pagina').forEach(btn => {
        if (!btn.classList.contains('disabled')) {
            btn.removeEventListener('click', handlePaginacionAjax);
            btn.addEventListener('click', handlePaginacionAjax);
        }
    });
    document.querySelectorAll('.ajax-toggle-estado').forEach(btn => {
        btn.removeEventListener('click', handleToggleEstadoAjax);
        btn.addEventListener('click', handleToggleEstadoAjax);
    });
    if (typeof window.cargarSeleccion === 'function') window.cargarSeleccion();
    
    // 👇 Agrega esta línea para que el contador se actualice después de cargar la tabla
    actualizarContador();
}

function handleAjaxLink(e) {
    e.preventDefault();
    const url = new URL(e.currentTarget.href);
    const params = Object.fromEntries(url.searchParams);
    
    // Mantener los filtros actuales del formulario
    const formData = new FormData(document.getElementById('filtrosForm'));
    for (let [key, value] of formData.entries()) {
        if (value && !params.hasOwnProperty(key)) {
            params[key] = value;
        }
    }
    
    // Mantener el parámetro 'i' de la URL actual si existe
    const urlActual = new URL(window.location.href);
    const iParam = urlActual.searchParams.get('i');
    if (iParam && !params.hasOwnProperty('i')) {
        params.i = iParam;
    }
    
    cargarTabla(params);
}

function handlePaginacionAjax(e) {
    e.preventDefault();
    const href = e.currentTarget.getAttribute('href');
    if (href && href !== '#') {
        const urlParams = new URLSearchParams(href.split('?')[1]);
        const pagina = urlParams.get('pagina');
        if (pagina) {
            // Obtener los filtros actuales desde el formulario
            const formData = new FormData(document.getElementById('filtrosForm'));
            const params = {};
            for (let [key, value] of formData.entries()) {
                if (value) params[key] = value;
            }
            
            // IMPORTANTE: Mantener el orden actual desde la URL del navegador
            const urlActual = new URL(window.location.href);
            const orderBy = urlActual.searchParams.get('order_by');
            const orderDir = urlActual.searchParams.get('order_dir');
            const iParam = urlActual.searchParams.get('i');
            
            if (orderBy) params.order_by = orderBy;
            if (orderDir) params.order_dir = orderDir;
            if (iParam) params.i = iParam;
            
            // Agregar la página
            params.pagina = pagina;
            
            cargarTabla(params);
        }
    }
}

let pendienteDesactivacion = null;

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML;
}

function cerrarModalDesactivarCombos() {
    const modal = document.getElementById('modalConfirmarDesactivarCombos');
    if (modal) modal.style.display = 'none';
    pendienteDesactivacion = null;
}

function aplicarEstadoVisualFilas(ids, nuevoEstado) {
    ids.forEach(id => {
        const checkbox = document.querySelector(`.checkbox-producto[value="${id}"]`);
        const fila = checkbox
            ? checkbox.closest('tr')
            : document.querySelector(`.ajax-toggle-estado[data-id="${id}"]`)?.closest('tr');
        if (!fila) return;

        const badgeEstado = fila.querySelector('.badge-estado');
        const btnToggle = fila.querySelector('.ajax-toggle-estado');

        if (badgeEstado) {
            badgeEstado.className = `badge-estado ${nuevoEstado === 1 ? 'badge-activo' : 'badge-inactivo'}`;
            badgeEstado.textContent = nuevoEstado === 1 ? '✅ Activo' : '❌ Inactivo';
        }

        if (btnToggle) {
            btnToggle.setAttribute('data-estado', nuevoEstado);
            btnToggle.textContent = nuevoEstado === 1 ? '🔴' : '🟢';
            btnToggle.title = nuevoEstado === 1 ? 'Desactivar' : 'Activar';
        }

        if (nuevoEstado === 0) {
            fila.style.opacity = '0.7';
            fila.style.background = '#fff5f5';
        } else {
            fila.style.opacity = '';
            fila.style.background = '';
        }
    });
}

function enviarAccionProductos(payload, onSuccess) {
    fetch('productos_acciones_masiva.php' + getProveedorIdParam(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(response => response.json())
    .then(data => {
        if (data.requires_confirmation && Array.isArray(data.combos_afectados) && data.combos_afectados.length > 0) {
            pendienteDesactivacion = { payload, onSuccess };
            const lista = document.getElementById('listaCombosAfectadosDesactivar');
            if (lista) {
                lista.innerHTML = data.combos_afectados
                    .map(c => `<div>🎁 <strong>${escaparHtml(c.nombre)}</strong> <span style="color:#718096;">(#${c.id})</span></div>`)
                    .join('');
            }
            const modal = document.getElementById('modalConfirmarDesactivarCombos');
            if (modal) modal.style.display = 'block';
            return;
        }

        if (data.success) {
            onSuccess(data);
        } else {
            mostrarNotificacion('❌ ' + (data.error || 'Error al procesar'), 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarNotificacion('❌ Error de conexión', 'error');
    });
}

document.getElementById('btnConfirmarDesactivarCombos')?.addEventListener('click', function () {
    if (!pendienteDesactivacion) return;
    const { payload, onSuccess } = pendienteDesactivacion;
    cerrarModalDesactivarCombos();
    mostrarNotificacion('⏳ Procesando...', 'info');
    enviarAccionProductos({ ...payload, confirmar_desactivar: true }, onSuccess);
});

document.addEventListener('click', function (e) {
    const modal = document.getElementById('modalConfirmarDesactivarCombos');
    if (modal && e.target === modal) {
        cerrarModalDesactivarCombos();
    }
});

function handleToggleEstadoAjax(e) {
    e.preventDefault();
    const link = e.currentTarget;
    const productoId = parseInt(link.getAttribute('data-id'), 10);
    const estadoActual = link.getAttribute('data-estado');
    const accion = estadoActual == '1' ? 'desactivar' : 'activar';

    const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || '';
    if (!csrfToken) {
        mostrarNotificacion('❌ Token de seguridad no encontrado', 'error');
        return;
    }

    // Solo confirmar nativo al ACTIVAR.
    // Al DESACTIVAR, el backend decide:
    //  - Si NO está en combos → desactiva directo (sin modal)
    //  - Si SÍ está en combos → abre el modal bonito con la lista
    if (accion === 'activar') {
        if (!confirm('¿Activar este producto?')) return;
    }

    enviarAccionProductos(
        { accion: accion, productos: [productoId], csrf_token: csrfToken },
        function () {
            const nuevoEstado = accion === 'activar' ? 1 : 0;
            aplicarEstadoVisualFilas([productoId], nuevoEstado);
            mostrarNotificacion(
                `✅ Producto ${accion === 'activar' ? 'activado' : 'desactivado'}`,
                'exito'
            );
        }
    );
}

// ============================================
// FILTROS VÍA AJAX (SIN RECARGAR)
// ============================================
function aplicarFiltros() {
    const formData = new FormData(document.getElementById('filtrosForm'));
    const params = {};
    for (let [key, value] of formData.entries()) {
        if (value) params[key] = value;
    }
    cargarTabla(params);
}

// Botones
document.getElementById('btnFiltrarAjax')?.addEventListener('click', function(e) {
    e.preventDefault();
    aplicarFiltros();
});

document.getElementById('btnLimpiarAjax')?.addEventListener('click', function(e) {
    e.preventDefault();
    
    // Resetear todos los campos del formulario de filtros
    const form = document.getElementById('filtrosForm');
    if (form) {
        form.reset();
    }
    
    // Resetear select de categoría también
const filtroCategoria = document.getElementById('filtro_categoria');
if (filtroCategoria) {
    filtroCategoria.value = '';
}
    
    // Limpiar el campo de búsqueda por si acaso
    const busquedaInput = document.getElementById('busqueda_vivo');
    if (busquedaInput) {
        busquedaInput.value = '';
    }
    
    // Limpiar los parámetros de la URL sin recargar la página
    const urlBase = window.location.pathname; // por ejemplo: /admin.php
    window.history.pushState({}, '', urlBase);
    
    // Recargar la tabla sin ningún filtro
    cargarTabla({});
    
    // Opcional: limpiar el autocomplete
    const autocompleteList = document.getElementById('autocomplete_list');
    if (autocompleteList) {
        autocompleteList.classList.remove('show');
        autocompleteList.innerHTML = '';
    }
});

// Selects automáticos (AJAX)
const selects = ['costo_operador', 'filtro_imagen', 'filtro_estado', 'filtro_rebaja', 'filtro_proveedor'];
selects.forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.addEventListener('change', aplicarFiltros); }
});
    
    // Select de categoría
const filtroCategoria = document.getElementById('filtro_categoria');
if (filtroCategoria) {
    filtroCategoria.addEventListener('change', aplicarFiltros);
}

// Precio Costo con delay
const precioCosto = document.getElementById('precio_costo');
if (precioCosto) {
    precioCosto.addEventListener('input', function() {
        if (timeoutId) clearTimeout(timeoutId);
        timeoutId = setTimeout(aplicarFiltros, 800);
    });
}

// Buscador con autocomplete (AJAX)
if (busquedaInput) {
    busquedaInput.addEventListener('input', function() {
        const termino = this.value.toLowerCase().trim();
        if (termino.length < 1) {
            autocompleteList.classList.remove('show');
            aplicarFiltros();
            return;
        }
        const resultados = productosDB.filter(p => p.nombre.toLowerCase().includes(termino)).slice(0, 10);
        if (resultados.length > 0) {
            mostrarResultados(resultados);
        } else {
            autocompleteList.classList.remove('show');
        }
        if (busquedaTimeout) clearTimeout(busquedaTimeout);
        busquedaTimeout = setTimeout(aplicarFiltros, 800);
    });
}

function mostrarResultados(resultados) {
    autocompleteList.innerHTML = '';
    resultados.forEach(p => {
        const item = document.createElement('div');
        item.className = 'autocomplete-item';
        item.innerHTML = `<strong>${p.nombre}</strong> <small>#${p.id}</small>`;
        item.addEventListener('click', function() { seleccionarProducto(p.nombre); });
        autocompleteList.appendChild(item);
    });
    autocompleteList.classList.add('show');
}

function seleccionarProducto(nombre) {
    busquedaInput.value = nombre;
    autocompleteList.classList.remove('show');
    aplicarFiltros();
}

document.addEventListener('click', function(e) {
    if (!busquedaInput.contains(e.target) && !autocompleteList.contains(e.target)) {
        autocompleteList.classList.remove('show');
    }
});

// ============================================
// NOTIFICACIONES Y MODALES
// ============================================
function mostrarNotificacion(mensaje, tipo = 'exito') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast-notificacion ' + tipo;
    toast.innerHTML = `<span>${mensaje}</span><button class="toast-cerrar" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => { if (toast.parentElement) toast.remove(); }, 5000);
}

// ============================================
// HELPER: obtener ?proveedor_id=X
//
// - Roles de proveedor (Proveedor, Inventario, etc.):
//   NO usan ?proveedor_id=X. El backend detecta
//   el proveedor del usuario logueado.
//
// - Super Admin / Gerente / Supervisor / Contador:
//   SÍ requieren ?proveedor_id=X. Se lee del GET
//   o del <select id="filtro_proveedor">.
//   Si no hay ninguno → devuelve '' → backend da error.
// ============================================
function getProveedorIdParam() {
    // Roles de proveedor: no usar ?proveedor_id=X
    if (ES_ROL_PROVEEDOR_JS) {
        return '';
    }
    
    // Super Admin / Gerente / Supervisor / Contador:
    // 1. Intentar del GET
    const urlParams = new URLSearchParams(window.location.search);
    let proveedorId = urlParams.get('proveedor_id') || '';
    
    // 2. Si no viene del GET, leer del <select> del filtro
    if (!proveedorId) {
        const selectProveedor = document.getElementById('filtro_proveedor');
        if (selectProveedor && selectProveedor.value) {
            proveedorId = selectProveedor.value;
        }
    }
    
    return proveedorId ? '?proveedor_id=' + proveedorId : '';
}

function abrirModalImportar() { document.getElementById('modalImportar').style.display = 'block'; }
function cerrarModalImportar() { document.getElementById('modalImportar').style.display = 'none'; }

window.onclick = function(event) {
    const modal = document.getElementById('modalImportar');
    if (event.target == modal) { modal.style.display = 'none'; }
}

function toggleActionsMenu() {
    const menu = document.getElementById('actionsMenu');
    menu.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    const menu = document.getElementById('actionsMenu');
    const btn = document.querySelector('.floating-actions-btn');
    if (btn && !btn.contains(event.target) && !menu.contains(event.target)) {
        menu.classList.remove('show');
    }
});

// ============================================
// SELECCIÓN MÚLTIPLE (PERSISTENTE)
// ============================================
let seleccionados = new Set();

function guardarSeleccion() { sessionStorage.setItem('productosSeleccionados', JSON.stringify([...seleccionados])); }
function cargarSeleccion() {
    // Verificar si es una recarga completa de la página (no una carga AJAX)
    if (window.performance && window.performance.navigation) {
        // Si es recarga manual (F5 o Ctrl+R)
        if (window.performance.navigation.type === 1) {
            sessionStorage.removeItem('productosSeleccionados');
            seleccionados = new Set();
            actualizarTodo();
            return;
        }
    }
    
    // Para cambios de página (paginación AJAX), mantener la selección
    const guardados = sessionStorage.getItem('productosSeleccionados');
    if (guardados) {
        seleccionados = new Set(JSON.parse(guardados));
        actualizarTodo();
    }
}

function actualizarCheckboxes() {
    document.querySelectorAll('.checkbox-producto').forEach(cb => cb.checked = seleccionados.has(parseInt(cb.value)));
    const total = document.querySelectorAll('.checkbox-producto').length;
    const seleccionadosEnPagina = document.querySelectorAll('.checkbox-producto:checked').length;
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.checked = total > 0 && seleccionadosEnPagina === total;
        selectAll.indeterminate = seleccionadosEnPagina > 0 && seleccionadosEnPagina < total;
    }
}

function actualizarContador() {
    const count = seleccionados.size;
    const floatingCounter = document.getElementById('floatingCounter');
    if (floatingCounter) {
        if (count > 0) {
            if (window.innerWidth > 768) {
                floatingCounter.textContent = count + (count === 1 ? ' seleccionado' : ' seleccionados');
            } else {
                floatingCounter.textContent = count;
            }
            floatingCounter.classList.add('show');
        } else {
            floatingCounter.classList.remove('show');
        }
    }
}

function actualizarTodo() { actualizarCheckboxes(); actualizarContador(); }

document.addEventListener('change', function(e) {
    if (e.target.classList.contains('checkbox-producto')) {
        const id = parseInt(e.target.value);
        e.target.checked ? seleccionados.add(id) : seleccionados.delete(id);
        actualizarTodo(); guardarSeleccion();
    }
    if (e.target.id === 'selectAll') {
        document.querySelectorAll('.checkbox-producto').forEach(cb => { cb.checked = e.target.checked; const id = parseInt(cb.value); e.target.checked ? seleccionados.add(id) : seleccionados.delete(id); });
        actualizarTodo(); guardarSeleccion();
    }
});

function ejecutarAccionMasiva(accion) {
    const ids = [...seleccionados];
    if (ids.length === 0) {
        mostrarNotificacion('❌ No hay productos seleccionados', 'error');
        return;
    }

    let accionTextoMostrar = '';
    if (accion === 'activar') {
        accionTextoMostrar = 'Activar';
    } else if (accion === 'desactivar') {
        accionTextoMostrar = 'Desactivar';
    } else if (accion === 'calcular_venta') {
        accionTextoMostrar = 'Recalcular Venta (seleccionados)';
    }

    if (confirm(`¿${accionTextoMostrar} ${ids.length} producto(s)?`)) {
        mostrarNotificacion('⏳ Procesando...', 'info');

        const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || '';
        if (!csrfToken) {
            mostrarNotificacion('❌ Token de seguridad no encontrado. Recarga la página.', 'error');
            return;
        }

        enviarAccionProductos(
            { accion: accion, productos: ids, csrf_token: csrfToken },
            function (data) {
                let mensajeAccion = '';
                if (accion === 'activar') mensajeAccion = 'activados';
                else if (accion === 'desactivar') mensajeAccion = 'desactivados';
                else if (accion === 'calcular_venta') mensajeAccion = 'recalculados';

                mostrarNotificacion(`✅ ${data.actualizados} producto(s) ${mensajeAccion}`, 'exito');

                if (accion === 'calcular_venta') {
                    if (data.productos_actualizados && data.productos_actualizados.length > 0) {
                        data.productos_actualizados.forEach(producto => {
                            actualizarFilaProducto(producto);
                        });
                    }
                } else {
                    const nuevoEstado = accion === 'activar' ? 1 : 0;
                    aplicarEstadoVisualFilas(ids, nuevoEstado);
                }

                seleccionados.clear();
                guardarSeleccion();
                actualizarTodo();
            }
        );
    }
}
function limpiarSeleccion() {
    seleccionados.clear();
    actualizarTodo();
    guardarSeleccion();
    document.getElementById('floatingActionsMenuPC')?.classList.remove('show');
}

document.getElementById('btnActivarMasivo')?.addEventListener('click', () => ejecutarAccionMasiva('activar'));
document.getElementById('btnDesactivarMasivo')?.addEventListener('click', () => ejecutarAccionMasiva('desactivar'));
document.getElementById('btnCalcularVenta')?.addEventListener('click', () => ejecutarAccionMasiva('calcular_venta'));

document.getElementById('btnCalcularVentaTodos')?.addEventListener('click', () => {
    if (!confirm('¿Recalcular el precio de venta de TODOS los productos del proveedor actual?\n\nEsto usará las tasas actuales del proveedor.')) {
        return;
    }

    const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || '';
    if (!csrfToken) {
        mostrarNotificacion('❌ Token de seguridad no encontrado', 'error');
        return;
    }

    mostrarNotificacion('⏳ Recalculando todos los productos...', 'info');

    fetch('productos_acciones_masiva.php' + getProveedorIdParam(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        accion: 'calcular_venta_todos',
        productos: [],
        csrf_token: csrfToken
    })
})
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacion(`✅ ${data.actualizados} producto(s) recalculados`, 'exito');
            if (data.productos_actualizados) {
                data.productos_actualizados.forEach(p => actualizarFilaProducto(p));
            }
        } else {
            mostrarNotificacion('❌ ' + (data.error || 'Error'), 'error');
        }
    })
    .catch(err => {
        console.error(err);
        mostrarNotificacion('❌ Error de conexión', 'error');
    });
});
document.getElementById('btnLimpiarSeleccion')?.addEventListener('click', limpiarSeleccion);

document.getElementById('floatingCounter')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('floatingActionsMenuPC')?.classList.toggle('show');
});

document.addEventListener('click', (e) => {
    if (!e.target.closest('#floatingCounter') && !e.target.closest('#floatingActionsMenuPC')) {
        document.getElementById('floatingActionsMenuPC')?.classList.remove('show');
    }
});
    
 // ============================================
// REBAJA MASIVA
// ============================================

function abrirModalRebajaMasiva() {
    const ids = [...seleccionados];  // 👈 CAMBIADO: ya no se llama 'seleccionados'
    console.log('IDs seleccionados:', ids);
    
    if (ids.length === 0) {
        mostrarNotificacion('❌ No hay productos seleccionados', 'error');
        return;
    }
    
    document.getElementById('contadorRebajaMasiva').textContent = ids.length;
    document.getElementById('inputPorcentajeRebaja').value = '';
    document.getElementById('modalRebajaMasiva').style.display = 'block';
}

function cerrarModalRebajaMasiva() {
    document.getElementById('modalRebajaMasiva').style.display = 'none';
}

function ejecutarRebajaMasiva() {
    const ids = [...seleccionados];
    if (ids.length === 0) {
        mostrarNotificacion('❌ No hay productos seleccionados', 'error');
        return;
    }
    
    const porcentaje = parseFloat(document.getElementById('inputPorcentajeRebaja').value);
    if (isNaN(porcentaje) || porcentaje < 0 || porcentaje > 100) {
        mostrarNotificacion('❌ Ingresa un porcentaje válido (0-100)', 'error');
        return;
    }
    
    if (!confirm(`¿Aplicar ${porcentaje}% de rebaja a ${ids.length} producto(s)?`)) {
        return;
    }
    
    mostrarNotificacion('⏳ Procesando...', 'info');
    cerrarModalRebajaMasiva();
    
        const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || '';
    if (!csrfToken) {
        mostrarNotificacion('❌ Token de seguridad no encontrado. Recarga la página.', 'error');
        return;
    }
    
    fetch('productos_acciones_masiva.php' + getProveedorIdParam(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        accion: 'aplicar_rebaja',
        productos: ids,
        porcentaje_rebaja: porcentaje,
        csrf_token: csrfToken
    })
})
    .then(response => response.json())
    .then(data => {
        console.log('Respuesta del servidor:', data);
        
        if (data.success) {
            mostrarNotificacion(`✅ ${data.actualizados} producto(s) actualizados con ${porcentaje}% de rebaja`, 'exito');
            
            if (data.productos_actualizados) {
                data.productos_actualizados.forEach(producto => {
                    actualizarFilaProducto(producto);
                });
            }
            
            seleccionados.clear();
            guardarSeleccion();
            actualizarTodo();
        } else {
            mostrarNotificacion('❌ ' + (data.error || 'Error al procesar'), 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarNotificacion('❌ Error de conexión', 'error');
    });
}

// Eventos
document.getElementById('btnAplicarRebaja')?.addEventListener('click', abrirModalRebajaMasiva);
document.getElementById('btnConfirmarRebajaMasiva')?.addEventListener('click', ejecutarRebajaMasiva);
document.getElementById('inputPorcentajeRebaja')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        ejecutarRebajaMasiva();
    }
});

// Cerrar modal al hacer clic fuera
document.addEventListener('click', function(e) {
    const modal = document.getElementById('modalRebajaMasiva');
    if (e.target === modal) {
        cerrarModalRebajaMasiva();
    }
});

// ============================================
// BARRA DE DESPLAZAMIENTO HORIZONTAL FIJA
// ============================================
function initHorizontalScroll() {
    const container = document.getElementById('tableContainer');
    const scrollContainer = document.getElementById('horizontalScrollContainer');
    const scrollBar = document.getElementById('scrollBar');
    const scrollThumb = document.getElementById('scrollThumb');
    
    if (!container || !scrollContainer || !scrollBar || !scrollThumb) return;
    
    function updateScrollBar() {
        const scrollWidth = container.scrollWidth;
        const clientWidth = container.clientWidth;
        if (scrollWidth <= clientWidth) { scrollContainer.style.display = 'none'; return; }
        scrollContainer.style.display = 'flex';
        const thumbWidth = Math.max(50, (clientWidth / scrollWidth) * scrollBar.clientWidth);
        scrollThumb.style.width = thumbWidth + 'px';
        const scrollLeft = container.scrollLeft;
        const maxScrollLeft = scrollWidth - clientWidth;
        const thumbLeft = (scrollLeft / maxScrollLeft) * (scrollBar.clientWidth - thumbWidth);
        scrollThumb.style.transform = `translateX(${thumbLeft}px)`;
    }
    
    let isDragging = false;
    scrollThumb.addEventListener('mousedown', (e) => { isDragging = true; e.preventDefault(); });
    window.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const rect = scrollBar.getBoundingClientRect();
        const thumbWidth = scrollThumb.offsetWidth;
        let newLeft = e.clientX - rect.left - thumbWidth / 2;
        newLeft = Math.max(0, Math.min(newLeft, rect.width - thumbWidth));
        const scrollWidth = container.scrollWidth;
        const clientWidth = container.clientWidth;
        const maxScrollLeft = scrollWidth - clientWidth;
        const scrollLeft = (newLeft / (rect.width - thumbWidth)) * maxScrollLeft;
        container.scrollLeft = scrollLeft;
    });
    window.addEventListener('mouseup', () => { isDragging = false; });
    container.addEventListener('scroll', updateScrollBar);
    window.addEventListener('resize', updateScrollBar);
    updateScrollBar();
}
    
function eliminarProductoIndividual(productoId, nombreProducto) {
const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || '';
    if (!csrfToken) {
        mostrarNotificacion('❌ Token de seguridad no encontrado', 'error');
        return;
    }
    // Primero, verificar si hay dependencias (la petición original)
    
    // 🔒 Verificar si el usuario tiene permiso para eliminar este producto
    // (el servidor también lo validará, pero es buena práctica)
    const usuarioRol = '<?php echo $_SESSION["rol"] ?? ""; ?>';
    const esProveedor = '<?php echo esRolProveedor($_SESSION["rol"] ?? "") ? "true" : "false"; ?>';
    const proveedorId = <?php echo $proveedor_id_filtro ?? 0; ?>;
    
    // Si es proveedor, validar que el producto le pertenece (el servidor lo hará)
        fetch('productos_acciones_masiva.php' + getProveedorIdParam(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 
        accion: 'eliminar', 
        productos: [productoId],
        csrf_token: csrfToken 
    })
})
        .then(response => response.json())
    .then(data => {
        // 🔒 Verificar si no tiene permiso
        if (data.error && data.error.includes('permiso')) {
            mostrarNotificacion('❌ No tienes permiso para eliminar este producto', 'error');
            return;
        }
        
        if (data.success) {
            if (confirm(`¿Estás seguro de eliminar el producto "${nombreProducto}"?\n\nEsta acción no se puede deshacer.`)) {
                const fila = document.querySelector(`.checkbox-producto[value="${productoId}"]`)?.closest('tr');
                if (fila) fila.remove();
                mostrarNotificacion('✅ Producto eliminado correctamente', 'exito');
            } else {
                mostrarNotificacion('ℹ️ Operación cancelada', 'info');
            }
        } else if (data.requires_confirmation) {
            const dependencias = data.dependencias;
            let textoDeps = '';
            if (dependencias.historial_mov) textoDeps += `📜 Historial de movimientos: ${dependencias.historial_mov}<br>`;
            if (dependencias.historial_cambios) textoDeps += `📝 Cambios registrados: ${dependencias.historial_cambios}<br>`;
            if (dependencias.carritos) textoDeps += `🛒 Carritos activos: ${dependencias.carritos}<br>`;
            if (dependencias.pedidos) textoDeps += `📦 Pedidos en curso: ${dependencias.pedidos}<br>`;
            if (dependencias.combos) textoDeps += `🎁 Combos activos: ${dependencias.combos}<br>`;

            // Crear el modal
            const modal = document.createElement('div');
            modal.id = 'modalEliminarCustom';
            modal.style.cssText = `
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center;
                z-index: 9999;
            `;
            
            modal.innerHTML = `
                <div style="background: white; border-radius: 16px; padding: 1.5rem; max-width: 450px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
                    <h3 style="margin: 0 0 0.5rem 0; color: #2d3748;">⚠️ Confirmar eliminación</h3>
                    <p style="margin: 0 0 0.5rem 0; color: #4a5568;">
                        El producto "<strong>${nombreProducto}</strong>" tiene dependencias:
                    </p>
                    <div style="background: #fef5e7; padding: 0.8rem; border-radius: 8px; margin: 0.8rem 0; font-size: 0.85rem; text-align: left;">
                        ${textoDeps}
                    </div>
                    <p style="color: #c53030; font-size: 0.85rem; margin: 0 0 1rem 0;">
                        ⚠️ Eliminar forzadamente borrará también las dependencias. Esta acción no se puede deshacer.
                    </p>
                    <div style="display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap;">
                        <button onclick="ejecutarEliminarForzar(${productoId})" style="background: #f56565; color: white; border: none; padding: 0.5rem 1.2rem; border-radius: 8px; cursor: pointer; font-weight: 600;">
                            🗑️ Eliminar
                        </button>
                        <button onclick="ejecutarDesactivar(${productoId})" style="background: #ecc94b; color: #744210; border: none; padding: 0.5rem 1.2rem; border-radius: 8px; cursor: pointer; font-weight: 600;">
                            🔒 Desactivar
                        </button>
                        <button onclick="cerrarModalEliminar()" style="background: #edf2f7; color: #4a5568; border: none; padding: 0.5rem 1.2rem; border-radius: 8px; cursor: pointer; font-weight: 600;">
                            ❌ Cancelar
                        </button>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);

            // Funciones globales para los botones
            window.ejecutarEliminarForzar = function(id) {
    fetch('productos_acciones_masiva.php' + getProveedorIdParam(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            accion: 'eliminar_forzar', 
            productos: [id],
            csrf_token: csrfToken 
        })
    })
                .then(res => res.json())
                .then(resp => {
                    cerrarModalEliminar();
                    if (resp.success) {
                        const fila = document.querySelector(`.checkbox-producto[value="${id}"]`)?.closest('tr');
                        if (fila) fila.remove();
                        mostrarNotificacion('✅ Producto eliminado permanentemente', 'exito');
                    } else {
                        mostrarNotificacion('❌ Error al eliminar: ' + (resp.error || 'desconocido'), 'error');
                    }
                });
            };

            window.ejecutarDesactivar = function(id) {
    fetch('productos_acciones_masiva.php' + getProveedorIdParam(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            accion: 'desactivar', 
            productos: [id],
            csrf_token: csrfToken 
        })
    })
    .then(res => res.json())
        .then(resp => {
        cerrarModalEliminar();
        // 🔒 Verificar si no tiene permiso
        if (resp.error && resp.error.includes('permiso')) {
            mostrarNotificacion('❌ No tienes permiso para eliminar este producto', 'error');
            return;
        }
        
        if (resp.success) {
            // ✅ SOLO ACTUALIZAR LA FILA (sin recargar toda la tabla)
            if (resp.producto && typeof actualizarFilaProducto === 'function') {
                actualizarFilaProducto(resp.producto);
            } else {
                // Si no viene el producto, actualizar manualmente
                const checkbox = document.querySelector(`.checkbox-producto[value="${id}"]`);
                if (checkbox) {
                    const fila = checkbox.closest('tr');
                    if (fila) {
                        const badgeEstado = fila.querySelector('.badge-estado');
                        const btnToggle = fila.querySelector('.ajax-toggle-estado');
                        
                        if (badgeEstado) {
                            badgeEstado.className = 'badge-estado badge-inactivo';
                            badgeEstado.textContent = '❌ Inactivo';
                        }
                        if (btnToggle) {
                            btnToggle.setAttribute('data-estado', '0');
                            btnToggle.textContent = '🟢';
                        }
                        fila.style.opacity = '0.7';
                        fila.style.background = '#fff5f5';
                    }
                }
            }
            mostrarNotificacion('🔒 Producto desactivado (conserva dependencias)', 'info');
        } else {
            mostrarNotificacion('❌ Error al desactivar', 'error');
        }
    });
};

            window.cerrarModalEliminar = function() {
                const modal = document.getElementById('modalEliminarCustom');
                if (modal) modal.remove();
            };

        } else {
            mostrarNotificacion('❌ ' + (data.mensaje || data.error || 'Error al procesar'), 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        mostrarNotificacion('❌ Error de conexión', 'error');
    });
}
// ============================================
// INICIALIZACIÓN
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    cargarTabla();
    initHorizontalScroll();
    cargarSeleccion();
    <?php if (isset($_SESSION['mensaje'])): ?>
        mostrarNotificacion('<?php echo addslashes($_SESSION['mensaje']); ?>', '<?php echo $_SESSION['tipo_mensaje'] ?? "exito"; ?>');
        <?php unset($_SESSION['mensaje']); unset($_SESSION['tipo_mensaje']); ?>
    <?php endif; ?>
});

document.querySelector('.filtros-form')?.addEventListener('submit', (e) => e.preventDefault());
document.querySelectorAll('.btn-pagina').forEach(link => link.addEventListener('click', () => guardarSeleccion()));
window.addEventListener('resize', () => actualizarContador());
  
</script>

<?php include __DIR__ . '/modal_editar_producto.php'; ?>

<?php
$conn->close();
include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';
?>
<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';

// ============================================
// PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Admin', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($_SESSION['rol'] ?? '', $roles_permitidos);
$es_supervisor = (($_SESSION['rol'] ?? '') == 'Supervisor');

if (!$puede_gestionar && !$es_supervisor) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// FILTRO POR PROVEEDOR (si el rol es Proveedor)
// ============================================
$proveedor_filtro = null;
if (($_SESSION['rol'] ?? '') == 'Proveedor') {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';
    $proveedor_filtro = obtenerProveedorId($conn, $_SESSION['usuario_id'] ?? 0, $_SESSION['rol'] ?? '');
    if (!$proveedor_filtro) {
        header('Location: /admin.php?error=sin_proveedor');
        exit;
    }
}

// ============================================
// RECOGER FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "p.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['precio_costo']) && isset($_GET['costo_operador'])) {
    $operador = $_GET['costo_operador'];
    if (in_array($operador, ['=', '<', '>'])) {
        $where[] = "p.precio_costo $operador ?";
        $params[] = $_GET['precio_costo'];
        $types .= "d";
    }
}

if (!empty($_GET['filtro_imagen'])) {
    if ($_GET['filtro_imagen'] == 'sin_imagen') {
        $where[] = "(p.imagen_url IS NULL OR p.imagen_url = '')";
    } elseif ($_GET['filtro_imagen'] == 'con_imagen') {
        $where[] = "(p.imagen_url IS NOT NULL AND p.imagen_url != '')";
    }
}

if (!empty($_GET['filtro_estado'])) {
    if ($_GET['filtro_estado'] == 'activos') {
        $where[] = "p.activo = 1";
    } elseif ($_GET['filtro_estado'] == 'inactivos') {
        $where[] = "p.activo = 0";
    }
}

if (!empty($_GET['filtro_rebaja'])) {
    if ($_GET['filtro_rebaja'] == 'con_rebaja') {
        $where[] = "p.porcentaje_rebaja > 0";
    } elseif ($_GET['filtro_rebaja'] == 'sin_rebaja') {
        $where[] = "(p.porcentaje_rebaja IS NULL OR p.porcentaje_rebaja = 0)";
    }
}

// Filtro por proveedor (rol Proveedor)
if ($proveedor_filtro !== null) {
    $where[] = "p.proveedor_id = ?";
    $params[] = $proveedor_filtro;
    $types .= "i";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// CONSULTA
// ============================================
$sql = "SELECT p.*, 
               c.nombre AS categoria_nombre, 
               c.icono AS categoria_icono,
               pr.nombre_tienda AS proveedor_nombre
        FROM productos p 
        LEFT JOIN categorias c ON p.categoria_id = c.id 
        LEFT JOIN proveedores pr ON p.proveedor_id = pr.id
        $sql_where 
        ORDER BY p.id ASC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$productos = $stmt->get_result();

// ============================================
// HEADERS PARA EXCEL
// ============================================
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="inventario_productos_' . date('Y-m-d_H-i') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

// ============================================
// GENERAR HTML
// ============================================
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <style>
        table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; font-size: 10pt; }
        th { background-color: #4F46E5; color: white; font-weight: bold; padding: 6px; border: 1px solid #ddd; text-align: center; }
        td { padding: 4px; border: 1px solid #ddd; text-align: left; }
        .number { text-align: right; }
        .center { text-align: center; }
        .title { font-size: 14pt; font-weight: bold; text-align: center; margin-bottom: 10px; color: #333; }
        .subtitle { font-size: 10pt; text-align: center; margin-bottom: 15px; color: #666; }
        .total-row { background-color: #f0f0f0; font-weight: bold; }
    </style>
</head>
<body>
    <div class="title">INVENTARIO DE PRODUCTOS</div>
    <div class="subtitle">
        Generado: <?php echo date('d/m/Y H:i:s'); ?> | 
        Total productos: <?php echo $productos->num_rows; ?>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Marca</th>
                <th>Categoría</th>
                <th>Proveedor</th>
                <th>Cantidad</th>
                <th>Reservado</th>
                <th>Stock disp.</th>
                <th>En combo</th>
                <th>Moneda</th>
                <th>P. Adquisición</th>
                <th>P. Costo (USD)</th>
                <th>Imp. Costo</th>
                <th>% Ganancia</th>
                <th>Precio Original</th>
                <th>% Rebaja</th>
                <th>Precio (Final)</th>
                <th>Imp. Venta</th>
                <th>Peso (kg)</th>
                <th>Estado</th>
                <th>Fecha creación</th>
                <th>Fecha agotado</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $total_costo = 0;
            $total_venta = 0;
            $total_cantidad = 0;
            $total_reservado = 0;
            $total_disponible = 0;

            while($p = $productos->fetch_assoc()): 
                $cantidad = (int)($p['cantidad'] ?? 0);
                $reservado = (int)($p['reservado_por_combos'] ?? 0);
                $disponible = $cantidad - $reservado;

                $precio_costo = (float)($p['precio_costo'] ?? 0);
                $precio_original = (float)($p['precio_original'] ?? 0);
                $precio_final = (float)($p['precio'] ?? 0); // ¡Ya es el final con rebaja!
                $porc_rebaja = (int)($p['porcentaje_rebaja'] ?? 0);
                $porc_ganancia = (float)($p['porcentaje_ganancia'] ?? 0);

                $importe_costo = $precio_costo * $cantidad;
                $importe_venta = $precio_final * $cantidad;

                $total_costo += $importe_costo;
                $total_venta += $importe_venta;
                $total_cantidad += $cantidad;
                $total_reservado += $reservado;
                $total_disponible += $disponible;

                $marca = ($p['marca'] !== null && $p['marca'] !== '') ? $p['marca'] : '—';
                $moneda = $p['moneda_adquisicion'] ?? '—';
                $fecha_creacion = !empty($p['fecha_creacion']) ? date('d/m/Y', strtotime($p['fecha_creacion'])) : '—';
                $fecha_agotado = !empty($p['fecha_agotado']) ? date('d/m/Y', strtotime($p['fecha_agotado'])) : '—';
            ?>
            <tr>
                <td class="center">#<?php echo $p['id']; ?></td>
                <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                <td><?php echo htmlspecialchars($marca); ?></td>
                <td><?php echo htmlspecialchars($p['categoria_nombre'] ?? 'Sin categoría'); ?></td>
                <td><?php echo htmlspecialchars($p['proveedor_nombre'] ?? '—'); ?></td>
                <td class="center"><?php echo $cantidad; ?></td>
                <td class="center"><?php echo $reservado; ?></td>
                <td class="center"><?php echo $disponible; ?></td>
                <td class="center"><?php echo $p['en_combo'] ? 'Sí' : 'No'; ?></td>
                <td class="center"><?php echo htmlspecialchars($moneda); ?></td>
                <td class="number">$<?php echo number_format((float)($p['precio_adquisicion'] ?? 0), 2); ?></td>
                <td class="number">$<?php echo number_format($precio_costo, 2); ?></td>
                <td class="number">$<?php echo number_format($importe_costo, 2); ?></td>
                <td class="center"><?php echo number_format($porc_ganancia, 2); ?>%</td>
                <td class="number">$<?php echo number_format($precio_original, 2); ?></td>
                <td class="center"><?php echo $porc_rebaja > 0 ? $porc_rebaja . '%' : '—'; ?></td>
                <td class="number"><strong>$<?php echo number_format($precio_final, 2); ?></strong></td>
                <td class="number">$<?php echo number_format($importe_venta, 2); ?></td>
                <td class="number"><?php echo number_format((float)($p['peso'] ?? 0), 3); ?></td>
                <td class="center"><?php echo $p['activo'] ? 'Activo' : 'Inactivo'; ?></td>
                <td class="center"><?php echo $fecha_creacion; ?></td>
                <td class="center"><?php echo $fecha_agotado; ?></td>
            </tr>
            <?php endwhile; ?>
            <tr class="total-row">
                <td colspan="5" style="text-align: right;">TOTALES:</td>
                <td class="center"><?php echo $total_cantidad; ?></td>
                <td class="center"><?php echo $total_reservado; ?></td>
                <td class="center"><?php echo $total_disponible; ?></td>
                <td class="center">—</td>
                <td class="center">—</td>
                <td class="number">—</td>
                <td class="number">—</td>
                <td class="number">$<?php echo number_format($total_costo, 2); ?></td>
                <td class="center">—</td>
                <td class="number">—</td>
                <td class="center">—</td>
                <td class="number">—</td>
                <td class="number">$<?php echo number_format($total_venta, 2); ?></td>
                <td class="number">—</td>
                <td class="center">—</td>
                <td class="center">—</td>
                <td class="center">—</td>
            </tr>
        </tbody>
    </table>
    
    <div style="margin-top: 15px; font-size: 9pt; color: #999; text-align: center;">
        Sistema de Gestión - <?php echo date('d/m/Y H:i:s'); ?>
    </div>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
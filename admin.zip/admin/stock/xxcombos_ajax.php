<?php
// ============================================
// COMBOS AJAX - CARGA DE COMBOS VÍA AJAX
// ============================================

// ============================================
// PERMITIR AJAX (CSP)
// ============================================
header("Content-Security-Policy: default-src 'self' 'unsafe-inline' 'unsafe-eval' data: *;");

// ============================================
// CABECERAS ANTI-CACHÉ
// ============================================
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_permitidos);
$es_supervisor = ($_SESSION['rol'] == 'Supervisor');

if (!$puede_gestionar && !$es_supervisor) {
    http_response_code(403);
    echo "Acceso denegado";
    exit;
}

// ============================================
// PERMISOS PARA COMBOS
// ============================================
$permisos = [
    'eliminar' => false
];

// Solo Super Admin y Gerente pueden eliminar
if (in_array($_SESSION['rol'], ['Super Admin', 'Gerente'])) {
    $permisos['eliminar'] = true;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

// Si tiene proveedor asociado, forzar el filtro
if ($proveedor_id_usuario > 0) {
    $_GET['proveedor_id'] = $proveedor_id_usuario;
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "c.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['estado'])) {
    if ($_GET['estado'] == 'activos') {
        $where[] = "c.activo = 1";
    } elseif ($_GET['estado'] == 'inactivos') {
        $where[] = "c.activo = 0";
    }
}

if (!empty($_GET['proveedor_id'])) {
    $where[] = "c.proveedor_id = ?";
    $params[] = intval($_GET['proveedor_id']);
    $types .= "i";
}

if (!empty($_GET['nombre_tienda'])) {
    $where[] = "pr.nombre_tienda LIKE ?";
    $params[] = "%" . $_GET['nombre_tienda'] . "%";
    $types .= "s";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// ORDENAMIENTO
// ============================================
$columnas_validas = [
    'id' => "c.id",
    'nombre' => "c.nombre",
    'nombre_tienda' => "pr.nombre_tienda",
    'precio' => "c.precio",
    'precio_final' => "c.precio_final",
    'rebaja' => "c.porcentaje_rebaja",
    'productos' => "c.productos_distintos",
    'unidades' => "c.unidades_totales",
    'importe_costo' => "importe_costo",
    'estado' => "c.activo",
    'fecha' => "c.fecha_creacion"
];

$order_by = isset($_GET['order_by']) && array_key_exists($_GET['order_by'], $columnas_validas) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . ($order_by == 'importe_costo' ? "importe_costo" : $columnas_validas[$order_by]) . " $order_dir";

// ============================================
// CONTAR TOTAL DE REGISTROS
// ============================================
$count_sql = "SELECT COUNT(*) as total FROM combos c $sql_where";
$count_stmt = $conn->prepare($count_sql);

if (!empty($params)) {
    $count_stmt->bind_param($types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_registros = $count_result ? $count_result->fetch_assoc()['total'] : 0;
$count_stmt->close();

// ============================================
// PAGINACIÓN
// ============================================
$result_config = $conn->query("SELECT valor FROM configuracion WHERE clave = 'productos_por_pagina'");
$row_config = $result_config->fetch_assoc();
$por_pagina = $row_config ? intval($row_config['valor']) : 30;

$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($pagina_actual - 1) * $por_pagina;
$total_paginas = ceil($total_registros / $por_pagina);

// ============================================
// CONSULTA PRINCIPAL CON IMPORTE COSTO
// ============================================
$sql = "SELECT c.*, 
               (SELECT COUNT(*) FROM combo_productos WHERE combo_id = c.id) as productos_distintos,
               (SELECT SUM(cantidad) FROM combo_productos WHERE combo_id = c.id) as unidades_totales,
               (SELECT SUM(p.precio_costo * cp.cantidad) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id) as importe_costo,
               pr.nombre_tienda
        FROM combos c 
        LEFT JOIN proveedores pr ON c.proveedor_id = pr.id
        $sql_where 
        $order_sql
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $params[] = $por_pagina;
    $params[] = $offset;
    $types = $types . "ii";
    $stmt->bind_param($types, ...$params);
} else {
    $stmt->bind_param("ii", $por_pagina, $offset);
}
$stmt->execute();
$combos = $stmt->get_result();
?>

<!-- ============================================ -->
<!-- TABLA DE COMBOS -->
<!-- ============================================ -->
<div class="productos-table-card">
    <div class="table-header">
        <h3>🎁 Lista de Combos <span style="font-size: 0.8rem; color: #718096; font-weight: normal;">(<?php echo $total_registros; ?> combos)</span></h3>
        <div class="table-header-right">
            <?php if ($puede_gestionar): ?>
            <a href="combos_editar.php" class="btn-primary btn">➕ Nuevo Combo</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="table-wrapper">
        <div class="table-responsive" id="tableContainer">
            <table class="tabla-moderna" id="tablaCombos">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="checkbox-col">
                            <input type="checkbox" class="select-all-checkbox" id="selectAll" title="Seleccionar todos">
                        </th>
                        <th class="no-print">Imagen</th>
                        <th><a href="#" data-order="nombre" class="ordenar-link">Nombre <?php echo $order_by == 'nombre' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="nombre_tienda" class="ordenar-link">Proveedor <?php echo $order_by == 'nombre_tienda' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="productos" class="ordenar-link">Productos <?php echo $order_by == 'productos' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="unidades" class="ordenar-link">Unidades <?php echo $order_by == 'unidades' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="importe_costo" class="ordenar-link">Importe Costo <?php echo $order_by == 'importe_costo' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="precio" class="ordenar-link">Precio Venta <?php echo $order_by == 'precio' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="rebaja" class="ordenar-link">Rebaja <?php echo $order_by == 'rebaja' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="stock_combo" class="ordenar-link">Stock <?php echo $order_by == 'stock_combo' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="estado" class="ordenar-link">Estado <?php echo $order_by == 'estado' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th><a href="#" data-order="fecha" class="ordenar-link">Fecha <?php echo $order_by == 'fecha' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                        <th class="no-print">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($combos->num_rows > 0): ?>
                        <?php while($combo = $combos->fetch_assoc()): 
                            $tiene_rebaja = $combo['porcentaje_rebaja'] > 0;
                        ?>
                        <tr style="<?php echo $combo['activo'] ? '' : 'opacity: 0.7; background: #fff5f5;'; ?>">
                            <td>#<?php echo $combo['id']; ?></td>
                            <td class="checkbox-col text-center">
                                <input type="checkbox" class="checkbox-combo" value="<?php echo $combo['id']; ?>" data-id="<?php echo $combo['id']; ?>">
                            </td>
                            <td class="no-print">
                                <?php if (!empty($combo['imagen_url'])): ?>
                                    <img src="<?php echo htmlspecialchars($combo['imagen_url']); ?>" alt="<?php echo htmlspecialchars($combo['nombre']); ?>" class="img-thumbnail" style="width: 45px; height: 45px; object-fit: cover; border-radius: 8px;">
                                <?php else: ?>
                                    <div class="sin-imagen" title="Sin imagen">🎁</div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($combo['nombre']); ?></strong></td>
                            <td><?php echo htmlspecialchars($combo['nombre_tienda'] ?? '—'); ?></td>
                            <td class="text-center"><?php echo intval($combo['productos_distintos']); ?></td>
                            <td class="text-center"><?php echo intval($combo['unidades_totales']); ?></td>
                            <td class="text-right">$<?php echo number_format($combo['importe_costo'], 2); ?></td>
                            <td class="text-right">$<?php echo number_format($combo['precio'], 2); ?></td>
                            <td class="text-center">
                                <?php if ($tiene_rebaja): ?>
                                    <span class="badge-rebaja">-<?php echo $combo['porcentaje_rebaja']; ?>%</span>
                                <?php else: ?>
                                    <span style="color: #9ca3af;">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?php echo intval($combo['stock_combo']); ?></td>
                            <td class="text-center">
                                <span class="badge-estado <?php echo $combo['activo'] ? 'badge-activo' : 'badge-inactivo'; ?>"><?php echo $combo['activo'] ? '✅ Activo' : '❌ Inactivo'; ?></span>
                            </td>
                            <td><?php echo date('d/m/Y', strtotime($combo['fecha_creacion'])); ?></td>
                            <td class="no-print acciones">
                                <a href="combos_ver.php?id=<?php echo $combo['id']; ?>" class="btn-icono" title="Ver detalles">👁️</a>
                                <?php if ($puede_gestionar): ?>
                                    <a href="#" class="btn-icono ajax-toggle-estado" data-id="<?php echo $combo['id']; ?>" data-estado="<?php echo $combo['activo']; ?>"><?php echo $combo['activo'] ? '🔴' : '🟢'; ?></a>
                                    <a href="combos_editar.php?id=<?php echo $combo['id']; ?>" class="btn-icono">✏️</a>
                                    <?php if ($permisos['eliminar']): ?>
                                    <a href="combos_acciones.php?accion=eliminar&id=<?php echo $combo['id']; ?>" class="btn-icono" onclick="return confirm('¿Eliminar combo <?php echo addslashes($combo['nombre']); ?>?')">🗑️</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="12" class="text-center sin-datos">📭 No se encontraron combos con los filtros seleccionados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ============================================ -->
<!-- PAGINACIÓN -->
<!-- ============================================ -->
<?php
$base_url = '#';
$total_registros = $total_registros;
$por_pagina = $por_pagina;
$pagina_actual = $pagina_actual;
$total_paginas = $total_paginas;
include $_SERVER['DOCUMENT_ROOT'] . '/includes/paginacion_botones.php';
?>

<form method="POST" id="formAccionMasiva" style="display: none;">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="hidden" name="accion_masiva" id="accion_masiva" value="">
    <input type="hidden" name="combos" id="combos_seleccionados" value="">
</form>

<script>
// Variables globales para selección
let seleccionados = new Set();

function guardarSeleccion() {
    sessionStorage.setItem('combosSeleccionados', JSON.stringify([...seleccionados]));
}

function cargarSeleccion() {
    const guardados = sessionStorage.getItem('combosSeleccionados');
    if (guardados) {
        seleccionados = new Set(JSON.parse(guardados));
        actualizarTodo();
    }
}

function actualizarCheckboxes() {
    document.querySelectorAll('.checkbox-combo').forEach(cb => {
        cb.checked = seleccionados.has(parseInt(cb.value));
    });
    const total = document.querySelectorAll('.checkbox-combo').length;
    const seleccionadosEnPagina = document.querySelectorAll('.checkbox-combo:checked').length;
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.checked = total > 0 && seleccionadosEnPagina === total;
        selectAll.indeterminate = seleccionadosEnPagina > 0 && seleccionadosEnPagina < total;
    }
}

function actualizarContador() {
    const count = seleccionados.size;
    const floatingCounter = document.getElementById('floatingCounter');
    if (floatingCounter) {
        if (count > 0) {
            if (window.innerWidth > 768) {
                floatingCounter.textContent = count + (count === 1 ? ' seleccionado' : ' seleccionados');
            } else {
                floatingCounter.textContent = count;
            }
            floatingCounter.classList.add('show');
        } else {
            floatingCounter.classList.remove('show');
        }
    }
}

function actualizarTodo() {
    actualizarCheckboxes();
    actualizarContador();
}

// Ordenamiento
document.querySelectorAll('.ordenar-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const orderBy = this.getAttribute('data-order');
        const params = new URLSearchParams(window.location.search);
        const currentOrder = params.get('order_by');
        const currentDir = params.get('order_dir');
        let newDir = 'ASC';
        if (currentOrder === orderBy && currentDir === 'ASC') {
            newDir = 'DESC';
        }
        params.set('order_by', orderBy);
        params.set('order_dir', newDir);
        cargarCombosConParams(params);
    });
});

function cargarCombosConParams(params) {
    const url = 'combos_ajax.php?' + params.toString();
    const contenedor = document.getElementById('tabla-combos-container');
    contenedor.innerHTML = '<div style="text-align: center; padding: 2rem;">🔄 Cargando combos...</div>';
    
    fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(response => response.text())
        .then(html => {
            contenedor.innerHTML = html;
            reinicializarEventosCombos();
            cargarSeleccion();
        })
        .catch(error => {
            console.error('Error:', error);
            contenedor.innerHTML = '<div style="text-align: center; padding: 2rem;">❌ Error al cargar combos</div>';
        });
}

function reinicializarEventosCombos() {
    document.querySelectorAll('.ajax-toggle-estado').forEach(btn => {
        btn.removeEventListener('click', handleToggleEstadoCombo);
        btn.addEventListener('click', handleToggleEstadoCombo);
    });
    document.querySelectorAll('.checkbox-combo').forEach(cb => {
        cb.removeEventListener('change', handleCheckboxChange);
        cb.addEventListener('change', handleCheckboxChange);
    });
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.removeEventListener('change', handleSelectAll);
        selectAll.addEventListener('change', handleSelectAll);
    }
}

function handleCheckboxChange(e) {
    const id = parseInt(e.target.value);
    if (e.target.checked) {
        seleccionados.add(id);
    } else {
        seleccionados.delete(id);
    }
    actualizarTodo();
    guardarSeleccion();
}

function handleSelectAll(e) {
    document.querySelectorAll('.checkbox-combo').forEach(cb => {
        cb.checked = e.target.checked;
        const id = parseInt(cb.value);
        if (e.target.checked) {
            seleccionados.add(id);
        } else {
            seleccionados.delete(id);
        }
    });
    actualizarTodo();
    guardarSeleccion();
}

function handleToggleEstadoCombo(e) {
    e.preventDefault();
    const btn = e.currentTarget;
    const comboId = btn.getAttribute('data-id');
    const estadoActual = btn.getAttribute('data-estado');
    if (confirm(`¿${estadoActual == '1' ? 'Desactivar' : 'Activar'} este combo?`)) {
        fetch(`combos_acciones.php?accion=toggle_estado&id=${comboId}&estado=${estadoActual}`, {
            method: 'GET',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(() => {
            cargarCombos();
        })
        .catch(error => console.error('Error:', error));
    }
}

// Inicializar
document.addEventListener('DOMContentLoaded', function() {
    cargarSeleccion();
});
</script>

<?php
$conn->close();
?>
<?php
// ============================================
// COMBO GET PRODUCTOS - OBTENER PRODUCTOS DISPONIBLES
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

header('Content-Type: application/json');

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Inventario', 'Proveedor'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    echo json_encode([]);
    exit;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo json_encode([]);
    exit;
}

// Si es rol de tienda, su proveedor ya está forzado por obtenerProveedorId
// Si es admin, debe pasar ?proveedor_id= obligatoriamente
$proveedor_id_filtro = $proveedor_id_usuario;

if ($proveedor_id_usuario == 0) {
    if (isset($_GET['proveedor_id']) && intval($_GET['proveedor_id']) > 0) {
        $proveedor_id_filtro = intval($_GET['proveedor_id']);
    } else {
        // Admin sin proveedor seleccionado → no devolver nada
        echo json_encode([]);
        exit;
    }
}

// Validar proveedor activo
$stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
$stmt_check->bind_param("i", $proveedor_id_filtro);
$stmt_check->execute();
if ($stmt_check->get_result()->num_rows === 0) {
    echo json_encode([]);
    $stmt_check->close();
    exit;
}
$stmt_check->close();

// ============================================
// PARÁMETROS
// ============================================
$combo_id = isset($_GET['combo_id']) ? intval($_GET['combo_id']) : 0;
$productos = [];

// ============================================
// CONSULTAR PRODUCTOS (FILTRADOS POR PROVEEDOR)
// ============================================
$sql = "SELECT p.id, p.nombre, p.precio_costo, p.precio, p.precio_original, p.porcentaje_rebaja, p.cantidad, p.reservado_por_combos,
               (p.cantidad - p.reservado_por_combos) as stock_disponible,
               c.nombre as categoria_nombre, c.icono as categoria_icono
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        WHERE p.activo = 1 
          AND p.proveedor_id = ?
          AND (p.cantidad - p.reservado_por_combos) > 0
        ORDER BY p.nombre";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $proveedor_id_filtro);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    // Si es edición, sumar la cantidad actual del producto en ese combo
    // (solo si el producto está activo y con cantidad positiva)
    if ($combo_id > 0 && intval($row['activo'] ?? 1) === 1) {
        $stmt_combo = $conn->prepare("SELECT COALESCE(MAX(cantidad), 0) as cantidad FROM combo_productos WHERE combo_id = ? AND producto_id = ? AND cantidad > 0");
        $stmt_combo->bind_param("ii", $combo_id, $row['id']);
        $stmt_combo->execute();
        $res_combo = $stmt_combo->get_result();
        if ($row_combo = $res_combo->fetch_assoc()) {
            $row['cantidad_en_combo_actual'] = intval($row_combo['cantidad']);
            $row['stock_disponible'] += $row['cantidad_en_combo_actual'];
        } else {
            $row['cantidad_en_combo_actual'] = 0;
        }
        $stmt_combo->close();
    } else {
        $row['cantidad_en_combo_actual'] = 0;
    }
    
    // Limpiar strings para JSON (el escape HTML se hace en el frontend al renderizar)
    $row['nombre'] = (string)($row['nombre'] ?? '');
    $row['categoria_nombre'] = trim((string)($row['categoria_nombre'] ?? ''));
    $iconoLimpio = trim((string)($row['categoria_icono'] ?? ''));
    $row['categoria_icono'] = $iconoLimpio !== '' ? $iconoLimpio : '📦';
    
    // Tipos numéricos
    $row['id'] = intval($row['id']);
    $row['precio_costo'] = floatval($row['precio_costo']);
$row['precio'] = floatval($row['precio']);
$row['precio_original'] = floatval($row['precio_original'] ?? 0);
$row['porcentaje_rebaja'] = intval($row['porcentaje_rebaja'] ?? 0);
$row['cantidad'] = intval($row['cantidad']);
$row['reservado_por_combos'] = intval($row['reservado_por_combos']);
$row['stock_disponible'] = intval($row['stock_disponible']);
    
    $productos[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($productos);
exit;
?>
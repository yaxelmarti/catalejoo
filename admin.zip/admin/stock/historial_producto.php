<?php
// ============================================
// HISTORIAL DE PRODUCTO - VERSIÓN 27 OCT 2026
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ✅ ORDEN CORRECTO: conexion → utils → csrf → header
require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/csrf.php';
require_once __DIR__ . '/../../header.php';

// ============================================
// VALIDAR SESIÓN ACTIVA
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

// ============================================
// VERIFICAR ROLES PERMITIDOS
// ============================================
$rol_actual = $_SESSION['rol'] ?? '';
$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($rol_actual, $roles_ver, true)) {
    error_log("[historial_producto] Permiso denegado. Rol: $rol_actual, usuario: " . ($_SESSION['usuario_id'] ?? 0));
    header('Location: /admin/stock/productos.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$proveedor_id_filtro = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_filtro == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// ============================================
// ID DEL PRODUCTO
// ============================================
$producto_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($producto_id <= 0) {
    header('Location: /admin/stock/productos.php');
    exit;
}

// ============================================
// CARGAR PRODUCTO (CON VERIFICACIÓN DE PROPIEDAD)
// ============================================
$sql = "
    SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono 
    FROM productos p 
    LEFT JOIN categorias c ON p.categoria_id = c.id 
    WHERE p.id = ?
";

if ($proveedor_id_filtro > 0) {
    $sql .= " AND p.proveedor_id = ?";
}

$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("[historial_producto] prepare producto: " . $conn->error);
    header('Location: /admin/stock/productos.php?error=db');
    exit;
}

if ($proveedor_id_filtro > 0) {
    $stmt->bind_param("ii", $producto_id, $proveedor_id_filtro);
} else {
    $stmt->bind_param("i", $producto_id);
}

$stmt->execute();
$producto = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$producto) {
    error_log("[historial_producto] Producto no encontrado o sin permiso. Producto: $producto_id, proveedor: $proveedor_id_filtro, usuario: $usuario_id_actual");
    header('Location: /admin/stock/productos.php?error=acceso');
    exit;
}

// ============================================
// CARGAR HISTORIAL (con LIMIT para escalabilidad)
// ============================================
$limite_historial = 200; // últimas 200 entradas
$stmt_hist = $conn->prepare(
    "SELECT * FROM historial_productos_cambios 
     WHERE producto_id = ? 
     ORDER BY fecha DESC 
     LIMIT ?"
);
$stmt_hist->bind_param("ii", $producto_id, $limite_historial);
$stmt_hist->execute();
$historial = $stmt_hist->get_result();
$total_historial = $historial->num_rows;

// ============================================
// FUNCIONES AUXILIARES
// ============================================

function getCategoriaNombre($conn, $categoria_id) {
    if (empty($categoria_id) || intval($categoria_id) <= 0) return 'Sin categoría';
    $stmt = $conn->prepare("SELECT nombre FROM categorias WHERE id = ? LIMIT 1");
    if (!$stmt) return 'Categoría eliminada';
    $cat_id_int = intval($categoria_id);
    $stmt->bind_param("i", $cat_id_int);
    $stmt->execute();
    $result = $stmt->get_result();
    $nombre = $result->num_rows > 0 ? $result->fetch_assoc()['nombre'] : 'Categoría eliminada';
    $stmt->close();
    return $nombre;
}

function formatearPeso($peso) {
    if ($peso === null || $peso === '') return '—';
    return number_format(floatval($peso), 3) . ' kg';
}

function formatearRebaja($porcentaje, $precio_original, $precio_final) {
    if ($porcentaje > 0) {
        return "-{$porcentaje}% (Original: $" . number_format(floatval($precio_original), 2) . " → Final: $" . number_format(floatval($precio_final), 2) . ")";
    }
    return 'Sin rebaja';
}

function formatearMoneda($valor, $moneda) {
    $moneda = strtoupper(trim((string)$moneda));
    if ($moneda === '') $moneda = 'USD';
    $valor = floatval($valor);
    // Mostrar el símbolo cuando sea USD; si no, mostrar código
    if ($moneda === 'USD') {
        return '$' . number_format($valor, 2) . ' USD';
    }
    return number_format($valor, 2) . ' ' . $moneda;
}

/**
 * Nombre legible para un campo del historial.
 */
function nombreCampoLegible($campo) {
    return match($campo) {
        'nombre' => 'Nombre',
        'descripcion' => 'Descripción',
        'marca' => 'Marca',
        'peso' => 'Peso (kg)',
        'cantidad' => 'Cantidad',
        'precio_costo' => 'Costo USD',
        'precio', 'precio_venta' => 'Precio Venta',
        'porcentaje_rebaja' => '% Rebaja',
        'precio_original' => 'Precio Original',
        'precio_adquisicion' => 'Precio Adquisición',
        'moneda_adquisicion' => 'Moneda Adquisición',
        'porcentaje_ganancia' => '% Ganancia',
        'categoria_id' => 'Categoría',
        'activo' => 'Activo',
        'proveedor_id' => 'Proveedor',
        default => ucfirst(str_replace('_', ' ', $campo))
    };
}

/**
 * Formatea el valor de un campo del historial según su tipo.
 * Devuelve null si el campo debe omitirse.
 */
function formatearValorCampo($campo, $valor, $cambios_completos, $conn, $es_antes = false) {
    if ($campo === 'imagen_url') return null;
    if ($campo === 'precio_original') return null; // se muestra dentro de % rebaja

    if ($campo === 'categoria_id') {
        return getCategoriaNombre($conn, $valor);
    }
    if ($campo === 'peso') {
        return formatearPeso($valor);
    }
    if ($campo === 'porcentaje_rebaja') {
        if ($es_antes) {
            $precio_original = $cambios_completos['precio_original']['antes'] ?? 0;
            $precio_final = $cambios_completos['precio']['antes'] ?? 0;
        } else {
            $precio_original = $cambios_completos['precio_original']['despues'] ?? 0;
            $precio_final = $cambios_completos['precio']['despues'] ?? 0;
        }
        return formatearRebaja($valor, $precio_original, $precio_final);
    }
    if ($campo === 'precio_adquisicion') {
        $moneda = $cambios_completos['moneda_adquisicion']['despues'] ?? ($cambios_completos['moneda_adquisicion'] ?? 'USD');
        return formatearMoneda($valor, $moneda);
    }
    if ($campo === 'precio_costo' || $campo === 'precio' || $campo === 'precio_venta') {
        return '$' . number_format(floatval($valor), 2) . ' USD';
    }
    if ($campo === 'porcentaje_ganancia') {
        return number_format(floatval($valor), 2) . ' %';
    }
    if ($campo === 'activo') {
        return (intval($valor) === 1) ? 'Sí' : 'No';
    }
    if ($campo === 'proveedor_id') {
        $pid = intval($valor);
        return ($pid > 0) ? "Proveedor #$pid" : 'Sin proveedor';
    }

    return (string)$valor;
}

/**
 * Devuelve true si el campo tuvo un cambio real (antes != después).
 * Compara como string normalizado (trim + cast).
 */
function campoCambioReal($valor_antes, $valor_despues) {
    $a = ($valor_antes === null) ? '' : (string)$valor_antes;
    $b = ($valor_despues === null) ? '' : (string)$valor_despues;
    return trim($a) !== trim($b);
}
?>

<style>
:root {
    --primary: #667eea;
    --secondary: #764ba2;
}

* { box-sizing: border-box; }

.historial-container {
    width: 100%;
    max-width: 1400px;
    margin: 1rem auto;
    padding: 0 1rem;
}

@media (min-width: 768px) {
    .historial-container { margin: 2rem auto; padding: 0 2rem; }
}

.historial-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

@media (max-width: 640px) {
    .historial-header { flex-direction: column; align-items: stretch; text-align: center; }
}

.historial-header h1 {
    font-size: 1.5rem;
    color: #2d3748;
    margin: 0;
}

@media (min-width: 768px) { .historial-header h1 { font-size: 1.8rem; } }

.btn-volver {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    width: auto;
    justify-content: center;
    min-height: 44px;
}

@media (min-width: 768px) { .btn-volver { padding: 0.6rem 1.2rem; } }

.btn-volver:hover {
    background: #e2e8f0;
    transform: translateY(-2px);
}

.info-producto-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    width: 100%;
}

@media (min-width: 768px) { .info-producto-card { padding: 1rem 1.5rem; margin-bottom: 2rem; } }

.info-producto-card p {
    margin: 0;
    font-size: 0.95rem;
}

@media (min-width: 768px) { .info-producto-card p { font-size: 1.1rem; } }

.info-producto-card strong { color: #2d3748; }

.tabla-wrapper {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    border-radius: 12px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.tabla-historial {
    width: 100%;
    min-width: 700px;
    border-collapse: collapse;
    background: white;
}

@media (max-width: 768px) { .tabla-historial { min-width: 650px; } }

.tabla-historial th {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.85rem 0.75rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
}

@media (min-width: 768px) { .tabla-historial th { padding: 1rem; font-size: 0.85rem; } }

.tabla-historial td {
    padding: 0.85rem 0.75rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: top;
    font-size: 0.8rem;
}

@media (min-width: 768px) { .tabla-historial td { padding: 1rem; font-size: 0.9rem; } }

.tabla-historial tr:hover { background: #f8fafc; }

.badge-accion {
    display: inline-block;
    padding: 0.25rem 0.6rem;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
    color: white;
    text-align: center;
    min-width: 65px;
}

@media (min-width: 768px) { .badge-accion { padding: 0.3rem 0.8rem; font-size: 0.8rem; min-width: 70px; } }

.badge-crear { background: #48bb78; }
.badge-editar { background: #4299e1; }
.badge-editar-masivo { background: #805ad5; }
.badge-eliminar { background: #f56565; }

.cambios-detalle {
    background: #f7fafc;
    border-radius: 8px;
    padding: 0.6rem;
    font-size: 0.75rem;
    max-width: 400px;
}

@media (min-width: 768px) { .cambios-detalle { padding: 0.8rem; font-size: 0.85rem; max-width: 500px; } }

.cambio-item {
    margin-bottom: 0.6rem;
    padding-bottom: 0.6rem;
    border-bottom: 1px dashed #e2e8f0;
}

.cambio-item:last-child { margin-bottom: 0; padding-bottom: 0; border-bottom: none; }

.campo-nombre {
    font-weight: 600;
    color: #4a5568;
    text-transform: uppercase;
    font-size: 0.65rem;
    margin-bottom: 0.25rem;
}

@media (min-width: 768px) { .campo-nombre { font-size: 0.75rem; margin-bottom: 0.3rem; } }

.valor-antes {
    color: #f56565;
    font-size: 0.75rem;
    margin-left: 0.5rem;
    word-break: break-word;
}

@media (min-width: 768px) { .valor-antes { font-size: 0.9rem; margin-left: 1rem; } }

.valor-despues {
    color: #48bb78;
    font-size: 0.75rem;
    margin-left: 0.5rem;
    word-break: break-word;
}

@media (min-width: 768px) { .valor-despues { font-size: 0.9rem; margin-left: 1rem; } }

.valor-antes small, .valor-despues small { font-size: 0.65rem; opacity: 0.8; }

@media (min-width: 768px) { .valor-antes small, .valor-despues small { font-size: 0.7rem; } }

.fecha-cell { white-space: nowrap; font-size: 0.7rem; }
@media (min-width: 768px) { .fecha-cell { font-size: 0.85rem; } }

.usuario-cell { font-weight: 600; color: #2d3748; font-size: 0.75rem; }
@media (min-width: 768px) { .usuario-cell { font-size: 0.9rem; } }

.ip-cell { font-family: monospace; font-size: 0.7rem; color: #718096; }
@media (min-width: 768px) { .ip-cell { font-size: 0.8rem; } }

.sin-historial {
    background: white;
    border-radius: 12px;
    padding: 2rem 1rem;
    text-align: center;
    color: #718096;
    width: 100%;
}

@media (min-width: 768px) { .sin-historial { padding: 3rem; } }

.sin-historial p { margin: 0; font-size: 0.9rem; }
@media (min-width: 768px) { .sin-historial p { font-size: 1rem; } }

body { overflow-x: hidden; }

.container-fluid, .main-content {
    padding-left: 0 !important;
    padding-right: 0 !important;
    max-width: 100% !important;
    overflow-x: hidden !important;
}
</style>

<div class="historial-container">
    <div class="historial-header">
        <h1>📋 Historial de Cambios</h1>
        <a href="/admin/stock/productos.php" class="btn-volver">← Volver</a>
    </div>

    <div class="info-producto-card">
        <p>📦 Producto: <strong><?php echo htmlspecialchars($producto['nombre']); ?></strong></p>
        <?php if ($total_historial >= $limite_historial): ?>
            <p style="margin-top:0.5rem; font-size:0.85rem; color:#718096;">
                Mostrando los últimos <?php echo $limite_historial; ?> cambios.
            </p>
        <?php endif; ?>
    </div>

    <?php if ($historial->num_rows > 0): ?>
        <div class="tabla-wrapper">
            <table class="tabla-historial">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Usuario</th>
                        <th>Acción</th>
                        <th>Cambios Realizados</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $historial->fetch_assoc()): 
                        $cambios = json_decode($row['cambios'], true);
                        if (json_last_error() !== JSON_ERROR_NONE || !is_array($cambios)) {
                            $cambios = [];
                        }
                        $accion = $row['accion'] ?? '';
                        $badge_class = match($accion) {
                            'crear' => 'badge-crear',
                            'editar' => 'badge-editar',
                            'editar_masivo' => 'badge-editar-masivo',
                            'eliminar' => 'badge-eliminar',
                            default => 'badge-editar'
                        };
                        $ts = strtotime($row['fecha'] ?? '');
                        $fecha_formateada = ($ts !== false) ? date('d/m/Y H:i:s', $ts) : '—';
                    ?>
                    <tr>
                        <td class="fecha-cell"><?php echo $fecha_formateada; ?></td>
                        <td class="usuario-cell"><?php echo htmlspecialchars($row['usuario_nombre'] ?? 'Sistema'); ?></td>
                        <td>
                            <span class="badge-accion <?php echo $badge_class; ?>">
                                <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $accion))); ?>
                            </span>
                        </td>
                                                <td>
                            <?php if (($accion === 'crear' || $accion === 'editar' || $accion === 'editar_masivo') && !empty($cambios)): ?>
                                <?php $es_edicion = ($accion === 'editar' || $accion === 'editar_masivo'); ?>
                                <div class="cambios-detalle">
                                    <?php foreach ($cambios as $campo => $valores):
                                        $nombre_campo = nombreCampoLegible($campo);

                                        if ($es_edicion) {
                                            $valor_antes_raw   = $valores['antes'] ?? '';
                                            $valor_despues_raw = $valores['despues'] ?? '';

                                            // ✅ SOLO mostrar si hubo cambio real
                                            if (!campoCambioReal($valor_antes_raw, $valor_despues_raw)) {
                                                continue;
                                            }

                                            $valor_antes   = formatearValorCampo($campo, $valor_antes_raw, $cambios, $conn, true);
                                            $valor_despues = formatearValorCampo($campo, $valor_despues_raw, $cambios, $conn, false);

                                            if ($valor_antes === null && $valor_despues === null) continue;
                                        } else {
                                            // crear: $valores es el valor directo (no array antes/despues)
                                            $valor_solo = is_array($valores) ? ($valores['despues'] ?? '') : $valores;

                                            // ✅ No mostrar campos vacíos en creación
                                            if ($valor_solo === '' || $valor_solo === null) continue;

                                            $valor_formateado = formatearValorCampo($campo, $valor_solo, $cambios, $conn, false);
                                            if ($valor_formateado === null) continue;
                                        }
                                    ?>
                                        <?php if ($es_edicion): ?>
                                            <div class="cambio-item">
                                                <div class="campo-nombre"><?php echo htmlspecialchars($nombre_campo); ?></div>
                                                <div class="valor-antes">
                                                    <small>⬅️ Antes:</small> <?php echo htmlspecialchars((string)$valor_antes); ?>
                                                </div>
                                                <div class="valor-despues">
                                                    <small>➡️ Después:</small> <?php echo htmlspecialchars((string)$valor_despues); ?>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <div style="margin-bottom: 0.5rem;">
                                                <strong><?php echo htmlspecialchars($nombre_campo); ?>:</strong>
                                                <div><?php echo htmlspecialchars((string)$valor_formateado); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>

                            <?php elseif ($accion === 'eliminar'): ?>
                                <div class="cambios-detalle">
                                    <em style="color: #f56565;">🗑️ Producto eliminado</em>
                                    <?php if (isset($cambios['nombre'])): ?>
                                        <div style="margin-top: 0.5rem;">
                                            <strong>Nombre:</strong> <?php echo htmlspecialchars(is_array($cambios['nombre']) ? ($cambios['nombre']['antes'] ?? '') : $cambios['nombre']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                            <?php else: ?>
                                <div class="cambios-detalle">
                                    <em>Sin detalles</em>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="ip-cell"><?php echo htmlspecialchars($row['ip_address'] ?? ''); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="sin-historial">
            <p>📭 No hay cambios registrados para este producto.</p>
        </div>
    <?php endif; ?>
</div>

<?php
if (isset($stmt_hist)) $stmt_hist->close();
// No cerramos $conn; footer.php puede necesitarlo
require_once __DIR__ . '/../../footer.php';
?>
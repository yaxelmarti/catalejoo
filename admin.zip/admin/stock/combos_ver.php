<?php
// ============================================
// COMBOS VER - DETALLE DE UN COMBO
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/csrf.php';

// ============================================
// ROLES PERMITIDOS
// ============================================
$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($_SESSION['rol'], $roles_ver)) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// PERMISOS DE GESTIÓN
// ============================================
$roles_gestion = ['Super Admin', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_gestion);

// ============================================
// ID DEL COMBO
// ============================================
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    header('Location: combos.php');
    exit;
}

// ============================================
// CARGAR COMBO
// ============================================
$stmt = $conn->prepare("SELECT c.*, pr.nombre_tienda,
                               (SELECT COUNT(*) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as productos_distintos,
                               (SELECT COALESCE(SUM(cp.cantidad), 0) FROM combo_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.combo_id = c.id AND cp.cantidad > 0 AND p.activo = 1) as unidades_totales
                        FROM combos c 
                        LEFT JOIN proveedores pr ON c.proveedor_id = pr.id 
                        WHERE c.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$combo = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$combo) {
    header('Location: combos.php?error=no_encontrado');
    exit;
}

// ============================================
// VERIFICAR PROPIEDAD
// ============================================
if ($proveedor_id_usuario > 0 && $combo['proveedor_id'] != $proveedor_id_usuario) {
    $_SESSION['mensaje'] = '❌ No tienes permiso para ver este combo';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: combos.php');
    exit;
}

// ============================================
// CARGAR PRODUCTOS DEL COMBO
// ============================================
$stmt_prod = $conn->prepare("
    SELECT cp.*, p.nombre, p.imagen_url, p.precio, p.precio_original, p.porcentaje_rebaja, p.activo AS producto_activo
    FROM combo_productos cp 
    JOIN productos p ON cp.producto_id = p.id 
    WHERE cp.combo_id = ?
");
$stmt_prod->bind_param("i", $id);
$stmt_prod->execute();
$productos = $stmt_prod->get_result();

// ============================================
// CONFIGURACIÓN DE MONEDA
// ============================================
$config = [];
$result = $conn->query("SELECT clave, valor FROM configuracion WHERE clave IN ('moneda_simbolo', 'moneda_codigo')");
while($row = $result->fetch_assoc()) {
    $config[$row['clave']] = $row['valor'];
}
$moneda_simbolo = $config['moneda_simbolo'] ?? '$';
$moneda_codigo = $config['moneda_codigo'] ?? 'USD';
?>

<style>
:root {
    --primary: <?php echo $color_primario; ?>;
    --secondary: <?php echo $color_secundario; ?>;
}

.combo-detalle {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    margin-top: 1rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.combo-header {
    display: flex;
    gap: 2rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}

.combo-imagen {
    flex: 0 0 200px;
    text-align: center;
}

.combo-imagen img {
    max-width: 100%;
    max-height: 200px;
    border-radius: 12px;
    object-fit: contain;
}

.combo-info {
    flex: 1;
    min-width: 250px;
}

.combo-nombre {
    font-size: 1.8rem;
    margin-bottom: 0.5rem;
    color: #2d3748;
}

.combo-descripcion {
    color: #718096;
    line-height: 1.6;
    margin-bottom: 1rem;
}

.combo-stats {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    margin-bottom: 1rem;
}

.combo-stat {
    background: #f7fafc;
    padding: 0.5rem 1rem;
    border-radius: 8px;
}

.combo-precio {
    margin-bottom: 1rem;
}

.precio-original {
    text-decoration: line-through;
    color: #ef4444;
    margin-right: 0.5rem;
}

.precio-final {
    font-size: 1.5rem;
    font-weight: 700;
    color: #10b981;
}

.precio-normal {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--primary);
}

.btn-guardar {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 600;
}

.btn-guardar:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102,126,234,0.3);
}

.productos-tabla {
    margin-top: 2rem;
}

.productos-tabla table {
    width: 100%;
    border-collapse: collapse;
}

.productos-tabla th {
    text-align: left;
    padding: 0.75rem;
    background: #f7fafc;
    font-weight: 600;
}

.productos-tabla td {
    padding: 0.75rem;
    border-bottom: 1px solid #edf2f7;
}

.btn-volver {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.btn-volver:hover {
    background: #e2e8f0;
}

/* Responsive */
@media (max-width: 768px) {
    .combo-detalle {
        padding: 1rem;
    }
    
    .combo-header {
        flex-direction: column;
        gap: 1rem;
    }
    
    .combo-imagen {
        flex: 0 0 auto;
    }
    
    .combo-imagen img {
        max-height: 150px;
    }
    
    .combo-nombre {
        font-size: 1.4rem;
    }
    
    .productos-tabla {
        overflow-x: auto;
    }
    
    .productos-tabla table {
        min-width: 500px;
    }
    
    .productos-tabla th,
    .productos-tabla td {
        padding: 0.5rem;
        font-size: 0.8rem;
    }
}

@media (max-width: 480px) {
    .combo-detalle {
        padding: 0.75rem;
    }
    
    .combo-nombre {
        font-size: 1.2rem;
    }
    
    .combo-precio {
        font-size: 1.2rem;
    }
    
    .precio-final, .precio-normal {
        font-size: 1.2rem;
    }
}
</style>

<main class="main-content">
    <a href="combos.php" class="btn-volver">← Volver a la lista</a>
    
    <div class="combo-detalle">
        <div class="combo-header">
            <div class="combo-imagen">
                <?php if (!empty($combo['imagen_url'])): ?>
                    <img src="<?php echo htmlspecialchars($combo['imagen_url']); ?>" alt="<?php echo htmlspecialchars($combo['nombre']); ?>">
                <?php else: ?>
                    <div style="width: 200px; height: 200px; background: #f7fafc; display: flex; align-items: center; justify-content: center; border-radius: 12px; font-size: 3rem;">🎁</div>
                <?php endif; ?>
            </div>
            <div class="combo-info">
                <h1 class="combo-nombre"><?php echo htmlspecialchars($combo['nombre']); ?></h1>
                <div class="combo-descripcion"><?php echo nl2br(htmlspecialchars($combo['descripcion'] ?? '')); ?></div>
                
                <div style="margin-bottom: 0.5rem;">
                    <span style="font-weight: 600; color: #4a5568;">🏪 Proveedor:</span>
                    <span style="color: #2d3748;">
                        <?php if (!empty($combo['nombre_tienda'])): ?>
                            <?php echo htmlspecialchars($combo['nombre_tienda']); ?>
                        <?php else: ?>
                            <span style="color: #9ca3af;">—</span>
                        <?php endif; ?>
                    </span>
                </div>
                
                <div class="combo-stats">
                    <div class="combo-stat">📦 <?php echo intval($combo['productos_distintos']); ?> productos distintos</div>
                    <div class="combo-stat">📦 <?php echo intval($combo['unidades_totales']); ?> unidades totales</div>
                    <div class="combo-stat">⚡ <?php echo $combo['activo'] ? 'Activo' : 'Inactivo'; ?></div>
                    <div class="combo-stat">📊 Stock: <?php echo intval($combo['stock_combo']); ?> / <?php echo intval($combo['stock_calculado']); ?></div>
                </div>
                <div class="combo-precio">
                    <?php if ($combo['porcentaje_rebaja'] > 0): ?>
                        <span class="precio-original"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio'], 2); ?></span>
                        <span class="precio-final"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio_final'], 2); ?></span>
                        <small style="color: #718096;"> (<?php echo $combo['porcentaje_rebaja']; ?>% de descuento)</small>
                    <?php else: ?>
                        <span class="precio-normal"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio'], 2); ?></span>
                    <?php endif; ?>
                    <small><?php echo $moneda_codigo; ?></small>
                </div>
                <div>
                    <?php if ($puede_gestionar): ?>
                        <a href="combos_editar.php?id=<?php echo $combo['id']; ?>" class="btn-guardar" style="padding: 0.5rem 1rem; font-size: 0.9rem; text-decoration: none;">✏️ Editar Combo</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="productos-tabla">
            <h3>📦 Productos incluidos</h3>
            <table>
                <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Precio unitario</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $total_productos = 0;
                    $total_base = 0;
                    while($item = $productos->fetch_assoc()): 
                        $es_activo = intval($item['producto_activo'] ?? 1) === 1 && intval($item['cantidad']) > 0;
                        $subtotal = $es_activo ? ($item['precio'] * $item['cantidad']) : 0;
                        $subtotal_base = $es_activo ? ((($item['precio_original'] ?? 0) > 0 ? $item['precio_original'] : $item['precio']) * $item['cantidad']) : 0;
                        $total_productos += $subtotal;
                        $total_base += $subtotal_base;
                    ?>
                        <tr style="<?php echo $es_activo ? '' : 'opacity: 0.55; background: #f9fafb;'; ?>">
                            <td>
                                <?php if (!empty($item['imagen_url'])): ?>
                                    <img src="<?php echo htmlspecialchars($item['imagen_url']); ?>" style="width: 40px; height: 40px; object-fit: cover; border-radius: 6px;">
                                <?php else: ?>
                                    <div style="width: 40px; height: 40px; background: #f7fafc; display: flex; align-items: center; justify-content: center; border-radius: 6px;">📦</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($item['nombre']); ?></strong>
                                <?php if (!$es_activo): ?>
                                    <span style="display: inline-block; margin-left: 6px; padding: 1px 6px; font-size: 0.72rem; border-radius: 6px; background: #fee2e2; color: #991b1b;">
                                        <?php echo intval($item['producto_activo'] ?? 1) === 0 ? 'Inactivo' : 'Sin cantidad'; ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>x<?php echo intval($item['cantidad']); ?></td>
                            <td>
                                <?php if (($item['porcentaje_rebaja'] ?? 0) > 0 && ($item['precio_original'] ?? 0) > 0): ?>
                                    <div style="text-decoration: line-through; color: #ef4444; font-size: 0.8rem;">
                                        <?php echo $moneda_simbolo; ?><?php echo number_format($item['precio_original'], 2); ?>
                                    </div>
                                    <div style="color: #10b981; font-weight: 600;">
                                        <?php echo $moneda_simbolo; ?><?php echo number_format($item['precio'], 2); ?>
                                    </div>
                                <?php else: ?>
                                    <?php echo $moneda_simbolo; ?><?php echo number_format($item['precio'], 2); ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $moneda_simbolo; ?><?php echo number_format($subtotal, 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot>
                    <tr style="background: #f7fafc;">
                        <td colspan="4" style="text-align: right; font-weight: 600;">Total en productos (sin rebaja):</td>
                        <td style="font-weight: 600; text-decoration: line-through; color: #ef4444;">
                            <?php echo $moneda_simbolo; ?><?php echo number_format($total_base, 2); ?>
                        </td>
                    </tr>
                    <?php if ($combo['porcentaje_rebaja'] > 0): ?>
                    <tr>
                        <td colspan="4" style="text-align: right;">Descuento (<?php echo $combo['porcentaje_rebaja']; ?>%):</td>
                        <td style="color: #ef4444;">-<?php echo $moneda_simbolo; ?><?php echo number_format($total_base - $combo['precio_final'], 2); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr style="background: #f0fff4;">
                        <td colspan="4" style="text-align: right; font-weight: 600;">Precio final del combo:</td>
                        <td style="font-weight: 600; color: #10b981;"><?php echo $moneda_simbolo; ?><?php echo number_format($combo['precio_final'], 2); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</main>

<?php
$stmt_prod->close();
$conn->close();
include $_SERVER['DOCUMENT_ROOT'] . '/footer.php';
?>
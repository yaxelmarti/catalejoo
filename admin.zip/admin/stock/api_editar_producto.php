<?php
// ============================================
// API EDITAR PRODUCTO (26 Oct 2026 — corregido)
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

ob_clean();
header('Content-Type: application/json; charset=UTF-8');

try {
    require_once __DIR__ . '/../../conexion.php';
    require_once __DIR__ . '/../../includes/proveedor_utils.php';
    require_once __DIR__ . '/../../includes/csrf.php';
    require_once __DIR__ . '/../../includes/historial.php';
    require_once __DIR__ . '/../../includes/moneda_funciones.php';

    // ===== VERIFICAR SESIÓN =====
    if (!isset($_SESSION['usuario_id'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Sesión expirada']);
        exit;
    }

    // ===== OBTENER PROVEEDOR DEL USUARIO =====
    $rol_actual = trim($_SESSION['rol'] ?? '');
    $es_super_admin = ($rol_actual === 'Super Admin');
    $proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $rol_actual);
    $es_proveedor = esRolProveedor($rol_actual);

    if ($es_proveedor && $proveedor_id_usuario == 0) {
        echo json_encode(['success' => false, 'error' => 'No se encontró una tienda asociada a tu usuario']);
        exit;
    }

    // ===== VERIFICAR PERMISOS DE EDICIÓN =====
    $roles_edicion = ['Super Admin', 'Gerente', 'Proveedor', 'Vendedor', 'Inventario'];
    if (!in_array($rol_actual, $roles_edicion, true)) {
        echo json_encode(['success' => false, 'error' => 'No tienes permiso para editar']);
        exit;
    }

    if (!$conn) {
        throw new Exception('No hay conexión');
    }

    $input = json_decode(file_get_contents('php://input'), true);

    // ============================================
    // VALIDACIÓN CSRF
    // ============================================
    $token_csrf = $input['csrf_token'] ?? ($_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? ''));
    if (!function_exists('csrf_validar') || !csrf_validar($token_csrf)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Token de seguridad inválido. Recarga la página e intenta de nuevo.']);
        exit;
    }

    if (!$input || empty($input['id'])) {
        echo json_encode(['success' => false, 'error' => 'ID requerido']);
        exit;
    }

    $id = intval($input['id']);

    // ============================================
    // VERIFICAR PROPIEDAD DEL PRODUCTO
    // ============================================
    if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_usuario)) {
        error_log("[api_editar_producto] Sin permiso (usuario={$_SESSION['usuario_id']}, id={$id}, proveedor={$proveedor_id_usuario})");
        echo json_encode(['success' => false, 'error' => 'No tienes permiso para editar este producto']);
        exit;
    }

    // ============================================
    // OBTENER DATOS ACTUALES DEL PRODUCTO
    // ============================================
    $stmt_actual = $conn->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt_actual->bind_param("i", $id);
    $stmt_actual->execute();
    $producto_actual = $stmt_actual->get_result()->fetch_assoc();
    $stmt_actual->close();

    if (!$producto_actual) {
        echo json_encode(['success' => false, 'error' => 'Producto no encontrado']);
        exit;
    }

    // ============================================
    // SANITIZAR ENTRADAS
    // ============================================
    $nombre = trim($input['nombre'] ?? $producto_actual['nombre']);
    $marca = trim($input['marca'] ?? $producto_actual['marca']);
    $descripcion = trim($input['descripcion'] ?? $producto_actual['descripcion']);
    $cantidad = intval($input['cantidad'] ?? $producto_actual['cantidad']);
    $peso = floatval($input['peso'] ?? $producto_actual['peso']);
    $categoria_id = isset($input['categoria_id']) && $input['categoria_id'] !== '' ? intval($input['categoria_id']) : null;
    $imagen_url = trim($input['imagen_url'] ?? $producto_actual['imagen_url']);
    $porcentaje_rebaja = floatval($input['porcentaje_rebaja'] ?? $producto_actual['porcentaje_rebaja']);

    // ============================================
    // MONEDA Y COSTO
    // ============================================
    $moneda_adquisicion = strtoupper(trim($input['moneda_adquisicion'] ?? ($producto_actual['moneda_adquisicion'] ?? 'USD')));
$costo = floatval($input['costo'] ?? 0);
$porcentaje_ganancia = floatval($input['porcentaje_ganancia'] ?? ($producto_actual['porcentaje_ganancia'] ?? 0));

// Fallback: si no viene costo, usar el valor actual de BD
if ($costo <= 0) {
    $costo = ($moneda_adquisicion === 'USD') 
        ? floatval($producto_actual['precio_costo'] ?? 0) 
        : floatval($producto_actual['precio_adquisicion'] ?? 0);
}

    // Determinar proveedor para tasa
    $proveedor_id_param = $proveedor_id_usuario;
    if ($es_super_admin && !empty($input['proveedor_id'])) {
        $prov_input = intval($input['proveedor_id']);
        if ($prov_input > 0) {
            // Validar que el proveedor existe y está activo
            $stmt_p = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1 LIMIT 1");
            $stmt_p->bind_param("i", $prov_input);
            $stmt_p->execute();
            if ($stmt_p->get_result()->num_rows > 0) {
                $proveedor_id_param = $prov_input;
            }
            $stmt_p->close();
        }
    }

    // Validar moneda contra las de adquisición del proveedor
    $monedas_validas = getMonedasParaAdquisicion($conn, $proveedor_id_param);
    if (!in_array($moneda_adquisicion, $monedas_validas)) {
        $moneda_adquisicion = 'USD';
    }

    // ============================================
    // RECALCULAR PRECIOS EN SERVIDOR
    // ============================================
        // precio_adquisicion SIEMPRE tiene el valor en moneda local (o USD si moneda = USD)
$precio_adquisicion = $costo;

if ($moneda_adquisicion === 'USD') {
    $precio_costo = $costo;
} else {
    $tasa = getTasaProveedor($conn, $proveedor_id_param, $moneda_adquisicion);
    if ($tasa <= 0) {
        throw new Exception("No hay tasa de cambio configurada para {$moneda_adquisicion}. Ve a Configuración → Monedas para definir una tasa propia o usar la global.");
    }
    $precio_costo = $costo / $tasa;
}

    $precio_venta = $precio_costo * (1 + $porcentaje_ganancia / 100);
    $precio_final = ($porcentaje_rebaja > 0) ? ($precio_venta * (100 - $porcentaje_rebaja) / 100) : $precio_venta;
    $precio_original = ($porcentaje_rebaja > 0) ? $precio_venta : 0;

    // ============================================
    // CONSTRUIR SQL
    // ============================================
    $sql = "UPDATE productos SET 
                nombre = ?, 
                marca = ?, 
                descripcion = ?, 
                precio_costo = ?, 
                precio = ?, 
                precio_original = ?, 
                porcentaje_rebaja = ?, 
                precio_adquisicion = ?, 
                moneda_adquisicion = ?, 
                porcentaje_ganancia = ?, 
                cantidad = ?, 
                peso = ?, 
                categoria_id = ?, 
                imagen_url = ?, 
                proveedor_id = ?
            WHERE id = ?";

    $tipos = 's' . 's' . 's' . 'd' . 'd' . 'd' . 'd' . 'd' . 's' . 'd' . 'i' . 'd' . 'i' . 's' . 'i' . 'i';
    
    if (strlen($tipos) !== 16) {
        throw new Exception("Desajuste de tipos: string=" . strlen($tipos) . " esperado=16");
    }

        $categoria_id_param = $categoria_id ?? 0;
    $proveedor_id_param_final = $proveedor_id_param > 0 ? $proveedor_id_param : $producto_actual['proveedor_id'];

    // ============================================
    // TRANSACCIÓN: UPDATE + HISTORIAL
    // ============================================
    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error al preparar UPDATE: " . $conn->error);
        }

        $stmt->bind_param(
            $tipos,
            $nombre,
            $marca,
            $descripcion,
            $precio_costo,
            $precio_final,
            $precio_original,
            $porcentaje_rebaja,
            $precio_adquisicion,
            $moneda_adquisicion,
            $porcentaje_ganancia,
            $cantidad,
            $peso,
            $categoria_id_param,
            $imagen_url,
            $proveedor_id_param_final,
            $id
        );

        if (!$stmt->execute()) {
            throw new Exception("Error al ejecutar UPDATE: " . $stmt->error);
        }

        $stmt->close();

                // ============================================
        // REGISTRAR EN HISTORIAL (solo campos que cambiaron)
        // ============================================
        if (function_exists('registrarCambioProducto')) {
            $cambios = [];
            $campos_comparar = [
                'nombre'              => $nombre,
                'marca'               => $marca,
                'descripcion'         => $descripcion,
                'precio_costo'        => $precio_costo,
                'precio'              => $precio_final,          // BD guarda precio FINAL (con rebaja)
                'precio_original'     => $precio_original,       // 0 si no hay rebaja
                'porcentaje_rebaja'   => $porcentaje_rebaja,
                'cantidad'            => $cantidad,
                'peso'                => $peso,
                'categoria_id'        => $categoria_id_param,
                'imagen_url'          => $imagen_url,
                'precio_adquisicion'  => $precio_adquisicion,
                'moneda_adquisicion'  => $moneda_adquisicion,
                'porcentaje_ganancia' => $porcentaje_ganancia,
                'proveedor_id'        => $proveedor_id_param_final,
            ];

            foreach ($campos_comparar as $campo_bd => $valor_nuevo) {
                $valor_anterior = $producto_actual[$campo_bd] ?? '';

                // Normalizar a string con trim
                $ant_str = trim((string)($valor_anterior ?? ''));
                $nue_str = trim((string)($valor_nuevo ?? ''));

                // Comparación numérica robusta (evita falsos positivos "10" vs "10.00")
                if (is_numeric($ant_str) && is_numeric($nue_str)) {
                    if (abs((float)$ant_str - (float)$nue_str) < 0.0001) {
                        continue;
                    }
                } else {
                    if ($ant_str === $nue_str) {
                        continue;
                    }
                }

                $cambios[$campo_bd] = [
                    'antes' => $ant_str,
                    'despues' => $nue_str,
                ];
            }

            if (!empty($cambios)) {
                registrarCambioProducto($conn, $id, 'editar', $cambios);
                error_log("[api_editar_producto] historial editar: " . json_encode($cambios));
            } else {
                error_log("[api_editar_producto] sin cambios reales (usuario={$_SESSION['usuario_id']}, id={$id})");
            }
        }

        $conn->commit();

    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }

    // ============================================
    // ACTUALIZAR COMBOS
    // ============================================
    try {
        $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
        if (file_exists($ruta_combos)) {
            include_once $ruta_combos;
            if (function_exists('actualizarCombosPorProducto')) {
                actualizarCombosPorProducto($conn, $id);
            }
        }
    } catch (Throwable $e_combos) {
        error_log('[api_editar_producto actualizar_combos] ' . $e_combos->getMessage());
    }

    // ============================================
    // OBTENER PRODUCTO ACTUALIZADO
    // ============================================
    $sql_select = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono,
                          pr.nombre_tienda
                   FROM productos p 
                   LEFT JOIN categorias c ON p.categoria_id = c.id 
                   LEFT JOIN proveedores pr ON p.proveedor_id = pr.id
                   WHERE p.id = ?";

    $stmt_sel = $conn->prepare($sql_select);
    if ($stmt_sel) {
        $stmt_sel->bind_param("i", $id);
        $stmt_sel->execute();
        $result = $stmt_sel->get_result();
        $producto = $result->fetch_assoc();
        $stmt_sel->close();

        if ($producto) {
            error_log("[api_editar_producto] OK (usuario={$_SESSION['usuario_id']}, id={$id}, proveedor={$proveedor_id_param_final})");
            echo json_encode([
                'success' => true,
                'message' => 'Producto actualizado',
                'producto' => $producto
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'message' => 'Producto actualizado pero no se pudo obtener los datos',
                'producto' => null
            ]);
        }
    } else {
        throw new Exception("Error al preparar SELECT: " . $conn->error);
    }

} catch (Throwable $e) {
    error_log('[api_editar_producto] Error: ' . $e->getMessage() . ' | Línea: ' . $e->getLine());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error al procesar la solicitud: ' . $e->getMessage()]);
}

if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
}
?>
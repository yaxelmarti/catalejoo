<?php
// ============================================
// COMBOS ACCIONES - GESTIÓN DE COMBOS
// ============================================

define('SEGURO', true);

if (!defined('SEGURO')) {
    http_response_code(403);
    exit('Acceso directo no permitido');
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_gestionar) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

// Validar que el proveedor existe y está activo
if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF PROTECTION
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$accion = $_GET['accion'] ?? '';

// ============================================
// FUNCIÓN PARA VERIFICAR PROPIEDAD DEL COMBO
// ============================================
function verificarPropiedadCombo($conn, $combo_id, $proveedor_id_usuario) {
    if ($proveedor_id_usuario == 0) {
        return true; // Es administrador, puede ver todo
    }
    
    $stmt = $conn->prepare("SELECT proveedor_id FROM combos WHERE id = ?");
    $stmt->bind_param("i", $combo_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['proveedor_id'] == $proveedor_id_usuario;
    }
    $stmt->close();
    return false;
}

function verificarPropiedadCombos($conn, $combo_ids, $proveedor_id_usuario) {
    if ($proveedor_id_usuario == 0) {
        return true; // Es administrador, puede ver todo
    }
    
    $placeholders = implode(',', array_fill(0, count($combo_ids), '?'));
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM combos WHERE id IN ($placeholders) AND proveedor_id != ?");
    $types = str_repeat('i', count($combo_ids)) . 'i';
    $params = array_merge($combo_ids, [$proveedor_id_usuario]);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    return $row['total'] == 0;
}

// ============================================
// CAMBIAR ESTADO (ACTIVAR/DESACTIVAR)
// ============================================
if ($accion == 'toggle_estado' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $estado_actual = intval($_GET['estado']);
    $nuevo_estado = $estado_actual == 1 ? 0 : 1;
    
    // 🔒 Verificar que el combo pertenece al proveedor
    if (!verificarPropiedadCombo($conn, $id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este combo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
    
    $stmt = $conn->prepare("UPDATE combos SET activo = ? WHERE id = ?");
    $stmt->bind_param("ii", $nuevo_estado, $id);
    $stmt->execute();
    
    // Si se desactiva el combo, liberar los productos
    if ($nuevo_estado == 0) {
        $stmt_prod = $conn->prepare("UPDATE productos SET en_combo = 0, combo_id = NULL WHERE combo_id = ?");
        $stmt_prod->bind_param("i", $id);
        $stmt_prod->execute();
    } else {
        // Si se reactiva, marcar los productos como en_combo
        $stmt_select = $conn->prepare("SELECT producto_id FROM combo_productos WHERE combo_id = ?");
        $stmt_select->bind_param("i", $id);
        $stmt_select->execute();
        $result = $stmt_select->get_result();
        
        $stmt_update = $conn->prepare("UPDATE productos SET en_combo = 1, combo_id = ? WHERE id = ?");
        while ($row = $result->fetch_assoc()) {
            $stmt_update->bind_param("ii", $id, $row['producto_id']);
            $stmt_update->execute();
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// ACCIONES MASIVAS
// ============================================
if ($accion == 'masiva' && isset($_POST['combos']) && isset($_POST['accion_masiva'])) {
    
    // 🔒 Verificar CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
    
    $combos_ids = json_decode($_POST['combos'], true);
    $accion_masiva = $_POST['accion_masiva'];
    
    if (!empty($combos_ids) && is_array($combos_ids)) {
        $ids = array_map('intval', $combos_ids);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));
        
        // 🔒 Verificar que todos los combos pertenecen al proveedor
        if (!verificarPropiedadCombos($conn, $ids, $proveedor_id_usuario)) {
            $_SESSION['mensaje'] = '❌ No tienes permiso para modificar algunos combos';
            $_SESSION['tipo_mensaje'] = 'error';
            header('Location: combos.php');
            exit;
        }
        
        if ($accion_masiva == 'activar') {
            $stmt = $conn->prepare("UPDATE combos SET activo = 1 WHERE id IN ($placeholders)");
            $stmt->bind_param($types, ...$ids);
            $stmt->execute();
            
            // Marcar productos de los combos activados
            $stmt_select = $conn->prepare("SELECT producto_id, combo_id FROM combo_productos WHERE combo_id IN ($placeholders)");
            $stmt_select->bind_param($types, ...$ids);
            $stmt_select->execute();
            $result = $stmt_select->get_result();
            
            $stmt_update = $conn->prepare("UPDATE productos SET en_combo = 1, combo_id = ? WHERE id = ?");
            while ($row = $result->fetch_assoc()) {
                $stmt_update->bind_param("ii", $row['combo_id'], $row['producto_id']);
                $stmt_update->execute();
            }
            $_SESSION['mensaje'] = "✅ " . count($ids) . " combos activados";
            
        } elseif ($accion_masiva == 'desactivar') {
            $stmt = $conn->prepare("UPDATE combos SET activo = 0 WHERE id IN ($placeholders)");
            $stmt->bind_param($types, ...$ids);
            $stmt->execute();
            
            // Liberar productos de los combos desactivados
            $stmt_update = $conn->prepare("UPDATE productos SET en_combo = 0, combo_id = NULL WHERE combo_id IN ($placeholders)");
            $stmt_update->bind_param($types, ...$ids);
            $stmt_update->execute();
            $_SESSION['mensaje'] = "✅ " . count($ids) . " combos desactivados";
            
        } elseif ($accion_masiva == 'eliminar' && $_SESSION['rol_nivel'] >= 2) {
            // Liberar productos antes de eliminar
            $stmt_update = $conn->prepare("UPDATE productos SET en_combo = 0, combo_id = NULL WHERE combo_id IN ($placeholders)");
            $stmt_update->bind_param($types, ...$ids);
            $stmt_update->execute();
            
            // Eliminar productos del combo
            $stmt_delete = $conn->prepare("DELETE FROM combo_productos WHERE combo_id IN ($placeholders)");
            $stmt_delete->bind_param($types, ...$ids);
            $stmt_delete->execute();
            
            // Eliminar los combos
            $stmt_delete = $conn->prepare("DELETE FROM combos WHERE id IN ($placeholders)");
            $stmt_delete->bind_param($types, ...$ids);
            $stmt_delete->execute();
            
            $_SESSION['mensaje'] = "✅ " . count($ids) . " combos eliminados";
        }
        $_SESSION['tipo_mensaje'] = "exito";
    } else {
        $_SESSION['mensaje'] = "❌ No se seleccionaron combos";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    // Redirigir de vuelta con los mismos filtros
    $query_params = $_GET;
    unset($query_params['accion']);
    unset($query_params['combos']);
    $query_string = http_build_query($query_params);
    header('Location: combos.php' . ($query_string ? '?' . $query_string : ''));
    exit;
}

// ============================================
// ELIMINAR COMBO INDIVIDUAL
// ============================================
if ($accion == 'eliminar' && isset($_GET['id']) && $_SESSION['rol_nivel'] >= 2) {
    $id = intval($_GET['id']);
    
    // 🔒 Verificar que el combo pertenece al proveedor
    if (!verificarPropiedadCombo($conn, $id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para eliminar este combo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
    
    // Liberar productos del combo
    $stmt = $conn->prepare("UPDATE productos SET en_combo = 0, combo_id = NULL WHERE combo_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    // Eliminar productos del combo
    $stmt = $conn->prepare("DELETE FROM combo_productos WHERE combo_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    // Eliminar combo
    $stmt = $conn->prepare("DELETE FROM combos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    
    $_SESSION['mensaje'] = "✅ Combo eliminado correctamente";
    $_SESSION['tipo_mensaje'] = "exito";
    
    $query_params = $_GET;
    unset($query_params['accion']);
    unset($query_params['id']);
    $query_string = http_build_query($query_params);
    header('Location: combos.php' . ($query_string ? '?' . $query_string : ''));
    exit;
}

// Si no hay acción válida, redirigir
header('Location: combos.php');
exit;
?>
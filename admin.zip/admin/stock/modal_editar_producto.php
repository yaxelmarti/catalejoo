<?php
// ============================================
// MODAL DE EDICIÓN DE PRODUCTOS
// Usa includes/moneda_funciones.php para:
//   - getMonedasDelProveedor() → monedas activas del proveedor
//   - getTasaProveedor() → tasa propia o global
// ============================================
if (!isset($conn) || !($conn instanceof mysqli)) {
    error_log('[modal_editar_producto] No hay conexión a BD');
    echo '<!-- modal_editar_producto: sin conexión -->';
    return;
}

require_once __DIR__ . '/../../includes/moneda_funciones.php';

$rol_actual_modal = $rol_actual ?? ($_SESSION['rol'] ?? '');
$proveedor_id_filtro_modal = intval($proveedor_id_filtro ?? 0);
$es_super_admin_modal = ($rol_actual_modal === 'Super Admin');
?>

<div id="modalEditarProducto" class="modal-overlay" style="display: none;">
    <div class="modal-contenido" style="max-width: 800px; width: 95%;">
        <span class="close-modal" onclick="cerrarModalEditar()">&times;</span>
        <h2 style="margin-bottom: 1.5rem; color: #2d3748; font-size: 1.3rem;">✏️ Editar Producto</h2>

        <input type="hidden" id="edit_producto_id">

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">📝 Nombre del Producto *</label>
                <input type="text" id="edit_nombre" class="modal-input" required style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">📌 Categoría</label>
                <select id="edit_categoria_id" class="modal-input" style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
                    <option value="">-- Sin categoría --</option>
                    <?php
                    $cat_result = $conn->query("SELECT id, nombre, icono FROM categorias WHERE activo = 1 ORDER BY nombre");
                    while ($cat = $cat_result->fetch_assoc()):
                    ?>
                        <option value="<?php echo intval($cat['id']); ?>"><?php echo htmlspecialchars($cat['icono'] ?? '📦'); ?> <?php echo htmlspecialchars($cat['nombre']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>

        <div style="margin-bottom: 1rem;">
            <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">📄 Descripción *</label>
            <textarea id="edit_descripcion" rows="3" class="modal-input" required style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; resize: vertical;"></textarea>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">🔢 Cantidad *</label>
                <input type="number" id="edit_cantidad" min="0" class="modal-input" required style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">🏷️ Marca</label>
                <input type="text" id="edit_marca" class="modal-input" style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
            </div>
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">⚖️ Peso (kg)</label>
                <input type="number" id="edit_peso" step="0.001" min="0" class="modal-input" style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
            </div>
        </div>

        <div style="margin-bottom: 1rem;">
            <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">🏪 Proveedor</label>
            <select id="edit_proveedor_id" class="modal-input" onchange="recargarMonedasProveedor(this.value)" style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;" <?php echo $es_super_admin_modal ? '' : 'disabled'; ?>>
                <option value="">Sin proveedor</option>
                <?php
                $proveedores_result = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda");
                while ($prov = $proveedores_result->fetch_assoc()):
                ?>
                    <option value="<?php echo intval($prov['id']); ?>">🏪 <?php echo htmlspecialchars($prov['nombre_tienda']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- FILA 1: Moneda + Precio Adquisición + % Ganancia -->
<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
    <div>
        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.75rem;">💱 Moneda *</label>
        <select id="edit_moneda_adquisicion" class="modal-input" onchange="recalcularPrecioModal()" style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
     
          <?php
            $proveedor_modal_sel = $proveedor_id_filtro_modal > 0 ? $proveedor_id_filtro_modal : (isset($_GET['proveedor_id']) ? intval($_GET['proveedor_id']) : 0);
            $monedas_modal = getMonedasParaAdquisicion($conn, $proveedor_modal_sel);
            foreach ($monedas_modal as $m): ?>
                <option value="<?php echo htmlspecialchars($m); ?>"><?php echo htmlspecialchars($m); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.75rem;">💰 Precio Adquisición *</label>
        <input type="number" id="edit_costo" step="0.01" min="0" class="modal-input" onchange="recalcularPrecioModal()" required style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
    </div>
    <div>
        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.75rem;">📈 % Ganancia *</label>
        <input type="number" id="edit_porcentaje_ganancia" step="0.01" min="0" max="999" class="modal-input" onchange="recalcularPrecioModal()" required style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;">
    </div>
</div>

<!-- FILA 2: % Rebaja + Costo USD + Precio Venta -->
<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
    <div>
        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.75rem;">🏷️ % Rebaja</label>
        <input type="number" id="edit_porcentaje_rebaja" step="1" min="0" max="100" class="modal-input" onchange="recalcularPrecioModal()" style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;" placeholder="0">
    </div>
    <div>
        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.75rem;">💵 Costo USD (calculado)</label>
        <input type="number" id="edit_precio_costo_mostrar" step="0.01" class="modal-input" readonly style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; background: #f7fafc; cursor: not-allowed;">
    </div>
    <div>
        <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.75rem;">💵 Precio Venta (USD) *</label>
        <input type="number" id="edit_precio" step="0.01" class="modal-input" readonly style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; background: #f7fafc; cursor: not-allowed;">
    </div>
</div>

        <div style="background: #f0f4f8; padding: 0.6rem 0.8rem; border-radius: 8px; margin-bottom: 1rem; font-size: 0.8rem;">
            <strong>📊 Información:</strong><br>
            Tasa: <span id="edit_info_tasa">1.00 USD</span> |
            Costo en USD: <span id="edit_info_costo_usd">$0.00</span> |
            Precio venta sin rebaja: <span id="edit_info_precio_sin_rebaja">$0.00</span> |
            Precio final con rebaja: <span id="edit_info_precio_final">$0.00</span>
        </div>

        <div style="margin-bottom: 1rem;">
            <label style="display: block; font-weight: 600; margin-bottom: 0.3rem; font-size: 0.85rem;">🖼️ URL de Imagen</label>
            <input type="text" id="edit_imagen_url" class="modal-input" style="width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem;" placeholder="https://ejemplo.com/imagen.jpg">
            <div id="edit_preview_imagen" style="margin-top: 0.5rem;"></div>
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 1rem; margin-top: 1.5rem; border-top: 1px solid #e2e8f0; padding-top: 1.5rem;">
            <button onclick="cerrarModalEditar()" style="padding: 0.7rem 2rem; background: #edf2f7; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; color: #4a5568;">Cancelar</button>
            <button id="btnGuardarEdicion" style="padding: 0.7rem 2rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">💾 Guardar Cambios</button>
        </div>
    </div>
</div>

<style>
.modal-input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
}
.btn-editar-producto {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1rem;
}

/* Responsive del modal */
@media (max-width: 640px) {
    #modalEditarProducto .modal-contenido {
        width: 95% !important;
        padding: 1rem !important;
        max-height: 90vh;
        overflow-y: auto;
    }
    #modalEditarProducto h2 {
        font-size: 1.2rem !important;
        margin-bottom: 1rem !important;
    }
    /* Todas las filas del modal a 1 columna en móvil */
    #modalEditarProducto .modal-contenido > div[style*="display: grid"],
    #modalEditarProducto .modal-contenido > div[style*="display:grid"] {
        grid-template-columns: 1fr !important;
        gap: 0.8rem !important;
    }
    /* Inputs sin zoom en iOS */
    #modalEditarProducto input,
    #modalEditarProducto select,
    #modalEditarProducto textarea {
        font-size: 16px !important;
        min-height: 44px;
    }
    /* Botones a ancho completo */
    #modalEditarProducto .modal-contenido > div:last-child {
        flex-direction: column;
        gap: 0.5rem;
    }
    #modalEditarProducto .modal-contenido > div:last-child button {
        width: 100%;
        min-height: 44px;
    }
    /* Cerrar modal más grande para touch */
    #modalEditarProducto .close-modal {
        top: 0.5rem !important;
        right: 1rem !important;
        font-size: 1.8rem !important;
    }
}
</style>

<script>
// ============================================
// TASAS DEL PROVEEDOR (desde moneda_funciones.php)
// ============================================
window.TASAS_MONEDAS_MODAL = <?php
    $proveedor_modal_tasas = $proveedor_id_filtro_modal > 0 ? $proveedor_id_filtro_modal : (isset($_GET['proveedor_id']) ? intval($_GET['proveedor_id']) : 0);
    $tasas_modal = ['USD' => 1.00];
    $monedas_modal_tasas = getMonedasParaAdquisicion($conn, $proveedor_modal_tasas);
    foreach ($monedas_modal_tasas as $mon) {
        if ($mon === 'USD') continue;
        $tasa = getTasaProveedor($conn, $proveedor_modal_tasas, $mon);
        $tasas_modal[$mon] = ($tasa > 0) ? $tasa : 0;
    }
    echo json_encode($tasas_modal, JSON_UNESCAPED_UNICODE);
?>;

// ============================================
// RECARGAR MONEDAS AL CAMBIAR PROVEEDOR
// ============================================
async function recargarMonedasProveedor(proveedorId) {
    const selectMoneda = document.getElementById('edit_moneda_adquisicion');
    if (!selectMoneda) return;

    try {
        const resp = await fetch(`/admin/stock/admin_ajax_productos.php?monedas_proveedor=${proveedorId || 0}`, {
            credentials: 'same-origin'
        });
        const data = await resp.json();

        if (!data.success) {
            console.error('Error al cargar monedas:', data.error);
            return;
        }

        const valorActual = selectMoneda.value;
        selectMoneda.innerHTML = '';
        data.monedas.forEach(mon => {
            const opt = document.createElement('option');
            opt.value = mon;
            opt.textContent = mon;
            selectMoneda.appendChild(opt);
        });

        if (data.monedas.includes(valorActual)) {
            selectMoneda.value = valorActual;
        } else {
            selectMoneda.value = 'USD';
        }

        window.TASAS_MONEDAS_MODAL = data.tasas;

        if (typeof recalcularPrecioModal === 'function') {
            recalcularPrecioModal();
        }
    } catch (error) {
        console.error('Error en recargarMonedasProveedor:', error);
    }
}

// ============================================
// RECALCULAR PRECIO
// ============================================
function recalcularPrecioModal() {
    const moneda = document.getElementById('edit_moneda_adquisicion').value;
    const costo = parseFloat(document.getElementById('edit_costo').value) || 0;
    const porcentajeGanancia = parseFloat(document.getElementById('edit_porcentaje_ganancia').value) || 0;
    const porcentajeRebaja = parseFloat(document.getElementById('edit_porcentaje_rebaja').value) || 0;

    const tasa = (moneda === 'USD') ? 1 : (window.TASAS_MONEDAS_MODAL[moneda] || 0);

    // Si no hay tasa para la moneda elegida, mostrar advertencia y no calcular
    if (moneda !== 'USD' && tasa <= 0) {
        document.getElementById('edit_precio_costo_mostrar').value = '';
        document.getElementById('edit_precio').value = '';
        document.getElementById('edit_info_tasa').textContent = '⚠️ Sin tasa';
        document.getElementById('edit_info_costo_usd').textContent = '—';
        document.getElementById('edit_info_precio_sin_rebaja').textContent = '—';
        document.getElementById('edit_info_precio_final').textContent = '—';
        const btn = document.getElementById('btnGuardarEdicion');
        if (btn) { btn.disabled = true; btn.style.opacity = '0.5'; }
        return;
    }

    // Rehabilitar botón si estaba deshabilitado
    const btnSubmit = document.getElementById('btnGuardarEdicion');
    if (btnSubmit) { btnSubmit.disabled = false; btnSubmit.style.opacity = '1'; }

    const precioCostoUSD = (moneda === 'USD') ? costo : (costo / tasa);
    const precioVentaUSD = precioCostoUSD * (1 + porcentajeGanancia / 100);

    let precioFinalUSD = precioVentaUSD;
    if (porcentajeRebaja > 0) {
        precioFinalUSD = precioVentaUSD * (100 - porcentajeRebaja) / 100;
    }

    document.getElementById('edit_precio_costo_mostrar').value = precioCostoUSD.toFixed(2);
    document.getElementById('edit_precio').value = precioVentaUSD.toFixed(2);
    document.getElementById('edit_info_tasa').textContent = tasa.toFixed(2) + ' ' + moneda;
    document.getElementById('edit_info_costo_usd').textContent = '$' + precioCostoUSD.toFixed(2);
    document.getElementById('edit_info_precio_sin_rebaja').textContent = '$' + precioVentaUSD.toFixed(2);
    document.getElementById('edit_info_precio_final').textContent = '$' + precioFinalUSD.toFixed(2);
}

// ============================================
// ABRIR MODAL
// ============================================
function abrirModalEditar(producto) {
    console.log('Abriendo modal con producto:', producto);

    document.getElementById('edit_producto_id').value = producto.id;
    document.getElementById('edit_nombre').value = producto.nombre || '';
    document.getElementById('edit_marca').value = producto.marca || '';
    document.getElementById('edit_descripcion').value = producto.descripcion || '';
    document.getElementById('edit_cantidad').value = producto.cantidad || 0;
    document.getElementById('edit_peso').value = producto.peso || 0;
    document.getElementById('edit_categoria_id').value = producto.categoria_id || '';
    document.getElementById('edit_proveedor_id').value = producto.proveedor_id || '';
    document.getElementById('edit_imagen_url').value = producto.imagen_url || '';
    document.getElementById('edit_porcentaje_rebaja').value = producto.porcentaje_rebaja || 0;
    document.getElementById('edit_porcentaje_ganancia').value = producto.porcentaje_ganancia || 0;

    const monedaProducto = producto.moneda_adquisicion || 'USD';
    document.getElementById('edit_moneda_adquisicion').value = monedaProducto;

    // Opción B: precio_adquisicion SIEMPRE tiene el valor en moneda local
    const costoMostrar = parseFloat(producto.precio_adquisicion) || 0;
    document.getElementById('edit_costo').value = costoMostrar.toFixed(2);

    document.getElementById('edit_precio').value = producto.precio || 0;
    document.getElementById('edit_precio_costo_mostrar').value = producto.precio_costo || 0;

    // Si es Super Admin, recargar monedas del proveedor del producto
    <?php if ($es_super_admin_modal): ?>
    if (producto.proveedor_id) {
        recargarMonedasProveedor(producto.proveedor_id).then(() => {
            const monedaProducto = producto.moneda_adquisicion || 'USD';
            const selectMoneda = document.getElementById('edit_moneda_adquisicion');
            if (selectMoneda) {
                selectMoneda.value = monedaProducto;
            }
            const costoMostrar = parseFloat(producto.precio_adquisicion) || 0;
            document.getElementById('edit_costo').value = costoMostrar.toFixed(2);
            recalcularPrecioModal();
        });
    } else {
        recalcularPrecioModal();
    }
    <?php else: ?>
    recalcularPrecioModal();
    <?php endif; ?>

    // Previsualizar imagen
    const previewDiv = document.getElementById('edit_preview_imagen');
    if (previewDiv) {
        if (producto.imagen_url) {
            previewDiv.innerHTML = `<img src="${producto.imagen_url}" style="max-width: 100px; max-height: 100px; border-radius: 8px;" onerror="this.style.display='none'">`;
        } else {
            previewDiv.innerHTML = '';
        }
    }

    const modal = document.getElementById('modalEditarProducto');
    if (modal) {
        modal.style.display = 'block';
    } else {
        console.error('Modal no encontrado');
    }
}

function cerrarModalEditar() {
    const modal = document.getElementById('modalEditarProducto');
    if (modal) {
        modal.style.display = 'none';
    }
}

// ============================================
// GUARDAR EDICIÓN
// ============================================
window.guardarEdicionProducto = function() {
    console.log('Guardando edición...');

    const id = document.getElementById('edit_producto_id').value;
    if (!id) {
        mostrarNotificacion('❌ Error: No se encontró el ID del producto', 'error');
        return;
    }

    const csrfToken = document.querySelector('input[name="csrf_token"]')?.value || '';
    if (!csrfToken) {
        mostrarNotificacion('❌ Token de seguridad no encontrado. Recarga la página.', 'error');
        return;
    }

    const monedaSel = document.getElementById('edit_moneda_adquisicion').value;
    const costoSel = parseFloat(document.getElementById('edit_costo').value) || 0;
    const porcentajeGananciaSel = parseFloat(document.getElementById('edit_porcentaje_ganancia').value) || 0;
    const porcentajeRebajaSel = parseFloat(document.getElementById('edit_porcentaje_rebaja').value) || 0;

    const proveedorSel = document.getElementById('edit_proveedor_id')?.value || null;

    const datos = {
        id: parseInt(id),
        nombre: document.getElementById('edit_nombre').value.trim(),
        marca: document.getElementById('edit_marca').value,
        descripcion: document.getElementById('edit_descripcion').value,
        cantidad: parseInt(document.getElementById('edit_cantidad').value) || 0,
        peso: parseFloat(document.getElementById('edit_peso').value) || 0,
        categoria_id: document.getElementById('edit_categoria_id').value || null,
        imagen_url: document.getElementById('edit_imagen_url').value,
        proveedor_id: proveedorSel ? parseInt(proveedorSel) : null,

        moneda_adquisicion: monedaSel,
        costo: costoSel,
        porcentaje_ganancia: porcentajeGananciaSel,
        porcentaje_rebaja: porcentajeRebajaSel,

        csrf_token: csrfToken
    };

    console.log('Datos a enviar:', datos);

    if (!datos.nombre) {
        mostrarNotificacion('❌ El nombre es obligatorio', 'error');
        return;
    }

    const btn = document.getElementById('btnGuardarEdicion');
    if (!btn) return;

    const textoOriginal = btn.innerHTML;
    btn.innerHTML = '⏳ Guardando...';
    btn.disabled = true;

    fetch('/admin/stock/api_editar_producto.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Respuesta del servidor:', data);

        if (data.success) {
            mostrarNotificacion('✅ ' + (data.message || 'Producto actualizado'), 'exito');
            cerrarModalEditar();

            if (data.producto) {
                actualizarFilaProducto(data.producto);
            } else {
                if (typeof cargarTabla === 'function') {
                    cargarTabla({});
                }
            }
        } else {
            mostrarNotificacion('❌ ' + (data.error || 'Error al actualizar'), 'error');
        }
    })
    .catch(error => {
        console.error('Error en fetch:', error);
        mostrarNotificacion('❌ Error de conexión: ' + error.message, 'error');
    })
    .finally(() => {
        btn.innerHTML = textoOriginal;
        btn.disabled = false;
    });
};

// ============================================
// ACTUALIZAR FILA
// ============================================
window.actualizarFilaProducto = function(producto) {
    console.log('Actualizando fila para producto:', producto.id);

    const checkbox = document.querySelector(`.checkbox-producto[value="${producto.id}"]`);
    if (!checkbox) {
        console.log('No se encontró la fila, recargando tabla...');
        if (typeof cargarTabla === 'function') cargarTabla({});
        return;
    }

    const fila = checkbox.closest('tr');
    if (!fila) return;

    const precio_costo = parseFloat(producto.precio_costo) || 0;
    const precio = parseFloat(producto.precio) || 0;
    const cantidad = parseInt(producto.cantidad) || 0;
    const peso = parseFloat(producto.peso) || 0;
    const porcentaje_rebaja = parseInt(producto.porcentaje_rebaja) || 0;

    const importe_costo = precio_costo * cantidad;
    const importe_venta = precio * cantidad;
    const tiene_rebaja = porcentaje_rebaja > 0;

    const celdas = fila.querySelectorAll('td');
    console.log('Celdas encontradas:', celdas.length);

    if (celdas.length >= 12) {
        if (celdas[0]) celdas[0].innerHTML = `#${producto.id}`;

        if (celdas[2]) {
            if (producto.imagen_url) {
                celdas[2].innerHTML = `<img src="${producto.imagen_url}" alt="${producto.nombre}" class="img-thumbnail">`;
            } else {
                celdas[2].innerHTML = `<div class="sin-imagen">❌</div>`;
            }
        }

        if (celdas[3]) {
            const icono = producto.categoria_icono || '📦';
            const catNombre = producto.categoria_nombre || 'Sin categoría';
            celdas[3].innerHTML = `<strong>${producto.nombre || ''}</strong><br>
                                   <span style="font-size: 0.7rem; color: #718096;">${icono} ${catNombre}</span>`;
        }

        if (celdas[4]) {
            if (producto.nombre_tienda) {
                celdas[4].innerHTML = `${producto.nombre_tienda}`;
            } else {
                celdas[4].innerHTML = `<span style="color: #9ca3af;">—</span>`;
            }
        }

        if (celdas[5]) {
            let stockClass = '';
            if (cantidad == 0) stockClass = 'sin-stock';
            else if (cantidad < 5) stockClass = 'bajo-stock';
            celdas[5].innerHTML = `<span class="badge-cantidad ${stockClass}">${cantidad}</span>`;
        }

        if (celdas[6]) celdas[6].innerHTML = peso.toFixed(3);

        if (celdas[7]) {
            celdas[7].innerHTML = `<strong>P-: $${precio_costo.toFixed(2)}</strong><br>
                                   <span style="font-size: 0.7rem; color: #718096;">Imp: $${importe_costo.toFixed(2)}</span>`;
        }

        if (celdas[8]) {
            if (tiene_rebaja) {
                const precioOriginalMostrar = producto.precio_original ? parseFloat(producto.precio_original) : precio;
                celdas[8].innerHTML = `<span style="text-decoration:line-through;color:#9ca3af;font-size:0.7rem;">P: $${precioOriginalMostrar.toFixed(2)}</span><br>
                                          <span style="color:#10b981;font-weight:bold;">P: $${precio.toFixed(2)}</span><br>
                                          <span style="font-size: 0.7rem; color: #718096;">I: $${importe_venta.toFixed(2)}</span>`;
            } else {
                celdas[8].innerHTML = `<strong>P: $${precio.toFixed(2)}</strong><br>
                                       <span style="font-size: 0.7rem; color: #718096;">Imp: $${importe_venta.toFixed(2)}</span>`;
            }
        }

        if (celdas[9]) {
            if (tiene_rebaja) {
                celdas[9].innerHTML = `<span class="badge-rebaja">-${porcentaje_rebaja}%</span>`;
            } else {
                celdas[9].innerHTML = `<span style="color:#9ca3af;">—</span>`;
            }
        }

        if (celdas[10]) {
            const fecha = new Date(producto.fecha_creacion);
            const estadoText = producto.activo == 1 ? '✅ Activo' : '❌ Inactivo';
            const estadoClass = producto.activo == 1 ? 'badge-activo' : 'badge-inactivo';
            celdas[10].innerHTML = `${fecha.toLocaleDateString('es-ES')}<br>
                                   <span class="badge-estado ${estadoClass}">${estadoText}</span>`;
        }

        if (celdas[11]) {
            const btnEditar = celdas[11].querySelector('.btn-editar-producto');
            if (btnEditar) {
                btnEditar.setAttribute('data-id', producto.id);
                btnEditar.setAttribute('data-nombre', producto.nombre || '');
                btnEditar.setAttribute('data-marca', producto.marca || '');
                btnEditar.setAttribute('data-descripcion', producto.descripcion || '');
                btnEditar.setAttribute('data-precio_costo', precio_costo);
                btnEditar.setAttribute('data-precio', precio);
                btnEditar.setAttribute('data-porcentaje_rebaja', porcentaje_rebaja);
                btnEditar.setAttribute('data-cantidad', cantidad);
                btnEditar.setAttribute('data-peso', peso);
                btnEditar.setAttribute('data-categoria_id', producto.categoria_id || '');
                btnEditar.setAttribute('data-proveedor_id', producto.proveedor_id || '');
                btnEditar.setAttribute('data-imagen_url', producto.imagen_url || '');
                btnEditar.setAttribute('data-precio_adquisicion', producto.precio_adquisicion || 0);
                btnEditar.setAttribute('data-moneda_adquisicion', producto.moneda_adquisicion || 'USD');
                btnEditar.setAttribute('data-porcentaje_ganancia', producto.porcentaje_ganancia || 0);
            }
        }

        fila.style.opacity = producto.activo == 1 ? '' : '0.7';
        fila.style.background = producto.activo == 1 ? '' : '#fff5f5';

        console.log('✅ Fila actualizada correctamente');
    } else {
        console.log('❌ Número de celdas incorrecto. Se esperaban 12, se encontraron:', celdas.length);
        if (typeof cargarTabla === 'function') cargarTabla({});
    }
};

// ============================================
// CLICK EN EDITAR
// ============================================
window.handleEditarClick = function(event) {
    const btn = event.currentTarget;
    console.log('Click editar en botón:', btn);

    const producto = {
        id: btn.getAttribute('data-id'),
        nombre: btn.getAttribute('data-nombre'),
        marca: btn.getAttribute('data-marca'),
        descripcion: btn.getAttribute('data-descripcion'),
        precio_costo: btn.getAttribute('data-precio_costo'),
        precio: btn.getAttribute('data-precio'),
        porcentaje_rebaja: btn.getAttribute('data-porcentaje_rebaja') || 0,
        cantidad: btn.getAttribute('data-cantidad'),
        peso: btn.getAttribute('data-peso'),
        categoria_id: btn.getAttribute('data-categoria_id'),
        proveedor_id: btn.getAttribute('data-proveedor_id') || '',
        imagen_url: btn.getAttribute('data-imagen_url'),
        precio_adquisicion: btn.getAttribute('data-precio_adquisicion') || 0,
        moneda_adquisicion: btn.getAttribute('data-moneda_adquisicion') || 'USD',
        porcentaje_ganancia: btn.getAttribute('data-porcentaje_ganancia') || 0
    };

    abrirModalEditar(producto);
};

// ============================================
// REINICIALIZAR EVENTOS
// ============================================
window.reinicializarEventosEdicion = function() {
    console.log('Reinicializando eventos de edición...');
    const botonesEditar = document.querySelectorAll('.btn-editar-producto');
    console.log('Botones encontrados:', botonesEditar.length);

    botonesEditar.forEach(btn => {
        btn.removeEventListener('click', window.handleEditarClick);
        btn.addEventListener('click', window.handleEditarClick);
    });
};

if (typeof window.reinicializarEventosTablaOriginal === 'undefined') {
    if (typeof reinicializarEventosTabla === 'function') {
        window.reinicializarEventosTablaOriginal = reinicializarEventosTabla;
    }
}

window.reinicializarEventosTabla = function() {
    if (typeof window.reinicializarEventosTablaOriginal === 'function') {
        window.reinicializarEventosTablaOriginal();
    }
    window.reinicializarEventosEdicion();
};

// ============================================
// INICIALIZAR
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM cargado, inicializando modal...');

    const btnGuardar = document.getElementById('btnGuardarEdicion');
    if (btnGuardar) {
        const newBtn = btnGuardar.cloneNode(true);
        btnGuardar.parentNode.replaceChild(newBtn, btnGuardar);
        newBtn.addEventListener('click', window.guardarEdicionProducto);
        console.log('Evento guardar asignado');
    } else {
        console.warn('Botón guardar no encontrado');
    }

    const modal = document.getElementById('modalEditarProducto');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                cerrarModalEditar();
            }
        });
    }

    window.reinicializarEventosEdicion();
});

// Previsualizar imagen
const imagenUrlInput = document.getElementById('edit_imagen_url');
if (imagenUrlInput) {
    imagenUrlInput.addEventListener('input', function() {
        const url = this.value;
        const previewDiv = document.getElementById('edit_preview_imagen');
        if (previewDiv) {
            if (url) {
                previewDiv.innerHTML = `<img src="${url}" style="max-width: 100px; max-height: 100px; border-radius: 8px;" onerror="this.style.display='none'">`;
            } else {
                previewDiv.innerHTML = '';
            }
        }
    });
}
</script>
<?php
// ============================================
// COMBO GET PRODUCTOS - OBTENER PRODUCTOS DISPONIBLES
// ============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

header('Content-Type: application/json');

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'];
if (!in_array($_SESSION['rol'], $roles_permitidos)) {
    echo json_encode([]);
    exit;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

// Validar que el proveedor existe y está activo
if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo json_encode([]);
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        echo json_encode([]);
        exit;
    }
    $stmt_check->close();
}

// ============================================
// CSRF PROTECTION (opcional para este endpoint)
// ============================================
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$combo_id = isset($_GET['combo_id']) ? intval($_GET['combo_id']) : 0;
$productos = [];

// ============================================
// CONSULTAR PRODUCTOS (FILTRADOS POR PROVEEDOR)
// ============================================
$where_proveedor = $proveedor_id_usuario > 0 ? " AND p.proveedor_id = $proveedor_id_usuario" : "";

$sql = "SELECT p.id, p.nombre, p.precio_costo, p.precio, p.cantidad, p.reservado_por_combos,
               (p.cantidad - p.reservado_por_combos) as stock_disponible,
               c.nombre as categoria_nombre, c.icono as categoria_icono
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        WHERE p.activo = 1 
          AND (p.cantidad - p.reservado_por_combos) > 0
          $where_proveedor
        ORDER BY p.nombre";

$result = $conn->query($sql);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Sanitizar datos antes de enviar
        $row['nombre'] = htmlspecialchars($row['nombre']);
        $row['categoria_nombre'] = htmlspecialchars($row['categoria_nombre'] ?? '');
        $row['categoria_icono'] = htmlspecialchars($row['categoria_icono'] ?? '');
        $productos[] = $row;
    }
}

echo json_encode($productos);
$conn->close();
?>
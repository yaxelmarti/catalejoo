<?php
// ============================================
// COMBOS ACCIONES - GESTIÓN DE COMBOS
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/csrf.php';

// ============================================
// VERIFICAR PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_gestionar) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// ROLES QUE PUEDEN ELIMINAR
// ============================================
$roles_eliminar = ['Super Admin', 'Proveedor'];
$puede_eliminar = in_array($_SESSION['rol'], $roles_eliminar);

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// ACCIÓN (GET o POST)
// ============================================
$accion = $_GET['accion'] ?? ($_POST['accion'] ?? '');

// ============================================
// FUNCIONES DE VERIFICACIÓN DE PROPIEDAD
// ============================================
function verificarPropiedadCombo($conn, $combo_id, $proveedor_id_usuario) {
    if ($proveedor_id_usuario == 0) {
        return true;
    }
    
    $stmt = $conn->prepare("SELECT proveedor_id FROM combos WHERE id = ?");
    $stmt->bind_param("i", $combo_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $pertenece = false;
    if ($row = $result->fetch_assoc()) {
        $pertenece = ($row['proveedor_id'] == $proveedor_id_usuario);
    }
    $stmt->close();
    return $pertenece;
}

function verificarPropiedadCombos($conn, $combo_ids, $proveedor_id_usuario) {
    if ($proveedor_id_usuario == 0) {
        return true;
    }
    
    $placeholders = implode(',', array_fill(0, count($combo_ids), '?'));
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM combos WHERE id IN ($placeholders) AND proveedor_id != ?");
    $types = str_repeat('i', count($combo_ids)) . 'i';
    $params = array_merge($combo_ids, [$proveedor_id_usuario]);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    return $row['total'] == 0;
}

// ============================================
// FUNCIÓN: LIBERAR RESERVA DE UN COMBO
// ============================================
function liberarReservaCombo($conn, $combo_id, $fecha_actual) {
    // Leer productos del combo
    $stmt = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
    $stmt->bind_param("i", $combo_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $productos = [];
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }
    $stmt->close();
    
    // Liberar reserva de cada producto
    $stmt_update = $conn->prepare("UPDATE productos p
        SET p.reservado_por_combos = GREATEST(0, p.reservado_por_combos - ?),
            p.fecha_actualizacion_reserva = ?,
            p.en_combo = CASE WHEN EXISTS (
                SELECT 1 FROM combo_productos cp
                INNER JOIN combos c ON c.id = cp.combo_id
                WHERE cp.producto_id = p.id AND cp.cantidad > 0 AND c.activo = 1
            ) THEN 1 ELSE 0 END
        WHERE p.id = ?");
    
    foreach ($productos as $prod) {
        $stmt_update->bind_param("isii", $prod['cantidad'], $fecha_actual, $prod['cantidad'], $prod['producto_id']);
        $stmt_update->execute();
    }
    $stmt_update->close();
}

// ============================================
// FUNCIÓN: RESERVAR STOCK DE UN COMBO
// ============================================
function reservarStockCombo($conn, $combo_id, $fecha_actual) {
    // Leer productos del combo
    $stmt = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
    $stmt->bind_param("i", $combo_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $productos = [];
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }
    $stmt->close();
    
    // Reservar stock de cada producto
    $stmt_update = $conn->prepare("UPDATE productos 
        SET reservado_por_combos = reservado_por_combos + ?,
            fecha_actualizacion_reserva = ?,
            en_combo = 1
        WHERE id = ?");
    
    foreach ($productos as $prod) {
        $stmt_update->bind_param("isi", $prod['cantidad'], $fecha_actual, $prod['producto_id']);
        $stmt_update->execute();
    }
    $stmt_update->close();
}

// ============================================
// CAMBIAR ESTADO (ACTIVAR/DESACTIVAR)
// ============================================
if ($accion == 'toggle_estado' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $estado_actual = intval($_GET['estado']);
    $nuevo_estado = $estado_actual == 1 ? 0 : 1;
    
    // Validar CSRF (POST o GET)
    $token_csrf = $_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? '');
    if (!csrf_validar($token_csrf)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Token de seguridad inválido']);
        exit;
    }
    
    // Verificar propiedad
    if (!verificarPropiedadCombo($conn, $id, $proveedor_id_usuario)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'No tienes permiso para modificar este combo']);
        exit;
    }
    
    $fecha_actual = date('Y-m-d H:i:s');
    
    $conn->begin_transaction();
    try {
        // Actualizar estado del combo
        $stmt = $conn->prepare("UPDATE combos SET activo = ? WHERE id = ?");
        $stmt->bind_param("ii", $nuevo_estado, $id);
        $stmt->execute();
        $stmt->close();
        
        if ($nuevo_estado == 0) {
            // Desactivar: liberar reserva
            liberarReservaCombo($conn, $id, $fecha_actual);
            $mensaje_exito = "✅ Combo desactivado correctamente";
        } else {
            // Activar: reservar stock
            reservarStockCombo($conn, $id, $fecha_actual);
            $mensaje_exito = "✅ Combo activado correctamente";
        }
        
       $conn->commit();
        
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'nuevo_estado' => $nuevo_estado]);
        exit;
        
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[combos_acciones toggle_estado] ' . $e->getMessage());
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Error al cambiar estado']);
        exit;
    }
}

// ============================================
// ACCIONES MASIVAS
// ============================================
if ($accion == 'masiva' && isset($_POST['combos']) && isset($_POST['accion_masiva'])) {
    
    // Validar CSRF (POST o GET)
    $token_csrf = $_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? '');
    if (!csrf_validar($token_csrf)) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
    
    $combos_ids = json_decode($_POST['combos'], true);
    $accion_masiva = $_POST['accion_masiva'];
    
    if (!empty($combos_ids) && is_array($combos_ids)) {
        $ids = array_map('intval', $combos_ids);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));
        
        // Verificar propiedad
        if (!verificarPropiedadCombos($conn, $ids, $proveedor_id_usuario)) {
            $_SESSION['mensaje'] = '❌ No tienes permiso para modificar algunos combos';
            $_SESSION['tipo_mensaje'] = 'error';
            header('Location: combos.php');
            exit;
        }
        
        $fecha_actual = date('Y-m-d H:i:s');
        
        $conn->begin_transaction();
        try {
            if ($accion_masiva == 'activar') {
                $stmt = $conn->prepare("UPDATE combos SET activo = 1 WHERE id IN ($placeholders)");
                $stmt->bind_param($types, ...$ids);
                $stmt->execute();
                $stmt->close();
                
                foreach ($ids as $combo_id) {
                    reservarStockCombo($conn, $combo_id, $fecha_actual);
                }
                $_SESSION['mensaje'] = "✅ " . count($ids) . " combos activados";
                
            } elseif ($accion_masiva == 'desactivar') {
                $stmt = $conn->prepare("UPDATE combos SET activo = 0 WHERE id IN ($placeholders)");
                $stmt->bind_param($types, ...$ids);
                $stmt->execute();
                $stmt->close();
                
                foreach ($ids as $combo_id) {
                    liberarReservaCombo($conn, $combo_id, $fecha_actual);
                }
                $_SESSION['mensaje'] = "✅ " . count($ids) . " combos desactivados";
                
            } elseif ($accion_masiva == 'eliminar' && $puede_eliminar) {
                // Liberar reserva
                foreach ($ids as $combo_id) {
                    liberarReservaCombo($conn, $combo_id, $fecha_actual);
                }
                
                // Eliminar productos del combo
                $stmt_delete = $conn->prepare("DELETE FROM combo_productos WHERE combo_id IN ($placeholders)");
                $stmt_delete->bind_param($types, ...$ids);
                $stmt_delete->execute();
                $stmt_delete->close();
                
                // Eliminar los combos
                $stmt_delete = $conn->prepare("DELETE FROM combos WHERE id IN ($placeholders)");
                $stmt_delete->bind_param($types, ...$ids);
                $stmt_delete->execute();
                $stmt_delete->close();
                
                $_SESSION['mensaje'] = "✅ " . count($ids) . " combos eliminados";
            }
            
            $conn->commit();
            $_SESSION['tipo_mensaje'] = "exito";
            
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[combos_acciones masiva] ' . $e->getMessage());
            $_SESSION['mensaje'] = "❌ Error al procesar la acción masiva";
            $_SESSION['tipo_mensaje'] = "error";
        }
    } else {
        $_SESSION['mensaje'] = "❌ No se seleccionaron combos";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    // Redirigir con filtros
    $query_params = $_GET;
    unset($query_params['accion']);
    unset($query_params['combos']);
    $query_string = http_build_query($query_params);
    header('Location: combos.php' . ($query_string ? '?' . $query_string : ''));
    exit;
}

// ============================================
// ELIMINAR COMBO INDIVIDUAL
// ============================================
if ($accion == 'eliminar' && isset($_GET['id'])) {
    
    // Validar CSRF (POST o GET)
    $token_csrf = $_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? '');
    if (!csrf_validar($token_csrf)) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
    
    // Validar permiso de eliminación
    if (!$puede_eliminar) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para eliminar combos';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
    
    $id = intval($_GET['id']);
    
    // Verificar propiedad
    if (!verificarPropiedadCombo($conn, $id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para eliminar este combo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos.php');
        exit;
    }
    
    $fecha_actual = date('Y-m-d H:i:s');
    
    $conn->begin_transaction();
    try {
        // Liberar reserva de productos
        liberarReservaCombo($conn, $id, $fecha_actual);
        
        // Eliminar productos del combo
        $stmt = $conn->prepare("DELETE FROM combo_productos WHERE combo_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        
        // Eliminar combo
        $stmt = $conn->prepare("DELETE FROM combos WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        
        $conn->commit();
        $_SESSION['mensaje'] = "✅ Combo eliminado correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
        
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[combos_acciones eliminar] ' . $e->getMessage());
        $_SESSION['mensaje'] = "❌ Error al eliminar el combo";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    $query_params = $_GET;
    unset($query_params['accion']);
    unset($query_params['id']);
    unset($query_params['csrf_token']);
    $query_string = http_build_query($query_params);
    header('Location: combos.php' . ($query_string ? '?' . $query_string : ''));
    exit;
}

// ============================================
// SIN ACCIÓN VÁLIDA
// ============================================
header('Location: combos.php');
exit;
?>
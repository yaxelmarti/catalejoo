<?php
// ============================================
// ADMIN MÓVIL - VISTA SIMPLIFICADA DE PRODUCTOS
// Versión 27 Oct 2026
// Ubicación: /admin/stock/admin_movil.php
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/csrf.php';
require_once __DIR__ . '/../../header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

$rol_actual = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

// ============================================
// VERIFICAR ROLES
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    error_log("[admin_movil] Permiso denegado. Rol: $rol_actual, usuario: $usuario_id_actual");
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// PERMISOS DE GESTIÓN
// ============================================
$roles_gestion = ['Super Admin', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($rol_actual, $roles_gestion, true);

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_filtro = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_filtro == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

// ============================================
// COLORES DE CONFIGURACIÓN
// ============================================
$color_primario = '#667eea';
$color_secundario = '#764ba2';

$stmt_color = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario' LIMIT 1");
if ($stmt_color) {
    $stmt_color->execute();
    $row_color = $stmt_color->get_result()->fetch_assoc();
    if ($row_color && !empty($row_color['valor'])) {
        $color_primario = $row_color['valor'];
    }
    $stmt_color->close();
}

$stmt_color2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario' LIMIT 1");
if ($stmt_color2) {
    $stmt_color2->execute();
    $row_color2 = $stmt_color2->get_result()->fetch_assoc();
    if ($row_color2 && !empty($row_color2['valor'])) {
        $color_secundario = $row_color2['valor'];
    }
    $stmt_color2->close();
}

// ============================================
// PROCESAR FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

// Filtro por proveedor (obligatorio para roles de tienda)
if ($proveedor_id_filtro > 0) {
    $where[] = "p.proveedor_id = ?";
    $params[] = $proveedor_id_filtro;
    $types .= "i";
}

if (!empty($_GET['nombre'])) {
    $where[] = "p.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['filtro_estado'])) {
    if ($_GET['filtro_estado'] === 'activos') {
        $where[] = "p.activo = 1";
    } elseif ($_GET['filtro_estado'] === 'inactivos') {
        $where[] = "p.activo = 0";
    }
}

if (!empty($_GET['filtro_imagen'])) {
    if ($_GET['filtro_imagen'] === 'sin_imagen') {
        $where[] = "(p.imagen_url IS NULL OR p.imagen_url = '')";
    } elseif ($_GET['filtro_imagen'] === 'con_imagen') {
        $where[] = "(p.imagen_url IS NOT NULL AND p.imagen_url != '')";
    }
}

if (!empty($_GET['filtro_rebaja'])) {
    if ($_GET['filtro_rebaja'] === 'con_rebaja') {
        $where[] = "p.porcentaje_rebaja > 0";
    } elseif ($_GET['filtro_rebaja'] === 'sin_rebaja') {
        $where[] = "(p.porcentaje_rebaja IS NULL OR p.porcentaje_rebaja = 0)";
    }
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// CONSULTA PRINCIPAL
// ============================================
$sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono 
        FROM productos p 
        LEFT JOIN categorias c ON p.categoria_id = c.id 
        $sql_where 
        ORDER BY p.fecha_creacion DESC";

$productos = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $productos = $stmt->get_result();
    $stmt->close();
} else {
    error_log("[admin_movil] prepare productos: " . $conn->error);
}

// Total de productos (con el mismo filtro de proveedor)
$total_productos = 0;
if ($proveedor_id_filtro > 0) {
    $stmt_total = $conn->prepare("SELECT COUNT(*) as total FROM productos p WHERE p.proveedor_id = ?");
    if ($stmt_total) {
        $stmt_total->bind_param("i", $proveedor_id_filtro);
        $stmt_total->execute();
        $total_productos = intval($stmt_total->get_result()->fetch_assoc()['total'] ?? 0);
        $stmt_total->close();
    }
} else {
    $res_total = $conn->query("SELECT COUNT(*) as total FROM productos");
    if ($res_total) {
        $total_productos = intval($res_total->fetch_assoc()['total'] ?? 0);
    }
}
?>

<style>
:root {
    --primary: <?php echo htmlspecialchars($color_primario); ?>;
    --secondary: <?php echo htmlspecialchars($color_secundario); ?>;
}

* { box-sizing: border-box; }

body {
    padding-top: 100px !important;
    background: #f7fafc;
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
}

.container { padding: 0 12px; max-width: 100%; overflow-x: hidden; }

.filtros-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.filtros-form {
    display: flex;
    flex-direction: column;
    gap: 0.8rem;
}

.filtros-row {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.filtros-row select,
.filtros-row input {
    flex: 1;
    padding: 0.5rem;
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 16px;
    min-height: 44px;
    min-width: 0;
}

.filtros-buttons {
    display: flex;
    gap: 0.5rem;
    justify-content: flex-end;
}

.btn-filtrar {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    min-height: 44px;
}

.btn-limpiar {
    background: #edf2f7;
    color: #4a5568;
    text-align: center;
    text-decoration: none;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 44px;
}

.productos-table-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    margin-bottom: 2rem;
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.table-header h3 {
    font-size: 1rem;
    margin: 0;
}

.btn-nuevo {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
    text-decoration: none;
    padding: 0.4rem 0.8rem;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    min-height: 44px;
}

.tabla-movil {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
}

.tabla-movil tr {
    border-bottom: 1px solid #edf2f7;
}

.tabla-movil td {
    padding: 12px 8px;
    vertical-align: middle;
}

.tabla-movil .producto-imagen {
    width: 50px;
    text-align: center;
}

.tabla-movil .producto-nombre {
    font-weight: 600;
    width: 50%;
    max-width: 180px;
    word-break: break-word;
}

.tabla-movil .producto-cantidad {
    text-align: center;
    width: 60px;
}

.tabla-movil .producto-precio {
    text-align: right;
    width: 70px;
}

.precio-texto {
    font-weight: 600;
    font-size: 0.75rem;
}

.precio-rebaja {
    text-decoration: line-through;
    font-size: 0.65rem;
    color: #9ca3af;
}

.precio-final {
    color: #10b981;
    font-weight: 600;
    font-size: 0.75rem;
}

.tabla-movil .producto-acciones {
    text-align: center;
    width: 120px;
}

.img-thumbnail {
    width: 40px;
    height: 40px;
    object-fit: cover;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
}

.sin-imagen {
    width: 40px;
    height: 40px;
    background: #fed7d7;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #c53030;
    font-size: 1rem;
    margin: 0 auto;
}

.badge-cantidad {
    display: inline-block;
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    background: #e2e8f0;
    font-weight: 600;
    font-size: 0.8rem;
    min-width: 40px;
    text-align: center;
}

.badge-cantidad.sin-stock {
    background: #fed7d7;
    color: #c53030;
}

.badge-cantidad.bajo-stock {
    background: #feebc8;
    color: #c05621;
}

.btn-icono {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    text-decoration: none;
    border-radius: 6px;
    font-size: 0.9rem;
    transition: all 0.2s;
    border: none;
    background: none;
    cursor: pointer;
    padding: 0;
}

.btn-icono:hover {
    background: #edf2f7;
    transform: scale(1.1);
}

.fila-activo {
    background-color: white;
}

.fila-inactivo {
    background-color: #fff5f5;
    opacity: 0.8;
}

.contador-productos {
    background: #e2e8f0;
    border-radius: 20px;
    padding: 0.2rem 0.6rem;
    font-size: 0.7rem;
    color: #4a5568;
    margin-left: 0.5rem;
}

.toast-container {
    position: fixed;
    top: 70px;
    right: 10px;
    left: 10px;
    z-index: 3000;
}

.toast-notificacion {
    background: white;
    border-radius: 8px;
    padding: 12px 16px;
    margin-bottom: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 0.85rem;
    border-left: 4px solid;
}

.toast-notificacion.exito { border-left-color: #48bb78; background: #f0fff4; color: #22543d; }
.toast-notificacion.error { border-left-color: #f56565; background: #fff5f5; color: #742a2a; }

.toast-cerrar {
    background: none;
    border: none;
    font-size: 1.2rem;
    cursor: pointer;
    padding: 0 5px;
}

.sin-datos {
    text-align: center;
    padding: 2rem;
    color: #a0aec0;
}
</style>

<div class="container">
    <!-- FILTROS -->
    <div class="filtros-card">
        <form method="GET" id="filtrosForm">
            <div class="filtros-row">
                <input type="text" name="nombre" value="<?php echo htmlspecialchars($_GET['nombre'] ?? ''); ?>" placeholder="🔍 Buscar producto...">
            </div>
            <div class="filtros-row">
                <select name="filtro_estado" id="filtro_estado">
                    <option value="">📌 Todos</option>
                    <option value="activos" <?php echo ($_GET['filtro_estado'] ?? '') === 'activos' ? 'selected' : ''; ?>>✅ Activos</option>
                    <option value="inactivos" <?php echo ($_GET['filtro_estado'] ?? '') === 'inactivos' ? 'selected' : ''; ?>>❌ Inactivos</option>
                </select>

                <select name="filtro_imagen" id="filtro_imagen">
                    <option value="">🖼️ Todas</option>
                    <option value="con_imagen" <?php echo ($_GET['filtro_imagen'] ?? '') === 'con_imagen' ? 'selected' : ''; ?>>Con imagen</option>
                    <option value="sin_imagen" <?php echo ($_GET['filtro_imagen'] ?? '') === 'sin_imagen' ? 'selected' : ''; ?>>Sin imagen</option>
                </select>

                <select name="filtro_rebaja" id="filtro_rebaja">
                    <option value="">🏷️ Todas</option>
                    <option value="con_rebaja" <?php echo ($_GET['filtro_rebaja'] ?? '') === 'con_rebaja' ? 'selected' : ''; ?>>Con rebaja</option>
                    <option value="sin_rebaja" <?php echo ($_GET['filtro_rebaja'] ?? '') === 'sin_rebaja' ? 'selected' : ''; ?>>Sin rebaja</option>
                </select>
            </div>
            <div class="filtros-buttons">
                <button type="submit" class="btn-filtrar">🔍 Filtrar</button>
                <a href="/admin/stock/admin_movil.php" class="btn-limpiar">✕ Limpiar</a>
            </div>
        </form>
    </div>

    <!-- TABLA DE PRODUCTOS -->
    <div class="productos-table-card">
        <div class="table-header">
            <h3>📋 Productos <span class="contador-productos"><?php echo intval($total_productos); ?></span></h3>
            <?php if ($puede_gestionar): ?>
            <a href="/admin/stock/productos_acciones.php?accion=crear" class="btn-nuevo">➕ Nuevo</a>
            <?php endif; ?>
        </div>

        <div style="overflow-x: auto;">
            <table class="tabla-movil" id="tablaProductos">
                <tbody>
                    <?php if ($productos && $productos->num_rows > 0): ?>
                        <?php while($p = $productos->fetch_assoc()): 
                            $tiene_rebaja = intval($p['porcentaje_rebaja'] ?? 0) > 0;
                            $nombre_js = htmlspecialchars(json_encode($p['nombre'] ?? ''), ENT_QUOTES, 'UTF-8');
                        ?>
                            <tr class="<?php echo !empty($p['activo']) ? 'fila-activo' : 'fila-inactivo'; ?>">
                                <td class="producto-imagen">
                                    <?php if (!empty($p['imagen_url'])): ?>
                                        <img src="<?php echo htmlspecialchars($p['imagen_url']); ?>" class="img-thumbnail" alt="<?php echo htmlspecialchars($p['nombre'] ?? ''); ?>">
                                    <?php else: ?>
                                        <div class="sin-imagen">❌</div>
                                    <?php endif; ?>
                                </td>
                                <td class="producto-nombre">
                                    <strong><?php echo htmlspecialchars($p['nombre'] ?? ''); ?></strong><br>
                                    <small style="color: #718096;">#<?php echo intval($p['id']); ?></small>
                                    <?php if ($tiene_rebaja): ?>
                                        <br><small style="color: #ef4444;">-<?php echo intval($p['porcentaje_rebaja']); ?>%</small>
                                    <?php endif; ?>
                                </td>
                                <td class="producto-cantidad">
                                    <span class="badge-cantidad <?php echo intval($p['cantidad']) == 0 ? 'sin-stock' : (intval($p['cantidad']) < 5 ? 'bajo-stock' : ''); ?>">
                                        <?php echo intval($p['cantidad']); ?>
                                    </span>
                                </td>
                                <td class="producto-precio">
                                    <?php if ($tiene_rebaja): ?>
                                        <div class="precio-rebaja">$<?php echo number_format(floatval($p['precio_original'] ?? $p['precio'] ?? 0), 2); ?></div>
                                        <div class="precio-final">$<?php echo number_format(floatval($p['precio'] ?? 0), 2); ?></div>
                                    <?php else: ?>
                                        <div class="precio-texto">$<?php echo number_format(floatval($p['precio'] ?? 0), 2); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td class="producto-acciones">
                                    <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: wrap;">
                                        <a href="/admin/stock/ver_producto.php?id=<?php echo intval($p['id']); ?>" class="btn-icono" title="Ver">👁️</a>
                                        <a href="/admin/stock/historial_producto.php?id=<?php echo intval($p['id']); ?>" class="btn-icono" title="Historial">📋</a>
                                        <?php if ($puede_gestionar): ?>
                                            <form method="POST" action="/admin/stock/productos_acciones.php?accion=toggle_estado&id=<?php echo intval($p['id']); ?>&estado=<?php echo intval($p['activo']); ?>" style="display:inline; margin:0;" onsubmit="return confirm('¿<?php echo !empty($p['activo']) ? 'Desactivar' : 'Activar'; ?> ' + <?php echo $nombre_js; ?> + '?')">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn-icono" title="<?php echo !empty($p['activo']) ? 'Desactivar' : 'Activar'; ?>">
                                                    <?php echo !empty($p['activo']) ? '🔴' : '🟢'; ?>
                                                </button>
                                            </form>
                                            <a href="/admin/stock/productos_acciones.php?accion=editar&id=<?php echo intval($p['id']); ?>" class="btn-icono" title="Editar">✏️</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="sin-datos">📭 No se encontraron productos</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="toast-container" id="toast-container"></div>
</div>

<script>
function mostrarNotificacion(mensaje, tipo) {
    tipo = tipo || 'exito';
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = 'toast-notificacion ' + tipo;
    const span = document.createElement('span');
    span.textContent = mensaje;
    const btn = document.createElement('button');
    btn.className = 'toast-cerrar';
    btn.textContent = '×';
    btn.onclick = function() { toast.remove(); };
    toast.appendChild(span);
    toast.appendChild(btn);
    container.appendChild(toast);
    
    setTimeout(function() {
        if (toast.parentElement) toast.remove();
    }, 5000);
}

document.addEventListener('DOMContentLoaded', function() {
    <?php if (isset($_SESSION['mensaje'])): ?>
        mostrarNotificacion(<?php echo json_encode((string)$_SESSION['mensaje']); ?>, <?php echo json_encode((string)($_SESSION['tipo_mensaje'] ?? 'exito')); ?>);
        <?php unset($_SESSION['mensaje']); unset($_SESSION['tipo_mensaje']); ?>
    <?php endif; ?>
});

// Auto-submit al cambiar selects
document.addEventListener('DOMContentLoaded', function() {
    const ids = ['filtro_estado', 'filtro_imagen', 'filtro_rebaja'];
    ids.forEach(function(id) {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', function() {
                const form = document.getElementById('filtrosForm');
                if (form) form.submit();
            });
        }
    });
});
</script>

<?php
require_once __DIR__ . '/../../footer.php';
?>
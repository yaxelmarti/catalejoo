<?php
require_once __DIR__ . '/../../header.php';
require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';

// ============================================
// DEFINIR PERMISOS DEL USUARIO
// ============================================
$rol_actual = trim($_SESSION['rol'] ?? '');
$es_super_admin = ($rol_actual === 'Super Admin');

$permisos = [
    'ver' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor']),
    'editar' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Inventario', 'Proveedor']),
    'eliminar' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Proveedor']),
    'crear' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'])
];

// ===== OBTENER COLORES DE CONFIGURACIÓN =====
$stmt_color = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario'");
$stmt_color->execute();
$result_color = $stmt_color->get_result();
$color_primario = $result_color->num_rows > 0 ? $result_color->fetch_assoc()['valor'] : '#667eea';
$stmt_color->close();

$stmt_color2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario'");
$stmt_color2->execute();
$result_color2 = $stmt_color2->get_result();
$color_secundario = $result_color2->num_rows > 0 ? $result_color2->fetch_assoc()['valor'] : '#764ba2';
$stmt_color2->close();

if (!$permisos['ver']) {
    header('Location: /admin/stock/productos.php?error=permiso');
    exit;
}

$producto_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$producto_id) {
    header('Location: /admin/stock/productos.php');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_filtro = obtenerProveedorId($conn, $_SESSION['usuario_id'], $rol_actual);
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_filtro == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_filtro > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_filtro);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $stmt_check->close();
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ============================================
// FUNCIONES PARA OBTENER ESTADO DEL PRODUCTO
// ============================================
function getUnidadesEnCarritos($conn, $producto_id, $tiempo_expiracion) {
    $sql = "SELECT SUM(cp.cantidad) as total 
            FROM carrito_productos cp
            JOIN carritos c ON cp.carrito_id = c.id
            WHERE cp.producto_id = ? 
            AND c.fecha_expiracion > DATE_SUB(NOW(), INTERVAL ? HOUR)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $producto_id, $tiempo_expiracion);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['total'] ?? 0;
}

function getUnidadesEnPedidos($conn, $producto_id) {
    $sql = "SELECT SUM(pd.cantidad) as total 
            FROM pedido_detalles pd
            JOIN pedidos p ON pd.pedido_id = p.id
            WHERE pd.producto_id = ? 
            AND p.estado_actual NOT IN ('cancelado', 'devuelto')";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $producto_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['total'] ?? 0;
}

// ============================================
// VERIFICAR PROPIEDAD ANTES DE CONSULTAR
// ============================================
if (!productoPerteneceAProveedor($conn, $producto_id, $proveedor_id_filtro)) {
    error_log("[ver_producto] Acceso denegado (usuario={$_SESSION['usuario_id']}, id={$producto_id}, proveedor={$proveedor_id_filtro})");
    header('Location: /admin/stock/productos.php?error=acceso');
    exit;
}

// ============================================
// CONSULTAR PRODUCTO (SIN FILTRO DUPLICADO DE PROVEEDOR)
// ============================================
$sql = "
    SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono 
    FROM productos p 
    LEFT JOIN categorias c ON p.categoria_id = c.id 
    WHERE p.id = ?
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("[ver_producto] Error prepare: " . $conn->error);
    header('Location: /admin/stock/productos.php?error=db');
    exit;
}
$stmt->bind_param("i", $producto_id);
$stmt->execute();
$producto = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$producto) {
    header('Location: /admin/stock/productos.php?error=acceso');
    exit;
}

// ===== Obtener tiempo de expiración de configuración =====
$tiempo_expiracion = 48;
$config_result = $conn->query("SELECT valor FROM configuracion WHERE clave = 'tiempo_expiracion' LIMIT 1");
if ($config_result && $row = $config_result->fetch_assoc()) {
    $tiempo_expiracion = intval($row['valor']);
}

$en_carritos = getUnidadesEnCarritos($conn, $producto_id, $tiempo_expiracion);
$en_pedidos = getUnidadesEnPedidos($conn, $producto_id);

$importe_costo = $producto['precio_costo'] * $producto['cantidad'];
$importe_venta = $producto['precio'] * $producto['cantidad'];
$margen = $importe_venta - $importe_costo;
$porcentaje = $importe_costo > 0 ? ($margen / $importe_costo) * 100 : 0;

$tiene_rebaja = ($producto['porcentaje_rebaja'] ?? 0) > 0;
$precio_original = $tiene_rebaja ? $producto['precio_original'] : $producto['precio'];
$precio_final = $producto['precio'];

// Nuevos campos
$moneda_adquisicion = $producto['moneda_adquisicion'] ?? 'USD';
$porcentaje_ganancia = floatval($producto['porcentaje_ganancia'] ?? 0);
$precio_adquisicion = floatval($producto['precio_adquisicion'] ?? 0);
?>

<style>
:root {
    --primary: <?php echo $color_primario; ?>;
    --secondary: <?php echo $color_secundario; ?>;
}

* { box-sizing: border-box; }

.ver-container {
    width: 100%;
    max-width: 1400px;
    margin: 1rem auto;
    padding: 0 1rem;
}

@media (min-width: 768px) {
    .ver-container { padding: 0 2rem; margin: 2rem auto; }
}

.ver-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

@media (max-width: 640px) {
    .ver-header { flex-direction: column; align-items: stretch; text-align: center; }
    .ver-header h1 { font-size: 1.5rem; }
}

.ver-header h1 {
    font-size: 1.75rem;
    color: #2d3748;
    margin: 0;
}

@media (min-width: 768px) { .ver-header h1 { font-size: 2rem; } }

.acciones-header {
    display: flex;
    gap: 0.75rem;
    flex-wrap: wrap;
}

@media (max-width: 640px) {
    .acciones-header { justify-content: center; gap: 0.5rem; }
}

.btn-header {
    padding: 0.5rem 1rem;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
}

@media (min-width: 768px) { .btn-header { padding: 0.6rem 1.2rem; } }

.btn-volver { background: #edf2f7; color: #4a5568; }
.btn-volver:hover { background: #e2e8f0; transform: translateY(-2px); }

.btn-historial {
    background: linear-gradient(135deg, #9f7aea 0%, #805ad5 100%);
    color: white;
}
.btn-historial:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(159, 122, 234, 0.3); }

.producto-card {
    background: white;
    border-radius: 12px;
    padding: 1.25rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    margin-bottom: 1.5rem;
    width: 100%;
}

@media (min-width: 768px) {
    .producto-card { padding: 2rem; margin-bottom: 2rem; }
}

.info-grid {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    margin-bottom: 1.5rem;
    width: 100%;
}

@media (min-width: 768px) {
    .info-grid {
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 2rem;
        margin-bottom: 2rem;
    }
}

@media (min-width: 1024px) {
    .info-grid { grid-template-columns: 320px 1fr; }
}

.imagen-container {
    background: #f8fafc;
    border-radius: 12px;
    padding: 1rem;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width: 100%;
}

.producto-imagen {
    max-width: 100%;
    max-height: 250px;
    width: auto;
    height: auto;
    object-fit: contain;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
}

@media (min-width: 768px) { .producto-imagen { max-height: 280px; } }
@media (min-width: 1024px) { .producto-imagen { max-height: 320px; } }

.producto-imagen:hover { transform: scale(1.02); }

.sin-imagen {
    width: 100%;
    min-height: 200px;
    background: #edf2f7;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #a0aec0;
    font-size: 2.5rem;
    border-radius: 8px;
}

@media (min-width: 768px) { .sin-imagen { min-height: 250px; font-size: 3rem; } }

.imagen-url {
    margin-top: 0.5rem;
    font-size: 0.7rem;
    color: #718096;
    word-break: break-all;
    max-width: 100%;
}

@media (min-width: 768px) { .imagen-url { font-size: 0.8rem; } }

.datos-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    width: 100%;
}

@media (min-width: 480px) { .datos-grid { gap: 1rem; } }
@media (min-width: 640px) { .datos-grid { grid-template-columns: repeat(3, 1fr); } }
@media (min-width: 1024px) { .datos-grid { grid-template-columns: repeat(3, 1fr); gap: 1.25rem; } }

.campo {
    margin-bottom: 0;
    background: #f9fafb;
    padding: 0.5rem;
    border-radius: 8px;
}

@media (min-width: 768px) { .campo { padding: 0; background: transparent; } }

.campo-label {
    font-size: 0.65rem;
    text-transform: uppercase;
    color: #718096;
    font-weight: 600;
    margin-bottom: 0.2rem;
}

@media (min-width: 768px) { .campo-label { font-size: 0.75rem; } }

.campo-valor {
    font-size: 0.85rem;
    color: #2d3748;
    font-weight: 500;
    word-break: break-word;
}

@media (min-width: 768px) { .campo-valor { font-size: 1rem; } }

.categoria-badge {
    display: inline-block;
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.2rem 0.6rem;
    border-radius: 20px;
    font-size: 0.75rem;
}

.badge-rebaja {
    background: #ef4444;
    color: white;
    padding: 0.15rem 0.5rem;
    border-radius: 20px;
    font-size: 0.65rem;
    font-weight: 600;
    display: inline-block;
    margin-left: 0.5rem;
}

@media (min-width: 768px) { .badge-rebaja { font-size: 0.7rem; } }

.inventario-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 0.75rem;
    margin: 1rem 0 1.5rem 0;
    width: 100%;
}

@media (min-width: 480px) { .inventario-grid { gap: 1rem; } }
@media (min-width: 768px) { .inventario-grid { gap: 1rem; margin: 1rem 0 2rem 0; } }

.inventario-card {
    background: #f8fafc;
    border-radius: 10px;
    padding: 0.75rem 0.5rem;
    text-align: center;
    border: 1px solid #e2e8f0;
    transition: transform 0.2s;
    width: 100%;
}

@media (min-width: 768px) { .inventario-card { padding: 1rem; border-radius: 12px; } }

.inventario-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }

.inventario-icono { font-size: 1.2rem; margin-bottom: 0.2rem; }
@media (min-width: 768px) { .inventario-icono { font-size: 1.5rem; margin-bottom: 0.3rem; } }

.inventario-label {
    font-size: 0.6rem;
    text-transform: uppercase;
    color: #718096;
    font-weight: 600;
    letter-spacing: 0.3px;
}

@media (min-width: 768px) { .inventario-label { font-size: 0.7rem; } }

.inventario-valor {
    font-size: 1.3rem;
    font-weight: 700;
    line-height: 1.2;
    margin: 0.15rem 0;
}

@media (min-width: 768px) { .inventario-valor { font-size: 1.8rem; margin: 0.2rem 0; } }

.inventario-sub { font-size: 0.6rem; color: #a0aec0; }
@media (min-width: 768px) { .inventario-sub { font-size: 0.7rem; } }

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-top: 1.5rem;
    width: 100%;
}

@media (min-width: 640px) { .stats-grid { grid-template-columns: repeat(4, 1fr); } }
@media (min-width: 768px) { .stats-grid { gap: 1rem; margin-top: 2rem; } }

.stat-card {
    background: #f8fafc;
    border-radius: 10px;
    padding: 0.75rem 0.5rem;
    text-align: center;
    border: 1px solid #edf2f7;
    width: 100%;
}

@media (min-width: 768px) { .stat-card { padding: 1rem; border-radius: 8px; } }

.stat-label { font-size: 0.65rem; color: #718096; text-transform: uppercase; }
@media (min-width: 768px) { .stat-label { font-size: 0.8rem; } }

.stat-value { font-size: 1rem; font-weight: 700; color: #2d3748; }
@media (min-width: 768px) { .stat-value { font-size: 1.5rem; } }

.stat-value.positivo { color: #48bb78; }
.stat-value.negativo { color: #f56565; }

.descripcion-card {
    background: #f8fafc;
    border-radius: 10px;
    padding: 1rem;
    margin-top: 1.5rem;
    width: 100%;
}

@media (min-width: 768px) { .descripcion-card { border-radius: 8px; padding: 1.5rem; margin-top: 2rem; } }

.descripcion-card h3 { margin-bottom: 0.75rem; color: #4a5568; font-size: 1rem; }
@media (min-width: 768px) { .descripcion-card h3 { margin-bottom: 1rem; font-size: 1.1rem; } }

.descripcion-texto {
    line-height: 1.5;
    color: #2d3748;
    white-space: pre-wrap;
    font-size: 0.85rem;
}

@media (min-width: 768px) { .descripcion-texto { line-height: 1.6; font-size: 1rem; } }

.info-imagen {
    margin-top: 1rem;
    padding: 0.75rem;
    background: #f8fafc;
    border-radius: 8px;
    width: 100%;
}

@media (min-width: 768px) { .info-imagen { margin-top: 1rem; padding: 1rem; } }

.info-imagen small { color: #718096; font-size: 0.7rem; }
@media (min-width: 768px) { .info-imagen small { font-size: 0.8rem; } }

.acciones-footer {
    margin-top: 1.5rem;
    display: flex;
    gap: 0.75rem;
    justify-content: center;
    flex-wrap: wrap;
    width: 100%;
}

@media (min-width: 768px) {
    .acciones-footer { margin-top: 2rem; gap: 1rem; justify-content: flex-end; }
}

.btn-accion {
    padding: 0.6rem 1rem;
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    font-size: 0.85rem;
    flex: 1;
    min-width: 140px;
}

@media (min-width: 480px) { .btn-accion { flex: auto; padding: 0.7rem 1.25rem; } }
@media (min-width: 768px) { .btn-accion { padding: 0.8rem 2rem; font-size: 1rem; } }

.btn-editar {
    background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
    color: white;
}

.btn-editar:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(66, 153, 225, 0.3); }

.btn-eliminar {
    background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
    color: white;
}

.btn-eliminar:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(245, 101, 101, 0.3); }

.btn-historial-footer {
    background: linear-gradient(135deg, #9f7aea 0%, #805ad5 100%);
    color: white;
}

.btn-historial-footer:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(159, 122, 234, 0.3); }

body { overflow-x: hidden; }

.container-fluid, .main-content {
    padding-left: 0 !important;
    padding-right: 0 !important;
    max-width: 100% !important;
    overflow-x: hidden !important;
}
</style>

<div class="ver-container">
    <div class="ver-header">
        <h1>🔍 Ver Producto</h1>
        <div class="acciones-header">
            <a href="/admin/stock/productos.php" class="btn-header btn-volver">← Volver</a>
            <a href="historial_producto.php?id=<?php echo $producto['id']; ?>" class="btn-header btn-historial">📋 Ver Historial</a>
        </div>
    </div>

    <div class="producto-card">
        <div class="info-grid">
            <div class="imagen-container">
                <?php 
                if (!empty($producto['imagen_url'])) {
                    if (filter_var($producto['imagen_url'], FILTER_VALIDATE_URL)) {
                        echo '<img src="' . htmlspecialchars($producto['imagen_url']) . '" 
                                   alt="' . htmlspecialchars($producto['nombre']) . '" 
                                   class="producto-imagen"
                                   onerror="this.onerror=null; this.src=\'\'; this.parentElement.innerHTML+=\'<div class=\\\'sin-imagen\\\' style=\\\'min-height:200px;\\\'>❌ Imagen externa no disponible</div>\';">';
                        echo '<div class="imagen-url">🌐 Imagen externa</div>';
                    } else {
                        $ruta_imagen = str_replace('./', '', $producto['imagen_url']);
                        if (strpos($ruta_imagen, '/') !== 0) {
                            $ruta_imagen = '/' . $ruta_imagen;
                        }
                        echo '<img src="' . htmlspecialchars($ruta_imagen) . '" 
                                   alt="' . htmlspecialchars($producto['nombre']) . '" 
                                   class="producto-imagen"
                                   onerror="this.onerror=null; this.src=\'\'; this.parentElement.innerHTML+=\'<div class=\\\'sin-imagen\\\' style=\\\'min-height:200px;\\\'>❌ Imagen local no encontrada</div>\';">';
                        echo '<div class="imagen-url">📁 Imagen local: ' . basename($ruta_imagen) . '</div>';
                    }
                } else {
                    echo '<div class="sin-imagen">📷 Sin imagen</div>';
                }
                ?>
            </div>
            
            <div class="datos-grid">
                <div class="campo">
                    <div class="campo-label">ID</div>
                    <div class="campo-valor">#<?php echo $producto['id']; ?></div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Nombre</div>
                    <div class="campo-valor"><?php echo htmlspecialchars($producto['nombre']); ?></div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Marca</div>
                    <div class="campo-valor"><?php echo htmlspecialchars($producto['marca'] ?? '—'); ?></div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Categoría</div>
                    <div class="campo-valor">
                        <?php if (!empty($producto['categoria_nombre'])): ?>
                            <span class="categoria-badge">
                                <?php echo $producto['categoria_icono'] ?? '📦'; ?> 
                                <?php echo htmlspecialchars($producto['categoria_nombre']); ?>
                            </span>
                        <?php else: ?>
                            <span style="color: #a0aec0;">Sin categoría</span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">🏪 Proveedor</div>
                    <div class="campo-valor">
                        <?php 
                        $proveedor_id_tmp = intval($producto['proveedor_id'] ?? 0);
                        if ($proveedor_id_tmp > 0): 
                            $stmt_prov = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                            $stmt_prov->bind_param("i", $proveedor_id_tmp);
                            $stmt_prov->execute();
                            $prov_result = $stmt_prov->get_result();
                            if ($prov = $prov_result->fetch_assoc()): ?>
                                <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                            <?php else: ?>
                                <span style="color: #a0aec0;">—</span>
                            <?php endif; 
                            $stmt_prov->close();
                        else: ?>
                            <span style="color: #a0aec0;">—</span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Creación</div>
                    <div class="campo-valor"><?php echo date('d/m/Y', strtotime($producto['fecha_creacion'])); ?></div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Peso (kg)</div>
                    <div class="campo-valor"><?php echo number_format($producto['peso'] ?? 0, 3); ?> kg</div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Precio Costo (USD)</div>
                    <div class="campo-valor">$<?php echo number_format($producto['precio_costo'], 2); ?></div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">💱 Moneda del Costo</div>
                    <div class="campo-valor">
                        <?php echo htmlspecialchars($moneda_adquisicion); ?>
                        <?php if ($precio_adquisicion > 0): ?>
                            (<?php echo number_format($precio_adquisicion, 2); ?> <?php echo htmlspecialchars($moneda_adquisicion); ?>)
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">📈 % Ganancia</div>
                    <div class="campo-valor"><?php echo number_format($porcentaje_ganancia, 2); ?>%</div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Precio Venta</div>
                    <div class="campo-valor">
                        <?php if ($tiene_rebaja): ?>
                            <span style="text-decoration: line-through; color: #9ca3af; font-size: 0.75rem;">
                                $<?php echo number_format($precio_original, 2); ?>
                            </span>
                            <span style="color: #10b981; font-weight: bold;">
                                $<?php echo number_format($precio_final, 2); ?>
                            </span>
                            <span class="badge-rebaja">-<?php echo $producto['porcentaje_rebaja']; ?>%</span>
                        <?php else: ?>
                            $<?php echo number_format($precio_final, 2); ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Stock Físico</div>
                    <div class="campo-valor">
                        <span style="background: <?php echo $producto['cantidad'] == 0 ? '#fed7d7' : ($producto['cantidad'] < 5 ? '#feebc8' : '#e2e8f0'); ?>; padding: 0.15rem 0.6rem; border-radius: 20px; display: inline-block;">
                            <?php echo $producto['cantidad']; ?> unidades
                        </span>
                    </div>
                </div>
                
                <div class="campo">
                    <div class="campo-label">Actualización</div>
                    <div class="campo-valor"><?php echo date('d/m/Y', strtotime($producto['fecha_creacion'])); ?></div>
                </div>
            </div>
        </div>

        <div class="inventario-grid">
            <div class="inventario-card">
                <div class="inventario-icono">📦</div>
                <div class="inventario-label">Stock Físico</div>
                <div class="inventario-valor"><?php echo $producto['cantidad']; ?></div>
                <div class="inventario-sub">En bodega</div>
            </div>
            
            <div class="inventario-card">
                <div class="inventario-icono">🛒</div>
                <div class="inventario-label">En Carritos</div>
                <div class="inventario-valor" style="color: <?php echo $en_carritos > 0 ? '#ecc94b' : '#a0aec0'; ?>;">
                    <?php echo $en_carritos; ?>
                </div>
                <div class="inventario-sub">Reservados (<?php echo $tiempo_expiracion; ?>h)</div>
            </div>
            
            <div class="inventario-card">
                <div class="inventario-icono">📋</div>
                <div class="inventario-label">En Pedidos</div>
                <div class="inventario-valor" style="color: <?php echo $en_pedidos > 0 ? '#48bb78' : '#a0aec0'; ?>;">
                    <?php echo $en_pedidos; ?>
                </div>
                <div class="inventario-sub">Vendidos</div>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Importe Costo</div>
                <div class="stat-value">$<?php echo number_format($importe_costo, 2); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Importe Venta</div>
                <div class="stat-value">$<?php echo number_format($importe_venta, 2); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Margen</div>
                <div class="stat-value <?php echo $margen >= 0 ? 'positivo' : 'negativo'; ?>">
                    $<?php echo number_format($margen, 2); ?>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Margen %</div>
                <div class="stat-value <?php echo $margen >= 0 ? 'positivo' : 'negativo'; ?>">
                    <?php echo number_format($porcentaje, 1); ?>%
                </div>
            </div>
        </div>

        <?php if (!empty($producto['descripcion'])): ?>
        <div class="descripcion-card">
            <h3>📝 Descripción</h3>
            <div class="descripcion-texto">
                <?php echo nl2br(htmlspecialchars($producto['descripcion'])); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($producto['imagen_url'])): ?>
        <div class="info-imagen">
            <small>
                <strong>Tipo:</strong> 
                <?php 
                if (filter_var($producto['imagen_url'], FILTER_VALIDATE_URL)) echo 'URL externa';
                else echo 'Archivo local';
                ?>
                <br>
                <strong>Ruta:</strong> <?php echo htmlspecialchars($producto['imagen_url']); ?>
            </small>
        </div>
        <?php endif; ?>
        
        <div class="acciones-footer">
            <a href="historial_producto.php?id=<?php echo $producto['id']; ?>" class="btn-accion btn-historial-footer">
                📋 Ver Historial
            </a>
            
            <?php if ($permisos['editar']): ?>
                <a href="/admin/stock/productos_acciones.php?accion=editar&id=<?php echo $producto['id']; ?>" 
                   class="btn-accion btn-editar">
                    ✏️ Editar
                </a>
            <?php endif; ?>
            
            <?php if ($permisos['eliminar']): ?>
                <a href="/admin/stock/productos_acciones.php?accion=eliminar&id=<?php echo $producto['id']; ?>&csrf_token=<?php echo urlencode($_SESSION['csrf_token'] ?? ''); ?>" 
                   class="btn-accion btn-eliminar"
                   onclick="return confirm('¿Estás seguro de eliminar el producto <?php echo addslashes($producto['nombre']); ?>?')">
                    🗑️ Eliminar
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
$conn->close();
?>
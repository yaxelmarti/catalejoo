<?php
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . '/conexion.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/header.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/proveedor_utils.php';

$roles_permitidos = ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_gestionar) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

// Validar que el proveedor existe y está activo
if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_usuario);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// Si es proveedor, forzar su proveedor_id
if ($proveedor_id_usuario > 0) {
    $_POST['proveedor_id'] = $proveedor_id_usuario;
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$nombre = trim($_POST['nombre'] ?? '');
$proveedor_id = isset($_POST['proveedor_id']) ? intval($_POST['proveedor_id']) : null;
$descripcion = trim($_POST['descripcion'] ?? '');
$imagen_url = trim($_POST['imagen_url'] ?? '');
$porcentaje_rebaja = intval($_POST['porcentaje_rebaja'] ?? 0);
$activo = isset($_POST['activo']) ? intval($_POST['activo']) : 1;

// ============================================
// VERIFICAR CSRF TOKEN
// ============================================
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: combos.php');
    exit;
}

// ============================================
// VALIDAR QUE EL PROVEEDOR EXISTE (SI NO ES PROVEEDOR)
// ============================================
if ($proveedor_id_usuario == 0 && $proveedor_id > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ El proveedor seleccionado no existe o no está activo';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
        exit;
    }
    $stmt_check->close();
}

// Obtener productos del JSON
$productos_json = $_POST['productos_json'] ?? '[]';
$productos = json_decode($productos_json, true);

if (empty($nombre)) {
    $_SESSION['mensaje'] = "❌ El nombre del combo es obligatorio";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

// Filtrar productos con cantidad > 0
$productos_filtrados = [];
$suma_precios = 0;

foreach ($productos as $item) {
    $prod_id = intval($item['id']);
    $cantidad = intval($item['cantidad']);
    
    if ($cantidad > 0 && $prod_id > 0) {
        $stmt = $conn->prepare("SELECT precio, precio_costo FROM productos WHERE id = ?");
        $stmt->bind_param("i", $prod_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $productos_filtrados[] = [
                'id' => $prod_id,
                'cantidad' => $cantidad,
                'precio' => $row['precio']
            ];
            $suma_precios += $row['precio'] * $cantidad;
        }
    }
}

if (empty($productos_filtrados)) {
    $_SESSION['mensaje'] = "❌ Debe seleccionar al menos un producto para el combo";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: combos_editar.php' . ($id ? '?id=' . $id : ''));
    exit;
}

// ============================================
// VERIFICAR PROPIEDAD DEL COMBO (SI ES EDICIÓN)
// ============================================
if ($id > 0 && $proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT proveedor_id FROM combos WHERE id = ?");
    $stmt_check->bind_param("i", $id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    if ($row_check = $result_check->fetch_assoc()) {
        if ($row_check['proveedor_id'] != $proveedor_id_usuario) {
            $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este combo';
            $_SESSION['tipo_mensaje'] = 'error';
            header('Location: combos.php');
            exit;
        }
    }
    $stmt_check->close();
}

// Calcular precio final con rebaja
$precio_final = $suma_precios * (1 - $porcentaje_rebaja / 100);
$productos_distintos = count($productos_filtrados);
$unidades_totales = array_sum(array_column($productos_filtrados, 'cantidad'));

// ============================================
// PRIMERO: Desmarcar productos de combos anteriores (si es edición)
// ============================================
if ($id > 0) {
    // Obtener los productos que estaban en este combo
    $stmt_old = $conn->prepare("SELECT producto_id FROM combo_productos WHERE combo_id = ?");
    $stmt_old->bind_param("i", $id);
    $stmt_old->execute();
    $result_old = $stmt_old->get_result();
    
    while ($old = $result_old->fetch_assoc()) {
        // Solo desmarcar si no están siendo usados en otro combo activo
        $check = $conn->query("SELECT COUNT(*) as total FROM combo_productos cp 
                               JOIN combos c ON cp.combo_id = c.id 
                               WHERE cp.producto_id = {$old['producto_id']} 
                               AND c.activo = 1 
                               AND c.id != $id");
        $check_result = $check->fetch_assoc();
        if ($check_result['total'] == 0) {
            $conn->query("UPDATE productos SET en_combo = 0, combo_id = NULL WHERE id = {$old['producto_id']}");
        }
    }
}

// ============================================
// SEGUNDO: Guardar/Actualizar el combo
// ============================================
if ($id > 0) {
    // Actualizar combo existente
    $stmt = $conn->prepare("UPDATE combos SET 
        nombre = ?, 
        proveedor_id = ?,
        descripcion = ?, 
        imagen_url = ?, 
        precio = ?, 
        porcentaje_rebaja = ?, 
        precio_final = ?,
        productos_distintos = ?,
        unidades_totales = ?,
        stock_combo = ?,
        activo = ?
        WHERE id = ?");
    
    $stmt->bind_param("sisssddiiiii", 
        $nombre, 
        $proveedor_id,
        $descripcion, 
        $imagen_url, 
        $suma_precios, 
        $porcentaje_rebaja, 
        $precio_final,
        $productos_distintos,
        $unidades_totales,
        $_POST['stock_combo'],
        $activo,
        $id
    );
    $stmt->execute();
    
    // Eliminar productos antiguos del combo
    $conn->query("DELETE FROM combo_productos WHERE combo_id = $id");
    
} else {
    // Insertar nuevo combo
    $stmt = $conn->prepare("INSERT INTO combos 
        (nombre, proveedor_id, descripcion, imagen_url, precio, porcentaje_rebaja, precio_final, productos_distintos, unidades_totales, stock_combo, activo) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->bind_param("sisssddiiii", 
        $nombre, 
        $proveedor_id,
        $descripcion, 
        $imagen_url, 
        $suma_precios, 
        $porcentaje_rebaja, 
        $precio_final,
        $productos_distintos,
        $unidades_totales,
        $_POST['stock_combo'],
        $activo
    );
    $stmt->execute();
    $id = $conn->insert_id;
}
// ============================================
// TERCERO: Insertar nuevos productos del combo
// ============================================
if ($id > 0) {
    $stmt_prod = $conn->prepare("INSERT INTO combo_productos (combo_id, producto_id, cantidad) VALUES (?, ?, ?)");
    
    foreach ($productos_filtrados as $item) {
        $stmt_prod->bind_param("iii", $id, $item['id'], $item['cantidad']);
        $stmt_prod->execute();
        
        // Marcar el producto como en_combo = 1 (solo si el combo está activo)
        if ($activo == 1) {
            $conn->query("UPDATE productos SET en_combo = 1, combo_id = $id WHERE id = {$item['id']}");
        }
    }
}

$_SESSION['mensaje'] = $id > 0 ? "✅ Combo actualizado correctamente" : "✅ Combo creado correctamente";
$_SESSION['tipo_mensaje'] = "exito";

header('Location: combos.php?t=' . time());
exit;
?>
<?php
// ============================================
// CONFIGURACIÓN (23 Oct 2026)
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/historial.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/csrf.php';

// ============================================
// VALIDAR SESIÓN ACTIVA
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

// ============================================
// DEFINIR PERMISOS DEL USUARIO
// ============================================
$rol_actual = trim($_SESSION['rol'] ?? '');

$permisos = [
    'editar' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Inventario', 'Proveedor']),
    'eliminar' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Proveedor']),
    'crear' => in_array($rol_actual, ['Super Admin', 'Gerente', 'Inventario', 'Proveedor'])
];

$accion = $_GET['accion'] ?? ($_POST['accion'] ?? '');
$id = isset($_GET['id']) ? intval($_GET['id']) : (isset($_POST['id']) ? intval($_POST['id']) : 0);
$mensaje = '';
$tipo_mensaje = '';

// ============================================
// VERIFICAR PERMISOS (ANTES DE header.php)
// ============================================
if ($accion == 'crear' && !$permisos['crear']) {
    $_SESSION['mensaje'] = '❌ No tienes permiso para CREAR productos';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'editar' && !$permisos['editar']) {
    $_SESSION['mensaje'] = '❌ No tienes permiso para EDITAR productos';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'eliminar' && !$permisos['eliminar']) {
    $_SESSION['mensaje'] = '❌ No tienes permiso para ELIMINAR productos';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'eliminar_confirmado' && $rol_actual != 'Super Admin') {
    header('Location: /admin/stock/productos.php?error=permiso');
    exit;
}
if ($accion == 'toggle_estado' && !$permisos['editar']) {
    $_SESSION['mensaje'] = '❌ No tienes permiso para cambiar el estado del producto';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}
if ($accion == 'eliminar_imagen' && !$permisos['editar']) {
    $_SESSION['mensaje'] = '❌ No tienes permiso para modificar la imagen del producto';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin/stock/productos.php');
    exit;
}

// ============================================
// VALIDACIÓN CSRF (POST guardar y GET destructivos)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar'])) {
    if (!function_exists('csrf_validar') || !csrf_validar($_POST['csrf_token'] ?? '')) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/stock/productos.php');
        exit;
    }
}

// Para acciones destructivas (GET o POST): exigir token
$token_csrf = $_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? '');
if (in_array($accion, ['toggle_estado', 'eliminar', 'eliminar_imagen'], true)) {
    if (!function_exists('csrf_validar') || !csrf_validar($token_csrf)) {
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin/stock/productos.php');
        exit;
    }
}

// ============================================
// AHORA INCLUIR header.php (SOLO SI NO HAY ERROR)
// ============================================
$es_post = ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar']));

if (!$es_post) {
    require_once __DIR__ . '/../../header.php';
}

// ============================================
// DETECTAR PROVEEDOR CON FUNCIÓN CENTRALIZADA
// ============================================
$proveedor_id_filtro = intval(obtenerProveedorId($conn, $_SESSION['usuario_id'], $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

// Validar que el proveedor existe y está activo
if ($es_proveedor && $proveedor_id_filtro == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_filtro > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    $stmt_check->bind_param("i", $proveedor_id_filtro);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows === 0) {
        $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /admin.php');
        exit;
    }
    $stmt_check->close();
}

// ===== ACTIVAR / DESACTIVAR PRODUCTO =====
if ($accion == 'toggle_estado' && $id > 0) {
    // VERIFICAR PROPIEDAD
    if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_filtro)) {
        $_SESSION['mensaje'] = "❌ No tienes permiso para modificar este producto (no pertenece a tu tienda)";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: /admin/stock/productos.php');
        exit;
    }
    
    $estado_actual = isset($_GET['estado']) ? intval($_GET['estado']) : (isset($_POST['estado']) ? intval($_POST['estado']) : 1);
    $nuevo_estado = $estado_actual ? 0 : 1;
    
    $stmt = $conn->prepare("SELECT nombre FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($producto) {
        $stmt = $conn->prepare("UPDATE productos SET activo = ? WHERE id = ?");
        $stmt->bind_param("ii", $nuevo_estado, $id);
        
        if ($stmt->execute()) {
            $stmt->close();
            $cambios = [
                'activo' => [
                    'antes' => $estado_actual,
                    'despues' => $nuevo_estado
                ]
            ];
            registrarCambioProducto($conn, $id, 'editar', $cambios);
            
            $_SESSION['mensaje'] = "✅ Producto '{$producto['nombre']}' " . ($nuevo_estado ? 'activado' : 'desactivado') . " correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
        } else {
            $stmt->close();
            $_SESSION['mensaje'] = "❌ Error al cambiar estado: " . $conn->error;
            $_SESSION['tipo_mensaje'] = "error";
        }
    } else {
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    // Construir URL de redirección
    $redirect = '/admin/stock/productos.php';
    if (isset($_GET['filtro_estado'])) {
        $redirect .= '?filtro_estado=' . urlencode($_GET['filtro_estado']);
    }
    
    if (!headers_sent()) {
        header('Location: ' . $redirect);
        exit;
    } else {
        echo '<script>window.location.href = "' . $redirect . '";</script>';
        exit;
    }
}

// ===== ELIMINACIÓN CONFIRMADA (SOLO SUPER ADMIN) =====
if ($accion == 'eliminar_confirmado' && $id > 0 && $_SESSION['rol'] == 'Super Admin') {
    // Verificar si el producto existe
    $check = $conn->prepare("SELECT id, nombre, imagen_url FROM productos WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $producto_eliminar = $check->get_result()->fetch_assoc();
    $check->close();
    
    if ($producto_eliminar) {
        // 🔒 VERIFICAR DEPENDENCIAS CRÍTICAS ANTES DE BORRAR
        $stmt_carritos = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos WHERE producto_id = ?");
        $stmt_carritos->bind_param("i", $id);
        $stmt_carritos->execute();
        $total_carritos = $stmt_carritos->get_result()->fetch_assoc()['total'];
        $stmt_carritos->close();
        
        $stmt_pedidos = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles pd 
                                        JOIN pedidos p ON pd.pedido_id = p.id 
                                        WHERE pd.producto_id = ? 
                                        AND p.estado_actual NOT IN ('cancelado', 'devuelto')");
        $stmt_pedidos->bind_param("i", $id);
        $stmt_pedidos->execute();
        $total_pedidos = $stmt_pedidos->get_result()->fetch_assoc()['total'];
        $stmt_pedidos->close();
        
        if ($total_carritos > 0 || $total_pedidos > 0) {
            $_SESSION['mensaje'] = "❌ No se puede eliminar '{$producto_eliminar['nombre']}': está en $total_carritos carrito(s) y $total_pedidos pedido(s) en curso. Desactívalo en su lugar.";
            $_SESSION['tipo_mensaje'] = "error";
            header('Location: /admin/stock/productos.php');
            exit;
        }
        
        // Si llega aquí, no hay carritos ni pedidos → borrar
        $conn->begin_transaction();
        try {
            // 1. Borrar historial del producto (FK a productos)
            $stmt_del = $conn->prepare("DELETE FROM historial_producto WHERE producto_id = ?");
            $stmt_del->bind_param("i", $id);
            $stmt_del->execute();
            $stmt_del->close();
            
            $stmt_del = $conn->prepare("DELETE FROM historial_productos_cambios WHERE producto_id = ?");
            $stmt_del->bind_param("i", $id);
            $stmt_del->execute();
            $stmt_del->close();
            
            // 2. Borrar movimientos de inventario (FK a productos)
            $stmt_del = $conn->prepare("DELETE FROM movimientos_inventario WHERE producto_id = ?");
            $stmt_del->bind_param("i", $id);
            $stmt_del->execute();
            $stmt_del->close();
            
            // 3. Eliminar imagen del servidor
            if (!empty($producto_eliminar['imagen_url'])) {
                $ruta_imagen = $_SERVER['DOCUMENT_ROOT'] . $producto_eliminar['imagen_url'];
                if (file_exists($ruta_imagen)) {
                    unlink($ruta_imagen);
                }
            }
            
            // 4. Eliminar el producto
            $stmt = $conn->prepare("DELETE FROM productos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            // 5. Registrar el cambio
            registrarCambioProducto($conn, $id, 'eliminar', ['nombre' => $producto_eliminar['nombre']]);
            
            $conn->commit();
            $_SESSION['mensaje'] = "✅ Producto '{$producto_eliminar['nombre']}' eliminado permanentemente";
            $_SESSION['tipo_mensaje'] = "exito";
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[productos_acciones eliminar_confirmado] ' . $e->getMessage());
            $_SESSION['mensaje'] = "❌ No se pudo eliminar: " . $e->getMessage();
            $_SESSION['tipo_mensaje'] = "error";
        }
    } else {
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    header('Location: /admin/stock/productos.php');
    exit;
}

// ===== PROCESAR ELIMINACIÓN DE PRODUCTO (CON VERIFICACIÓN) =====
if ($accion == 'eliminar' && $id > 0) {
    // Verificar si el producto existe
    $check = $conn->prepare("SELECT id, nombre, imagen_url, proveedor_id FROM productos WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $producto_eliminar = $check->get_result()->fetch_assoc();
    
    if ($producto_eliminar) {
        // 🔥 VERIFICAR QUE EL PRODUCTO PERTENEZCA AL PROVEEDOR
if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_filtro)) {
    $_SESSION['mensaje'] = "❌ No tienes permiso para eliminar este producto (no pertenece a tu tienda)";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: /admin/stock/productos.php');
    exit;
}
        // 🔥 ELIMINAR IMAGEN DEL SERVIDOR
        if (!empty($producto_eliminar['imagen_url'])) {
            $ruta_imagen = $_SERVER['DOCUMENT_ROOT'] . $producto_eliminar['imagen_url'];
            if (file_exists($ruta_imagen)) {
                unlink($ruta_imagen);
            }
        }

        // ===== VERIFICAR DEPENDENCIAS =====
                // 1. Verificar si está en CUALQUIER carrito (activo, pendiente o expirado)
        $stmt_carritos = $conn->prepare("SELECT cp.*, c.id as carrito_id, c.fecha_expiracion, c.estado 
                                         FROM carrito_productos cp 
                                         JOIN carritos c ON cp.carrito_id = c.id 
                                         WHERE cp.producto_id = ?");
        $stmt_carritos->bind_param("i", $id);
        $stmt_carritos->execute();
        $carritos_result = $stmt_carritos->get_result();
        $carritos = $carritos_result->num_rows;
        
        // 2. Verificar si está en pedidos (no cancelados)
        $stmt_pedidos = $conn->prepare("SELECT pd.*, p.id as pedido_id, p.estado_actual, p.fecha_pedido 
                                        FROM pedido_detalles pd 
                                        JOIN pedidos p ON pd.pedido_id = p.id 
                                        WHERE pd.producto_id = ? 
                                        AND p.estado_actual NOT IN ('cancelado', 'devuelto')");
        $stmt_pedidos->bind_param("i", $id);
        $stmt_pedidos->execute();
        $pedidos_result = $stmt_pedidos->get_result();
        $pedidos = $pedidos_result->num_rows;
        
        // 3. Verificar historial
        $historial_mov = $conn->query("SELECT COUNT(*) as total FROM historial_producto WHERE producto_id = $id")->fetch_assoc()['total'];
        $historial_cambios = $conn->query("SELECT COUNT(*) as total FROM historial_productos_cambios WHERE producto_id = $id")->fetch_assoc()['total'];
        $tiene_historial = ($historial_mov > 0 || $historial_cambios > 0);
        
        // ===== VERIFICAR SI ESTÁ EN CARRITOS O PEDIDOS =====
        if ($carritos > 0 || $pedidos > 0) {
            $mensaje_html = '<!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>No se puede eliminar</title>
                <link rel="stylesheet" href="/estilo.css">
                <style>
                    * { box-sizing: border-box; }
                    body { font-family: Arial, sans-serif; background: #f8fafc; padding: 1rem; margin: 0; }
                    .card { max-width: 600px; margin: 2rem auto; background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
                    @media (min-width: 768px) { .card { padding: 2rem; } }
                    .warning { color: #f56565; font-size: 3rem; margin-bottom: 1rem; text-align: center; }
                    h2 { color: #2d3748; margin-bottom: 1rem; text-align: center; font-size: 1.3rem; }
                    @media (min-width: 768px) { h2 { font-size: 1.5rem; } }
                    .info { background: #fef5e7; padding: 1rem; border-radius: 8px; margin: 1.5rem 0; word-break: break-word; }
                    .btn-group { display: flex; gap: 1rem; justify-content: center; margin-top: 1.5rem; flex-wrap: wrap; }
                    .btn { padding: 0.75rem 1.5rem; border-radius: 8px; text-decoration: none; font-weight: 600; transition: all 0.3s; display: inline-block; text-align: center; }
                    .btn-secondary { background: #edf2f7; color: #4a5568; }
                    .btn-secondary:hover { background: #e2e8f0; transform: translateY(-2px); }
                    ul { margin: 0.5rem 0 0 1.5rem; padding: 0; }
                    li { margin: 0.3rem 0; word-break: break-word; }
                    @media (max-width: 480px) {
                        .btn { width: 100%; }
                    }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="warning">⛔</div>
                    <h2>No se puede eliminar el producto</h2>
                    <p>El producto <strong>' . htmlspecialchars($producto_eliminar['nombre']) . '</strong> está en uso:</p>
                    <div class="info">';
            
            if ($carritos > 0) {
                $mensaje_html .= "<strong>🛒 Carritos activos ($carritos):</strong><ul>";
                $carritos_result->data_seek(0);
                while($c = $carritos_result->fetch_assoc()) {
                    $mensaje_html .= "<li>Carrito ID: {$c['carrito_id']} (expira: " . date('d/m/Y H:i', strtotime($c['fecha_expiracion'])) . ")</li>";
                }
                $mensaje_html .= "</ul>";
            }
            
            if ($pedidos > 0) {
                $mensaje_html .= "<strong>📋 Pedidos en curso ($pedidos):</strong><ul>";
                $pedidos_result->data_seek(0);
                while($p = $pedidos_result->fetch_assoc()) {
                    $mensaje_html .= "<li>Pedido #{$p['pedido_id']} - Estado: {$p['estado_actual']} - Fecha: " . date('d/m/Y', strtotime($p['fecha_pedido'])) . "</li>";
                }
                $mensaje_html .= "</ul>";
            }
            
            $mensaje_html .= '</div>
                    <div class="btn-group">
                        <a href="/admin/stock/productos.php" class="btn btn-secondary">Cancelar</a>
                    </div>
                </div>
            </body>
            </html>';
            
            echo $mensaje_html;
            exit;
        }
        
        // ===== SOLO CON HISTORIAL =====
        if ($tiene_historial) {
            // Super Admin puede eliminar
            if ($_SESSION['rol'] == 'Super Admin') {
                echo '<!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Confirmar eliminación</title>
                    <link rel="stylesheet" href="/estilo.css">
                    <style>
                        * { box-sizing: border-box; }
                        body { font-family: Arial, sans-serif; background: #f8fafc; padding: 1rem; margin: 0; }
                        .confirm-card { max-width: 500px; margin: 2rem auto; background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center; }
                        @media (min-width: 768px) { .confirm-card { padding: 2rem; } }
                        .warning { color: #f56565; font-size: 3rem; margin-bottom: 1rem; }
                        h2 { color: #2d3748; margin-bottom: 1rem; font-size: 1.3rem; }
                        @media (min-width: 768px) { h2 { font-size: 1.5rem; } }
                        p { color: #4a5568; margin-bottom: 1.5rem; line-height: 1.5; }
                        .btn-group { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
                        .btn { padding: 0.75rem 1.5rem; border-radius: 8px; text-decoration: none; font-weight: 600; transition: all 0.3s; display: inline-block; text-align: center; }
                        .btn-danger { background: #f56565; color: white; }
                        .btn-danger:hover { background: #e53e3e; transform: translateY(-2px); }
                        .btn-secondary { background: #edf2f7; color: #4a5568; }
                        .btn-secondary:hover { background: #e2e8f0; transform: translateY(-2px); }
                        .historial-info { background: #fef5e7; padding: 1rem; border-radius: 8px; margin: 1.5rem 0; text-align: left; word-break: break-word; }
                        @media (max-width: 480px) {
                            .btn { width: 100%; }
                        }
                    </style>
                </head>
                <body>
                    <div class="confirm-card">
                        <div class="warning">⚠️</div>
                        <h2>¿Eliminar permanentemente?</h2>
                        <p>El producto <strong>' . htmlspecialchars($producto_eliminar['nombre']) . '</strong> tiene registros en el historial:</p>
                        <div class="historial-info">
                            <p>📜 Movimientos de inventario: <strong>' . $historial_mov . '</strong></p>
                            <p>📝 Cambios registrados: <strong>' . $historial_cambios . '</strong></p>
                        </div>
                        <p style="color: #c53030;"><strong>Esta acción NO SE PUEDE DESHACER.</strong></p>
                        <div class="btn-group">
                            <a href="/admin/stock/productos_acciones.php?accion=eliminar_confirmado&id=' . $id . '" class="btn btn-danger">🗑️ Eliminar permanentemente</a>
                            <a href="/admin/stock/productos.php" class="btn btn-secondary">Cancelar</a>
                        </div>
                    </div>
                </body>
                </html>';
                exit;
               } else {
                   // Admin/Inventario → desactivar en lugar de eliminar
        $conn->query("UPDATE productos SET activo = 0 WHERE id = $id");
        $_SESSION['mensaje'] = "⚠️ Producto '{$producto_eliminar['nombre']}' ha sido DESACTIVADO (tiene historial). Solo Super Admin puede eliminarlo permanentemente.";
        $_SESSION['tipo_mensaje'] = "info";
        echo '<script>window.location.href = "/admin/stock/productos.php";</script>';
        exit;
    }
}
        
        // ===== SIN DEPENDENCIAS NI HISTORIAL =====
        // Verificar rol para decidir si eliminar o desactivar
        if ($_SESSION['rol'] == 'Super Admin') {
            // Eliminar imagen si existe
            if (!empty($producto_eliminar['imagen_url']) && strpos($producto_eliminar['imagen_url'], 'uploads/') === 0) {
                $ruta_imagen = __DIR__ . '/' . $producto_eliminar['imagen_url'];
                if (file_exists($ruta_imagen)) {
                    unlink($ruta_imagen);
                }
            }
            
            // Eliminar el producto
            $sql = "DELETE FROM productos WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                registrarCambioProducto($conn, $id, 'eliminar', ['nombre' => $producto_eliminar['nombre']]);
                $_SESSION['mensaje'] = "✅ Producto '{$producto_eliminar['nombre']}' eliminado permanentemente";
                $_SESSION['tipo_mensaje'] = "exito";
            } else {
                $_SESSION['mensaje'] = "❌ Error al eliminar: " . $conn->error;
                $_SESSION['tipo_mensaje'] = "error";
            }
        } else {
            // Admin/Inventario → desactivar
            $conn->query("UPDATE productos SET activo = 0 WHERE id = $id");
            $_SESSION['mensaje'] = "✅ Producto '{$producto_eliminar['nombre']}' ha sido DESACTIVADO";
            $_SESSION['tipo_mensaje'] = "exito";
        }
    } else {
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    header('Location: /admin/stock/productos.php');
    exit;
}

// ===== PROCESAR ELIMINACIÓN DE IMAGEN =====
if ($accion == 'eliminar_imagen' && $id > 0) {
    // VERIFICAR PROPIEDAD
    if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_filtro)) {
        $_SESSION['mensaje'] = "❌ No tienes permiso para modificar este producto";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: /admin/stock/productos.php');
        exit;
    }
    
    $stmt = $conn->prepare("SELECT imagen_url FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($producto && !empty($producto['imagen_url'])) {
        if (strpos($producto['imagen_url'], 'uploads/') === 0) {
            $ruta_imagen = __DIR__ . '/' . $producto['imagen_url'];
            if (file_exists($ruta_imagen)) {
                unlink($ruta_imagen);
            }
        }
        
        $stmt = $conn->prepare("UPDATE productos SET imagen_url = NULL WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $stmt->close();
            $_SESSION['mensaje'] = "✅ Imagen eliminada correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
        } else {
            $stmt->close();
            $_SESSION['mensaje'] = "❌ Error al eliminar imagen: " . $conn->error;
            $_SESSION['tipo_mensaje'] = "error";
        }
    } else {
        $_SESSION['mensaje'] = "❌ El producto no tiene imagen";
        $_SESSION['tipo_mensaje'] = "error";
    }
    
    header('Location: /admin/stock/productos_acciones.php?accion=editar&id=' . $id);
    exit;
}

// ===== OBTENER CATEGORÍAS =====
$categorias = $conn->query("SELECT * FROM categorias WHERE activo = 1 ORDER BY nombre");

// ===== OBTENER PROVEEDOR DEL USUARIO (YA TENEMOS $proveedor_id_filtro) =====
$proveedor_id_usuario = $proveedor_id_filtro;

$producto = null;
if ($accion == 'editar' && $id > 0) {
    $stmt = $conn->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $producto = $resultado->fetch_assoc();
    
    if (!$producto) {
        $_SESSION['mensaje'] = "❌ Producto no encontrado";
        $_SESSION['tipo_mensaje'] = "error";
        echo '<script>window.location.href="/admin/stock/productos.php";</script>';
        exit;
    }
    
    // 🔥 VERIFICAR QUE EL PRODUCTO PERTENEZCA AL PROVEEDOR
if (!productoPerteneceAProveedor($conn, $id, $proveedor_id_usuario)) {
    $_SESSION['mensaje'] = "❌ No tienes permiso para editar este producto (no pertenece a tu tienda)";
    $_SESSION['tipo_mensaje'] = "error";
    header('Location: /admin/stock/productos.php');
    exit;
}
}

// ===== PROCESAR GUARDADO (CREAR O EDITAR) =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar'])) {
    
    // Si es editar, verificar propiedad ANTES de cualquier cambio
    if ($accion == 'editar' && isset($_POST['id'])) {
        $id_editar = intval($_POST['id']);
        if (!productoPerteneceAProveedor($conn, $id_editar, $proveedor_id_filtro)) {
            $_SESSION['mensaje'] = "❌ No tienes permiso para editar este producto (no pertenece a tu tienda)";
            $_SESSION['tipo_mensaje'] = "error";
            header('Location: /admin/stock/productos.php');
            exit;
        }
    }
    
    $nombre = trim($_POST['nombre']);
    $descripcion = trim($_POST['descripcion']);
    $marca = trim($_POST['marca'] ?? '');
    $peso = floatval($_POST['peso'] ?? 0);
    $cantidad = intval($_POST['cantidad']);
    $precio_costo = floatval($_POST['precio_costo']);
    $precio_venta = floatval($_POST['precio_venta']);
    $porcentaje_rebaja = intval($_POST['porcentaje_rebaja'] ?? 0);
    $categoria_id = !empty($_POST['categoria_id']) ? intval($_POST['categoria_id']) : null;
    $eliminar_imagen = isset($_POST['eliminar_imagen']) ? true : false;
    
    // Validar que el precio final no sea menor al precio de costo
    $precio_final = $precio_venta;
    if ($porcentaje_rebaja > 0) {
        $precio_final = $precio_venta * (100 - $porcentaje_rebaja) / 100;
    }
    
    $errores = [];
    if (empty($nombre)) $errores[] = "El nombre es obligatorio";
    if (empty($descripcion)) $errores[] = "La descripción es obligatoria";
    if ($cantidad < 0) $errores[] = "La cantidad no puede ser negativa";
    if ($precio_costo < 0) $errores[] = "El precio de costo no puede ser negativo";
    if ($precio_venta <= 0) $errores[] = "El precio de venta debe ser mayor a 0";
    if ($precio_final < $precio_costo) {
        $errores[] = "El precio final con rebaja ($" . number_format($precio_final, 2) . ") no puede ser menor al precio de costo ($" . number_format($precio_costo, 2) . ")";
    }
    if ($peso < 0) $errores[] = "El peso no puede ser negativo";
    if ($porcentaje_rebaja < 0 || $porcentaje_rebaja > 100) $errores[] = "El porcentaje de rebaja debe estar entre 0 y 100";
    
    $imagen_url = $producto['imagen_url'] ?? '';
    
    if ($eliminar_imagen && $accion == 'editar') {
        if (!empty($producto['imagen_url']) && strpos($producto['imagen_url'], 'uploads/') === 0) {
            $ruta_imagen = __DIR__ . '/' . $producto['imagen_url'];
            if (file_exists($ruta_imagen)) {
                unlink($ruta_imagen);
            }
        }
        $imagen_url = null;
    }
    
    if (isset($_FILES['imagen_archivo']) && $_FILES['imagen_archivo']['error'] == 0) {
        $target_dir = $_SERVER['DOCUMENT_ROOT'] . "/uploads/productos/";
        
        if ($accion == 'editar' && !empty($producto['imagen_url']) && strpos($producto['imagen_url'], 'uploads/') === 0) {
            $ruta_anterior = __DIR__ . '/' . $producto['imagen_url'];
            if (file_exists($ruta_anterior)) {
                unlink($ruta_anterior);
            }
        }
        
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $extension = strtolower(pathinfo($_FILES["imagen_archivo"]["name"], PATHINFO_EXTENSION));
        $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (!in_array($extension, $extensiones_permitidas)) {
            $errores[] = "Solo se permiten imágenes JPG, JPEG, PNG, GIF o WEBP";
        } elseif ($_FILES["imagen_archivo"]["size"] > 2 * 1024 * 1024) {
            $errores[] = "La imagen no debe pesar más de 2MB";
        } else {
            $check = getimagesize($_FILES["imagen_archivo"]["tmp_name"]);
            if ($check !== false) {
                $nombre_unico = time() . '_' . uniqid() . '.' . $extension;
                $target_file = $target_dir . $nombre_unico;
                
                if (move_uploaded_file($_FILES["imagen_archivo"]["tmp_name"], $target_file)) {
                    $imagen_url = "/uploads/productos/" . $nombre_unico;
                } else {
                    $errores[] = "Error al subir la imagen";
                }
            } else {
                $errores[] = "El archivo no es una imagen válida";
            }
        }
   } elseif (!empty($_POST['imagen_url']) && !$eliminar_imagen) {
    $imagen_url = trim($_POST['imagen_url']);
    // Validar si es una URL completa
    if (filter_var($imagen_url, FILTER_VALIDATE_URL)) {
        // Es una URL completa, válida
    } 
    // Validar si es una ruta relativa que empieza con /
    elseif (preg_match('/^\/[a-zA-Z0-9\/_\-\.]+\.(jpg|jpeg|png|gif|webp|svg)$/i', $imagen_url)) {
        // Es una ruta relativa válida
    } 
    else {
        $errores[] = "La URL o ruta de la imagen no es válida. Debe ser una URL completa (https://...) o una ruta que empiece con / (ej: /uploads/logo.png)";
    }
} elseif ($accion == 'crear' && empty($imagen_url) && !$eliminar_imagen) {
    $errores[] = "Debes subir una imagen o proporcionar una URL";
}
    
    if (!empty($errores)) {
        $mensaje = "❌ " . implode("<br>❌ ", $errores);
        $tipo_mensaje = "error";
    } else {

    if ($accion == 'crear') {
    // ===== ASIGNAR PROVEEDOR =====
    // Si el usuario es de tienda, usar su proveedor. Si es global (Super Admin/Gerente), null.
    $proveedor_id = $proveedor_id_filtro > 0 ? $proveedor_id_filtro : null;

    $sql = "INSERT INTO productos (nombre, descripcion, marca, peso, cantidad, precio_costo, precio, porcentaje_rebaja, precio_original, imagen_url, categoria_id, precio_adquisicion_mn, proveedor_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $precio_original = $porcentaje_rebaja > 0 ? $precio_venta : null;
    $precio_final = $porcentaje_rebaja > 0 ? $precio_venta * (100 - $porcentaje_rebaja) / 100 : $precio_venta;
    $precio_adquisicion_mn = isset($_POST['precio_adquisicion_mn']) ? floatval($_POST['precio_adquisicion_mn']) : 0;
$precio_original_param = $precio_original ?? 0;
$categoria_id_param = $categoria_id ?? 0;
$proveedor_id_param = $proveedor_id ?? 0;
$stmt->bind_param("sssdiddidsisdi", $nombre, $descripcion, $marca, $peso, $cantidad, $precio_costo, $precio_final, $porcentaje_rebaja, $precio_original_param, $imagen_url, $categoria_id_param, $precio_adquisicion_mn, $proveedor_id_param);
    $mensaje_exito = "creado";

} else {
    $sql = "UPDATE productos SET 
            nombre=?, descripcion=?, marca=?, peso=?, cantidad=?, precio_costo=?, 
            precio=?, porcentaje_rebaja=?, precio_original=?, imagen_url=?, categoria_id=?, precio_adquisicion_mn=? 
            WHERE id=?";
    $stmt = $conn->prepare($sql);
    $precio_original = $porcentaje_rebaja > 0 ? $precio_venta : null;
    $precio_final = $porcentaje_rebaja > 0 ? $precio_venta * (100 - $porcentaje_rebaja) / 100 : $precio_venta;
    $precio_adquisicion_mn = isset($_POST['precio_adquisicion_mn']) ? floatval($_POST['precio_adquisicion_mn']) : 0;
        $id_editar_post = intval($_POST['id']);
 $precio_original_param = $precio_original ?? 0;
$categoria_id_param = $categoria_id ?? 0;
error_log('bind_param editar: ' . print_r([
    'nombre' => $nombre,
    'descripcion' => $descripcion,
    'marca' => $marca,
    'peso' => $peso,
    'cantidad' => $cantidad,
    'precio_costo' => $precio_costo,
    'precio_final' => $precio_final,
    'porcentaje_rebaja' => $porcentaje_rebaja,
    'precio_original_param' => $precio_original_param,
    'imagen_url' => $imagen_url,
    'categoria_id_param' => $categoria_id_param,
    'precio_adquisicion_mn' => $precio_adquisicion_mn,
    'id_editar_post' => $id_editar_post
], true));

$stmt->bind_param("sssdiddidsisdi", $nombre, $descripcion, $marca, $peso, $cantidad, $precio_costo, $precio_final, $porcentaje_rebaja, $precio_original_param, $imagen_url, $categoria_id_param, $precio_adquisicion_mn, $id_editar_post);
    $mensaje_exito = "actualizado";
}
        
               if ($stmt->execute()) {
            
            // Si la cantidad es mayor que 0, limpiar fecha_agotado (solo en editar)
            if ($cantidad > 0 && $accion == 'editar' && !empty($_POST['id'])) {
                $id_para_agotado = intval($_POST['id']);
                $stmt_agotado = $conn->prepare("UPDATE productos SET fecha_agotado = NULL WHERE id = ?");
                $stmt_agotado->bind_param("i", $id_para_agotado);
                $stmt_agotado->execute();
                $stmt_agotado->close();
            }
            // Registrar según la acción
            if ($accion == 'crear') {
                $nuevo_id = $conn->insert_id;
                $cambios = [
                    'nombre' => $nombre,
                    'descripcion' => $descripcion,
                    'marca' => $marca,
                    'peso' => $peso,
                    'cantidad' => $cantidad,
                    'precio_costo' => $precio_costo,
                    'precio_venta' => $precio_venta,
                    'porcentaje_rebaja' => $porcentaje_rebaja,
                    'categoria_id' => $categoria_id,
                    'imagen_url' => $imagen_url
                ];
                registrarCambioProducto($conn, $nuevo_id, 'crear', $cambios);
            } else {
                // Edición: comparar cambios
                $cambios = [];
                $campos_comparar = [
                    'nombre' => 'nombre',
                    'descripcion' => 'descripcion',
                    'marca' => 'marca',
                    'peso' => 'peso',
                    'cantidad' => 'cantidad',
                    'precio_costo' => 'precio_costo',
                    'precio' => 'precio_venta',
                    'porcentaje_rebaja' => 'porcentaje_rebaja',
                    'categoria_id' => 'categoria_id',
                    'imagen_url' => 'imagen_url'
                ];
                
                foreach ($campos_comparar as $campo_bd => $campo_post) {
                    $valor_anterior = $producto[$campo_bd] ?? '';
                    $valor_nuevo = $$campo_post ?? '';
                    
                    if (is_numeric($valor_anterior)) $valor_anterior = (string)$valor_anterior;
                    if (is_numeric($valor_nuevo)) $valor_nuevo = (string)$valor_nuevo;
                    
                    if (empty($valor_anterior) && empty($valor_nuevo)) continue;
                    
                    if ($valor_anterior != $valor_nuevo) {
                        $cambios[$campo_bd] = [
                            'antes' => $valor_anterior,
                            'despues' => $valor_nuevo
                        ];
                    }
                }
                
                if (!empty($cambios)) {
                    registrarCambioProducto($conn, $_POST['id'], 'editar', $cambios);
                }
            }
            
            // ===== ACTUALIZAR COMBOS QUE USAN ESTE PRODUCTO =====
if ($accion == 'crear' || $accion == 'editar') {
    $producto_id_actual = $accion == 'crear' ? intval($nuevo_id) : intval($_POST['id']);
    
    // Incluir el archivo de actualización (ruta corregida)
    $ruta_combos = __DIR__ . '/actualizar_precio_combos.php';
    if (file_exists($ruta_combos)) {
        include_once $ruta_combos;
        if (function_exists('actualizarCombosPorProducto')) {
            $resultado = actualizarCombosPorProducto($conn, $producto_id_actual, $proveedor_id_filtro);
        }
    }
}
            
                        $_SESSION['mensaje'] = "✅ Producto '{$nombre}' {$mensaje_exito} correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
            
            header('Location: /admin/stock/productos.php');
            exit;
        } else {
            $_SESSION['mensaje'] = "❌ Error al guardar: " . $conn->error;
            $_SESSION['tipo_mensaje'] = "error";
            
            header('Location: /admin/stock/productos.php');
            exit;
        }
    }
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}
?>
<!-- ============================================ -->
<!-- CONTENIDO PRINCIPAL (SIN HTML PROPIO)        -->
<!-- ============================================ -->
<div class="container">
    <div class="card">
        <h2><?php echo $accion == 'crear' ? '➕ Crear Nuevo Producto' : '✏️ Editar Producto'; ?></h2>
        
        <?php if ($mensaje): ?>
            <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data" class="form-admin" id="formProducto">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="guardar" value="1">
    <input type="hidden" name="accion" value="<?php echo $accion; ?>">
            <?php if ($accion == 'editar'): ?>
                <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">
            <?php endif; ?>
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="nombre">📝 Nombre del Producto *</label>
                    <input type="text" id="nombre" name="nombre" required 
                           value="<?php echo htmlspecialchars($_POST['nombre'] ?? ($producto['nombre'] ?? '')); ?>">
                </div>
                
                <div class="form-group">
                    <label for="categoria_id">📌 Categoría</label>
                    <select id="categoria_id" name="categoria_id">
                        <option value="">-- Sin categoría --</option>
                        <?php 
                        $categorias->data_seek(0);
                        while($cat = $categorias->fetch_assoc()): 
                            $selected = false;
                            if (isset($_POST['categoria_id']) && $_POST['categoria_id'] == $cat['id']) $selected = true;
                            elseif (isset($producto['categoria_id']) && $producto['categoria_id'] == $cat['id']) $selected = true;
                        ?>
                            <option value="<?php echo $cat['id']; ?>" <?php echo $selected ? 'selected' : ''; ?>>
                                <?php echo $cat['icono']; ?> <?php echo htmlspecialchars($cat['nombre']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label for="descripcion">📄 Descripción *</label>
                <textarea id="descripcion" name="descripcion" required rows="4"><?php echo htmlspecialchars($_POST['descripcion'] ?? ($producto['descripcion'] ?? '')); ?></textarea>
            </div>
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="cantidad">🔢 Cantidad en Stock *</label>
                    <input type="number" id="cantidad" name="cantidad" min="0" required
                           value="<?php echo htmlspecialchars($_POST['cantidad'] ?? ($producto['cantidad'] ?? 0)); ?>">
                </div>
                
                <div class="form-group">
                    <label for="marca">🏷️ Marca</label>
                    <input type="text" id="marca" name="marca" 
                           value="<?php echo htmlspecialchars($_POST['marca'] ?? ($producto['marca'] ?? '')); ?>"
                           placeholder="Ej: Coca-Cola, Nestlé, etc.">
                </div>
                
                <div class="form-group">
                    <label for="peso">⚖️ Peso (kg)</label>
                    <input type="number" id="peso" name="peso" step="0.001" min="0" 
                           value="<?php echo htmlspecialchars($_POST['peso'] ?? ($producto['peso'] ?? 0)); ?>"
                           placeholder="0.000">
                    <small class="campo-opcional">Peso en kilogramos (ej: 0.500 = 500g)</small>
                </div>
            </div>

<div class="form-grid">
    <div class="form-group">
        <label for="proveedor_id">🏪 Proveedor</label>
        <input type="text" id="proveedor_id" name="proveedor_id" 
               value="<?php 
                   $proveedor_nombre_tmp = '';
                   if ($accion == 'crear') {
                       $proveedor_id_tmp = intval($proveedor_id_filtro ?? 0);
                       if ($proveedor_id_tmp > 0) {
                           $stmt_prov = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                           $stmt_prov->bind_param("i", $proveedor_id_tmp);
                           $stmt_prov->execute();
                           $result_prov = $stmt_prov->get_result();
                           $prov_tmp = $result_prov->fetch_assoc();
                           $stmt_prov->close();
                           $proveedor_nombre_tmp = $prov_tmp ? $prov_tmp['nombre_tienda'] : 'Sin proveedor';
                       } else {
                           $proveedor_nombre_tmp = 'Sin proveedor (admin global)';
                       }
                   } elseif ($accion == 'editar') {
                       $proveedor_id_tmp = intval($producto['proveedor_id'] ?? 0);
                       if ($proveedor_id_tmp > 0) {
                           $stmt_prov = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
                           $stmt_prov->bind_param("i", $proveedor_id_tmp);
                           $stmt_prov->execute();
                           $result_prov = $stmt_prov->get_result();
                           $prov_tmp = $result_prov->fetch_assoc();
                           $stmt_prov->close();
                           $proveedor_nombre_tmp = $prov_tmp ? $prov_tmp['nombre_tienda'] : 'Sin proveedor';
                       } else {
                           $proveedor_nombre_tmp = 'Sin proveedor';
                       }
                   } else {
                       $proveedor_nombre_tmp = 'Sin proveedor';
                   }
                   echo htmlspecialchars($proveedor_nombre_tmp);
               ?>" 
               readonly 
               style="background: #f7fafc; cursor: not-allowed; width: 100%; padding: 0.7rem; border: 1px solid #e2e8f0; border-radius: 8px;">
        <small style="color: #718096; font-size: 0.7rem;">El proveedor se asigna automáticamente según tu usuario.</small>
    </div>
</div>
         
            <div class="form-grid">
                <div class="form-group">
                    <label for="precio_costo">💰 Precio de Costo *</label>
                    <input type="number" id="precio_costo" name="precio_costo" step="0.01" min="0" required
                           value="<?php echo htmlspecialchars($_POST['precio_costo'] ?? ($producto['precio_costo'] ?? 0.00)); ?>">
                </div>
                
                <div class="form-group">
                    <label for="precio_adquisicion_mn">💵 Precio Adquisición (MN)</label>
                    <input type="number" id="precio_adquisicion_mn" name="precio_adquisicion_mn" step="0.01" min="0" 
                           value="<?php echo htmlspecialchars($_POST['precio_adquisicion_mn'] ?? ($producto['precio_adquisicion_mn'] ?? '')); ?>">
                    <small class="campo-opcional">Precio de compra en pesos cubanos (CUP)</small>
                </div>
                
                <div class="form-group">
                    <label for="precio_venta">💵 Precio de Venta *</label>
                    <input type="number" id="precio_venta" name="precio_venta" step="0.01" min="0" required
                           value="<?php echo htmlspecialchars($_POST['precio_venta'] ?? ($producto['precio'] ?? 0.00)); ?>"
                           onchange="calcularPrecioFinal()">
                </div>
                
                <div class="form-group">
                    <label for="porcentaje_rebaja">🏷️ % Rebaja</label>
                    <input type="number" id="porcentaje_rebaja" name="porcentaje_rebaja" step="1" min="0" max="100" 
                           value="<?php echo htmlspecialchars($_POST['porcentaje_rebaja'] ?? ($producto['porcentaje_rebaja'] ?? 0)); ?>"
                           onchange="calcularPrecioFinal()">
                    <small class="campo-opcional">0 = sin rebaja. El precio final se calculará automáticamente</small>
                </div>
            </div>
            
            <div class="info-rebaja" id="infoRebaja">
                <p style="margin: 0;">
                    <strong>📊 Información de rebaja:</strong><br>
                    Precio original: <span id="precio_original_mostrar">$0.00</span><br>
                    Precio final con rebaja: <span id="precio_final_mostrar">$0.00</span>
                </p>
            </div>
            
            <div class="seccion-imagen">
                <h3>🖼️ Imagen del Producto</h3>
                
                <?php if ($accion == 'editar' && !empty($producto['imagen_url'])): ?>
                <div class="eliminar-imagen-container">
                    <label>
                        <input type="checkbox" name="eliminar_imagen" value="1"> 
                        <span>Eliminar imagen actual</span>
                    </label>
                    <small style="color: #856404; display: block; margin-top: 0.25rem;">Si marcas esta opción, la imagen se eliminará.</small>
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="imagen_archivo">📁 Subir imagen desde tu PC:</label>
                    <input type="file" id="imagen_archivo" name="imagen_archivo" accept="image/*" onchange="previewFile()">
                    <div class="campo-opcional">Máximo 2MB. Formatos: JPG, PNG, GIF, WEBP</div>
                </div>
                
                <div class="separador-o">— O —</div>
                
                <div class="form-group">
                    <label for="imagen_url">🌐 URL o ruta de la imagen:</label>
                    <input type="text" id="imagen_url" name="imagen_url" 
                           value="<?php 
                           if (!empty($_POST['imagen_url'])) {
                               echo htmlspecialchars($_POST['imagen_url']);
                           } elseif (!empty($producto['imagen_url']) && strpos($producto['imagen_url'], 'uploads/') !== 0) {
                               echo htmlspecialchars($producto['imagen_url']);
                           }
                           ?>" placeholder="https://ejemplo.com/imagen.jpg  o  /uploads/logo.png" onchange="previewURL()">
                    <small class="campo-opcional">Puedes usar una URL completa (https://...) o una ruta local que empiece con / (ej: /uploads/logo.png)</small>
                </div>
                
                <div style="text-align: center; margin-top: 1rem;">
    <p><strong>Vista previa:</strong></p>
    <img id="preview" class="preview-imagen <?php echo (!empty($producto['imagen_url']) || !empty($_POST['imagen_url'])) ? 'visible' : ''; ?>" 
         style="max-width: 120px; max-height: 120px; object-fit: contain;"
         src="<?php 
             if (!empty($_POST['imagen_url'])) {
                 echo htmlspecialchars($_POST['imagen_url']);
             } elseif (!empty($producto['imagen_url'])) {
                 echo htmlspecialchars($producto['imagen_url']);
             }
         ?>" 
         alt="Vista previa" 
         onerror="this.style.display='none'">
</div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <?php echo $accion == 'crear' ? '✨ Crear Producto' : '💾 Actualizar Producto'; ?>
                </button>
                <a href="/admin/stock/productos.php" class="btn btn-secondary">↩️ Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
    function previewFile() {
        const preview = document.getElementById('preview');
        const file = document.getElementById('imagen_archivo').files[0];
        const reader = new FileReader();
        reader.onloadend = function() {
            preview.src = reader.result;
            preview.classList.add('visible');
        }
        if (file) reader.readAsDataURL(file);
    }
    
    function previewURL() {
        const preview = document.getElementById('preview');
        const url = document.getElementById('imagen_url').value;
        if (url) {
            preview.src = url;
            preview.classList.add('visible');
        }
    }
    
    function calcularPrecioFinal() {
        const precioVenta = parseFloat(document.getElementById('precio_venta').value) || 0;
        const porcentaje = parseInt(document.getElementById('porcentaje_rebaja').value) || 0;
        const infoDiv = document.getElementById('infoRebaja');
        
        if (porcentaje > 0 && precioVenta > 0) {
            const precioFinal = precioVenta * (100 - porcentaje) / 100;
            document.getElementById('precio_original_mostrar').innerHTML = '$' + precioVenta.toFixed(2);
            document.getElementById('precio_final_mostrar').innerHTML = '$' + precioFinal.toFixed(2);
            infoDiv.classList.add('show');
            
            const precioCosto = parseFloat(document.getElementById('precio_costo').value) || 0;
            if (precioFinal < precioCosto) {
                infoDiv.style.borderLeft = '4px solid #f56565';
                infoDiv.style.background = '#fed7d7';
            } else {
                infoDiv.style.borderLeft = '4px solid #ecc94b';
                infoDiv.style.background = '#fef5e7';
            }
        } else {
            infoDiv.classList.remove('show');
        }
    }
    
    document.getElementById('formProducto').addEventListener('submit', function(e) {
        const archivo = document.getElementById('imagen_archivo').files[0];
        const url = document.getElementById('imagen_url').value;
        <?php if ($accion == 'crear'): ?>
        if (!archivo && !url) {
            e.preventDefault();
            alert('❌ Debes subir una imagen o proporcionar una URL');
        }
        <?php endif; ?>
        
        const precioCosto = parseFloat(document.getElementById('precio_costo').value) || 0;
        const precioVenta = parseFloat(document.getElementById('precio_venta').value) || 0;
        const porcentaje = parseInt(document.getElementById('porcentaje_rebaja').value) || 0;
        const precioFinal = porcentaje > 0 ? precioVenta * (100 - porcentaje) / 100 : precioVenta;
        
        if (precioFinal < precioCosto) {
            e.preventDefault();
            alert('❌ El precio final con rebaja ($' + precioFinal.toFixed(2) + ') no puede ser menor al precio de costo ($' + precioCosto.toFixed(2) + ')');
        }
    });
    
    window.onload = function() {
        const preview = document.getElementById('preview');
        if (preview.src && preview.src !== window.location.href) {
            preview.classList.add('visible');
        }
        calcularPrecioFinal();
    }
</script>

<?php
ob_end_flush();
$conn->close();
?>
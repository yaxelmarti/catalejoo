<?php
/**
 * Archivo: /admin/stock/actualizar_precio_combos.php
 * Función: Actualiza precio, costo, precio_final y stock_calculado
 *          de los combos que usan un producto específico.
 *
 * REGLA DE ORO:
 *   - Solo se actualizan los combos del MISMO proveedor que el producto.
 *   - Si el producto no tiene proveedor (proveedor_id = 0/NULL),
 *     solo se actualizan combos sin proveedor (globales).
 *   - Super Admin: se respeta el proveedor del producto (no "todos").
 */

require_once __DIR__ . '/../../includes/proveedor_utils.php';

function actualizarCombosPorProducto($conn, $producto_id, $proveedor_id_usuario = 0) {
    $producto_id = intval($producto_id);

    if ($producto_id <= 0) {
        return [
            'success' => false,
            'message' => 'ID de producto inválido',
            'combos_actualizados' => 0
        ];
    }

    // ============================================
    // VERIFICAR QUE EL PRODUCTO EXISTE Y OBTENER SU PROVEEDOR
    // ============================================
    $stmt_prod = $conn->prepare("SELECT id, proveedor_id FROM productos WHERE id = ?");
    $stmt_prod->bind_param("i", $producto_id);
    $stmt_prod->execute();
    $row_prod = $stmt_prod->get_result()->fetch_assoc();
    $stmt_prod->close();

    if (!$row_prod) {
        return [
            'success' => false,
            'message' => 'El producto no existe',
            'combos_actualizados' => 0
        ];
    }

    $proveedor_id_producto = intval($row_prod['proveedor_id'] ?? 0);

    // ============================================
    // BUSCAR COMBOS QUE USAN ESTE PRODUCTO
    // FILTRANDO POR EL PROVEEDOR DEL PRODUCTO
    // ============================================
    if ($proveedor_id_producto > 0) {
        // Producto con proveedor → solo combos del mismo proveedor
        $sql_buscar = "SELECT DISTINCT cp.combo_id
                       FROM combo_productos cp
                       INNER JOIN combos c ON cp.combo_id = c.id
                       WHERE cp.producto_id = ?
                         AND c.proveedor_id = ?";
        $stmt_buscar = $conn->prepare($sql_buscar);
        $stmt_buscar->bind_param("ii", $producto_id, $proveedor_id_producto);
    } else {
        // Producto sin proveedor → solo combos sin proveedor (globales)
        $sql_buscar = "SELECT DISTINCT cp.combo_id
                       FROM combo_productos cp
                       INNER JOIN combos c ON cp.combo_id = c.id
                       WHERE cp.producto_id = ?
                         AND (c.proveedor_id IS NULL OR c.proveedor_id = 0)";
        $stmt_buscar = $conn->prepare($sql_buscar);
        $stmt_buscar->bind_param("i", $producto_id);
    }

    if (!$stmt_buscar) {
        error_log('[actualizar_precio_combos] Error prepare buscar: ' . $conn->error);
        return [
            'success' => false,
            'message' => 'Error al preparar búsqueda de combos',
            'combos_actualizados' => 0
        ];
    }

    $stmt_buscar->execute();
    $combos_result = $stmt_buscar->get_result();

    if ($combos_result->num_rows === 0) {
        $stmt_buscar->close();
        return [
            'success' => true,
            'message' => 'El producto no está en ningún combo de su proveedor',
            'combos_actualizados' => 0
        ];
    }

    // ============================================
    // RECOGER IDs DE COMBOS (ya vienen filtrados por proveedor)
    // ============================================
    $combos_validos = [];
    while ($combo_row = $combos_result->fetch_assoc()) {
        $combos_validos[] = intval($combo_row['combo_id']);
    }
    $stmt_buscar->close();

    if (empty($combos_validos)) {
        return [
            'success' => true,
            'message' => 'No hay combos del proveedor que usen este producto',
            'combos_actualizados' => 0
        ];
    }

    // ============================================
    // ACTUALIZAR CADA COMBO (en transacción)
    // ============================================
    $combos_actualizados = 0;
    $fecha_actual = date('Y-m-d H:i:s');

    $conn->begin_transaction();

    try {
        foreach ($combos_validos as $combo_id) {
            // ----------------------------------------
            // 1. Calcular nuevo precio, costo y precio_final
            // ----------------------------------------
            $sql_calcular = "SELECT
                    COALESCE(SUM(cp.cantidad * p.precio), 0) AS total_precio,
                    COALESCE(SUM(cp.cantidad * COALESCE(NULLIF(p.precio_original, 0), p.precio)), 0) AS total_precio_base,
                    COALESCE(SUM(cp.cantidad * p.precio_costo), 0) AS total_costo,
                    COALESCE(SUM(CASE WHEN p.porcentaje_rebaja > 0 AND COALESCE(NULLIF(p.precio_original, 0), p.precio) > p.precio THEN p.porcentaje_rebaja ELSE 0 END), 0) AS suma_porc,
                    COALESCE(SUM(CASE WHEN p.porcentaje_rebaja > 0 AND COALESCE(NULLIF(p.precio_original, 0), p.precio) > p.precio THEN 1 ELSE 0 END), 0) AS count_con_rebaja
                 FROM combo_productos cp
                 INNER JOIN productos p ON cp.producto_id = p.id
                 WHERE cp.combo_id = ?
                   AND p.activo = 1
                   AND cp.cantidad > 0";
            $stmt_calcular = $conn->prepare($sql_calcular);

            if (!$stmt_calcular) {
                throw new Exception("Error prepare calcular combo {$combo_id}: " . $conn->error);
            }

            $stmt_calcular->bind_param("i", $combo_id);
            $stmt_calcular->execute();
            $row_calcular = $stmt_calcular->get_result()->fetch_assoc();
            $stmt_calcular->close();

            $nuevo_precio_final = round(floatval($row_calcular['total_precio'] ?? 0), 2);       // actual (ya rebajado)
            $nuevo_precio_tachado = round(floatval($row_calcular['total_precio_base'] ?? 0), 2); // tachado
            $nuevo_costo = round(floatval($row_calcular['total_costo'] ?? 0), 2);

            $suma_porc = floatval($row_calcular['suma_porc'] ?? 0);
            $count_con_rebaja = intval($row_calcular['count_con_rebaja'] ?? 0);
            $nuevo_porcentaje_rebaja = ($count_con_rebaja > 0)
                ? (int) round($suma_porc / $count_con_rebaja)
                : 0;

            $nuevo_precio = $nuevo_precio_tachado;   // precio = tachado

            // ----------------------------------------
            // 2. Calcular stock_calculado del combo
            //    stock_disponible = cantidad - reservado_por_combos
            //    stock_calculado = min(floor(stock_disponible / cantidad_por_combo))
            // ----------------------------------------
            $stmt_productos = $conn->prepare("
                SELECT cp.cantidad, p.cantidad AS stock_total, p.reservado_por_combos
                FROM combo_productos cp
                INNER JOIN productos p ON cp.producto_id = p.id
                WHERE cp.combo_id = ?
                  AND p.activo = 1
                  AND cp.cantidad > 0
            ");

            if (!$stmt_productos) {
                throw new Exception("Error prepare productos combo {$combo_id}: " . $conn->error);
            }

            $stmt_productos->bind_param("i", $combo_id);
            $stmt_productos->execute();
            $res_productos = $stmt_productos->get_result();

            $stock_calculado = PHP_INT_MAX;
            $tiene_productos = false;

            while ($prod = $res_productos->fetch_assoc()) {
                $tiene_productos = true;

                $stock_total = intval($prod['stock_total']);
                $reservado = intval($prod['reservado_por_combos']);
                $stock_disponible = $stock_total - $reservado;

                if ($stock_disponible < 0) {
                    $stock_disponible = 0;
                }

                $cantidad_combo = intval($prod['cantidad']);
                if ($cantidad_combo <= 0) {
                    continue;
                }

                $combos_posibles = (int) floor($stock_disponible / $cantidad_combo);

                if ($combos_posibles < $stock_calculado) {
                    $stock_calculado = $combos_posibles;
                }
            }
            $stmt_productos->close();

            if (!$tiene_productos || $stock_calculado === PHP_INT_MAX) {
                $stock_calculado = 0;
            }

            $stock_calculado = max(0, intval($stock_calculado));

            // ----------------------------------------
            // 3. Actualizar combo
            // ----------------------------------------
            $sql_update = "UPDATE combos SET
                    precio = ?,
                    precio_final = ?,
                    porcentaje_rebaja = ?,
                    costo = ?,
                    stock_calculado = ?,
                    fecha_actualizacion_stock = ?
               WHERE id = ?";
            $stmt_update = $conn->prepare($sql_update);

            if (!$stmt_update) {
                throw new Exception("Error prepare update combo {$combo_id}: " . $conn->error);
            }

            $stmt_update->bind_param(
    "ddidisi", 
    $nuevo_precio,
    $nuevo_precio_final,
    $nuevo_porcentaje_rebaja,
    $nuevo_costo,
    $stock_calculado,
    $fecha_actual,
    $combo_id
);

            if (!$stmt_update->execute()) {
                $err = $stmt_update->error;
                $stmt_update->close();
                throw new Exception("Error execute update combo {$combo_id}: " . $err);
            }

            $stmt_update->close();
            $combos_actualizados++;
        }

        $conn->commit();

        error_log("[actualizar_precio_combos] OK producto={$producto_id} proveedor={$proveedor_id_producto} combos={$combos_actualizados}");

        return [
            'success' => true,
            'message' => "Se actualizaron {$combos_actualizados} combo(s)",
            'combos_actualizados' => $combos_actualizados
        ];

    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[actualizar_precio_combos] Error: ' . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Error al actualizar combos: ' . $e->getMessage(),
            'combos_actualizados' => 0
        ];
    }
}
?>
<?php
// ============================================
// IMPORTAR PRODUCTOS — FRAGMENTO PARA MODAL
// Este archivo se incluye dentro de productos.php
// NO debe tener header.php ni footer.php
// ============================================

// Detectar proveedor (las variables ya vienen de productos.php)
if (!isset($conn)) {
    require_once __DIR__ . '/../../conexion.php';
}
if (!function_exists('obtenerProveedorId')) {
    require_once __DIR__ . '/../../includes/proveedor_utils.php';
}
if (!function_exists('csrf_field')) {
    require_once __DIR__ . '/../../includes/csrf.php';
}

$proveedor_id_usuario = obtenerProveedorId($conn, $_SESSION['usuario_id'], $_SESSION['rol'] ?? '');
$es_proveedor = esRolProveedor($_SESSION['rol'] ?? '');

$mensaje = '';
$tipo_mensaje = '';

// ============================================
// PROCESAR IMPORTACIÓN
// ============================================
if (isset($_POST['importar']) && isset($_FILES['csv_file'])) {

    // Validar CSRF
    if (!function_exists('csrf_validar') || !csrf_validar($_POST['csrf_token'] ?? '')) {
        $mensaje = '❌ Token de seguridad inválido. Recarga la página e intenta de nuevo.';
        $tipo_mensaje = 'error';
    } else {

        $archivo = $_FILES['csv_file']['tmp_name'];
        $contador = 0;
        $errores = [];

        if (($handle = fopen($archivo, "r")) !== FALSE) {
            // Leer primera fila (encabezados)
            $cabeceras = fgetcsv($handle, 1000, ",");

            // Procesar cada fila
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {

                if (count($data) < 6) {
                    $errores[] = "Fila " . ($contador + 2) . ": Datos incompletos";
                    continue;
                }

                $nombre = trim($data[0]);
                $descripcion = trim($data[1]);
                $precio = floatval($data[2]);
                $categoria_id = intval($data[3]);
                $nombre_imagen = trim($data[4]);
                $cantidad = intval($data[5]);

                if (empty($nombre)) {
                    $errores[] = "Fila " . ($contador + 2) . ": Nombre vacío";
                    continue;
                }

                if ($precio <= 0) {
                    $errores[] = "Fila " . ($contador + 2) . ": Precio inválido ($precio)";
                    continue;
                }

                // Validar categoría
                $stmt_cat = $conn->prepare("SELECT id FROM categorias WHERE id = ?");
                $stmt_cat->bind_param("i", $categoria_id);
                $stmt_cat->execute();
                $check_cat = $stmt_cat->get_result();
                if ($check_cat->num_rows == 0) {
                    $errores[] = "Fila " . ($contador + 2) . ": Categoría $categoria_id no existe";
                    $stmt_cat->close();
                    continue;
                }
                $stmt_cat->close();

                // Construir ruta de imagen
                $imagen_url = '';
                if (!empty($nombre_imagen)) {
                    $ruta_imagen = __DIR__ . "/../../uploads/productos/" . $nombre_imagen;
                    if (file_exists($ruta_imagen)) {
                        $imagen_url = "/uploads/productos/" . $nombre_imagen;
                    } else {
                        $errores[] = "Fila " . ($contador + 2) . ": Imagen no encontrada ($nombre_imagen)";
                        continue;
                    }
                }

                // Insertar producto
                $stmt = $conn->prepare("INSERT INTO productos 
                    (nombre, descripcion, precio, categoria_id, imagen_url, cantidad, proveedor_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdisii",
                    $nombre,
                    $descripcion,
                    $precio,
                    $categoria_id,
                    $imagen_url,
                    $cantidad,
                    $proveedor_id_usuario
                );

                if ($stmt->execute()) {
                    $contador++;
                } else {
                    $errores[] = "Fila " . ($contador + 2) . ": Error al insertar - " . $conn->error;
                }
                $stmt->close();
            }

            fclose($handle);

            if ($contador > 0) {
                $mensaje = "✅ Se importaron $contador productos correctamente.";
                $tipo_mensaje = "exito";
            }

            if (!empty($errores)) {
                $mensaje .= "<br><br>⚠️ Errores encontrados:<br>" . implode("<br>", array_map('htmlspecialchars', $errores));
                $tipo_mensaje = "warning";
            }

        } else {
            $mensaje = "❌ No se pudo abrir el archivo.";
            $tipo_mensaje = "error";
        }
    }
}

// Obtener categorías para mostrar
$categorias = $conn->query("SELECT id, nombre FROM categorias ORDER BY nombre");
?>

<div style="max-width: 900px; margin: 0 auto;">

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>" style="padding: 1rem; border-radius: 8px; margin-bottom: 1rem; <?php echo $tipo_mensaje === 'exito' ? 'background:#f0fff4;color:#22543d;border:1px solid #48bb78;' : ($tipo_mensaje === 'warning' ? 'background:#fef5e7;color:#744210;border:1px solid #ecc94b;' : 'background:#fff5f5;color:#c53030;border:1px solid #f56565;'); ?>">
            <?php echo $mensaje; ?>
        </div>
    <?php endif; ?>

    <h2 style="margin-bottom: 1rem; color: #2d3748;">📋 Instrucciones</h2>

    <div style="background: #ebf8ff; border-left: 4px solid #4299e1; padding: 1rem; margin-bottom: 1.5rem; border-radius: 4px;">
        <p style="margin: 0;">✅ Las imágenes deben estar en <strong>uploads/productos/</strong></p>
        <p style="margin: 0.5rem 0 0 0;">✅ El archivo CSV debe tener las columnas en este orden:</p>
    </div>

    <div style="overflow-x:auto; margin-bottom: 1.5rem;">
        <table style="width:100%; border-collapse:collapse; font-size: 0.85rem;">
            <thead>
                <tr style="background: #f7fafc;">
                    <th style="padding:0.6rem; text-align:left; border-bottom: 2px solid #e2e8f0;">Columna</th>
                    <th style="padding:0.6rem; text-align:left; border-bottom: 2px solid #e2e8f0;">Campo</th>
                    <th style="padding:0.6rem; text-align:left; border-bottom: 2px solid #e2e8f0;">Ejemplo</th>
                </tr>
            </thead>
            <tbody>
                <tr><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">A</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">nombre</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">Camiseta Negra</td></tr>
                <tr><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">B</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">descripcion</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">Camiseta 100% algodón</td></tr>
                <tr><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">C</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">precio</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">25.99</td></tr>
                <tr><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">D</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">categoria_id</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">1</td></tr>
                <tr><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">E</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">imagen</td><td style="padding:0.5rem; border-bottom:1px solid #edf2f7;">camiseta.jpg</td></tr>
                <tr><td style="padding:0.5rem;">F</td><td style="padding:0.5rem;">cantidad</td><td style="padding:0.5rem;">10</td></tr>
            </tbody>
        </table>
    </div>

    <div style="margin-bottom: 1.5rem;">
        <p style="margin-bottom: 0.5rem;"><strong>📌 Categorías disponibles:</strong></p>
        <ul style="columns: 2; list-style: none; padding: 0; font-size: 0.85rem;">
            <?php while($cat = $categorias->fetch_assoc()): ?>
                <li style="margin-bottom: 0.3rem;">
                    <span style="display: inline-block; width: 26px; background: #667eea; color: white; text-align: center; border-radius: 4px; margin-right: 0.5rem; font-size: 0.75rem; padding: 2px 0;">
                        <?php echo $cat['id']; ?>
                    </span>
                    <?php echo htmlspecialchars($cat['nombre']); ?>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>

    <div style="margin-bottom: 1.5rem; padding: 0.8rem; background: #f7fafc; border-radius: 8px;">
        <p style="margin: 0; font-size: 0.85rem;"><strong>📎 Plantilla de ejemplo:</strong></p>
        <pre style="background: white; padding: 0.8rem; border-radius: 6px; margin-top: 0.5rem; overflow-x: auto; font-size: 0.75rem; border: 1px solid #e2e8f0;">nombre,descripcion,precio,categoria_id,imagen,cantidad
Camiseta Negra,Camiseta 100% algodón,25.99,1,camiseta.jpg,10
Pantalón Azul,Pantalón de mezclilla,35.50,1,pantalon.jpg,5
Zapatos Deportivos,Zapatillas cómodas,45.00,2,zapatos.jpg,8</pre>
    </div>

    <hr style="margin: 1.5rem 0; border-color: #edf2f7;">

    <form method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom: 1rem;">
            <label style="display: block; font-weight: 600; margin-bottom: 0.5rem; font-size: 0.85rem;">
                Seleccionar archivo CSV:
            </label>
            <input type="file" name="csv_file" accept=".csv" required style="padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 4px; width: 100%; font-size: 0.85rem;">
            <small style="color: #718096; font-size: 0.75rem;">El archivo debe tener la primera fila con los nombres de las columnas</small>
        </div>

        <button type="submit" name="importar" style="padding: 0.8rem 2rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.9rem;">
            📥 Importar Productos
        </button>
    </form>
</div>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';

header('Content-Type: application/json');

// Validar sesión
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'mensaje' => 'No autorizado']);
    exit;
}

$rol_actual = $_SESSION['rol'] ?? '';
$usuario_id = $_SESSION['usuario_id'];

// Roles permitidos
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor', 'Empaquetador', 'Transportista'];
if (!in_array($rol_actual, $roles_permitidos)) {
    echo json_encode(['success' => false, 'mensaje' => 'Sin permiso']);
    exit;
}

// Validar pedido_id
$pedido_id = intval($_GET['pedido_id'] ?? 0);
if ($pedido_id <= 0) {
    echo json_encode(['success' => false, 'mensaje' => 'ID no válido']);
    exit;
}

// Detectar proveedor del usuario
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id, $rol_actual));

// Verificar propiedad del pedido
if ($proveedor_id_usuario > 0) {
    $stmt_prop = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles WHERE pedido_id = ? AND proveedor_id = ?");
    $stmt_prop->bind_param("ii", $pedido_id, $proveedor_id_usuario);
    $stmt_prop->execute();
    $prop = $stmt_prop->get_result()->fetch_assoc();
    $stmt_prop->close();
    
    if ($prop['total'] == 0) {
        echo json_encode(['success' => false, 'mensaje' => 'No tienes permiso para ver este pedido']);
        exit;
    }
}

// Obtener dirección de entrega
$stmt = $conn->prepare("SELECT * FROM direcciones_envio WHERE pedido_id = ?");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $stmt->close();
    echo json_encode(['success' => false, 'mensaje' => 'No hay dirección registrada']);
    exit;
}

$direccion = $result->fetch_assoc();
$stmt->close();

// Construir dirección completa
$direccion_completa = $direccion['direccion'];
if (!empty($direccion['municipio'])) {
    $direccion_completa .= ', ' . $direccion['municipio'];
}
if (!empty($direccion['provincia'])) {
    $direccion_completa .= ', ' . $direccion['provincia'];
}

echo json_encode([
    'success' => true,
    'nombre_completo' => $direccion['nombre_completo'],
    'documento' => $direccion['documento'],
    'direccion' => $direccion_completa,
    'direccion_simple' => $direccion['direccion'],
    'municipio' => $direccion['municipio'] ?? '',
    'provincia' => $direccion['provincia'] ?? '',
    'telefono' => $direccion['telefono'],
    'email' => $direccion['email'] ?? '',
    'instrucciones' => $direccion['instrucciones'] ?? ''
]);

$conn->close();
?>
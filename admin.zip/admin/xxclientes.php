<?php
require_once '../header.php';
require_once '../conexion.php';

// ============================================
// VERIFICACIÓN DE PERMISOS PARA CLIENTES
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
$puede_ver = in_array($_SESSION['rol'], $roles_permitidos);

if (!$puede_ver) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// PERMISOS DE GESTIÓN (editar/eliminar clientes)
// ============================================
$roles_gestion = ['Super Admin', 'Gerente'];
$puede_gestionar = in_array($_SESSION['rol'], $roles_gestion);

// ============================================
// CLIENTES ONLINE
// ============================================
$conn->query("DELETE FROM clientes_online WHERE ultima_actividad < DATE_SUB(NOW(), INTERVAL 2 MINUTE)");

$online = $conn->query("SELECT DISTINCT cliente_id FROM clientes_online");
$online_ids = [];
while($row = $online->fetch_assoc()) {
    $online_ids[] = $row['cliente_id'];
}
$online_count = count($online_ids);
$online_ids_str = implode(',', $online_ids);

$online_info = [];
$info_query = $conn->query("SELECT cliente_id, pagina_actual, ip_address, user_agent, ultima_actividad FROM clientes_online ORDER BY ultima_actividad DESC");
while($row = $info_query->fetch_assoc()) {
    $online_info[$row['cliente_id']] = $row;
}

// ============================================
// PROCESAR ACCIONES
// ============================================
$mensaje = '';
$tipo_mensaje = '';

// Editar cliente (CON CAMBIO DE CONTRASEÑA OPCIONAL)
if (isset($_POST['editar_cliente'])) {
    $id = intval($_POST['cliente_id']);
    $nombre = trim($_POST['nombre']);
    $email = trim($_POST['email']);
    $movil = trim($_POST['movil']);
    $nueva_password = trim($_POST['nueva_password'] ?? '');
    
    if (empty($nueva_password)) {
        $stmt = $conn->prepare("UPDATE clientes SET nombre = ?, email = ?, movil = ? WHERE id = ?");
        $stmt->bind_param("sssi", $nombre, $email, $movil, $id);
    } else {
        if (strlen($nueva_password) < 6) {
            $_SESSION['mensaje'] = "❌ La contraseña debe tener al menos 6 caracteres";
            $_SESSION['tipo_mensaje'] = "error";
            echo '<script>window.location.href="clientes.php";</script>';
            exit;
        }
        $password_hash = password_hash($nueva_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE clientes SET nombre = ?, email = ?, movil = ?, password = ? WHERE id = ?");
        $stmt->bind_param("ssssi", $nombre, $email, $movil, $password_hash, $id);
    }
    
    if ($stmt->execute()) {
        $_SESSION['mensaje'] = "✅ Cliente actualizado correctamente";
        $_SESSION['tipo_mensaje'] = "exito";
    } else {
        $_SESSION['mensaje'] = "❌ Error al actualizar: " . $conn->error;
        $_SESSION['tipo_mensaje'] = "error";
    }
    echo '<script>window.location.href="clientes.php";</script>';
    exit;
}

// Eliminar dispositivo
if (isset($_GET['eliminar_dispositivo'])) {
    $cliente_id = intval($_GET['cliente_id']);
    $campo = $_GET['eliminar_dispositivo'];
    
    if (in_array($campo, ['uuid', 'uuid2', 'uuid3'])) {
        $stmt = $conn->prepare("UPDATE clientes SET $campo = NULL WHERE id = ?");
        $stmt->bind_param("i", $cliente_id);
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "✅ Dispositivo eliminado";
            $_SESSION['tipo_mensaje'] = "exito";
        }
    }
    echo '<script>window.location.href="clientes.php";</script>';
    exit;
}

// Activar/Desactivar cliente
if (isset($_GET['toggle_activo'])) {
    $id = intval($_GET['toggle_activo']);
    $estado = intval($_GET['estado']);
    
    $stmt = $conn->prepare("UPDATE clientes SET activo = ? WHERE id = ?");
    $stmt->bind_param("ii", $estado, $id);
    if ($stmt->execute()) {
        $_SESSION['mensaje'] = "✅ Estado del cliente actualizado";
        $_SESSION['tipo_mensaje'] = "exito";
    }
    echo '<script>window.location.href="clientes.php";</script>';
    exit;
}

// Eliminar cliente
if (isset($_GET['eliminar'])) {
    $id = intval($_GET['eliminar']);
    
    $check = $conn->prepare("SELECT COUNT(*) as total FROM carritos WHERE cliente_id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $carritos = $check->get_result()->fetch_assoc()['total'];
    
    if ($carritos > 0) {
        $_SESSION['mensaje'] = "❌ No se puede eliminar: el cliente tiene $carritos carrito(s) asociados";
        $_SESSION['tipo_mensaje'] = "error";
    } else {
        $stmt = $conn->prepare("DELETE FROM clientes WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "✅ Cliente eliminado correctamente";
            $_SESSION['tipo_mensaje'] = "exito";
        }
    }
    echo '<script>window.location.href="clientes.php";</script>';
    exit;
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "(nombre LIKE ? OR apellidos LIKE ?)";
    $search = "%" . $_GET['nombre'] . "%";
    $params[] = $search;
    $params[] = $search;
    $types .= "ss";
}

if (!empty($_GET['email'])) {
    $where[] = "email LIKE ?";
    $params[] = "%" . $_GET['email'] . "%";
    $types .= "s";
}

if (!empty($_GET['documento'])) {
    $where[] = "documento LIKE ?";
    $params[] = "%" . $_GET['documento'] . "%";
    $types .= "s";
}

if (!empty($_GET['movil'])) {
    $where[] = "movil LIKE ?";
    $params[] = "%" . $_GET['movil'] . "%";
    $types .= "s";
}

if (isset($_GET['activo']) && $_GET['activo'] !== '') {
    $where[] = "activo = ?";
    $params[] = $_GET['activo'];
    $types .= "i";
}

if (isset($_GET['online']) && $_GET['online'] !== '' && !empty($online_ids_str)) {
    if ($_GET['online'] == '1') {
        $where[] = "id IN ($online_ids_str)";
    } else if ($_GET['online'] == '0' && !empty($online_ids_str)) {
        $where[] = "id NOT IN ($online_ids_str)";
    }
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ===== CONTAR TOTAL DE REGISTROS =====
$count_sql = "SELECT COUNT(*) as total FROM clientes c $sql_where";
$count_result = $conn->query($count_sql);
$total_registros = $count_result->fetch_assoc()['total'];

// ===== INCLUIR VARIABLES DE PAGINACIÓN =====
$base_url = 'clientes.php?' . http_build_query(array_filter($_GET));
include __DIR__ . '/../includes/paginacion_vars.php';

// ============================================
// CONSULTA
// ============================================
$sql = "SELECT c.*, 
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id) as total_carritos,
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id AND estado = 'pendiente') as carritos_pendientes,
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id AND estado = 'comprado') as compras_realizadas
        FROM clientes c
        $sql_where
        ORDER BY c.fecha_registro DESC
        LIMIT $por_pagina OFFSET $offset";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$clientes = $stmt->get_result();

// Estadísticas
$stats = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(activo) as activos,
    SUM(CASE WHEN activo = 0 THEN 1 ELSE 0 END) as inactivos
    FROM clientes")->fetch_assoc();

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}
?>

<!-- ESTILOS ESPECÍFICOS DE CLIENTES -->
<style>
.gestion-container {
    max-width: 1400px;
    margin: 1rem auto;
    padding: 0 1rem;
}

@media (min-width: 768px) {
    .gestion-container {
        margin: 2rem auto;
        padding: 0 2rem;
    }
}

.gestion-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

@media (max-width: 640px) {
    .gestion-header {
        justify-content: center;
        text-align: center;
    }
}

.gestion-header h1 {
    font-size: 1.5rem;
    color: #2d3748;
    margin: 0;
}

@media (min-width: 768px) {
    .gestion-header h1 {
        font-size: 2rem;
    }
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}

@media (min-width: 640px) {
    .stats-grid {
        grid-template-columns: repeat(4, 1fr);
        gap: 1rem;
    }
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: 0.75rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    text-align: center;
}

.stat-card .label {
    font-size: 0.65rem;
    color: #718096;
    text-transform: uppercase;
}

.stat-card .value {
    font-size: 1.2rem;
    font-weight: 700;
    color: #2d3748;
}

.filtros-card {
    background: white;
    border-radius: 12px;
    padding: 1rem;
    margin-bottom: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    width: 100%;
}

@media (min-width: 768px) {
    .filtros-card {
        padding: 1.5rem;
    }
}

.filtros-linea {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 0.5rem;
}

.filtro-item {
    flex: 1;
    min-width: 0;
}

.filtro-item label {
    display: block;
    font-size: 0.65rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.2rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.filtro-item input,
.filtro-item select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 0.8rem;
}

.btn-online {
    background: #48bb78;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 20px;
    cursor: pointer;
    font-weight: bold;
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 0.8rem;
    white-space: nowrap;
}

.filtros-botones {
    display: flex;
    gap: 0.5rem;
    flex-shrink: 0;
}

.btn-filtro {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.8rem;
    text-decoration: none;
    display: inline-block;
    text-align: center;
    white-space: nowrap;
}

.btn-filtro-aplicar {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
}

.btn-filtro-limpiar {
    background: #edf2f7;
    color: #4a5568;
}

@media (max-width: 768px) {
    .filtros-linea {
        flex-direction: column;
        align-items: stretch;
        gap: 0.75rem;
    }
    
    .filtro-item {
        width: 100%;
    }
    
    .btn-online {
        justify-content: center;
    }
    
    .filtros-botones {
        margin-top: 0.5rem;
    }
    
    .btn-filtro {
        flex: 1;
        text-align: center;
    }
}

.tabla-clientes {
    background: white;
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    width: 100%;
}

.tabla-clientes table {
    width: 100%;
    min-width: 900px;
    border-collapse: collapse;
    font-size: 0.75rem;
}

@media (min-width: 768px) {
    .tabla-clientes table {
        font-size: 0.85rem;
        min-width: 1000px;
    }
}

.tabla-clientes th {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 0.7rem 0.5rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.7rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.tabla-clientes td {
    padding: 0.7rem 0.5rem;
    border-bottom: 1px solid #edf2f7;
    vertical-align: middle;
}

.online-indicator {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-right: 5px;
}

.online {
    background-color: #48bb78;
    box-shadow: 0 0 5px #48bb78;
}

.offline {
    background-color: #cbd5e0;
}

.email-verificado {
    color: #48bb78;
    font-weight: 600;
}

.email-no-verificado {
    color: #f56565;
    font-weight: 600;
}

.badge-estado {
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.65rem;
    color: white;
    display: inline-block;
    white-space: nowrap;
}

.badge-activo { background: #48bb78; }
.badge-inactivo { background: #f56565; }

.acciones-container {
    display: flex;
    gap: 0.2rem;
    flex-wrap: wrap;
}

.btn-accion {
    width: 28px;
    height: 28px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.8rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: none;
    cursor: pointer;
    transition: all 0.2s;
    color: white;
    flex-shrink: 0;
}

.btn-editar { background: #4299e1; }
.btn-dispositivos { background: #9f7aea; }
.btn-historial { background: #48bb78; }
.btn-activar { background: #48bb78; }
.btn-desactivar { background: #ed8936; }
.btn-eliminar { background: #f56565; }

.mensaje {
    padding: 0.75rem;
    border-radius: 10px;
    margin-bottom: 1rem;
    font-size: 0.85rem;
}

.mensaje.exito {
    background: #f0fff4;
    color: #22543d;
    border: 1px solid #48bb78;
}

.mensaje.error {
    background: #fff5f5;
    color: #742a2a;
    border: 1px solid #f56565;
}

.modal {
    display: none;
    position: fixed;
    z-index: 2000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(5px);
}

.modal-content {
    background: white;
    margin: 10% auto;
    padding: 1.25rem;
    border-radius: 16px;
    max-width: 95%;
    width: 95%;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
    animation: slideDown 0.3s;
}

@media (min-width: 768px) {
    .modal-content {
        margin: 5% auto;
        padding: 2rem;
        max-width: 500px;
    }
}

.close {
    position: absolute;
    top: 0.75rem;
    right: 1rem;
    font-size: 1.8rem;
    cursor: pointer;
    color: #718096;
}

.close:hover {
    color: #2d3748;
}

.dispositivo-card {
    background: #f8fafc;
    border-radius: 8px;
    padding: 0.8rem;
    margin-bottom: 0.8rem;
    border-left: 4px solid var(--primary);
}

.dispositivo-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.5rem;
}

.dispositivo-nombre {
    font-weight: 600;
    color: #2d3748;
    font-size: 0.9rem;
}

.dispositivo-uuid {
    font-family: monospace;
    font-size: 0.7rem;
    color: #718096;
    word-break: break-all;
}

.btn-eliminar-dispositivo {
    background: #f56565;
    color: white;
    padding: 0.2rem 0.5rem;
    border-radius: 4px;
    text-decoration: none;
    font-size: 0.7rem;
}

.text-right { text-align: right; }
.text-center { text-align: center; }
.sin-datos { padding: 2rem; text-align: center; color: #a0aec0; }
</style>

<div class="gestion-container">
    <div class="gestion-header">
        <h1>👥 Gestión de Clientes</h1>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Total Clientes</div>
            <div class="value"><?php echo $stats['total']; ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Activos</div>
            <div class="value"><?php echo $stats['activos']; ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Inactivos</div>
            <div class="value"><?php echo $stats['inactivos']; ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Online</div>
            <div class="value"><?php echo $online_count; ?></div>
        </div>
    </div>

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <div class="filtros-card">
        <form method="GET" class="filtros-form">
            <div class="filtros-linea">
                <div class="filtro-item">
                    <label>Nombre</label>
                    <input type="text" name="nombre" value="<?php echo htmlspecialchars($_GET['nombre'] ?? ''); ?>" placeholder="Buscar...">
                </div>
                <div class="filtro-item">
                    <label>Email</label>
                    <input type="text" name="email" value="<?php echo htmlspecialchars($_GET['email'] ?? ''); ?>" placeholder="correo@ejemplo.com">
                </div>
                <div class="filtro-item">
                    <label>Documento</label>
                    <input type="text" name="documento" value="<?php echo htmlspecialchars($_GET['documento'] ?? ''); ?>" placeholder="12345678">
                </div>
                <div class="filtro-item">
                    <label>Móvil</label>
                    <input type="text" name="movil" value="<?php echo htmlspecialchars($_GET['movil'] ?? ''); ?>" placeholder="555-1234">
                </div>
                <div class="filtro-item">
                    <label>Estado</label>
                    <select name="activo">
                        <option value="">Todos</option>
                        <option value="1" <?php echo ($_GET['activo'] ?? '') == '1' ? 'selected' : ''; ?>>Activos</option>
                        <option value="0" <?php echo ($_GET['activo'] ?? '') == '0' ? 'selected' : ''; ?>>Inactivos</option>
                    </select>
                </div>
                <button type="button" class="btn-online" onclick="verClientesOnline()">🟢 <span id="contadorOnline"><?php echo $online_count; ?></span></button>
                <div class="filtros-botones">
                    <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
                    <a href="clientes.php" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
                </div>
            </div>
        </form>
    </div>

    <div class="tabla-clientes">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Doc.</th>
                    <th>Móvil</th>
                    <th>Registro</th>
                    <th>Estado</th>
                    <th>Carros</th>
                    <th>Disp.</th>
                    <th>Acciones</th>
                </thead>
            <tbody>
                <?php if ($clientes->num_rows > 0): ?>
                    <?php while($c = $clientes->fetch_assoc()): 
                        $dispositivos = 0;
                        if (!empty($c['uuid'])) $dispositivos++;
                        if (!empty($c['uuid2'])) $dispositivos++;
                        if (!empty($c['uuid3'])) $dispositivos++;
                        $online_actual = in_array($c['id'], $online_ids);
                    ?>
                    <tr>
                        <td>#<?php echo $c['id']; ?></td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 0.2rem;">
                                <span class="online-indicator <?php echo $online_actual ? 'online' : 'offline'; ?>" title="<?php echo $online_actual ? 'Online' : 'Offline'; ?>"></span>
                                <strong><?php echo htmlspecialchars($c['nombre'] . ' ' . $c['apellidos']); ?></strong>
                            </div>
                        </td>
                        <td>
                            <?php if ($c['email_verified'] ?? 0): ?>
                                <span class="email-verificado" title="Email verificado">✓ <?php echo htmlspecialchars(substr($c['email'], 0, 15)) . (strlen($c['email']) > 15 ? '...' : ''); ?></span>
                            <?php else: ?>
                                <span class="email-no-verificado" title="Email no verificado">⚠️ <?php echo htmlspecialchars(substr($c['email'], 0, 15)) . (strlen($c['email']) > 15 ? '...' : ''); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars(substr($c['documento'], 0, 8)); ?></td>
                        <td><?php echo htmlspecialchars(substr($c['movil'], 0, 8)); ?></td>
                        <td><?php echo date('d/m/y', strtotime($c['fecha_registro'])); ?></td>
                        <td><span class="badge-estado <?php echo $c['activo'] ? 'badge-activo' : 'badge-inactivo'; ?>"><?php echo $c['activo'] ? 'Act' : 'Inact'; ?></span></td>
                        <td class="text-center"><?php echo $c['total_carritos']; ?></td>
                        <td class="text-center"><?php echo $dispositivos; ?></td>
                        <td>
    <div class="acciones-container">
        <?php if ($puede_gestionar): ?>
            <button onclick='editarCliente(<?php echo $c['id']; ?>, "<?php echo addslashes($c['nombre']); ?>", "<?php echo addslashes($c['email']); ?>", "<?php echo addslashes($c['movil']); ?>")' class="btn-accion btn-editar" title="Editar">✏️</button>
        <?php endif; ?>
        <button onclick='verDispositivos(<?php echo $c['id']; ?>, "<?php echo addslashes($c['nombre'] . ' ' . $c['apellidos']); ?>", "<?php echo $c['uuid']; ?>", "<?php echo $c['uuid2']; ?>", "<?php echo $c['uuid3']; ?>")' class="btn-accion btn-dispositivos" title="Dispositivos">📱</button>
        <a href="historial_cliente_cambios.php?id=<?php echo $c['id']; ?>" class="btn-accion btn-historial" title="Historial">📋</a>
        <?php if ($puede_gestionar): ?>
            <?php if ($c['activo']): ?>
                <a href="?toggle_activo=<?php echo $c['id']; ?>&estado=0" class="btn-accion btn-desactivar" title="Desactivar">🔴</a>
            <?php else: ?>
                <a href="?toggle_activo=<?php echo $c['id']; ?>&estado=1" class="btn-accion btn-activar" title="Activar">🟢</a>
            <?php endif; ?>
            <?php if ($c['total_carritos'] == 0): ?>
                <a href="?eliminar=<?php echo $c['id']; ?>" class="btn-accion btn-eliminar" title="Eliminar" onclick="return confirm('¿Eliminar?')">🗑️</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="10" class="sin-datos">📭 No hay clientes</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
       </div>
</div>

<?php
// ===== BOTONES DE PAGINACIÓN =====
include __DIR__ . '/../includes/paginacion_botones.php';
?>

<!-- Modales -->
<div id="modalEditarCliente" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalEditarCliente')">&times;</span>
        <h2 style="font-size: 1.3rem;">✏️ Editar Cliente</h2>
        <form method="POST" id="formEditarCliente">
            <input type="hidden" name="editar_cliente" value="1">
            <input type="hidden" name="cliente_id" id="edit_id">
            
            <div style="margin-bottom: 0.8rem;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Nombre</label>
                <input type="text" name="nombre" id="edit_nombre" required style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px;">
            </div>
            
            <div style="margin-bottom: 0.8rem;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Email</label>
                <input type="email" name="email" id="edit_email" required style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px;">
            </div>
            
            <div style="margin-bottom: 0.8rem;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Móvil</label>
                <input type="text" name="movil" id="edit_movil" required style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px;">
            </div>
            
            <!-- NUEVO: CAMPO CONTRASEÑA -->
            <div style="margin-bottom: 1rem; padding-top: 0.5rem; border-top: 1px solid #e2e8f0;">
                <label style="display: block; font-size: 0.8rem; font-weight: 600;">Nueva Contraseña</label>
                <input type="password" name="nueva_password" id="edit_password" style="width:100%; padding:0.5rem; border:1px solid #e2e8f0; border-radius:4px;" placeholder="Dejar en blanco para no cambiar">
                <small style="color: #718096; font-size:0.7rem;">🔒 Mínimo 6 caracteres</small>
            </div>
            
            <button type="submit" style="width:100%; padding:0.8rem; background:linear-gradient(135deg, #667eea 0%, #764ba2 100%); color:white; border:none; border-radius:4px; cursor:pointer;">Actualizar Datos</button>
        </form>
    </div>
</div>

<div id="modalDispositivos" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalDispositivos')">&times;</span>
        <h2 style="font-size: 1.3rem;">📱 Dispositivos</h2>
        <div id="contenidoDispositivos"></div>
    </div>
</div>

<div id="modalClientesOnline" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <span class="close" onclick="cerrarModal('modalClientesOnline')">&times;</span>
        <h2 style="font-size: 1.3rem;">👥 Clientes Online</h2>
        <div style="overflow-x: auto;">
            <table class="tabla-online">
                <thead><tr><th>Cliente</th><th>Página</th><th>Actividad</th><th>IP</th></tr></thead>
                <tbody id="listaClientesOnline"><tr><td colspan="4" style="text-align:center;">Cargando...</td></tr></tbody>
            </table>
        </div>
    </div>
</div>

<script>
function editarCliente(id, nombre, email, movil) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nombre').value = nombre;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_movil').value = movil;
    document.getElementById('edit_password').value = '';
    document.getElementById('modalEditarCliente').style.display = 'block';
}
    
function verDispositivos(id, nombre, uuid, uuid2, uuid3) {
    let html = '<p><strong>' + nombre + '</strong></p>';
    const dispositivos = [
        { nombre: 'Principal', uuid: uuid, campo: 'uuid' },
        { nombre: 'Dispositivo 2', uuid: uuid2, campo: 'uuid2' },
        { nombre: 'Dispositivo 3', uuid: uuid3, campo: 'uuid3' }
    ];
    dispositivos.forEach(disp => {
        if (disp.uuid) {
            html += '<div class="dispositivo-card"><div class="dispositivo-header"><span class="dispositivo-nombre">' + disp.nombre + '</span><a href="?eliminar_dispositivo=' + disp.campo + '&cliente_id=' + id + '" class="btn-eliminar-dispositivo" onclick="return confirm(\'¿Eliminar este dispositivo?\')">Eliminar</a></div><div class="dispositivo-uuid">' + disp.uuid.substring(0, 20) + '...</div></div>';
        } else {
            html += '<div class="dispositivo-card" style="opacity:0.5;"><span class="dispositivo-nombre">' + disp.nombre + '</span><br><span style="color:#a0aec0;">Vacío</span></div>';
        }
    });
    document.getElementById('contenidoDispositivos').innerHTML = html;
    document.getElementById('modalDispositivos').style.display = 'block';
}

function verClientesOnline() {
    document.getElementById('modalClientesOnline').style.display = 'block';
    cargarClientesOnline();
}

function cargarClientesOnline() {
    fetch('clientes_online_json.php')
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length === 0) {
                html = '<tr><td colspan="4" style="text-align:center;">📭 No hay clientes online</td></tr>';
            } else {
                data.forEach(c => {
                    html += '<tr><td><strong>' + c.nombre + ' ' + c.apellidos + '</strong></td><td>' + (c.pagina_actual.length > 25 ? c.pagina_actual.substring(0,25) + '...' : c.pagina_actual) + '</td><td>' + c.tiempo + '</td><td>' + c.ip_address + '</td></tr>';
                });
            }
            document.getElementById('listaClientesOnline').innerHTML = html;
            document.getElementById('contadorOnline').innerHTML = data.length;
        })
        .catch(() => {
            document.getElementById('listaClientesOnline').innerHTML = '<tr><td colspan="4" style="text-align:center;color:#f56565;">Error</td></tr>';
        });
}

function cerrarModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

setInterval(() => {
    if (document.getElementById('modalClientesOnline').style.display === 'block') {
        cargarClientesOnline();
    }
}, 30000);

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>

<?php
$conn->close();
include '../footer.php';
?>
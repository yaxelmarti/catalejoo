<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/csrf.php';
require_once dirname(__DIR__) . '/header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

$rol = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol));

// ============================================
// VALIDAR PROVEEDOR OBLIGATORIO
// ============================================
if (esRolProveedor($rol) && $proveedor_id_usuario == 0) {
    header('Location: /admin.php?error=sin_tienda');
    exit;
}

// ============================================
// PERMISOS DE ACCESO
// ============================================
$roles_ver = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Vendedor'];
if (!in_array($rol, $roles_ver, true)) {
    header('Location: /admin.php?error=permiso');
    exit;
}

$roles_gestion = ['Super Admin', 'Gerente', 'Contador', 'Proveedor', 'Vendedor'];
$puede_gestionar = in_array($rol, $roles_gestion, true);

$roles_ver_todos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
$puede_ver_todos = in_array($rol, $roles_ver_todos, true);

// ============================================
// COLORES DE CONFIGURACIÓN
// ============================================
$color_primario = '#667eea';
$color_secundario = '#764ba2';
$stmt_c = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario' LIMIT 1");
if ($stmt_c) {
    $stmt_c->execute();
    $row_c = $stmt_c->get_result()->fetch_assoc();
    if ($row_c && !empty($row_c['valor'])) $color_primario = $row_c['valor'];
    $stmt_c->close();
}
$stmt_c2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario' LIMIT 1");
if ($stmt_c2) {
    $stmt_c2->execute();
    $row_c2 = $stmt_c2->get_result()->fetch_assoc();
    if ($row_c2 && !empty($row_c2['valor'])) $color_secundario = $row_c2['valor'];
    $stmt_c2->close();
}

// ============================================
// FUNCIÓN: Verificar propiedad del pedido
// ============================================
function verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario) {
    if ($proveedor_id_usuario == 0) return true;
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles WHERE pedido_id = ? AND proveedor_id = ?");
    if (!$stmt) return false;
    $stmt->bind_param("ii", $pedido_id, $proveedor_id_usuario);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result && $result['total'] > 0;
}

// ============================================
// FUNCIÓN: Calcular comisión del pago
// ============================================
function calcularComisionPago($conn, $metodo_pago, $proveedor_id_usuario, $monto_base) {
    $stmt_com = $conn->prepare("SELECT valor FROM configuracion WHERE clave = ? AND grupo = 'pagos' AND proveedor_id IN (?, 0) ORDER BY proveedor_id DESC LIMIT 1");
    if (!$stmt_com) return 0;
    $clave_com = $metodo_pago . '_comision';
    $stmt_com->bind_param("si", $clave_com, $proveedor_id_usuario);
    $stmt_com->execute();
    $com_data = $stmt_com->get_result()->fetch_assoc();
    $stmt_com->close();
    $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;
    return round($monto_base * ($porcentaje_comision / 100), 2);
}

// ============================================
// FUNCIÓN: Confirmar un pago individual
// ============================================
function confirmarPagoIndividual($conn, $pedido_id, $proveedor_id_usuario, $usuario_id) {
    $stmt_info = $conn->prepare("SELECT estado_pago, estado_actual, porcentaje_comprometido, monto_pagado, monto_pendiente, comision, moneda, tipo_pago, total_convertido, total, cliente_id, codigo FROM pedidos WHERE id = ?");
    if (!$stmt_info) return ['success' => false, 'mensaje' => 'Error de BD'];
    $stmt_info->bind_param("i", $pedido_id);
    $stmt_info->execute();
    $info = $stmt_info->get_result()->fetch_assoc();
    $stmt_info->close();

       if (!$info) return ['success' => false, 'mensaje' => 'Pedido no encontrado'];
    if ($info['estado_pago'] === 'pagado') return ['success' => false, 'mensaje' => 'Este pedido ya está pagado.'];

    // ============================================
    // VALIDAR: pendiente_entrega y pendiente_pago_final solo si estado_actual = 'entregado'
    // ============================================
    if (in_array($info['estado_pago'], ['pendiente_entrega', 'pendiente_pago_final'], true)) {
        if (($info['estado_actual'] ?? '') !== 'entregado') {
            return ['success' => false, 'mensaje' => 'Este pedido se paga al recibir. Primero debe estar entregado.'];
        }
    }

    $moneda_pedido = !empty($info['moneda']) ? $info['moneda'] : 'USD';
    $total_convertido = floatval($info['total_convertido'] ?? $info['total']);
    $monto_pagado_actual = floatval($info['monto_pagado'] ?? 0);
    $monto_pendiente_actual = floatval($info['monto_pendiente'] ?? 0);
    $comision_actual = floatval($info['comision'] ?? 0);
    $metodo_pago = $info['tipo_pago'] ?? '';

    if ($monto_pendiente_actual <= 0) {
        $monto_pendiente_actual = $total_convertido - $monto_pagado_actual;
    }

    $monto_manual = floatval($_POST['monto_manual'] ?? 0);
    $tipo_pago_modal = trim($_POST['tipo_pago_modal'] ?? 'exacto');

    if ($monto_manual > 0) {
        if ($monto_manual > $monto_pendiente_actual + 0.01) {
            return ['success' => false, 'mensaje' => 'El monto excede el saldo pendiente (' . $monto_pendiente_actual . ' ' . $moneda_pedido . ')'];
        }
        if ($monto_manual < 0.01) {
            return ['success' => false, 'mensaje' => 'El monto debe ser mayor a 0'];
        }
        $monto_base_pago = $monto_manual;
    } else {
        $monto_base_pago = $monto_pendiente_actual;
    }

    $comision_pago = calcularComisionPago($conn, $metodo_pago, $proveedor_id_usuario, $monto_base_pago);
    $nuevo_monto_pagado = $monto_pagado_actual + $monto_base_pago;
    $nuevo_monto_pendiente = max(0, $total_convertido - $nuevo_monto_pagado);
    $nuevo_porcentaje = ($total_convertido > 0) ? round(($nuevo_monto_pagado / $total_convertido) * 100) : 0;
    $nueva_comision = $comision_actual + $comision_pago;

        if ($nuevo_monto_pendiente <= 0.01) {
        // ============================================
        // PAGO TOTAL (cubre 100%)
        // ============================================
        $nuevo_estado_pago = 'pagado';

        // Forma 1: pago total adelantado (API o manual) → pago_confirmado
        if (in_array($info['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
            $nuevo_estado_actual = 'pago_confirmado';
        } else {
            // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar estado_actual
            $nuevo_estado_actual = $info['estado_actual'];
        }
    } else {
        // ============================================
        // PAGO PARCIAL (no cubre 100%)
        // ============================================
        if ($info['estado_pago'] === 'pendiente_parcial' && $monto_pagado_actual == 0) {
            // Forma 3: 1er pago parcial
            $nuevo_estado_pago = 'pendiente_pago_final';
            $nuevo_estado_actual = 'pendiente_entrega_pago';
        } else {
            // Cualquier otro caso → no cambiar
            $nuevo_estado_pago = $info['estado_pago'];
            $nuevo_estado_actual = $info['estado_actual'];
        }
    }

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE pedidos SET monto_pagado = ?, monto_pendiente = ?, porcentaje_pagado = ?, comision = ?, estado_pago = ?, estado_actual = ?, fecha_pago = NOW() WHERE id = ?");
        if (!$stmt) throw new Exception("prepare update: " . $conn->error);
        $stmt->bind_param("ddidssi", $nuevo_monto_pagado, $nuevo_monto_pendiente, $nuevo_porcentaje, $nueva_comision, $nuevo_estado_pago, $nuevo_estado_actual, $pedido_id);
        $stmt->execute();
        $stmt->close();

        $obs = "Pago confirmado por admin. Monto: $monto_base_pago $moneda_pedido | Comisión: $comision_pago $moneda_pedido | Método: $metodo_pago | Tipo: " . ($tipo_pago_modal === 'exacto' ? 'monto exacto' : 'monto diferente');
        $stmt_estado = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'pago_confirmado', ?, ?)");
        if (!$stmt_estado) throw new Exception("prepare estado: " . $conn->error);
        $stmt_estado->bind_param("iis", $pedido_id, $usuario_id, $obs);
        $stmt_estado->execute();
        $stmt_estado->close();

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[admin/pagos.php] Rollback pedido #' . $pedido_id . ': ' . $e->getMessage());
        return ['success' => false, 'mensaje' => 'Error al confirmar el pago'];
    }

    try {
        require_once dirname(__DIR__) . '/includes/cola_correos.php';
        $email_cliente = '';
        if (!empty($info['cliente_id'])) {
            $stmt_email = $conn->prepare("SELECT email FROM clientes WHERE id = ? LIMIT 1");
            if ($stmt_email) {
                $stmt_email->bind_param("i", $info['cliente_id']);
                $stmt_email->execute();
                $email_cliente = $stmt_email->get_result()->fetch_assoc()['email'] ?? '';
                $stmt_email->close();
            }
        }
        if (!empty($email_cliente) && filter_var($email_cliente, FILTER_VALIDATE_EMAIL)) {
            encolarCorreo($conn, $email_cliente, 'Pago confirmado - Pedido ' . ($info['codigo'] ?? ''), 'pago_confirmado', null, $pedido_id);
        }
    } catch (Throwable $e) {
        error_log('[admin/pagos.php] Error encolando correo pedido #' . $pedido_id . ': ' . $e->getMessage());
    }

    return ['success' => true, 'mensaje' => 'Pago confirmado'];
}

// ============================================
// PROCESAR ACCIONES
// ============================================
$mensaje = '';
$tipo_mensaje = '';

// ============================================
// VALIDACIÓN CSRF EN POST
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!function_exists('csrf_validar') || !csrf_validar($token)) {
        error_log("[admin/pagos.php] CSRF inválido. Usuario: $usuario_id_actual");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: pagos.php');
        exit;
    }
}

// ----- CONFIRMAR PAGO INDIVIDUAL -----
if (isset($_POST['confirmar_pago'])) {
    $pedido_id = intval($_POST['pedido_id']);
    
    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pago';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    $stmt_estado = $conn->prepare("SELECT estado_pago FROM pedidos WHERE id = ?");
    $estado_pago_actual = '';
    if ($stmt_estado) {
        $stmt_estado->bind_param("i", $pedido_id);
        $stmt_estado->execute();
        $estado_pago_actual = $stmt_estado->get_result()->fetch_assoc()['estado_pago'] ?? '';
        $stmt_estado->close();
    }

    if ($estado_pago_actual === 'pagado') {
        $_SESSION['mensaje'] = '❌ Este pedido ya está pagado';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }
    
    $resultado = confirmarPagoIndividual($conn, $pedido_id, $proveedor_id_usuario, $usuario_id_actual);
    $_SESSION['mensaje'] = ($resultado['success'] ? '✅ ' : '❌ ') . $resultado['mensaje'];
    $_SESSION['tipo_mensaje'] = $resultado['success'] ? 'exito' : 'error';
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// ----- CANCELAR PAGO INDIVIDUAL (POST con CSRF) -----
if (isset($_POST['cancelar_pedido'])) {
    $pedido_id = intval($_POST['cancelar_pedido']);
    
    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pago';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    if (!in_array($rol, ['Super Admin', 'Proveedor', 'Vendedor'], true)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para cancelar pagos';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    $stmt_info = $conn->prepare("SELECT cliente_id, codigo, estado_pago, monto_pagado FROM pedidos WHERE id = ?");
    $info_cancel = null;
    if ($stmt_info) {
        $stmt_info->bind_param("i", $pedido_id);
        $stmt_info->execute();
        $info_cancel = $stmt_info->get_result()->fetch_assoc();
        $stmt_info->close();
    }

    if (!$info_cancel) {
        $_SESSION['mensaje'] = '❌ Pedido no encontrado';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    if (in_array($info_cancel['estado_pago'], ['pagado', 'cancelado'])) {
        $_SESSION['mensaje'] = '❌ Este pedido no se puede cancelar (estado no válido)';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    if ($rol === 'Vendedor' && floatval($info_cancel['monto_pagado'] ?? 0) > 0) {
        $_SESSION['mensaje'] = '❌ No puedes cancelar un pedido con pagos registrados';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = 'cancelado', estado_actual = 'cancelado' WHERE id = ?");
        if (!$stmt) throw new Exception("prepare cancel: " . $conn->error);
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'pago_cancelado', ?, 'Pago cancelado por admin')");
        if (!$stmt) throw new Exception("prepare estado: " . $conn->error);
        $stmt->bind_param("ii", $pedido_id, $usuario_id_actual);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[admin/pagos.php] Rollback cancelar #' . $pedido_id . ': ' . $e->getMessage());
        $_SESSION['mensaje'] = "❌ Error al cancelar";
        $_SESSION['tipo_mensaje'] = "error";
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    try {
        require_once dirname(__DIR__) . '/includes/cola_correos.php';
        $email_cliente = '';
        if (!empty($info_cancel['cliente_id'])) {
            $stmt_email = $conn->prepare("SELECT email FROM clientes WHERE id = ? LIMIT 1");
            if ($stmt_email) {
                $stmt_email->bind_param("i", $info_cancel['cliente_id']);
                $stmt_email->execute();
                $email_cliente = $stmt_email->get_result()->fetch_assoc()['email'] ?? '';
                $stmt_email->close();
            }
        }
        if (!empty($email_cliente) && filter_var($email_cliente, FILTER_VALIDATE_EMAIL)) {
            encolarCorreo($conn, $email_cliente, 'Pago cancelado - Pedido ' . ($info_cancel['codigo'] ?? ''), 'cancelado', null, $pedido_id);
        }
    } catch (Throwable $e) {
        error_log('[admin/pagos.php] Error encolando correo cancelación #' . $pedido_id . ': ' . $e->getMessage());
    }

    $_SESSION['mensaje'] = "✅ Pago cancelado";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// ----- CONFIRMAR MÚLTIPLES PAGOS -----
if (isset($_POST['accion_multiple']) && $_POST['accion_multiple'] === 'confirmar_multiple') {
    $ids = json_decode($_POST['accion_multiple_ids'] ?? '[]', true);
    if (!is_array($ids)) $ids = [];
    
    $contador = 0;
    $errores = 0;
    
    foreach ($ids as $pedido_id) {
        $pedido_id = intval($pedido_id);
        if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
            $errores++;
            continue;
        }
        $resultado = confirmarPagoIndividual($conn, $pedido_id, $proveedor_id_usuario, $usuario_id_actual);
        if ($resultado['success']) $contador++; else $errores++;
    }
    
    $_SESSION['mensaje'] = "✅ $contador pago(s) confirmado(s)" . ($errores > 0 ? ", $errores error(es)" : "");
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// ----- CANCELAR MÚLTIPLES PAGOS -----
if (isset($_POST['accion_multiple']) && $_POST['accion_multiple'] === 'cancelar_multiple') {
    if (!in_array($rol, ['Super Admin', 'Proveedor', 'Vendedor'], true)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para cancelar pagos';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }

    $ids = json_decode($_POST['accion_multiple_ids'] ?? '[]', true);
    if (!is_array($ids)) $ids = [];
    
    $contador = 0;
    $pedidos_cancelados = [];
    
    $info_cancel_multiple = [];
    foreach ($ids as $pedido_id) {
        $stmt_info = $conn->prepare("SELECT cliente_id, codigo, estado_pago, monto_pagado FROM pedidos WHERE id = ?");
        if ($stmt_info) {
            $stmt_info->bind_param("i", $pedido_id);
            $stmt_info->execute();
            $info_cancel_multiple[$pedido_id] = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();
        }
    }
    
    $conn->begin_transaction();
    try {
        foreach ($ids as $pedido_id) {
            $pedido_id = intval($pedido_id);
            if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) continue;

            $info = $info_cancel_multiple[$pedido_id] ?? null;
            if (!$info) continue;
            if (in_array($info['estado_pago'], ['pagado', 'cancelado'])) continue;
            if ($rol === 'Vendedor' && floatval($info['monto_pagado'] ?? 0) > 0) continue;
            
            $stmt = $conn->prepare("UPDATE pedidos SET estado_pago = 'cancelado', estado_actual = 'cancelado' WHERE id = ?");
            if (!$stmt) throw new Exception("prepare cancel multiple: " . $conn->error);
            $stmt->bind_param("i", $pedido_id);
            $stmt->execute();
            $stmt->close();
            
            $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'pago_cancelado', ?, 'Pago cancelado por admin')");
            if (!$stmt) throw new Exception("prepare estado multiple: " . $conn->error);
            $stmt->bind_param("ii", $pedido_id, $usuario_id_actual);
            $stmt->execute();
            $stmt->close();
            
            $pedidos_cancelados[] = $pedido_id;
            $contador++;
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[admin/pagos.php] Rollback cancelar multiple: ' . $e->getMessage());
        $_SESSION['mensaje'] = "❌ Error al cancelar los pagos";
        $_SESSION['tipo_mensaje'] = "error";
        echo '<script>window.location.href="pagos.php";</script>';
        exit;
    }
    
    try {
        require_once dirname(__DIR__) . '/includes/cola_correos.php';
        
        foreach ($pedidos_cancelados as $pedido_id) {
            $info_cancel = $info_cancel_multiple[$pedido_id] ?? null;
            if (!$info_cancel || empty($info_cancel['cliente_id'])) continue;
            
            $stmt_email = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
            $stmt_email->bind_param("i", $info_cancel['cliente_id']);
            $stmt_email->execute();
            $email_cliente = $stmt_email->get_result()->fetch_assoc()['email'] ?? '';
            $stmt_email->close();
            
            if (!empty($email_cliente) && filter_var($email_cliente, FILTER_VALIDATE_EMAIL)) {
                encolarCorreo(
                    $conn,
                    $email_cliente,
                    'Pago cancelado - Pedido ' . ($info_cancel['codigo'] ?? ''),
                    'cancelado',
                    null,
                    $pedido_id
                );
            }
        }
    } catch (Throwable $e) {
        error_log('[admin/pagos.php] Error encolando correos cancelación multiple: ' . $e->getMessage());
    }
    
    $_SESSION['mensaje'] = "✅ $contador pago(s) cancelado(s)";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pagos.php?t=' . time() . '";</script>';
    exit;
}

// ============================================
// FILTRO DE PROVEEDOR
// ============================================
$proveedor_filtro = 0;
if ($puede_ver_todos && !empty($_GET['proveedor_filtro'])) {
    $proveedor_filtro = intval($_GET['proveedor_filtro']);
}

$proveedores_lista = [];
if ($puede_ver_todos) {
    $stmt_lista = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda");
    while ($row = $stmt_lista->fetch_assoc()) {
        $proveedores_lista[] = $row;
    }
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

// Filtro de proveedor
if ($proveedor_id_usuario > 0) {
    $where[] = "p.id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = ?)";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
} elseif ($puede_ver_todos && $proveedor_filtro > 0) {
    $where[] = "p.id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = ?)";
    $params[] = $proveedor_filtro;
    $types .= "i";
}

$hay_filtros = !empty($_GET['pedido_id']) || !empty($_GET['cliente']) || !empty($_GET['estado_pago']) || !empty($_GET['moneda']) || !empty($_GET['fecha_desde']) || !empty($_GET['fecha_hasta']);

if (!$hay_filtros) {
    $where[] = "p.estado_pago IN ('pendiente', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_pago_final', 'pendiente_verificacion')";
}

if (!empty($_GET['pedido_id'])) {
    $where[] = "p.codigo LIKE ?";
    $params[] = $_GET['pedido_id'] . "%";
    $types .= "s";
}

if (!empty($_GET['cliente'])) {
    $where[] = "(c.nombre LIKE ? OR c.apellidos LIKE ? OR c.email LIKE ?)";
    $search = "%" . $_GET['cliente'] . "%";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= "sss";
}

if (!empty($_GET['estado_pago']) && $_GET['estado_pago'] != 'todos') {
    $where[] = "p.estado_pago = ?";
    $params[] = $_GET['estado_pago'];
    $types .= "s";
}

if (!empty($_GET['moneda'])) {
    $where[] = "p.moneda = ?";
    $params[] = $_GET['moneda'];
    $types .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $where[] = "DATE(p.fecha_pedido) >= ?";
    $params[] = $_GET['fecha_desde'];
    $types .= "s";
}

if (!empty($_GET['fecha_hasta'])) {
    $where[] = "DATE(p.fecha_pedido) <= ?";
    $params[] = $_GET['fecha_hasta'];
    $types .= "s";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

$columnas_validas = [
    'id' => "p.id",
    'cliente' => "CONCAT(c.nombre, ' ', c.apellidos)",
    'fecha' => "p.fecha_pedido",
    'total' => "p.total",
    'metodo' => "p.tipo_pago",
    'estado' => "p.estado_pago"
];

$order_by = isset($_GET['order_by']) && array_key_exists($_GET['order_by'], $columnas_validas) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . $columnas_validas[$order_by] . " $order_dir";

$count_sql = "SELECT COUNT(*) as total FROM pedidos p JOIN clientes c ON p.cliente_id = c.id $sql_where";
$count_stmt = $conn->prepare($count_sql);
if (!$count_stmt) {
    error_log('[admin/pagos.php] Error prepare count: ' . $conn->error);
    $total_registros = 0;
} else {
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total_registros = $count_stmt->get_result()->fetch_assoc()['total'] ?? 0;
    $count_stmt->close();
}

$base_url = 'pagos.php?' . http_build_query(array_filter($_GET));
include __DIR__ . '/../includes/paginacion_vars.php';

$sql = "SELECT p.*, c.nombre, c.apellidos, c.email 
        FROM pedidos p
        JOIN clientes c ON p.cliente_id = c.id
        $sql_where
        $order_sql
        LIMIT $por_pagina OFFSET $offset";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$pedidos = $stmt->get_result();

// Estadísticas
$stats_sql = "SELECT 
    SUM(CASE WHEN p.estado_pago = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
    SUM(CASE WHEN p.estado_pago = 'pendiente_parcial' THEN 1 ELSE 0 END) as pendiente_parcial,
    SUM(CASE WHEN p.estado_pago = 'pendiente_entrega' THEN 1 ELSE 0 END) as pendiente_entrega,
    SUM(CASE WHEN p.estado_pago = 'pendiente_pago_final' THEN 1 ELSE 0 END) as pendiente_pago_final,
    SUM(CASE WHEN p.estado_pago = 'pendiente_verificacion' THEN 1 ELSE 0 END) as pendiente_verificacion,
    SUM(CASE WHEN p.estado_pago = 'pagado' THEN 1 ELSE 0 END) as pagados,
    SUM(CASE WHEN p.estado_pago = 'cancelado' THEN 1 ELSE 0 END) as cancelados
    FROM pedidos p
    JOIN clientes c ON p.cliente_id = c.id
    $sql_where";
    
$stats_stmt = $conn->prepare($stats_sql);
if (!$stats_stmt) {
    error_log('[admin/pagos.php] Error prepare stats: ' . $conn->error);
    $stats = [];
} else {
    if (!empty($params)) {
        $stats_stmt->bind_param($types, ...$params);
    }
    $stats_stmt->execute();
    $stats = $stats_stmt->get_result()->fetch_assoc();
    $stats_stmt->close();
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}
?>

<style>
:root {
    --primary: <?php echo $color_primario ?? '#667eea'; ?>;
    --secondary: <?php echo $color_secundario ?? '#764ba2'; ?>;
}

.gestion-container { width: 100%; max-width: 1400px; margin: 1rem auto; padding: 0 1rem; }
@media (min-width: 768px) { .gestion-container { margin: 2rem auto; padding: 0 2rem; } }
.gestion-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.gestion-header h1 { font-size: 1.5rem; color: #2d3748; margin: 0; }
@media (min-width: 768px) { .gestion-header h1 { font-size: 2rem; } }

.stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.75rem; margin-bottom: 1.5rem; }
@media (min-width: 640px) { .stats-grid { grid-template-columns: repeat(3, 1fr); gap: 1rem; } }
@media (min-width: 1024px) { .stats-grid { grid-template-columns: repeat(6, 1fr); } }
.stat-card { background: white; border-radius: 12px; padding: 0.75rem; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; }
.stat-card .label { font-size: 0.65rem; color: #718096; text-transform: uppercase; }
.stat-card .value { font-size: 1.2rem; font-weight: 700; color: #2d3748; }

.filtros-card { background: white; border-radius: 12px; padding: 1rem; margin-bottom: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
@media (min-width: 768px) { .filtros-card { padding: 1.5rem; } }
.filtros-linea { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 0.5rem; }
.filtro-item { flex: 1; min-width: 0; }
.filtro-item label { display: block; font-size: 0.65rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem; text-transform: uppercase; }
.filtro-item input, .filtro-item select { width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.8rem; }
.filtro-fecha { max-width: 130px; }
.filtros-botones { display: flex; gap: 0.5rem; flex-shrink: 0; }
.btn-filtro { padding: 0.5rem 1rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.8rem; text-decoration: none; display: inline-block; text-align: center; }
.btn-filtro-aplicar { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; }
.btn-filtro-limpiar { background: #edf2f7; color: #4a5568; }

@media (max-width: 768px) {
    .filtros-linea { flex-direction: column; align-items: stretch; gap: 0.75rem; }
    .filtro-item { width: 100%; }
    .filtro-fecha { max-width: none; }
    .filtros-botones { margin-top: 0.5rem; }
    .btn-filtro { flex: 1; text-align: center; }
}

.tabla-pagos { background: white; border-radius: 12px; padding: 0; box-shadow: 0 2px 4px rgba(0,0,0,0.05); overflow-x: auto; width: 100%; }
.tabla-pagos table { width: 100%; min-width: 900px; border-collapse: collapse; font-size: 0.75rem; }
@media (min-width: 768px) { .tabla-pagos table { font-size: 0.85rem; } }
.tabla-pagos th { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; padding: 0.7rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.7rem; text-transform: uppercase; }
.tabla-pagos td { padding: 0.7rem 0.5rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }

.checkbox-col { width: 40px; text-align: center; }
.checkbox-pedido, .select-all-checkbox { width: 18px; height: 18px; cursor: pointer; accent-color: var(--primary); margin: 0 auto; display: block; }

.badge-estado-pago { padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.7rem; font-weight: 600; display: inline-block; }
.badge-pendiente { background: #fef5e7; color: #c05621; }
.badge-pendiente_parcial { background: #fef5e7; color: #744210; }
.badge-pendiente_entrega { background: #fef5e7; color: #744210; }
.badge-pendiente_pago_final { background: #e9d8fd; color: #6b46c1; }
.badge-pendiente_verificacion { background: #bee3f8; color: #2a4365; }
.badge-pagado { background: #c6f6d5; color: #22543d; }
.badge-cancelado { background: #fed7d7; color: #c53030; }

.badge-api { padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.65rem; font-weight: 600; display: inline-block; white-space: nowrap; }
.badge-api-ok { background: #c6f6d5; color: #22543d; }
.badge-api-error { background: #fed7d7; color: #c53030; }
.badge-api-pendiente { background: #fef5e7; color: #c05621; }
.badge-api-fallido { background: #fed7d7; color: #c53030; }
.badge-api-sin { background: #edf2f7; color: #718096; }

.tabla-pagos th a { color: white; text-decoration: none; display: flex; align-items: center; gap: 4px; white-space: nowrap; }

.btn-accion { padding: 0.3rem 0.6rem; border-radius: 6px; text-decoration: none; font-size: 0.7rem; display: inline-block; border: none; cursor: pointer; margin: 0 0.15rem; }
@media (min-width: 768px) { .btn-accion { padding: 0.4rem 0.8rem; font-size: 0.8rem; } }
.btn-ver { background: #4299e1; color: white; }
.btn-confirmar { background: #48bb78; color: white; }
.btn-cancelar { background: #f56565; color: white; }

.floating-counter { position: fixed; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; font-weight: bold; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 1000; transition: all 0.3s ease; border: 2px solid white; display: none; align-items: center; justify-content: center; gap: 5px; }
.floating-counter:hover { transform: scale(1.05); }
.floating-counter.show { display: flex; }
@media (min-width: 769px) { .floating-counter { bottom: 20px; right: 20px; padding: 12px 20px; border-radius: 50px; font-size: 1rem; min-width: auto; } }
@media (max-width: 768px) { .floating-counter { top: 70px; left: 20px; width: 45px; height: 45px; border-radius: 50%; font-size: 1.1rem; padding: 0; } }

.floating-actions-menu { position: fixed; background: white; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.2); z-index: 1000; min-width: 200px; overflow: hidden; display: none; border: 1px solid #e2e8f0; }
.floating-actions-menu.show { display: block; animation: fadeInUp 0.2s ease; }
@media (min-width: 769px) { .floating-actions-menu { bottom: 90px; right: 20px; } }
@media (max-width: 768px) { .floating-actions-menu { top: 125px; left: 20px; } }
@keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.floating-actions-menu button { display: flex; align-items: center; gap: 12px; width: 100%; padding: 12px 16px; border: none; background: white; color: #2d3748; font-size: 0.9rem; font-weight: 500; cursor: pointer; transition: all 0.2s; text-align: left; }
.floating-actions-menu button:hover { background: #f7fafc; }
.floating-actions-menu hr { margin: 0; border-top: 1px solid #e2e8f0; }

.mensaje { padding: 0.75rem; border-radius: 10px; margin-bottom: 1rem; font-size: 0.85rem; }
.mensaje.exito { background: #f0fff4; color: #22543d; border: 1px solid #48bb78; }
.mensaje.error { background: #fff5f5; color: #742a2a; border: 1px solid #f56565; }
.text-center { text-align: center; }

.modal { display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(5px); }
.modal-content { background: white; margin: 10% auto; padding: 1.25rem; border-radius: 16px; max-width: 95%; width: 95%; max-height: 80vh; overflow-y: auto; position: relative; }
@media (min-width: 768px) { .modal-content { margin: 5% auto; padding: 2rem; max-width: 600px; } }
.close { position: absolute; top: 0.75rem; right: 1rem; font-size: 1.8rem; cursor: pointer; color: #718096; }
.close:hover { color: #2d3748; }
.btn-confirmar-modal { width: 100%; padding: 0.8rem; background: #48bb78; color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; margin-top: 1rem; }
</style>

<div class="gestion-container">
    <div class="gestion-header">
        <h1>💰 Gestión de Pagos</h1>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="label">Pendientes</div><div class="value"><?php echo $stats['pendientes'] ?? 0; ?></div></div>
        <div class="stat-card"><div class="label">Pend. Parcial</div><div class="value"><?php echo $stats['pendiente_parcial'] ?? 0; ?></div></div>
        <div class="stat-card"><div class="label">Pend. Entrega</div><div class="value"><?php echo $stats['pendiente_entrega'] ?? 0; ?></div></div>
                <div class="stat-card"><div class="label">Pend. Pago Final</div><div class="value"><?php echo $stats['pendiente_pago_final'] ?? 0; ?></div></div>
        <div class="stat-card"><div class="label">Pend. Verificación</div><div class="value"><?php echo $stats['pendiente_verificacion'] ?? 0; ?></div></div>
        <div class="stat-card"><div class="label">Pagados</div><div class="value"><?php echo $stats['pagados'] ?? 0; ?></div></div>
        <div class="stat-card"><div class="label">Cancelados</div><div class="value"><?php echo $stats['cancelados'] ?? 0; ?></div></div>
    </div>

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <div class="filtros-card">
        <form method="GET" class="filtros-form">
            <div class="filtros-linea">
                <?php if ($puede_ver_todos): ?>
                <div class="filtro-item">
                    <label>Proveedor</label>
                    <select name="proveedor_filtro" onchange="this.form.submit()">
                        <option value="0">Todos los proveedores</option>
                        <?php foreach ($proveedores_lista as $prov): ?>
                            <option value="<?php echo $prov['id']; ?>" <?php echo ($proveedor_filtro == $prov['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="filtro-item">
                    <label>Código Pedido</label>
                    <input type="text" name="pedido_id" value="<?php echo htmlspecialchars($_GET['pedido_id'] ?? ''); ?>" placeholder="260521-0001" onchange="this.form.submit()">
                </div>
                <div class="filtro-item">
                    <label>Cliente</label>
                    <input type="text" name="cliente" value="<?php echo htmlspecialchars($_GET['cliente'] ?? ''); ?>" placeholder="Nombre o email" onchange="this.form.submit()">
                </div>
                <div class="filtro-item">
                    <label>Estado pago</label>
                    <select name="estado_pago" onchange="this.form.submit()">
                        <option value="todos">Todos</option>
                        <option value="pendiente" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                        <option value="pendiente_parcial" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_parcial' ? 'selected' : ''; ?>>Pendiente Parcial</option>
                        <option value="pendiente_entrega" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_entrega' ? 'selected' : ''; ?>>Pendiente Entrega</option>
                                                <option value="pendiente_pago_final" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_pago_final' ? 'selected' : ''; ?>>Pendiente Pago Final</option>
                        <option value="pendiente_verificacion" <?php echo ($_GET['estado_pago'] ?? '') == 'pendiente_verificacion' ? 'selected' : ''; ?>>Pendiente Verificación</option>
                        <option value="pagado" <?php echo ($_GET['estado_pago'] ?? '') == 'pagado' ? 'selected' : ''; ?>>Pagado</option>
                        <option value="cancelado" <?php echo ($_GET['estado_pago'] ?? '') == 'cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                    </select>
                </div>
                <div class="filtro-item">
                    <label>Moneda</label>
                    <select name="moneda" onchange="this.form.submit()">
                        <option value="">Todas</option>
                        <option value="USD" <?php echo ($_GET['moneda'] ?? '') == 'USD' ? 'selected' : ''; ?>>USD</option>
                        <option value="CUP" <?php echo ($_GET['moneda'] ?? '') == 'CUP' ? 'selected' : ''; ?>>CUP</option>
                    </select>
                </div>
                <div class="filtro-item filtro-fecha">
                    <label>Desde</label>
                    <input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>" onchange="this.form.submit()">
                </div>
                <div class="filtro-item filtro-fecha">
                    <label>Hasta</label>
                    <input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>" onchange="this.form.submit()">
                </div>
                <div class="filtros-botones">
                    <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
                    <a href="pagos.php" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
                </div>
            </div>
        </form>
    </div>

    <div class="tabla-pagos">
        <table id="tablaPagos">
            <thead>
                <tr>
                    <th class="checkbox-col"><input type="checkbox" class="select-all-checkbox" id="selectAll"></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'id', 'order_dir' => ($order_by == 'id' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Código <?php if ($order_by == 'id'): ?><?php echo $order_dir == 'ASC' ? '▲' : '▼'; ?><?php endif; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'cliente', 'order_dir' => ($order_by == 'cliente' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Cliente<?php if ($order_by == 'cliente'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'fecha', 'order_dir' => ($order_by == 'fecha' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Fecha<?php if ($order_by == 'fecha'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'total', 'order_dir' => ($order_by == 'total' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Total<?php if ($order_by == 'total'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'metodo', 'order_dir' => ($order_by == 'metodo' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Método<?php if ($order_by == 'metodo'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
                    <th>Estado API</th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'estado', 'order_dir' => ($order_by == 'estado' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>">Estado Pago<?php if ($order_by == 'estado'): ?><?php echo $order_dir == 'ASC' ? ' ▲' : ' ▼'; ?><?php endif; ?></a></th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($pedidos->num_rows > 0): ?>
                    <?php while($p = $pedidos->fetch_assoc()): 
                        $badge_class = '';
                        $estado_texto = '';
                        switch($p['estado_pago']) {
                            case 'pendiente':
                                $badge_class = 'badge-pendiente';
                                $estado_texto = 'Pendiente';
                                break;
                            case 'pendiente_parcial':
                                $badge_class = 'badge-pendiente_parcial';
                                $estado_texto = 'Pendiente Parcial';
                                break;
                            case 'pendiente_entrega':
                                $badge_class = 'badge-pendiente_entrega';
                                $estado_texto = 'Pendiente Entrega';
                                break;
                                                        case 'pendiente_pago_final':
                                $badge_class = 'badge-pendiente_pago_final';
                                $estado_texto = 'Pendiente Pago Final';
                                break;
                            case 'pendiente_verificacion':
                                $badge_class = 'badge-pendiente_verificacion';
                                $estado_texto = 'Pendiente Verificación';
                                break;
                            case 'pagado':
                                $badge_class = 'badge-pagado';
                                $estado_texto = 'Pagado';
                                break;
                            case 'cancelado':
                                $badge_class = 'badge-cancelado';
                                $estado_texto = 'Cancelado';
                                break;
                            default:
                                $badge_class = 'badge-pendiente';
                                $estado_texto = ucfirst(str_replace('_', ' ', $p['estado_pago']));
                        }
                        
                        $stmt_api = $conn->prepare("
                            SELECT estado FROM pedido_estados 
                            WHERE pedido_id = ? 
                              AND estado IN ('error_pasarela', 'pago_fallido', 'pago_confirmado', 'orden_aprobada')
                            ORDER BY id DESC LIMIT 1
                        ");
                        $estado_api = 'sin_registro';
                        if ($stmt_api) {
                            $stmt_api->bind_param("i", $p['id']);
                            $stmt_api->execute();
                            $res_api = $stmt_api->get_result()->fetch_assoc();
                            $stmt_api->close();
                            $estado_api = $res_api['estado'] ?? 'sin_registro';
                        }
                        
                        $api_badge = 'badge-api-sin';
                        $api_texto = '—';
                        
                        if ($estado_api === 'pago_confirmado') {
                            $api_badge = 'badge-api-ok';
                            $api_texto = '✅ OK';
                        } elseif ($estado_api === 'error_pasarela') {
                            $api_badge = 'badge-api-error';
                            $api_texto = '⚠️ Error';
                        } elseif ($estado_api === 'pago_fallido') {
                            $api_badge = 'badge-api-fallido';
                            $api_texto = '❌ Fallido';
                        } elseif ($estado_api === 'orden_aprobada') {
                            $api_badge = 'badge-api-pendiente';
                            $api_texto = '⏳ Pendiente';
                        }
                    ?>
                        <tr>
                            <td class="checkbox-col text-center"><input type="checkbox" class="checkbox-pedido" value="<?php echo $p['id']; ?>"></td>
                            <td style="font-weight: 600; color: #4a5568;"><?php echo htmlspecialchars($p['codigo']); ?></td>
                            <td><strong><?php echo htmlspecialchars($p['nombre'] . ' ' . $p['apellidos']); ?></strong><br><small><?php echo htmlspecialchars($p['email']); ?></small></td>
                            <td><?php echo date('d/m/Y', strtotime($p['fecha_pedido'])); ?></td>
                            <td>
    $<?php echo number_format($p['total_convertido'] ?? $p['total'], 2); ?> <?php echo htmlspecialchars($p['moneda']); ?>
    <?php if (floatval($p['monto_pagado'] ?? 0) > 0): ?>
        <br><small style="color: #f56565; text-decoration: line-through; font-weight: 600;">Pag: $<?php echo number_format($p['monto_pagado'], 2); ?> <?php echo htmlspecialchars($p['moneda']); ?></small>
    <?php endif; ?>
</td>
                            <td><?php echo ucfirst(htmlspecialchars($p['tipo_pago'])); ?></td>
                            <td><span class="badge-api <?php echo $api_badge; ?>"><?php echo $api_texto; ?></span></td>
                            <td>
    <span class="badge-estado-pago <?php echo $badge_class; ?>"><?php echo $estado_texto; ?></span>
    <?php if (floatval($p['monto_pendiente'] ?? 0) > 0): ?>
        <br><small style="color: #f56565; font-weight: 600;">Pend: $<?php echo number_format($p['monto_pendiente'], 2); ?> <?php echo htmlspecialchars($p['moneda']); ?></small>
    <?php endif; ?>
</td>
                            <td>
                                <button onclick="verDetallePedido(<?php echo $p['id']; ?>)" class="btn-accion btn-ver">👁️ Ver</button>
                                <?php if ($puede_gestionar): ?>
            <?php
    // ¿Se puede confirmar el pago?
    // - pendiente_entrega y pendiente_pago_final → solo si estado_actual = 'entregado'
    // - pendiente, pendiente_parcial, pendiente_verificacion → siempre
    $puede_confirmar_pago = false;
    $texto_boton_confirmar = '💰 Confirmar';
    $boton_deshabilitado = false;

    if (in_array($p['estado_pago'], ['pendiente', 'pendiente_parcial', 'pendiente_verificacion'])) {
        $puede_confirmar_pago = true;
    } elseif (in_array($p['estado_pago'], ['pendiente_entrega', 'pendiente_pago_final'])) {
        if (($p['estado_actual'] ?? '') === 'entregado') {
            $puede_confirmar_pago = true;
        } else {
            $puede_confirmar_pago = true; // se muestra el botón, pero deshabilitado
            $boton_deshabilitado = true;
            $texto_boton_confirmar = '⏳ Sin Entregar';
        }
    }

    if ($puede_confirmar_pago):
    ?>
        <?php if ($boton_deshabilitado): ?>
            <button type="button" class="btn-accion btn-confirmar" disabled style="opacity: 0.5; cursor: not-allowed;"><?php echo $texto_boton_confirmar; ?></button>
        <?php else: ?>
            <button onclick="mostrarModalConfirmar(<?php echo $p['id']; ?>, <?php echo floatval($p['monto_pendiente'] ?? 0); ?>, '<?php echo htmlspecialchars($p['codigo']); ?>', '<?php echo htmlspecialchars($p['nombre'] . ' ' . $p['apellidos']); ?>', '<?php echo htmlspecialchars(ucfirst($p['tipo_pago'])); ?>', '<?php echo htmlspecialchars($p['moneda']); ?>')" class="btn-accion btn-confirmar"><?php echo $texto_boton_confirmar; ?></button>
        <?php endif; ?>
    <?php endif; ?>
    
    <?php
    // ¿Se puede cancelar?
    $puede_cancelar_este = false;
    if (in_array($rol, ['Super Admin', 'Proveedor', 'Vendedor'])) {
        if (!in_array($p['estado_pago'], ['pagado', 'cancelado'])) {
            if ($rol === 'Vendedor' && floatval($p['monto_pagado'] ?? 0) > 0) {
                $puede_cancelar_este = false;
            } else {
                $puede_cancelar_este = true;
            }
        }
    }
    ?>
    <?php if ($puede_cancelar_este): ?>
        <form method="POST" action="pagos.php" style="display:inline;" onsubmit="return confirm('¿Cancelar este pago?')">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="cancelar_pedido" value="<?php echo intval($p['id']); ?>">
            <button type="submit" class="btn-accion btn-cancelar">❌ Cancelar</button>
        </form>
    <?php endif; ?>
<?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="9" class="text-center" style="padding:2rem;">📭 No hay pagos para mostrar</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php include __DIR__ . '/../includes/paginacion_botones.php'; ?>

    <div id="floatingCounter" class="floating-counter">0</div>

    <div id="floatingActionsMenu" class="floating-actions-menu">
    <?php if ($puede_gestionar): ?>
    <button id="btnConfirmarAccion">💰 Confirmar</button>
    <?php endif; ?>
    <?php if (in_array($rol, ['Super Admin', 'Proveedor', 'Vendedor'])): ?>
    <button id="btnCancelarAccion">❌ Cancelar</button>
    <?php endif; ?>
    <hr>
    <button id="btnLimpiarAccion">✖ Limpiar selección</button>
</div>

<!-- Form oculto para acciones múltiples (POST + CSRF) -->
<form id="formAccionMultiple" method="POST" action="pagos.php" style="display:none;">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="accion_multiple" id="accion_multiple_nombre" value="">
    <input type="hidden" name="accion_multiple_ids" id="accion_multiple_ids" value="">
</form>
</div>

<div id="modalConfirmarPago" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalConfirmarPago')">&times;</span>
        <h2>💰 Confirmar Pago</h2>
        <form method="POST" id="formConfirmarPago">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="confirmar_pago" value="1">
            <input type="hidden" name="pedido_id" id="confirmar_pago_id">
            <input type="hidden" name="tipo_pago_modal" id="tipo_pago_modal" value="exacto">
            
            <div style="margin-bottom: 1rem; padding: 0.75rem; background: #f7fafc; border-radius: 8px; font-size: 0.85rem;">
                <div><strong>Pedido:</strong> <span id="modal_pedido_codigo">—</span></div>
                <div><strong>Cliente:</strong> <span id="modal_pedido_cliente">—</span></div>
                <div><strong>Método:</strong> <span id="modal_pedido_metodo">—</span></div>
            </div>
            
            <div style="margin-bottom: 1rem;">
                <div style="font-size: 1.1rem; font-weight: 600; color: #2d3748; margin-bottom: 0.5rem;">
                    💰 Saldo pendiente: <span id="monto_pendiente_display">—</span> <span id="modal_moneda">—</span>
                </div>
            </div>
            
            <div style="margin-bottom: 1rem; padding: 1rem; border: 2px solid #48bb78; border-radius: 8px; background: #f0fff4;">
                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-weight: 600; color: #22543d;">
                    <input type="checkbox" id="check_pago_exacto" checked style="width: 20px; height: 20px; cursor: pointer;">
                    El cliente pagó el monto pendiente exacto
                </label>
            </div>
            
            <div style="margin-bottom: 1rem; padding: 1rem; border: 2px solid #e2e8f0; border-radius: 8px; background: #fff;">
                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-weight: 600; color: #4a5568; margin-bottom: 0.75rem;">
                    <input type="checkbox" id="check_pago_diferente" style="width: 20px; height: 20px; cursor: pointer;">
                    El cliente pagó un monto diferente
                </label>
                
                <label for="monto_manual" style="display:block; font-weight:600; margin-bottom:0.5rem; color:#4a5568; font-size: 0.85rem;">
                    Monto pagado real:
                </label>
                <input type="number" 
                       name="monto_manual" 
                       id="monto_manual" 
                       step="0.01" 
                       min="0.01" 
                       required
                       readonly
                       style="width:100%; padding:0.6rem; border:1px solid #e2e8f0; border-radius:8px; font-size:1rem; background: #edf2f7;">
                <small id="aviso_monto" style="display:block; margin-top:0.3rem; color:#718096; font-size: 0.8rem;">
                    Saldo pendiente: <span id="monto_pendiente_ref">—</span>
                </small>
            </div>
            
            <div style="display: flex; gap: 0.5rem;">
                <button type="button" onclick="cerrarModal('modalConfirmarPago')" class="btn-cancelar-modal" style="flex: 1; padding: 0.8rem; background: #edf2f7; color: #4a5568; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer;">Cancelar</button>
                <button type="submit" class="btn-confirmar-modal" id="btn_confirmar_modal" style="flex: 2; margin-top: 0;">✓ Sí, confirmar pago</button>
            </div>
        </form>
    </div>
</div>

<div id="modalDetallePedido" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalDetallePedido')">&times;</span>
        <div id="contenidoDetallePedido">Cargando...</div>
    </div>
</div>

<script>
let seleccionados = new Set();

function guardarSeleccion() { sessionStorage.setItem('pedidosSeleccionados', JSON.stringify([...seleccionados])); }
function cargarSeleccion() {
    const guardados = sessionStorage.getItem('pedidosSeleccionados');
    if (guardados) { seleccionados = new Set(JSON.parse(guardados)); actualizarTodo(); }
}
function actualizarCheckboxes() {
    document.querySelectorAll('.checkbox-pedido').forEach(cb => cb.checked = seleccionados.has(parseInt(cb.value)));
    const total = document.querySelectorAll('.checkbox-pedido').length;
    const seleccionadosEnPagina = document.querySelectorAll('.checkbox-pedido:checked').length;
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.checked = total > 0 && seleccionadosEnPagina === total;
        selectAll.indeterminate = seleccionadosEnPagina > 0 && seleccionadosEnPagina < total;
    }
}
function actualizarContador() {
    const count = seleccionados.size;
    const floatingCounter = document.getElementById('floatingCounter');
    if (floatingCounter) {
        if (count > 0) {
            if (window.innerWidth > 768) {
                floatingCounter.textContent = count + (count === 1 ? ' seleccionado' : ' seleccionados');
            } else {
                floatingCounter.textContent = count;
            }
            floatingCounter.classList.add('show');
        } else {
            floatingCounter.classList.remove('show');
        }
    }
}
function actualizarTodo() { actualizarCheckboxes(); actualizarContador(); }

document.addEventListener('change', function(e) {
    if (e.target.classList.contains('checkbox-pedido')) {
        const id = parseInt(e.target.value);
        e.target.checked ? seleccionados.add(id) : seleccionados.delete(id);
        actualizarTodo(); guardarSeleccion();
    }
    if (e.target.id === 'selectAll') {
        document.querySelectorAll('.checkbox-pedido').forEach(cb => { cb.checked = e.target.checked; const id = parseInt(cb.value); e.target.checked ? seleccionados.add(id) : seleccionados.delete(id); });
        actualizarTodo(); guardarSeleccion();
    }
});

function ejecutarAccion(accion, ids) {
    if (ids.length === 0) return;
    document.getElementById('accion_multiple_nombre').value = accion;
    document.getElementById('accion_multiple_ids').value = JSON.stringify(ids);
    document.getElementById('formAccionMultiple').submit();
}

document.getElementById('btnConfirmarAccion')?.addEventListener('click', () => {
    if (seleccionados.size && confirm(`¿Confirmar ${seleccionados.size} pedido(s)?`)) ejecutarAccion('confirmar_multiple', [...seleccionados]);
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('btnCancelarAccion')?.addEventListener('click', () => {
    if (seleccionados.size && confirm(`¿Cancelar ${seleccionados.size} pedido(s)?`)) ejecutarAccion('cancelar_multiple', [...seleccionados]);
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('btnLimpiarAccion')?.addEventListener('click', () => {
    seleccionados.clear(); actualizarTodo(); guardarSeleccion();
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});

document.getElementById('floatingCounter')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('floatingActionsMenu')?.classList.toggle('show');
});
document.addEventListener('click', (e) => {
    if (!e.target.closest('#floatingCounter') && !e.target.closest('#floatingActionsMenu')) {
        document.getElementById('floatingActionsMenu')?.classList.remove('show');
    }
});

function verDetallePedido(pedidoId) {
    const modal = document.getElementById('modalDetallePedido');
    const contenido = document.getElementById('contenidoDetallePedido');
    modal.style.display = 'block';
    contenido.innerHTML = '<div style="text-align:center;padding:2rem;">🔄 Cargando...</div>';
    fetch('detalle_pedido_json.php?id=' + pedidoId).then(r => r.text()).then(html => contenido.innerHTML = html).catch(() => contenido.innerHTML = '<div style="text-align:center;padding:2rem;color:#f56565;">❌ Error</div>');
}
function mostrarModalConfirmar(pedidoId, montoPendiente, codigo, cliente, metodo, moneda) { 
    document.getElementById('confirmar_pago_id').value = pedidoId; 
    document.getElementById('monto_pendiente_display').textContent = montoPendiente.toFixed(2);
    document.getElementById('monto_pendiente_ref').textContent = montoPendiente.toFixed(2);
    document.getElementById('modal_pedido_codigo').textContent = codigo || '—';
    document.getElementById('modal_pedido_cliente').textContent = cliente || '—';
    document.getElementById('modal_pedido_metodo').textContent = metodo || '—';
    document.getElementById('modal_moneda').textContent = moneda || 'USD';
    
    document.getElementById('check_pago_exacto').checked = true;
    document.getElementById('check_pago_diferente').checked = false;
    document.getElementById('tipo_pago_modal').value = 'exacto';
    document.getElementById('monto_manual').value = montoPendiente.toFixed(2);
    document.getElementById('monto_manual').readOnly = true;
    document.getElementById('monto_manual').style.background = '#edf2f7';
    document.getElementById('aviso_monto').innerHTML = 'Saldo pendiente: <span id="monto_pendiente_ref">' + montoPendiente.toFixed(2) + '</span>';
    document.getElementById('aviso_monto').style.color = '#718096';
    document.getElementById('btn_confirmar_modal').disabled = false;
    
    document.getElementById('modalConfirmarPago').style.display = 'block'; 
}

document.getElementById('check_pago_exacto')?.addEventListener('change', function() {
    if (this.checked) {
        document.getElementById('check_pago_diferente').checked = false;
        document.getElementById('tipo_pago_modal').value = 'exacto';
        document.getElementById('monto_manual').value = document.getElementById('monto_pendiente_display').textContent;
        document.getElementById('monto_manual').readOnly = true;
        document.getElementById('monto_manual').style.background = '#edf2f7';
        document.getElementById('btn_confirmar_modal').disabled = false;
    }
});

document.getElementById('check_pago_diferente')?.addEventListener('change', function() {
    if (this.checked) {
        document.getElementById('check_pago_exacto').checked = false;
        document.getElementById('tipo_pago_modal').value = 'diferente';
        document.getElementById('monto_manual').readOnly = false;
        document.getElementById('monto_manual').style.background = '#fff';
        document.getElementById('monto_manual').focus();
        document.getElementById('monto_manual').select();
    }
});

document.getElementById('monto_manual')?.addEventListener('input', function() {
    const montoPendiente = parseFloat(document.getElementById('monto_pendiente_display').textContent) || 0;
    const montoActual = parseFloat(this.value) || 0;
    
    if (montoActual <= 0) {
        document.getElementById('btn_confirmar_modal').disabled = true;
        document.getElementById('aviso_monto').innerHTML = '⚠️ El monto debe ser mayor a 0';
        document.getElementById('aviso_monto').style.color = '#c53030';
    } else if (montoActual > montoPendiente + 0.01) {
        document.getElementById('btn_confirmar_modal').disabled = true;
        document.getElementById('aviso_monto').innerHTML = '⚠️ El monto excede el saldo pendiente (' + montoPendiente.toFixed(2) + ')';
        document.getElementById('aviso_monto').style.color = '#c53030';
    } else if (montoActual < montoPendiente - 0.01) {
        document.getElementById('btn_confirmar_modal').disabled = false;
        document.getElementById('aviso_monto').innerHTML = '✅ Monto válido. Quedará saldo pendiente de ' + (montoPendiente - montoActual).toFixed(2);
        document.getElementById('aviso_monto').style.color = '#22543d';
    } else {
        document.getElementById('btn_confirmar_modal').disabled = false;
        document.getElementById('aviso_monto').innerHTML = '✅ Monto válido (pago completo)';
        document.getElementById('aviso_monto').style.color = '#22543d';
    }
});

function cerrarModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

document.addEventListener('DOMContentLoaded', () => { cargarSeleccion(); });
document.querySelector('.filtros-form')?.addEventListener('submit', () => guardarSeleccion());
document.querySelectorAll('.btn-pagina').forEach(link => link.addEventListener('click', () => guardarSeleccion()));
window.onclick = (event) => { if (event.target.classList.contains('modal')) event.target.style.display = 'none'; };
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') document.querySelectorAll('.modal').forEach(m => m.style.display = 'none'); });
window.addEventListener('resize', () => actualizarContador());
</script>

<?php $conn->close(); ?>
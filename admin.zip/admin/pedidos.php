<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================
// CONFIGURACIÓN DE SESIÓN SEGURA
// ============================================
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/csrf.php';

// ============================================
// DETECCIÓN DE PROVEEDOR (ÚNICA VEZ, ANTES DEL HEADER)
// ============================================
$rol = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

$proveedor_id_usuario = obtenerProveedorId($conn, $usuario_id_actual, $rol);
$es_proveedor = esRolProveedor($rol);

if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
    if ($stmt_check) {
        $stmt_check->bind_param("i", $proveedor_id_usuario);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows === 0) {
            $stmt_check->close();
            $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
            $_SESSION['tipo_mensaje'] = 'error';
            header('Location: /admin.php');
            exit;
        }
        $stmt_check->close();
    }
}

// ============================================
// VERIFICAR PROPIEDAD DEL PEDIDO
// ============================================
function verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario) {
    if ($proveedor_id_usuario == 0) {
        return true;
    }
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM pedido_detalles WHERE pedido_id = ? AND proveedor_id = ?");
    $stmt->bind_param("ii", $pedido_id, $proveedor_id_usuario);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result['total'] > 0;
}

// ============================================
// HELPER: Encolar correo (no bloquea el POST)
// ============================================
function encolarCorreoPedidoSeguro($conn, $pedido_id, $accion) {
    try {
        require_once dirname(__DIR__) . '/includes/cola_correos.php';
        require_once dirname(__DIR__) . '/includes/email_functions.php';

        $stmt = $conn->prepare("SELECT c.email, p.codigo FROM pedidos p JOIN clientes c ON p.cliente_id = c.id WHERE p.id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $info = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!empty($info['email']) && filter_var($info['email'], FILTER_VALIDATE_EMAIL)) {
            $asuntos = [
                'empaquetado' => 'Pedido empaquetado',
                'entregado'   => 'Pedido entregado',
                'cancelado'   => 'Pedido cancelado',
                'incidencia'  => 'Incidencia en tu pedido',
            ];
            $asunto = ($asuntos[$accion] ?? 'Actualización') . ' - Pedido ' . ($info['codigo'] ?? '');
            encolarCorreo($conn, $info['email'], $asunto, $accion, null, $pedido_id);
        }
    } catch (Throwable $e) {
        error_log('[admin/pedidos.php] Error encolando correo pedido #' . $pedido_id . ': ' . $e->getMessage());
    }
}

// ============================================
// FUNCIÓN: Validar transición de estado según rol
// ============================================
function validarTransicionEstado($rol, $estado_actual, $nuevo_estado) {
    // Super Admin: cualquier transición excepto desde cancelado y entregado solo a incidencia
    if ($rol === 'Super Admin') {
        if ($estado_actual === 'cancelado') return false;
        if ($estado_actual === 'entregado' && $nuevo_estado !== 'incidencia') return false;
        return true;
    }
    
    // Gerente: cualquier transición excepto a cancelado, desde cancelado, y entregado solo a incidencia
    if ($rol === 'Gerente') {
        if ($nuevo_estado === 'cancelado') return false;
        if ($estado_actual === 'cancelado') return false;
        if ($estado_actual === 'entregado' && $nuevo_estado !== 'incidencia') return false;
        return true;
    }
    
        // Proveedor: desde pago_confirmado puede empaquetar, transporte, entregado, incidencia, cancelado
    if ($rol === 'Proveedor') {
        $transiciones = [
            'pendiente_pago'         => ['cancelado'],
            'pendiente_parcial'      => ['cancelado'],
            'pendiente_entrega'      => ['cancelado', 'empaquetado'],
            'pendiente_entrega_pago' => ['cancelado', 'empaquetado'],
            'pendiente_verificacion' => ['cancelado'],
            'pago_confirmado'        => ['cancelado', 'empaquetado', 'transporte', 'entregado', 'incidencia'],
            'pagado'                 => ['cancelado', 'empaquetado'],
            'empaquetado'            => ['cancelado', 'transporte', 'entregado', 'incidencia'],
            'transporte'             => ['cancelado', 'entregado', 'incidencia'],
            'entregado'              => ['incidencia'],
            'incidencia'             => ['cancelado', 'empaquetado'],
            'cancelado'              => [],
        ];
        return in_array($nuevo_estado, $transiciones[$estado_actual] ?? []);
    }
    
        // Vendedor: desde pago_confirmado puede empaquetar, transporte, incidencia (no entregado)
    if ($rol === 'Vendedor') {
        $transiciones = [
            'pago_confirmado'        => ['empaquetado', 'transporte', 'incidencia'],
            'pagado'                 => ['empaquetado', 'incidencia'],
            'pendiente_entrega'      => ['empaquetado', 'incidencia'],
            'pendiente_entrega_pago' => ['empaquetado', 'incidencia'],
        ];
        return in_array($nuevo_estado, $transiciones[$estado_actual] ?? []);
    }
    
       // Empaquetador: desde pago_confirmado puede empaquetar, transporte, incidencia (no entregado)
    if ($rol === 'Empaquetador') {
        $transiciones = [
            'pago_confirmado' => ['empaquetado', 'transporte', 'incidencia'],
            'empaquetado'     => ['transporte', 'incidencia'],
        ];
        return in_array($nuevo_estado, $transiciones[$estado_actual] ?? []);
    }
    
    // Transportista
    if ($rol === 'Transportista') {
        $transiciones = [
            'transporte' => ['entregado', 'incidencia'],
        ];
        return in_array($nuevo_estado, $transiciones[$estado_actual] ?? []);
    }
    
    // Supervisor, Contador, Inventario: no pueden cambiar estado
    return false;
}

// ============================================
// PROCESAR ACCIONES
// ============================================
$mensaje = '';
$tipo_mensaje = '';

// ============================================
// VALIDACIÓN CSRF EN POST
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!function_exists('csrf_validar') || !csrf_validar($token)) {
        error_log("[admin/pedidos.php] CSRF inválido. Usuario: $usuario_id_actual");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: pedidos.php');
        exit;
    }
}

// ----- EMPAQUETADO (Empaquetador) -----
if (isset($_POST['confirmar_empaquetado'])) {
    $pedido_id = intval($_POST['pedido_id']);
    $incidencia = $_POST['incidencia'] ?? '';

    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pedido';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    // Validar estado actual
        $stmt_estado = $conn->prepare("SELECT estado_actual FROM pedidos WHERE id = ?");
    $estado_actual = '';
    if ($stmt_estado) {
        $stmt_estado->bind_param("i", $pedido_id);
        $stmt_estado->execute();
        $estado_actual = $stmt_estado->get_result()->fetch_assoc()['estado_actual'] ?? '';
        $stmt_estado->close();
    }

    $estados_validos_empaquetar = ['pagado', 'pendiente_entrega', 'pendiente_entrega_pago'];
    if (!in_array($estado_actual, $estados_validos_empaquetar)) {
        $_SESSION['mensaje'] = '❌ Este pedido no está en estado para empaquetar';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'empaquetado', ?, ?)");
        $stmt->bind_param("iis", $pedido_id, $_SESSION['usuario_id'], $incidencia);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("UPDATE pedidos SET estado_actual = 'empaquetado', fecha_empaquetado = NOW() WHERE id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[admin/pedidos.php] Error empaquetado #' . $pedido_id . ': ' . $e->getMessage());
        $_SESSION['mensaje'] = '❌ Error al empaquetar';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    encolarCorreoPedidoSeguro($conn, $pedido_id, 'empaquetado');

    $_SESSION['mensaje'] = "✅ Pedido confirmado como empaquetado";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>window.location.href="pedidos.php";</script>';
    exit;
}

// ----- ENTREGA (Transportista) -----
if (isset($_POST['confirmar_entrega'])) {
    $pedido_id = intval($_POST['pedido_id']);
    $no_entrega = $_POST['no_entrega'] ?? '';
    $motivo = $_POST['no_entrega_desc'] ?? $no_entrega;

    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pedido';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    // Validar estado actual
        $stmt_estado = $conn->prepare("SELECT estado_actual FROM pedidos WHERE id = ?");
    $estado_actual = '';
    if ($stmt_estado) {
        $stmt_estado->bind_param("i", $pedido_id);
        $stmt_estado->execute();
        $estado_actual = $stmt_estado->get_result()->fetch_assoc()['estado_actual'] ?? '';
        $stmt_estado->close();
    }

    if ($estado_actual !== 'empaquetado') {
        $_SESSION['mensaje'] = '❌ Este pedido no está listo para entrega';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    $estado = empty($no_entrega) ? 'entregado' : 'incidencia';
    $observacion = empty($no_entrega) ? 'Entrega exitosa' : "No entregado: $motivo";

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $pedido_id, $estado, $_SESSION['usuario_id'], $observacion);
        $stmt->execute();
        $stmt->close();

        if (empty($no_entrega)) {
            $stmt = $conn->prepare("UPDATE pedidos SET estado_actual = 'entregado', fecha_entregado = NOW() WHERE id = ?");
            $stmt->bind_param("i", $pedido_id);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $conn->prepare("UPDATE pedidos SET estado_actual = 'incidencia' WHERE id = ?");
            $stmt->bind_param("i", $pedido_id);
            $stmt->execute();
            $stmt->close();
        }

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[admin/pedidos.php] Error entrega #' . $pedido_id . ': ' . $e->getMessage());
        $_SESSION['mensaje'] = '❌ Error al confirmar la entrega';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    if (empty($no_entrega)) {
        encolarCorreoPedidoSeguro($conn, $pedido_id, 'entregado');
    }

    $_SESSION['mensaje'] = empty($no_entrega) ? "✅ Entrega confirmada" : "⚠️ Incidencia registrada";
    $_SESSION['tipo_mensaje'] = empty($no_entrega) ? "exito" : "warning";
    echo '<script>window.location.href="pedidos.php";</script>';
    exit;
}

// ----- CAMBIO MANUAL DE ESTADO (Admin/Supervisor) -----
if (isset($_POST['cambiar_estado'])) {
    $pedido_id = intval($_POST['pedido_id']);
    $nuevo_estado = $_POST['nuevo_estado'];
    $observaciones = $_POST['observaciones_estado'] ?? 'Cambio manual por administrador';

    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pedido';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    if (!$pedido_id || !$nuevo_estado) {
        $_SESSION['mensaje'] = "❌ Error: Datos incompletos";
        $_SESSION['tipo_mensaje'] = "error";
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

        $estados_validos = ['pendiente_pago','pendiente_parcial','pendiente_entrega','pendiente_entrega_pago','pendiente_verificacion','pago_confirmado','empaquetado','transporte','entregado','cancelado','incidencia'];
    if (!in_array($nuevo_estado, $estados_validos)) {
        $_SESSION['mensaje'] = "❌ Estado no válido";
        $_SESSION['tipo_mensaje'] = "error";
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    // Validar transición según estado actual y rol
        $stmt_estado_actual = $conn->prepare("SELECT estado_actual FROM pedidos WHERE id = ?");
    $estado_actual_pedido = '';
    if ($stmt_estado_actual) {
        $stmt_estado_actual->bind_param("i", $pedido_id);
        $stmt_estado_actual->execute();
        $estado_actual_pedido = $stmt_estado_actual->get_result()->fetch_assoc()['estado_actual'] ?? '';
        $stmt_estado_actual->close();
    }

        if (!validarTransicionEstado($rol, $estado_actual_pedido, $nuevo_estado)) {
        $_SESSION['mensaje'] = "❌ No se puede cambiar de '{$estado_actual_pedido}' a '{$nuevo_estado}' con tu rol";
        $_SESSION['tipo_mensaje'] = "error";
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    // ============================================
    // VALIDACIÓN ESPECIAL: Vendedor solo puede cancelar si no hay pagos
    // ============================================
    if ($nuevo_estado === 'cancelado' && $rol === 'Vendedor') {
        $stmt_mp = $conn->prepare("SELECT monto_pagado FROM pedidos WHERE id = ?");
        $stmt_mp->bind_param("i", $pedido_id);
        $stmt_mp->execute();
        $mp_data = $stmt_mp->get_result()->fetch_assoc();
        $stmt_mp->close();
        if (floatval($mp_data['monto_pagado'] ?? 0) > 0) {
            $_SESSION['mensaje'] = '❌ No puedes cancelar un pedido con pagos realizados';
            $_SESSION['tipo_mensaje'] = 'error';
            echo '<script>window.location.href="pedidos.php";</script>';
            exit;
        }
    }

    // ============================================
    // VALIDACIÓN ESPECIAL: si está entregado, solo Super Admin y Proveedor
    // ============================================
    if ($nuevo_estado === 'cancelado' && $estado_actual_pedido === 'entregado') {
        if (!in_array($rol, ['Super Admin', 'Proveedor'], true)) {
            $_SESSION['mensaje'] = '❌ Solo Super Admin y Proveedor pueden cancelar un pedido entregado';
            $_SESSION['tipo_mensaje'] = 'error';
            echo '<script>window.location.href="pedidos.php";</script>';
            exit;
        }
    }

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isis", $pedido_id, $nuevo_estado, $_SESSION['usuario_id'], $observaciones);
        $stmt->execute();
        $stmt->close();

        $stmt2 = $conn->prepare("UPDATE pedidos SET estado_actual = ? WHERE id = ?");
        $stmt2->bind_param("si", $nuevo_estado, $pedido_id);
        $stmt2->execute();
        $stmt2->close();

               if ($nuevo_estado == 'cancelado') {
            $stmt3 = $conn->prepare("SELECT producto_id, combo_id, cantidad FROM pedido_detalles WHERE pedido_id = ?");
            $stmt3->bind_param("i", $pedido_id);
            $stmt3->execute();
            $productos = $stmt3->get_result();
            $stmt3->close();

            while ($item = $productos->fetch_assoc()) {
                if (intval($item['producto_id']) > 0) {
                    $stmt4 = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                    $stmt4->bind_param("ii", $item['cantidad'], $item['producto_id']);
                    $stmt4->execute();
                    $stmt4->close();
                } elseif (intval($item['combo_id']) > 0) {
                    $combo_id = intval($item['combo_id']);
                    $cant_combo = intval($item['cantidad']);

                    $stmt_c = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                    $stmt_c->bind_param("ii", $cant_combo, $combo_id);
                    $stmt_c->execute();
                    $stmt_c->close();

                    $stmt_cp = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                    $stmt_cp->bind_param("i", $combo_id);
                    $stmt_cp->execute();
                    $prod_internos = $stmt_cp->get_result();
                    $stmt_cp->close();

                    while ($pi = $prod_internos->fetch_assoc()) {
                        $stock_devolver = intval($pi['cantidad']) * $cant_combo;
                        $stmt_pi = $conn->prepare("
                            UPDATE productos 
                            SET cantidad = cantidad + ?,
                                reservado_por_combos = reservado_por_combos + ?,
                                fecha_actualizacion_reserva = NOW(),
                                en_combo = 1,
                                fecha_agotado = NULL
                            WHERE id = ?
                        ");
                        $stmt_pi->bind_param("iii", $stock_devolver, $stock_devolver, $pi['producto_id']);
                        $stmt_pi->execute();
                        $stmt_pi->close();
                    }
                }
            }
        }

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[admin/pedidos.php] Error cambiar_estado #' . $pedido_id . ': ' . $e->getMessage());
        $_SESSION['mensaje'] = '❌ Error al cambiar el estado';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    encolarCorreoPedidoSeguro($conn, $pedido_id, $nuevo_estado);

    $_SESSION['mensaje'] = "✅ Estado cambiado a: " . ucfirst($nuevo_estado);
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>window.location.href="pedidos.php";</script>';
    exit;
}

// ----- CANCELACIÓN INDIVIDUAL -----
if (isset($_GET['cancelar_pedido'])) {
    $token_csrf = $_GET['csrf_token'] ?? '';
    if (!function_exists('csrf_validar') || !csrf_validar($token_csrf)) {
        error_log("[admin/pedidos.php] CSRF inválido en cancelar_pedido. Usuario: $usuario_id_actual");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: pedidos.php');
        exit;
    }
    
    $pedido_id = intval($_GET['cancelar_pedido']);
    $motivo = $_GET['motivo'] ?? 'Cancelado por administrador';

    if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para modificar este pedido';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

        // Validar rol (Super Admin, Proveedor y Vendedor pueden cancelar)
    if (!in_array($rol, ['Super Admin', 'Proveedor', 'Vendedor'])) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para cancelar pedidos';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

// Validar estado
$stmt_validar = $conn->prepare("SELECT estado_actual FROM pedidos WHERE id = ?");
$datos_validar = null;
if ($stmt_validar) {
    $stmt_validar->bind_param("i", $pedido_id);
    $stmt_validar->execute();
    $datos_validar = $stmt_validar->get_result()->fetch_assoc();
    $stmt_validar->close();
}

if ($rol === 'Super Admin') {
    if ($datos_validar && $datos_validar['estado_actual'] === 'cancelado') {
        $_SESSION['mensaje'] = '❌ Este pedido ya está cancelado';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }
} elseif ($rol === 'Proveedor') {
    if ($datos_validar && $datos_validar['estado_actual'] === 'cancelado') {
        $_SESSION['mensaje'] = '❌ Este pedido ya está cancelado';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }
} elseif ($rol === 'Vendedor') {
    if ($datos_validar && $datos_validar['estado_actual'] === 'cancelado') {
        $_SESSION['mensaje'] = '❌ Este pedido ya está cancelado';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }
    if ($datos_validar && $datos_validar['estado_actual'] === 'entregado') {
        $_SESSION['mensaje'] = '❌ No puedes cancelar un pedido entregado';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }
    $stmt_mp = $conn->prepare("SELECT monto_pagado FROM pedidos WHERE id = ?");
    $stmt_mp->bind_param("i", $pedido_id);
    $stmt_mp->execute();
    $mp_data = $stmt_mp->get_result()->fetch_assoc();
    $stmt_mp->close();
    if (floatval($mp_data['monto_pagado'] ?? 0) > 0) {
        $_SESSION['mensaje'] = '❌ No puedes cancelar un pedido con pagos realizados';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }
}

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'cancelado', ?, ?)");
        $stmt->bind_param("iis", $pedido_id, $_SESSION['usuario_id'], $motivo);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("UPDATE pedidos SET estado_actual = 'cancelado' WHERE id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $stmt->close();

               $stmt = $conn->prepare("SELECT producto_id, combo_id, cantidad FROM pedido_detalles WHERE pedido_id = ?");
        $stmt->bind_param("i", $pedido_id);
        $stmt->execute();
        $productos = $stmt->get_result();
        $stmt->close();

        while ($item = $productos->fetch_assoc()) {
            if (intval($item['producto_id']) > 0) {
                $stmt2 = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                $stmt2->bind_param("ii", $item['cantidad'], $item['producto_id']);
                $stmt2->execute();
                $stmt2->close();
            } elseif (intval($item['combo_id']) > 0) {
                $combo_id = intval($item['combo_id']);
                $cant_combo = intval($item['cantidad']);

                // 1. Devolver stock del combo
                $stmt_c = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                $stmt_c->bind_param("ii", $cant_combo, $combo_id);
                $stmt_c->execute();
                $stmt_c->close();

                // 2. Devolver stock de productos internos del combo
                $stmt_cp = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                $stmt_cp->bind_param("i", $combo_id);
                $stmt_cp->execute();
                $prod_internos = $stmt_cp->get_result();
                $stmt_cp->close();

                while ($pi = $prod_internos->fetch_assoc()) {
                    $stock_devolver = intval($pi['cantidad']) * $cant_combo;
                    $stmt_pi = $conn->prepare("
                        UPDATE productos 
                        SET cantidad = cantidad + ?,
                            reservado_por_combos = reservado_por_combos + ?,
                            fecha_actualizacion_reserva = NOW(),
                            en_combo = 1,
                            fecha_agotado = NULL
                        WHERE id = ?
                    ");
                    $stmt_pi->bind_param("iii", $stock_devolver, $stock_devolver, $pi['producto_id']);
                    $stmt_pi->execute();
                    $stmt_pi->close();
                }
            }
        }

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[admin/pedidos.php] Error cancelar #' . $pedido_id . ': ' . $e->getMessage());
        $_SESSION['mensaje'] = '❌ Error al cancelar el pedido';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    encolarCorreoPedidoSeguro($conn, $pedido_id, 'cancelado');

    $_SESSION['mensaje'] = "✅ Pedido cancelado";
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>window.location.href="pedidos.php";</script>';
    exit;
}

// ============================================
// ACCIONES MASIVAS
// ============================================

// Cambio masivo de estado
if (isset($_POST['cambiar_estado_multiple'])) {
    $ids = json_decode($_POST['cambiar_estado_multiple_ids'], true);
    $nuevo_estado = $_POST['nuevo_estado_masivo'];
    $observaciones = $_POST['observaciones_masivo'] ?? 'Cambio masivo por administrador';

    $estados_validos = ['pendiente_pago','pendiente_parcial','pendiente_entrega','pendiente_entrega_pago','pendiente_verificacion','pago_confirmado','empaquetado','transporte','entregado','cancelado','incidencia'];

    if (!in_array($nuevo_estado, $estados_validos)) {
        $_SESSION['mensaje'] = "❌ Estado no válido";
        $_SESSION['tipo_mensaje'] = "error";
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }

    if (!is_array($ids)) $ids = [];

        $contador = 0;
    $errores = 0;

    foreach ($ids as $pedido_id) {
        $pedido_id = intval($pedido_id);

        if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
            $errores++;
            continue;
        }

        $stmt_check = $conn->prepare("SELECT id, estado_actual FROM pedidos WHERE id = ?");
        $stmt_check->bind_param("i", $pedido_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        if ($result_check->num_rows == 0) { $stmt_check->close(); $errores++; continue; }
        $estado_actual_pedido = $result_check->fetch_assoc()['estado_actual'];
        $stmt_check->close();

                // Validar transición según estado actual y rol
        if (!validarTransicionEstado($rol, $estado_actual_pedido, $nuevo_estado)) {
            $errores++;
            continue;
        }

        // VALIDACIÓN ESPECIAL: Vendedor solo puede cancelar si no hay pagos
        if ($nuevo_estado === 'cancelado' && $rol === 'Vendedor') {
            $stmt_mp = $conn->prepare("SELECT monto_pagado FROM pedidos WHERE id = ?");
            $stmt_mp->bind_param("i", $pedido_id);
            $stmt_mp->execute();
            $mp_data = $stmt_mp->get_result()->fetch_assoc();
            $stmt_mp->close();
            if (floatval($mp_data['monto_pagado'] ?? 0) > 0) {
                $errores++;
                continue;
            }
        }

        // VALIDACIÓN ESPECIAL: si está entregado, solo Super Admin y Proveedor
        if ($nuevo_estado === 'cancelado' && $estado_actual_pedido === 'entregado') {
            if (!in_array($rol, ['Super Admin', 'Proveedor'], true)) {
                $errores++;
                continue;
            }
        }

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isis", $pedido_id, $nuevo_estado, $_SESSION['usuario_id'], $observaciones);
            $stmt->execute();
            $stmt->close();

            $stmt2 = $conn->prepare("UPDATE pedidos SET estado_actual = ? WHERE id = ?");
            $stmt2->bind_param("si", $nuevo_estado, $pedido_id);
            $stmt2->execute();
            $stmt2->close();

                        if ($nuevo_estado == 'cancelado') {
                $stmt3 = $conn->prepare("SELECT producto_id, combo_id, cantidad FROM pedido_detalles WHERE pedido_id = ?");
                $stmt3->bind_param("i", $pedido_id);
                $stmt3->execute();
                $productos = $stmt3->get_result();
                $stmt3->close();

                while ($item = $productos->fetch_assoc()) {
                    if (intval($item['producto_id']) > 0) {
                        $stmt4 = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                        $stmt4->bind_param("ii", $item['cantidad'], $item['producto_id']);
                        $stmt4->execute();
                        $stmt4->close();
                    } elseif (intval($item['combo_id']) > 0) {
                        $combo_id = intval($item['combo_id']);
                        $cant_combo = intval($item['cantidad']);

                        $stmt_c = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                        $stmt_c->bind_param("ii", $cant_combo, $combo_id);
                        $stmt_c->execute();
                        $stmt_c->close();

                        $stmt_cp = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                        $stmt_cp->bind_param("i", $combo_id);
                        $stmt_cp->execute();
                        $prod_internos = $stmt_cp->get_result();
                        $stmt_cp->close();

                        while ($pi = $prod_internos->fetch_assoc()) {
                            $stock_devolver = intval($pi['cantidad']) * $cant_combo;
                            $stmt_pi = $conn->prepare("
                                UPDATE productos 
                                SET cantidad = cantidad + ?,
                                    reservado_por_combos = reservado_por_combos + ?,
                                    fecha_actualizacion_reserva = NOW(),
                                    en_combo = 1,
                                    fecha_agotado = NULL
                                WHERE id = ?
                            ");
                            $stmt_pi->bind_param("iii", $stock_devolver, $stock_devolver, $pi['producto_id']);
                            $stmt_pi->execute();
                            $stmt_pi->close();
                        }
                    }
                }
            }

            $conn->commit();
            $contador++;

            encolarCorreoPedidoSeguro($conn, $pedido_id, $nuevo_estado);
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[admin/pedidos.php] Error masivo #' . $pedido_id . ': ' . $e->getMessage());
            $errores++;
        }
    }

    $_SESSION['mensaje'] = "✅ $contador pedido(s) cambiado(s) a: " . ucfirst($nuevo_estado) . ($errores > 0 ? " ($errores con error)" : "");
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pedidos.php?t=' . time() . '";</script>';
    exit;
}

// Cancelación masiva
if (isset($_POST['cancelar_multiple'])) {
    if (!in_array($rol, ['Super Admin', 'Proveedor', 'Vendedor'])) {
        $_SESSION['mensaje'] = '❌ No tienes permiso para cancelar pedidos';
        $_SESSION['tipo_mensaje'] = 'error';
        echo '<script>window.location.href="pedidos.php";</script>';
        exit;
    }
    
    $ids = json_decode($_POST['cancelar_multiple'], true);
    if (!is_array($ids)) $ids = [];

    $contador = 0;
    $errores = 0;

    foreach ($ids as $pedido_id) {
        $pedido_id = intval($pedido_id);

        if (!verificarPropiedadPedido($conn, $pedido_id, $proveedor_id_usuario)) {
            $errores++;
            continue;
        }

        $stmt_check = $conn->prepare("SELECT estado_actual FROM pedidos WHERE id = ?");
        $stmt_check->bind_param("i", $pedido_id);
        $stmt_check->execute();
        $result = $stmt_check->get_result();
        if ($result->num_rows == 0) { $stmt_check->close(); continue; }
        $estado_actual = $result->fetch_assoc()['estado_actual'];
        $stmt_check->close();

                if ($rol === 'Super Admin') {
            if ($estado_actual === 'cancelado') continue;
        } elseif ($rol === 'Proveedor') {
            if ($estado_actual === 'cancelado') continue;
        } elseif ($rol === 'Vendedor') {
            if ($estado_actual === 'cancelado') continue;
            if ($estado_actual === 'entregado') continue;
            $stmt_mp = $conn->prepare("SELECT monto_pagado FROM pedidos WHERE id = ?");
            $stmt_mp->bind_param("i", $pedido_id);
            $stmt_mp->execute();
            $mp_data = $stmt_mp->get_result()->fetch_assoc();
            $stmt_mp->close();
            if (floatval($mp_data['monto_pagado'] ?? 0) > 0) continue;
        }

        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) VALUES (?, 'cancelado', ?, 'Cancelado masivo por administrador')");
            $stmt->bind_param("ii", $pedido_id, $_SESSION['usuario_id']);
            $stmt->execute();
            $stmt->close();

            $stmt2 = $conn->prepare("UPDATE pedidos SET estado_actual = 'cancelado' WHERE id = ?");
            $stmt2->bind_param("i", $pedido_id);
            $stmt2->execute();
            $stmt2->close();

                        $stmt3 = $conn->prepare("SELECT producto_id, combo_id, cantidad FROM pedido_detalles WHERE pedido_id = ?");
            $stmt3->bind_param("i", $pedido_id);
            $stmt3->execute();
            $productos = $stmt3->get_result();
            $stmt3->close();

            while ($item = $productos->fetch_assoc()) {
                if (intval($item['producto_id']) > 0) {
                    $stmt4 = $conn->prepare("UPDATE productos SET cantidad = cantidad + ? WHERE id = ?");
                    $stmt4->bind_param("ii", $item['cantidad'], $item['producto_id']);
                    $stmt4->execute();
                    $stmt4->close();
                } elseif (intval($item['combo_id']) > 0) {
                    $combo_id = intval($item['combo_id']);
                    $cant_combo = intval($item['cantidad']);

                    $stmt_c = $conn->prepare("UPDATE combos SET stock_combo = stock_combo + ? WHERE id = ?");
                    $stmt_c->bind_param("ii", $cant_combo, $combo_id);
                    $stmt_c->execute();
                    $stmt_c->close();

                    $stmt_cp = $conn->prepare("SELECT producto_id, cantidad FROM combo_productos WHERE combo_id = ?");
                    $stmt_cp->bind_param("i", $combo_id);
                    $stmt_cp->execute();
                    $prod_internos = $stmt_cp->get_result();
                    $stmt_cp->close();

                    while ($pi = $prod_internos->fetch_assoc()) {
                        $stock_devolver = intval($pi['cantidad']) * $cant_combo;
                        $stmt_pi = $conn->prepare("
                            UPDATE productos 
                            SET cantidad = cantidad + ?,
                                reservado_por_combos = reservado_por_combos + ?,
                                fecha_actualizacion_reserva = NOW(),
                                en_combo = 1,
                                fecha_agotado = NULL
                            WHERE id = ?
                        ");
                        $stmt_pi->bind_param("iii", $stock_devolver, $stock_devolver, $pi['producto_id']);
                        $stmt_pi->execute();
                        $stmt_pi->close();
                    }
                }
            }

            $conn->commit();
            $contador++;

            encolarCorreoPedidoSeguro($conn, $pedido_id, 'cancelado');
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('[admin/pedidos.php] Error cancelar masivo #' . $pedido_id . ': ' . $e->getMessage());
            $errores++;
        }
    }

    $_SESSION['mensaje'] = "✅ $contador pedido(s) cancelado(s)" . ($errores > 0 ? " ($errores con error)" : "");
    $_SESSION['tipo_mensaje'] = "exito";
    echo '<script>sessionStorage.removeItem("pedidosSeleccionados"); window.location.href="pedidos.php?t=' . time() . '";</script>';
    exit;
}

// ============================================
// HEADER
// ============================================
require_once dirname(__DIR__) . '/header.php';

// ============================================
// PERMISOS DE GESTIÓN (header.php ya validó proveedor y rol)
// ============================================
$roles_gestion = ['Super Admin', 'Gerente', 'Proveedor', 'Vendedor'];
$puede_gestionar = in_array($rol, $roles_gestion);

$roles_cambiar_estado = ['Super Admin', 'Gerente', 'Proveedor', 'Vendedor', 'Empaquetador', 'Transportista'];
$puede_cambiar_estado = in_array($rol, $roles_cambiar_estado);

$roles_ver_todos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
$puede_ver_todos = in_array($rol, $roles_ver_todos);

// ============================================
// FILTRO DE PROVEEDOR (Super Admin/Gerente/Supervisor/Contador)
// ============================================
$proveedor_filtro = 0;
if ($puede_ver_todos && !empty($_GET['proveedor_filtro'])) {
    $proveedor_filtro = intval($_GET['proveedor_filtro']);
}

$proveedores_lista = [];
if ($puede_ver_todos) {
    $stmt_lista = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda");
    if ($stmt_lista) {
        while ($row = $stmt_lista->fetch_assoc()) {
            $proveedores_lista[] = $row;
        }
        $stmt_lista->free();
    }
}

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if ($rol == 'Empaquetador') {
    $where[] = "p.estado_actual = 'empaquetado'";
} elseif ($rol == 'Transportista') {
    $where[] = "p.estado_actual = 'transporte'";
}

// Filtro de proveedor
if ($proveedor_id_usuario > 0) {
    $where[] = "p.id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = ?)";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
} elseif ($puede_ver_todos && $proveedor_filtro > 0) {
    $where[] = "p.id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = ?)";
    $params[] = $proveedor_filtro;
    $types .= "i";
}

if (!empty($_GET['pedido_id'])) {
    $where[] = "p.id = ?";
    $params[] = intval($_GET['pedido_id']);
    $types .= "i";
}

if (!empty($_GET['cliente'])) {
    $where[] = "(c.nombre LIKE ? OR c.apellidos LIKE ? OR c.email LIKE ?)";
    $search = "%" . $_GET['cliente'] . "%";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= "sss";
}

if (!empty($_GET['estado'])) {
    $where[] = "p.estado_actual = ?";
    $params[] = $_GET['estado'];
    $types .= "s";
}

if (!empty($_GET['municipio'])) {
    $where[] = "p.id IN (SELECT pedido_id FROM direcciones_envio WHERE municipio = ?)";
    $params[] = $_GET['municipio'];
    $types .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $where[] = "DATE(p.fecha_pedido) >= ?";
    $params[] = $_GET['fecha_desde'];
    $types .= "s";
}

if (!empty($_GET['fecha_hasta'])) {
    $where[] = "DATE(p.fecha_pedido) <= ?";
    $params[] = $_GET['fecha_hasta'];
    $types .= "s";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// Ordenamiento
$columnas_validas = [
    'id' => "p.id",
    'cliente' => "c.nombre",
    'fecha' => "p.fecha_pedido",
    'total' => "p.total",
    'estado' => "p.estado_actual"
];
$order_by = isset($_GET['order_by']) && array_key_exists($_GET['order_by'], $columnas_validas) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . $columnas_validas[$order_by] . " $order_dir";

// Contar total
$count_sql = "SELECT COUNT(*) as total FROM pedidos p JOIN clientes c ON p.cliente_id = c.id $sql_where";
$total_registros = 0;
$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $count_stmt->close();
} else {
    error_log("[admin/pedidos.php] prepare count: " . $conn->error);
}

$base_url = 'pedidos.php?' . http_build_query(array_filter($_GET));
include __DIR__ . '/../includes/paginacion_vars.php';

// Consulta principal
$sql = "SELECT p.*, 
               c.nombre, c.apellidos, c.email, c.movil,
               (SELECT COUNT(*) FROM pedido_detalles WHERE pedido_id = p.id) as total_productos,
               (SELECT SUM(cantidad) FROM pedido_detalles WHERE pedido_id = p.id) as total_items
        FROM pedidos p
        JOIN clientes c ON p.cliente_id = c.id
        $sql_where
        $order_sql
        LIMIT $por_pagina OFFSET $offset";
$pedidos = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $pedidos = $stmt->get_result();
    $stmt->close();
} else {
    error_log("[admin/pedidos.php] prepare pedidos: " . $conn->error);
}

// Estadísticas
$filtros_stats = [];
$params_stats = [];
$types_stats = "";

if ($proveedor_id_usuario > 0) {
    $filtros_stats[] = "p.id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = ?)";
    $params_stats[] = $proveedor_id_usuario;
    $types_stats .= "i";
} elseif ($puede_ver_todos && $proveedor_filtro > 0) {
    $filtros_stats[] = "p.id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = ?)";
    $params_stats[] = $proveedor_filtro;
    $types_stats .= "i";
}

if (!empty($_GET['estado'])) {
    $filtros_stats[] = "p.estado_actual = ?";
    $params_stats[] = $_GET['estado'];
    $types_stats .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $filtros_stats[] = "DATE(p.fecha_pedido) >= ?";
    $params_stats[] = $_GET['fecha_desde'];
    $types_stats .= "s";
}

if (!empty($_GET['fecha_hasta'])) {
    $filtros_stats[] = "DATE(p.fecha_pedido) <= ?";
    $params_stats[] = $_GET['fecha_hasta'];
    $types_stats .= "s";
}

$stats_sql_where = !empty($filtros_stats) ? "WHERE " . implode(" AND ", $filtros_stats) : "";

$stats_sql = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN p.estado_actual = 'pendiente_verificacion' THEN 1 ELSE 0 END) as pendiente_verificacion,
    SUM(CASE WHEN p.estado_actual = 'pendiente_entrega_pago' THEN 1 ELSE 0 END) as pendiente_entrega_pago,
    SUM(CASE WHEN p.estado_actual = 'empaquetado' THEN 1 ELSE 0 END) as empaquetados,
    SUM(CASE WHEN p.estado_actual = 'transporte' THEN 1 ELSE 0 END) as transporte,
    SUM(CASE WHEN p.estado_actual = 'entregado' THEN 1 ELSE 0 END) as entregados,
    SUM(CASE WHEN p.estado_actual = 'cancelado' THEN 1 ELSE 0 END) as cancelados,
    SUM(CASE WHEN p.estado_actual = 'incidencia' THEN 1 ELSE 0 END) as incidencias,
    SUM(CASE WHEN p.estado_pago = 'pagado' THEN 1 ELSE 0 END) as pagados
    FROM pedidos p
    $stats_sql_where";

$stats = [
    'total' => 0, 'pagados' => 0, 'empaquetados' => 0, 'transporte' => 0,
    'entregados' => 0, 'cancelados' => 0, 'incidencias' => 0, 'pendiente_entrega_pago' => 0,
];
$stats_stmt = $conn->prepare($stats_sql);
if ($stats_stmt) {
    if (!empty($params_stats)) {
        $stats_stmt->bind_param($types_stats, ...$params_stats);
    }
    $stats_stmt->execute();
    $row_stats = $stats_stmt->get_result()->fetch_assoc();
    if ($row_stats) {
        $stats = [
    'total' => intval($row_stats['total'] ?? 0),
    'pagados' => intval($row_stats['pagados'] ?? 0),
    'empaquetados' => intval($row_stats['empaquetados'] ?? 0),
    'transporte' => intval($row_stats['transporte'] ?? 0),
    'entregados' => intval($row_stats['entregados'] ?? 0),
    'cancelados' => intval($row_stats['cancelados'] ?? 0),
    'incidencias' => intval($row_stats['incidencias'] ?? 0),
        'pendiente_entrega_pago' => intval($row_stats['pendiente_entrega_pago'] ?? 0),
];
    }
    $stats_stmt->close();
} else {
    error_log("[admin/pedidos.php] prepare stats: " . $conn->error);
}

if (isset($_SESSION['mensaje'])) {
    $mensaje = $_SESSION['mensaje'];
    $tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
}
?>
<!-- ESTILOS (sin cambios, se mantienen igual) -->
<style>
* { box-sizing: border-box; }
.gestion-container { width: 100%; max-width: 1400px; margin: 1rem auto; padding: 0 1rem; }
@media (min-width: 768px) { .gestion-container { margin: 2rem auto; padding: 0 2rem; } }
.gestion-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
@media (max-width: 640px) { .gestion-header { justify-content: center; text-align: center; } }
.gestion-header h1 { font-size: 1.5rem; color: #2d3748; margin: 0; }
@media (min-width: 768px) { .gestion-header h1 { font-size: 2rem; } }
.stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.75rem; margin-bottom: 1.5rem; }
@media (min-width: 640px) { .stats-grid { grid-template-columns: repeat(4, 1fr); } }
@media (min-width: 1024px) { .stats-grid { grid-template-columns: repeat(3, 1fr); } }
@media (min-width: 1280px) { .stats-grid { grid-template-columns: repeat(5, 1fr); } }
.stat-card { background: white; border-radius: 10px; padding: 0.75rem; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border-left: 4px solid var(--primary); }
@media (min-width: 768px) { .stat-card { padding: 1rem; } }
.stat-card .label { font-size: 0.65rem; color: #718096; text-transform: uppercase; }
@media (min-width: 768px) { .stat-card .label { font-size: 0.8rem; } }
.stat-card .value { font-size: 1.2rem; font-weight: 700; color: #2d3748; }
@media (min-width: 768px) { .stat-card .value { font-size: 1.5rem; } }
.filtros-card { background: white; border-radius: 12px; padding: 1rem; margin-bottom: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.05); width: 100%; }
@media (min-width: 768px) { .filtros-card { padding: 1.5rem; } }
.filtros-form { width: 100%; }
.filtros-linea { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 0.5rem; }
.filtro-item { flex: 1; min-width: 0; }
.filtro-item label { display: block; font-size: 0.65rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem; text-transform: uppercase; white-space: nowrap; }
.filtro-item input, .filtro-item select { width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 0.8rem; }
.filtro-fecha { min-width: 0; max-width: 130px; }
.filtro-fecha input { padding: 0.5rem; font-size: 0.75rem; }
.filtros-botones { display: flex; gap: 0.5rem; flex-shrink: 0; }
.btn-filtro { padding: 0.5rem 1rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.8rem; text-decoration: none; display: inline-block; text-align: center; white-space: nowrap; }
.btn-filtro-aplicar { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; }
.btn-filtro-limpiar { background: #edf2f7; color: #4a5568; }
@media (max-width: 768px) {
    .filtros-linea { flex-direction: column; align-items: stretch; gap: 0.75rem; }
    .filtro-item { width: 100%; }
    .filtro-fecha { max-width: none; }
    .filtros-botones { margin-top: 0.5rem; }
    .btn-filtro { flex: 1; text-align: center; }
}
.tabla-pedidos { background: white; border-radius: 12px; padding: 0; box-shadow: 0 2px 4px rgba(0,0,0,0.05); overflow-x: auto; -webkit-overflow-scrolling: touch; margin-bottom: 1.5rem; width: 100%; }
.tabla-pedidos table { width: 100%; min-width: 800px; border-collapse: collapse; font-size: 0.75rem; }
@media (min-width: 768px) { .tabla-pedidos table { font-size: 0.9rem; min-width: 900px; } }
.tabla-pedidos th { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; padding: 0.7rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.7rem; text-transform: uppercase; white-space: nowrap; }
@media (min-width: 768px) { .tabla-pedidos th { padding: 0.8rem; font-size: 0.8rem; } }
.tabla-pedidos td { padding: 0.7rem 0.5rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }
@media (min-width: 768px) { .tabla-pedidos td { padding: 0.8rem; } }
.badge-estado { padding: 0.2rem 0.5rem; border-radius: 20px; font-size: 0.65rem; font-weight: 600; display: inline-block; white-space: nowrap; }
@media (min-width: 768px) { .badge-estado { padding: 0.3rem 0.8rem; font-size: 0.75rem; } }
.badge-pendiente_pago { background: #fef5e7; color: #c05621; }
.badge-pendiente_parcial { background: #fef5e7; color: #744210; }
.badge-pendiente_entrega { background: #fef5e7; color: #744210; }
.badge-pendiente_entrega_pago { background: #fef5e7; color: #744210; }
.badge-pendiente_verificacion { background: #fef5e7; color: #744210; }
.badge-pendiente_pago_final { background: #e9d8fd; color: #6b46c1; }
.badge-pago_confirmado { background: #c6f6d5; color: #22543d; }
.badge-empaquetado { background: #feebc8; color: #c05621; }
.badge-transporte { background: #e9d8fd; color: #6b46c1; }
.badge-entregado { background: #c6f6d5; color: #22543d; }
.badge-cancelado { background: #fed7d7; color: #c53030; }
.badge-incidencia { background: #fed7d7; color: #c05621; }
.acciones-container { display: flex; gap: 0.3rem; flex-wrap: wrap; justify-content: flex-start; }
.btn-accion { width: 30px; height: 30px; border-radius: 6px; text-decoration: none; font-size: 0.9rem; display: inline-flex; align-items: center; justify-content: center; border: none; cursor: pointer; font-weight: 500; transition: all 0.2s; color: white; flex-shrink: 0; }
@media (min-width: 768px) { .btn-accion { width: 32px; height: 32px; font-size: 1rem; } }
.btn-accion:hover { transform: translateY(-2px); filter: brightness(1.1); }
.btn-ver { background: #4299e1; }
.btn-empaquetar { background: #ecc94b; color: #744210; }
.btn-entregar { background: #48bb78; }
.btn-estado { background: #4299e1; }
.btn-cancelar { background: #f56565; }
.btn-direccion { background: #9f7aea; }
.mensaje { padding: 0.75rem; border-radius: 10px; margin-bottom: 1rem; font-size: 0.85rem; }
@media (min-width: 768px) { .mensaje { padding: 1rem; } }
.mensaje.exito { background: #f0fff4; color: #22543d; border: 1px solid #48bb78; }
.mensaje.error { background: #fff5f5; color: #742a2a; border: 1px solid #f56565; }
.mensaje.warning { background: #fef5e7; color: #744210; border: 1px solid #ecc94b; }
.modal { display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(5px); }
.modal-content { background: white; margin: 10% auto; padding: 1.25rem; border-radius: 16px; max-width: 95%; width: 95%; max-height: 80vh; overflow-y: auto; position: relative; animation: slideDown 0.3s; }
@media (min-width: 768px) { .modal-content { margin: 5% auto; padding: 2rem; max-width: 600px; width: 95%; } }
@keyframes slideDown { from { transform: translateY(-50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
.close { position: absolute; top: 0.75rem; right: 1rem; font-size: 1.8rem; cursor: pointer; color: #718096; }
@media (min-width: 768px) { .close { top: 1rem; right: 1.5rem; font-size: 2rem; } }
.close:hover { color: #2d3748; }
.text-right { text-align: right; }
.text-center { text-align: center; }
.sin-datos { padding: 2rem; text-align: center; color: #a0aec0; }
.floating-counter { position: fixed; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; font-weight: bold; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 1000; transition: all 0.3s ease; border: 2px solid white; display: none; align-items: center; justify-content: center; gap: 5px; }
.floating-counter:hover { transform: scale(1.05); }
.floating-counter.show { display: flex; }
@media (min-width: 769px) { .floating-counter { bottom: 20px; right: 20px; padding: 12px 20px; border-radius: 50px; font-size: 1rem; min-width: auto; } }
@media (max-width: 768px) { .floating-counter { top: 70px; left: 20px; width: 45px; height: 45px; border-radius: 50%; font-size: 1.1rem; padding: 0; } }
.floating-actions-menu { position: fixed; background: white; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.2); z-index: 1000; min-width: 200px; overflow: hidden; display: none; border: 1px solid #e2e8f0; }
.floating-actions-menu.show { display: block; animation: fadeInUp 0.2s ease; }
@media (min-width: 769px) { .floating-actions-menu { bottom: 90px; right: 20px; } }
@media (max-width: 768px) { .floating-actions-menu { top: 125px; left: 20px; } }
@keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.floating-actions-menu button { display: flex; align-items: center; gap: 12px; width: 100%; padding: 12px 16px; border: none; background: white; color: #2d3748; font-size: 0.9rem; font-weight: 500; cursor: pointer; transition: all 0.2s; text-align: left; }
.floating-actions-menu button:hover { background: #f7fafc; }
.floating-actions-menu hr { margin: 0; border-top: 1px solid #e2e8f0; }
.checkbox-col { width: 40px; text-align: center; }
.checkbox-pedido, .select-all-checkbox { width: 18px; height: 18px; cursor: pointer; accent-color: var(--primary); margin: 0 auto; display: block; }
</style>

<div class="gestion-container">
    <div class="gestion-header">
        <h1>📦 Gestión de Pedidos</h1>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="label">Total</div><div class="value"><?php echo $stats['total']; ?></div></div>
        <div class="stat-card"><div class="label">Pagados</div><div class="value"><?php echo $stats['pagados']; ?></div></div>
        <div class="stat-card"><div class="label">Empaquetados</div><div class="value"><?php echo $stats['empaquetados']; ?></div></div>
        <div class="stat-card"><div class="label">En Transporte</div><div class="value"><?php echo $stats['transporte']; ?></div></div>
        <div class="stat-card"><div class="label">Entregados</div><div class="value"><?php echo $stats['entregados']; ?></div></div>
        <div class="stat-card"><div class="label">Cancelados</div><div class="value"><?php echo $stats['cancelados']; ?></div></div>
        <div class="stat-card"><div class="label">Incidencias</div><div class="value"><?php echo $stats['incidencias']; ?></div></div>
        <div class="stat-card"><div class="label">Pend. Entrega</div><div class="value"><?php echo $stats['pendiente_entrega_pago']; ?></div></div>
    </div>

    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo htmlspecialchars($tipo_mensaje); ?>"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <div class="filtros-card">
        <form method="GET" class="filtros-form">
            <div class="filtros-linea">
                <?php if ($puede_ver_todos): ?>
                <div class="filtro-item">
                    <label>Proveedor</label>
                    <select name="proveedor_filtro" onchange="this.form.submit()">
                        <option value="0">Todos los proveedores</option>
                        <?php foreach ($proveedores_lista as $prov): ?>
                            <option value="<?php echo $prov['id']; ?>" <?php echo ($proveedor_filtro == $prov['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="filtro-item">
                    <label>ID Pedido</label>
                    <input type="number" name="pedido_id" value="<?php echo htmlspecialchars($_GET['pedido_id'] ?? ''); ?>" placeholder="123" onchange="this.form.submit()">
                </div>
                <div class="filtro-item">
                    <label>Cliente</label>
                    <input type="text" name="cliente" value="<?php echo htmlspecialchars($_GET['cliente'] ?? ''); ?>" placeholder="Nombre o email" onchange="this.form.submit()">
                </div>
                <div class="filtro-item">
                    <label>Estado</label>
                    <select name="estado" onchange="this.form.submit()">
                        <option value="">Todos</option>
                        <option value="pendiente_pago" <?php echo ($_GET['estado'] ?? '') == 'pendiente_pago' ? 'selected' : ''; ?>>Pendiente Pago</option>
                        <option value="pendiente_parcial" <?php echo ($_GET['estado'] ?? '') == 'pendiente_parcial' ? 'selected' : ''; ?>>Pendiente Parcial</option>
                        <option value="pendiente_entrega" <?php echo ($_GET['estado'] ?? '') == 'pendiente_entrega' ? 'selected' : ''; ?>>Pendiente Entrega</option>
                        <option value="pendiente_entrega_pago" <?php echo ($_GET['estado'] ?? '') == 'pendiente_entrega_pago' ? 'selected' : ''; ?>>Pendiente pago entrega</option>
                        <option value="pendiente_verificacion" <?php echo ($_GET['estado'] ?? '') == 'pendiente_verificacion' ? 'selected' : ''; ?>>Pendiente Verificación</option>
                        <option value="pendiente_pago_final" <?php echo ($_GET['estado'] ?? '') == 'pendiente_pago_final' ? 'selected' : ''; ?>>Pendiente Pago Final</option>
	               <option value="pago_confirmado" <?php echo ($_GET['estado'] ?? '') == 'pago_confirmado' ? 'selected' : ''; ?>>Pago Confirmado</option>
                        <option value="empaquetado" <?php echo ($_GET['estado'] ?? '') == 'empaquetado' ? 'selected' : ''; ?>>Empaquetado</option>
                        <option value="transporte" <?php echo ($_GET['estado'] ?? '') == 'transporte' ? 'selected' : ''; ?>>En Transporte</option>
                        <option value="entregado" <?php echo ($_GET['estado'] ?? '') == 'entregado' ? 'selected' : ''; ?>>Entregado</option>
                        <option value="cancelado" <?php echo ($_GET['estado'] ?? '') == 'cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                        <option value="incidencia" <?php echo ($_GET['estado'] ?? '') == 'incidencia' ? 'selected' : ''; ?>>Incidencia</option>
                    </select>
                </div>
                                <div class="filtro-item">
                    <label>📍 Municipio</label>
                    <select name="municipio" onchange="this.form.submit()">
                        <option value="">Todos</option>
                        <?php
                        $result_municipios = null;
                        if ($proveedor_id_usuario > 0) {
                            $stmt_mun = $conn->prepare("SELECT DISTINCT de.municipio FROM direcciones_envio de INNER JOIN pedido_detalles pd ON pd.pedido_id = de.pedido_id WHERE pd.proveedor_id = ? ORDER BY de.municipio");
                            if ($stmt_mun) {
                                $stmt_mun->bind_param("i", $proveedor_id_usuario);
                                $stmt_mun->execute();
                                $result_municipios = $stmt_mun->get_result();
                            }
                        } else {
                            $result_municipios = $conn->query("SELECT DISTINCT municipio FROM direcciones_envio ORDER BY municipio");
                        }
                        if ($result_municipios):
                            while($m = $result_municipios->fetch_assoc()):
                        ?>
                            <option value="<?php echo htmlspecialchars($m['municipio']); ?>" <?php echo (isset($_GET['municipio']) && $_GET['municipio'] == $m['municipio']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($m['municipio']); ?>
                            </option>
                        <?php
                            endwhile;
                        endif;
                        if ($proveedor_id_usuario > 0 && isset($stmt_mun) && $stmt_mun) $stmt_mun->close();
                        ?>
                    </select>
                </div>
                <div class="filtro-item filtro-fecha">
                    <label>Desde</label>
                    <input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>" onchange="this.form.submit()">
                </div>
                <div class="filtro-item filtro-fecha">
                    <label>Hasta</label>
                    <input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>" onchange="this.form.submit()">
                </div>
                <div class="filtros-botones">
                    <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
                    <a href="pedidos.php" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
                </div>
            </div>
        </form>
    </div>

    <div class="tabla-pedidos">
        <table>
            <thead>
                <tr>
                    <th class="checkbox-col"><input type="checkbox" class="select-all-checkbox" id="selectAll"></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'id', 'order_dir' => ($order_by == 'id' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" style="color: white; text-decoration: none;">Código <?php if ($order_by == 'id'): ?><?php echo $order_dir == 'ASC' ? '▲' : '▼'; ?><?php endif; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'cliente', 'order_dir' => ($order_by == 'cliente' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" style="color: white; text-decoration: none;">Cliente <?php if ($order_by == 'cliente'): ?><?php echo $order_dir == 'ASC' ? '▲' : '▼'; ?><?php endif; ?></a></th>
                    <th style="color: white;">Email</th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'fecha', 'order_dir' => ($order_by == 'fecha' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" style="color: white; text-decoration: none;">Fecha <?php if ($order_by == 'fecha'): ?><?php echo $order_dir == 'ASC' ? '▲' : '▼'; ?><?php endif; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'total', 'order_dir' => ($order_by == 'total' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" style="color: white; text-decoration: none;">Total <?php if ($order_by == 'total'): ?><?php echo $order_dir == 'ASC' ? '▲' : '▼'; ?><?php endif; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['order_by' => 'estado', 'order_dir' => ($order_by == 'estado' && $order_dir == 'ASC') ? 'DESC' : 'ASC'])); ?>" style="color: white; text-decoration: none;">Estado Actual <?php if ($order_by == 'estado'): ?><?php echo $order_dir == 'ASC' ? '▲' : '▼'; ?><?php endif; ?></a></th>
<th style="color: white;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($pedidos && $pedidos->num_rows > 0): ?>
                    <?php while($p = $pedidos->fetch_assoc()): 
                        $estado_class = 'badge-' . $p['estado_actual'];
                    ?>
                        <tr>
                            <td class="checkbox-col text-center"><input type="checkbox" class="checkbox-pedido" value="<?php echo $p['id']; ?>"></td>
                            <td><?php echo htmlspecialchars($p['codigo']); ?></td>
                            <td><?php echo htmlspecialchars($p['nombre'] . ' ' . $p['apellidos']); ?></td>
                            <td><?php echo htmlspecialchars($p['email']); ?></td>
                            <td class="fecha-cell"><?php
    $ts_ped = strtotime($p['fecha_pedido'] ?? '');
    echo ($ts_ped !== false) ? date('d/m/Y H:i', $ts_ped) : '—';
?></td>
                            <td>
                                $<?php echo number_format($p['total_convertido'] ?? $p['total'], 2); ?> <?php echo htmlspecialchars($p['moneda']); ?>
                                <?php if (floatval($p['monto_pagado'] ?? 0) > 0): ?>
                                    <br><small style="color: #f56565; text-decoration: line-through;">Pag: $<?php echo number_format($p['monto_pagado'], 2); ?> <?php echo htmlspecialchars($p['moneda']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge-estado <?php echo htmlspecialchars($estado_class); ?>"><?php echo ucfirst(str_replace('_', ' ', $p['estado_actual'])); ?></span>
                                <?php if ($p['monto_pendiente'] > 0): ?>
                                    <br><small style="color: #f56565;">Pend: $<?php echo number_format($p['monto_pendiente'], 2); ?> <?php echo htmlspecialchars($p['moneda']); ?></small>
                                <?php endif; ?>
                            </td>
 
                            <td>
                                <div class="acciones-container">
    <a href="/checkout/confirmacion.php?pedido=<?php echo $p['id']; ?>" target="_blank" class="btn-accion btn-ver" title="Ver detalle">👁️</a>
    <button onclick="verDireccionEntrega(<?php echo $p['id']; ?>)" class="btn-accion btn-direccion" title="Ver dirección">📍</button>
    
    <!-- Empaquetar y entregar se hacen desde el modal de cambiar estado -->
    
    <?php if ($puede_cambiar_estado): ?>
        <button onclick="mostrarModalCambiarEstado(<?php echo $p['id']; ?>, '<?php echo htmlspecialchars($p['estado_actual']); ?>')" class="btn-accion btn-estado" title="Cambiar estado">✏️</button>
    <?php endif; ?>
    
     <?php
// ¿Se puede cancelar?
$puede_cancelar = false;

if ($rol === 'Super Admin') {
    // Super Admin puede cancelar desde cualquier estado excepto cancelado
    $puede_cancelar = ($p['estado_actual'] !== 'cancelado');
} elseif ($rol === 'Proveedor') {
    // Proveedor puede cancelar desde cualquier estado excepto cancelado
    $puede_cancelar = ($p['estado_actual'] !== 'cancelado');
} elseif ($rol === 'Vendedor') {
    // Vendedor solo si no hay pagos y no está entregado
    $puede_cancelar = ($p['estado_actual'] !== 'cancelado'
        && $p['estado_actual'] !== 'entregado'
        && floatval($p['monto_pagado'] ?? 0) == 0);
}
?>
<?php if ($puede_cancelar): ?>
    <a href="?cancelar_pedido=<?php echo intval($p['id']); ?>&motivo=Cancelado+por+admin&csrf_token=<?php echo urlencode($_SESSION['csrf_token'] ?? ''); ?>" class="btn-accion btn-cancelar" title="Cancelar" onclick="return confirm('¿Cancelar este pedido?')">❌</a>
<?php endif; ?>
</div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="sin-datos">📭 No hay pedidos para mostrar</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../includes/paginacion_botones.php'; ?>

<div id="floatingCounter" class="floating-counter">0</div>

<div id="floatingActionsMenu" class="floating-actions-menu">
    <?php if ($puede_cambiar_estado): ?>
    <button id="btnCambiarEstadoAccion">✏️ Cambiar estado</button>
    <button id="btnCancelarAccion">❌ Cancelar pedidos</button>
    <?php endif; ?>
    <button id="btnResumenAccion">📊 Generar resumen consolidado</button>
    <hr>
    <button id="btnLimpiarAccion">✖ Limpiar selección</button>
</div>

<!-- Modales (idénticos a los originales, sin cambios) -->
<div id="modalDireccionEntrega" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <span class="close" onclick="cerrarModal('modalDireccionEntrega')">&times;</span>
        <h2>📍 Dirección de Entrega</h2>
        <div id="contenidoDireccionEntrega" style="margin-top: 1rem;">Cargando...</div>
    </div>
</div>

<div id="modalEmpaquetar" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalEmpaquetar')">&times;</span>
        <h2>📦 Confirmar Empaquetado</h2>
        <form method="POST" id="formEmpaquetar">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="confirmar_empaquetado" value="1">
            <input type="hidden" name="pedido_id" id="empaquetar_pedido_id">
            <div style="margin: 1rem 0;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Observaciones (opcional)</label>
                <textarea name="incidencia" rows="3" style="width:100%; padding:0.8rem; border:1px solid #e2e8f0; border-radius:8px;"></textarea>
            </div>
            <button type="submit" class="btn-accion btn-empaquetar" style="width:100%; padding:1rem;">Confirmar Empaquetado</button>
        </form>
    </div>
</div>

<div id="modalTransporte" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalTransporte')">&times;</span>
        <h2>🚚 Confirmar Entrega</h2>
        <form method="POST" id="formTransporte">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="confirmar_entrega" value="1">
            <input type="hidden" name="pedido_id" id="transporte_pedido_id">
            <div style="margin: 1rem 0;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">¿Problemas con la entrega?</label>
                <select name="no_entrega" id="no_entrega_select" onchange="toggleNoEntrega()" style="width:100%; padding:0.8rem; border:1px solid #e2e8f0; border-radius:8px;">
                    <option value="">✅ Entrega exitosa</option>
                    <option value="cliente_ausente">❌ Cliente ausente</option>
                    <option value="direccion_incorrecta">❌ Dirección incorrecta</option>
                    <option value="producto_danado">❌ Producto dañado</option>
                    <option value="cliente_rechaza">❌ Cliente rechaza</option>
                    <option value="otro">❌ Otro motivo</option>
                </select>
            </div>
            <div id="no_entrega_otro" style="display: none; margin: 1rem 0;">
                <textarea name="no_entrega_desc" placeholder="Especificar motivo..." rows="3" style="width:100%; padding:0.8rem; border:1px solid #e2e8f0; border-radius:8px;"></textarea>
            </div>
            <button type="submit" class="btn-accion btn-entregar" style="width:100%; padding:1rem;">Confirmar</button>
        </form>
    </div>
</div>

<div id="modalCambiarEstado" class="modal">
    <div class="modal-content" style="max-width: 450px;">
        <span class="close" onclick="cerrarModal('modalCambiarEstado')">&times;</span>
        <h2>✏️ Cambiar Estado del Pedido</h2>
                <form method="POST" id="formCambiarEstado">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="cambiar_estado" value="1">
            <input type="hidden" name="pedido_id" id="cambiar_estado_pedido_id">
            <div style="margin: 1rem 0;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nuevo Estado</label>
                <select name="nuevo_estado" id="nuevo_estado_select" style="width:100%; padding:0.8rem; border:1px solid #e2e8f0; border-radius:8px;">
    <option value="pendiente_pago">Pendiente Pago</option>
    <option value="pendiente_parcial">Pendiente Parcial</option>
    <option value="pendiente_entrega">Pendiente Entrega</option>
    <option value="pendiente_entrega_pago">Pendiente Pago Entrega</option>
    <option value="pendiente_verificacion">Pendiente Verificación</option>
    <option value="pendiente_pago_final">Pendiente Pago Final</option>
    <option value="pago_confirmado">Pago Confirmado</option>
    <option value="empaquetado">Empaquetado</option>
    <option value="transporte">En Transporte</option>
    <option value="entregado">Entregado</option>
    <option value="cancelado">Cancelado</option>
    <option value="incidencia">Incidencia</option>
</select>
            </div>
            <div style="margin: 1rem 0;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Observaciones</label>
                <textarea name="observaciones_estado" rows="3" style="width:100%; padding:0.8rem; border:1px solid #e2e8f0; border-radius:8px;" placeholder="Motivo del cambio..."></textarea>
            </div>
            <div style="margin: 1rem 0; padding: 0.8rem; background: #fef5e7; border-radius:8px; color:#744210;">
                ⚠️ Al cambiar a "cancelado" se devolverá el stock automáticamente.
            </div>
            <button type="submit" class="btn-accion" style="width:100%; padding:1rem; background:#4299e1; color:white; border:none; border-radius:8px; cursor:pointer;">Cambiar Estado</button>
        </form>
    </div>
</div>

<div id="modalCambiarEstadoMasivo" class="modal">
    <div class="modal-content" style="max-width: 450px;">
        <span class="close" onclick="cerrarModal('modalCambiarEstadoMasivo')">&times;</span>
        <h2>✏️ Cambiar Estado Masivo</h2>
        <form method="POST" id="formCambiarEstadoMasivo">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="cambiar_estado_multiple" value="1">
            <input type="hidden" name="cambiar_estado_multiple_ids" id="cambiar_estado_multiple_ids">
            <div style="margin: 1rem 0;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Nuevo Estado</label>
                <select name="nuevo_estado_masivo" id="nuevo_estado_masivo_select" style="width:100%; padding:0.8rem; border:1px solid #e2e8f0; border-radius:8px;">
                    <option value="pendiente_pago">Pendiente Pago</option>
                    <option value="pendiente_parcial">Pendiente Parcial</option>
                    <option value="pendiente_entrega">Pendiente Entrega</option>
                    <option value="pendiente_entrega_pago">Pendiente Pago Entrega</option>
                    <option value="pendiente_verificacion">Pendiente Verificación</option>
                    <option value="pendiente_pago_final">Pendiente Pago Final</option>
		    <option value="pago_confirmado">Pago Confirmado</option>
                    <option value="empaquetado">Empaquetado</option>
                    <option value="transporte">En Transporte</option>
                    <option value="entregado">Entregado</option>
                    <option value="cancelado">Cancelado</option>
                    <option value="incidencia">Incidencia</option>
                </select>
            </div>
            <div style="margin: 1rem 0;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Observaciones (opcional)</label>
                <textarea name="observaciones_masivo" rows="3" style="width:100%; padding:0.8rem; border:1px solid #e2e8f0; border-radius:8px;" placeholder="Motivo del cambio masivo..."></textarea>
            </div>
            <div style="margin: 1rem 0; padding: 0.8rem; background: #fef5e7; border-radius:8px; color:#744210;">
                ⚠️ Se cambiarán <span id="contadorPedidosMasivo">0</span> pedido(s) al estado seleccionado.
            </div>
            <button type="submit" class="btn-accion" style="width:100%; padding:1rem; background:#4299e1; color:white; border:none; border-radius:8px; cursor:pointer;">Cambiar Estado</button>
        </form>
    </div>
</div>

<script>
let seleccionados = new Set();
function guardarSeleccion() { sessionStorage.setItem('pedidosSeleccionados', JSON.stringify([...seleccionados])); }
function cargarSeleccion() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('limpiar')) {
        sessionStorage.removeItem('pedidosSeleccionados');
        seleccionados = new Set(); actualizarTodo();
        urlParams.delete('limpiar');
        const newUrl = window.location.pathname + (urlParams.toString() ? '?' + urlParams.toString() : '');
        window.history.replaceState({}, '', newUrl);
        return;
    }
    const guardados = sessionStorage.getItem('pedidosSeleccionados');
    if (guardados) { seleccionados = new Set(JSON.parse(guardados)); actualizarTodo(); }
}
function actualizarCheckboxes() {
    document.querySelectorAll('.checkbox-pedido').forEach(cb => cb.checked = seleccionados.has(parseInt(cb.value)));
    const total = document.querySelectorAll('.checkbox-pedido').length;
    const sel = document.querySelectorAll('.checkbox-pedido:checked').length;
    const selectAll = document.getElementById('selectAll');
    if (selectAll) {
        selectAll.checked = total > 0 && sel === total;
        selectAll.indeterminate = sel > 0 && sel < total;
    }
}
function actualizarContador() {
    const count = seleccionados.size;
    const fc = document.getElementById('floatingCounter');
    if (fc) {
        if (count > 0) {
            fc.textContent = window.innerWidth > 768 ? count + (count === 1 ? ' seleccionado' : ' seleccionados') : count;
            fc.classList.add('show');
        } else { fc.classList.remove('show'); }
    }
}
function actualizarTodo() { actualizarCheckboxes(); actualizarContador(); }
document.addEventListener('change', function(e) {
    if (e.target.classList.contains('checkbox-pedido')) {
        const id = parseInt(e.target.value);
        e.target.checked ? seleccionados.add(id) : seleccionados.delete(id);
        actualizarTodo(); guardarSeleccion();
    }
    if (e.target.id === 'selectAll') {
        document.querySelectorAll('.checkbox-pedido').forEach(cb => {
            cb.checked = e.target.checked;
            const id = parseInt(cb.value);
            e.target.checked ? seleccionados.add(id) : seleccionados.delete(id);
        });
        actualizarTodo(); guardarSeleccion();
    }
});
function ejecutarAccionPedidos(accion, ids, extraData = {}) {
    if (ids.length === 0) return;
    const form = document.createElement('form');
    form.method = 'POST'; form.action = 'pedidos.php';
    
    // Añadir CSRF token
    const csrfInput = document.createElement('input');
    csrfInput.type = 'hidden';
    csrfInput.name = 'csrf_token';
    csrfInput.value = '<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? ''); ?>';
    form.appendChild(csrfInput);
    
    const input = document.createElement('input');
    input.type = 'hidden'; input.name = accion; input.value = JSON.stringify(ids);
    form.appendChild(input);
    for (const [k, v] of Object.entries(extraData)) {
        const h = document.createElement('input'); h.type='hidden'; h.name=k; h.value=v;
        form.appendChild(h);
    }
    document.body.appendChild(form); form.submit();
}
document.getElementById('btnCambiarEstadoAccion')?.addEventListener('click', () => {
    if (seleccionados.size > 0) {
        document.getElementById('contadorPedidosMasivo').textContent = seleccionados.size;
        document.getElementById('cambiar_estado_multiple_ids').value = JSON.stringify([...seleccionados]);
        document.getElementById('modalCambiarEstadoMasivo').style.display = 'block';
    }
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('btnCancelarAccion')?.addEventListener('click', () => {
    if (seleccionados.size && confirm(`¿Cancelar ${seleccionados.size} pedido(s)?`)) {
        ejecutarAccionPedidos('cancelar_multiple', [...seleccionados]);
    }
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('btnResumenAccion')?.addEventListener('click', () => {
    if (seleccionados.size === 0) { alert('Seleccione al menos un pedido.'); return; }
    const ids = [...seleccionados].join(',');
    window.open('/admin/generar_consolidado_productos_pdf.php?ids=' + ids + '&limpiar=1', '_blank');
    seleccionados.clear(); actualizarTodo(); guardarSeleccion();
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('btnLimpiarAccion')?.addEventListener('click', () => {
    seleccionados.clear(); actualizarTodo(); guardarSeleccion();
    document.getElementById('floatingActionsMenu')?.classList.remove('show');
});
document.getElementById('floatingCounter')?.addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('floatingActionsMenu')?.classList.toggle('show');
});
document.addEventListener('click', (e) => {
    if (!e.target.closest('#floatingCounter') && !e.target.closest('#floatingActionsMenu')) {
        document.getElementById('floatingActionsMenu')?.classList.remove('show');
    }
});
document.addEventListener('DOMContentLoaded', function() {
    if (window.performance && window.performance.navigation && window.performance.navigation.type === 1) {
        sessionStorage.removeItem('pedidosSeleccionados');
        seleccionados = new Set(); actualizarTodo();
    }
    cargarSeleccion();
});
document.querySelector('.filtros-form')?.addEventListener('submit', () => guardarSeleccion());
document.querySelectorAll('.btn-pagina').forEach(link => link.addEventListener('click', () => guardarSeleccion()));
window.addEventListener('resize', () => actualizarContador());
function cerrarModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

function verDireccionEntrega(pedidoId) {
    document.getElementById('modalDireccionEntrega').style.display = 'block';
    document.getElementById('contenidoDireccionEntrega').innerHTML = 'Cargando...';
    fetch('direccion_entrega_json.php?pedido_id=' + pedidoId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                let html = '<div style="background:#f7fafc; border-radius:8px; padding:1.5rem;">' +
                    '<p><strong>' + data.nombre_completo + '</strong></p>' +
                    '<p><span style="color:#718096;">Documento:</span> ' + data.documento + '</p>' +
                    '<p><span style="color:#718096;">Teléfono:</span> ' + data.telefono + '</p>' +
                    '<p><span style="color:#718096;">Dirección:</span> ' + data.direccion + '</p>';
                if (data.email) html += '<p><span style="color:#718096;">Email:</span> ' + data.email + '</p>';
                if (data.instrucciones) html += '<p style="margin-top:1rem; font-style:italic;">📝 ' + data.instrucciones + '</p>';
                html += '</div>';
                document.getElementById('contenidoDireccionEntrega').innerHTML = html;
            } else {
                document.getElementById('contenidoDireccionEntrega').innerHTML = '<p style="color:#f56565;">No hay dirección registrada</p>';
            }
        })
        .catch(() => {
            document.getElementById('contenidoDireccionEntrega').innerHTML = '<p style="color:#f56565;">Error al cargar la dirección</p>';
        });
}
function mostrarModalEmpaquetar(pedidoId) {
    document.getElementById('empaquetar_pedido_id').value = pedidoId;
    document.getElementById('modalEmpaquetar').style.display = 'block';
}
function mostrarModalTransporte(pedidoId) {
    document.getElementById('transporte_pedido_id').value = pedidoId;
    document.getElementById('modalTransporte').style.display = 'block';
}
function mostrarModalCambiarEstado(pedidoId, estadoActual) {
    document.getElementById('cambiar_estado_pedido_id').value = pedidoId;
    
    const rol = '<?php echo htmlspecialchars($rol); ?>';
    const select = document.getElementById('nuevo_estado_select');
    
    // Matriz de transiciones por rol
    const transicionesPorRol = {
                'Super Admin': {
            'pendiente_pago': ['pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'cancelado', 'incidencia'],
            'pendiente_parcial': ['pendiente_pago', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'cancelado', 'incidencia'],
            'pendiente_entrega': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'cancelado', 'incidencia'],
            'pendiente_entrega_pago': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'cancelado', 'incidencia'],
            'pendiente_verificacion': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'cancelado', 'incidencia'],
            'pago_confirmado': ['empaquetado', 'transporte', 'entregado', 'cancelado', 'incidencia'],
            'empaquetado': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'transporte', 'entregado', 'cancelado', 'incidencia'],
            'transporte': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'entregado', 'cancelado', 'incidencia'],
            'entregado': ['incidencia'],
            'incidencia': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'cancelado'],
            'cancelado': []
        },
                'Gerente': {
            'pendiente_pago': ['pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'incidencia'],
            'pendiente_parcial': ['pendiente_pago', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'incidencia'],
            'pendiente_entrega': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'incidencia'],
            'pendiente_entrega_pago': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'incidencia'],
            'pendiente_verificacion': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado', 'incidencia'],
            'pago_confirmado': ['empaquetado', 'transporte', 'entregado', 'incidencia'],
            'empaquetado': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'transporte', 'entregado', 'incidencia'],
            'transporte': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'entregado', 'incidencia'],
            'entregado': ['incidencia'],
            'incidencia': ['pendiente_pago', 'pendiente_parcial', 'pendiente_entrega', 'pendiente_entrega_pago', 'pendiente_verificacion', 'pago_confirmado', 'empaquetado', 'transporte', 'entregado'],
            'cancelado': []
        },
                'Proveedor': {
            'pendiente_pago': ['cancelado'],
            'pendiente_parcial': ['cancelado'],
            'pendiente_entrega': ['cancelado', 'empaquetado'],
            'pendiente_entrega_pago': ['cancelado', 'empaquetado'],
            'pendiente_verificacion': ['cancelado'],
            'pagado': ['cancelado', 'empaquetado'],
            'empaquetado': ['cancelado', 'transporte', 'entregado', 'incidencia'],
            'transporte': ['cancelado', 'entregado', 'incidencia'],
            'entregado': ['incidencia'],
            'pago_confirmado': ['cancelado', 'empaquetado', 'transporte', 'entregado', 'incidencia'],
            'incidencia': ['cancelado', 'empaquetado'],
            'cancelado': []
        },
        'Vendedor': {
            'pago_confirmado': ['empaquetado', 'transporte', 'incidencia'],
            'pagado': ['empaquetado', 'incidencia'],
            'pendiente_entrega': ['empaquetado', 'incidencia'],
            'pendiente_entrega_pago': ['empaquetado', 'incidencia']
        },
        'Empaquetador': {
            'pago_confirmado': ['empaquetado', 'transporte', 'incidencia'],
            'empaquetado': ['transporte', 'incidencia']
        },
        'Transportista': {
            'transporte': ['entregado', 'incidencia']
        }
    };
    
    // Filtrar opciones del select
    const transiciones = transicionesPorRol[rol] || {};
    const permitidas = transiciones[estadoActual] || [];
    
    // Ocultar todas las opciones que no estén permitidas
    for (let i = 0; i < select.options.length; i++) {
        if (permitidas.includes(select.options[i].value)) {
            select.options[i].style.display = '';
        } else {
            select.options[i].style.display = 'none';
        }
    }
    
    // Seleccionar la primera opción permitida
    for (let i = 0; i < select.options.length; i++) {
        if (permitidas.includes(select.options[i].value)) {
            select.selectedIndex = i;
            break;
        }
    }
    
    document.getElementById('modalCambiarEstado').style.display = 'block';
}

function toggleNoEntrega() {
    const select = document.getElementById('no_entrega_select');
    const otroDiv = document.getElementById('no_entrega_otro');
    otroDiv.style.display = select.value === 'otro' ? 'block' : 'none';
}
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) event.target.style.display = 'none';
};
</script>

<?php $conn->close(); ?>
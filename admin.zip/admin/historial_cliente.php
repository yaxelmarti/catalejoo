<?php
require_once '../header.php';
require_once '../conexion.php';

if (!isset($permisos['crear']) || !$permisos['crear']) {
    header('Location: ../admin.php?error=permiso');
    exit;
}

$cliente_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$cliente_id) {
    header('Location: reportes_clientes.php');
    exit;
}

// Obtener información del cliente
$stmt = $conn->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$cliente = $stmt->get_result()->fetch_assoc();

if (!$cliente) {
    header('Location: reportes_clientes.php');
    exit;
}

// Obtener todos los carritos del cliente
$stmt = $conn->prepare("
    SELECT ca.*,
           (SELECT COUNT(*) FROM carrito_productos WHERE carrito_id = ca.id) as total_productos,
           (SELECT SUM(cantidad) FROM carrito_productos WHERE carrito_id = ca.id) as total_items,
           (SELECT SUM(cantidad * precio_unitario) FROM carrito_productos WHERE carrito_id = ca.id) as total_monto
    FROM carritos ca
    WHERE ca.cliente_id = ?
    ORDER BY ca.fecha_inicio DESC
");
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$carritos = $stmt->get_result();

// Estadísticas del cliente
$stats = $conn->prepare("
    SELECT 
        COUNT(*) as total_carritos,
        SUM(CASE WHEN estado = 'comprado' THEN 1 ELSE 0 END) as compras,
        SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
        SUM(CASE WHEN estado = 'cancelado' THEN 1 ELSE 0 END) as cancelados,
        SUM(CASE WHEN estado = 'comprado' THEN (SELECT SUM(cantidad * precio_unitario) FROM carrito_productos WHERE carrito_id = carritos.id) ELSE 0 END) as total_gastado
    FROM carritos
    WHERE cliente_id = ?
");
$stats->bind_param("i", $cliente_id);
$stats->execute();
$stats_data = $stats->get_result()->fetch_assoc();
?>

<!-- ============================================ -->
<!-- ESTILOS -->
<!-- ============================================ -->
<style>
:root {
    --primary: #667eea;
    --secondary: #764ba2;
}

.container {
    max-width: 1400px;
    margin: 2rem auto;
    padding: 0 2rem;
}

.cliente-header {
    background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
    color: white;
    padding: 2rem;
    border-radius: 10px;
    margin-bottom: 2rem;
}

.cliente-header h2 {
    margin-bottom: 0.5rem;
    font-size: 1.8rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 8px;
    padding: 1rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.stat-card .label {
    font-size: 0.8rem;
    color: #718096;
    text-transform: uppercase;
}

.stat-card .value {
    font-size: 1.5rem;
    font-weight: 700;
    color: #2d3748;
}

.tabla-clientes {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
}

.tabla-clientes table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.9rem;
}

.tabla-clientes th {
    background: #f8fafc;
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: #4a5568;
    border-bottom: 2px solid #e2e8f0;
}

.tabla-clientes td {
    padding: 1rem;
    border-bottom: 1px solid #edf2f7;
}

.badge-estado {
    padding: 0.3rem 0.8rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    color: white;
    display: inline-block;
}

.badge-pendiente { background: #ecc94b; }
.badge-comprado { background: #48bb78; }
.badge-cancelado { background: #f56565; }

.btn-accion {
    background: #667eea;
    color: white;
    padding: 0.3rem 0.8rem;
    border-radius: 4px;
    text-decoration: none;
    font-size: 0.8rem;
}

.btn-secondary {
    background: #edf2f7;
    color: #4a5568;
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
}

.btn-secondary:hover {
    background: #e2e8f0;
}

.text-right { text-align: right; }
.text-center { text-align: center; }
.sin-datos { padding: 2rem; color: #a0aec0; }

@media (max-width: 768px) {
    .container { padding: 0 1rem; }
    .stats-grid { grid-template-columns: 1fr; }
}
</style>

<div class="container">
    <!-- CABECERA -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <h1>📋 Historial del Cliente</h1>
        <a href="../reportes.php?tab=clientes" class="btn-volver">← Volver a Clientes</a>
    </div>
    
    <!-- Información del cliente -->
    <div class="cliente-header">
        <h2><?php echo htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellidos']); ?></h2>
        <p style="opacity: 0.9;">📧 <?php echo htmlspecialchars($cliente['email']); ?> | 📄 <?php echo htmlspecialchars($cliente['documento']); ?> | 📱 <?php echo htmlspecialchars($cliente['movil']); ?></p>
        <p style="opacity: 0.9;">📅 Registrado el <?php echo date('d/m/Y', strtotime($cliente['fecha_registro'])); ?></p>
    </div>
    
    <!-- Estadísticas -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Total carritos</div>
            <div class="value"><?php echo $stats_data['total_carritos']; ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Compras</div>
            <div class="value"><?php echo $stats_data['compras']; ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Pendientes</div>
            <div class="value"><?php echo $stats_data['pendientes']; ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Cancelados</div>
            <div class="value"><?php echo $stats_data['cancelados']; ?></div>
        </div>
        <div class="stat-card">
            <div class="label">Total gastado</div>
            <div class="value">$<?php echo number_format($stats_data['total_gastado'] ?? 0, 2); ?></div>
        </div>
    </div>
    
    <!-- Lista de carritos -->
    <div class="tabla-clientes">
        <h3 style="margin-bottom: 1rem;">🛒 Carritos del Cliente</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Fecha inicio</th>
                    <th>Fecha cierre</th>
                    <th>Estado</th>
                    <th>Productos</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($carritos->num_rows > 0): ?>
                    <?php while($c = $carritos->fetch_assoc()): 
                        $estado_class = match($c['estado']) {
                            'pendiente' => 'badge-pendiente',
                            'comprado' => 'badge-comprado',
                            'cancelado' => 'badge-cancelado',
                            default => ''
                        };
                    ?>
                    <tr>
                        <td>#<?php echo $c['id']; ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($c['fecha_inicio'])); ?></td>
                        <td><?php echo $c['fecha_cierre'] ? date('d/m/Y H:i', strtotime($c['fecha_cierre'])) : '-'; ?></td>
                        <td><span class="badge-estado <?php echo $estado_class; ?>"><?php echo ucfirst($c['estado']); ?></span></td>
                        <td class="text-center"><?php echo $c['total_productos']; ?></td>
                        <td class="text-center"><?php echo $c['total_items']; ?></td>
                        <td class="text-right">$<?php echo number_format($c['total_monto'] ?? 0, 2); ?></td>
                        <td>
                            <a href="detalle_carrito.php?id=<?php echo $c['id']; ?>" class="btn-accion">Ver</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center sin-datos">📭 Este cliente no tiene carritos</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$conn->close();
?>
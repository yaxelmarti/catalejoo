<?php
// ============================================
// GESTIÓN DE PROVEEDORES - SEGURO (VERSIÓN MEJORADA)
// Ubicación: /admin/proveedores/gestionar_proveedores.php
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../../includes/proveedor_utils.php';
require_once __DIR__ . '/../../includes/csrf.php';
require_once __DIR__ . '/../../includes/cola_correos.php';
require_once __DIR__ . '/../../header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

$rol_actual = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

// ============================================
// VERIFICACIÓN DE PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    error_log("[gestionar_proveedores] Permiso denegado. Rol: $rol_actual, usuario: $usuario_id_actual");
    header('Location: /admin.php?error=permiso');
    exit;
}

$roles_gestion = ['Super Admin', 'Gerente'];
$puede_gestionar = in_array($rol_actual, $roles_gestion, true);

// ============================================
// COLORES DE CONFIGURACIÓN
// ============================================
$color_primario = '#667eea';
$color_secundario = '#764ba2';
$stmt_c = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_primario' LIMIT 1");
if ($stmt_c) {
    $stmt_c->execute();
    $row_c = $stmt_c->get_result()->fetch_assoc();
    if ($row_c && !empty($row_c['valor'])) $color_primario = $row_c['valor'];
    $stmt_c->close();
}
$stmt_c2 = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'color_secundario' LIMIT 1");
if ($stmt_c2) {
    $stmt_c2->execute();
    $row_c2 = $stmt_c2->get_result()->fetch_assoc();
    if ($row_c2 && !empty($row_c2['valor'])) $color_secundario = $row_c2['valor'];
    $stmt_c2->close();
}

// ============================================
// OBTENER ID REAL DEL ROL "PROVEEDOR"
// ============================================
$rol_proveedor_id = 0;
$stmt_rol = $conn->prepare("SELECT id FROM roles WHERE nombre = 'Proveedor' LIMIT 1");
if ($stmt_rol) {
    $stmt_rol->execute();
    $row_rol = $stmt_rol->get_result()->fetch_assoc();
    if ($row_rol) $rol_proveedor_id = intval($row_rol['id']);
    $stmt_rol->close();
}
if ($rol_proveedor_id <= 0) {
    error_log("[gestionar_proveedores] No se encontró el rol 'Proveedor' en la tabla roles");
}

// ============================================
// FUNCIONES DE SEGURIDAD MEJORADAS
// ============================================
function sanitizarInput($data) {
    if (is_array($data)) {
        return array_map('sanitizarInput', $data);
    }
    $data = trim($data);
    $data = stripslashes($data);
    // ⚠️ NO aplicar htmlspecialchars al guardar en BD
    // Se aplica al MOSTRAR (en los outputs)
    return $data;
}

function generarSlug($texto) {
    $texto = strtolower($texto);
    $texto = str_replace(['á','é','í','ó','ú','ñ','ü'], ['a','e','i','o','u','n','u'], $texto);
    $texto = preg_replace('/[^a-z0-9]+/', '-', $texto);
    $texto = trim($texto, '-');
    return $texto;
}

function validarImagenWEBP($archivo) {
    // Verificar que el servidor soporte WEBP
    if (!function_exists('imagecreatefromwebp')) {
        return ['success' => false, 'error' => '❌ El servidor no soporta el formato WEBP'];
    }
    
    // Validar tipo MIME
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $archivo['tmp_name']);
    finfo_close($finfo);
    
    if ($mime_type !== 'image/webp') {
        return ['success' => false, 'error' => '❌ Solo se permiten archivos WEBP'];
    }
    
    // Validar tamaño (500KB max)
    if ($archivo['size'] > 500000) {
        return ['success' => false, 'error' => '❌ La imagen no puede superar los 500KB'];
    }
    
    // Validar dimensiones
    $dimensiones = getimagesize($archivo['tmp_name']);
    if ($dimensiones !== false) {
        if ($dimensiones[0] > 1920 || $dimensiones[1] > 1080) {
            return ['success' => false, 'error' => '❌ La imagen es demasiado grande (máx. 1920x1080)'];
        }
    }
    
    return ['success' => true];
}

function validarDocumento($documento, $pais = 'GT') {
    // Si está vacío, es válido (campo opcional)
    if (empty($documento)) {
        return true;
    }
    
    // Ejemplo para Guatemala
    if ($pais === 'GT') {
        // Cédula: 8 dígitos
        if (preg_match('/^\d{8}$/', $documento)) {
            return true;
        }
        // NIT: 8 dígitos + guión + 1 dígito
        if (preg_match('/^\d{8}-\d$/', $documento)) {
            return true;
        }
        // Pasaporte: letras y números (6-12 caracteres)
        if (preg_match('/^[A-Z0-9]{6,12}$/', $documento)) {
            return true;
        }
        return false;
    }
    return true; // Si no es GT, no validamos
}

function generarUsername($conn, $nombre_completo) {
    $partes = explode(' ', trim($nombre_completo));
    $nombre = strtolower($partes[0] ?? '');
    $apellido1 = isset($partes[1]) ? strtolower(substr($partes[1], 0, 1)) : '';
    $apellido2 = isset($partes[2]) ? strtolower(substr($partes[2], 0, 1)) : '';
    
    $base_username = 'p.' . $nombre . $apellido1 . $apellido2;
    $username = preg_replace('/[^a-z0-9.]/', '', $base_username);
    if ($username === 'p.' || $username === '') {
        $username = 'proveedor';
    }
    
    $final_username = $username;
    $counter = 1;
    $max_intentos = 1000;
    
    while ($counter <= $max_intentos) {
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE username = ? LIMIT 1");
        if (!$stmt) {
            break;
        }
        $stmt->bind_param("s", $final_username);
        $stmt->execute();
        $existe = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        
        if (!$existe) {
            break;
        }
        
        $final_username = $username . $counter;
        $counter++;
    }
    
    return $final_username;
}

function enviarCredenciales($conn, $email, $username, $password, $nombre_tienda, $nombre_contacto) {
    $asunto = "🔐 Tus credenciales de acceso - Catalejo";
    $mensaje = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f8fafc; padding: 30px; border-radius: 0 0 10px 10px; }
            .credenciales { background: white; padding: 15px; border-radius: 8px; margin: 15px 0; border-left: 4px solid #667eea; }
            .btn { display: inline-block; background: #667eea; color: white; padding: 12px 25px; text-decoration: none; border-radius: 8px; margin-top: 15px; }
            .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #999; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>¡Bienvenido a Catalejo!</h2>
            </div>
            <div class='content'>
                <p>Hola <strong>" . htmlspecialchars($nombre_contacto) . "</strong>,</p>
                <p>Has sido registrado como proveedor de <strong>" . htmlspecialchars($nombre_tienda) . "</strong>.</p>
                <p>Tus credenciales de acceso son:</p>
                <div class='credenciales'>
                    <p><strong>👤 Usuario:</strong> " . htmlspecialchars($username) . "</p>
                    <p><strong>🔑 Contraseña:</strong> " . htmlspecialchars($password) . "</p>
                </div>
                <p style='color: #e74c3c; font-size: 14px;'><strong>⚠️ Importante:</strong> Por seguridad, cambia tu contraseña en tu primer inicio de sesión.</p>
                <div style='text-align: center;'>
                    <a href='https://catalejoo.com/login' class='btn'>Iniciar sesión</a>
                </div>
            </div>
            <div class='footer'>
                <p>Este mensaje es automático, por favor no responder.</p>
                <p>&copy; " . date('Y') . " Catalejo - Todos los derechos reservados.</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    // Encolar el correo (pedido_id = null → correo general)
    return encolarCorreo($conn, $email, $asunto, $mensaje, null, null);
}

// ============================================
// PROCESAR ACCIONES
// ============================================
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
        // Validar CSRF
    $token = $_POST['csrf_token'] ?? '';
    if (!function_exists('csrf_validar') || !csrf_validar($token)) {
        error_log("[gestionar_proveedores] CSRF inválido. Usuario: $usuario_id_actual");
        $mensaje = '❌ Token de seguridad inválido';
        $tipo_mensaje = 'error';
    } else {
        
        // 1. CREAR PROVEEDOR
        if (isset($_POST['accion']) && $_POST['accion'] === 'crear') {
            try {
                $nombre_tienda = sanitizarInput($_POST['nombre_tienda']);
                $slug = !empty($_POST['slug']) ? sanitizarInput($_POST['slug']) : generarSlug($nombre_tienda);
                $descripcion = sanitizarInput($_POST['descripcion'] ?? '');
                $direccion = sanitizarInput($_POST['direccion'] ?? '');
                $telefono = sanitizarInput($_POST['telefono'] ?? '');
                $documento = sanitizarInput($_POST['documento'] ?? '');
                $activo = isset($_POST['activo']) ? 1 : 0;
                
                // Nuevos campos: Datos del dueño
                $nombre_contacto = sanitizarInput($_POST['nuevo_usuario_nombre']);
                $email = filter_var(trim($_POST['nuevo_usuario_email']), FILTER_SANITIZE_EMAIL);
                $password = $_POST['nuevo_usuario_password'];
                
                // ============================================
                // VALIDACIONES MEJORADAS
                // ============================================
                $errores = [];
                
                // 1. Campos obligatorios
                if (empty($nombre_tienda)) {
                    $errores[] = "El nombre de la tienda es obligatorio";
                }
                if (empty($nombre_contacto) || empty($email) || empty($password)) {
                    $errores[] = "Los datos del dueño son obligatorios";
                }
                
                // 2. Email válido
                if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errores[] = "Email del dueño no válido";
                }
                
                // 3. Contraseña mínima (mejorada a 8 caracteres)
                if (!empty($password) && strlen($password) < 8) {
                    $errores[] = "La contraseña debe tener al menos 8 caracteres";
                }
                
                // 4. Validar documento
                if (!empty($documento) && !validarDocumento($documento)) {
                    $errores[] = "Documento de identidad no válido (formato: 12345678, 12345678-9 o ABC123)";
                }
                
                if (empty($errores)) {
                    // ============================================
                    // VERIFICAR DUPLICADOS
                    // ============================================
                    
                    // 5. Verificar si el email ya existe en usuarios
                    $check = $conn->prepare("SELECT id FROM usuarios WHERE email = ? LIMIT 1");
if ($check) {
    $check->bind_param("s", $email);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $errores[] = "❌ El email '$email' ya está registrado como usuario";
    }
    $check->close();
}
                    
                    // 6. Verificar si el email ya existe en proveedores (como email de contacto)
                    $check = $conn->prepare("SELECT id FROM proveedores WHERE email = ? OR email_contacto = ?");
                    $check->bind_param("ss", $email, $email);
                    $check->execute();
                    if ($check->get_result()->num_rows > 0) {
                        $errores[] = "❌ El email '$email' ya está registrado como contacto de otro proveedor";
                    }
                    
                    // 7. Verificar si el nombre de la tienda ya existe
                    $check = $conn->prepare("SELECT id FROM proveedores WHERE nombre_tienda = ?");
                    $check->bind_param("s", $nombre_tienda);
                    $check->execute();
                    if ($check->get_result()->num_rows > 0) {
                        $errores[] = "❌ El nombre de tienda '$nombre_tienda' ya está en uso";
                    }
                    
                    // 8. Verificar si el slug ya existe
                    $check = $conn->prepare("SELECT id FROM proveedores WHERE slug = ?");
                    $check->bind_param("s", $slug);
                    $check->execute();
                    if ($check->get_result()->num_rows > 0) {
                        $errores[] = "❌ El slug '$slug' ya está en uso";
                    }
                }
                
                // ============================================
                // SI HAY ERRORES, MOSTRAR Y SALIR
                // ============================================
                if (!empty($errores)) {
                    $mensaje = "❌ " . implode("<br>❌ ", $errores);
                    $tipo_mensaje = "error";
                } else {
                    // ============================================
                    // PROCESAR IMAGEN (si se subió)
                    // ============================================
                    $imagen_url = null;
                    if (isset($_FILES['imagen_proveedor']) && $_FILES['imagen_proveedor']['error'] === UPLOAD_ERR_OK) {
                        $validacion = validarImagenWEBP($_FILES['imagen_proveedor']);
                        if (!$validacion['success']) {
                            $mensaje = $validacion['error'];
                            $tipo_mensaje = "error";
                        } else {
                            $nombre_archivo = $slug . '.webp';
                            $ruta_destino = $_SERVER['DOCUMENT_ROOT'] . '/uploads/proveedores/' . $nombre_archivo;
                            
                            if (!is_dir($_SERVER['DOCUMENT_ROOT'] . '/uploads/proveedores/')) {
                                mkdir($_SERVER['DOCUMENT_ROOT'] . '/uploads/proveedores/', 0777, true);
                            }
                            
                            if (move_uploaded_file($_FILES['imagen_proveedor']['tmp_name'], $ruta_destino)) {
                                $imagen_url = '/uploads/proveedores/' . $nombre_archivo;
                            }
                        }
                    }
                    
                                        if ($tipo_mensaje !== 'error') {
                        // ============================================
                        // 1-2-3. CREAR USUARIO + PROVEEDOR + USUARIO_PROVEEDOR
                        // EN UNA TRANSACCIÓN
                        // ============================================
                        $username = generarUsername($conn, $nombre_contacto);
                        $password_hash = password_hash($password, PASSWORD_DEFAULT);
                        
                        $email_ventas = filter_var(trim($_POST['email_ventas'] ?? ''), FILTER_SANITIZE_EMAIL);
                        if (empty($email_ventas)) {
                            $email_ventas = null;
                        }
                        
                        $conn->begin_transaction();
                        try {
                            // 1) INSERT USUARIO (rol_id real desde BD, no hardcodeado)
                            $sql_usuario = "INSERT INTO usuarios (username, email, password, nombre_completo, rol_id, activo) 
                                            VALUES (?, ?, ?, ?, ?, 1)";
                            $stmt_usuario = $conn->prepare($sql_usuario);
                            if (!$stmt_usuario) {
                                throw new Exception("prepare usuario: " . $conn->error);
                            }
                            $stmt_usuario->bind_param("ssssi", $username, $email, $password_hash, $nombre_contacto, $rol_proveedor_id);
                            if (!$stmt_usuario->execute()) {
                                throw new Exception("Error al crear usuario: " . $stmt_usuario->error);
                            }
                            $usuario_id = intval($conn->insert_id);
                            $stmt_usuario->close();
                            
                            // 2) INSERT PROVEEDOR
                            $sql = "INSERT INTO proveedores (usuario_id, nombre_tienda, slug, descripcion, direccion, telefono, documento, imagen_url, activo, nombre_contacto, email, email_ventas) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                            $stmt = $conn->prepare($sql);
                            if (!$stmt) {
                                throw new Exception("prepare proveedor: " . $conn->error);
                            }
                            $stmt->bind_param("isssssssisss", $usuario_id, $nombre_tienda, $slug, $descripcion, $direccion, $telefono, $documento, $imagen_url, $activo, $nombre_contacto, $email, $email_ventas);
                            if (!$stmt->execute()) {
                                throw new Exception("Error al crear proveedor: " . $stmt->error);
                            }
                            $proveedor_id = intval($conn->insert_id);
                            $stmt->close();
                            
                            // 3) INSERT USUARIO_PROVEEDOR (tabla intermedia)
                            $sql_up = "INSERT INTO usuario_proveedor (usuario_id, proveedor_id, activo) VALUES (?, ?, 1)";
                            $stmt_up = $conn->prepare($sql_up);
                            if (!$stmt_up) {
                                throw new Exception("prepare usuario_proveedor: " . $conn->error);
                            }
                            $stmt_up->bind_param("ii", $usuario_id, $proveedor_id);
                            if (!$stmt_up->execute()) {
                                throw new Exception("execute usuario_proveedor: " . $stmt_up->error);
                            }
                            $stmt_up->close();
                            
                            // COMMIT
                            $conn->commit();
                            error_log("[gestionar_proveedores] crear OK. Usuario: $usuario_id_actual, nuevo_usuario: $usuario_id, proveedor: $proveedor_id");
                            
                                                        // 4) ENCOLAR EMAIL CON CREDENCIALES (fuera de la transacción)
                            $email_encolado = enviarCredenciales($conn, $email, $username, $password, $nombre_tienda, $nombre_contacto);
                            
                            $mensaje = "✅ Proveedor creado correctamente.<br>👤 Usuario: <strong>" . htmlspecialchars($username) . "</strong><br>📧 Email: <strong>" . htmlspecialchars($email) . "</strong>";
                            if ($email_encolado) {
                                $mensaje .= "<br>📨 El correo con las credenciales se enviará en los próximos minutos.";
                            } else {
                                $mensaje .= "<br>⚠️ No se pudo encolar el correo con las credenciales.";
                                error_log("[gestionar_proveedores] Error al encolar email a: $email");
                            }
                            $tipo_mensaje = "exito";
                            
                        } catch (Throwable $e) {
                            $conn->rollback();
                            error_log("[gestionar_proveedores] crear ERROR: " . $e->getMessage());
                            $mensaje = "❌ " . $e->getMessage();
                            $tipo_mensaje = "error";
                        }
                    }
                }
            } catch (Exception $e) {
                error_log("Error en creación de proveedor: " . $e->getMessage());
                $mensaje = "❌ " . $e->getMessage();
                $tipo_mensaje = "error";
            }
        }
        
        // 2. EDITAR PROVEEDOR
        if (isset($_POST['accion']) && $_POST['accion'] === 'editar') {
            try {
                $id = intval($_POST['id']);
                $nombre_tienda = sanitizarInput($_POST['nombre_tienda']);
                $slug = !empty($_POST['slug']) ? sanitizarInput($_POST['slug']) : generarSlug($nombre_tienda);
                $descripcion = sanitizarInput($_POST['descripcion'] ?? '');
                $direccion = sanitizarInput($_POST['direccion'] ?? '');
                $telefono = sanitizarInput($_POST['telefono'] ?? '');
                $documento = sanitizarInput($_POST['documento'] ?? '');
                $activo = isset($_POST['activo']) ? 1 : 0;
                
                // Datos del dueño (opcionales en edición)
                $nombre_contacto = sanitizarInput($_POST['nuevo_usuario_nombre'] ?? '');
                $email = filter_var(trim($_POST['nuevo_usuario_email'] ?? ''), FILTER_SANITIZE_EMAIL);
                $nueva_password = $_POST['nuevo_usuario_password'] ?? '';
                
                // ============================================
                // VALIDACIONES MEJORADAS
                // ============================================
                $errores = [];
                
                // 1. Campos obligatorios
                if (empty($nombre_tienda)) {
                    $errores[] = "El nombre de la tienda es obligatorio";
                }
                if (empty($nombre_contacto) || empty($email)) {
                    $errores[] = "Los datos del dueño son obligatorios";
                }
                
                // 2. Email válido
                if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errores[] = "Email del dueño no válido";
                }
                
                // 3. Contraseña (solo si se proporciona) - mejorada a 8 caracteres
                if (!empty($nueva_password) && strlen($nueva_password) < 8) {
                    $errores[] = "La contraseña debe tener al menos 8 caracteres";
                }
                
                // 4. Validar documento
                if (!empty($documento) && !validarDocumento($documento)) {
                    $errores[] = "Documento de identidad no válido (formato: 12345678, 12345678-9 o ABC123)";
                }
                
                if (empty($errores)) {
                    // ============================================
                    // OBTENER USUARIO_ID DEL PROVEEDOR
                    // ============================================
                    $stmt = $conn->prepare("SELECT usuario_id FROM proveedores WHERE id = ? LIMIT 1");
if (!$stmt) {
    throw new Exception("prepare select proveedor: " . $conn->error);
}
$stmt->bind_param("i", $id);
$stmt->execute();
$row_prov = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$row_prov) {
    throw new Exception("Proveedor no encontrado");
}
$usuario_actual_id = intval($row_prov['usuario_id'] ?? 0);
                    
                    // ============================================
                    // VERIFICAR DUPLICADOS (excluyendo el actual)
                    // ============================================
                    
                    // 5. Verificar email en usuarios (excluyendo el actual)
                    $check = $conn->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
                    $check->bind_param("si", $email, $usuario_actual_id);
                    $check->execute();
                    if ($check->get_result()->num_rows > 0) {
                        $errores[] = "❌ El email '$email' ya está registrado como usuario";
                    }
                    
                    // 6. Verificar email en proveedores (excluyendo el actual)
                    $check = $conn->prepare("SELECT id FROM proveedores WHERE email = ? AND id != ?");
                    $check->bind_param("si", $email, $id);
                    $check->execute();
                    if ($check->get_result()->num_rows > 0) {
                        $errores[] = "❌ El email '$email' ya está registrado como contacto de otro proveedor";
                    }
                    
                    // 7. Verificar nombre de tienda (excluyendo el actual)
                    $check = $conn->prepare("SELECT id FROM proveedores WHERE nombre_tienda = ? AND id != ?");
                    $check->bind_param("si", $nombre_tienda, $id);
                    $check->execute();
                    if ($check->get_result()->num_rows > 0) {
                        $errores[] = "❌ El nombre de tienda '$nombre_tienda' ya está en uso";
                    }
                    
                    // 8. Verificar slug (excluyendo el actual)
                    $check = $conn->prepare("SELECT id FROM proveedores WHERE slug = ? AND id != ?");
                    $check->bind_param("si", $slug, $id);
                    $check->execute();
                    if ($check->get_result()->num_rows > 0) {
                        $errores[] = "❌ El slug '$slug' ya está en uso";
                    }
                }
                
                // ============================================
                // SI HAY ERRORES, MOSTRAR Y SALIR
                // ============================================
                if (!empty($errores)) {
                    $mensaje = "❌ " . implode("<br>❌ ", $errores);
                    $tipo_mensaje = "error";
                } else {
                                        // ============================================
                    // PROCESAR IMAGEN
                    // ============================================
                    $imagen_url = null;
                    if (isset($_FILES['imagen_proveedor']) && $_FILES['imagen_proveedor']['error'] === UPLOAD_ERR_OK) {
                        $validacion = validarImagenWEBP($_FILES['imagen_proveedor']);
                        if (!$validacion['success']) {
                            $mensaje = $validacion['error'];
                            $tipo_mensaje = "error";
                        } else {
                            $nombre_archivo = $slug . '.webp';
                            $ruta_destino = $_SERVER['DOCUMENT_ROOT'] . '/uploads/proveedores/' . $nombre_archivo;
                            
                            if (!is_dir($_SERVER['DOCUMENT_ROOT'] . '/uploads/proveedores/')) {
                                mkdir($_SERVER['DOCUMENT_ROOT'] . '/uploads/proveedores/', 0777, true);
                            }
                            
                            // Eliminar imagen anterior
                            $stmt_img = $conn->prepare("SELECT imagen_url FROM proveedores WHERE id = ? LIMIT 1");
                            if ($stmt_img) {
                                $stmt_img->bind_param("i", $id);
                                $stmt_img->execute();
                                $result_img = $stmt_img->get_result();
                                if ($row_img = $result_img->fetch_assoc()) {
                                    if (!empty($row_img['imagen_url'])) {
                                        $ruta_anterior = $_SERVER['DOCUMENT_ROOT'] . $row_img['imagen_url'];
                                        if (file_exists($ruta_anterior)) {
                                            unlink($ruta_anterior);
                                        }
                                    }
                                }
                                $stmt_img->close();
                            }
                            
                            if (move_uploaded_file($_FILES['imagen_proveedor']['tmp_name'], $ruta_destino)) {
                                $imagen_url = '/uploads/proveedores/' . $nombre_archivo;
                            }
                        }
                    } else {
                        // Mantener imagen actual
                        $stmt_img = $conn->prepare("SELECT imagen_url FROM proveedores WHERE id = ? LIMIT 1");
                        if ($stmt_img) {
                            $stmt_img->bind_param("i", $id);
                            $stmt_img->execute();
                            $result_img = $stmt_img->get_result();
                            if ($row_img = $result_img->fetch_assoc()) {
                                $imagen_url = $row_img['imagen_url'];
                            }
                            $stmt_img->close();
                        }
                    }
                    
                    if ($tipo_mensaje !== 'error') {
                        // ============================================
                        // 1-2. ACTUALIZAR USUARIO + PROVEEDOR EN TRANSACCIÓN
                        // ============================================
                        $conn->begin_transaction();
                        try {
                            // 1) ACTUALIZAR USUARIO
                            if ($usuario_actual_id) {
                                if (!empty($nueva_password)) {
                                    // Si se proporcionó nueva contraseña
                                    $password_hash = password_hash($nueva_password, PASSWORD_DEFAULT);
                                    $sql_usuario = "UPDATE usuarios SET nombre_completo = ?, email = ?, password = ? WHERE id = ?";
                                    $stmt_usuario = $conn->prepare($sql_usuario);
                                    if (!$stmt_usuario) {
                                        throw new Exception("prepare usuario (password): " . $conn->error);
                                    }
                                    $stmt_usuario->bind_param("sssi", $nombre_contacto, $email, $password_hash, $usuario_actual_id);
                                } else {
                                    // Sin cambiar contraseña
                                    $sql_usuario = "UPDATE usuarios SET nombre_completo = ?, email = ? WHERE id = ?";
                                    $stmt_usuario = $conn->prepare($sql_usuario);
                                    if (!$stmt_usuario) {
                                        throw new Exception("prepare usuario: " . $conn->error);
                                    }
                                    $stmt_usuario->bind_param("ssi", $nombre_contacto, $email, $usuario_actual_id);
                                }
                                if (!$stmt_usuario->execute()) {
                                    throw new Exception("execute usuario: " . $stmt_usuario->error);
                                }
                                $stmt_usuario->close();
                            }
                            
                            // 2) ACTUALIZAR PROVEEDOR
                            $email_ventas = filter_var(trim($_POST['email_ventas'] ?? ''), FILTER_SANITIZE_EMAIL);
                            if (empty($email_ventas)) {
                                $email_ventas = null;
                            }
                            
                            $sql = "UPDATE proveedores SET 
                                    nombre_tienda = ?, 
                                    slug = ?, 
                                    descripcion = ?, 
                                    direccion = ?, 
                                    telefono = ?, 
                                    documento = ?, 
                                    imagen_url = ?, 
                                    activo = ?, 
                                    nombre_contacto = ?, 
                                    email = ?,
                                    email_ventas = ?
                                    WHERE id = ?";
                            $stmt = $conn->prepare($sql);
                            if (!$stmt) {
                                throw new Exception("prepare proveedor: " . $conn->error);
                            }
                            $stmt->bind_param("sssssssssssi", $nombre_tienda, $slug, $descripcion, $direccion, $telefono, $documento, $imagen_url, $activo, $nombre_contacto, $email, $email_ventas, $id);
                            if (!$stmt->execute()) {
                                throw new Exception("Error al actualizar proveedor: " . $stmt->error);
                            }
                            $stmt->close();
                            
                            // COMMIT
                            $conn->commit();
                            error_log("[gestionar_proveedores] editar OK. Usuario: $usuario_id_actual, proveedor: $id");
                            $mensaje = "✅ Proveedor actualizado correctamente";
                            $tipo_mensaje = "exito";
                            
                        } catch (Throwable $e) {
                            $conn->rollback();
                            error_log("[gestionar_proveedores] editar ERROR: " . $e->getMessage());
                            $mensaje = "❌ " . $e->getMessage();
                            $tipo_mensaje = "error";
                        }
                    }
                }
            } catch (Exception $e) {
                error_log("Error en edición de proveedor: " . $e->getMessage());
                $mensaje = "❌ " . $e->getMessage();
                $tipo_mensaje = "error";
            }
        }
        
        // 3. ELIMINAR PROVEEDOR (mejorado)
        if (isset($_POST['accion']) && $_POST['accion'] === 'eliminar') {
            try {
                $id = intval($_POST['id']);
                
                // Obtener usuario_id antes de eliminar
                $stmt = $conn->prepare("SELECT usuario_id, imagen_url FROM proveedores WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();
                $proveedor_data = $result->fetch_assoc();
                
                if (!$proveedor_data) {
                    throw new Exception("Proveedor no encontrado");
                }
                
                $usuario_id = $proveedor_data['usuario_id'];
                
                // Verificar si tiene productos
                $check = $conn->prepare("SELECT COUNT(*) as total FROM productos WHERE proveedor_id = ?");
                $check->bind_param("i", $id);
                $check->execute();
                $result = $check->get_result();
                $row = $result->fetch_assoc();
                
                if ($row['total'] > 0) {
                    $mensaje = "❌ No se puede eliminar: el proveedor tiene $row[total] productos asignados";
                    $tipo_mensaje = "error";
                } else {
                    // Eliminar imagen
                    if (!empty($proveedor_data['imagen_url'])) {
                        $ruta_imagen = $_SERVER['DOCUMENT_ROOT'] . $proveedor_data['imagen_url'];
                        if (file_exists($ruta_imagen)) {
                            unlink($ruta_imagen);
                        }
                    }
                    
                    // Eliminar proveedor
                    $sql = "DELETE FROM proveedores WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $id);
                    
                    if ($stmt->execute()) {
                        // Eliminar también el usuario si no tiene otros proveedores
                        $check = $conn->prepare("SELECT COUNT(*) as total FROM proveedores WHERE usuario_id = ?");
                        $check->bind_param("i", $usuario_id);
                        $check->execute();
                        $result = $check->get_result();
                        $row = $result->fetch_assoc();
                        
                        if ($row['total'] == 0) {
                            $sql_user = "DELETE FROM usuarios WHERE id = ?";
                            $stmt_user = $conn->prepare($sql_user);
                            $stmt_user->bind_param("i", $usuario_id);
                            $stmt_user->execute();
                        }
                        
                        $mensaje = "✅ Proveedor eliminado correctamente";
                        $tipo_mensaje = "exito";
                    } else {
                        throw new Exception("Error al eliminar el proveedor");
                    }
                }
            } catch (Exception $e) {
                error_log("Error en eliminación de proveedor: " . $e->getMessage());
                $mensaje = "❌ " . $e->getMessage();
                $tipo_mensaje = "error";
            }
        }
    }
}

// ============================================
// OBTENER DATOS (con paginación opcional)
// ============================================
$pagina = isset($_GET['pagina']) ? intval($_GET['pagina']) : 1;
$limite = 20;
$offset = ($pagina - 1) * $limite;

// Contar total de proveedores para paginación
$sql_count = "SELECT COUNT(*) as total FROM proveedores";
$result_count = $conn->query($sql_count);
$total_registros = $result_count->fetch_assoc()['total'];
$total_paginas = ceil($total_registros / $limite);

$sql_proveedores = "SELECT p.*, u.username, u.email as usuario_email, u.nombre_completo as nombre_dueño 
                    FROM proveedores p 
                    LEFT JOIN usuarios u ON p.usuario_id = u.id 
                    ORDER BY p.fecha_registro DESC 
                    LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql_proveedores);
$proveedores = null;
if ($stmt) {
    $stmt->bind_param("ii", $limite, $offset);
    $stmt->execute();
    $proveedores = $stmt->get_result();
    $stmt->close();
} else {
    error_log("[gestionar_proveedores] prepare proveedores: " . $conn->error);
}

$sql_usuarios = "SELECT id, username, email FROM usuarios WHERE rol_id = 7 OR rol_id = 2 ORDER BY username";
$usuarios_lista = $conn->query($sql_usuarios);

$proveedor_editar = null;
if (isset($_GET['editar']) && is_numeric($_GET['editar'])) {
    $id_editar = intval($_GET['editar']);
    $stmt = $conn->prepare("SELECT * FROM proveedores WHERE id = ?");
    $stmt->bind_param("i", $id_editar);
    $stmt->execute();
    $result = $stmt->get_result();
    $proveedor_editar = $result->fetch_assoc();
}
?>

<style>
    :root {
        --primary: <?php echo htmlspecialchars($color_primario); ?>;
        --secondary: <?php echo htmlspecialchars($color_secundario); ?>;
        --danger: #ef4444;
        --success: #22c55e;
        --gray: #6b7280;
        --light-gray: #f3f4f6;
        --border: #e5e7eb;
        --radius: 12px;
        --shadow: 0 2px 10px rgba(0,0,0,0.08);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        background: #f8fafc;
        padding-top: 80px;
        color: #1f2937;
        line-height: 1.6;
    }

    .gestion-container {
        max-width: 1400px;
        margin: 1rem auto;
        padding: 0 1rem;
    }

        @media (min-width: 768px) {
            .gestion-container {
                margin: 2rem auto;
                padding: 0 2rem;
            }
        }

        .page-title {
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
            color: #1f2937;
        }

        @media (min-width: 768px) {
            .page-title {
                font-size: 2.2rem;
                margin-bottom: 2rem;
            }
        }

        .card {
            background: white;
            border-radius: var(--radius);
            padding: 1.25rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow);
            width: 100%;
            border: 1px solid var(--border);
        }

        @media (min-width: 768px) {
            .card {
                padding: 2rem;
                margin-bottom: 2rem;
            }
        }

        .card h3 {
            margin-bottom: 1.25rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--primary);
            color: #1f2937;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        @media (min-width: 768px) {
            .card h3 {
                font-size: 1.4rem;
                margin-bottom: 1.5rem;
            }
        }

        /* ===== FORMULARIO MEJORADO ===== */
.form-section {
    background: #f8fafc;
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 1.25rem;
    margin-bottom: 1.25rem;
}

@media (min-width: 768px) {
    .form-section {
        padding: 1.5rem;
    }
}

.form-section-title {
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--primary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin: 0 0 1rem 0;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid var(--border);
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.form-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1rem;
    margin-bottom: 0;
}

@media (min-width: 640px) {
    .form-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1.25rem;
    }
}

.form-group {
    margin-bottom: 0;
    width: 100%;
    min-width: 0;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 0.4rem;
    color: #374151;
    font-size: 0.85rem;
}

.form-group label .requerido {
    color: #ef4444;
    margin-left: 2px;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 0.7rem 0.8rem;
    border: 2px solid var(--border);
    border-radius: 8px;
    font-size: 16px;
    transition: all 0.3s;
    background: white;
    color: #1f2937;
    min-height: 44px;
    box-sizing: border-box;
}

.form-group textarea {
    min-height: 90px;
    resize: vertical;
    font-family: inherit;
    line-height: 1.5;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(102,126,234,0.15);
}

.form-group input[type="file"] {
    padding: 0.6rem;
    border: 2px dashed var(--border);
    background: var(--light-gray);
    cursor: pointer;
}

.form-group input[type="file"]:hover {
    background: #f1f5f9;
    border-color: var(--primary);
}

.form-group input[type="checkbox"] {
    width: 20px;
    height: 20px;
    margin: 0;
    cursor: pointer;
    accent-color: var(--primary);
    flex-shrink: 0;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    cursor: pointer;
    font-size: 0.9rem;
    padding: 0.5rem 0;
}

.campo-opcional {
    display: block;
    font-size: 0.75rem;
    color: #6b7280;
    margin-top: 0.3rem;
    font-weight: 400;
}

/* Sección de imagen */
.imagen-section {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

@media (min-width: 640px) {
    .imagen-section {
        flex-direction: row;
        align-items: flex-start;
    }
}

.imagen-section .form-group {
    flex: 1;
}

.imagen-preview-box {
    background: var(--light-gray);
    border: 2px dashed var(--border);
    border-radius: 10px;
    padding: 1rem;
    text-align: center;
    min-width: 150px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.imagen-preview-box img {
    max-width: 120px;
    max-height: 120px;
    border-radius: 8px;
    border: 2px solid white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    object-fit: cover;
}

.imagen-preview-box .imagen-vacia {
    font-size: 2.5rem;
    color: #d1d5db;
}

.imagen-preview-box small {
    font-size: 0.7rem;
    color: #6b7280;
}

/* Slug display mejorado */
.slug-display {
    background: var(--light-gray);
    padding: 0.7rem 0.8rem;
    border-radius: 8px;
    border: 2px solid var(--border);
    color: #4b5563;
    font-size: 0.85rem;
    cursor: not-allowed;
    width: 100%;
    font-family: monospace;
    word-break: break-all;
    min-height: 44px;
    display: flex;
    align-items: center;
}

/* Acciones del formulario */
.form-actions {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid var(--border);
}

@media (min-width: 480px) {
    .form-actions {
        flex-direction: row;
        justify-content: flex-end;
        gap: 1rem;
    }
}

/* Responsive móvil */
@media (max-width: 480px) {
    .form-section {
        padding: 1rem;
        margin-bottom: 1rem;
    }
    
    .form-grid {
        gap: 0.8rem;
    }
    
    .form-group input,
    .form-group select,
    .form-group textarea {
        padding: 0.65rem 0.7rem;
        font-size: 16px;
    }
    
    .form-section-title {
        font-size: 0.8rem;
    }
}

        .btn {
            padding: 0.7rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            font-size: 0.9rem;
            width: 100%;
        }

        @media (min-width: 480px) {
            .btn {
                width: auto;
                padding: 0.8rem 2rem;
            }
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102,126,234,0.35);
        }

        .btn-secondary {
            background: var(--light-gray);
            color: #374151;
            border: 1px solid var(--border);
        }

        .btn-secondary:hover {
            background: #e5e7eb;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-2px);
        }

        .tabla-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            margin-top: 1rem;
            width: 100%;
        }

        .tabla-wrapper table {
            width: 100%;
            min-width: 800px;
            border-collapse: collapse;
            font-size: 0.8rem;
        }

        @media (min-width: 768px) {
            .tabla-wrapper table {
                font-size: 0.9rem;
                min-width: 900px;
            }
        }

        .tabla-wrapper th {
            background: var(--light-gray);
            padding: 0.7rem 0.5rem;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid var(--border);
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        @media (min-width: 768px) {
            .tabla-wrapper th {
                padding: 1rem;
                font-size: 0.8rem;
            }
        }

        .tabla-wrapper td {
            padding: 0.7rem 0.5rem;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
            font-size: 0.75rem;
        }

        @media (min-width: 768px) {
            .tabla-wrapper td {
                padding: 1rem;
                font-size: 0.85rem;
            }
        }

        .tabla-wrapper tr:hover {
            background: #f8fafc;
        }

        .estado {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 500;
            white-space: nowrap;
        }

        @media (min-width: 768px) {
            .estado {
                padding: 0.3rem 0.8rem;
                font-size: 0.75rem;
            }
        }

        .estado.activo {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #86efac;
        }

        .estado.inactivo {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fca5a5;
        }

        .acciones-tabla {
            display: flex;
            gap: 0.3rem;
            flex-wrap: wrap;
        }

        @media (max-width: 640px) {
            .acciones-tabla {
                flex-direction: column;
                gap: 0.3rem;
            }
        }

        .btn-edit,
        .btn-delete {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.3rem;
            padding: 0.25rem 0.6rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.65rem;
            font-weight: 500;
            transition: all 0.2s;
            text-decoration: none;
            color: white;
        }

        @media (min-width: 768px) {
            .btn-edit,
            .btn-delete {
                padding: 0.35rem 0.8rem;
                font-size: 0.75rem;
            }
        }

        @media (max-width: 640px) {
            .btn-edit,
            .btn-delete {
                width: 100%;
                padding: 0.4rem;
                font-size: 0.7rem;
            }
        }

        .btn-edit {
            background: #3b82f6;
        }

        .btn-edit:hover {
            background: #2563eb;
        }

        .btn-delete {
            background: var(--danger);
        }

        .btn-delete:hover {
            background: #dc2626;
        }

        .mensaje {
            position: fixed;
            top: 80px;
            right: 20px;
            left: 20px;
            padding: 0.8rem 1rem;
            border-radius: 10px;
            z-index: 1000;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            font-size: 0.85rem;
            max-width: 500px;
            margin: 0 auto;
        }

        @media (min-width: 768px) {
            .mensaje {
                top: 90px;
                right: 30px;
                left: auto;
                padding: 1rem 1.5rem;
                max-width: 450px;
            }
        }

        .mensaje.exito {
            background: #dcfce7;
            color: #166534;
            border-left: 4px solid #22c55e;
        }

        .mensaje.error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .sin-datos {
            text-align: center;
            padding: 2rem;
            color: #9ca3af;
        }

        .slug-display {
            background: var(--light-gray);
            padding: 0.7rem 0.8rem;
            border-radius: 8px;
            border: 2px solid var(--border);
            color: #4b5563;
            font-size: 0.9rem;
            cursor: not-allowed;
            width: 100%;
        }

        .imagen-preview {
            margin-top: 0.5rem;
        }

        .imagen-preview img {
            max-width: 120px;
            max-height: 80px;
            border-radius: 8px;
            border: 1px solid var(--border);
            object-fit: cover;
        }

        @media (min-width: 768px) {
            .imagen-preview img {
                max-width: 150px;
                max-height: 100px;
            }
        }

        .imagen-preview p {
            font-size: 0.7rem;
            color: #6b7280;
            margin-top: 0.2rem;
        }

        .img-tabla {
            width: 35px;
            height: 35px;
            object-fit: cover;
            border-radius: 6px;
            border: 1px solid var(--border);
        }

        @media (min-width: 768px) {
            .img-tabla {
                width: 45px;
                height: 45px;
            }
        }

        .text-center {
            text-align: center;
        }

        .mt-1 { margin-top: 1rem; }
        .mb-1 { margin-bottom: 1rem; }
        .text-sm { font-size: 0.75rem; color: #6b7280; }
        
        /* Estilos para paginación */
        .paginacion {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1.5rem;
            flex-wrap: wrap;
        }

        .paginacion a, .paginacion span {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            color: #374151;
            background: var(--light-gray);
            border: 1px solid var(--border);
            transition: all 0.3s;
            font-size: 0.9rem;
        }

        .paginacion a:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .paginacion .actual {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .paginacion .disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .badge-documento {
            display: inline-block;
            padding: 0.15rem 0.5rem;
            border-radius: 4px;
            background: #f1f5f9;
            font-size: 0.7rem;
            color: #475569;
            border: 1px solid #e2e8f0;
        }

        @media (max-width: 480px) {
            .card {
                padding: 0.8rem;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
                gap: 0.8rem;
            }
            
            .page-title {
                font-size: 1.4rem;
            }
            
            .tabla-wrapper table {
                font-size: 0.7rem;
                min-width: 600px;
            }
            
            .tabla-wrapper td, 
            .tabla-wrapper th {
                padding: 0.4rem 0.3rem;
            }
        }
    </style>

<div class="gestion-container">
    <h1 class="page-title">🏪 Gestión de Proveedores</h1>
    
    <?php if ($mensaje): ?>
        <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
    <?php endif; ?>
    
    <!-- FORMULARIO (solo para Super Admin y Gerente) -->
    <?php if ($puede_gestionar): ?>
    <div class="card">
        <h3><?php echo $proveedor_editar ? '✏️ Editar Proveedor' : '➕ Crear Nuevo Proveedor'; ?></h3>
        
                <form method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="accion" value="<?php echo $proveedor_editar ? 'editar' : 'crear'; ?>">
            <?php if ($proveedor_editar): ?>
                <input type="hidden" name="id" value="<?php echo intval($proveedor_editar['id']); ?>">
            <?php endif; ?>
            
            <!-- SECCIÓN 1: DATOS DE LA TIENDA -->
            <div class="form-section">
                <h4 class="form-section-title">🏪 Datos de la Tienda</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre_tienda">Nombre de la Tienda <span class="requerido">*</span></label>
                        <input type="text" id="nombre_tienda" name="nombre_tienda" required 
                               value="<?php echo htmlspecialchars($proveedor_editar['nombre_tienda'] ?? ''); ?>"
                               oninput="generarSlugDesdeNombre(this.value)"
                               placeholder="Ej: Mi Tienda Online">
                    </div>
                    
                    <div class="form-group">
                        <label>Slug (URL amigable)</label>
                        <?php if ($proveedor_editar): ?>
                            <div class="slug-display" id="slug_display"><?php echo htmlspecialchars($proveedor_editar['slug'] ?? ''); ?></div>
                            <input type="hidden" name="slug" id="slug_hidden" value="<?php echo htmlspecialchars($proveedor_editar['slug'] ?? ''); ?>">
                        <?php else: ?>
                            <div class="slug-display" id="slug_display">Se generará automáticamente</div>
                            <input type="hidden" name="slug" id="slug_hidden" value="">
                        <?php endif; ?>
                        <small class="campo-opcional">Se genera desde el nombre de la tienda</small>
                    </div>
                </div>
                
                <div class="form-group" style="margin-top: 1rem;">
                    <label for="descripcion">Descripción</label>
                    <textarea id="descripcion" name="descripcion" rows="3" placeholder="Describe tu tienda brevemente..."><?php echo htmlspecialchars($proveedor_editar['descripcion'] ?? ''); ?></textarea>
                </div>
            </div>
            
            <!-- SECCIÓN 2: DATOS DEL DUEÑO -->
            <div class="form-section">
                <h4 class="form-section-title">👤 Datos del Dueño</h4>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nuevo_usuario_nombre">Nombre Completo <span class="requerido">*</span></label>
                        <input type="text" id="nuevo_usuario_nombre" name="nuevo_usuario_nombre" 
                               placeholder="Nombre completo del dueño" required
                               value="<?php echo htmlspecialchars($proveedor_editar['nombre_contacto'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="nuevo_usuario_email">Email <span class="requerido">*</span></label>
                        <input type="email" id="nuevo_usuario_email" name="nuevo_usuario_email" 
                               placeholder="email@ejemplo.com" required
                               value="<?php echo htmlspecialchars($proveedor_editar['email'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="email_ventas">📨 Email de Notificaciones</label>
                        <input type="email" id="email_ventas" name="email_ventas" 
                               placeholder="Opcional - Usa el email del dueño si está vacío"
                               value="<?php echo htmlspecialchars($proveedor_editar['email_ventas'] ?? ''); ?>">
                        <small class="campo-opcional">Recibirá notificaciones de pedidos</small>
                    </div>

                    <div class="form-group">
                        <label for="nuevo_usuario_password">Contraseña</label>
                        <input type="password" id="nuevo_usuario_password" name="nuevo_usuario_password" 
                               placeholder="<?php echo $proveedor_editar ? 'Dejar en blanco para mantener' : 'Mínimo 8 caracteres'; ?>" 
                               minlength="8">
                        <small class="campo-opcional"><?php echo $proveedor_editar ? 'Dejar en blanco para mantener la actual' : 'Mínimo 8 caracteres'; ?></small>
                    </div>

                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input type="text" id="telefono" name="telefono" 
                               placeholder="+53 555 1234"
                               value="<?php echo htmlspecialchars($proveedor_editar['telefono'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="documento">📄 Documento de Identidad</label>
                        <input type="text" id="documento" name="documento" 
                               placeholder="Pasaporte o Carné (opcional)"
                               value="<?php echo htmlspecialchars($proveedor_editar['documento'] ?? ''); ?>">
                        <small class="campo-opcional">Formato: 8 dígitos, 8-1 dígito o letras/números (6-12)</small>
                    </div>
                </div>
                
                <div class="form-group" style="margin-top: 1rem;">
                    <label for="direccion">Dirección</label>
                    <input type="text" id="direccion" name="direccion" 
                           placeholder="Dirección completa de la tienda"
                           value="<?php echo htmlspecialchars($proveedor_editar['direccion'] ?? ''); ?>">
                </div>
            </div>
            
            <!-- SECCIÓN 3: IMAGEN -->
            <div class="form-section">
                <h4 class="form-section-title">🖼️ Imagen de la Tienda</h4>
                <div class="imagen-section">
                    <div class="form-group">
                        <label for="imagen_proveedor">Subir imagen (WEBP, máx. 500KB)</label>
                        <input type="file" id="imagen_proveedor" name="imagen_proveedor" accept=".webp">
                        <small class="campo-opcional">Formato recomendado: WEBP, máx. 1920x1080. Se guardará como /uploads/proveedores/slug.webp</small>
                    </div>
                    
                    <div class="imagen-preview-box">
                        <?php if ($proveedor_editar && !empty($proveedor_editar['imagen_url'])): ?>
                            <img src="<?php echo htmlspecialchars($proveedor_editar['imagen_url']); ?>" alt="Imagen actual" id="preview_imagen">
                            <small>Imagen actual</small>
                        <?php else: ?>
                            <div class="imagen-vacia" id="preview_imagen_vacia">📷</div>
                            <small id="preview_texto">Sin imagen</small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- SECCIÓN 4: ESTADO -->
            <div class="form-section">
                <h4 class="form-section-title">⚙️ Estado</h4>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="activo" name="activo" value="1" 
                               <?php echo ($proveedor_editar && $proveedor_editar['activo']) ? 'checked' : ''; ?>>
                        <span>Proveedor activo (visible en la tienda)</span>
                    </label>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <?php echo $proveedor_editar ? '💾 Actualizar Proveedor' : '✨ Crear Proveedor'; ?>
                </button>
                <?php if ($proveedor_editar): ?>
                    <a href="/admin/proveedores/gestionar_proveedores.php" class="btn btn-secondary">Cancelar</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- LISTA DE PROVEEDORES -->
    <div class="card">
        <h3>📋 Proveedores Registrados (<?php echo $total_registros; ?>)</h3>
        
        <div class="tabla-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tienda</th>
                        <th>Slug</th>
                        <th>Proveedor</th>
                        <th>Email</th>
                        <th>Documento</th>
                        <th>Imagen</th>
                        <th>Estado</th>
                        <th>Registro</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($proveedores && $proveedores->num_rows > 0): ?>
                        <?php while($prov = $proveedores->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo intval($prov['id']); ?></td>
                            <td><strong><?php echo htmlspecialchars($prov['nombre_tienda']); ?></strong></td>
                            <td><?php echo htmlspecialchars($prov['slug']); ?></td>
                            <td>
    <strong><?php echo htmlspecialchars($prov['nombre_dueño'] ?? 'Sin nombre'); ?></strong>
    <span style="color: #9ca3af; font-size: 0.7rem; display: block;">
        (<?php echo htmlspecialchars($prov['username'] ?? 'sin-usuario'); ?>)
    </span>
</td>
                            <td><?php echo htmlspecialchars($prov['usuario_email'] ?? '—'); ?></td>
                            <td>
                                <?php if (!empty($prov['documento'])): ?>
                                    <span class="badge-documento"><?php echo htmlspecialchars($prov['documento']); ?></span>
                                <?php else: ?>
                                    <span style="color: #9ca3af;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($prov['imagen_url'])): ?>
                                    <img src="<?php echo htmlspecialchars($prov['imagen_url']); ?>" 
                                         class="img-tabla" alt="<?php echo htmlspecialchars($prov['nombre_tienda']); ?>">
                                <?php else: ?>
                                    <span style="color: #9ca3af;">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="estado <?php echo $prov['activo'] ? 'activo' : 'inactivo'; ?>">
                                    <?php echo $prov['activo'] ? '✅ Activo' : '❌ Inactivo'; ?>
                                </span>
                            </td>
                            <td><?php
    $ts_reg = strtotime($prov['fecha_registro'] ?? '');
    echo ($ts_reg !== false) ? date('d/m/Y', $ts_reg) : '—';
?></td>
                            <td>
                                <div class="acciones-tabla">
                                    <?php if ($puede_gestionar): ?>
                                        <a href="?editar=<?php echo intval($prov['id']); ?>" class="btn-edit">✏️ Editar</a>
                                        <?php if (intval($prov['id']) !== 1): ?>
    <form method="POST" style="display:inline;"
      onsubmit="return confirm('¿Eliminar proveedor ' + <?php echo htmlspecialchars(json_encode($prov['nombre_tienda']), ENT_QUOTES, 'UTF-8'); ?> + '? Esta acción no se puede deshacer.');">
    <input type="hidden" name="accion" value="eliminar">
    <input type="hidden" name="id" value="<?php echo intval($prov['id']); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn-delete">🗑️</button>
</form>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span style="color: #9ca3af; font-size: 0.75rem;">Solo lectura</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="sin-datos">📭 No hay proveedores registrados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Paginación -->
        <?php if ($total_paginas > 1): ?>
        <div class="paginacion">
            <?php if ($pagina > 1): ?>
                <a href="?pagina=<?php echo ($pagina - 1); ?>">◀ Anterior</a>
            <?php else: ?>
                <span class="disabled">◀ Anterior</span>
            <?php endif; ?>
            
            <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                <?php if ($i == $pagina): ?>
                    <span class="actual"><?php echo $i; ?></span>
                <?php else: ?>
                    <a href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($pagina < $total_paginas): ?>
                <a href="?pagina=<?php echo ($pagina + 1); ?>">Siguiente ▶</a>
            <?php else: ?>
                <span class="disabled">Siguiente ▶</span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function generarSlugDesdeNombre(nombre) {
    if (!nombre) {
        document.getElementById('slug_display').textContent = 'Se generará automáticamente';
        document.getElementById('slug_hidden').value = '';
        return;
    }
    let slug = nombre.toLowerCase();
    slug = slug.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    slug = slug.replace(/[^a-z0-9]+/g, '-');
    slug = slug.replace(/^-+|-+$/g, '');
    document.getElementById('slug_display').textContent = slug;
    document.getElementById('slug_hidden').value = slug;
}

document.addEventListener('DOMContentLoaded', function() {
    const nombreInput = document.getElementById('nombre_tienda');
    if (nombreInput && nombreInput.value) {
        generarSlugDesdeNombre(nombreInput.value);
    }
});

// Auto-cerrar mensajes después de 6 segundos
setTimeout(function() {
    const mensaje = document.querySelector('.mensaje');
    if (mensaje) {
        mensaje.style.transition = 'opacity 0.5s';
        mensaje.style.opacity = '0';
        setTimeout(() => mensaje.remove(), 500);
    }
}, 6000);
</script>

<?php
// No cerrar $conn (footer.php puede necesitarlo)
require_once __DIR__ . '/../../footer.php';
?>
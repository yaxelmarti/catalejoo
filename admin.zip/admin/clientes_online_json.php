<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();
require_once '../conexion.php';
require_once '../includes/cliente_identificador.php';

// Solo para administradores (protección)
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Limpiar inactivos (mayor a 2 minutos)
$conn->query("DELETE FROM clientes_online WHERE ultima_actividad < DATE_SUB(NOW(), INTERVAL 2 MINUTE)");

// Obtener clientes online con sus datos
$sql = "SELECT 
            c.id,
            c.nombre,
            c.apellidos,
            c.email,
            co.pagina_actual,
            co.ip_address,
            co.user_agent,
            co.ultima_actividad,
            co.uuid,
            TIMESTAMPDIFF(SECOND, co.ultima_actividad, NOW()) as segundos_inactivo
        FROM clientes_online co
        INNER JOIN clientes c ON co.cliente_id = c.id
        ORDER BY co.ultima_actividad DESC";

$result = $conn->query($sql);
$online = [];

while ($row = $result->fetch_assoc()) {
    // Formatear tiempo
    if ($row['segundos_inactivo'] < 60) {
        $row['tiempo'] = 'hace ' . $row['segundos_inactivo'] . ' seg';
    } else {
        $row['tiempo'] = 'hace ' . floor($row['segundos_inactivo'] / 60) . ' min';
    }
    
    // Extraer nombre del navegador del user_agent
    $ua = $row['user_agent'];
    if (strpos($ua, 'Chrome') !== false) $row['navegador'] = 'Chrome';
    elseif (strpos($ua, 'Firefox') !== false) $row['navegador'] = 'Firefox';
    elseif (strpos($ua, 'Safari') !== false) $row['navegador'] = 'Safari';
    elseif (strpos($ua, 'Edge') !== false) $row['navegador'] = 'Edge';
    else $row['navegador'] = substr($ua, 0, 30) . '...';
    
    $online[] = $row;
}

echo json_encode($online);
$conn->close();
?>
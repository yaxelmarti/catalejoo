<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    die('Acceso denegado.');
}

$rol_actual = $_SESSION['rol'] ?? '';
$usuario_id = $_SESSION['usuario_id'];

// ============================================
// ROLES PERMITIDOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Proveedor', 'Vendedor', 'Empaquetador', 'Transportista'];
if (!in_array($rol_actual, $roles_permitidos)) {
    die('Acceso denegado.');
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id, $rol_actual));

// ============================================
// VALIDAR IDs
// ============================================
$ids = $_GET['ids'] ?? '';
if (empty($ids)) {
    die('No se seleccionaron pedidos.');
}

$ids_array = array_filter(array_map('intval', explode(',', $ids)), function($id) { return $id > 0; });
$ids_array = array_unique($ids_array);

if (empty($ids_array)) {
    die('IDs no válidos.');
}

$ids_placeholders = implode(',', array_fill(0, count($ids_array), '?'));

// ============================================
// CONSULTAR PEDIDOS (con filtro de proveedor)
// ============================================
$sql_pedidos = "SELECT id, codigo, total, total_convertido, moneda, fecha_pedido, estado_actual 
                FROM pedidos 
                WHERE id IN ($ids_placeholders)";

$params = array_values($ids_array);
$types = str_repeat('i', count($ids_array));

if ($proveedor_id_usuario > 0) {
    $sql_pedidos .= " AND id IN (SELECT DISTINCT pedido_id FROM pedido_detalles WHERE proveedor_id = ?)";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
}

$sql_pedidos .= " ORDER BY id";

$stmt = $conn->prepare($sql_pedidos);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$pedidos = $stmt->get_result();

// ============================================
// PROCESAR PEDIDOS
// ============================================
$productos_resumen = [];
$total_general = 0;
$lista_ids = [];
$lista_codigos = [];

while ($pedido = $pedidos->fetch_assoc()) {
    $lista_ids[] = $pedido['id'];
    $lista_codigos[] = $pedido['codigo'];
    $total_general += $pedido['total'];
    
    // Obtener todos los detalles del pedido
    $stmt_prod = $conn->prepare("
        SELECT pd.producto_id, pd.combo_id, pd.cantidad, pd.precio_unitario, pd.subtotal,
               p.nombre AS producto_nombre
        FROM pedido_detalles pd
        LEFT JOIN productos p ON pd.producto_id = p.id
        WHERE pd.pedido_id = ?
    ");
    $stmt_prod->bind_param('i', $pedido['id']);
    $stmt_prod->execute();
    $detalles = $stmt_prod->get_result();
    $stmt_prod->close();
    
    while ($det = $detalles->fetch_assoc()) {
                // CASO 1: Producto normal (producto_id > 0, combo_id = NULL)
        if ($det['producto_id'] > 0 && empty($det['combo_id'])) {
            $key = 'p_' . $det['producto_id'];
            if (!isset($productos_resumen[$key])) {
                $productos_resumen[$key] = [
                    'nombre' => $det['producto_nombre'] ?: 'Producto #' . $det['producto_id'],
                    'cantidad_total' => 0
                ];
            }
            $productos_resumen[$key]['cantidad_total'] += $det['cantidad'];
            continue;
        }
        
        // CASO 2: Combo (producto_id = 0, combo_id > 0)
        if ($det['producto_id'] == 0 && $det['combo_id'] > 0) {
            // Obtener los productos del combo
            $stmt_cp = $conn->prepare("
                SELECT cp.producto_id, cp.cantidad AS cantidad_combo, p.nombre
                FROM combo_productos cp
                JOIN productos p ON cp.producto_id = p.id
                WHERE cp.combo_id = ?
            ");
            $stmt_cp->bind_param('i', $det['combo_id']);
            $stmt_cp->execute();
            $productos_combo = $stmt_cp->get_result();
            $stmt_cp->close();
            
            // Calcular el subtotal total del combo
            $subtotal_combo = floatval($det['subtotal']);
            $cantidad_combo = intval($det['cantidad']);
            
            // Sumar los productos del combo (multiplicando por la cantidad del combo en el pedido)
                        while ($pc = $productos_combo->fetch_assoc()) {
                $key = 'p_' . $pc['producto_id'];
                $cantidad_real = $pc['cantidad_combo'] * $cantidad_combo;
                
                if (!isset($productos_resumen[$key])) {
                    $productos_resumen[$key] = [
                        'nombre' => $pc['nombre'],
                        'cantidad_total' => 0
                    ];
                }
                $productos_resumen[$key]['cantidad_total'] += $cantidad_real;
            }
            continue;
        }
    }
}
$stmt->close();

// ============================================
// ORDENAR POR NOMBRE
// ============================================
usort($productos_resumen, function($a, $b) {
    return strcmp($a['nombre'], $b['nombre']);
});

// ============================================
// NOMBRE Y LOGO DE LA TIENDA
// ============================================
$nombre_tienda = 'Catalejoo';
$logo_url = '';

if ($proveedor_id_usuario > 0) {
    $stmt_tienda = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
    $stmt_tienda->bind_param("i", $proveedor_id_usuario);
    $stmt_tienda->execute();
    $tienda = $stmt_tienda->get_result()->fetch_assoc();
    $stmt_tienda->close();
    if ($tienda) {
        $nombre_tienda = $tienda['nombre_tienda'];
    }
}

$stmt_logo = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'logo_url' AND proveedor_id IN (?, 0) ORDER BY proveedor_id DESC LIMIT 1");
$stmt_logo->bind_param("i", $proveedor_id_usuario);
$stmt_logo->execute();
$logo_data = $stmt_logo->get_result()->fetch_assoc();
$stmt_logo->close();
if ($logo_data) {
    $logo_url = $logo_data['valor'];
}

$nombre_usuario = $_SESSION['username'] ?? 'Administrador';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resumen Consolidado de Productos</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Courier New', Courier, monospace; 
            font-size: 12px; 
            margin: 10px; 
            line-height: 1.2;
            background: white;
        }
        .no-print { margin-top: 60px; margin-bottom: 10px; }
        .no-print button { padding: 5px 10px; margin-right: 5px; cursor: pointer; }
        .header-pdf {
            text-align: center;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 2px solid #000;
        }
        .header-pdf img { max-height: 50px; margin-bottom: 5px; }
        .header-pdf h2 { font-size: 14px; margin: 5px 0 0; }
        h1 { font-size: 12px; text-align: center; margin: 0 0 10px; }
        .info { margin-bottom: 8px; border-bottom: 1px solid #ccc; padding-bottom: 4px; font-size: 14px; }
table { width: 100%; border-collapse: separate; border-spacing: 0; margin-top: 8px; }
th, td { padding: 3px 2px; text-align: left; border: none; }
th { border-bottom: 1px solid #000; }
th:last-child, td:last-child { padding-right: 40px; text-align: right; }
.text-right { text-align: right; }
        .total { margin-top: 10px; text-align: right; font-weight: bold; font-size: 12px; }
        .sin-datos { text-align: center; padding: 20px; color: #718096; }
        @media print {
            .no-print { display: none !important; }
            header, .site-header, nav, .header, .menu, .sidebar, .footer, .site-footer, 
            .modal, .btn, button, .close, .close-modal, .categorias-right-menu, 
            .side-menu, .bottom-overlay, .right-overlay, .menu-overlay { display: none !important; }
            body { margin: 0; padding: 0; }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()">🖨️ Imprimir / Guardar PDF</button>
        <button onclick="window.close()">Cerrar</button>
    </div>
    
    <div class="header-pdf">
        <?php if (!empty($logo_url) && file_exists($_SERVER['DOCUMENT_ROOT'] . $logo_url)): ?>
            <img src="<?php echo htmlspecialchars($logo_url); ?>" alt="<?php echo htmlspecialchars($nombre_tienda); ?>">
        <?php endif; ?>
        <h2><?php echo htmlspecialchars($nombre_tienda); ?></h2>
    </div>
    
    <h1>📊 RESUMEN CONSOLIDADO DE PRODUCTOS</h1>
    
    <?php if (empty($lista_ids)): ?>
        <div class="sin-datos">
            <p>No se encontraron pedidos para los IDs proporcionados.</p>
            <p>Es posible que los pedidos no existan o no tengas permiso para verlos.</p>
        </div>
    <?php else: ?>
    
    <div class="info">
        <strong>Pedidos:</strong> <?php echo htmlspecialchars(implode(', ', $lista_codigos)); ?><br>
        <strong>Total pedidos:</strong> <?php echo count($lista_ids); ?><br>
        <strong>Fecha generación:</strong> <?php echo date('d/m/Y H:i'); ?>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th class="text-right">Cantidad</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($productos_resumen)): ?>
            <tr>
                <td colspan="2" class="sin-datos">Sin productos</td>
            </tr>
        <?php else: ?>
            <?php foreach ($productos_resumen as $prod): ?>
                <tr>
                    <td><?php echo htmlspecialchars($prod['nombre']); ?></td>
                    <td class="text-right"><?php echo number_format($prod['cantidad_total'], 0); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
                </tbody>
    </table>
    
    <div class="total">
        Generado por: <?php echo htmlspecialchars($nombre_usuario); ?>
    </div>
    
    <?php endif; ?>
</body>
</html>
<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/moneda_funciones.php';

$pedido_id = isset($_GET['pedido']) ? intval($_GET['pedido']) : 0;
if ($pedido_id == 0) { header('Location: /index.php'); exit; }

// Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

// Validar que el pedido exista Y pertenezca al cliente
$stmt = $conn->prepare("SELECT p.* FROM pedidos p WHERE p.id = ? AND p.cliente_id = ?");
$stmt->bind_param("ii", $pedido_id, $cliente_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
if (!$pedido) { header('Location: /mis_pedidos.php'); exit; }

// ============================================
// MONEDA HISTÓRICA DEL PEDIDO
// ============================================
$moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
$moneda_simbolo = getSimboloPorMoneda($moneda_pedido);
$moneda_codigo = $moneda_pedido;

// Obtener proveedor del pedido
$stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
$stmt_prov->bind_param("i", $pedido_id);
$stmt_prov->execute();
$proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
$stmt_prov->close();

// ===== DETECTAR RESPUESTA DE PAYPAL V2 =====
$captura_paypal_ok = false;
$captura_paypal_error = false;

if (isset($_GET['token']) && !empty($_GET['token']) && $pedido['forma_pago'] == 'paypal') {
    
    // Si el pedido ya está pagado, no capturar de nuevo
    if (in_array($pedido['estado_pago'], ['pagado', 'completado'])) {
        $captura_paypal_ok = true;
    } else {
        // Obtener credenciales del proveedor (o global)
        $stmt_pp = $conn->prepare("
            SELECT clave, valor FROM configuracion 
            WHERE grupo = 'pagos' 
            AND proveedor_id = ? 
            AND clave IN ('paypal_client_id', 'paypal_client_secret', 'paypal_modo')
        ");
        $stmt_pp->bind_param("i", $proveedor_id);
        $stmt_pp->execute();
        $res_pp = $stmt_pp->get_result();
        $pp_datos = [];
        while ($row = $res_pp->fetch_assoc()) {
            $clave = str_replace('paypal_', '', $row['clave']);
            $pp_datos[$clave] = $row['valor'];
        }
        $stmt_pp->close();
        
        $client_id = $pp_datos['client_id'] ?? '';
        $client_secret = $pp_datos['client_secret'] ?? '';
        $modo = $pp_datos['modo'] ?? 'sandbox';
        
        if (!empty($client_id) && !empty($client_secret)) {
            require_once __DIR__ . '/pago/apis/api_paypal.php';
            
            $token = obtenerTokenPayPal($client_id, $client_secret, $modo);
            
            if (!empty($token)) {
                $order_id = $_GET['token'];
                $captura = ejecutarCapturaPayPal($token, $order_id, $modo);
                
                if ($captura && $captura['success']) {
                    $captura_paypal_ok = true;
                } else {
                    $captura_paypal_error = true;
                }
            } else {
                $captura_paypal_error = true;
            }
        }
    }
}

// Obtener dirección de entrega
$stmt = $conn->prepare("SELECT * FROM direcciones_envio WHERE pedido_id = ?");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$direccion = $stmt->get_result()->fetch_assoc();

// ===== OBTENER PRODUCTOS INDIVIDUALES =====
$stmt = $conn->prepare("SELECT pd.*, p.nombre FROM pedido_detalles pd JOIN productos p ON pd.producto_id = p.id WHERE pd.pedido_id = ?");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$productos = $stmt->get_result();
$productos_array = [];
while ($item = $productos->fetch_assoc()) {
    $item['tipo'] = 'producto';
    $productos_array[] = $item;
}

// ===== OBTENER COMBOS DEL PEDIDO CON SUS PRODUCTOS =====
$stmt_combos = $conn->prepare("SELECT pd.*, c.nombre 
                                FROM pedido_detalles pd 
                                JOIN combos c ON pd.combo_id = c.id 
                                WHERE pd.pedido_id = ?");
$stmt_combos->bind_param("i", $pedido_id);
$stmt_combos->execute();
$combos = $stmt_combos->get_result();

while ($combo = $combos->fetch_assoc()) {
    // Obtener productos del combo
    $stmt_prod_combo = $conn->prepare("SELECT cp.cantidad, p.nombre 
                                        FROM combo_productos cp 
                                        JOIN productos p ON cp.producto_id = p.id 
                                        WHERE cp.combo_id = ?");
    $stmt_prod_combo->bind_param("i", $combo['combo_id']);
    $stmt_prod_combo->execute();
    $productos_combo = $stmt_prod_combo->get_result();
    
    $productos_lista = [];
    while ($prod = $productos_combo->fetch_assoc()) {
        $productos_lista[] = '📦 ' . $prod['cantidad'] . 'x ' . $prod['nombre'];
    }
    
    $combo['tipo'] = 'combo';
    $combo['nombre'] = '🎁 ' . $combo['nombre'] . ' (' . count($productos_lista) . ' 📦)';
    $combo['productos_detalle'] = implode(', ', $productos_lista);
    $productos_array[] = $combo;
}

// ===== ORDENAR: primero productos, luego combos =====
usort($productos_array, function($a, $b) {
    if ($a['tipo'] === $b['tipo']) return 0;
    return ($a['tipo'] === 'producto') ? -1 : 1;
});

// Obtener nombre de la tienda desde configuración
$stmt_tienda = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'sitio_nombre'");
$stmt_tienda->execute();
$result_tienda = $stmt_tienda->get_result();
$nombre_tienda = ($result_tienda->num_rows > 0) ? $result_tienda->fetch_assoc()['valor'] : 'MI TIENDA';

// Función para obtener datos del método de pago
function obtenerDatosPago($conn, $metodo_pago, $proveedor_id = 0) {
    $datos = [];
    $like = $metodo_pago . '_%';
    
    // Buscar primero en el proveedor, luego en global
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE clave LIKE ? AND grupo = 'pagos' 
        AND proveedor_id IN (?, 0)
        ORDER BY proveedor_id DESC
    ");
    $stmt->bind_param("si", $like, $proveedor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $clave = str_replace($metodo_pago . '_', '', $row['clave']);
        if (!isset($datos[$clave])) {
            $datos[$clave] = $row['valor'];
        }
    }
    return $datos;
}

// ============================================
// CÁLCULOS CON CAMPOS CONVERTIDOS
// ============================================
// Preferir los campos *_convertido si existen (pedidos nuevos).
// Fallback: usar los USD base (pedidos viejos → moneda USD)

// Subtotal: sumar de items (subtotal_convertido si existe, si no subtotal USD)
$subtotal = 0;
foreach ($productos_array as $it) {
    $subtotal += isset($it['subtotal_convertido']) && $it['subtotal_convertido'] !== null
        ? floatval($it['subtotal_convertido'])
        : floatval($it['subtotal'] ?? 0);
}

// Envío: usar envío convertido si existe (envio está en moneda del pedido según procesar_pago.php)
$costo_envio = floatval($pedido['envio'] ?? 0);

// Total: usar total_convertido si existe, fallback a total (USD)
$total = !empty($pedido['total_convertido']) 
    ? floatval($pedido['total_convertido']) 
    : floatval($pedido['total']);

$fecha_estimada = date('d/m/Y', strtotime($pedido['fecha_pedido'] . ' +3 days'));

// Nombre del método: leer de tabla `pasarelas` (fallback: formatear slug)
$stmt_nombre_pas = $conn->prepare("SELECT nombre FROM pasarelas WHERE slug = ? LIMIT 1");
$stmt_nombre_pas->bind_param("s", $pedido['tipo_pago']);
$stmt_nombre_pas->execute();
$row_nombre_pas = $stmt_nombre_pas->get_result()->fetch_assoc();
$stmt_nombre_pas->close();

$nombre_metodo = !empty($row_nombre_pas['nombre']) 
    ? $row_nombre_pas['nombre'] 
    : ucfirst(str_replace('_', ' ', $pedido['tipo_pago']));

$datos_metodo = obtenerDatosPago($conn, $pedido['tipo_pago'], $proveedor_id);

// ===== MANEJAR RESPUESTAS DE PAGO =====
$mensaje_pago = '';
$tipo_mensaje = '';

// Prioridad 1: PayPal v2 (token capturado)
if ($captura_paypal_ok) {
    $mensaje_pago = '✅ Pago confirmado. Tu pedido está en proceso.';
    $tipo_mensaje = 'exito';
} elseif ($captura_paypal_error) {
    $mensaje_pago = '⚠️ Estamos verificando tu pago. En unos momentos se confirmará.';
    $tipo_mensaje = 'warning';
}
// Prioridad 2: Respuestas genéricas (Stripe, MercadoPago, etc.)
elseif (isset($_GET['pago'])) {
    $pago = $_GET['pago'];
    
    if ($pago == 'exitoso') {
        $mensaje_pago = '✅ Pago recibido correctamente. Tu pedido está en proceso.';
        $tipo_mensaje = 'exito';
    } elseif ($pago == 'error') {
        $mensaje_pago = '❌ Hubo un error al procesar el pago. Por favor, intenta de nuevo.';
        $tipo_mensaje = 'error';
    } elseif ($pago == 'cancelado') {
        $mensaje_pago = '⚠️ El pago fue cancelado. Tu pedido sigue pendiente.';
        $tipo_mensaje = 'warning';
    }
}

// Prioridad 3: Cancelación de PayPal
if (isset($_GET['cancelado']) && $_GET['cancelado'] == '1') {
    $mensaje_pago = '⚠️ Cancelaste el pago en PayPal. Tu pedido sigue pendiente.';
    $tipo_mensaje = 'warning';
}

// Prioridad 4: Error de pasarela
if (isset($_GET['error']) && $_GET['error'] == 'pasarela') {
    $mensaje_pago = '⚠️ La pasarela no está disponible en este momento. Contacta con soporte.';
    $tipo_mensaje = 'warning';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedido <?php echo $pedido['codigo']; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Poppins', sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 30px 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        @media (max-width: 768px) {
            body { padding: 20px 15px; }
        }
        .ticket {
            max-width: 850px;
            width: 100%;
            margin: 0 auto;
            background: white;
            border-radius: 28px;
            padding: 35px 40px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.3);
        }
        @media (max-width: 600px) {
            .ticket { padding: 20px; }
        }
        @media print {
            body { background: white; padding: 0; margin: 0; }
            .ticket { box-shadow: none; border-radius: 0; padding: 15px; }
            .no-print { display: none; }
        }
        .header { text-align: center; margin-bottom: 25px; }
        .logo { font-size: 28px; font-weight: 700; color: #667eea; margin-bottom: 5px; }
        .invoice-title { font-size: 14px; color: #718096; letter-spacing: 1px; }
        .factura-num { font-size: 22px; font-weight: 700; color: #2d3748; margin-top: 8px; }
        
        .info-grid {
            background: #f7fafc;
            border-radius: 20px;
            padding: 18px 20px;
            margin-bottom: 25px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .info-item { flex: 1; min-width: 130px; }
        .info-label { font-size: 11px; color: #718096; text-transform: uppercase; letter-spacing: 0.5px; }
        .info-value { font-size: 16px; font-weight: 600; color: #2d3748; margin-top: 5px; }
        
        .section-title {
            font-size: 17px;
            font-weight: 600;
            color: #2d3748;
            margin: 25px 0 15px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        table { width: 100%; border-collapse: collapse; margin: 5px 0; }
        th { 
            background: #f7fafc; 
            padding: 12px 10px; 
            font-size: 12px; 
            font-weight: 600; 
            color: #4a5568;
            text-align: left;
        }
        td { padding: 10px 10px; font-size: 14px; border-bottom: 1px solid #e2e8f0; }
        .producto-nombre { font-weight: 500; color: #2d3748; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        
        .totales {
            background: #f7fafc;
            border-radius: 20px;
            padding: 18px 20px;
            margin-top: 20px;
        }
        .total-linea { display: flex; justify-content: space-between; padding: 8px 0; font-size: 15px; }
        .total-final { display: flex; justify-content: space-between; padding: 12px 0 0; margin-top: 8px; border-top: 2px solid #e2e8f0; font-size: 19px; font-weight: 700; color: #667eea; }
        
        .pago-card {
            background: linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%);
            border-radius: 20px;
            padding: 18px 20px;
            margin: 15px 0;
        }
        .entrega-card {
            background: #fff5f5;
            border-radius: 20px;
            padding: 18px 20px;
            margin: 15px 0;
        }
        .info-line { display: flex; justify-content: space-between; padding: 8px 0; font-size: 14px; border-bottom: 1px dashed #e2e8f0; }
        .info-line:last-child { border-bottom: none; }
        
        .fecha-estimada {
            background: #667eea;
            color: white;
            border-radius: 16px;
            padding: 12px 20px;
            text-align: center;
            margin-top: 20px;
            font-weight: 500;
            font-size: 15px;
        }
        
        .footer { text-align: center; margin-top: 30px; padding-top: 18px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #a0aec0; }
        
        .botones {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 25px;
            flex-wrap: wrap;
        }
        .btn {
            display: inline-block;
            padding: 12px 28px;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 12px rgba(102,126,234,0.3);
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(102,126,234,0.4); }
        .btn-secondary {
            background: #edf2f7;
            color: #4a5568;
        }
        .btn-secondary:hover { background: #e2e8f0; transform: translateY(-2px); }
        
        @media (max-width: 600px) {
            .info-grid { flex-direction: column; gap: 12px; }
            th, td { font-size: 12px; padding: 8px 5px; }
            .btn { padding: 10px 20px; font-size: 13px; }
        }
    </style>
</head>
<body>
    <div class="ticket">
    <!-- MENSAJE DE PAGO -->
    <?php if (!empty($mensaje_pago)): ?>
    <div style="
        padding: 1rem 1.5rem;
        margin-bottom: 1.5rem;
        border-radius: 12px;
        font-weight: 600;
        text-align: center;
        <?php if ($tipo_mensaje == 'exito'): ?>
            background: #f0fff4;
            color: #22543d;
            border: 2px solid #48bb78;
        <?php elseif ($tipo_mensaje == 'error'): ?>
            background: #fff5f5;
            color: #742a2a;
            border: 2px solid #f56565;
        <?php else: ?>
            background: #fffaf0;
            color: #744210;
            border: 2px solid #ed8936;
        <?php endif; ?>
    ">
        <?php echo $mensaje_pago; ?>
    </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="header">
            <div class="logo">
    <?php 
    // Obtener la URL del logo desde configuración
    $stmt_logo = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'logo_url'");
    $stmt_logo->execute();
    $result_logo = $stmt_logo->get_result();
    $logo_url = ($result_logo->num_rows > 0) ? $result_logo->fetch_assoc()['valor'] : '';
    
    if (!empty($logo_url)): 
    ?>
        <img src="<?php echo htmlspecialchars($logo_url); ?>" alt="<?php echo htmlspecialchars($nombre_tienda); ?>" style="height: 40px; vertical-align: middle;">
        <span style="margin-left: 10px;"><?php echo htmlspecialchars($nombre_tienda); ?></span>
    <?php else: ?>
        🛍️ <?php echo htmlspecialchars($nombre_tienda); ?>
    <?php endif; ?>
</div>
            <div class="invoice-title">COMPROBANTE DE PEDIDO</div>
            <div class="factura-num"><?php echo $pedido['codigo']; ?></div>
        </div>
        
        <!-- Info rápida -->
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">📅 FECHA</div>
                <div class="info-value"><?php echo date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])); ?></div>
            </div>
                        <div class="info-item">
                <div class="info-label">💰 TOTAL</div>
                <div class="info-value"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($total, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">📦 ESTADO</div>
                <div class="info-value"><?php echo ucfirst(str_replace('_', ' ', $pedido['estado_actual'])); ?></div>
            </div>
        </div>
        
        <!-- Productos -->
        <div class="section-title">
            <span>📋</span> DETALLE DE PRODUCTOS
        </div>
        <table>
            <thead>
                <tr><th>Producto</th><th style="width:60px" class="text-center">Cant</th><th style="width:90px" class="text-right">Precio</th><th style="width:90px" class="text-right">Subtotal</th></tr>
            </thead>
            <tbody>
                                <?php foreach ($productos_array as $item): 
                    // Precios históricos del pedido
                    $precio_unit_hist = isset($item['precio_convertido']) && $item['precio_convertido'] !== null
                        ? floatval($item['precio_convertido'])
                        : floatval($item['precio_unitario'] ?? 0);
                    $subtotal_hist = isset($item['subtotal_convertido']) && $item['subtotal_convertido'] !== null
                        ? floatval($item['subtotal_convertido'])
                        : floatval($item['subtotal'] ?? 0);
                ?>
                <tr>
                    <td class="producto-nombre"><?php echo htmlspecialchars($item['nombre']); ?></td>
                    <td class="text-center"><?php echo $item['cantidad']; ?></td>
                    <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($precio_unit_hist, 2); ?></td>
                    <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($subtotal_hist, 2); ?></td>
                </tr>
                <?php if (isset($item['productos_detalle'])): ?>
                <tr>
                    <td colspan="4" style="padding: 5px 10px; font-size: 10px; color: #4a5568; background: #f7fafc; border-bottom: 1px solid #e2e8f0;">
                        <?php echo htmlspecialchars($item['productos_detalle']); ?>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
        
                <!-- Totales -->
        <div class="totales">
            <div class="total-linea">
                <span>📦 Subtotal</span>
                <span><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($subtotal, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
            </div>
            <div class="total-linea">
                <span>🚚 Envío</span>
                <span><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($costo_envio, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
            </div>
            <div class="total-final">
                <span>💰 TOTAL</span>
                <span><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($total, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
            </div>
           <?php 
$monto_pagado_conf = floatval($pedido['monto_pagado'] ?? 0);
$monto_pendiente_conf = floatval($pedido['monto_pendiente'] ?? 0);
$porcentaje_pagado_conf = intval($pedido['porcentaje_pagado'] ?? 0);

if ($monto_pagado_conf > 0 && $monto_pendiente_conf > 0): 
?>
<div class="total-linea" style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed #e2e8f0; color: #10b981;">
    <span>💸 Pagado (<?php echo $porcentaje_pagado_conf; ?>%):</span>
    <span><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_pagado_conf, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
</div>
<div class="total-linea" style="color: #ed8936;">
    <span>💵 A pagar al recibir:</span>
    <span><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_pendiente_conf, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
</div>
<?php endif; ?>
        </div>
        
        <!-- Datos del método de pago -->
        <?php if (!empty($datos_metodo)): ?>
        <div class="section-title">
            <span>💳</span> DATOS DEL PAGO
        </div>
        <div class="pago-card">
            <div class="info-line"><strong>💳 Método:</strong> <span><?php echo $nombre_metodo; ?></span></div>
            <?php foreach ($datos_metodo as $clave => $valor): ?>
                <?php if ($clave != 'activo' && $clave != 'modo' && !empty($valor)): ?>
                <div class="info-line">
                    <strong><?php echo ucfirst(str_replace('_', ' ', $clave)); ?>:</strong>
                    <span><?php echo htmlspecialchars($valor); ?></span>
                </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <!-- Datos de entrega -->
        <div class="section-title">
            <span>📍</span> DATOS DE ENTREGA
        </div>
        <div class="entrega-card">
            <div class="info-line"><strong>👤 Beneficiario:</strong> <span><?php echo htmlspecialchars($direccion['nombre_completo'] ?? '-'); ?></span></div>
            <div class="info-line"><strong>📄 Documento:</strong> <span><?php echo htmlspecialchars($direccion['documento'] ?? '-'); ?></span></div>
            <div class="info-line"><strong>📞 Teléfono:</strong> <span><?php echo htmlspecialchars($direccion['telefono'] ?? '-'); ?></span></div>
            <div class="info-line"><strong>🏠 Dirección:</strong> <span><?php echo htmlspecialchars($direccion['direccion'] ?? ''); ?>, <?php echo htmlspecialchars($direccion['municipio'] ?? ''); ?>, <?php echo htmlspecialchars($direccion['provincia'] ?? ''); ?></span></div>
            <?php if (!empty($direccion['instrucciones'])): ?>
            <div class="info-line"><strong>📝 Instrucciones:</strong> <span><?php echo htmlspecialchars($direccion['instrucciones']); ?></span></div>
            <?php endif; ?>
        </div>
        
        <!-- Fecha estimada -->
        <div class="fecha-estimada">
            📅 FECHA ESTIMADA DE ENTREGA: <strong><?php echo $fecha_estimada; ?></strong>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            ¡Gracias por confiar en nosotros!<br>
            <span class="no-print">© <?php echo date('Y'); ?> <?php echo htmlspecialchars($nombre_tienda); ?></span>
        </div>
        
        <!-- Botones -->
        <div class="botones no-print">
            <a href="/index.php" class="btn btn-secondary">← Volver a la tienda</a>
            <a href="/mis_pedidos.php" class="btn btn-primary">📋 Ver Mis Pedidos</a>
        </div>
    </div>
</body>
</html>
<?php
// ============================================
// PAGAR SALDO PENDIENTE - CHECKOUT SIMPLIFICADO
// ============================================
// Permite pagar el saldo de un pedido existente
// NO crea pedido, NO pide datos de entrega, NO recalcula envío
// ============================================

if (!defined('SEGURO')) {
    define('SEGURO', true);
}

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/moneda_funciones.php';

// 1. Obtener cliente
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

if ($cliente_id == 0) {
    header('Location: /index.php?error=login');
    exit;
}

// 2. Obtener pedido_id
$pedido_id = intval($_GET['pedido'] ?? 0);

if ($pedido_id == 0) {
    header('Location: /mis_pedidos.php');
    exit;
}

// 3. Validar pedido + cliente
$stmt = $conn->prepare("SELECT * FROM pedidos WHERE id = ? AND cliente_id = ?");
$stmt->bind_param("ii", $pedido_id, $cliente_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pedido) {
    header('Location: /mis_pedidos.php');
    exit;
}

// 4. Validar monto_pendiente > 0 y estado
$monto_pendiente = floatval($pedido['monto_pendiente'] ?? 0);

if ($monto_pendiente <= 0 || $pedido['estado_actual'] === 'cancelado') {
    $_SESSION['mensaje'] = '❌ Este pedido no tiene saldo pendiente.';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /mis_pedidos.php');
    exit;
}

// 5. Moneda del pedido
$moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
$moneda_simbolo = getSimboloPorMoneda($moneda_pedido);
$moneda_codigo = $moneda_pedido;

// 6. Obtener proveedor del pedido
$stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
$stmt_prov->bind_param("i", $pedido_id);
$stmt_prov->execute();
$proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
$stmt_prov->close();

if ($proveedor_id == 0) {
    header('Location: /mis_pedidos.php');
    exit;
}

// 7. Datos del proveedor
$stmt_tienda = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
$stmt_tienda->bind_param("i", $proveedor_id);
$stmt_tienda->execute();
$proveedor_data = $stmt_tienda->get_result()->fetch_assoc();
$stmt_tienda->close();
$nombre_tienda = $proveedor_data['nombre_tienda'] ?? 'Tienda';

// 8. Productos del pedido (sin precios)
$stmt_det = $conn->prepare("
    SELECT pd.*, 
           p.nombre AS prod_nombre, p.imagen_url AS prod_imagen,
           c.nombre AS combo_nombre, c.imagen_url AS combo_imagen
    FROM pedido_detalles pd
    LEFT JOIN productos p ON pd.producto_id = p.id AND pd.producto_id > 0
    LEFT JOIN combos c ON pd.combo_id = c.id AND pd.combo_id > 0
    WHERE pd.pedido_id = ?
    ORDER BY pd.producto_id DESC, pd.combo_id DESC
");
$stmt_det->bind_param("i", $pedido_id);
$stmt_det->execute();
$result_det = $stmt_det->get_result();
$items = [];
while ($row = $result_det->fetch_assoc()) {
    $items[] = $row;
}
$stmt_det->close();

// 9. Datos de entrega (solo lectura)
$stmt_dir = $conn->prepare("SELECT * FROM direcciones_envio WHERE pedido_id = ? LIMIT 1");
$stmt_dir->bind_param("i", $pedido_id);
$stmt_dir->execute();
$direccion = $stmt_dir->get_result()->fetch_assoc();
$stmt_dir->close();

// 10. Envío (moneda del pedido)
$envio = floatval($pedido['envio'] ?? 0);

// 11. Cargar pasarelas activas + activaciones del proveedor
$pasarelas_activas = [];
$stmt_pas = $conn->prepare("SELECT slug, nombre, tipo, icono, monedas, orden FROM pasarelas WHERE activo = 1 ORDER BY orden");
$stmt_pas->execute();
$res_pas = $stmt_pas->get_result();
while ($row = $res_pas->fetch_assoc()) {
    $pasarelas_activas[$row['slug']] = $row;
}
$stmt_pas->close();

$activaciones_proveedor = [];
$stmt_act = $conn->prepare("
    SELECT clave, valor FROM configuracion 
    WHERE grupo = 'pagos' AND proveedor_id = ? AND clave LIKE '%_activo'
");
$stmt_act->bind_param("i", $proveedor_id);
$stmt_act->execute();
$res_act = $stmt_act->get_result();
while ($row = $res_act->fetch_assoc()) {
    $slug = str_replace('_activo', '', $row['clave']);
    $activaciones_proveedor[$slug] = $row['valor'];
}
$stmt_act->close();

$total_metodos_proveedor = count(array_filter($activaciones_proveedor, function($v) { return $v == 1; }));
$proveedor_config_id = ($total_metodos_proveedor == 0) ? 0 : $proveedor_id;

// 12. Filtrar métodos por moneda + activos del proveedor
$metodos_pago = [];
foreach ($pasarelas_activas as $slug => $info) {
    $esta_activa = false;
    
    if ($proveedor_config_id > 0) {
        $esta_activa = isset($activaciones_proveedor[$slug]) && $activaciones_proveedor[$slug] == 1;
    } else {
        $stmt_glob = $conn->prepare("SELECT valor FROM configuracion WHERE clave = ? AND grupo = 'pagos' AND proveedor_id = 0 LIMIT 1");
        $clave_activo = $slug . '_activo';
        $stmt_glob->bind_param("s", $clave_activo);
        $stmt_glob->execute();
        $res_glob = $stmt_glob->get_result()->fetch_assoc();
        $stmt_glob->close();
        $esta_activa = ($res_glob && $res_glob['valor'] == 1);
    }
    
    if (!$esta_activa) continue;
    
    $monedas_pasarela = !empty($info['monedas']) 
        ? array_map('trim', explode(',', $info['monedas'])) 
        : [];
    
    if (!empty($monedas_pasarela) && !in_array($moneda_pedido, $monedas_pasarela)) {
        continue;
    }
    
    $stmt_com = $conn->prepare("SELECT valor FROM configuracion WHERE clave = ? AND grupo = 'pagos' AND proveedor_id = ?");
    $clave_com = $slug . '_comision';
    $stmt_com->bind_param("si", $clave_com, $proveedor_config_id);
    $stmt_com->execute();
    $com_data = $stmt_com->get_result()->fetch_assoc();
    $stmt_com->close();
    
    $metodos_pago[] = [
        'pasarela' => $slug,
        'nombre' => $info['nombre'],
        'icono' => $info['icono'],
        'comision' => $com_data ? floatval($com_data['valor']) : 0
    ];
}

// 13. Último método usado (preselección)
$ultimo_metodo = $pedido['tipo_pago'] ?? '';

// 14. CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pagar saldo - Pedido <?php echo htmlspecialchars($pedido['codigo']); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', sans-serif; background: #f8fafc; min-height: 100vh; padding: 1rem; }
.container { max-width: 600px; margin: 0 auto; }

.card { background: white; border-radius: 20px; padding: 2rem; box-shadow: 0 4px 20px rgba(0,0,0,0.05); margin-bottom: 1.5rem; }
.card h2 { font-size: 1.2rem; color: #2d3748; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e2e8f0; }

.header-pedido { text-align: center; margin-bottom: 1.5rem; }
.header-pedido h1 { font-size: 1.4rem; color: #2d3748; margin-bottom: 0.3rem; }
.header-pedido p { color: #718096; font-size: 0.9rem; }

.metodos-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.8rem; }
.metodo-item { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 1rem 0.5rem; border: 2px solid #e2e8f0; border-radius: 12px; cursor: pointer; transition: all 0.3s; text-align: center; background: white; }
.metodo-item:hover { border-color: #667eea; transform: translateY(-2px); }
.metodo-item.selected { border-color: #667eea; background: #f0f4ff; box-shadow: 0 0 15px rgba(102, 126, 234, 0.2); }
.metodo-item .icono { width: 100%; display: flex; flex-direction: column; align-items: center; gap: 2px; }
.metodo-item .icono img { width: 40px; height: 40px; object-fit: contain; }
.metodo-item .icono .nombre { font-size: 0.6rem; font-weight: 600; color: #4a5568; text-align: center; line-height: 1.1; word-break: break-word; }

.total-box { display: none; margin-top: 1.5rem; padding: 1.2rem; background: #f0fff4; border: 2px solid #48bb78; border-radius: 12px; text-align: center; }
.total-box.visible { display: block; }
.total-box .total-label { font-size: 0.9rem; color: #4a5568; margin-bottom: 0.5rem; }
.total-box .total-monto { font-size: 1.8rem; font-weight: 700; color: #22543d; margin-bottom: 1rem; }

.btn-pagar { width: 100%; padding: 1rem; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; border-radius: 12px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: all 0.3s; font-family: inherit; }
.btn-pagar:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(16,185,129,0.4); }
.btn-pagar:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

.productos-list { display: flex; flex-direction: column; gap: 0.8rem; }
.producto-item { display: flex; align-items: center; gap: 0.8rem; padding: 0.6rem; background: #f8fafc; border-radius: 10px; }
.producto-item img { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; background: #e2e8f0; }
.producto-item .info { flex: 1; }
.producto-item .info h4 { font-size: 0.9rem; color: #2d3748; margin-bottom: 0.2rem; }
.producto-item .info .cantidad { font-size: 0.8rem; color: #718096; }

.entrega-info { display: flex; flex-direction: column; gap: 0.6rem; }
.entrega-linea { display: flex; justify-content: space-between; padding: 0.4rem 0; border-bottom: 1px dashed #e2e8f0; font-size: 0.9rem; }
.entrega-linea:last-child { border-bottom: none; }
.entrega-linea .label { color: #718096; }
.entrega-linea .valor { color: #2d3748; font-weight: 500; text-align: right; }

.no-metodos { grid-column: 1 / -1; background: #fff5f5; border: 1px solid #fc8181; border-radius: 12px; padding: 1.2rem; color: #c53030; font-size: 0.9rem; text-align: center; line-height: 1.5; }

.btn-volver { display: block; text-align: center; margin-top: 1.5rem; color: #718096; text-decoration: none; font-size: 0.9rem; }
.btn-volver:hover { color: #667eea; }

@media (max-width: 480px) {
    .card { padding: 1.5rem; }
    .metodos-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (min-width: 768px) {
    .metodos-grid { grid-template-columns: repeat(3, 1fr); }
}
</style>
</head>
<body>
<div class="container">
    <div class="header-pedido">
        <h1>💰 Pagar saldo pendiente</h1>
        <p>Pedido <?php echo htmlspecialchars($pedido['codigo']); ?> - <?php echo htmlspecialchars($nombre_tienda); ?></p>
    </div>

    <!-- MÉTODOS DE PAGO -->
    <div class="card">
        <h2>💳 Selecciona método de pago</h2>
        <div class="metodos-grid" id="metodos_grid">
            <?php foreach ($metodos_pago as $metodo): ?>
            <div class="metodo-item <?php echo ($metodo['pasarela'] === $ultimo_metodo) ? 'selected' : ''; ?>" 
                 data-pasarela="<?php echo htmlspecialchars($metodo['pasarela']); ?>"
                 data-comision="<?php echo $metodo['comision']; ?>"
                 onclick="seleccionarMetodo(this)">
                <span class="icono">
                    <?php 
                    if (!empty($metodo['icono'])) {
                        $ruta_fisica = $_SERVER['DOCUMENT_ROOT'] . $metodo['icono'];
                        if (file_exists($ruta_fisica)) {
                            echo '<img src="' . htmlspecialchars($metodo['icono']) . '" alt="' . htmlspecialchars($metodo['nombre']) . '">';
                        } else {
                            echo '<span style="font-size: 1.8rem;">💰</span>';
                        }
                    } else {
                        echo '<span style="font-size: 1.8rem;">💰</span>';
                    }
                    ?>
                    <span class="nombre"><?php echo htmlspecialchars($metodo['nombre']); ?></span>
                </span>
            </div>
            <?php endforeach; ?>
            
            <?php if (empty($metodos_pago)): ?>
            <div class="no-metodos">
                ⚠️ <strong>No hay métodos de pago disponibles</strong> para la moneda <strong><?php echo htmlspecialchars($moneda_codigo); ?></strong>.<br>
                Por favor contacta al proveedor.
            </div>
            <?php endif; ?>
        </div>

        <!-- TOTAL + BOTÓN (oculto hasta seleccionar) -->
        <div class="total-box" id="total_box">
            <div class="total-label">Total a pagar:</div>
            <div class="total-monto" id="total_monto">—</div>
            <button type="button" class="btn-pagar" id="btn_pagar" onclick="procesarPago()">
                💰 Pagar
            </button>
        </div>
    </div>

    <!-- PRODUCTOS -->
    <div class="card">
        <h2>🛍️ Productos del pedido</h2>
        <div class="productos-list">
            <?php foreach ($items as $item): 
                $nombre = $item['prod_nombre'] ?? $item['combo_nombre'] ?? 'Producto';
                $imagen = $item['prod_imagen'] ?? $item['combo_imagen'] ?? '';
                $es_combo = !empty($item['combo_id']);
            ?>
            <div class="producto-item">
                <?php if (!empty($imagen)): ?>
                    <img src="/<?php echo ltrim(htmlspecialchars($imagen), '/'); ?>" alt="<?php echo htmlspecialchars($nombre); ?>">
                <?php else: ?>
                    <div style="width:50px;height:50px;background:#e2e8f0;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;">📦</div>
                <?php endif; ?>
                <div class="info">
                    <h4><?php echo $es_combo ? '🎁 ' : ''; ?><?php echo htmlspecialchars($nombre); ?></h4>
                    <div class="cantidad">Cantidad: <?php echo intval($item['cantidad']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <?php if (empty($items)): ?>
            <p style="color:#a0aec0;text-align:center;padding:1rem;">No hay productos en este pedido.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- DATOS DE ENTREGA (SOLO LECTURA) -->
    <div class="card">
        <h2>📍 Datos de entrega</h2>
        <div class="entrega-info">
            <div class="entrega-linea">
                <span class="label">Nombre:</span>
                <span class="valor"><?php echo htmlspecialchars($direccion['nombre_completo'] ?? '-'); ?></span>
            </div>
            <div class="entrega-linea">
                <span class="label">Dirección:</span>
                <span class="valor"><?php echo htmlspecialchars($direccion['direccion'] ?? '-'); ?></span>
            </div>
            <div class="entrega-linea">
                <span class="label">Municipio:</span>
                <span class="valor"><?php echo htmlspecialchars($direccion['municipio'] ?? '-'); ?></span>
            </div>
            <div class="entrega-linea">
                <span class="label">Provincia:</span>
                <span class="valor"><?php echo htmlspecialchars($direccion['provincia'] ?? '-'); ?></span>
            </div>
            <div class="entrega-linea">
                <span class="label">Teléfono:</span>
                <span class="valor"><?php echo htmlspecialchars($direccion['telefono'] ?? '-'); ?></span>
            </div>
            <div class="entrega-linea">
                <span class="label">Envío:</span>
                <span class="valor"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($envio, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
            </div>
        </div>
    </div>

    <a href="/mis_pedidos.php" class="btn-volver">← Volver a mis pedidos</a>
</div>

<script>
// ============================================
// DATOS DEL PEDIDO
// ============================================
const montoPendiente = <?php echo floatval($monto_pendiente); ?>;
const simbolo = '<?php echo htmlspecialchars($moneda_simbolo); ?>';
const codigo = '<?php echo htmlspecialchars($moneda_codigo); ?>';
const pedidoId = <?php echo intval($pedido_id); ?>;
const csrfToken = '<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>';

let metodoSeleccionado = '';
let comisionPorcentaje = 0;

// ============================================
// SELECCIONAR MÉTODO
// ============================================
function seleccionarMetodo(element) {
    document.querySelectorAll('.metodo-item').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    
    metodoSeleccionado = element.dataset.pasarela;
    comisionPorcentaje = parseFloat(element.dataset.comision) || 0;
    
    // Calcular total (base + comisión)
    const comision = montoPendiente * (comisionPorcentaje / 100);
    const total = montoPendiente + comision;
    
    // Mostrar total
    document.getElementById('total_monto').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
    document.getElementById('total_box').classList.add('visible');
    document.getElementById('btn_pagar').textContent = '💰 Pagar ' + simbolo + total.toFixed(2) + ' ' + codigo;
}

// ============================================
// PROCESAR PAGO
// ============================================
async function procesarPago() {
    if (!metodoSeleccionado) {
        alert('Selecciona un método de pago');
        return;
    }
    
    const btn = document.getElementById('btn_pagar');
    btn.disabled = true;
    btn.textContent = '⏳ Procesando...';
    
    const formData = new FormData();
    formData.append('csrf_token', csrfToken);
    formData.append('pedido_id', pedidoId);
    formData.append('metodo_pago', metodoSeleccionado);
    
    try {
        const resp = await fetch('/checkout/procesar_saldo_pendiente.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        
        const texto = await resp.text();
        let data;
        
        try {
            data = JSON.parse(texto);
        } catch (err) {
            console.error('Respuesta no-JSON:', texto);
            alert('Error inesperado del servidor.');
            btn.disabled = false;
            btn.textContent = '💰 Pagar';
            return;
        }
        
        if (!data.success) {
            alert(data.mensaje || 'Error al procesar el pago');
            btn.disabled = false;
            btn.textContent = '💰 Pagar';
            return;
        }
        
        // POST a redirigir_pago.php
        const f = document.createElement('form');
        f.method = 'POST';
        f.action = data.redirect;
        f.innerHTML = `
            <input type="hidden" name="csrf_token" value="${data.csrf_token}">
            <input type="hidden" name="pedido_id" value="${data.pedido_id}">
            <input type="hidden" name="metodo_pago" value="${data.metodo_pago}">
        `;
        document.body.appendChild(f);
        f.submit();
        
    } catch (err) {
        console.error(err);
        alert('Error de conexión');
        btn.disabled = false;
        btn.textContent = '💰 Pagar';
    }
}

// ============================================
// AUTO-SELECCIONAR ÚLTIMO MÉTODO
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    const ultimoMetodo = '<?php echo htmlspecialchars($ultimo_metodo); ?>';
    
    if (ultimoMetodo) {
        const el = document.querySelector(`.metodo-item[data-pasarela="${ultimoMetodo}"]`);
        if (el) {
            seleccionarMetodo(el);
        }
    }
});
</script>
</body>
</html>
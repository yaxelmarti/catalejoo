<?php
// ============================================
// WEBHOOK UNIVERSAL - ENRUTADOR
// ============================================
// Recibe notificaciones de todas las pasarelas
// Detecta cuál envió la notificación
// Carga el archivo de la pasarela correspondiente
// ============================================

// 1. Configuración inicial
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// 2. Conexión y archivos necesarios
require_once dirname(__DIR__, 2) . '/conexion.php';
require_once dirname(__DIR__, 2) . '/includes/cola_correos.php';
require_once dirname(__DIR__, 2) . '/includes/email_functions.php';

// 3. Obtener datos de la petición
$raw_post = file_get_contents('php://input');
$headers = getallheaders();
$post_data = $_POST;
$get_data = $_GET;

// 4. Registrar para depuración
$log_file = __DIR__ . '/webhook.log';
$log_data = date('Y-m-d H:i:s') . " - Webhook recibido\n";
$log_data .= "Headers: " . print_r($headers, true) . "\n";
$log_data .= "Raw POST: " . substr($raw_post, 0, 2000) . "\n";
$log_data .= "POST: " . print_r($post_data, true) . "\n";
$log_data .= "GET: " . print_r($get_data, true) . "\n";
file_put_contents($log_file, $log_data, FILE_APPEND);

// 5. Detectar la pasarela
$gateway = detectarPasarela($headers, $post_data, $get_data, $raw_post);

file_put_contents($log_file, date('Y-m-d H:i:s') . " - Gateway detectada: $gateway\n", FILE_APPEND);

// 6. Si no se detecta, salir
if (empty($gateway)) {
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Gateway no reconocida\n", FILE_APPEND);
    http_response_code(200);
    exit('OK');
}

// 7. Validar que el archivo de la pasarela existe
$archivo_pasarela = __DIR__ . '/webhooks/wh_' . $gateway . '.php';

if (!file_exists($archivo_pasarela)) {
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Archivo no encontrado: $archivo_pasarela\n", FILE_APPEND);
    http_response_code(200);
    exit('OK');
}

// 8. Cargar el archivo de la pasarela
require_once $archivo_pasarela;

// 9. Verificar que la función existe
$funcion = 'procesarWebhook_' . $gateway;

if (!function_exists($funcion)) {
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Función no encontrada: $funcion\n", FILE_APPEND);
    http_response_code(200);
    exit('OK');
}

// 10. Ejecutar el procesamiento
try {
    $datos = [
        'conn' => $conn,
        'headers' => $headers,
        'post' => $post_data,
        'get' => $get_data,
        'raw' => $raw_post,
        'log_file' => $log_file
    ];
    
    $resultado = $funcion($datos);
    
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Resultado: " . print_r($resultado, true) . "\n", FILE_APPEND);
    
} catch (Throwable $e) {
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - ERROR: " . $e->getMessage() . " @ " . $e->getFile() . ":" . $e->getLine() . "\n", FILE_APPEND);
}

// 11. Responder HTTP 200 (siempre)
http_response_code(200);
echo 'OK';

// ============================================
// FUNCIONES AUXILIARES
// ============================================

/**
 * Detecta qué pasarela envió la notificación
 */
function detectarPasarela($headers, $post, $get, $raw) {
    // Normalizar headers a minúsculas
    $headers_lower = array_change_key_case($headers, CASE_LOWER);
    
    // ===== PAYPAL =====
    if (isset($headers_lower['paypal-transmission-id'])) {
        return 'paypal';
    }
    if (isset($post['txn_id']) && isset($post['payment_status'])) {
        return 'paypal';
    }
    
    // ===== STRIPE =====
    if (isset($headers_lower['stripe-signature'])) {
        return 'stripe';
    }
    $data = json_decode($raw, true);
    if (isset($data['type']) && strpos($data['type'], 'payment_intent') !== false) {
        return 'stripe';
    }
    
    // ===== MERCADO PAGO =====
    if (isset($headers_lower['x-signature']) && isset($headers_lower['x-request-id'])) {
        return 'mercadopago';
    }
    if (isset($post['action']) && $post['action'] == 'payment.created') {
        return 'mercadopago';
    }
    if (isset($data['action']) && $data['action'] == 'payment.created') {
        return 'mercadopago';
    }
    if (isset($get['type']) && $get['type'] == 'payment') {
        return 'mercadopago';
    }
    
    // ===== QVAPAY =====
    if (isset($headers_lower['x-signature-256']) && isset($post['order_id'])) {
        return 'qvapay';
    }
    if (isset($post['order_id']) && isset($post['status'])) {
        return 'qvapay';
    }
    
    // ===== TROPIPAY =====
    if (isset($headers_lower['x-signature-256']) && isset($post['event'])) {
        return 'tropipay';
    }
    if (isset($post['event']) && strpos($post['event'], 'payment') !== false) {
        return 'tropipay';
    }
    
    // ===== SQUARE =====
    if (isset($headers_lower['x-square-hmacsha256-signature'])) {
        return 'square';
    }
    if (isset($data['type']) && strpos($data['type'], 'payment') !== false && isset($headers_lower['x-square-hmacsha256-signature'])) {
        return 'square';
    }
    
    // ===== AMAZON PAY =====
    if (isset($headers_lower['x-amz-sns-message-type'])) {
        return 'amazon';
    }
    
    // ===== FLOWGLAD =====
    if (isset($headers_lower['x-flowglad-signature'])) {
        return 'flowglad';
    }
    
    return '';
}
?>
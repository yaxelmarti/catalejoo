<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();
require_once dirname(__DIR__, 2) . '/conexion.php';
require_once dirname(__DIR__, 2) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__, 2) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__, 2) . '/includes/moneda_funciones.php';

$pedido_id = isset($_GET['pedido']) ? intval($_GET['pedido']) : 0;

if ($pedido_id == 0) {
    header('Location: /index.php');
    exit;
}

// Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

if ($cliente_id == 0) {
    header('Location: /index.php?error=login');
    exit;
}

// Obtener datos del pedido
$stmt = $conn->prepare("SELECT p.*, d.nombre_completo, d.direccion 
                        FROM pedidos p 
                        LEFT JOIN direcciones_envio d ON p.id = d.pedido_id 
                        WHERE p.id = ? AND p.cliente_id = ?");
$stmt->bind_param("ii", $pedido_id, $cliente_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();

if (!$pedido) {
    header('Location: /index.php?error=pedido_no_encontrado');
    exit;
}

// ============================================
// OBTENER MONEDA DEL PEDIDO (histórico)
// ============================================
$moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
$moneda_simbolo = getSimboloPorMoneda($moneda_pedido);
$moneda_codigo = $moneda_pedido;

// ============================================
// OBTENER MONTOS DEL PEDIDO (moneda del pedido)
// ============================================
$total_pedido = !empty($pedido['total_convertido']) 
    ? floatval($pedido['total_convertido']) 
    : floatval($pedido['total'] ?? 0);

$monto_pagado = floatval($pedido['monto_pagado'] ?? 0);
$monto_pendiente = floatval($pedido['monto_pendiente'] ?? 0);
$porcentaje_pagado = floatval($pedido['porcentaje_pagado'] ?? 0);

// Si no hay monto_pendiente calculado, calcularlo
if ($monto_pendiente == 0 && $monto_pagado == 0) {
    $monto_pendiente = $total_pedido;
} elseif ($monto_pendiente == 0 && $monto_pagado > 0) {
    $monto_pendiente = $total_pedido - $monto_pagado;
}

// Determinar tipo de pago
$es_pago_parcial = ($monto_pagado > 0 && $monto_pendiente > 0);

// ============================================
// OBTENER INSTRUCCIONES DEL PROVEEDOR (o global)
// ============================================
require_once dirname(__DIR__, 2) . '/includes/email_functions.php';

$config_efectivo = obtenerDatosMetodoPago('efectivo', $pedido['proveedor_id'] ?? 0);
$instrucciones_proveedor = trim($config_efectivo['instrucciones'] ?? '');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago en Efectivo</title>
    <link rel="stylesheet" href="/estilo.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        
        .pago-container {
            max-width: 600px;
            width: 100%;
        }
        
        .pago-card {
            background: white;
            border-radius: 30px;
            padding: 2.5rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .metodo-icono {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 2rem;
            color: white;
            font-size: 3rem;
        }
        
        h1 {
            font-size: 2rem;
            color: #2d3748;
            margin-bottom: 1rem;
        }
        
        .pedido-info {
            background: #f7fafc;
            border-radius: 15px;
            padding: 1.5rem;
            margin: 1.5rem 0;
            text-align: left;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            color: #718096;
            font-weight: 500;
        }
        
        .info-value {
            font-weight: 600;
            color: #2d3748;
        }
        
        .total {
            font-size: 1.5rem;
            color: #48bb78;
        }
        
        .direccion-card {
            background: #ebf8ff;
            border-left: 4px solid #4299e1;
            border-radius: 10px;
            padding: 1.5rem;
            margin: 1.5rem 0;
            text-align: left;
        }
        
        .direccion-card h3 {
            color: #2c5282;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .direccion-detalle {
            background: white;
            border-radius: 8px;
            padding: 1rem;
        }
        
        .direccion-detalle p {
            margin: 0.5rem 0;
            color: #4a5568;
        }
        
        .instrucciones {
            background: #fef5e7;
            border-radius: 15px;
            padding: 1.5rem;
            margin: 1.5rem 0;
            text-align: left;
        }
        
        .instrucciones h3 {
            color: #744210;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .instrucciones ul {
            list-style: none;
            padding: 0;
        }
        
        .instrucciones li {
            margin-bottom: 1rem;
            padding-left: 1.5rem;
            position: relative;
            color: #4a5568;
        }
        
        .instrucciones li::before {
            content: "✅";
            position: absolute;
            left: 0;
            color: #48bb78;
        }
        
        .instrucciones-personalizadas {
            background: white;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            color: #4a5568;
            line-height: 1.6;
            border-left: 3px solid #ed8936;
        }
        
        .btn-mis-pedidos {
            display: inline-block;
            padding: 1rem 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            margin-top: 1rem;
            transition: all 0.3s;
        }
        
        .btn-mis-pedidos:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
        }
        
        .btn-volver {
            display: inline-block;
            color: #718096;
            text-decoration: none;
            margin-top: 2rem;
        }
        
        .btn-volver:hover {
            color: #667eea;
        }
        
        .aviso {
            background: #fef5e7;
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
            font-size: 0.9rem;
            color: #744210;
        }

@media (max-width: 480px) {
    .pago-card {
        padding: 1.5rem;
        border-radius: 20px;
    }
    
    h1 {
        font-size: 1.5rem;
    }
    
    .metodo-icono {
        width: 80px;
        height: 80px;
        font-size: 2.2rem;
    }
    
    .info-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.2rem;
    }
    
    .info-value {
        font-size: 0.95rem;
    }
}
    </style>
</head>
<body>
    <div class="pago-container">
        <div class="pago-card">
            <div class="metodo-icono">💵</div>
            
            <h1>Pago en Efectivo</h1>
            <p style="color: #718096; margin-bottom: 2rem;">Pagas al recibir tu pedido</p>
            
            <div class="pedido-info">
                <div class="info-item">
                    <span class="info-label">Pedido #</span>
                    <span class="info-value"><?php echo htmlspecialchars($pedido['codigo'] ?? $pedido['id']); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Fecha</span>
                    <span class="info-value"><?php echo date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Total del pedido</span>
                    <span class="info-value"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($total_pedido, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
                </div>
                
                <?php if ($es_pago_parcial): ?>
                <div class="info-item">
                    <span class="info-label">Ya pagaste (<?php echo number_format($porcentaje_pagado, 0); ?>%)</span>
                    <span class="info-value" style="color: #10b981;"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_pagado, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
                </div>
                <?php endif; ?>
                
                <div class="info-item" style="border-top: 2px solid #e2e8f0; padding-top: 0.8rem; margin-top: 0.5rem;">
                    <span class="info-label" style="font-weight: 700; color: #2d3748; font-size: 1rem;">💵 A pagar al recibir</span>
                    <span class="info-value total"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_pendiente, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
                </div>
            </div>
            
            <?php if (!empty($pedido['nombre_completo'])): ?>
            <div class="direccion-card">
                <h3>📍 Dirección de Entrega</h3>
                <div class="direccion-detalle">
                    <p><strong><?php echo htmlspecialchars($pedido['nombre_completo']); ?></strong></p>
                    <p><?php echo htmlspecialchars($pedido['direccion']); ?></p>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="instrucciones">
                <h3>📋 ¿Cómo funciona?</h3>
                
                <?php if (!empty($instrucciones_proveedor)): ?>
                    <div class="instrucciones-personalizadas">
                        <?php echo nl2br(htmlspecialchars($instrucciones_proveedor)); ?>
                    </div>
                <?php endif; ?>
                
                <ul>
                    <li>Tu pedido será preparado y enviado a la dirección indicada</li>
                    <li>El repartidor llevará el producto y el cambio (si es necesario)</li>
                    
                    <?php if ($es_pago_parcial): ?>
                    <li>Ya realizaste el pago parcial de <strong><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_pagado, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></strong></li>
                    <li>Al recibir, pagas el resto: <strong><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_pendiente, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></strong></li>
                    <?php else: ?>
                    <li>Al recibir, pagas: <strong><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_pendiente, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></strong></li>
                    <?php endif; ?>
                    
                    <li>Puedes pagar con billetes o monedas</li>
                </ul>
            </div>
            
            <div class="aviso">
                ⏱️ El tiempo de entrega depende de tu ubicación. Te contactaremos para coordinar.
            </div>
            
            <a href="/mis_pedidos.php" class="btn-mis-pedidos">
                📋 Ver mis pedidos
            </a>
            
            <br>
            <a href="/index.php" class="btn-volver">← Seguir comprando</a>
        </div>
    </div>
</body>
</html>
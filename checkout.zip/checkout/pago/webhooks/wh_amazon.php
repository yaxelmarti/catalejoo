<?php
// ============================================
// WEBHOOK AMAZON PAY - PROCESADOR
// ============================================
// Recibe IPN de Amazon Pay (SNS)
// Consulta el Charge para saber el estado real
// ============================================

function procesarWebhook_amazon($datos) {
    $conn = $datos['conn'];
    $headers = $datos['headers'];
    $raw = $datos['raw'];
    $log_file = $datos['log_file'];

    require_once __DIR__ . '/../apis/api_amazon.php';
    require_once __DIR__ . '/../apis/api_webhook_utils.php';

    // ===== 1. PARSEAR EL MENSAJE SNS =====
    $sns = json_decode($raw, true);

    if (!$sns || !isset($sns['Type'])) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: JSON inválido\n", FILE_APPEND);
        responderWebhookError('JSON inválido');
    }

    // Manejar confirmación de suscripción
    if ($sns['Type'] === 'SubscriptionConfirmation') {
        $subscribe_url = $sns['SubscribeURL'] ?? '';
        if (!empty($subscribe_url)) {
            file_get_contents($subscribe_url);
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Suscripción confirmada\n", FILE_APPEND);
        }
        responderWebhookOK('Suscripción confirmada');
    }

    if ($sns['Type'] !== 'Notification') {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Tipo no manejado (" . $sns['Type'] . ")\n", FILE_APPEND);
        responderWebhookOK('Tipo no manejado');
    }

    // ===== 2. PARSEAR EL MENSAJE INTERNO =====
    $message = json_decode($sns['Message'] ?? '{}', true);

    if (!$message) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Message inválido\n", FILE_APPEND);
        responderWebhookError('Message inválido');
    }

    $object_type = $message['ObjectType'] ?? '';
    $object_id = $message['ObjectId'] ?? '';
    $notification_id = $message['NotificationId'] ?? '';

    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: ObjectType=$object_type, ObjectId=$object_id\n", FILE_APPEND);

    // ===== 3. VALIDAR QUE SEA UN CHARGE =====
    if ($object_type !== 'CHARGE') {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: No es CHARGE\n", FILE_APPEND);
        responderWebhookOK('No es CHARGE');
    }

    // ===== 4. IDEMPOTENCIA =====
    if (webhookYaProcessado($conn, 'amazon', $notification_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Evento ya procesado\n", FILE_APPEND);
        responderWebhookOK('Ya procesado');
    }

    // ===== 5. BUSCAR PEDIDO POR CHECKOUT SESSION ID =====
    $stmt = $conn->prepare("SELECT * FROM pedidos WHERE referencia_externa = ? LIMIT 1");
    $stmt->bind_param("s", $object_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Pedido no encontrado para $object_id\n", FILE_APPEND);
        registrarWebhookEvent($conn, 'amazon', $notification_id, null, $raw);
        responderWebhookOK('Pedido no encontrado');
    }

    $pedido_id = $pedido['id'];

    // ===== 6. REGISTRAR EVENTO =====
    if (!registrarWebhookEvent($conn, 'amazon', $notification_id, $pedido_id, $raw)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Evento duplicado\n", FILE_APPEND);
        responderWebhookOK('Evento duplicado');
    }

    // ===== 7. CONSULTAR EL CHARGE PARA SABER EL ESTADO REAL =====
    $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
    $stmt_prov->bind_param("i", $pedido_id);
    $stmt_prov->execute();
    $proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
    $stmt_prov->close();

    $config = obtenerConfigAmazon($conn, $proveedor_id);
    $charge = consultarCargoAmazon($config, $object_id);

    if (!$charge) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: No se pudo consultar el Charge\n", FILE_APPEND);
        responderWebhookError('No se pudo consultar el Charge');
    }

    $state = $charge['statusDetails']['state'] ?? '';
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Charge state=$state\n", FILE_APPEND);

    // ===== 8. PROCESAR SEGÚN ESTADO =====
    if ($state === 'Captured') {
        // Verificar que no esté ya completamente pagado
        if ($pedido['estado_pago'] === 'pagado') {
            marcarWebhookProcesado($conn, 'amazon', $notification_id);
            responderWebhookOK('Pedido ya pagado');
        }

        // Validar moneda del pago contra moneda del pedido
        $moneda_pago = strtoupper($charge['chargeAmount']['currencyCode'] ?? '');
        $moneda_pedido = strtoupper($pedido['moneda'] ?? 'USD');

        if (!empty($moneda_pago) && $moneda_pago !== $moneda_pedido) {
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Moneda no coincide. Pedido: $moneda_pedido, Pago: $moneda_pago\n", FILE_APPEND);
            marcarWebhookProcesado($conn, 'amazon', $notification_id);
            responderWebhookOK('Moneda no coincide');
        }

        // Monto recibido
        $monto_recibido = floatval($charge['chargeAmount']['amount'] ?? 0);

        // Validar monto contra monto_pendiente (lo que debe pagar en este intento)
        $monto_pendiente_actual = floatval($pedido['monto_pendiente']);

        if (abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Monto no coincide. Esperado: $monto_pendiente_actual, Recibido: $monto_recibido\n", FILE_APPEND);
            marcarWebhookProcesado($conn, 'amazon', $notification_id);
            responderWebhookOK('Monto no coincide');
        }

        // Determinar si es el 1er pago o el 2do pago
        $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);

        // Calcular nuevos valores
        $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
        $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
        $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);

        // Comisión: solo se suma si es 2do pago
        $nueva_comision = floatval($pedido['comision']);

        if (!$es_primer_pago) {
            $stmt_com = $conn->prepare("
                SELECT valor FROM configuracion 
                WHERE clave = 'amazon_comision' 
                AND grupo = 'pagos' 
                AND proveedor_id IN (?, 0)
                ORDER BY proveedor_id DESC LIMIT 1
            ");
            $stmt_com->bind_param("i", $proveedor_id);
            $stmt_com->execute();
            $com_data = $stmt_com->get_result()->fetch_assoc();
            $stmt_com->close();
            $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;

            $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
            $nueva_comision += $comision_del_pago;
        }

            // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago completo
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        // 1er pago parcial → debe el saldo final
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        // Otros casos → mantener estado actual
        $nuevo_estado_pago = $pedido['estado_pago'];
    }

               // Determinar nuevo estado_actual
        if ($nuevo_monto_pendiente <= 0.01) {
            // Pago total (cubre 100%)
            // Forma 1: pago total adelantado → pago_confirmado
            if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
                $nuevo_estado_actual = 'pago_confirmado';
            } else {
                // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar
                $nuevo_estado_actual = $pedido['estado_actual'];
            }
        } else {
            // Pago parcial (no cubre 100%)
            if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
                // Forma 3: 1er pago parcial
                $nuevo_estado_actual = 'pendiente_entrega_pago';
            } else {
                // Cualquier otro caso → no cambiar
                $nuevo_estado_actual = $pedido['estado_actual'];
            }
        }

        $transaccion_id = $object_id;

        $conn->begin_transaction();

        try {
            $stmt_upd = $conn->prepare("
                UPDATE pedidos 
                SET monto_pagado = ?,
                    monto_pendiente = ?,
                    porcentaje_pagado = ?,
                    comision = ?,
                    estado_pago = ?,
                    estado_actual = ?,
                    fecha_pago = NOW(),
                    transaccion_id = ?
                WHERE id = ?
            ");
            $stmt_upd->bind_param("ddidsissi", 
                $nuevo_monto_pagado,
                $nuevo_monto_pendiente,
                $nuevo_porcentaje,
                $nueva_comision,
                $nuevo_estado_pago,
                $nuevo_estado_actual,
                $transaccion_id,
                $pedido_id
            );
            $stmt_upd->execute();
            $stmt_upd->close();

            $obs = "Pago confirmado por Amazon Pay. Charge: " . $transaccion_id . " | Monto: " . $monto_recibido . " " . $moneda_pedido;
            $stmt_estado = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'pago_confirmado', 1, ?)
            ");
            $stmt_estado->bind_param("is", $pedido_id, $obs);
            $stmt_estado->execute();
            $stmt_estado->close();

            encolarCorreosPagoAmazon($conn, $pedido_id, $pedido);

            $conn->commit();
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - Amazon: Pedido $pedido_id actualizado\n", FILE_APPEND);

        } catch (Throwable $e) {
            $conn->rollback();
            error_log("[wh_amazon] Rollback pedido #$pedido_id: " . $e->getMessage());
            responderWebhookError('Error al actualizar pedido');
        }

    } elseif ($state === 'Declined' || $state === 'Canceled') {
        $obs = "Pago rechazado/cancelado en Amazon Pay. State: $state";
        $stmt = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'pago_fallido', 1, ?)
        ");
        $stmt->bind_param("is", $pedido_id, $obs);
        $stmt->execute();
        $stmt->close();
    }

    // ===== 9. MARCAR COMO PROCESADO =====
    marcarWebhookProcesado($conn, 'amazon', $notification_id);

    responderWebhookOK('OK');
}


/**
 * Encola correos de pago confirmado
 */
function encolarCorreosPagoAmazon($conn, $pedido_id, $pedido) {
    // Correo al cliente (solo al cliente)
    $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $pedido['cliente_id']);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($cliente && !empty($cliente['email'])) {
        encolarCorreo($conn, $cliente['email'], 'Pago confirmado - Pedido ' . $pedido['codigo'], 'pago_confirmado', null, $pedido_id);
    }

    // NO se envía correo al proveedor (solo recibe al crear el pedido)
}
?>
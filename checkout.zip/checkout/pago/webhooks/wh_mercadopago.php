<?php
// ============================================
// WEBHOOK MERCADO PAGO - PROCESADOR
// ============================================
// Recibe notificaciones de Mercado Pago (Webhooks REST)
// Verifica firma HMAC-SHA256, deduplica por event.id
// ============================================

function procesarWebhook_mercadopago($datos) {
    $conn = $datos['conn'];
    $headers = $datos['headers'];
    $get = $datos['get'];
    $raw = $datos['raw'];
    $log_file = $datos['log_file'];

    // Incluir librerías necesarias
    require_once __DIR__ . '/../apis/api_mercadopago.php';
    require_once __DIR__ . '/../apis/api_webhook_utils.php';

    // ===== 1. NORMALIZAR HEADERS =====
    $headers_lower = array_change_key_case($headers, CASE_LOWER);

    // ===== 2. PARSEAR EL EVENTO =====
    $event = json_decode($raw, true);

    if (!$event) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: JSON inválido\n", FILE_APPEND);
        responderWebhookError('JSON inválido');
    }

    $type = $event['type'] ?? $get['type'] ?? '';
    $action = $event['action'] ?? '';
    $data_id = $event['data']['id'] ?? $get['data.id'] ?? $get['id'] ?? '';

    file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: type=$type, action=$action, data_id=$data_id\n", FILE_APPEND);

    // ===== 3. VALIDAR QUE SEA NOTIFICACIÓN DE PAGO =====
    if ($type !== 'payment' && $type !== 'order') {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: No es notificación de pago\n", FILE_APPEND);
        responderWebhookOK('No es notificación de pago');
    }

    if (empty($data_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Sin data_id\n", FILE_APPEND);
        responderWebhookError('Sin data_id');
    }

    // ===== 4. OBTENER PEDIDO POR REFERENCIA EXTERNA =====
    $stmt = $conn->prepare("SELECT * FROM pedidos WHERE referencia_externa = ? OR codigo = ? LIMIT 1");
    $stmt->bind_param("ss", $data_id, $data_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Pedido no encontrado para data_id=$data_id\n", FILE_APPEND);
        responderWebhookOK('Pedido no encontrado');
    }

    $pedido_id = $pedido['id'];

    // ===== 5. OBTENER PROVEEDOR Y CREDENCIALES =====
    $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
    $stmt_prov->bind_param("i", $pedido_id);
    $stmt_prov->execute();
    $proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
    $stmt_prov->close();

    $stmt_mp = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id IN (?, 0)
        AND clave IN ('mercadopago_access_token', 'mercadopago_webhook_secret')
        ORDER BY proveedor_id DESC
    ");
    $stmt_mp->bind_param("i", $proveedor_id);
    $stmt_mp->execute();
    $res_mp = $stmt_mp->get_result();

    $mp_datos = [];
    while ($row = $res_mp->fetch_assoc()) {
        $clave = str_replace('mercadopago_', '', $row['clave']);
        if (!isset($mp_datos[$clave])) {
            $mp_datos[$clave] = $row['valor'];
        }
    }
    $stmt_mp->close();

    $access_token = $mp_datos['access_token'] ?? '';
    $webhook_secret = $mp_datos['webhook_secret'] ?? '';

    if (empty($access_token)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Access token no configurado\n", FILE_APPEND);
        responderWebhookError('Access token no configurado');
    }

    // ===== 6. VERIFICAR FIRMA =====
    $x_signature = $headers_lower['x-signature'] ?? '';
    $x_request_id = $headers_lower['x-request-id'] ?? '';

    if (!empty($webhook_secret) && !empty($x_signature)) {
        $firma_valida = verificarFirmaMercadoPago($x_signature, $x_request_id, $data_id, $webhook_secret);

        if (!$firma_valida) {
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Firma inválida\n", FILE_APPEND);
            responderWebhookError('Firma inválida');
        }

        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Firma válida\n", FILE_APPEND);
    }

    // ===== 7. CONSULTAR EL PAGO A MERCADO PAGO =====
    $order_data = consultarOrdenMercadoPago($access_token, $data_id);

    if (!$order_data) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: No se pudo consultar el pago\n", FILE_APPEND);
        responderWebhookError('No se pudo consultar el pago');
    }

    $status = $order_data['status'] ?? '';
    $status_detail = $order_data['status_detail'] ?? '';

    file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: status=$status, detail=$status_detail\n", FILE_APPEND);

    // ===== 8. IDEMPOTENCIA =====
    $event_id = $data_id . '_' . $status;

    if (webhookYaProcessado($conn, 'mercadopago', $event_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Evento ya procesado\n", FILE_APPEND);
        responderWebhookOK('Ya procesado');
    }

    // ===== 9. REGISTRAR EVENTO =====
    if (!registrarWebhookEvent($conn, 'mercadopago', $event_id, $pedido_id, $raw)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Evento duplicado\n", FILE_APPEND);
        responderWebhookOK('Evento duplicado');
    }

    // ===== 10. PROCESAR SEGÚN STATUS =====
    if ($status === 'processed' || $status === 'approved') {
        // Verificar que no esté ya completamente pagado
        if ($pedido['estado_pago'] === 'pagado') {
            marcarWebhookProcesado($conn, 'mercadopago', $event_id);
            responderWebhookOK('Pedido ya pagado');
        }

        // Validar moneda del pago contra moneda del pedido
        $moneda_pago = strtoupper($order_data['currency_id'] ?? '');
        $moneda_pedido = strtoupper($pedido['moneda'] ?? 'MXN');

        if (!empty($moneda_pago) && $moneda_pago !== $moneda_pedido) {
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Moneda no coincide. Pedido: $moneda_pedido, Pago: $moneda_pago\n", FILE_APPEND);
            marcarWebhookProcesado($conn, 'mercadopago', $event_id);
            responderWebhookOK('Moneda no coincide');
        }

        // Monto recibido (MP usa decimales normales)
        $monto_recibido = floatval($order_data['total_amount'] ?? 0);

        // Validar monto contra monto_pendiente (lo que debe pagar en este intento)
        $monto_pendiente_actual = floatval($pedido['monto_pendiente']);

        if (abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Monto no coincide. Esperado: $monto_pendiente_actual, Recibido: $monto_recibido\n", FILE_APPEND);
            marcarWebhookProcesado($conn, 'mercadopago', $event_id);
            responderWebhookOK('Monto no coincide');
        }

        // Determinar si es el 1er pago o el 2do pago
        $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);

        // Calcular nuevos valores
        $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
        $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
        $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);

        // Comisión: solo se suma si es 2do pago
        $nueva_comision = floatval($pedido['comision']);

        if (!$es_primer_pago) {
            $stmt_com = $conn->prepare("
                SELECT valor FROM configuracion 
                WHERE clave = 'mercadopago_comision' 
                AND grupo = 'pagos' 
                AND proveedor_id IN (?, 0)
                ORDER BY proveedor_id DESC LIMIT 1
            ");
            $stmt_com->bind_param("i", $proveedor_id);
            $stmt_com->execute();
            $com_data = $stmt_com->get_result()->fetch_assoc();
            $stmt_com->close();
            $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;

            $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
            $nueva_comision += $comision_del_pago;
        }

            // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago completo
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        // 1er pago parcial → debe el saldo final
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        // Otros casos → mantener estado actual
        $nuevo_estado_pago = $pedido['estado_pago'];
    }

                // Determinar nuevo estado_actual
        if ($nuevo_monto_pendiente <= 0.01) {
            // Pago total (cubre 100%)
            // Forma 1: pago total adelantado → pago_confirmado
            if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
                $nuevo_estado_actual = 'pago_confirmado';
            } else {
                // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar
                $nuevo_estado_actual = $pedido['estado_actual'];
            }
        } else {
            // Pago parcial (no cubre 100%)
            if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
                // Forma 3: 1er pago parcial
                $nuevo_estado_actual = 'pendiente_entrega_pago';
            } else {
                // Cualquier otro caso → no cambiar
                $nuevo_estado_actual = $pedido['estado_actual'];
            }
        }

        // Actualizar pedido
        $transaccion_id = $order_data['id'] ?? $data_id;

        $conn->begin_transaction();

        try {
            $stmt_upd = $conn->prepare("
                UPDATE pedidos 
                SET monto_pagado = ?,
                    monto_pendiente = ?,
                    porcentaje_pagado = ?,
                    comision = ?,
                    estado_pago = ?,
                    estado_actual = ?,
                    fecha_pago = NOW(),
                    transaccion_id = ?
                WHERE id = ?
            ");
            $stmt_upd->bind_param("ddidsissi", 
                $nuevo_monto_pagado,
                $nuevo_monto_pendiente,
                $nuevo_porcentaje,
                $nueva_comision,
                $nuevo_estado_pago,
                $nuevo_estado_actual,
                $transaccion_id,
                $pedido_id
            );
            $stmt_upd->execute();
            $stmt_upd->close();

            $obs = "Pago confirmado por Mercado Pago. Transacción: " . $transaccion_id . " | Monto: " . $monto_recibido . " " . $moneda_pedido;
            $stmt_estado = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'pago_confirmado', 1, ?)
            ");
            $stmt_estado->bind_param("is", $pedido_id, $obs);
            $stmt_estado->execute();
            $stmt_estado->close();

            encolarCorreosPagoMercadopago($conn, $pedido_id, $pedido);

            $conn->commit();
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Pedido $pedido_id actualizado correctamente\n", FILE_APPEND);

        } catch (Throwable $e) {
            $conn->rollback();
            error_log("[wh_mercadopago] Rollback pedido #$pedido_id: " . $e->getMessage());
            responderWebhookError('Error al actualizar pedido');
        }

    } elseif ($status === 'rejected' || $status === 'cancelled' || $status === 'failed') {
        $obs = "Pago rechazado/cancelado en Mercado Pago. Status: $status ($status_detail)";
        $stmt = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'pago_fallido', 1, ?)
        ");
        $stmt->bind_param("is", $pedido_id, $obs);
        $stmt->execute();
        $stmt->close();

        file_put_contents($log_file, date('Y-m-d H:i:s') . " - MercadoPago: Pago rechazado/cancelado para pedido $pedido_id\n", FILE_APPEND);
    }

    // ===== 11. MARCAR COMO PROCESADO =====
    marcarWebhookProcesado($conn, 'mercadopago', $event_id);

    responderWebhookOK('OK');
}


/**
 * Encola correos de pago confirmado
 */
function encolarCorreosPagoMercadopago($conn, $pedido_id, $pedido) {
    // Correo al cliente (solo al cliente)
    $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $pedido['cliente_id']);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($cliente && !empty($cliente['email'])) {
        encolarCorreo($conn, $cliente['email'], 'Pago confirmado - Pedido ' . $pedido['codigo'], 'pago_confirmado', null, $pedido_id);
    }

    // NO se envía correo al proveedor (solo recibe al crear el pedido)
}
?>
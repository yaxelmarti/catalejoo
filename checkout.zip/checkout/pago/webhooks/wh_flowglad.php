<?php
// ============================================
// WEBHOOK FLOWGLAD - PROCESADOR
// ============================================
// Recibe notificaciones de Flowglad
// Valida autenticidad con firma HMAC-SHA256
// ============================================

function procesarWebhook_flowglad($datos) {
    $conn = $datos['conn'];
    $headers = $datos['headers'];
    $post = $datos['post'];
    $raw = $datos['raw'];
    $log_file = $datos['log_file'];

    require_once __DIR__ . '/../apis/api_webhook_utils.php';

    // ===== 1. NORMALIZAR HEADERS =====
    $headers_lower = array_change_key_case($headers, CASE_LOWER);

    // ===== 2. OBTENER DATOS DEL PAGO =====
    $event = json_decode($raw, true);

    if (!$event) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: JSON inválido\n", FILE_APPEND);
        responderWebhookError('JSON inválido');
    }

    $tipo_evento = $event['type'] ?? '';
    $data = $event['data'] ?? [];

    $order_id = $data['orderId'] ?? $data['id'] ?? '';
    $status = $data['status'] ?? '';
    $amount = floatval($data['amount'] ?? 0);
    $transaction_id = $data['transactionId'] ?? '';

    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: evento=$tipo_evento, order_id=$order_id, status=$status\n", FILE_APPEND);

    // ===== 3. VALIDAR QUE SEA NOTIFICACIÓN DE PAGO =====
    $eventos_exitosos = ['payment.succeeded', 'payment.completed', 'invoice.paid'];
    $eventos_fallidos = ['payment.failed', 'invoice.payment_failed'];

    if (empty($order_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Notificación inválida\n", FILE_APPEND);
        responderWebhookError('Notificación inválida');
    }

    // ===== 4. OBTENER PEDIDO =====
    $stmt = $conn->prepare("SELECT * FROM pedidos WHERE referencia_externa = ? OR codigo = ? LIMIT 1");
    $stmt->bind_param("ss", $order_id, $order_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Pedido no encontrado para $order_id\n", FILE_APPEND);
        responderWebhookOK('Pedido no encontrado');
    }

    $pedido_id = $pedido['id'];

    // ===== 5. OBTENER PROVEEDOR =====
    $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
    $stmt_prov->bind_param("i", $pedido_id);
    $stmt_prov->execute();
    $proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
    $stmt_prov->close();

    // ===== 6. VALIDAR FIRMA =====
    $signature = $headers_lower['x-flowglad-signature'] ?? '';
    $webhook_secret = obtenerConfigProveedor($conn, 'flowglad_webhook_secret', $proveedor_id);

    if (!empty($webhook_secret) && !empty($signature)) {
        $firma_calculada = hash_hmac('sha256', $raw, $webhook_secret);

        if (!hash_equals($firma_calculada, $signature)) {
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Firma inválida\n", FILE_APPEND);
            responderWebhookError('Firma inválida');
        }

        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Firma válida\n", FILE_APPEND);
    } else {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Sin webhook secret, saltando validación\n", FILE_APPEND);
    }

    // ===== 7. IDEMPOTENCIA =====
    $event_id = !empty($transaction_id) ? $transaction_id : $order_id . '_' . $tipo_evento;

    if (webhookYaProcessado($conn, 'flowglad', $event_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Evento ya procesado\n", FILE_APPEND);
        responderWebhookOK('Ya procesado');
    }

    // ===== 8. REGISTRAR EVENTO =====
    if (!registrarWebhookEvent($conn, 'flowglad', $event_id, $pedido_id, $raw)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Evento duplicado\n", FILE_APPEND);
        responderWebhookOK('Evento duplicado');
    }

    // ===== 9. VERIFICAR ESTADO DEL PAGO =====
    if (in_array($tipo_evento, $eventos_fallidos) || $status == 'FAILED' || $status == 'CANCELED') {
        $obs = "Pago rechazado/cancelado en Flowglad. Estado: $status";
        $stmt = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'pago_fallido', 1, ?)
        ");
        $stmt->bind_param("is", $pedido_id, $obs);
        $stmt->execute();
        $stmt->close();

        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Pago rechazado/cancelado\n", FILE_APPEND);
        marcarWebhookProcesado($conn, 'flowglad', $event_id);
        responderWebhookOK('Pago rechazado');
    }

    if (!in_array($tipo_evento, $eventos_exitosos)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Evento no manejado ($tipo_evento)\n", FILE_APPEND);
        marcarWebhookProcesado($conn, 'flowglad', $event_id);
        responderWebhookOK('Evento no manejado');
    }

    // ===== 10. VALIDAR QUE EL PEDIDO NO ESTÉ YA COMPLETAMENTE PAGADO =====
    if ($pedido['estado_pago'] === 'pagado') {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Pedido ya pagado\n", FILE_APPEND);
        marcarWebhookProcesado($conn, 'flowglad', $event_id);
        responderWebhookOK('Pedido ya pagado');
    }

    // ===== 11. VALIDAR MONEDA Y MONTO =====
    $moneda_pago = strtoupper($data['currency'] ?? '');
    $moneda_pedido = strtoupper($pedido['moneda'] ?? 'USD');

    if (!empty($moneda_pago) && $moneda_pago !== $moneda_pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Moneda no coincide. Pedido: $moneda_pedido, Pago: $moneda_pago\n", FILE_APPEND);
        marcarWebhookProcesado($conn, 'flowglad', $event_id);
        responderWebhookOK('Moneda no coincide');
    }

    // Monto recibido
    $monto_recibido = $amount;

    // Validar monto contra monto_pendiente
    $monto_pendiente_actual = floatval($pedido['monto_pendiente']);

    if ($monto_recibido > 0 && abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Monto no coincide. Esperado: $monto_pendiente_actual, Recibido: $monto_recibido\n", FILE_APPEND);
        marcarWebhookProcesado($conn, 'flowglad', $event_id);
        responderWebhookOK('Monto no coincide');
    }

    // ===== 12. DETERMINAR SI ES 1ER PAGO O 2DO PAGO =====
    $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);

    // Calcular nuevos valores
    $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
    $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
    $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);

    // Comisión: solo se suma si es 2do pago
    $nueva_comision = floatval($pedido['comision']);

    if (!$es_primer_pago) {
        $stmt_com = $conn->prepare("
            SELECT valor FROM configuracion 
            WHERE clave = 'flowglad_comision' 
            AND grupo = 'pagos' 
            AND proveedor_id IN (?, 0)
            ORDER BY proveedor_id DESC LIMIT 1
        ");
        $stmt_com->bind_param("i", $proveedor_id);
        $stmt_com->execute();
        $com_data = $stmt_com->get_result()->fetch_assoc();
        $stmt_com->close();
        $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;

        $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
        $nueva_comision += $comision_del_pago;
    }

        // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago completo
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        // 1er pago parcial → debe el saldo final
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        // Otros casos → mantener estado actual
        $nuevo_estado_pago = $pedido['estado_pago'];
    }

        // Determinar nuevo estado_actual
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago total (cubre 100%)
        // Forma 1: pago total adelantado → pago_confirmado
        if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
            $nuevo_estado_actual = 'pago_confirmado';
        } else {
            // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    } else {
        // Pago parcial (no cubre 100%)
        if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
            // Forma 3: 1er pago parcial
            $nuevo_estado_actual = 'pendiente_entrega_pago';
        } else {
            // Cualquier otro caso → no cambiar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    }

    // ===== 13. ACTUALIZAR PEDIDO EN TRANSACCIÓN =====
    $transaccion_id = !empty($transaction_id) ? $transaction_id : $order_id;
    $respuesta_json = json_encode($event);

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare("
            UPDATE pedidos 
            SET monto_pagado = ?,
                monto_pendiente = ?,
                porcentaje_pagado = ?,
                comision = ?,
                estado_pago = ?,
                estado_actual = ?,
                fecha_pago = NOW(),
                transaccion_id = ?,
                referencia_externa = ?,
                respuesta_pasarela = ?
            WHERE id = ?
        ");
        $stmt->bind_param(
            "ddidsisssi",
            $nuevo_monto_pagado,
            $nuevo_monto_pendiente,
            $nuevo_porcentaje,
            $nueva_comision,
            $nuevo_estado_pago,
            $nuevo_estado_actual,
            $transaccion_id,
            $order_id,
            $respuesta_json,
            $pedido_id
        );
        $stmt->execute();
        $stmt->close();

        // Registrar en historial
        $obs = "Pago confirmado por Flowglad. Transacción: " . $transaccion_id . " | Monto: " . $monto_recibido . " " . $moneda_pedido;
        $stmt_estado = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'pago_confirmado', 1, ?)
        ");
        $stmt_estado->bind_param("is", $pedido_id, $obs);
        $stmt_estado->execute();
        $stmt_estado->close();

        // Encolar correo al cliente
        encolarCorreosPago($conn, $pedido_id, $pedido);

        $conn->commit();
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Flowglad: Pedido $pedido_id actualizado correctamente\n", FILE_APPEND);

        marcarWebhookProcesado($conn, 'flowglad', $event_id);

        responderWebhookOK('OK');

    } catch (Throwable $e) {
        $conn->rollback();
        error_log("[wh_flowglad] Rollback pedido #$pedido_id: " . $e->getMessage());
        responderWebhookError('Error al actualizar pedido');
    }
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================

/**
 * Obtiene configuración del proveedor (o global)
 */
if (!function_exists('obtenerConfigProveedor')) {
    function obtenerConfigProveedor($conn, $clave, $proveedor_id) {
        $stmt = $conn->prepare("
            SELECT valor FROM configuracion 
            WHERE clave = ? AND proveedor_id IN (?, 0)
            ORDER BY proveedor_id DESC
            LIMIT 1
        ");
        $stmt->bind_param("si", $clave, $proveedor_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result['valor'] ?? null;
    }
}

/**
 * Encola correo de confirmación de pago (solo al cliente)
 */
if (!function_exists('encolarCorreosPago')) {
    function encolarCorreosPago($conn, $pedido_id, $pedido) {
        // Obtener email del cliente
        $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
        $stmt->bind_param("i", $pedido['cliente_id']);
        $stmt->execute();
        $cliente = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // Encolar correo al cliente (solo al cliente)
        if ($cliente && !empty($cliente['email'])) {
            encolarCorreo(
                $conn,
                $cliente['email'],
                'Pago confirmado - Pedido ' . $pedido['codigo'],
                'pago_confirmado',
                null,
                $pedido_id
            );
        }

        // NO se envía correo al proveedor (solo recibe al crear el pedido)
    }
}
?>
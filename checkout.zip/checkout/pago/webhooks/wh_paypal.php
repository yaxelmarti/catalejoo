<?php
// ============================================
// WEBHOOK PAYPAL - PROCESADOR v2
// ============================================
// Recibe notificaciones de PayPal (Webhooks REST)
// Verifica firma RSA-SHA256, deduplica por event.id
// ============================================

function procesarWebhook_paypal($datos) {
    $conn = $datos['conn'];
    $headers = $datos['headers'];
    $raw = $datos['raw'];
    $log_file = $datos['log_file'];
    
    // Incluir librerías necesarias
    require_once __DIR__ . '/../apis/api_paypal.php';
    require_once __DIR__ . '/../apis/api_webhook_utils.php';
    
    // ===== 1. PARSEAR EL EVENTO =====
    $event = json_decode($raw, true);
    
    if (!$event || !isset($event['event_type'])) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Evento inválido\n", FILE_APPEND);
        responderWebhookError('Evento inválido');
    }
    
    $event_type = $event['event_type'];
    $event_id = $event['id'] ?? '';
    $resource = $event['resource'] ?? [];
    
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: event_type=$event_type, event_id=$event_id\n", FILE_APPEND);
    
    if (empty($event_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Sin event_id\n", FILE_APPEND);
        responderWebhookError('Sin event_id');
    }
    
    // ===== 2. IDEMPOTENCIA =====
    if (webhookYaProcessado($conn, 'paypal', $event_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Evento ya procesado\n", FILE_APPEND);
        responderWebhookOK('Ya procesado');
    }
    
    // ===== 3. EXTRAER PEDIDO_ID =====
    $pedido_id = intval($resource['custom_id'] ?? 0);
    
    if ($pedido_id <= 0) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Sin custom_id\n", FILE_APPEND);
        // Registrar el evento igual para no reprocesar
        registrarWebhookEvent($conn, 'paypal', $event_id, null, $raw);
        responderWebhookOK('Sin pedido_id');
    }
    
    // ===== 4. OBTENER PEDIDO =====
    $stmt = $conn->prepare("SELECT * FROM pedidos WHERE id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Pedido $pedido_id no encontrado\n", FILE_APPEND);
        registrarWebhookEvent($conn, 'paypal', $event_id, null, $raw);
        responderWebhookOK('Pedido no encontrado');
    }
    
    // ===== 5. OBTENER PROVEEDOR Y CREDENCIALES =====
    $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
    $stmt_prov->bind_param("i", $pedido_id);
    $stmt_prov->execute();
    $proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
    $stmt_prov->close();
    
    // Buscar config del proveedor (o global)
    $stmt_pp = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id IN (?, 0)
        AND clave IN ('paypal_client_id', 'paypal_client_secret', 'paypal_modo', 'paypal_webhook_id')
        ORDER BY proveedor_id DESC
    ");
    $stmt_pp->bind_param("i", $proveedor_id);
    $stmt_pp->execute();
    $res_pp = $stmt_pp->get_result();
    
    $pp_datos = [];
    while ($row = $res_pp->fetch_assoc()) {
        $clave = str_replace('paypal_', '', $row['clave']);
        if (!isset($pp_datos[$clave])) {
            $pp_datos[$clave] = $row['valor'];
        }
    }
    $stmt_pp->close();
    
    $client_id = $pp_datos['client_id'] ?? '';
    $client_secret = $pp_datos['client_secret'] ?? '';
    $webhook_id = $pp_datos['webhook_id'] ?? '';
    $modo = $pp_datos['modo'] ?? 'sandbox';
    
    if (empty($client_id) || empty($client_secret) || empty($webhook_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Credenciales incompletas\n", FILE_APPEND);
        responderWebhookError('Credenciales incompletas');
    }
    
    // ===== 6. VERIFICAR FIRMA =====
    $token = obtenerTokenPayPal($client_id, $client_secret, $modo);
    
    if (empty($token)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: No se pudo obtener token\n", FILE_APPEND);
        responderWebhookError('Error al obtener token');
    }
    
    $firma_valida = verificarWebhookPayPal($headers, $raw, $webhook_id, $token, $modo);
    
    if (!$firma_valida) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Firma inválida\n", FILE_APPEND);
        responderWebhookError('Firma inválida');
    }
    
    // ===== 7. REGISTRAR EVENTO =====
    if (!registrarWebhookEvent($conn, 'paypal', $event_id, $pedido_id, $raw)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Evento duplicado\n", FILE_APPEND);
        responderWebhookOK('Evento duplicado');
    }
    
    // ===== 8. PROCESAR SEGÚN TIPO DE EVENTO =====
    $resultado = procesarEventoPayPal($conn, $pedido, $event_type, $resource, $log_file, $proveedor_id);
    
    // ===== 9. MARCAR COMO PROCESADO =====
    marcarWebhookProcesado($conn, 'paypal', $event_id);
    
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Evento $event_id procesado. Resultado: " . json_encode($resultado) . "\n", FILE_APPEND);
    
    responderWebhookOK('OK');
}


/**
 * Procesa el evento según su tipo
 */
function procesarEventoPayPal($conn, $pedido, $event_type, $resource, $log_file, $proveedor_id = 0) {
    $pedido_id = $pedido['id'];
    
    // Si el pedido ya está completamente pagado, no hacer nada
if ($pedido['estado_pago'] === 'pagado') {
    return ['success' => true, 'mensaje' => 'Pedido ya pagado'];
}
    
    switch ($event_type) {
        
        // ===== PAGO COMPLETADO =====
        case 'PAYMENT.CAPTURE.COMPLETED':
    $capture_id = $resource['id'] ?? '';
    $monto_recibido = floatval($resource['amount']['value'] ?? 0);
    
    // Validar moneda del pago contra moneda del pedido
    $moneda_pago = strtoupper($resource['amount']['currency_code'] ?? '');
    $moneda_pedido = strtoupper($pedido['moneda'] ?? 'USD');
    
    if (!empty($moneda_pago) && $moneda_pago !== $moneda_pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Moneda no coincide. Pedido: $moneda_pedido, Pago: $moneda_pago\n", FILE_APPEND);
        return ['success' => false, 'mensaje' => 'Moneda no coincide'];
    }
    
    // Validar monto contra monto_pendiente (lo que debe pagar en este intento)
    $monto_pendiente_actual = floatval($pedido['monto_pendiente']);
    
    if (abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Monto no coincide. Esperado: $monto_pendiente_actual, Recibido: $monto_recibido\n", FILE_APPEND);
        return ['success' => false, 'mensaje' => 'Monto no coincide'];
    }
    
    // Determinar si es el 1er pago o el 2do pago
    $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);
    
    // Calcular nuevos valores
    $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
    $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
    $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);
    
    // Comisión: solo se suma si es 2do pago (en el 1er pago ya está calculada en procesar_pago.php)
    $nueva_comision = floatval($pedido['comision']);
    
    if (!$es_primer_pago) {
        // 2do pago: calcular y sumar la comisión del nuevo pago
        $stmt_com = $conn->prepare("
            SELECT valor FROM configuracion 
            WHERE clave = 'paypal_comision' 
            AND grupo = 'pagos' 
            AND proveedor_id IN (?, 0)
            ORDER BY proveedor_id DESC LIMIT 1
        ");
        $stmt_com->bind_param("i", $proveedor_id);
        $stmt_com->execute();
        $com_data = $stmt_com->get_result()->fetch_assoc();
        $stmt_com->close();
        $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;
        
        $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
        $nueva_comision += $comision_del_pago;
    }
    
        // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago completo
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        // 1er pago parcial → debe el saldo final
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        // Otros casos → mantener estado actual
        $nuevo_estado_pago = $pedido['estado_pago'];
    }
    
        // Determinar nuevo estado_actual
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago total (cubre 100%)
        // Forma 1: pago total adelantado → pago_confirmado
        if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
            $nuevo_estado_actual = 'pago_confirmado';
        } else {
            // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    } else {
        // Pago parcial (no cubre 100%)
        if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
            // Forma 3: 1er pago parcial
            $nuevo_estado_actual = 'pendiente_entrega_pago';
        } else {
            // Cualquier otro caso → no cambiar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    }
    
    // Actualizar pedido
    $stmt = $conn->prepare("
        UPDATE pedidos 
        SET monto_pagado = ?,
            monto_pendiente = ?,
            porcentaje_pagado = ?,
            comision = ?,
            estado_pago = ?,
            estado_actual = ?,
            fecha_pago = NOW(),
            transaccion_id = ?
        WHERE id = ?
    ");
    $stmt->bind_param("ddidsissi", 
        $nuevo_monto_pagado,
        $nuevo_monto_pendiente,
        $nuevo_porcentaje,
        $nueva_comision,
        $nuevo_estado_pago,
        $nuevo_estado_actual,
        $capture_id,
        $pedido_id
    );
    $stmt->execute();
    $stmt->close();
    
    // Registrar en historial
    $obs = "Pago confirmado por PayPal. Captura: " . $capture_id . " | Monto: " . $monto_recibido . " " . $moneda_pedido;
    $stmt = $conn->prepare("
        INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
        VALUES (?, 'pago_confirmado', 1, ?)
    ");
    $stmt->bind_param("is", $pedido_id, $obs);
    $stmt->execute();
    $stmt->close();
    
    // Encolar correo al cliente
    encolarCorreosPagoPayPal($conn, $pedido_id, $pedido);
    
    return ['success' => true, 'mensaje' => 'Pago confirmado'];
        
        // ===== PAGO DENEGADO =====
        case 'PAYMENT.CAPTURE.DENIED':
            $obs = "Pago denegado por PayPal. " . json_encode($resource);
            $stmt = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'pago_fallido', 1, ?)
            ");
            $stmt->bind_param("is", $pedido_id, $obs);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'mensaje' => 'Pago denegado registrado'];
        
        // ===== PAGO REEMBOLSADO =====
        case 'PAYMENT.CAPTURE.REFUNDED':
            $obs = "Pago reembolsado por PayPal. " . json_encode($resource);
            $stmt = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'pago_reembolsado', 1, ?)
            ");
            $stmt->bind_param("is", $pedido_id, $obs);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'mensaje' => 'Reembolso registrado'];
        
        // ===== ORDEN APROBADA (para cron de respaldo) =====
        case 'CHECKOUT.ORDER.APPROVED':
            $order_id = $resource['id'] ?? '';
            $obs = "Orden aprobada por el cliente. Order ID: " . $order_id . ". Pendiente de captura.";
            $stmt = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'orden_aprobada', 1, ?)
            ");
            $stmt->bind_param("is", $pedido_id, $obs);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'mensaje' => 'Aprobación registrada'];
        
        default:
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - PayPal: Evento no manejado ($event_type)\n", FILE_APPEND);
            return ['success' => false, 'mensaje' => 'Evento no manejado'];
    }
}


/**
 * Encola correos de pago confirmado
 */
function encolarCorreosPagoPayPal($conn, $pedido_id, $pedido) {
    // Correo al cliente (solo al cliente)
    $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $pedido['cliente_id']);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($cliente && !empty($cliente['email'])) {
        encolarCorreo(
            $conn,
            $cliente['email'],
            'Pago confirmado - Pedido ' . $pedido['codigo'],
            'pago_confirmado',
            null,
            $pedido_id
        );
    }
    
    // NO se envía correo al proveedor (solo recibe al crear el pedido)
}
?>
<?php
// ============================================
// WEBHOOK STRIPE - PROCESADOR
// ============================================
// Recibe notificaciones de Stripe (Webhooks REST)
// Verifica firma HMAC, deduplica por event.id
// ============================================

function procesarWebhook_stripe($datos) {
    $conn = $datos['conn'];
    $headers = $datos['headers'];
    $raw = $datos['raw'];
    $log_file = $datos['log_file'];
    
    // Incluir librerías necesarias
    require_once __DIR__ . '/../apis/api_stripe.php';
    require_once __DIR__ . '/../apis/api_webhook_utils.php';
    
    // ===== 1. VERIFICAR QUE EXISTA LA FIRMA =====
    $headers_lower = array_change_key_case($headers, CASE_LOWER);
    
    if (!isset($headers_lower['stripe-signature'])) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: No hay firma\n", FILE_APPEND);
        responderWebhookError('No hay firma');
    }
    
    $sig_header = $headers_lower['stripe-signature'];
    
    // ===== 2. PARSEAR EL EVENTO =====
    $event = json_decode($raw, true);
    
    if (!$event || !isset($event['type'])) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Evento inválido\n", FILE_APPEND);
        responderWebhookError('Evento inválido');
    }
    
    $event_type = $event['type'];
    $event_id = $event['id'] ?? '';
    $data_object = $event['data']['object'] ?? [];
    
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: event_type=$event_type, event_id=$event_id\n", FILE_APPEND);
    
    if (empty($event_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Sin event_id\n", FILE_APPEND);
        responderWebhookError('Sin event_id');
    }
    
    // ===== 3. IDEMPOTENCIA =====
    if (webhookYaProcessado($conn, 'stripe', $event_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Evento ya procesado\n", FILE_APPEND);
        responderWebhookOK('Ya procesado');
    }
    
    // ===== 4. EXTRAER PEDIDO_ID =====
    $pedido_id = 0;
    
    // El pedido_id está en metadata[pedido_id] (lo enviamos al crear la sesión)
    if (isset($data_object['metadata']['pedido_id'])) {
        $pedido_id = intval($data_object['metadata']['pedido_id']);
    }
    
    if ($pedido_id <= 0) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Sin pedido_id en metadata\n", FILE_APPEND);
        registrarWebhookEvent($conn, 'stripe', $event_id, null, $raw);
        responderWebhookOK('Sin pedido_id');
    }
    
    // ===== 5. OBTENER PEDIDO =====
    $stmt = $conn->prepare("SELECT * FROM pedidos WHERE id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Pedido $pedido_id no encontrado\n", FILE_APPEND);
        registrarWebhookEvent($conn, 'stripe', $event_id, null, $raw);
        responderWebhookOK('Pedido no encontrado');
    }
    
    // ===== 6. OBTENER PROVEEDOR Y CREDENCIALES =====
    $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
    $stmt_prov->bind_param("i", $pedido_id);
    $stmt_prov->execute();
    $proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
    $stmt_prov->close();
    
    // Buscar config del proveedor (o global)
    $stmt_st = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id IN (?, 0)
        AND clave IN ('stripe_webhook_secret')
        ORDER BY proveedor_id DESC
    ");
    $stmt_st->bind_param("i", $proveedor_id);
    $stmt_st->execute();
    $res_st = $stmt_st->get_result()->fetch_assoc();
    $stmt_st->close();
    
    $webhook_secret = $res_st['valor'] ?? '';
    
    if (empty($webhook_secret)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Webhook secret no configurado\n", FILE_APPEND);
        responderWebhookError('Webhook secret no configurado');
    }
    
    // ===== 7. VERIFICAR FIRMA =====
    $firma_valida = verificarFirmaStripe($raw, $sig_header, $webhook_secret);
    
    if (!$firma_valida) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Firma inválida\n", FILE_APPEND);
        responderWebhookError('Firma inválida');
    }
    
    // ===== 8. REGISTRAR EVENTO =====
    if (!registrarWebhookEvent($conn, 'stripe', $event_id, $pedido_id, $raw)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Evento duplicado\n", FILE_APPEND);
        responderWebhookOK('Evento duplicado');
    }
    
    // ===== 9. PROCESAR SEGÚN TIPO DE EVENTO =====
$resultado = procesarEventoStripe($conn, $pedido, $event_type, $data_object, $log_file, $proveedor_id);
    
    // ===== 10. MARCAR COMO PROCESADO =====
    marcarWebhookProcesado($conn, 'stripe', $event_id);
    
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Evento $event_id procesado. Resultado: " . json_encode($resultado) . "\n", FILE_APPEND);
    
    responderWebhookOK('OK');
}


/**
 * Procesa el evento según su tipo
 */
function procesarEventoStripe($conn, $pedido, $event_type, $data_object, $log_file, $proveedor_id = 0) {
    $pedido_id = $pedido['id'];
    
    // Si el pedido ya está completamente pagado, no hacer nada
if ($pedido['estado_pago'] === 'pagado') {
    return ['success' => true, 'mensaje' => 'Pedido ya pagado'];
}
    
    switch ($event_type) {
        
                // ===== PAGO COMPLETADO =====
        case 'checkout.session.completed':
    // Verificar que el pago esté realmente completo
    $payment_status = $data_object['payment_status'] ?? '';
    
    if ($payment_status !== 'paid') {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: checkout.session.completed pero payment_status=$payment_status\n", FILE_APPEND);
        return ['success' => false, 'mensaje' => 'Pago no completado'];
    }
    
    // Validar moneda del pago contra moneda del pedido
    $moneda_pago = strtoupper($data_object['currency'] ?? '');
    $moneda_pedido = strtoupper($pedido['moneda'] ?? 'USD');
    
    if (!empty($moneda_pago) && $moneda_pago !== $moneda_pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Moneda no coincide. Pedido: $moneda_pedido, Pago: $moneda_pago\n", FILE_APPEND);
        return ['success' => false, 'mensaje' => 'Moneda no coincide'];
    }
    
    $session_id = $data_object['id'] ?? '';
    $payment_intent = $data_object['payment_intent'] ?? '';
    $transaccion_id = !empty($payment_intent) ? $payment_intent : $session_id;
    
    // Monto recibido (Stripe usa centavos)
    $monto_recibido = floatval(($data_object['amount_total'] ?? 0) / 100);
    
    // Validar monto contra monto_pendiente (lo que debe pagar en este intento)
    $monto_pendiente_actual = floatval($pedido['monto_pendiente']);
    
    if (abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Monto no coincide. Esperado: $monto_pendiente_actual, Recibido: $monto_recibido\n", FILE_APPEND);
        return ['success' => false, 'mensaje' => 'Monto no coincide'];
    }
    
    // Determinar si es el 1er pago o el 2do pago
    $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);
    
    // Calcular nuevos valores
    $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
    $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
    $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);
    
    // Comisión: solo se suma si es 2do pago
    $nueva_comision = floatval($pedido['comision']);
    
    if (!$es_primer_pago) {
        $stmt_com = $conn->prepare("
            SELECT valor FROM configuracion 
            WHERE clave = 'stripe_comision' 
            AND grupo = 'pagos' 
            AND proveedor_id IN (?, 0)
            ORDER BY proveedor_id DESC LIMIT 1
        ");
        $stmt_com->bind_param("i", $proveedor_id);
        $stmt_com->execute();
        $com_data = $stmt_com->get_result()->fetch_assoc();
        $stmt_com->close();
        $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;
        
        $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
        $nueva_comision += $comision_del_pago;
    }
    
        // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago completo
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        // 1er pago parcial → debe el saldo final
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        // Otros casos → mantener estado actual
        $nuevo_estado_pago = $pedido['estado_pago'];
    }
    
        // Determinar nuevo estado_actual
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago total (cubre 100%)
        // Forma 1: pago total adelantado → pago_confirmado
        if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
            $nuevo_estado_actual = 'pago_confirmado';
        } else {
            // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    } else {
        // Pago parcial (no cubre 100%)
        if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
            // Forma 3: 1er pago parcial
            $nuevo_estado_actual = 'pendiente_entrega_pago';
        } else {
            // Cualquier otro caso → no cambiar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    }
    
    // Actualizar pedido
    $stmt = $conn->prepare("
        UPDATE pedidos 
        SET monto_pagado = ?,
            monto_pendiente = ?,
            porcentaje_pagado = ?,
            comision = ?,
            estado_pago = ?,
            estado_actual = ?,
            fecha_pago = NOW(),
            transaccion_id = ?
        WHERE id = ?
    ");
    $stmt->bind_param("ddidsissi", 
        $nuevo_monto_pagado,
        $nuevo_monto_pendiente,
        $nuevo_porcentaje,
        $nueva_comision,
        $nuevo_estado_pago,
        $nuevo_estado_actual,
        $transaccion_id,
        $pedido_id
    );
    $stmt->execute();
    $stmt->close();
    
    // Registrar en historial
    $obs = "Pago confirmado por Stripe. Transacción: " . $transaccion_id . " | Monto: " . $monto_recibido . " " . $moneda_pedido;
    $stmt = $conn->prepare("
        INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
        VALUES (?, 'pago_confirmado', 1, ?)
    ");
    $stmt->bind_param("is", $pedido_id, $obs);
    $stmt->execute();
    $stmt->close();
    
    // Encolar correo al cliente
    encolarCorreosPagoStripe($conn, $pedido_id, $pedido);
    
    return ['success' => true, 'mensaje' => 'Pago confirmado'];
        
        // ===== SESIÓN EXPIRADA =====
        case 'checkout.session.expired':
            $obs = "Sesión de Stripe expirada (cliente abandonó). Session ID: " . ($data_object['id'] ?? '');
            $stmt = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'sesion_expirada', 1, ?)
            ");
            $stmt->bind_param("is", $pedido_id, $obs);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'mensaje' => 'Sesión expirada registrada'];
        
        // ===== PAGO FALLIDO =====
        case 'payment_intent.payment_failed':
        case 'charge.failed':
            $obs = "Pago fallido en Stripe. " . json_encode($data_object);
            $stmt = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'pago_fallido', 1, ?)
            ");
            $stmt->bind_param("is", $pedido_id, $obs);
            $stmt->execute();
            $stmt->close();
            
            return ['success' => true, 'mensaje' => 'Pago fallido registrado'];
        
        default:
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - Stripe: Evento no manejado ($event_type)\n", FILE_APPEND);
            return ['success' => false, 'mensaje' => 'Evento no manejado'];
    }
}


/**
 * Encola correos de pago confirmado
 */
function encolarCorreosPagoStripe($conn, $pedido_id, $pedido) {
    // Correo al cliente (solo al cliente)
    $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $pedido['cliente_id']);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($cliente && !empty($cliente['email'])) {
        encolarCorreo(
            $conn,
            $cliente['email'],
            'Pago confirmado - Pedido ' . $pedido['codigo'],
            'pago_confirmado',
            null,
            $pedido_id
        );
    }
    
    // NO se envía correo al proveedor (solo recibe al crear el pedido)
}
?>
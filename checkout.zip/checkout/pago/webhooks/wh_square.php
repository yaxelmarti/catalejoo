<?php
// ============================================
// WEBHOOK SQUARE - PROCESADOR
// ============================================
// Recibe notificaciones de Square (Webhooks REST)
// Verifica firma HMAC-SHA256, deduplica por event_id
// ============================================

function procesarWebhook_square($datos) {
    $conn = $datos['conn'];
    $headers = $datos['headers'];
    $raw = $datos['raw'];
    $log_file = $datos['log_file'];

    // Incluir librerías necesarias
    require_once __DIR__ . '/../apis/api_square.php';
    require_once __DIR__ . '/../apis/api_webhook_utils.php';

    // ===== 1. PARSEAR EL EVENTO =====
    $event = json_decode($raw, true);

    if (!$event) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: JSON inválido\n", FILE_APPEND);
        responderWebhookError('JSON inválido');
    }

    $event_id = $event['event_id'] ?? '';
    $type = $event['type'] ?? '';
    $data_object = $event['data']['object'] ?? [];

    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: type=$type, event_id=$event_id\n", FILE_APPEND);

    if (empty($event_id) || empty($type)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Evento inválido\n", FILE_APPEND);
        responderWebhookError('Evento inválido');
    }

    // ===== 2. IDEMPOTENCIA =====
    if (webhookYaProcessado($conn, 'square', $event_id)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Evento ya procesado\n", FILE_APPEND);
        responderWebhookOK('Ya procesado');
    }

    // ===== 3. EXTRAER PEDIDO_ID =====
    $pedido_id = 0;

    if (isset($data_object['order']['reference_id'])) {
        $pedido_id = intval($data_object['order']['reference_id']);
    } elseif (isset($data_object['order_id'])) {
        $stmt = $conn->prepare("SELECT id FROM pedidos WHERE referencia_externa = ? LIMIT 1");
        $stmt->bind_param("s", $data_object['order_id']);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $pedido_id = $res['id'] ?? 0;
    }

    if ($pedido_id <= 0) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Sin pedido_id\n", FILE_APPEND);
        registrarWebhookEvent($conn, 'square', $event_id, null, $raw);
        responderWebhookOK('Sin pedido_id');
    }

    // ===== 4. OBTENER PEDIDO =====
    $stmt = $conn->prepare("SELECT * FROM pedidos WHERE id = ?");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$pedido) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Pedido $pedido_id no encontrado\n", FILE_APPEND);
        registrarWebhookEvent($conn, 'square', $event_id, null, $raw);
        responderWebhookOK('Pedido no encontrado');
    }

    // ===== 5. OBTENER PROVEEDOR Y CREDENCIALES =====
    $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
    $stmt_prov->bind_param("i", $pedido_id);
    $stmt_prov->execute();
    $proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
    $stmt_prov->close();

    $stmt_sq = $conn->prepare("
        SELECT valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id IN (?, 0)
        AND clave = 'square_webhook_secret'
        ORDER BY proveedor_id DESC
        LIMIT 1
    ");
    $stmt_sq->bind_param("i", $proveedor_id);
    $stmt_sq->execute();
    $res_sq = $stmt_sq->get_result()->fetch_assoc();
    $stmt_sq->close();

    $webhook_secret = $res_sq['valor'] ?? '';

    if (empty($webhook_secret)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Webhook secret no configurado\n", FILE_APPEND);
        responderWebhookError('Webhook secret no configurado');
    }

    // ===== 6. VERIFICAR FIRMA =====
    $headers_lower = array_change_key_case($headers, CASE_LOWER);
    $signature = $headers_lower['x-square-hmacsha256-signature'] ?? '';

    if (!empty($signature)) {
        $notification_url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $firma_valida = verificarFirmaSquare($raw, $signature, $webhook_secret, $notification_url);

        if (!$firma_valida) {
            file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Firma inválida\n", FILE_APPEND);
            responderWebhookError('Firma inválida');
        }

        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Firma válida\n", FILE_APPEND);
    }

    // ===== 7. REGISTRAR EVENTO =====
    if (!registrarWebhookEvent($conn, 'square', $event_id, $pedido_id, $raw)) {
        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Evento duplicado\n", FILE_APPEND);
        responderWebhookOK('Evento duplicado');
    }

    // ===== 8. PROCESAR SEGÚN TIPO =====
    if ($type === 'payment.updated') {
        $status = $data_object['status'] ?? '';

        file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: payment.updated status=$status\n", FILE_APPEND);

        if ($status === 'COMPLETED') {
            // Verificar que no esté ya completamente pagado
            if ($pedido['estado_pago'] === 'pagado') {
                marcarWebhookProcesado($conn, 'square', $event_id);
                responderWebhookOK('Pedido ya pagado');
            }

            // Validar moneda del pago contra moneda del pedido
            $moneda_pago = strtoupper($data_object['total_money']['currency'] ?? '');
            $moneda_pedido = strtoupper($pedido['moneda'] ?? 'USD');

            if (!empty($moneda_pago) && $moneda_pago !== $moneda_pedido) {
                file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Moneda no coincide. Pedido: $moneda_pedido, Pago: $moneda_pago\n", FILE_APPEND);
                marcarWebhookProcesado($conn, 'square', $event_id);
                responderWebhookOK('Moneda no coincide');
            }

            // Monto recibido (Square usa centavos)
            $monto_recibido = floatval(($data_object['total_money']['amount'] ?? 0) / 100);

            // Validar monto contra monto_pendiente (lo que debe pagar en este intento)
            $monto_pendiente_actual = floatval($pedido['monto_pendiente']);

            if (abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
                file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Monto no coincide. Esperado: $monto_pendiente_actual, Recibido: $monto_recibido\n", FILE_APPEND);
                marcarWebhookProcesado($conn, 'square', $event_id);
                responderWebhookOK('Monto no coincide');
            }

            // Determinar si es el 1er pago o el 2do pago
            $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);

            // Calcular nuevos valores
            $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
            $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
            $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);

            // Comisión: solo se suma si es 2do pago
            $nueva_comision = floatval($pedido['comision']);

            if (!$es_primer_pago) {
                $stmt_com = $conn->prepare("
                    SELECT valor FROM configuracion 
                    WHERE clave = 'square_comision' 
                    AND grupo = 'pagos' 
                    AND proveedor_id IN (?, 0)
                    ORDER BY proveedor_id DESC LIMIT 1
                ");
                $stmt_com->bind_param("i", $proveedor_id);
                $stmt_com->execute();
                $com_data = $stmt_com->get_result()->fetch_assoc();
                $stmt_com->close();
                $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;

                $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
                $nueva_comision += $comision_del_pago;
            }

         // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago completo
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        // 1er pago parcial → debe el saldo final
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        // Otros casos → mantener estado actual
        $nuevo_estado_pago = $pedido['estado_pago'];
    }

                        // Determinar nuevo estado_actual
            if ($nuevo_monto_pendiente <= 0.01) {
                // Pago total (cubre 100%)
                // Forma 1: pago total adelantado → pago_confirmado
                if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
                    $nuevo_estado_actual = 'pago_confirmado';
                } else {
                    // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar
                    $nuevo_estado_actual = $pedido['estado_actual'];
                }
            } else {
                // Pago parcial (no cubre 100%)
                if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
                    // Forma 3: 1er pago parcial
                    $nuevo_estado_actual = 'pendiente_entrega_pago';
                } else {
                    // Cualquier otro caso → no cambiar
                    $nuevo_estado_actual = $pedido['estado_actual'];
                }
            }

            $transaccion_id = $data_object['id'] ?? $event_id;

            $conn->begin_transaction();

            try {
                $stmt_upd = $conn->prepare("
                    UPDATE pedidos 
                    SET monto_pagado = ?,
                        monto_pendiente = ?,
                        porcentaje_pagado = ?,
                        comision = ?,
                        estado_pago = ?,
                        estado_actual = ?,
                        fecha_pago = NOW(),
                        transaccion_id = ?
                    WHERE id = ?
                ");
                $stmt_upd->bind_param("ddidsissi", 
                    $nuevo_monto_pagado,
                    $nuevo_monto_pendiente,
                    $nuevo_porcentaje,
                    $nueva_comision,
                    $nuevo_estado_pago,
                    $nuevo_estado_actual,
                    $transaccion_id,
                    $pedido_id
                );
                $stmt_upd->execute();
                $stmt_upd->close();

                $obs = "Pago confirmado por Square. Transacción: " . $transaccion_id . " | Monto: " . $monto_recibido . " " . $moneda_pedido;
                $stmt_estado = $conn->prepare("
                    INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                    VALUES (?, 'pago_confirmado', 1, ?)
                ");
                $stmt_estado->bind_param("is", $pedido_id, $obs);
                $stmt_estado->execute();
                $stmt_estado->close();

                encolarCorreosPagoSquare($conn, $pedido_id, $pedido);

                $conn->commit();
                file_put_contents($log_file, date('Y-m-d H:i:s') . " - Square: Pedido $pedido_id actualizado correctamente\n", FILE_APPEND);

            } catch (Throwable $e) {
                $conn->rollback();
                error_log("[wh_square] Rollback pedido #$pedido_id: " . $e->getMessage());
                responderWebhookError('Error al actualizar pedido');
            }
        } elseif ($status === 'FAILED' || $status === 'CANCELED') {
            $obs = "Pago fallido/cancelado en Square. Status: $status";
            $stmt = $conn->prepare("
                INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
                VALUES (?, 'pago_fallido', 1, ?)
            ");
            $stmt->bind_param("is", $pedido_id, $obs);
            $stmt->execute();
            $stmt->close();
        }
    }

    // ===== 9. MARCAR COMO PROCESADO =====
    marcarWebhookProcesado($conn, 'square', $event_id);

    responderWebhookOK('OK');
}


/**
 * Encola correos de pago confirmado
 */
function encolarCorreosPagoSquare($conn, $pedido_id, $pedido) {
    // Correo al cliente (solo al cliente)
    $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
    $stmt->bind_param("i", $pedido['cliente_id']);
    $stmt->execute();
    $cliente = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($cliente && !empty($cliente['email'])) {
        encolarCorreo($conn, $cliente['email'], 'Pago confirmado - Pedido ' . $pedido['codigo'], 'pago_confirmado', null, $pedido_id);
    }

    // NO se envía correo al proveedor (solo recibe al crear el pedido)
}
?>
<?php
// ============================================
// WEBHOOK UTILS - FUNCIONES COMUNES
// ============================================
// Funciones compartidas por todos los webhooks
// Idempotencia, respuestas HTTP, logs
// ============================================

/**
 * Verifica si un webhook ya fue procesado
 *
 * @param mysqli $conn      Conexión a BD
 * @param string $provider  Nombre de la pasarela (paypal, stripe, etc.)
 * @param string $event_id  ID único del evento
 * @return bool             true si ya existe
 */
function webhookYaProcessado($conn, $provider, $event_id) {
    $stmt = $conn->prepare("
        SELECT id FROM webhook_events 
        WHERE provider = ? AND event_id = ? 
        LIMIT 1
    ");
    $stmt->bind_param("ss", $provider, $event_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $existe = $result->num_rows > 0;
    $stmt->close();
    
    return $existe;
}


/**
 * Registra un webhook en la tabla de eventos
 * Devuelve false si ya existe (violación de UNIQUE)
 *
 * @param mysqli $conn      Conexión a BD
 * @param string $provider  Nombre de la pasarela
 * @param string $event_id  ID único del evento
 * @param int    $pedido_id ID del pedido (puede ser NULL)
 * @param string $payload   JSON completo del webhook
 * @return bool             true si se registró, false si ya existía o error
 */
function registrarWebhookEvent($conn, $provider, $event_id, $pedido_id, $payload) {
    $stmt = $conn->prepare("
        INSERT INTO webhook_events (provider, event_id, pedido_id, payload) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->bind_param("ssis", $provider, $event_id, $pedido_id, $payload);
    
    $resultado = $stmt->execute();
    $error_num = $conn->errno;
    $stmt->close();
    
    // Si hay violación de UNIQUE (error 1062), el evento ya existe
    if (!$resultado && $error_num == 1062) {
        return false;
    }
    
    return $resultado;
}


/**
 * Marca un webhook como procesado
 *
 * @param mysqli $conn      Conexión a BD
 * @param string $provider  Nombre de la pasarela
 * @param string $event_id  ID único del evento
 * @return bool
 */
function marcarWebhookProcesado($conn, $provider, $event_id) {
    $stmt = $conn->prepare("
        UPDATE webhook_events 
        SET procesado = 1 
        WHERE provider = ? AND event_id = ?
    ");
    $stmt->bind_param("ss", $provider, $event_id);
    $resultado = $stmt->execute();
    $stmt->close();
    
    return $resultado;
}


/**
 * Responde HTTP 200 y termina la ejecución
 * Se usa para que la pasarela sepa que el webhook fue recibido
 *
 * @param string $mensaje Mensaje opcional para el log
 */
function responderWebhookOK($mensaje = 'OK') {
    http_response_code(200);
    echo $mensaje;
    exit;
}


/**
 * Responde HTTP 200 con error (para evitar reintentos innecesarios)
 * Registra el error en el log
 *
 * @param string $mensaje Mensaje de error
 */
function responderWebhookError($mensaje) {
    error_log("[webhook_utils] " . $mensaje);
    http_response_code(200);
    echo 'OK';
    exit;
}


/**
 * Verifica la firma HMAC de un webhook (genérico para Stripe, Mercado Pago, etc.)
 *
 * @param string $payload    Cuerpo crudo del webhook
 * @param string $signature  Firma recibida en el header
 * @param string $secret     Secret configurado
 * @param string $algo       Algoritmo (sha256 por defecto)
 * @return bool
 */
function verificarFirmaHMAC($payload, $signature, $secret, $algo = 'sha256') {
    if (empty($signature) || empty($secret)) {
        return false;
    }
    
    $firma_calculada = hash_hmac($algo, $payload, $secret);
    
    return hash_equals($firma_calculada, $signature);
}
?>
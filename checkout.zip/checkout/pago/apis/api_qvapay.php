<?php
// ============================================
// API QVAPAY - FUNCIONES
// ============================================
// App Invoices v2 + verificación de firma HMAC
// ============================================

/**
 * Crea una factura (App Invoice v2)
 *
 * @param string $app_id        App ID de QvaPay
 * @param string $app_secret    App Secret de QvaPay
 * @param float  $monto         Monto en moneda del pedido
 * @param int    $pedido_id     ID del pedido
 * @param string $codigo_pedido Código del pedido
 * @param string $webhook_url   URL del webhook
 * @param string $modo          sandbox | live
 * @param string $moneda        Código ISO 4217 (QvaPay opera principalmente con USD)
 */
function crearInvoiceQvapay($app_id, $app_secret, $monto, $pedido_id, $codigo_pedido, $webhook_url, $return_url, $modo = 'sandbox', $moneda = 'USD') {
    $api_base = ($modo == 'live') 
        ? 'https://api.qvapay.com' 
        : 'https://sandbox.api.qvapay.com';

    // QvaPay requiere la moneda en MAYÚSCULAS
    $moneda = strtoupper(trim($moneda));

    $payload = [
        'amount' => round($monto, 2),
        'currency' => $moneda,
        'description' => 'Pedido ' . $codigo_pedido,
        'remote_id' => (string)$pedido_id,
        'webhook' => $webhook_url,
        'return_url' => $return_url
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/v2/create_invoice');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'app-id: ' . $app_id,
        'app-secret: ' . $app_secret
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || ($http_code != 200 && $http_code != 201)) {
        error_log("[api_qvapay] Error crearInvoiceQvapay: HTTP $http_code - $curl_error - $response");
        return null;
    }

    $invoice = json_decode($response, true);

    if (!isset($invoice['url'])) {
        error_log("[api_qvapay] crearInvoiceQvapay: respuesta sin url");
        return null;
    }

    return [
        'success' => true,
        'invoice_id' => $invoice['transation_uuid'] ?? $invoice['uuid'] ?? '',
        'url' => $invoice['url']
    ];
}

/**
 * Verifica la firma de un webhook de QvaPay
 * QvaPay firma con HMAC-SHA256 del body raw en X-Signature-256
 */
function verificarFirmaQvapay($raw_body, $signature, $secret) {
    if (empty($signature) || empty($secret)) {
        return false;
    }

    $firma_esperada = hash_hmac('sha256', $raw_body, $secret);

    return hash_equals($firma_esperada, $signature);
}


/**
 * Captura una orden para el cron genérico
 * QvaPay no requiere captura manual
 */
function capturarOrdenQvapay($conn, $pedido_id, $pedido, $proveedor_id) {
    if (in_array($pedido['estado_pago'] ?? '', ['pagado', 'completado'])) {
        return ['success' => true, 'mensaje' => 'Pedido ya pagado'];
    }
    return ['success' => false, 'mensaje' => 'QvaPay no requiere captura manual'];
}

/**
 * ============================================
 * FUNCIÓN PÚBLICA (carga por convención)
 * ============================================
 * Llamada desde redirigir_pago.php:
 *   $archivo = __DIR__ . '/apis/api_' . $metodo_pago . '.php';
 *   require_once $archivo;
 *   $funcion = 'construirUrl_' . $metodo_pago;
 *   $url = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
 *
 * @param mysqli $conn               Conexión a BD
 * @param int    $proveedor_config_id 0 = global, >0 = proveedor
 * @param int    $pedido_id          ID del pedido
 * @param float  $monto              Monto en moneda del pedido
 * @param string $codigo_pedido      Código del pedido
 * @param string $moneda             Código ISO 4217 (USD principalmente)
 * @return string|null               URL de pago o null si falla
 */
function construirUrl_qvapay($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'USD') {
    // 1. Obtener credenciales del proveedor (o global)
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id = ? 
        AND clave IN ('qvapay_app_id', 'qvapay_app_secret', 'qvapay_modo')
    ");
    $stmt->bind_param("i", $proveedor_config_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $datos = [];
    while ($row = $result->fetch_assoc()) {
        $clave = str_replace('qvapay_', '', $row['clave']);
        $datos[$clave] = $row['valor'];
    }
    $stmt->close();
    
    $app_id = $datos['app_id'] ?? '';
    $app_secret = $datos['app_secret'] ?? '';
    $modo = $datos['modo'] ?? 'sandbox';
    
    if (empty($app_id) || empty($app_secret)) {
        error_log("[api_qvapay] construirUrl_qvapay: sin credenciales");
        return null;
    }
    
     // 2. Construir URLs
    $host = 'https://' . $_SERVER['HTTP_HOST'];
    $webhook_url = $host . '/checkout/pago/webhook.php';
    $return_url = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id;
    
    // 3. Crear factura (con moneda)
    $invoice = crearInvoiceQvapay($app_id, $app_secret, $monto, $pedido_id, $codigo_pedido, $webhook_url, $return_url, $modo, $moneda);
    
    if (!$invoice || empty($invoice['url'])) {
        error_log("[api_qvapay] construirUrl_qvapay: no se pudo crear factura");
        return null;
    }
    
    // 4. Guardar invoice_id en el pedido
    $stmt_upd = $conn->prepare("UPDATE pedidos SET referencia_externa = ? WHERE id = ?");
    $stmt_upd->bind_param("si", $invoice['invoice_id'], $pedido_id);
    $stmt_upd->execute();
    $stmt_upd->close();
    
    // 5. Devolver URL
    return $invoice['url'];
}
?>
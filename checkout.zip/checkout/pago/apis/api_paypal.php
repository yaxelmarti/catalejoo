<?php
// ============================================
// API PAYPAL - FUNCIONES
// ============================================
// OAuth2, crear orden, capturar orden, verificar webhooks
// ============================================

/**
 * Obtiene un access token de PayPal
 */
function obtenerTokenPayPal($client_id, $client_secret, $modo = 'sandbox') {
    $api_base = ($modo == 'live')
        ? 'https://api-m.paypal.com'
        : 'https://api-m.sandbox.paypal.com';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/v1/oauth2/token');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
    curl_setopt($ch, CURLOPT_USERPWD, $client_id . ':' . $client_secret);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: application/json',
        'Accept-Language: en_US',
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || $http_code != 200) {
        error_log("[api_paypal] Error obtenerTokenPayPal: HTTP $http_code - $curl_error");
        return null;
    }

    $data = json_decode($response, true);
    return $data['access_token'] ?? null;
}


/**
 * Crea una orden en PayPal con intent CAPTURE
 *
 * @param string $token         Access token de PayPal
 * @param float  $monto         Monto en moneda del pedido
 * @param int    $pedido_id     ID del pedido
 * @param string $codigo_pedido Código del pedido
 * @param string $return_url    URL de retorno tras pago
 * @param string $cancel_url    URL de retorno si cancela
 * @param string $modo          sandbox | live
 * @param string $moneda        Código ISO 4217 (USD, EUR, MXN, etc.)
 */
function crearOrdenPayPal($token, $monto, $pedido_id, $codigo_pedido, $return_url, $cancel_url, $modo = 'sandbox', $moneda = 'USD') {
    $api_base = ($modo == 'live')
        ? 'https://api-m.paypal.com'
        : 'https://api-m.sandbox.paypal.com';

    // Normalizar moneda
    $moneda = strtoupper(trim($moneda));

    // Formatear monto (PayPal espera 2 decimales, excepto monedas sin decimales)
    $monedas_sin_decimales = ['HUF', 'JPY', 'TWD'];
    if (in_array($moneda, $monedas_sin_decimales)) {
        $valor_formateado = (string)intval(round($monto));
    } else {
        $valor_formateado = number_format($monto, 2, '.', '');
    }

    $order_data = [
        'intent' => 'CAPTURE',
        'purchase_units' => [
            [
                'reference_id' => $codigo_pedido,
                'custom_id' => (string)$pedido_id,
                'amount' => [
                    'currency_code' => $moneda,
                    'value' => $valor_formateado
                ]
            ]
        ],
        'payment_source' => [
            'paypal' => [
                'experience_context' => [
                    'brand_name' => 'Catalejoo',
                    'locale' => 'es-ES',
                    'landing_page' => 'LOGIN',
                    'user_action' => 'PAY_NOW',
                    'return_url' => $return_url,
                    'cancel_url' => $cancel_url
                ]
            ]
        ]
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/v2/checkout/orders');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || ($http_code != 200 && $http_code != 201)) {
        error_log("[api_paypal] Error crearOrdenPayPal: HTTP $http_code - $curl_error - $response");
        return null;
    }

    $order = json_decode($response, true);

    if (!isset($order['id']) || !isset($order['links'])) {
        error_log("[api_paypal] crearOrdenPayPal: respuesta sin id o links");
        return null;
    }

    $approve_url = null;
    foreach ($order['links'] as $link) {
        if (isset($link['rel']) && ($link['rel'] == 'approve' || $link['rel'] == 'payer-action')) {
            $approve_url = $link['href'];
            break;
        }
    }

    if (empty($approve_url)) {
        error_log("[api_paypal] crearOrdenPayPal: no se encontró approve_url");
        return null;
    }

    return [
        'success' => true,
        'order_id' => $order['id'],
        'approve_url' => $approve_url
    ];
}


/**
 * Ejecuta la captura de una orden previamente aprobada
 * (versión simple: recibe token + order_id)
 */
function ejecutarCapturaPayPal($token, $order_id, $modo = 'sandbox') {
    $api_base = ($modo == 'live')
        ? 'https://api-m.paypal.com'
        : 'https://api-m.sandbox.paypal.com';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/v2/checkout/orders/' . $order_id . '/capture');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, '{}');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || $http_code != 201) {
        error_log("[api_paypal] Error ejecutarCapturaPayPal: HTTP $http_code - $curl_error - $response");
        return null;
    }

    $capture = json_decode($response, true);

    if (!isset($capture['status']) || $capture['status'] != 'COMPLETED') {
        error_log("[api_paypal] ejecutarCapturaPayPal: status no COMPLETED - " . ($capture['status'] ?? 'desconocido'));
        return null;
    }

    $capture_id = '';
    if (isset($capture['purchase_units'][0]['payments']['captures'][0]['id'])) {
        $capture_id = $capture['purchase_units'][0]['payments']['captures'][0]['id'];
    }

    return [
        'success' => true,
        'capture_id' => $capture_id,
        'status' => $capture['status'],
        'data' => $capture
    ];
}


/**
 * Verifica la firma de un webhook de PayPal
 */
function verificarWebhookPayPal($headers, $raw_body, $webhook_id, $access_token, $modo = 'sandbox') {
    $headers_lower = array_change_key_case($headers, CASE_LOWER);

    $transmission_id = $headers_lower['paypal-transmission-id'] ?? '';
    $transmission_time = $headers_lower['paypal-transmission-time'] ?? '';
    $transmission_sig = $headers_lower['paypal-transmission-sig'] ?? '';
    $cert_url = $headers_lower['paypal-cert-url'] ?? '';
    $auth_algo = $headers_lower['paypal-auth-algo'] ?? '';

    if (empty($transmission_id) || empty($transmission_time) || empty($transmission_sig) || empty($cert_url)) {
        error_log("[api_paypal] verificarWebhookPayPal: faltan headers");
        return false;
    }

    $api_base = ($modo == 'live')
        ? 'https://api-m.paypal.com'
        : 'https://api-m.sandbox.paypal.com';

    $verification_data = [
        'transmission_id' => $transmission_id,
        'transmission_time' => $transmission_time,
        'cert_url' => $cert_url,
        'auth_algo' => $auth_algo,
        'transmission_sig' => $transmission_sig,
        'webhook_id' => $webhook_id,
        'webhook_event' => json_decode($raw_body, true)
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/v1/notifications/verify-webhook-signature');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($verification_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $access_token
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || $http_code != 200) {
        error_log("[api_paypal] verificarWebhookPayPal: HTTP $http_code - $curl_error");
        return false;
    }

    $result = json_decode($response, true);

    return isset($result['verification_status']) && $result['verification_status'] == 'SUCCESS';
}


/**
 * Captura una orden para el cron genérico
 * (versión que recibe conn + pedido_id + pedido + proveedor_id)
 *
 * @param mysqli $conn         Conexión a BD
 * @param int    $pedido_id    ID del pedido
 * @param array  $pedido       Datos del pedido
 * @param int    $proveedor_id ID del proveedor
 * @return array               ['success' => bool, 'mensaje' => string]
 */
function capturarOrdenPaypal($conn, $pedido_id, $pedido, $proveedor_id) {
    // 1. Obtener credenciales del proveedor (o global)
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id IN (?, 0)
        AND clave IN ('paypal_client_id', 'paypal_client_secret', 'paypal_modo')
        ORDER BY proveedor_id DESC
    ");
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    $datos = [];
    while ($row = $res->fetch_assoc()) {
        $clave = str_replace('paypal_', '', $row['clave']);
        if (!isset($datos[$clave])) {
            $datos[$clave] = $row['valor'];
        }
    }
    $stmt->close();
    
    $client_id = $datos['client_id'] ?? '';
    $client_secret = $datos['client_secret'] ?? '';
    $modo = $datos['modo'] ?? 'sandbox';
    
    if (empty($client_id) || empty($client_secret)) {
        return ['success' => false, 'mensaje' => 'Credenciales incompletas'];
    }
    
    // 2. Obtener token
    $token = obtenerTokenPayPal($client_id, $client_secret, $modo);
    
    if (empty($token)) {
        return ['success' => false, 'mensaje' => 'Error al obtener token'];
    }
    
    // 3. Capturar orden
    $order_id = $pedido['referencia_externa'];
    $captura = ejecutarCapturaPayPal($token, $order_id, $modo);
    
    if (!$captura || !$captura['success']) {
        return ['success' => false, 'mensaje' => 'No se pudo capturar (posiblemente aún no aprobada)'];
    }
    
        // 4. Actualizar pedido en transacción
    $capture_id = $captura['capture_id'] ?? '';
    
    // Obtener el monto real recibido del JSON de PayPal (en moneda del pedido)
    $monto_recibido = 0;
    if (isset($captura['data']['purchase_units'][0]['payments']['captures'][0]['amount']['value'])) {
        $monto_recibido = floatval($captura['data']['purchase_units'][0]['payments']['captures'][0]['amount']['value']);
    }
    
    // Fallback: usar monto_pendiente si no se pudo extraer del JSON
    if ($monto_recibido <= 0) {
        $monto_recibido = floatval($pedido['monto_pendiente']);
    }
    
    // Validar monto contra monto_pendiente
    $monto_pendiente_actual = floatval($pedido['monto_pendiente']);
    
    if (abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
        return ['success' => false, 'mensaje' => 'Monto no coincide. Esperado: ' . $monto_pendiente_actual . ', Recibido: ' . $monto_recibido];
    }
    
    // Determinar si es 1er pago o 2do pago
    $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);
    
    // Calcular nuevos valores
    $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
    $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
    $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);
    
    // Comisión: solo se suma si es 2do pago
    $nueva_comision = floatval($pedido['comision']);
    
    if (!$es_primer_pago) {
        $stmt_com = $conn->prepare("
            SELECT valor FROM configuracion 
            WHERE clave = 'paypal_comision' 
            AND grupo = 'pagos' 
            AND proveedor_id IN (?, 0)
            ORDER BY proveedor_id DESC LIMIT 1
        ");
        $stmt_com->bind_param("i", $proveedor_id);
        $stmt_com->execute();
        $com_data = $stmt_com->get_result()->fetch_assoc();
        $stmt_com->close();
        $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;
        
        $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
        $nueva_comision += $comision_del_pago;
    }
    
        // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago completo
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        // 1er pago parcial → debe el saldo final
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        // Otros casos → mantener estado actual
        $nuevo_estado_pago = $pedido['estado_pago'];
    }
    
        // Determinar nuevo estado_actual
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago total (cubre 100%)
        // Forma 1: pago total adelantado → pago_confirmado
        if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
            $nuevo_estado_actual = 'pago_confirmado';
        } else {
            // Forma 2 (contra entrega) o Forma 3 (2do pago parcial) → no tocar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    } else {
        // Pago parcial (no cubre 100%)
        if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
            // Forma 3: 1er pago parcial
            $nuevo_estado_actual = 'pendiente_entrega_pago';
        } else {
            // Cualquier otro caso → no cambiar
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    }
    
    $conn->begin_transaction();
    
    try {
        $stmt_upd = $conn->prepare("
            UPDATE pedidos 
            SET monto_pagado = ?,
                monto_pendiente = ?,
                porcentaje_pagado = ?,
                comision = ?,
                estado_pago = ?,
                estado_actual = ?,
                fecha_pago = NOW(),
                transaccion_id = ?
            WHERE id = ?
        ");
        $stmt_upd->bind_param("ddidsissi", 
            $nuevo_monto_pagado,
            $nuevo_monto_pendiente,
            $nuevo_porcentaje,
            $nueva_comision,
            $nuevo_estado_pago,
            $nuevo_estado_actual,
            $capture_id,
            $pedido_id
        );
        $stmt_upd->execute();
        $stmt_upd->close();
        
        // Registrar en historial
        $obs = "Pago capturado por cron. Captura: " . $capture_id . " | Monto: " . $monto_recibido;
        $stmt_estado = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'pago_confirmado', 1, ?)
        ");
        $stmt_estado->bind_param("is", $pedido_id, $obs);
        $stmt_estado->execute();
        $stmt_estado->close();
        
        // Encolar correos
        encolarCorreosPagoPaypalCron($conn, $pedido_id, $pedido);
        
        $conn->commit();
        
        return ['success' => true, 'mensaje' => 'Capturado'];
        
    } catch (Throwable $e) {
        $conn->rollback();
        error_log("[api_paypal] Rollback pedido #$pedido_id: " . $e->getMessage());
        return ['success' => false, 'mensaje' => 'Error al actualizar: ' . $e->getMessage()];
    }
}


/**
 * Encola correos de pago confirmado (versión para cron)
 */
if (!function_exists('encolarCorreosPagoPaypalCron')) {
    function encolarCorreosPagoPaypalCron($conn, $pedido_id, $pedido) {
        // Correo al cliente (solo al cliente)
        $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
        $stmt->bind_param("i", $pedido['cliente_id']);
        $stmt->execute();
        $cliente = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($cliente && !empty($cliente['email'])) {
            encolarCorreo(
                $conn,
                $cliente['email'],
                'Pago confirmado - Pedido ' . $pedido['codigo'],
                'pago_confirmado',
                null,
                $pedido_id
            );
        }
        
        // NO se envía correo al proveedor (solo recibe al crear el pedido)
    }
}

/**
 * ============================================
 * FUNCIÓN PÚBLICA (carga por convención)
 * ============================================
 * Llamada desde redirigir_pago.php:
 *   $archivo = __DIR__ . '/apis/api_' . $metodo_pago . '.php';
 *   require_once $archivo;
 *   $funcion = 'construirUrl_' . $metodo_pago;
 *   $url = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
 *
 * @param mysqli $conn               Conexión a BD
 * @param int    $proveedor_config_id 0 = global, >0 = proveedor
 * @param int    $pedido_id          ID del pedido
 * @param float  $monto              Monto en moneda del pedido
 * @param string $codigo_pedido      Código del pedido
 * @param string $moneda             Código ISO 4217 (USD, EUR, MXN, etc.)
 * @return string|null               URL de aprobación o null si falla
 */
function construirUrl_paypal($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'USD') {
    // 1. Obtener credenciales del proveedor (o global)
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id = ? 
        AND clave IN ('paypal_client_id', 'paypal_client_secret', 'paypal_modo')
    ");
    $stmt->bind_param("i", $proveedor_config_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $datos = [];
    while ($row = $result->fetch_assoc()) {
        $clave = str_replace('paypal_', '', $row['clave']);
        $datos[$clave] = $row['valor'];
    }
    $stmt->close();

    $client_id = $datos['client_id'] ?? '';
    $client_secret = $datos['client_secret'] ?? '';
    $modo = $datos['modo'] ?? 'sandbox';

    if (empty($client_id) || empty($client_secret)) {
        error_log("[api_paypal] construirUrl_paypal: sin credenciales");
        return null;
    }

    // 2. Obtener access token
    $token = obtenerTokenPayPal($client_id, $client_secret, $modo);

    if (empty($token)) {
        error_log("[api_paypal] construirUrl_paypal: no se pudo obtener token");
        return null;
    }

    // 3. Construir URLs de retorno
    $host = 'https://' . $_SERVER['HTTP_HOST'];
    $return_url = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id;
    $cancel_url = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id . '&cancelado=1';

    // 4. Crear orden (con moneda)
    $orden = crearOrdenPayPal($token, $monto, $pedido_id, $codigo_pedido, $return_url, $cancel_url, $modo, $moneda);

    if (!$orden || empty($orden['approve_url'])) {
        error_log("[api_paypal] construirUrl_paypal: no se pudo crear orden");
        return null;
    }

    // 5. Guardar order_id en el pedido
    $stmt_upd = $conn->prepare("UPDATE pedidos SET referencia_externa = ? WHERE id = ?");
    $stmt_upd->bind_param("si", $orden['order_id'], $pedido_id);
    $stmt_upd->execute();
    $stmt_upd->close();

    // 6. Devolver URL de aprobación
    return $orden['approve_url'];
}
?>
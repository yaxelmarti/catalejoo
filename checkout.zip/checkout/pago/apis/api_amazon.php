<?php
// ============================================
// API AMAZON PAY - FUNCIONES
// ============================================
// Amazon Pay Checkout v2 usando el SDK oficial
// ============================================
// NOTA: el SDK de Amazon Pay no está instalado todavía.
// Este archivo es defensivo: si el SDK no está, no revienta el proceso.
// Cuando se instale vendor/autoload.php con amazon-pay-api-sdk-php,
// las funciones operarán normalmente sin tocar nada más.
// ============================================

// Cargar el SDK oficial de Amazon Pay (si existe)
$amazon_sdk_path = dirname(__DIR__, 3) . '/vendor/autoload.php';
$GLOBALS['amazon_sdk_disponible'] = false;

if (file_exists($amazon_sdk_path)) {
    require_once $amazon_sdk_path;
    if (class_exists('Amazon\Pay\API\Client')) {
        $GLOBALS['amazon_sdk_disponible'] = true;
    }
}

/**
 * Obtiene la configuración de Amazon Pay del proveedor (o global)
 */
function obtenerConfigAmazon($conn, $proveedor_id) {
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id IN (?, 0)
        AND clave IN ('amazon_public_key_id', 'amazon_private_key', 'amazon_store_id', 'amazon_seller_id', 'amazon_modo')
        ORDER BY proveedor_id DESC
    ");
    $stmt->bind_param("i", $proveedor_id);
    $stmt->execute();
    $res = $stmt->get_result();

    $datos = [];
    while ($row = $res->fetch_assoc()) {
        $clave = str_replace('amazon_', '', $row['clave']);
        if (!isset($datos[$clave])) {
            $datos[$clave] = $row['valor'];
        }
    }
    $stmt->close();

    return $datos;
}


/**
 * Crea una Checkout Session en Amazon Pay
 *
 * @param array  $config        Credenciales de Amazon Pay
 * @param float  $monto         Monto en moneda del pedido
 * @param int    $pedido_id     ID del pedido
 * @param string $codigo_pedido Código del pedido
 * @param string $return_url    URL de retorno
 * @param string $moneda        Código ISO 4217 (USD, EUR, GBP, JPY, etc.)
 * @return array|null           ['success' => true, 'checkout_url' => '...'] o null
 */
function crearCheckoutSessionAmazon($config, $monto, $pedido_id, $codigo_pedido, $return_url, $moneda = 'USD') {
    // 0. Verificar que el SDK esté disponible
    if (empty($GLOBALS['amazon_sdk_disponible'])) {
        error_log("[api_amazon] crearCheckoutSessionAmazon: SDK de Amazon Pay no disponible");
        return null;
    }
    
    $public_key_id = $config['public_key_id'] ?? '';
    $private_key_path = $config['private_key'] ?? '';
    $store_id = $config['store_id'] ?? '';
    $modo = $config['modo'] ?? 'sandbox';

    if (empty($public_key_id) || empty($private_key_path) || empty($store_id)) {
        error_log("[api_amazon] crearCheckoutSessionAmazon: credenciales incompletas");
        return null;
    }

    // Amazon Pay requiere la moneda en MAYÚSCULAS
    $moneda = strtoupper(trim($moneda));

    // Formatear monto (Amazon Pay espera 2 decimales, excepto JPY)
    $monedas_sin_decimales = ['JPY'];
    if (in_array($moneda, $monedas_sin_decimales)) {
        $valor_formateado = (string)intval(round($monto));
    } else {
        $valor_formateado = number_format($monto, 2, '.', '');
    }

    $amazonpay_config = [
        'public_key_id' => $public_key_id,
        'private_key'   => $private_key_path,
        'sandbox'       => ($modo === 'sandbox'),
        'region'        => 'NA',
        'algorithm'     => 'AMZN-PAY-RSASSA-PSS-V2'
    ];

    try {
        $client = new \Amazon\Pay\API\Client($amazonpay_config);
    } catch (Throwable $e) {
        error_log("[api_amazon] crearCheckoutSessionAmazon: no se pudo instanciar Client: " . $e->getMessage());
        return null;
    }

    // Payload de la Checkout Session
    $payload = [
        'webCheckoutDetails' => [
            'checkoutReviewReturnUrl' => $return_url,
            'checkoutResultReturnUrl' => $return_url
        ],
        'storeId' => $store_id,
        'scopes' => ['name', 'email', 'phoneNumber', 'billingAddress', 'shippingAddress'],
        'chargePermissionType' => 'OneTime',
        'paymentDetails' => [
            'chargeAmount' => [
                'amount' => $valor_formateado,
                'currencyCode' => $moneda
            ],
            'paymentIntent' => 'ChargeNow',
            'canHandlePendingAuthorization' => true
        ],
        'merchantMetadata' => [
            'merchantReferenceId' => $codigo_pedido,
            'merchantStoreName' => 'Catalejoo',
            'noteToBuyer' => 'Pedido ' . $codigo_pedido
        ]
    ];

    $headers = [
        'x-amz-pay-Idempotency-Key' => uniqid('pedido_' . $pedido_id . '_', true)
    ];

    try {
        $response = $client->createCheckoutSession($payload, $headers);
    } catch (Throwable $e) {
        error_log("[api_amazon] Exception crearCheckoutSessionAmazon: " . $e->getMessage());
        return null;
    }

    if (!is_array($response) || ($response['status'] ?? 0) !== 201) {
        error_log("[api_amazon] Error crearCheckoutSessionAmazon: status=" . ($response['status'] ?? 'NO') . " - " . json_encode($response['response'] ?? []));
        return null;
    }

    $body = $response['response'] ?? [];
    $checkout_url = $body['webCheckoutDetails']['amazonPayRedirectUrl'] ?? '';

    if (empty($checkout_url)) {
        error_log("[api_amazon] crearCheckoutSessionAmazon: sin amazonPayRedirectUrl");
        return null;
    }

    return [
        'success' => true,
        'checkout_session_id' => $body['checkoutSessionId'] ?? '',
        'checkout_url' => $checkout_url
    ];
}

/**
 * Consulta el estado de un Charge
 *
 * @param array  $config     Credenciales
 * @param string $charge_id  ID del Charge
 * @return array|null
 */
function consultarCargoAmazon($config, $charge_id) {
    // 0. Verificar que el SDK esté disponible
    if (empty($GLOBALS['amazon_sdk_disponible'])) {
        error_log("[api_amazon] consultarCargoAmazon: SDK de Amazon Pay no disponible");
        return null;
    }
    
    $public_key_id = $config['public_key_id'] ?? '';
    $private_key_path = $config['private_key'] ?? '';
    $modo = $config['modo'] ?? 'sandbox';

    $amazonpay_config = [
        'public_key_id' => $public_key_id,
        'private_key'   => $private_key_path,
        'sandbox'       => ($modo === 'sandbox'),
        'region'        => 'NA',
        'algorithm'     => 'AMZN-PAY-RSASSA-PSS-V2'
    ];

    try {
        $client = new \Amazon\Pay\API\Client($amazonpay_config);
    } catch (Throwable $e) {
        error_log("[api_amazon] consultarCargoAmazon: no se pudo instanciar Client: " . $e->getMessage());
        return null;
    }

    try {
        $response = $client->getCharge($charge_id);
    } catch (Throwable $e) {
        error_log("[api_amazon] Exception consultarCargoAmazon: " . $e->getMessage());
        return null;
    }

    if (!is_array($response) || ($response['status'] ?? 0) !== 200) {
        error_log("[api_amazon] Error consultarCargoAmazon: status=" . ($response['status'] ?? 'NO'));
        return null;
    }

    return $response['response'] ?? null;
}


/**
 * Captura una orden para el cron genérico
 * Amazon Pay requiere consultar el Charge para saber si se completó
 */
function capturarOrdenAmazon($conn, $pedido_id, $pedido, $proveedor_id) {
    if (in_array($pedido['estado_pago'] ?? '', ['pagado', 'cancelado'], true)) {
        return ['success' => true, 'mensaje' => 'Pedido ya pagado o cancelado'];
    }

    if (empty($pedido['referencia_externa'])) {
        return ['success' => false, 'mensaje' => 'Sin Charge ID'];
    }

    $config = obtenerConfigAmazon($conn, $proveedor_id);
    $charge = consultarCargoAmazon($config, $pedido['referencia_externa']);

    if (!$charge) {
        return ['success' => false, 'mensaje' => 'No se pudo consultar el Charge'];
    }

    $state = $charge['statusDetails']['state'] ?? '';

    if ($state !== 'Captured') {
        return ['success' => false, 'mensaje' => 'Charge no capturado (' . $state . ')'];
    }

    // Validar moneda del pago contra moneda del pedido
    $moneda_pago = strtoupper($charge['chargeAmount']['currencyCode'] ?? '');
    $moneda_pedido = strtoupper($pedido['moneda'] ?? 'USD');

    if (!empty($moneda_pago) && $moneda_pago !== $moneda_pedido) {
        return ['success' => false, 'mensaje' => 'Moneda no coincide'];
    }

    // Monto recibido
    $monto_recibido = floatval($charge['chargeAmount']['amount'] ?? 0);
    $monto_pendiente_actual = floatval($pedido['monto_pendiente']);

    if (abs($monto_recibido - $monto_pendiente_actual) > 0.01) {
        return ['success' => false, 'mensaje' => 'Monto no coincide. Esperado: ' . $monto_pendiente_actual . ', Recibido: ' . $monto_recibido];
    }

    // Determinar si es 1er pago o 2do pago
    $es_primer_pago = (floatval($pedido['monto_pagado']) == 0);

    // Calcular nuevos valores
    $nuevo_monto_pagado = floatval($pedido['monto_pagado']) + $monto_recibido;
    $nuevo_monto_pendiente = max(0, floatval($pedido['total_convertido']) - $nuevo_monto_pagado);
    $nuevo_porcentaje = round(($nuevo_monto_pagado / floatval($pedido['total_convertido'])) * 100);

    // Comisión: solo se suma si es 2do pago
    $nueva_comision = floatval($pedido['comision']);

    if (!$es_primer_pago) {
        $stmt_com = $conn->prepare("
            SELECT valor FROM configuracion 
            WHERE clave = 'amazon_comision' 
            AND grupo = 'pagos' 
            AND proveedor_id IN (?, 0)
            ORDER BY proveedor_id DESC LIMIT 1
        ");
        $stmt_com->bind_param("i", $proveedor_id);
        $stmt_com->execute();
        $com_data = $stmt_com->get_result()->fetch_assoc();
        $stmt_com->close();
        $porcentaje_comision = $com_data ? floatval($com_data['valor']) : 0;

        $comision_del_pago = round($monto_recibido * ($porcentaje_comision / 100), 2);
        $nueva_comision += $comision_del_pago;
    }

    // Determinar nuevo estado_pago
    if ($nuevo_monto_pendiente <= 0.01) {
        $nuevo_estado_pago = 'pagado';
    } elseif ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
        $nuevo_estado_pago = 'pendiente_pago_final';
    } else {
        $nuevo_estado_pago = $pedido['estado_pago'];
    }

    // Determinar nuevo estado_actual
    if ($nuevo_monto_pendiente <= 0.01) {
        // Pago total (cubre 100%)
        if (in_array($pedido['estado_pago'], ['pendiente', 'pendiente_verificacion'], true)) {
            $nuevo_estado_actual = 'pago_confirmado';
        } else {
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    } else {
        // Pago parcial (no cubre 100%)
        if ($es_primer_pago && floatval($pedido['porcentaje_comprometido'] ?? 0) > 0) {
            $nuevo_estado_actual = 'pendiente_entrega_pago';
        } else {
            $nuevo_estado_actual = $pedido['estado_actual'];
        }
    }

    $transaccion_id = $pedido['referencia_externa'];

    $conn->begin_transaction();

    try {
        $stmt_upd = $conn->prepare("
            UPDATE pedidos 
            SET monto_pagado = ?,
                monto_pendiente = ?,
                porcentaje_pagado = ?,
                comision = ?,
                estado_pago = ?,
                estado_actual = ?,
                fecha_pago = NOW(),
                transaccion_id = ?,
                pasarela_pago = 'amazon'
            WHERE id = ?
        ");
        $stmt_upd->bind_param("ddidsissi", 
            $nuevo_monto_pagado,
            $nuevo_monto_pendiente,
            $nuevo_porcentaje,
            $nueva_comision,
            $nuevo_estado_pago,
            $nuevo_estado_actual,
            $transaccion_id,
            $pedido_id
        );
        $stmt_upd->execute();
        $stmt_upd->close();

        $obs = "Pago confirmado por Amazon Pay (cron). Charge: " . $transaccion_id . " | Monto: " . $monto_recibido . " " . $moneda_pedido;
        $stmt_estado = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'pago_confirmado', 1, ?)
        ");
        $stmt_estado->bind_param("is", $pedido_id, $obs);
        $stmt_estado->execute();
        $stmt_estado->close();

        encolarCorreosPagoAmazonCron($conn, $pedido_id, $pedido);

        $conn->commit();
        return ['success' => true, 'mensaje' => 'Capturado'];

    } catch (Throwable $e) {
        $conn->rollback();
        error_log("[api_amazon] Rollback pedido #$pedido_id: " . $e->getMessage());
        return ['success' => false, 'mensaje' => 'Error al actualizar: ' . $e->getMessage()];
    }
}

/**
 * Encola correos de pago confirmado (versión para cron)
 */
if (!function_exists('encolarCorreosPagoAmazonCron')) {
    function encolarCorreosPagoAmazonCron($conn, $pedido_id, $pedido) {
        $stmt = $conn->prepare("SELECT email FROM clientes WHERE id = ?");
        $stmt->bind_param("i", $pedido['cliente_id']);
        $stmt->execute();
        $cliente = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($cliente && !empty($cliente['email'])) {
            encolarCorreo($conn, $cliente['email'], 'Pago confirmado - Pedido ' . $pedido['codigo'], 'pago_confirmado', null, $pedido_id);
        }

        $stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
        $stmt_prov->bind_param("i", $pedido_id);
        $stmt_prov->execute();
        $proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
        $stmt_prov->close();

        if ($proveedor_id > 0) {
            $stmt = $conn->prepare("SELECT email, email_ventas FROM proveedores WHERE id = ?");
            $stmt->bind_param("i", $proveedor_id);
            $stmt->execute();
            $proveedor = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $email_proveedor = !empty($proveedor['email_ventas']) ? $proveedor['email_ventas'] : ($proveedor['email'] ?? '');

            if (!empty($email_proveedor) && filter_var($email_proveedor, FILTER_VALIDATE_EMAIL)) {
                if (!$cliente || $email_proveedor !== $cliente['email']) {
                    encolarCorreo($conn, $email_proveedor, 'Pago confirmado - Pedido ' . $pedido['codigo'], 'pago_confirmado_proveedor', null, $pedido_id);
                }
            }
        }
    }
}


/**
 * ============================================
 * FUNCIÓN PÚBLICA (carga por convención)
 * ============================================
 * Llamada desde redirigir_pago.php:
 *   $archivo = __DIR__ . '/apis/api_' . $metodo_pago . '.php';
 *   require_once $archivo;
 *   $funcion = 'construirUrl_' . $metodo_pago;
 *   $url = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
 *
 * @param mysqli $conn               Conexión a BD
 * @param int    $proveedor_config_id 0 = global, >0 = proveedor
 * @param int    $pedido_id          ID del pedido
 * @param float  $monto              Monto en moneda del pedido
 * @param string $codigo_pedido      Código del pedido
 * @param string $moneda             Código ISO 4217
 * @return string|null               URL de pago o null si falla
 */
function construirUrl_amazon($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'USD') {
    // 0. Verificar que el SDK esté disponible
    if (empty($GLOBALS['amazon_sdk_disponible'])) {
        error_log("[api_amazon] construirUrl_amazon: SDK de Amazon Pay no disponible");
        return null;
    }
    
    // 1. Obtener configuración del proveedor (o global)
    $config = obtenerConfigAmazon($conn, $proveedor_config_id);
    
    if (empty($config['public_key_id']) || empty($config['private_key']) || empty($config['store_id'])) {
        error_log("[api_amazon] construirUrl_amazon: credenciales incompletas");
        return null;
    }
    
    // 2. Construir URL de retorno
    $host = 'https://' . $_SERVER['HTTP_HOST'];
    $return_url = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id;
    
    // 3. Crear Checkout Session (con moneda)
    $session = crearCheckoutSessionAmazon($config, $monto, $pedido_id, $codigo_pedido, $return_url, $moneda);
    
    if (!$session || empty($session['checkout_url'])) {
        error_log("[api_amazon] construirUrl_amazon: no se pudo crear Checkout Session");
        return null;
    }
    
    // 4. Guardar checkout_session_id en el pedido
    $stmt_upd = $conn->prepare("UPDATE pedidos SET referencia_externa = ? WHERE id = ?");
    $stmt_upd->bind_param("si", $session['checkout_session_id'], $pedido_id);
    $stmt_upd->execute();
    $stmt_upd->close();
    
    // 5. Devolver URL
    return $session['checkout_url'];
}


/**
 * Verifica que la pasarela Amazon Pay esté lista para usarse.
 * Se llama desde verificar_pasarela.php (pre-check antes de crear pedido).
 *
 * @param mysqli $conn
 * @param int    $proveedor_config_id
 * @return array ['success' => bool, 'mensaje' => string]
 */
function verificar_amazon($conn, $proveedor_config_id) {
    // 1. SDK disponible
    if (empty($GLOBALS['amazon_sdk_disponible'])) {
        return ['success' => false, 'mensaje' => 'El SDK de Amazon Pay no está instalado en el servidor'];
    }
    
    // 2. Credenciales completas
    $config = obtenerConfigAmazon($conn, $proveedor_config_id);
    
    if (empty($config['public_key_id'])) {
        return ['success' => false, 'mensaje' => 'Falta el Public Key ID de Amazon Pay'];
    }
    if (empty($config['private_key'])) {
        return ['success' => false, 'mensaje' => 'Falta la Private Key de Amazon Pay'];
    }
    if (empty($config['store_id'])) {
        return ['success' => false, 'mensaje' => 'Falta el Store ID de Amazon Pay'];
    }
    
    // 3. Ruta al archivo de la private key existe
    if (!file_exists($config['private_key'])) {
        return ['success' => false, 'mensaje' => 'El archivo de la Private Key no existe en el servidor'];
    }
    
    return ['success' => true];
}
?>
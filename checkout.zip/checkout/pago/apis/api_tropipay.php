<?php
// ============================================
// API TROPIPAY - FUNCIONES
// ============================================
// OAuth2, crear Payment Card, verificar firma
// ============================================

/**
 * Obtiene un access token de TropiPay
 */
function obtenerTokenTropipay($client_id, $client_secret, $modo = 'sandbox') {
    $api_base = ($modo == 'live') 
        ? 'https://www.tropipay.com' 
        : 'https://sandbox.tropipay.me';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/api/v1/oauth/token');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'client_credentials',
        'client_id' => $client_id,
        'client_secret' => $client_secret
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || $http_code != 200) {
        error_log("[api_tropipay] Error obtenerTokenTropipay: HTTP $http_code - $curl_error");
        return null;
    }

    $data = json_decode($response, true);
    return $data['access_token'] ?? null;
}


/**
 * Crea un Payment Card (enlace de pago)
 *
 * @param string $token           Access token de TropiPay
 * @param float  $monto           Monto en moneda del pedido
 * @param int    $pedido_id       ID del pedido
 * @param string $codigo_pedido   Código del pedido
 * @param string $url_success     URL de retorno si el pago se completa
 * @param string $url_failed      URL de retorno si el cliente cancela
 * @param string $url_notification URL de webhook
 * @param string $modo            sandbox | live
 * @param string $moneda          Código ISO 4217 (EUR, USD, USDC)
 */
function crearPaymentCardTropipay($token, $monto, $pedido_id, $codigo_pedido, $url_success, $url_failed, $url_notification, $modo = 'sandbox', $moneda = 'USD') {
    $api_base = ($modo == 'live') 
        ? 'https://www.tropipay.com' 
        : 'https://sandbox.tropipay.me';

    // TropiPay requiere la moneda en MAYÚSCULAS
    $moneda = strtoupper(trim($moneda));

    $payload = [
        'reference' => $codigo_pedido,
        'concept' => 'Pedido ' . $codigo_pedido,
        'amount' => round($monto * 100), // TropiPay usa centavos
        'currency' => $moneda,
        'singleUse' => true,
        'lang' => 'es',
        'urlSuccess' => $url_success,
        'urlFailed' => $url_failed,
        'urlNotification' => $url_notification,
        'directPayment' => true
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/api/v2/paymentcards');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || ($http_code != 200 && $http_code != 201)) {
        error_log("[api_tropipay] Error crearPaymentCardTropipay: HTTP $http_code - $curl_error - $response");
        return null;
    }

    $card = json_decode($response, true);

    if (!isset($card['shortUrl'])) {
        error_log("[api_tropipay] crearPaymentCardTropipay: respuesta sin shortUrl");
        return null;
    }

    return [
        'success' => true,
        'paymentcard_id' => $card['id'] ?? '',
        'shortUrl' => $card['shortUrl']
    ];
}


/**
 * Verifica la firma de un webhook de TropiPay
 */
function verificarFirmaTropipay($payload, $signature, $secret) {
    if (empty($signature) || empty($secret)) {
        return false;
    }

    $data = json_decode($payload, true);
    if (!$data) return false;

    $original_amount = $data['originalCurrencyAmount'] ?? '';
    $bank_order_code = $data['bankOrderCode'] ?? '';

    if (empty($original_amount) || empty($bank_order_code)) {
        error_log("[api_tropipay] verificarFirmaTropipay: faltan datos");
        return false;
    }

    $firma_esperada = hash_hmac('sha256', $original_amount . $bank_order_code, $secret);

    return hash_equals($firma_esperada, $signature);
}


/**
 * Captura una orden para el cron genérico
 * TropiPay no requiere captura manual
 */
function capturarOrdenTropipay($conn, $pedido_id, $pedido, $proveedor_id) {
    if (in_array($pedido['estado_pago'] ?? '', ['pagado', 'completado'])) {
        return ['success' => true, 'mensaje' => 'Pedido ya pagado'];
    }
    return ['success' => false, 'mensaje' => 'TropiPay no requiere captura manual'];
}

/**
 * ============================================
 * FUNCIÓN PÚBLICA (carga por convención)
 * ============================================
 * Llamada desde redirigir_pago.php:
 *   $archivo = __DIR__ . '/apis/api_' . $metodo_pago . '.php';
 *   require_once $archivo;
 *   $funcion = 'construirUrl_' . $metodo_pago;
 *   $url = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
 *
 * @param mysqli $conn               Conexión a BD
 * @param int    $proveedor_config_id 0 = global, >0 = proveedor
 * @param int    $pedido_id          ID del pedido
 * @param float  $monto              Monto en moneda del pedido
 * @param string $codigo_pedido      Código del pedido
 * @param string $moneda             Código ISO 4217 (EUR, USD, USDC)
 * @return string|null               URL de pago o null si falla
 */
function construirUrl_tropipay($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'USD') {
    // 1. Obtener credenciales del proveedor (o global)
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id = ? 
        AND clave IN ('tropipay_client_id', 'tropipay_client_secret', 'tropipay_modo')
    ");
    $stmt->bind_param("i", $proveedor_config_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $datos = [];
    while ($row = $result->fetch_assoc()) {
        $clave = str_replace('tropipay_', '', $row['clave']);
        $datos[$clave] = $row['valor'];
    }
    $stmt->close();
    
    $client_id = $datos['client_id'] ?? '';
    $client_secret = $datos['client_secret'] ?? '';
    $modo = $datos['modo'] ?? 'sandbox';
    
    if (empty($client_id) || empty($client_secret)) {
        error_log("[api_tropipay] construirUrl_tropipay: sin credenciales");
        return null;
    }
    
    // 2. Obtener access token
    $token = obtenerTokenTropipay($client_id, $client_secret, $modo);
    
    if (empty($token)) {
        error_log("[api_tropipay] construirUrl_tropipay: no se pudo obtener token");
        return null;
    }
    
    // 3. Construir URLs de retorno
    $host = 'https://' . $_SERVER['HTTP_HOST'];
    $url_success = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id;
    $url_failed = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id . '&cancelado=1';
    $url_notification = $host . '/checkout/pago/webhook.php';
    
    // 4. Crear Payment Card (con moneda)
    $card = crearPaymentCardTropipay($token, $monto, $pedido_id, $codigo_pedido, $url_success, $url_failed, $url_notification, $modo, $moneda);
    
    if (!$card || empty($card['shortUrl'])) {
        error_log("[api_tropipay] construirUrl_tropipay: no se pudo crear Payment Card");
        return null;
    }
    
    // 5. Guardar paymentcard_id en el pedido
    $stmt_upd = $conn->prepare("UPDATE pedidos SET referencia_externa = ? WHERE id = ?");
    $stmt_upd->bind_param("si", $card['paymentcard_id'], $pedido_id);
    $stmt_upd->execute();
    $stmt_upd->close();
    
    // 6. Devolver URL
    return $card['shortUrl'];
}
?>
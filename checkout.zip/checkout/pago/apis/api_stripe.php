<?php
// ============================================
// API STRIPE - FUNCIONES
// ============================================
// Checkout Sessions + verificación de firma HMAC
// ============================================

/**
 * Crea una Checkout Session en Stripe
 *
 * @param string $secret_key      Secret key (sk_test_... o sk_live_...)
 * @param float  $monto           Monto a cobrar (en moneda del pedido)
 * @param int    $pedido_id       ID del pedido
 * @param string $codigo_pedido   Código del pedido
 * @param string $success_url     URL de retorno si el pago se completa
 * @param string $cancel_url      URL de retorno si el cliente cancela
 * @param string $moneda          Código ISO 4217 (USD, EUR, MXN, etc.) - Stripe lo requiere en minúsculas
 * @return array|null             ['success' => true, 'session_id' => '...', 'checkout_url' => '...'] o null
 */
function crearCheckoutSessionStripe($secret_key, $monto, $pedido_id, $codigo_pedido, $success_url, $cancel_url, $moneda = 'USD') {
    $url = 'https://api.stripe.com/v1/checkout/sessions';
    
    // Stripe requiere la moneda en minúsculas
    $moneda = strtolower(trim($moneda));
    
    // Stripe usa centavos (o la unidad mínima de la moneda)
    // Monedas sin decimales se pasan sin multiplicar
    $monedas_sin_decimales = ['jpy', 'krw', 'vnd', 'clp', 'isk', 'xaf', 'xof', 'xpf'];
    if (in_array($moneda, $monedas_sin_decimales)) {
        $unit_amount = round($monto);
    } else {
        $unit_amount = round($monto * 100);
    }
    
    $datos = [
        'mode' => 'payment',
        'ui_mode' => 'hosted',
        'success_url' => $success_url,
        'cancel_url' => $cancel_url,
        'client_reference_id' => $codigo_pedido,
        'metadata[pedido_id]' => (string)$pedido_id,
        'line_items[0][price_data][currency]' => $moneda,
        'line_items[0][price_data][product_data][name]' => 'Pedido ' . $codigo_pedido,
        'line_items[0][price_data][unit_amount]' => $unit_amount,
        'line_items[0][quantity]' => 1
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($datos));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $secret_key,
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    if ($curl_error || $http_code != 200) {
        error_log("[api_stripe] Error crearCheckoutSessionStripe: HTTP $http_code - $curl_error - $response");
        return null;
    }
    
    $session = json_decode($response, true);
    
    if (!isset($session['id']) || !isset($session['url'])) {
        error_log("[api_stripe] crearCheckoutSessionStripe: respuesta sin id o url");
        return null;
    }
    
    return [
        'success' => true,
        'session_id' => $session['id'],
        'checkout_url' => $session['url']
    ];
}


/**
 * Verifica la firma de un webhook de Stripe
 *
 * @param string $payload     Cuerpo crudo del webhook (JSON)
 * @param string $sig_header  Header Stripe-Signature
 * @param string $secret      Webhook secret (whsec_...)
 * @return bool               true si la firma es válida
 */
function verificarFirmaStripe($payload, $sig_header, $secret) {
    if (empty($sig_header) || empty($secret)) {
        return false;
    }
    
    // Parsear el header: t=timestamp,v1=firma
    $elementos = explode(',', $sig_header);
    $timestamp = null;
    $firmas = [];
    
    foreach ($elementos as $elemento) {
        $partes = explode('=', trim($elemento), 2);
        if (count($partes) == 2) {
            if ($partes[0] == 't') {
                $timestamp = $partes[1];
            } elseif ($partes[0] == 'v1') {
                $firmas[] = $partes[1];
            }
        }
    }
    
    if (!$timestamp || empty($firmas)) {
        error_log("[api_stripe] verificarFirmaStripe: header inválido");
        return false;
    }
    
    // Verificar timestamp (evitar replay attacks, tolerancia 5 minutos)
    if (abs(time() - $timestamp) > 300) {
        error_log("[api_stripe] verificarFirmaStripe: timestamp fuera de rango");
        return false;
    }
    
    // Calcular firma esperada
    $signed_payload = $timestamp . '.' . $payload;
    $firma_esperada = hash_hmac('sha256', $signed_payload, $secret);
    
    // Comparar firmas de forma segura
    foreach ($firmas as $firma) {
        if (hash_equals($firma_esperada, $firma)) {
            return true;
        }
    }
    
    error_log("[api_stripe] verificarFirmaStripe: firma no coincide");
    return false;
}


/**
 * Captura una orden para el cron genérico
 * Stripe Checkout cobra automáticamente, así que no requiere captura posterior
 * Esta función existe por consistencia con el cron genérico
 *
 * @param mysqli $conn         Conexión a BD
 * @param int    $pedido_id    ID del pedido
 * @param array  $pedido       Datos del pedido
 * @param int    $proveedor_id ID del proveedor
 * @return array               ['success' => bool, 'mensaje' => string]
 */
function capturarOrdenStripe($conn, $pedido_id, $pedido, $proveedor_id) {
    // Stripe Checkout cobra automáticamente al completar el pago.
    // No hay nada que capturar manualmente.
    // Esta función existe solo para que el cron genérico no falle.
    
    // Si el pedido ya está pagado, no hacer nada
    if (in_array($pedido['estado_pago'] ?? '', ['pagado', 'completado'])) {
        return ['success' => true, 'mensaje' => 'Pedido ya pagado'];
    }
    
    // Si aún no está pagado, no podemos hacer nada desde aquí
    // El webhook se encargará de confirmarlo
    return ['success' => false, 'mensaje' => 'Stripe no requiere captura manual'];
}

/**
 * ============================================
 * FUNCIÓN PÚBLICA (carga por convención)
 * ============================================
 * Llamada desde redirigir_pago.php:
 *   $archivo = __DIR__ . '/apis/api_' . $metodo_pago . '.php';
 *   require_once $archivo;
 *   $funcion = 'construirUrl_' . $metodo_pago;
 *   $url = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
 *
 * @param mysqli $conn               Conexión a BD
 * @param int    $proveedor_config_id 0 = global, >0 = proveedor
 * @param int    $pedido_id          ID del pedido
 * @param float  $monto              Monto en moneda del pedido
 * @param string $codigo_pedido      Código del pedido
 * @param string $moneda             Código ISO 4217 (USD, EUR, MXN, etc.)
 * @return string|null               URL de checkout o null si falla
 */
function construirUrl_stripe($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'USD') {
    // 1. Obtener secret_key del proveedor (o global)
    $stmt = $conn->prepare("
        SELECT valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id = ? 
        AND clave = 'stripe_secret_key'
    ");
    $stmt->bind_param("i", $proveedor_config_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    $secret_key = $result['valor'] ?? '';
    
    if (empty($secret_key)) {
        error_log("[api_stripe] construirUrl_stripe: sin secret_key");
        return null;
    }
    
    // 2. Construir URLs de retorno
    $host = 'https://' . $_SERVER['HTTP_HOST'];
    $success_url = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id;
    $cancel_url = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id . '&cancelado=1';
    
    // 3. Crear Checkout Session (con moneda)
    $session = crearCheckoutSessionStripe($secret_key, $monto, $pedido_id, $codigo_pedido, $success_url, $cancel_url, $moneda);
    
    if (!$session || empty($session['checkout_url'])) {
        error_log("[api_stripe] construirUrl_stripe: no se pudo crear sesión");
        return null;
    }
    
    // 4. Guardar session_id en el pedido
    $stmt_upd = $conn->prepare("UPDATE pedidos SET referencia_externa = ? WHERE id = ?");
    $stmt_upd->bind_param("si", $session['session_id'], $pedido_id);
    $stmt_upd->execute();
    $stmt_upd->close();
    
    // 5. Devolver URL de checkout
    return $session['checkout_url'];
}
?>
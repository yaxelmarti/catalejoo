<?php
// ============================================
// API SQUARE - FUNCIONES
// ============================================
// Checkout API (Payment Links) + verificación de firma HMAC
// ============================================

/**
 * Crea un Payment Link en Square
 *
 * @param string $access_token  Access token de Square
 * @param string $location_id   Location ID
 * @param float  $monto         Monto en moneda del pedido
 * @param int    $pedido_id     ID del pedido
 * @param string $codigo_pedido Código del pedido
 * @param string $redirect_url  URL de retorno
 * @param string $modo          sandbox | live
 * @param string $moneda        Código ISO 4217 (Square solo acepta la moneda del país de la cuenta)
 */
function crearCheckoutSquare($access_token, $location_id, $monto, $pedido_id, $codigo_pedido, $redirect_url, $modo = 'sandbox', $moneda = 'USD') {
    $api_base = ($modo == 'live')
        ? 'https://connect.squareup.com'
        : 'https://connect.squareupsandbox.com';

    // Square requiere la moneda en MAYÚSCULAS
    $moneda = strtoupper(trim($moneda));

    $payload = [
        'idempotency_key' => uniqid('pedido_' . $pedido_id . '_', true),
        'order' => [
            'location_id' => $location_id,
            'reference_id' => (string)$pedido_id,
            'line_items' => [
                [
                    'name' => 'Pedido ' . $codigo_pedido,
                    'quantity' => '1',
                    'base_price_money' => [
                        'amount' => round($monto * 100),
                        'currency' => $moneda
                    ]
                ]
            ]
        ],
        'checkout_options' => [
            'redirect_url' => $redirect_url
        ]
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_base . '/v2/online-checkout/payment-links');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $access_token,
        'Square-Version: 2026-08-19'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || ($http_code != 200 && $http_code != 201)) {
        error_log("[api_square] Error crearCheckoutSquare: HTTP $http_code - $curl_error - $response");
        return null;
    }

    $link = json_decode($response, true);

    if (!isset($link['payment_link']['url'])) {
        error_log("[api_square] crearCheckoutSquare: respuesta sin url");
        return null;
    }

    return [
        'success' => true,
        'payment_link_id' => $link['payment_link']['id'] ?? '',
        'url' => $link['payment_link']['url']
    ];
}

/**
 * Verifica la firma de un webhook de Square
 * Square firma: HMAC-SHA256( notification_url + raw_body, signature_key )
 * El resultado se base64-encodea y se compara con el header.
 */
function verificarFirmaSquare($raw_body, $signature, $signature_key, $notification_url) {
    if (empty($signature) || empty($signature_key) || empty($notification_url)) {
        return false;
    }

    $payload = $notification_url . $raw_body;
    $digest = hash_hmac('sha256', $payload, $signature_key, true);
    $firma_esperada = base64_encode($digest);

    return hash_equals($firma_esperada, $signature);
}


/**
 * Captura una orden para el cron genérico
 * Square Checkout cobra automáticamente
 */
function capturarOrdenSquare($conn, $pedido_id, $pedido, $proveedor_id) {
    if (in_array($pedido['estado_pago'] ?? '', ['pagado', 'completado'])) {
        return ['success' => true, 'mensaje' => 'Pedido ya pagado'];
    }
    return ['success' => false, 'mensaje' => 'Square no requiere captura manual'];
}

/**
 * ============================================
 * FUNCIÓN PÚBLICA (carga por convención)
 * ============================================
 * Llamada desde redirigir_pago.php:
 *   $archivo = __DIR__ . '/apis/api_' . $metodo_pago . '.php';
 *   require_once $archivo;
 *   $funcion = 'construirUrl_' . $metodo_pago;
 *   $url = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
 *
 * @param mysqli $conn               Conexión a BD
 * @param int    $proveedor_config_id 0 = global, >0 = proveedor
 * @param int    $pedido_id          ID del pedido
 * @param float  $monto              Monto en moneda del pedido
 * @param string $codigo_pedido      Código del pedido
 * @param string $moneda             Código ISO 4217
 * @return string|null               URL de pago o null si falla
 */
function construirUrl_square($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'USD') {
    // 1. Obtener credenciales del proveedor (o global)
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id = ? 
        AND clave IN ('square_access_token', 'square_location_id', 'square_modo')
    ");
    $stmt->bind_param("i", $proveedor_config_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $datos = [];
    while ($row = $result->fetch_assoc()) {
        $clave = str_replace('square_', '', $row['clave']);
        $datos[$clave] = $row['valor'];
    }
    $stmt->close();
    
    $access_token = $datos['access_token'] ?? '';
    $location_id = $datos['location_id'] ?? '';
    $modo = $datos['modo'] ?? 'sandbox';
    
    if (empty($access_token) || empty($location_id)) {
        error_log("[api_square] construirUrl_square: sin credenciales");
        return null;
    }
    
    // 2. Construir URL de retorno
    $host = 'https://' . $_SERVER['HTTP_HOST'];
    $redirect_url = $host . '/checkout/confirmacion.php?pedido=' . $pedido_id;
    
    // 3. Crear Payment Link (con moneda)
    $link = crearCheckoutSquare($access_token, $location_id, $monto, $pedido_id, $codigo_pedido, $redirect_url, $modo, $moneda);
    
    if (!$link || empty($link['url'])) {
        error_log("[api_square] construirUrl_square: no se pudo crear Payment Link");
        return null;
    }
    
    // 4. Guardar payment_link_id en el pedido
    $stmt_upd = $conn->prepare("UPDATE pedidos SET referencia_externa = ? WHERE id = ?");
    $stmt_upd->bind_param("si", $link['payment_link_id'], $pedido_id);
    $stmt_upd->execute();
    $stmt_upd->close();
    
    // 5. Devolver URL
    return $link['url'];
}
?>
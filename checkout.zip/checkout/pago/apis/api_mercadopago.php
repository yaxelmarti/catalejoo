<?php
// ============================================
// API MERCADO PAGO - FUNCIONES
// ============================================
// Orders API (recomendada) + verificación de firma HMAC
// ============================================

/**
 * Crea una order en Mercado Pago (Orders API)
 * Documentación: POST /v1/orders
 *
 * @param string $access_token   Access token (TEST-... o APP_USR-...)
 * @param float  $monto          Monto en moneda del pedido
 * @param int    $pedido_id      ID del pedido
 * @param string $codigo_pedido  Código del pedido
 * @param string $email_cliente  Email del cliente
 * @param string $modo           sandbox | live
 * @param string $moneda         Código ISO 4217 (MXN, BRL, ARS, COP, CLP, PEN)
 * @return array|null            ['success' => true, 'order_id' => ..., 'init_point' => ...] o null
 */
function crearOrdenMercadoPago($access_token, $monto, $pedido_id, $codigo_pedido, $email_cliente, $modo = 'sandbox', $moneda = 'MXN') {
    $url = 'https://api.mercadopago.com/v1/orders';

    // Mercado Pago requiere la moneda en MAYÚSCULAS
    $moneda = strtoupper(trim($moneda));

    $payload = [
        'type' => 'online',
        'processing_mode' => 'automatic',
        'total_amount' => number_format($monto, 2, '.', ''),
        'external_reference' => (string)$pedido_id,
        'currency_id' => $moneda,
        'payer' => [
            'email' => $email_cliente
        ],
        'items' => [
            [
                'title' => 'Pedido ' . $codigo_pedido,
                'unit_price' => number_format($monto, 2, '.', ''),
                'quantity' => 1,
                'unit_measure' => 'unit'
            ]
        ]
    ];

    // Idempotency key única
    $idempotency_key = uniqid('pedido_' . $pedido_id . '_', true);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $access_token,
        'X-Idempotency-Key: ' . $idempotency_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || ($http_code != 200 && $http_code != 201)) {
        error_log("[api_mercadopago] Error crearOrdenMercadoPago: HTTP $http_code - $curl_error - $response");
        return null;
    }

    $order = json_decode($response, true);

    if (!isset($order['id'])) {
        error_log("[api_mercadopago] crearOrdenMercadoPago: respuesta sin id");
        return null;
    }

    // Buscar la URL de pago (init_point o sandbox_init_point)
    $init_point = $order['init_point'] ?? $order['sandbox_init_point'] ?? '';

    if (empty($init_point)) {
        error_log("[api_mercadopago] crearOrdenMercadoPago: sin init_point");
        return null;
    }

    return [
        'success' => true,
        'order_id' => $order['id'],
        'init_point' => $init_point,
        'data' => $order
    ];
}


/**
 * Consulta una order en Mercado Pago
 * Documentación: GET /v1/orders/{id}
 */
function consultarOrdenMercadoPago($access_token, $order_id) {
    $url = 'https://api.mercadopago.com/v1/orders/' . $order_id;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error || $http_code != 200) {
        error_log("[api_mercadopago] Error consultarOrdenMercadoPago: HTTP $http_code - $curl_error");
        return null;
    }

    return json_decode($response, true);
}


/**
 * Verifica la firma de un webhook de Mercado Pago
 * Header: x-signature con formato ts=...,v1=...
 * Manifest: id:{data_id};request-id:{x_request_id};ts:{ts};
 */
function verificarFirmaMercadoPago($x_signature, $x_request_id, $data_id, $secret) {
    if (empty($x_signature) || empty($x_request_id) || empty($data_id) || empty($secret)) {
        return false;
    }

    // Parsear x-signature
    $ts = '';
    $v1 = '';
    $elementos = explode(',', $x_signature);

    foreach ($elementos as $elemento) {
        $partes = explode('=', trim($elemento), 2);
        if (count($partes) == 2) {
            if ($partes[0] == 'ts') $ts = $partes[1];
            if ($partes[0] == 'v1') $v1 = $partes[1];
        }
    }

    if (empty($ts) || empty($v1)) {
        error_log("[api_mercadopago] verificarFirmaMercadoPago: header inválido");
        return false;
    }

    // Construir manifest
    $manifest = "id:" . strtolower($data_id) . ";request-id:" . $x_request_id . ";ts:" . $ts . ";";

    // Calcular firma esperada
    $firma_esperada = hash_hmac('sha256', $manifest, $secret);

    return hash_equals($firma_esperada, $v1);
}


/**
 * Captura una orden para el cron genérico
 * Mercado Pago con processing_mode automatic cobra automáticamente
 */
function capturarOrdenMercadopago($conn, $pedido_id, $pedido, $proveedor_id) {
    if (in_array($pedido['estado_pago'] ?? '', ['pagado', 'completado'])) {
        return ['success' => true, 'mensaje' => 'Pedido ya pagado'];
    }
    return ['success' => false, 'mensaje' => 'Mercado Pago no requiere captura manual'];
}

/**
 * ============================================
 * FUNCIÓN PÚBLICA (carga por convención)
 * ============================================
 * Llamada desde redirigir_pago.php:
 *   $archivo = __DIR__ . '/apis/api_' . $metodo_pago . '.php';
 *   require_once $archivo;
 *   $funcion = 'construirUrl_' . $metodo_pago;
 *   $url = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
 *
 * @param mysqli $conn               Conexión a BD
 * @param int    $proveedor_config_id 0 = global, >0 = proveedor
 * @param int    $pedido_id          ID del pedido
 * @param float  $monto              Monto en moneda del pedido
 * @param string $codigo_pedido      Código del pedido
 * @param string $moneda             Código ISO 4217
 * @return string|null               URL de pago o null si falla
 */
function construirUrl_mercadopago($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'MXN') {
    // 1. Obtener access_token del proveedor (o global)
    $stmt = $conn->prepare("
        SELECT valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND proveedor_id = ? 
        AND clave = 'mercadopago_access_token'
    ");
    $stmt->bind_param("i", $proveedor_config_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    $access_token = $result['valor'] ?? '';
    
    if (empty($access_token)) {
        error_log("[api_mercadopago] construirUrl_mercadopago: sin access_token");
        return null;
    }
    
    // 2. Obtener email del cliente (necesario para payer)
    $stmt_cliente = $conn->prepare("
        SELECT c.email 
        FROM clientes c 
        JOIN pedidos p ON p.cliente_id = c.id 
        WHERE p.id = ?
    ");
    $stmt_cliente->bind_param("i", $pedido_id);
    $stmt_cliente->execute();
    $cliente = $stmt_cliente->get_result()->fetch_assoc();
    $stmt_cliente->close();
    
    $email_cliente = $cliente['email'] ?? 'test_user_123@testuser.com';
    
    // 3. Detectar modo
    $modo = (strpos($access_token, 'TEST-') === 0) ? 'sandbox' : 'live';
    
    // 4. Crear orden (con moneda)
    $orden = crearOrdenMercadoPago($access_token, $monto, $pedido_id, $codigo_pedido, $email_cliente, $modo, $moneda);
    
    if (!$orden || empty($orden['init_point'])) {
        error_log("[api_mercadopago] construirUrl_mercadopago: no se pudo crear orden");
        return null;
    }
    
    // 5. Guardar order_id en el pedido
    $stmt_upd = $conn->prepare("UPDATE pedidos SET referencia_externa = ? WHERE id = ?");
    $stmt_upd->bind_param("si", $orden['order_id'], $pedido_id);
    $stmt_upd->execute();
    $stmt_upd->close();
    
    // 6. Devolver URL
    return $orden['init_point'];
}
?>
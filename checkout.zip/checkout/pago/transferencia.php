<?php
// ============================================
// PAGO CON TRANSFERENCIA BANCARIA - INSTRUCCIONES
// ============================================
// Este archivo muestra las instrucciones para pago con transferencia
// y permite al cliente confirmar que ya realizó el pago
// ============================================

// 1. Configurar cookies de sesión seguras
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Conexión y archivos necesarios
require_once dirname(__DIR__, 2) . '/conexion.php';
require_once dirname(__DIR__, 2) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__, 2) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__, 2) . '/includes/moneda_funciones.php';

// 3. Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

if ($cliente_id == 0) {
    header('Location: /index.php?error=login');
    exit;
}

// 4. Obtener pedido_id
$pedido_id = intval($_GET['pedido'] ?? 0);

if ($pedido_id == 0) {
    header('Location: /mis_pedidos.php');
    exit;
}

// 5. Validar que el pedido exista y pertenezca al cliente
$stmt = $conn->prepare("SELECT * FROM pedidos WHERE id = ? AND cliente_id = ?");
$stmt->bind_param("ii", $pedido_id, $cliente_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pedido) {
    header('Location: /mis_pedidos.php');
    exit;
}

// ============================================
// OBTENER MONEDA DEL PEDIDO
// ============================================
$moneda_pedido = $pedido['moneda'] ?? 'USD';
$moneda_simbolo = getSimboloPorMoneda($moneda_pedido);
$moneda_codigo = $moneda_pedido;

// 6. Obtener proveedor del pedido
$stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
$stmt_prov->bind_param("i", $pedido_id);
$stmt_prov->execute();
$proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
$stmt_prov->close();

if ($proveedor_id == 0) {
    header('Location: /mis_pedidos.php');
    exit;
}

// 7. Obtener nombre del proveedor
$stmt_tienda = $conn->prepare("SELECT nombre_tienda FROM proveedores WHERE id = ?");
$stmt_tienda->bind_param("i", $proveedor_id);
$stmt_tienda->execute();
$proveedor_data = $stmt_tienda->get_result()->fetch_assoc();
$stmt_tienda->close();
$nombre_tienda = $proveedor_data['nombre_tienda'] ?? 'Tienda';

// 8. Obtener el tipo de transferencia (USD o Clásica)
$tipo_transferencia = $_GET['tipo'] ?? $pedido['tipo_pago'];

// 9. Obtener datos de transferencia del proveedor (o global)
function obtenerDatosTransferencia($conn, $proveedor_id, $tipo) {
    $datos = [];
    
    if ($tipo == 'transferencia_usd') {
        $claves = ['transferencia_usd_beneficiario', 'transferencia_usd_banco', 'transferencia_usd_numero', 'transferencia_usd_swift', 'transferencia_usd_instrucciones'];
    } else {
        $claves = ['transferencia_clasica_beneficiario', 'transferencia_clasica_banco', 'transferencia_clasica_numero', 'transferencia_clasica_instrucciones'];
    }
    
    $placeholders = implode(',', array_fill(0, count($claves), '?'));
    
    $stmt = $conn->prepare("
        SELECT clave, valor FROM configuracion 
        WHERE grupo = 'pagos' 
        AND clave IN ($placeholders)
        AND proveedor_id IN (?, 0)
        ORDER BY proveedor_id DESC
    ");
    
    $types = str_repeat('s', count($claves)) . 'i';
    $params = array_merge($claves, [$proveedor_id]);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $clave = str_replace($tipo . '_', '', $row['clave']);
        if (!isset($datos[$clave])) {
            $datos[$clave] = $row['valor'];
        }
    }
    $stmt->close();
    return $datos;
}

$datos_transferencia = obtenerDatosTransferencia($conn, $proveedor_id, $tipo_transferencia);

// 10. Obtener monto a pagar (monto_pendiente = base del próximo pago, sin comisión)
$monto_a_pagar = floatval($pedido['monto_pendiente'] ?? 0);

if ($monto_a_pagar <= 0) {
    // Fallback para pedidos viejos
    $monto_a_pagar = floatval($pedido['total_convertido'] ?? $pedido['total']);
}

// 11. Generar CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 12. Manejar POST (cuando el cliente confirma que ya pagó)
$mensaje = '';
$tipo_mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $mensaje = '❌ Token de seguridad inválido';
        $tipo_mensaje = 'error';
    } else {
        $referencia = trim($_POST['referencia'] ?? '');
        
        // NO se cambia el estado del pedido.
        // Solo se registra en el historial que el cliente notificó el pago.
        $obs = "Cliente indica que realizó transferencia bancaria. Referencia: " . ($referencia ?: 'No especificada');
        $stmt_estado = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'notificacion_cliente', ?, ?)
        ");
        $stmt_estado->bind_param("iis", $pedido_id, $cliente_id, $obs);
        $stmt_estado->execute();
        $stmt_estado->close();
        
        // Redirigir a confirmación con mensaje
        header('Location: /checkout/confirmacion.php?pedido=' . $pedido_id . '&pendiente=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago con Transferencia - Pedido <?php echo htmlspecialchars($pedido['codigo']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 1rem;
        }
        .card {
            max-width: 520px;
            width: 100%;
            background: white;
            border-radius: 28px;
            padding: 2rem;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.3);
        }
        .icono {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 2.5rem;
            color: white;
        }
        h1 {
            font-size: 1.4rem;
            color: #2d3748;
            text-align: center;
            margin-bottom: 0.5rem;
        }
        .subtitulo {
            color: #718096;
            text-align: center;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }
        .info-box {
            background: #f8fafc;
            border-radius: 16px;
            padding: 1rem 1.2rem;
            margin-bottom: 1.5rem;
        }
        .info-linea {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            font-size: 0.9rem;
            color: #4a5568;
            border-bottom: 1px dashed #e2e8f0;
        }
        .info-linea:last-child { border-bottom: none; }
        .info-linea strong { color: #2d3748; }
        .monto {
            font-size: 1.3rem;
            color: #10b981;
            font-weight: 700;
        }
        .datos-pago {
            background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%);
            border-radius: 16px;
            padding: 1.2rem;
            margin-bottom: 1rem;
            border: 2px dashed #f59e0b;
        }
        .datos-pago h3 {
            font-size: 0.9rem;
            color: #92400e;
            margin-bottom: 0.8rem;
        }
        .dato {
            background: white;
            border-radius: 10px;
            padding: 0.8rem;
            margin-bottom: 0.6rem;
        }
        .dato:last-child { margin-bottom: 0; }
        .dato-label {
            font-size: 0.7rem;
            color: #718096;
            text-transform: uppercase;
            margin-bottom: 0.2rem;
        }
        .dato-valor {
            font-size: 1rem;
            font-weight: 700;
            color: #2d3748;
            word-break: break-all;
        }
        .botones-accion {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        .btn-accion {
            flex: 1;
            min-width: 120px;
            padding: 0.7rem;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            font-size: 0.85rem;
            font-family: inherit;
            transition: all 0.3s;
        }
        .btn-copiar {
            background: #f59e0b;
            color: white;
        }
        .btn-copiar:hover {
            background: #d97706;
            transform: translateY(-2px);
        }
        .btn-copiar-todo {
            background: #667eea;
            color: white;
            width: 100%;
            margin-bottom: 1.5rem;
        }
        .btn-copiar-todo:hover {
            background: #5a67d8;
            transform: translateY(-2px);
        }
        .mensaje-copiado {
            display: none;
            padding: 0.6rem 1rem;
            background: #f0fff4;
            color: #22543d;
            border: 2px solid #48bb78;
            border-radius: 10px;
            margin-bottom: 1rem;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .instrucciones {
            background: #fffaf0;
            border-left: 4px solid #ed8936;
            border-radius: 12px;
            padding: 1rem 1.2rem;
            margin-bottom: 1.5rem;
        }
        .instrucciones h3 {
            font-size: 0.9rem;
            color: #744210;
            margin-bottom: 0.6rem;
        }
        .instrucciones ol {
            margin-left: 1.2rem;
            color: #4a5568;
            font-size: 0.85rem;
            line-height: 1.6;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            font-size: 0.8rem;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 0.3rem;
        }
        .form-group input {
            width: 100%;
            padding: 0.7rem;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 0.9rem;
            font-family: inherit;
        }
        .form-group input:focus {
            outline: none;
            border-color: #f59e0b;
        }
        .btn-confirmar {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            font-family: inherit;
        }
        .btn-confirmar:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(16,185,129,0.4);
        }
        .btn-volver {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: #718096;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .btn-volver:hover { color: #f59e0b; }
        .aviso {
            background: #fef5e7;
            border-radius: 12px;
            padding: 0.8rem 1rem;
            font-size: 0.8rem;
            color: #744210;
            margin-top: 1rem;
            text-align: center;
        }
        @media (max-width: 480px) {
            .card { padding: 1.5rem; }
            .botones-accion { flex-direction: column; }
            .btn-accion { width: 100%; }
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="icono">🏦</div>
        <h1>Pago con Transferencia</h1>
        <p class="subtitulo">Pedido <?php echo htmlspecialchars($pedido['codigo']); ?> - <?php echo htmlspecialchars($nombre_tienda); ?></p>

        <?php if (!empty($mensaje)): ?>
        <div style="padding:1rem; margin-bottom:1rem; border-radius:12px; text-align:center; font-weight:600;
            <?php echo $tipo_mensaje == 'error' ? 'background:#fff5f5;color:#742a2a;border:2px solid #f56565;' : 'background:#f0fff4;color:#22543d;border:2px solid #48bb78;'; ?>">
            <?php echo $mensaje; ?>
        </div>
        <?php endif; ?>

        <div class="info-box">
            <div class="info-linea">
                <span>Pedido:</span>
                <strong><?php echo htmlspecialchars($pedido['codigo']); ?></strong>
            </div>
            <div class="info-linea">
                <span>Monto a pagar:</span>
                <span class="monto"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_a_pagar, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></span>
            </div>
        </div>

        <div class="datos-pago">
            <h3>🏦 Datos para la transferencia</h3>
            
            <?php if (!empty($datos_transferencia['beneficiario'])): ?>
            <div class="dato">
                <div class="dato-label">👤 Beneficiario</div>
                <div class="dato-valor"><?php echo htmlspecialchars($datos_transferencia['beneficiario']); ?></div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($datos_transferencia['banco'])): ?>
            <div class="dato">
                <div class="dato-label">🏦 Banco</div>
                <div class="dato-valor"><?php echo htmlspecialchars($datos_transferencia['banco']); ?></div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($datos_transferencia['numero'])): ?>
            <div class="dato">
                <div class="dato-label">🔢 Número de cuenta</div>
                <div class="dato-valor"><?php echo htmlspecialchars($datos_transferencia['numero']); ?></div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($datos_transferencia['swift'])): ?>
            <div class="dato">
                <div class="dato-label">🌐 SWIFT</div>
                <div class="dato-valor"><?php echo htmlspecialchars($datos_transferencia['swift']); ?></div>
            </div>
            <?php endif; ?>
        </div>

        <!-- BOTONES DE ACCIÓN -->
        <div class="botones-accion">
            <?php if (!empty($datos_transferencia['numero'])): ?>
            <button type="button" class="btn-accion btn-copiar" onclick="copiarDato('<?php echo htmlspecialchars($datos_transferencia['numero']); ?>')">
                📋 Copiar Cuenta
            </button>
            <?php endif; ?>
            
            <?php if (!empty($datos_transferencia['swift'])): ?>
            <button type="button" class="btn-accion btn-copiar" onclick="copiarDato('<?php echo htmlspecialchars($datos_transferencia['swift']); ?>')">
                📋 Copiar SWIFT
            </button>
            <?php endif; ?>
        </div>

        <!-- BOTÓN COPIAR TODO -->
        <button type="button" class="btn-accion btn-copiar-todo" onclick="copiarTodo()">
            📋 Copiar todos los datos
        </button>

        <!-- MENSAJE DE COPIADO -->
        <div id="mensajeCopiado" class="mensaje-copiado">
            ✅ Copiado al portapapeles
        </div>

        <div class="instrucciones">
            <h3>📋 Instrucciones</h3>
            <ol>
                <?php if (!empty($datos_transferencia['instrucciones'])): ?>
                    <?php echo nl2br(htmlspecialchars($datos_transferencia['instrucciones'])); ?>
                <?php else: ?>
                    <li>Realiza una transferencia bancaria a los datos de arriba</li>
                    <li>Por el monto exacto: <?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_a_pagar, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></li>
                    <li>Guarda el comprobante</li>
                    <li>Haz clic en "Ya pagué" para notificarnos</li>
                <?php endif; ?>
            </ol>
        </div>

        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div class="form-group">
                <label>Número de referencia (opcional)</label>
                <input type="text" name="referencia" placeholder="Ej: 123456789" value="">
            </div>

            <button type="submit" class="btn-confirmar">
                ✅ Ya pagué
            </button>
        </form>

        <div class="aviso">
            ⚠️ Tu pedido quedará pendiente de verificación hasta que confirmemos el pago.
        </div>

        <a href="/mis_pedidos.php" class="btn-volver">← Volver a mis pedidos</a>
    </div>

    <script>
    function copiarDato(texto) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(texto).then(function() {
                mostrarMensajeCopiado();
            }).catch(function() {
                copiarFallback(texto);
            });
        } else {
            copiarFallback(texto);
        }
    }

    function copiarFallback(texto) {
        const textarea = document.createElement('textarea');
        textarea.value = texto;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            mostrarMensajeCopiado();
        } catch (err) {
            alert('No se pudo copiar. Copia manualmente: ' + texto);
        }
        document.body.removeChild(textarea);
    }

    function mostrarMensajeCopiado() {
        const mensaje = document.getElementById('mensajeCopiado');
        mensaje.style.display = 'block';
        setTimeout(function() {
            mensaje.style.display = 'none';
        }, 2000);
    }

    function copiarTodo() {
        let texto = 'DATOS DE TRANSFERENCIA\n\n';
        texto += 'Pedido: <?php echo $pedido['codigo']; ?>\n';
        texto += 'Monto: <?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($monto_a_pagar, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?>\n\n';
        
        <?php if (!empty($datos_transferencia['beneficiario'])): ?>
        texto += 'Beneficiario: <?php echo addslashes($datos_transferencia['beneficiario']); ?>\n';
        <?php endif; ?>
        
        <?php if (!empty($datos_transferencia['banco'])): ?>
        texto += 'Banco: <?php echo addslashes($datos_transferencia['banco']); ?>\n';
        <?php endif; ?>
        
        <?php if (!empty($datos_transferencia['numero'])): ?>
        texto += 'Cuenta: <?php echo addslashes($datos_transferencia['numero']); ?>\n';
        <?php endif; ?>
        
        <?php if (!empty($datos_transferencia['swift'])): ?>
        texto += 'SWIFT: <?php echo addslashes($datos_transferencia['swift']); ?>\n';
        <?php endif; ?>
        
        copiarDato(texto);
    }
    </script>
</body>
</html>
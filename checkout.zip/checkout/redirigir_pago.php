<?php
// ============================================
// REDIRIGIR PAGO - CENTRALIZACIÓN DE PASARELAS
// ============================================
// Este archivo recibe el pedido_id y metodo_pago
// Detecta el proveedor y redirige a la pasarela correspondiente
// ============================================

// 1. Configurar cookies de sesión seguras
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Conexión y archivos necesarios
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/cola_correos.php';

// 3. Validar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /index.php');
    exit;
}

// 4. Validar CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /index.php');
    exit;
}

// 5. Obtener datos del POST
$pedido_id = intval($_POST['pedido_id'] ?? 0);
$metodo_pago = trim($_POST['metodo_pago'] ?? '');

if ($pedido_id <= 0 || empty($metodo_pago)) {
    header('Location: /index.php');
    exit;
}

// 6. Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

if ($cliente_id == 0) {
    header('Location: /index.php?error=login');
    exit;
}

// 7. Validar que el pedido exista y pertenezca al cliente
$stmt = $conn->prepare("SELECT * FROM pedidos WHERE id = ? AND cliente_id = ?");
$stmt->bind_param("ii", $pedido_id, $cliente_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pedido) {
    $_SESSION['mensaje'] = '❌ Pedido no encontrado';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /mis_pedidos.php');
    exit;
}

// 8. Obtener proveedor del pedido
$stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
$stmt_prov->bind_param("i", $pedido_id);
$stmt_prov->execute();
$proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
$stmt_prov->close();

if ($proveedor_id == 0) {
    $_SESSION['mensaje'] = '❌ El pedido no tiene un proveedor asignado';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /mis_pedidos.php');
    exit;
}

// 9. Validar que el proveedor esté activo
$stmt_prov_activo = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
$stmt_prov_activo->bind_param("i", $proveedor_id);
$stmt_prov_activo->execute();
$proveedor_activo = $stmt_prov_activo->get_result()->num_rows > 0;
$stmt_prov_activo->close();

if (!$proveedor_activo) {
    $_SESSION['mensaje'] = '❌ La tienda no está disponible';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /mis_pedidos.php');
    exit;
}

// 10. Determinar si el proveedor tiene configuración propia de pago
$stmt_config_prov = $conn->prepare("
    SELECT COUNT(*) as total 
    FROM configuracion 
    WHERE clave LIKE ? 
    AND grupo = 'pagos' 
    AND proveedor_id = ? 
    AND valor IS NOT NULL
");
$clave_activo = $metodo_pago . '_activo';
$stmt_config_prov->bind_param("si", $clave_activo, $proveedor_id);
$stmt_config_prov->execute();
$tiene_config_propia = $stmt_config_prov->get_result()->fetch_assoc()['total'] > 0;
$stmt_config_prov->close();

$proveedor_config_id = $tiene_config_propia ? $proveedor_id : 0;

// 11. Determinar el monto a pagar (SOLO monto_pendiente, sin comisión)
// La comisión la absorbe el proveedor (la pasarela se la cobra a él).
// CataLejoo solo la registra para auditoría en pedidos.comision.
$monto_base = floatval($pedido['monto_pendiente']);

if ($monto_base <= 0) {
    // Fallback para pedidos viejos sin monto_pendiente calculado
    $monto_base = floatval($pedido['total_convertido'] ?? $pedido['total']);
}

// El monto que paga el cliente es SOLO el monto base (sin comisión)
$monto_a_pagar = $monto_base;

// 12. Obtener tipo de pasarela desde la tabla `pasarelas` (escalable)
$stmt_tipo = $conn->prepare("
    SELECT tipo 
    FROM pasarelas 
    WHERE slug = ? 
    AND activo = 1
    LIMIT 1
");
$stmt_tipo->bind_param("s", $metodo_pago);
$stmt_tipo->execute();
$tipo_data = $stmt_tipo->get_result()->fetch_assoc();
$stmt_tipo->close();

$tipo_pasarela = $tipo_data['tipo'] ?? null;

// 13. Redirigir según tipo
if ($tipo_pasarela === 'api') {
    // ===== API =====
    
    // Caso especial PayPal: si NO hay client_id/client_secret → usar manual
    if ($metodo_pago == 'paypal') {
        $stmt_pp = $conn->prepare("
            SELECT clave, valor FROM configuracion 
            WHERE grupo = 'pagos' 
            AND proveedor_id = ?
            AND clave IN ('paypal_client_id', 'paypal_client_secret')
        ");
        $stmt_pp->bind_param("i", $proveedor_config_id);
        $stmt_pp->execute();
        $res_pp = $stmt_pp->get_result();
        
        $pp_datos = [];
        while ($row = $res_pp->fetch_assoc()) {
            $pp_datos[$row['clave']] = $row['valor'];
        }
        $stmt_pp->close();
        
        $tiene_api = !empty($pp_datos['paypal_client_id']) && !empty($pp_datos['paypal_client_secret']);
        
        if (!$tiene_api) {
            header('Location: /checkout/pago/paypal.php?pedido=' . $pedido_id);
            exit;
        }
    }
    
    // ============================================
    // MONEDA DEL PEDIDO (fuente de verdad: el pedido)
    // ============================================
    $moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
    
    // ============================================
    // INCLUIR CARGADOR POR CONVENCIÓN
    // ============================================
    require_once __DIR__ . '/general_api_pasarelas.php';
    
    // ============================================
    // DEFENSA EN PROFUNDIDAD: validar que la pasarela acepte la moneda
    // ============================================
    if (!pasarelaAceptaMoneda($conn, $metodo_pago, $moneda_pedido)) {
        $_SESSION['mensaje'] = '❌ Este método de pago no acepta la moneda del pedido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /checkout/confirmacion.php?pedido=' . $pedido_id . '&error=moneda_pasarela');
        exit;
    }
    
    // ============================================
    // CARGAR Y LLAMAR A LA API
    // ============================================
    $url_pago = construirUrlPasarela($conn, $metodo_pago, $proveedor_config_id, $pedido_id, $monto_a_pagar, $pedido['codigo'], $moneda_pedido);
    
    if ($url_pago) {
        header('Location: ' . $url_pago);
        exit;
    }
    
    // ============================================
    // FALLBACK: la pasarela API no pudo generar URL
    // ============================================
    // 1. Registrar el error en pedido_estados
    $obs_error = "Error al generar URL de pago. Pasarela: {$metodo_pago}. Moneda: {$moneda_pedido}. Monto: {$monto_a_pagar}.";
    $stmt_error = $conn->prepare("
        INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
        VALUES (?, 'error_pasarela', 1, ?)
    ");
    if ($stmt_error) {
        $stmt_error->bind_param("is", $pedido_id, $obs_error);
        $stmt_error->execute();
        $stmt_error->close();
    } else {
        error_log('[redirigir_pago] No se pudo registrar error_pasarela pedido #' . $pedido_id . ': ' . $conn->error);
    }
    
    // 2. Encolar correo al cliente (si tiene email válido)
    $email_cliente = $cliente['email'] ?? '';
    
    if (!empty($email_cliente) && filter_var($email_cliente, FILTER_VALIDATE_EMAIL)) {
        encolarCorreo(
            $conn,
            $email_cliente,
            '⚠️ No pudimos procesar tu pago - Pedido ' . $pedido['codigo'],
            'error_pasarela',
            null,
            $pedido_id
        );
    }
    
    // 3. Guardar mensaje flash para el cliente
    $nombre_pasarela_txt = ucfirst(str_replace('_', ' ', $metodo_pago));
    $_SESSION['mensaje'] = '⚠️ No pudimos conectar con ' . $nombre_pasarela_txt . '. Por favor, elige otro método de pago o inténtalo de nuevo más tarde. Tu pedido ' . $pedido['codigo'] . ' ha sido guardado y puedes pagarlo desde aquí.';
    $_SESSION['tipo_mensaje'] = 'error';
    
    // 4. Redirigir a mis_pedidos.php
    header('Location: /mis_pedidos.php');
    exit;
    
} elseif ($tipo_pasarela === 'manual') {
    // ===== MANUAL =====
    if ($metodo_pago == 'transferencia_usd' || $metodo_pago == 'transferencia_clasica') {
        header('Location: /checkout/pago/transferencia.php?pedido=' . $pedido_id . '&tipo=' . $metodo_pago);
    } else {
        header('Location: /checkout/pago/' . $metodo_pago . '.php?pedido=' . $pedido_id);
    }
    exit;
    
} else {
    // ===== SIN TIPO DEFINIDO: POR DEFECTO, CONFIRMACIÓN =====
    header('Location: /checkout/confirmacion.php?pedido=' . $pedido_id);
    exit;
}
?>
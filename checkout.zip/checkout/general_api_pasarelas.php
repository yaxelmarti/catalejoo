<?php
// ============================================
// GENERAL API PASARELAS - CARGADOR POR CONVENCIÓN
// ============================================
// Carga dinámicamente api_{slug}.php y llama a construirUrl_{slug}().
// NO tiene funciones hardcodeadas por pasarela.
// ============================================

/**
 * Carga dinámicamente el archivo de la API de una pasarela
 * y llama a su función construirUrl_{slug}().
 *
 * @param mysqli $conn                 Conexión a BD
 * @param string $slug                 Slug de la pasarela (paypal, stripe, etc.)
 * @param int    $proveedor_config_id  0 = global, >0 = proveedor
 * @param int    $pedido_id            ID del pedido
 * @param float  $monto                Monto en moneda del pedido
 * @param string $codigo_pedido        Código del pedido
 * @param string $moneda               Código ISO 4217
 * @return string|null                 URL de pago o null si falla
 */
function construirUrlPasarela($conn, $slug, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda = 'USD') {
    // Validar slug (solo letras, números y guión bajo)
    $slug = preg_replace('/[^a-z0-9_]/', '', strtolower($slug));
    if (empty($slug)) {
        error_log("[general_api_pasarelas] Slug inválido");
        return null;
    }
    
    // Construir ruta del archivo
    $archivo_api = __DIR__ . '/pago/apis/api_' . $slug . '.php';
    
    if (!file_exists($archivo_api)) {
        error_log("[general_api_pasarelas] Archivo no encontrado: $archivo_api");
        return null;
    }
    
    // Cargar archivo
    require_once $archivo_api;
    
    // Construir nombre de la función
    $funcion = 'construirUrl_' . $slug;
    
    if (!function_exists($funcion)) {
        error_log("[general_api_pasarelas] Función no encontrada: $funcion");
        return null;
    }
    
    // Llamar a la función con protección
    try {
        $url_pago = $funcion($conn, $proveedor_config_id, $pedido_id, $monto, $codigo_pedido, $moneda);
        
        if (!empty($url_pago)) {
            return $url_pago;
        }
        
        error_log("[general_api_pasarelas] $slug no devolvió URL");
        return null;
        
    } catch (Throwable $e) {
        error_log("[general_api_pasarelas] Error en $slug: " . $e->getMessage());
        return null;
    }
}

/**
 * Valida que la pasarela acepte la moneda del pedido.
 *
 * @param mysqli $conn          Conexión a BD
 * @param string $slug          Slug de la pasarela
 * @param string $moneda        Código ISO 4217
 * @return bool                 true si acepta, false si no
 */
function pasarelaAceptaMoneda($conn, $slug, $moneda) {
    $stmt = $conn->prepare("SELECT monedas FROM pasarelas WHERE slug = ? AND activo = 1 LIMIT 1");
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$res) {
        return false;
    }
    
    $monedas_pasarela = !empty($res['monedas']) 
        ? array_map('trim', explode(',', $res['monedas'])) 
        : [];
    
    // Si no tiene monedas configuradas, acepta todas
    if (empty($monedas_pasarela)) {
        return true;
    }
    
    return in_array(strtoupper($moneda), $monedas_pasarela);
}
?>
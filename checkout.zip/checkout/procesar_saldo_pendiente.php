<?php
// ============================================
// PROCESAR PAGO SALDO - SIN CREAR PEDIDO
// ============================================
// Replica procesar_pago.php pero sin crear pedido
// Solo valida y devuelve JSON para redirigir a la pasarela
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

set_exception_handler(function ($e) {
    error_log('[procesar_pago_saldo] EXCEPTION: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        header('Content-Type: application/json');
        http_response_code(500);
    }
    echo json_encode(['success' => false, 'mensaje' => 'Error interno del servidor']);
    exit;
});

set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    error_log("[procesar_pago_saldo] ERROR [$errno] $errstr @ $errfile:$errline");
    return true;
});

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/moneda_funciones.php';

header('Content-Type: application/json');

function responder($ok, $datos = []) {
    echo json_encode(array_merge(['success' => $ok], $datos), JSON_UNESCAPED_UNICODE);
    exit;
}

// 1. Validar CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    responder(false, ['mensaje' => 'Token de seguridad inválido']);
}

// 2. Datos del POST
$pedido_id = intval($_POST['pedido_id'] ?? 0);
$metodo_pago = trim($_POST['metodo_pago'] ?? '');

if ($pedido_id <= 0 || empty($metodo_pago)) {
    responder(false, ['mensaje' => 'Datos incompletos']);
}

// 3. Obtener cliente
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

if ($cliente_id == 0) {
    responder(false, ['mensaje' => 'Cliente no identificado']);
}

// 4. Validar pedido
$stmt = $conn->prepare("SELECT * FROM pedidos WHERE id = ? AND cliente_id = ?");
$stmt->bind_param("ii", $pedido_id, $cliente_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pedido) {
    responder(false, ['mensaje' => 'Pedido no encontrado']);
}

// 5. Validar monto_pendiente > 0 y estado
$monto_pendiente = floatval($pedido['monto_pendiente'] ?? 0);

if ($monto_pendiente <= 0) {
    responder(false, ['mensaje' => 'Este pedido no tiene saldo pendiente']);
}

if ($pedido['estado_actual'] === 'cancelado') {
    responder(false, ['mensaje' => 'Este pedido está cancelado']);
}

// 6. Obtener proveedor
$stmt_prov = $conn->prepare("SELECT DISTINCT proveedor_id FROM pedido_detalles WHERE pedido_id = ? LIMIT 1");
$stmt_prov->bind_param("i", $pedido_id);
$stmt_prov->execute();
$proveedor_id = $stmt_prov->get_result()->fetch_assoc()['proveedor_id'] ?? 0;
$stmt_prov->close();

if ($proveedor_id == 0) {
    responder(false, ['mensaje' => 'Pedido sin proveedor asignado']);
}

// 7. Validar proveedor activo
$stmt_prov_act = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1");
$stmt_prov_act->bind_param("i", $proveedor_id);
$stmt_prov_act->execute();
$proveedor_activo = $stmt_prov_act->get_result()->num_rows > 0;
$stmt_prov_act->close();

if (!$proveedor_activo) {
    responder(false, ['mensaje' => 'La tienda no está disponible']);
}

// 8. Validar método de pago activo en pasarelas
$stmt_pas = $conn->prepare("SELECT slug, nombre, tipo, monedas FROM pasarelas WHERE slug = ? AND activo = 1 LIMIT 1");
$stmt_pas->bind_param("s", $metodo_pago);
$stmt_pas->execute();
$info_pasarela = $stmt_pas->get_result()->fetch_assoc();
$stmt_pas->close();

if (!$info_pasarela) {
    responder(false, ['mensaje' => 'Método de pago no permitido']);
}

// 9. Validar moneda del método
$moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
$monedas_pasarela = !empty($info_pasarela['monedas']) 
    ? array_map('trim', explode(',', $info_pasarela['monedas'])) 
    : [];

if (!empty($monedas_pasarela) && !in_array($moneda_pedido, $monedas_pasarela)) {
    responder(false, ['mensaje' => 'Este método de pago no acepta la moneda del pedido']);
}

// 10. Validar activación del proveedor
$stmt_act = $conn->prepare("
    SELECT valor FROM configuracion 
    WHERE clave = ? AND grupo = 'pagos' AND proveedor_id IN (?, 0)
    ORDER BY proveedor_id DESC LIMIT 1
");
$clave_activo = $metodo_pago . '_activo';
$stmt_act->bind_param("si", $clave_activo, $proveedor_id);
$stmt_act->execute();
$act_data = $stmt_act->get_result()->fetch_assoc();
$stmt_act->close();

if (!$act_data || $act_data['valor'] != 1) {
    responder(false, ['mensaje' => 'El método de pago no está disponible para este proveedor']);
}

// 11. D22-A: Actualizar tipo_pago si el cliente cambia de método
// (para que el admin calcule la comisión con el método correcto al confirmar)
if ($pedido['tipo_pago'] !== $metodo_pago) {
    $stmt_tp = $conn->prepare("UPDATE pedidos SET tipo_pago = ? WHERE id = ?");
    $stmt_tp->bind_param("si", $metodo_pago, $pedido_id);
    $stmt_tp->execute();
    $stmt_tp->close();
}

// 12. Todo OK → devolver JSON
responder(true, [
    'pedido_id' => $pedido_id,
    'metodo_pago' => $metodo_pago,
    'redirect' => '/checkout/redirigir_pago.php',
    'csrf_token' => $_SESSION['csrf_token']
]);
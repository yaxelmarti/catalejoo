﻿<?php
// ============================================
// CHECKOUT MODERNO - 3 PASOS
// ============================================

if (!defined('SEGURO')) {
    define('SEGURO', true);
}

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Regenerar ID de sesión al entrar al checkout (prevenir fijación de sesión)
if (!isset($_SESSION['checkout_session_regenerada'])) {
    session_regenerate_id(true);
    $_SESSION['checkout_session_regenerada'] = true;
}

require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__) . '/includes/carrito_funciones.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/moneda_funciones.php';

$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

// ============================================
// LA MONEDA SE DETERMINA MÁS ABAJO, DESDE EL CARRITO
// (el carrito es la fuente de verdad en el checkout)
// ============================================

// ===== OBTENER ÚLTIMA DIRECCIÓN DE ENTREGA =====
$ultima_direccion = null;
$ultima_provincia_id = null;

if ($cliente_id > 0) {
    $stmt_dir = $conn->prepare("
        SELECT d.* 
        FROM direcciones_envio d
        JOIN pedidos p ON d.pedido_id = p.id
        WHERE p.cliente_id = ?
        ORDER BY p.fecha_pedido DESC
        LIMIT 1
    ");
    $stmt_dir->bind_param("i", $cliente_id);
    $stmt_dir->execute();
    $result_dir = $stmt_dir->get_result();
    
    if ($result_dir->num_rows > 0) {
        $ultima_direccion = $result_dir->fetch_assoc();
        
        if (!empty($ultima_direccion['provincia'])) {
            $stmt_prov = $conn->prepare("SELECT id FROM provincias WHERE nombre = ? AND activo = 1 LIMIT 1");
            $stmt_prov->bind_param("s", $ultima_direccion['provincia']);
            $stmt_prov->execute();
            $res_prov = $stmt_prov->get_result();
            if ($res_prov->num_rows > 0) {
                $ultima_provincia_id = $res_prov->fetch_assoc()['id'];
            }
            $stmt_prov->close();
        }
    }
    $stmt_dir->close();
}

if ($cliente_id == 0) {
    header('Location: /index.php?error=login');
    exit;
}

$carrito = iniciarCarrito($conn, $cliente_id);

if (!$carrito) {
    header('Location: /index.php?error=no_carrito');
    exit;
}

$proveedor_id = $carrito['proveedor_id'] ?? 0;

if ($proveedor_id == 0) {
    $_SESSION['mensaje'] = '❌ El carrito no tiene un proveedor asignado';
    header('Location: /carrito.php');
    exit;
}

$stmt_prov = $conn->prepare("SELECT id, nombre_tienda, slug FROM proveedores WHERE id = ? AND activo = 1");
$stmt_prov->bind_param("i", $proveedor_id);
$stmt_prov->execute();
$proveedor = $stmt_prov->get_result()->fetch_assoc();
$stmt_prov->close();

if (!$proveedor) {
    $_SESSION['mensaje'] = '❌ La tienda no está disponible';
    header('Location: /index.php');
    exit;
}

// Productos del carrito
$stmt = $conn->prepare("SELECT cp.*, p.nombre, p.imagen_url FROM carrito_productos cp JOIN productos p ON cp.producto_id = p.id WHERE cp.carrito_id = ?");
$stmt->bind_param("i", $carrito['id']);
$stmt->execute();
$productos = $stmt->get_result();
$items = [];
while ($item = $productos->fetch_assoc()) { $items[] = $item; }
$stmt->close();

// Combos del carrito
$stmt_combos = $conn->prepare("SELECT cc.*, c.nombre, c.imagen_url FROM carrito_combos cc JOIN combos c ON cc.combo_id = c.id WHERE cc.carrito_id = ?");
$stmt_combos->bind_param("i", $carrito['id']);
$stmt_combos->execute();
$combos = $stmt_combos->get_result();
$items_combos = [];
while ($combo = $combos->fetch_assoc()) { $items_combos[] = $combo; }
$stmt_combos->close();

// ============================================
// DETERMINAR MONEDA DESDE EL CARRITO
// ============================================
$moneda_actual = $carrito['moneda'] ?? 'USD';
$moneda_simbolo = getSimboloPorMoneda($moneda_actual);
$moneda_codigo = $moneda_actual;

// ============================================
// CALCULAR TASA UNA SOLA VEZ (optimización)
// ============================================
$tasa_actual = ($moneda_actual !== 'USD') 
    ? getTasaProveedor($conn, $proveedor_id, $moneda_actual) 
    : 1.0;

// ============================================
// CALCULAR SUBTOTAL (USD base + convertido)
// ============================================
$subtotal_usd = 0;
foreach ($items as $item) {
    $item_usd = floatval($item['precio_unitario']) * intval($item['cantidad']);
    $subtotal_usd += $item_usd;
}

$subtotal_combos_usd = 0;
foreach ($items_combos as $combo) {
    $combo_usd = floatval($combo['precio_total']);
    $subtotal_combos_usd += $combo_usd;
}

$subtotal_usd_total = $subtotal_usd + $subtotal_combos_usd;

// Convertir subtotal a la moneda del carrito
$subtotal = ($moneda_actual !== 'USD' && $tasa_actual > 0)
    ? $subtotal_usd_total * $tasa_actual
    : $subtotal_usd_total;

// ============================================
// CARGAR PASARELAS DESDE LA TABLA `pasarelas` (escalable)
// ============================================

// 1. Cargar pasarelas activas globalmente (admin)
$pasarelas_activas = [];
$stmt_pas = $conn->prepare("SELECT slug, nombre, tipo, icono, monedas, orden FROM pasarelas WHERE activo = 1 ORDER BY orden");
$stmt_pas->execute();
$res_pas = $stmt_pas->get_result();
while ($row = $res_pas->fetch_assoc()) {
    $pasarelas_activas[$row['slug']] = $row;
}
$stmt_pas->close();

// 2. Cargar activaciones del proveedor (si tiene)
$activaciones_proveedor = [];
$stmt_act = $conn->prepare("
    SELECT clave, valor 
    FROM configuracion 
    WHERE grupo = 'pagos' 
      AND proveedor_id = ? 
      AND clave LIKE '%_activo'
");
$stmt_act->bind_param("i", $proveedor_id);
$stmt_act->execute();
$res_act = $stmt_act->get_result();
while ($row = $res_act->fetch_assoc()) {
    $slug = str_replace('_activo', '', $row['clave']);
    $activaciones_proveedor[$slug] = $row['valor'];
}
$stmt_act->close();

// 3. Determinar si el proveedor tiene configuración propia
$total_metodos_proveedor = count(array_filter($activaciones_proveedor, function($v) { return $v == 1; }));
$proveedor_config_id = ($total_metodos_proveedor == 0) ? 0 : $proveedor_id;

// 4. Construir lista de métodos de pago filtrados
$metodos_pago = [];
foreach ($pasarelas_activas as $slug => $info) {
    // Verificar si el proveedor la tiene activa (o si no tiene config, usar la global)
    $esta_activa = false;
    
    if ($proveedor_config_id > 0) {
        // Proveedor tiene config propia → solo mostrar las que tiene activas
        $esta_activa = isset($activaciones_proveedor[$slug]) && $activaciones_proveedor[$slug] == 1;
    } else {
        // Proveedor sin config propia → usar la global
        $stmt_glob = $conn->prepare("SELECT valor FROM configuracion WHERE clave = ? AND grupo = 'pagos' AND proveedor_id = 0 LIMIT 1");
        $clave_activo = $slug . '_activo';
        $stmt_glob->bind_param("s", $clave_activo);
        $stmt_glob->execute();
        $res_glob = $stmt_glob->get_result()->fetch_assoc();
        $stmt_glob->close();
        $esta_activa = ($res_glob && $res_glob['valor'] == 1);
    }
    
    if (!$esta_activa) continue;
    
    // Filtrar por moneda del carrito
    $monedas_pasarela = !empty($info['monedas']) 
        ? array_map('trim', explode(',', $info['monedas'])) 
        : [];
    
    if (!empty($monedas_pasarela) && !in_array($moneda_actual, $monedas_pasarela)) {
        continue;
    }
    
    // Comisión (desde configuracion)
    $stmt_com = $conn->prepare("SELECT valor FROM configuracion WHERE clave = ? AND grupo = 'pagos' AND proveedor_id = ?");
    $clave_com = $slug . '_comision';
    $stmt_com->bind_param("si", $clave_com, $proveedor_config_id);
    $stmt_com->execute();
    $com_data = $stmt_com->get_result()->fetch_assoc();
    $stmt_com->close();
    
    $metodos_pago[] = [
        'pasarela' => $slug,
        'nombre' => $info['nombre'],
        'icono' => $info['icono'],
        'comision' => $com_data ? floatval($com_data['valor']) : 0
    ];
}

// Configuración de pago parcial
$stmt_parcial = $conn->prepare("SELECT clave, valor FROM configuracion WHERE clave IN ('pago_con_entrega_activo', 'porcentaje_con_entrega') AND grupo = 'general' AND proveedor_id = ?");
$stmt_parcial->bind_param("i", $proveedor_id);
$stmt_parcial->execute();
$config_parcial = $stmt_parcial->get_result();
$pago_parcial = [];
while ($row = $config_parcial->fetch_assoc()) { $pago_parcial[$row['clave']] = $row['valor']; }
$stmt_parcial->close();

if (empty($pago_parcial)) {
    $stmt_parcial_global = $conn->prepare("SELECT clave, valor FROM configuracion WHERE clave IN ('pago_con_entrega_activo', 'porcentaje_con_entrega') AND grupo = 'general' AND proveedor_id = 0");
    $stmt_parcial_global->execute();
    $config_parcial_global = $stmt_parcial_global->get_result();
    while ($row = $config_parcial_global->fetch_assoc()) { $pago_parcial[$row['clave']] = $row['valor']; }
    $stmt_parcial_global->close();
}

$pago_con_entrega_activo = ($pago_parcial['pago_con_entrega_activo'] ?? 0) == 1;
$porcentaje_entrega = floatval($pago_parcial['porcentaje_con_entrega'] ?? 100);
$porcentaje_ahora = 100 - $porcentaje_entrega;

// Configuración de pago anticipado (Pagar Todo)
$stmt_anticipado = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'pago_anticipado_activo' AND grupo = 'general' AND proveedor_id = ?");
$stmt_anticipado->bind_param("i", $proveedor_id);
$stmt_anticipado->execute();
$res_anticipado = $stmt_anticipado->get_result()->fetch_assoc();
$stmt_anticipado->close();

$pago_anticipado_activo = true; // default si no existe
if ($res_anticipado) {
    $pago_anticipado_activo = ($res_anticipado['valor'] == 1);
} else {
    $stmt_ant_global = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'pago_anticipado_activo' AND grupo = 'general' AND proveedor_id = 0");
    $stmt_ant_global->execute();
    $res_ant_global = $stmt_ant_global->get_result()->fetch_assoc();
    $stmt_ant_global->close();
    if ($res_ant_global) {
        $pago_anticipado_activo = ($res_ant_global['valor'] == 1);
    }
}

$aviso_sin_opciones_pago = (!$pago_anticipado_activo && !$pago_con_entrega_activo);

// Mensaje según configuración
$mensaje_pago = '';
if (!$pago_con_entrega_activo) {
    $mensaje_pago = "Realice el pago para que su pedido sea empacado y entregado";
} elseif ($porcentaje_entrega >= 100) {
    $mensaje_pago = "Decida si Pagara todo ahora -O- Pagara después de la entrega";
} else {
    $mensaje_pago = "Decida si Pagar todo ahora -O- Pagara el {$porcentaje_ahora}% ahora y el resto con la entrega";
}

if (function_exists('registrarEvento')) {
    registrarEvento($conn, 'iniciar_checkout');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
<title>Checkout - <?php echo htmlspecialchars($proveedor['nombre_tienda']); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', sans-serif; background: #f8fafc; min-height: 100vh; padding: 1rem; }
.checkout-container { max-width: 1200px; margin: 0 auto; }

.progress-bar { display: flex; align-items: center; justify-content: center; gap: 0; padding: 20px 10px; background: white; border-radius: 16px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 2rem; }
.progress-step { position: relative; display: flex; align-items: center; justify-content: center; width: 50px; height: 50px; border-radius: 50%; transition: all 0.5s ease; }
.progress-step .step-emoji { font-size: 24px; position: relative; z-index: 2; transition: all 0.5s ease; }
.progress-step.completed { background: #10b981; box-shadow: 0 0 20px rgba(16, 185, 129, 0.3); }
.progress-step.active { 
    background: #667eea; 
    box-shadow: 0 0 40px rgba(102, 126, 234, 0.9), 0 0 80px rgba(102, 126, 234, 0.6), 0 0 120px rgba(102, 126, 234, 0.4); 
    animation: pulse-glow 1.5s infinite; 
}
.progress-step.pending { 
    background: #e2e8f0; 
    opacity: 0.6; 
}
@keyframes pulse-glow { 
    0%, 100% { 
        box-shadow: 0 0 40px rgba(102, 126, 234, 0.9), 0 0 80px rgba(102, 126, 234, 0.6), 0 0 120px rgba(102, 126, 234, 0.4); 
        transform: scale(1.1);
    } 
    50% { 
        box-shadow: 0 0 60px rgba(102, 126, 234, 1), 0 0 120px rgba(102, 126, 234, 0.8), 0 0 180px rgba(102, 126, 234, 0.6); 
        transform: scale(0.65);
    } 
}
.progress-line { width: 60px; height: 3px; background: #e2e8f0; transition: background 0.5s ease; }
.progress-line.completed { background: #10b981; }

.checkout-grid { display: flex; flex-direction: column-reverse; gap: 1.5rem; }

.resumen-card { background: white; border-radius: 20px; padding: 1.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.05); order: 1; }
.resumen-card h2 { font-size: 1.2rem; color: #2d3748; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e2e8f0; }
.resumen-items { max-height: 350px; overflow-y: auto; margin-bottom: 1rem; }
.resumen-item { display: flex; gap: 0.8rem; padding: 0.8rem; border-bottom: 1px solid #edf2f7; align-items: center; }
.resumen-item:last-child { border-bottom: none; }
.resumen-item img { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; background: #f1f5f9; }
.resumen-item-info { flex: 1; }
.resumen-item-info h4 { font-size: 0.9rem; margin-bottom: 0.2rem; color: #2d3748; }
.resumen-item-info .cantidad { color: #718096; font-size: 0.8rem; }
.resumen-item-precio { font-weight: 600; color: #667eea; font-size: 0.9rem; white-space: nowrap; display: block; }

.resumen-detalle { 
    background: #f8fafc; 
    border-radius: 12px; 
    padding: 0.6rem 0.8rem; 
    margin-top: 0.8rem; 
    display: block; 
}
.resumen-detalle-linea { 
    display: flex; 
    justify-content: space-between; 
    margin: 0.1rem 0; 
    color: #4a5568; 
    font-size: 0.75rem; 
    line-height: 1.2; 
}
.resumen-detalle-linea span:first-child { 
    text-align: left; 
}
.resumen-detalle-linea span:last-child { 
    text-align: right; 
}
.resumen-detalle-total { 
    font-size: 0.85rem; 
    font-weight: 700; 
    color: #2d3748; 
    border-top: 1px solid #e2e8f0; 
    margin-top: 0.2rem; 
    padding-top: 0.2rem; 
}

.pasos-card { background: white; border-radius: 20px; padding: 1.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.05); order: 2; }
.paso h2 { font-size: 1.2rem; color: #2d3748; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #e2e8f0; }

.mensaje-pago { background: #f0f4ff; border: 1px solid #667eea; border-radius: 12px; padding: 0.8rem 1rem; margin-bottom: 1rem; font-size: 0.85rem; color: #4a5568; line-height: 1.4; }

.opciones-pago { display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem; }
.opcion-pago { display: flex; align-items: center; gap: 0.3rem; font-size: 0.75rem; color: #4a5568; cursor: pointer; padding: 0.3rem 0.6rem; border: 1px solid #e2e8f0; border-radius: 20px; transition: all 0.3s; }
.opcion-pago:hover { border-color: #667eea; }
.opcion-pago input[type="radio"] { width: 14px; height: 14px; accent-color: #667eea; cursor: pointer; }
.opcion-pago.selected { border-color: #667eea; background: #f0f4ff; }

.metodos-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.8rem; margin-bottom: 1rem; }
.metodo-item { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 1rem 0.5rem; border: 2px solid #e2e8f0; border-radius: 12px; cursor: pointer; transition: all 0.3s; text-align: center; background: white; }
.metodo-item:hover { border-color: #667eea; transform: translateY(-2px); }
.metodo-item.selected { border-color: #667eea; background: #f0f4ff; box-shadow: 0 0 15px rgba(102, 126, 234, 0.2); }
.metodo-item .icono {
    width: 100%;
    height: auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
    margin-bottom: 0;
}

.metodos-grid.deshabilitado .metodo-item {
    opacity: 0.4;
    cursor: not-allowed;
    pointer-events: none;
    filter: grayscale(1);
}

.metodo-item .icono img {
    width: 40px;
    height: 40px;
    object-fit: contain;
}

.metodo-item .icono .nombre {
    font-size: 0.6rem;
    font-weight: 600;
    color: #4a5568;
    text-align: center;
    line-height: 1.1;
    white-space: normal;
    word-break: break-word;
}

.datos-entrega-container { display: none; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 2px solid #e2e8f0; }
.datos-entrega-container.visible { display: block; }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.8rem; }
.form-group { margin-bottom: 0; }
.form-group.full-width { grid-column: span 2; }
.form-group label { display: block; font-size: 0.75rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.85rem; font-family: inherit; transition: border-color 0.3s; }
.form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline: none; border-color: #667eea; }

.btn-continuar { width: 100%; padding: 0.9rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 12px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: all 0.3s; margin-top: 1rem; }
.btn-continuar:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(102,126,234,0.4); }
.btn-continuar:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

@media (min-width: 768px) {
    body { padding: 2rem; }
    .checkout-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; }
    .resumen-card, .pasos-card { padding: 2rem; }
    .metodos-grid { grid-template-columns: repeat(4, 1fr); }
}
@media (min-width: 1024px) { .metodos-grid { grid-template-columns: repeat(6, 1fr); } }
@media (max-width: 767px) {
    .form-grid { grid-template-columns: 1fr; }
    .form-group.full-width { grid-column: span 1; }
    .progress-step { width: 40px; height: 40px; }
    .progress-step .step-emoji { font-size: 18px; }
    .progress-line { width: 30px; }
}
</style>
</head>
<body>
<div class="checkout-container">
    <div class="progress-bar">
        <div class="progress-step completed" id="step1"><span class="step-emoji">🛒</span></div>
        <div class="progress-line completed" id="line1"></div>
        <div class="progress-step active" id="step2"><span class="step-emoji">💳</span></div>
        <div class="progress-line" id="line2"></div>
        <div class="progress-step pending" id="step3"><span class="step-emoji">📍</span></div>
        <div class="progress-line" id="line3"></div>
        <div class="progress-step pending" id="step4"><span class="step-emoji">✅</span></div>
    </div>

    <div class="checkout-grid">
        <div class="resumen-card">
            <h2>🛍️ Tus productos</h2>
            <div class="resumen-items">
             <?php foreach ($items as $item): 
    // Convertir precio unitario a la moneda del carrito (usando tasa ya calculada)
    $precio_unitario_conv = ($moneda_actual !== 'USD' && $tasa_actual > 0)
        ? floatval($item['precio_unitario']) * $tasa_actual
        : floatval($item['precio_unitario']);
    $subtotal_item_conv = $precio_unitario_conv * intval($item['cantidad']);
?>
                <div class="resumen-item">
                    <img src="/<?php echo ltrim($item['imagen_url'], '/'); ?>" alt="<?php echo htmlspecialchars($item['nombre']); ?>">
                    <div class="resumen-item-info">
                        <h4><?php echo htmlspecialchars($item['nombre']); ?></h4>
                        <div class="cantidad">Cantidad: <?php echo $item['cantidad']; ?></div>
                    </div>
                    <div class="resumen-item-precio"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($subtotal_item_conv, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></div>
                </div>
                <?php endforeach; ?>
               <?php foreach ($items_combos as $combo): 
    $stmt_pc = $conn->prepare("SELECT COUNT(*) as total FROM combo_productos WHERE combo_id = ?");
    $stmt_pc->bind_param("i", $combo['combo_id']);
    $stmt_pc->execute();
    $tp = $stmt_pc->get_result()->fetch_assoc()['total'];
    $stmt_pc->close();
    
    // Convertir precio total del combo (usando tasa ya calculada)
    $precio_combo_conv = ($moneda_actual !== 'USD' && $tasa_actual > 0)
        ? floatval($combo['precio_total']) * $tasa_actual
        : floatval($combo['precio_total']);
?>
                <div class="resumen-item">
                    <img src="/<?php echo ltrim($combo['imagen_url'], '/'); ?>" alt="<?php echo htmlspecialchars($combo['nombre']); ?>">
                    <div class="resumen-item-info">
                        <h4>🎁 <?php echo htmlspecialchars($combo['nombre']); ?> (<?php echo $tp; ?>📦)</h4>
                        <div class="cantidad">Cantidad: <?php echo $combo['cantidad']; ?></div>
                    </div>
                    <div class="resumen-item-precio"><?php echo htmlspecialchars($moneda_simbolo); ?><?php echo number_format($precio_combo_conv, 2); ?> <?php echo htmlspecialchars($moneda_codigo); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
                        <div class="resumen-detalle" id="resumen_detalle">
    <div class="resumen-detalle-linea"><span>Productos:</span><span id="cliente_subtotal"><?php echo htmlspecialchars($moneda_simbolo); ?>0.00 <?php echo htmlspecialchars($moneda_codigo); ?></span></div>
    <div class="resumen-detalle-linea" id="envio_row"><span>Envío:</span><span id="cliente_envio" style="color: #718096; font-style: italic;">Seleccione la dirección de entrega</span></div>
    
    <!-- Fila: Total del pedido -->
    <div class="resumen-detalle-linea resumen-detalle-total" id="fila_total_pedido">
        <span>Total del pedido:</span>
        <span id="cliente_total"><?php echo htmlspecialchars($moneda_simbolo); ?>0.00 <?php echo htmlspecialchars($moneda_codigo); ?></span>
    </div>
    
    <!-- Separador visual (solo visible en parcial/entrega) -->
    <div id="separador_pago" style="display:none; border-top: 1px dashed #cbd5e0; margin: 0.6rem 0;"></div>
    
    <!-- Fila: Pagas ahora (solo parcial) -->
    <div class="resumen-detalle-linea" id="fila_pago_ahora" style="display:none; color: #10b981; font-weight: 600;">
        <span>💸 Pagas ahora (<span id="cliente_pago_ahora_pct">0</span>%):</span>
        <span id="cliente_pago_ahora"><?php echo htmlspecialchars($moneda_simbolo); ?>0.00 <?php echo htmlspecialchars($moneda_codigo); ?></span>
    </div>
    
    <!-- Fila: Pagas al recibir (parcial o entrega) -->
    <div class="resumen-detalle-linea" id="fila_pago_recibir" style="display:none; color: #ed8936; font-weight: 600;">
        <span>💵 Pagas al recibir:</span>
        <span id="cliente_pago_recibir"><?php echo htmlspecialchars($moneda_simbolo); ?>0.00 <?php echo htmlspecialchars($moneda_codigo); ?></span>
    </div>
</div>
        </div>

        <div class="pasos-card">
            <div class="paso" id="paso2">
                <h2>💳 Selecciona método de pago</h2>
                <div class="mensaje-pago"><?php echo htmlspecialchars($mensaje_pago); ?></div>
                                <?php if (!empty($aviso_sin_opciones_pago)): ?>
                <div style="background:#fff5f5;border:2px solid #fc8181;border-radius:12px;padding:1rem;margin-bottom:1rem;color:#c53030;font-size:0.9rem;text-align:center;line-height:1.5;">
                    ⚠️ <strong>Configuración incompleta.</strong><br>
                    El proveedor debe activar al menos una opción de pago (Pago Anticipado o Pago con Entrega).
                </div>
                <?php endif; ?>
                               <?php if ($pago_con_entrega_activo || $pago_anticipado_activo): ?>
                <div class="opciones-pago" id="opciones_pago">
                    <?php if ($pago_anticipado_activo): ?>
                    <label class="opcion-pago <?php echo ($pago_anticipado_activo && !$pago_con_entrega_activo) ? 'selected' : ''; ?>" onclick="seleccionarOpcion('todo', this)">
                        <input type="radio" name="opcion_pago" value="todo" <?php echo ($pago_anticipado_activo && !$pago_con_entrega_activo) ? 'checked' : ''; ?>> Pagar Todo
                    </label>
                    <?php endif; ?>
                    <?php if ($pago_con_entrega_activo): ?>
                        <?php if ($porcentaje_entrega >= 100): ?>
                        <label class="opcion-pago <?php echo (!$pago_anticipado_activo) ? 'selected' : ''; ?>" onclick="seleccionarOpcion('entrega', this)">
                            <input type="radio" name="opcion_pago" value="entrega" <?php echo (!$pago_anticipado_activo) ? 'checked' : ''; ?>> Pagar con la Entrega
                        </label>
                        <?php else: ?>
                        <label class="opcion-pago <?php echo (!$pago_anticipado_activo) ? 'selected' : ''; ?>" onclick="seleccionarOpcion('parcial', this)">
                            <input type="radio" name="opcion_pago" value="parcial" <?php echo (!$pago_anticipado_activo) ? 'checked' : ''; ?>> Pagar <?php echo $porcentaje_ahora; ?>% y el resto con la Entrega
                        </label>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Texto indicativo encima de las pasarelas -->
                <div style="text-align: center; margin: 1rem 0 0.6rem 0; font-size: 0.85rem; color: #475569; font-weight: 500;">
                    👇 Toca el botón de la pasarela por la que deseas pagar
                </div>

                                <div class="metodos-grid" id="metodos_grid">
    <?php foreach ($metodos_pago as $metodo): ?>
    <div class="metodo-item" onclick="seleccionarMetodo('<?php echo $metodo['pasarela']; ?>', <?php echo $metodo['comision']; ?>, this)">
        <span class="icono">
            <?php 
    // Usar el icono guardado en la tabla pasarelas (ruta completa)
    if (!empty($metodo['icono'])) {
        $ruta_fisica = $_SERVER['DOCUMENT_ROOT'] . $metodo['icono'];
        if (file_exists($ruta_fisica)) {
            echo '<img src="' . htmlspecialchars($metodo['icono']) . '" alt="' . htmlspecialchars($metodo['nombre']) . '">';
        } else {
            // Fallback: emoji genérico
            echo '<span style="font-size: 1.8rem;">💰</span>';
        }
    } else {
        // Fallback: emoji genérico
        echo '<span style="font-size: 1.8rem;">💰</span>';
    }
?>
            <span class="nombre"><?php echo htmlspecialchars($metodo['nombre']); ?></span>
        </span>
    </div>
    <?php endforeach; ?>
    <?php if (empty($metodos_pago)): ?>
    <div style="grid-column: 1 / -1; background:#fff5f5;border:1px solid #fc8181;border-radius:12px;padding:1.2rem;color:#c53030;font-size:0.9rem;text-align:center;line-height:1.5;">
        ⚠️ <strong>No hay métodos de pago disponibles</strong> para la moneda <strong><?php echo htmlspecialchars($moneda_codigo); ?></strong> en esta tienda.<br>
        Por favor contacta al proveedor o intenta con otra moneda.
    </div>
    <?php endif; ?>
</div>

                <div class="datos-entrega-container" id="datos_entrega_container">
                    <h3 style="font-size:1rem; color:#2d3748; margin-bottom:1rem;">📍 Datos de entrega</h3>
                    <div class="form-grid">
  <div class="form-group full-width">
    <label>Nombre *</label>
    <input type="text" id="entrega_nombre" required placeholder="Nombre y apellidos" value="<?php echo htmlspecialchars($ultima_direccion['nombre_completo'] ?? ''); ?>">
</div>
<div class="form-group">
    <label>Teléfono *</label>
    <input type="tel" id="entrega_telefono" required placeholder="Ej: 55551234" value="<?php echo htmlspecialchars($ultima_direccion['telefono'] ?? ''); ?>">
</div>
<div class="form-group">
    <label>Email (opcional)</label>
    <input type="email" id="entrega_email" placeholder="correo@ejemplo.com" value="<?php echo htmlspecialchars($ultima_direccion['email'] ?? ''); ?>">
</div>
 <div class="form-group">
    <label>Provincia *</label>
    <select id="entrega_provincia" required>
        <option value="" disabled <?php echo !$ultima_provincia_id ? 'selected' : ''; ?>>Seleccione provincia</option>
        <?php 
        $sql_provincias = "
            SELECT DISTINCT p.id, p.nombre
            FROM provincias p
            INNER JOIN municipios m ON m.provincia_id = p.id AND m.activo = 1
            INNER JOIN proveedor_envio_config pec ON pec.municipio_id = m.id 
                AND pec.proveedor_id = ? 
                AND pec.activo = 1
            WHERE p.activo = 1
            ORDER BY p.nombre
        ";
        $stmt_provincias = $conn->prepare($sql_provincias);
        $stmt_provincias->bind_param("i", $proveedor_id);
        $stmt_provincias->execute();
        $provincias = $stmt_provincias->get_result();
        $stmt_provincias->close();
        
        while($prov = $provincias->fetch_assoc()): 
            $selected = ($ultima_provincia_id == $prov['id']) ? 'selected' : '';
        ?>
        <option value="<?php echo $prov['id']; ?>" <?php echo $selected; ?>><?php echo htmlspecialchars($prov['nombre']); ?></option>
        <?php endwhile; ?>
    </select>
</div>
                        <div class="form-group">
    <label>Municipio *</label>
    <select id="entrega_municipio" required data-ultimo="<?php echo htmlspecialchars($ultima_direccion['municipio'] ?? ''); ?>">
        <option value="">Seleccione primero provincia</option>
    </select>
</div>
                        <div class="form-group full-width">
    <label>Dirección *</label>
    <input type="text" id="entrega_direccion" required placeholder="Calle, número, reparto" value="<?php echo htmlspecialchars($ultima_direccion['direccion'] ?? ''); ?>">
</div>
<div class="form-group full-width">
    <label>Instrucciones (opcional)</label>
    <textarea id="entrega_instrucciones" rows="2" placeholder="Ej: Entregar en piso 3..."><?php echo htmlspecialchars($ultima_direccion['instrucciones'] ?? ''); ?></textarea>
</div>
                    </div>
                    <button type="button" class="btn-continuar" onclick="completarPago()">COMPLETAR PAGO</button>
                </div>
            </div>

            <div class="paso" id="paso4" style="display:none;">
                <h2>✅ Confirmar Pedido</h2>
                <div id="resumen_confirmacion"></div>
                <form id="formPagoFinal" onsubmit="return enviarPedido(event)">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <input type="hidden" name="carrito_id" value="<?php echo $carrito['id']; ?>">
                    <input type="hidden" name="metodo_pago" id="hidden_metodo_pago" value="">
                    <input type="hidden" name="opcion_pago" id="hidden_opcion_pago" value="todo">
                    <input type="hidden" name="costo_envio" id="hidden_costo_envio" value="0">
                    <input type="hidden" name="nombre_entrega" id="hidden_nombre" value="">
                    <input type="hidden" name="documento_entrega" value="000000">
                    <input type="hidden" name="telefono_entrega" id="hidden_telefono" value="">
                    <input type="hidden" name="direccion_entrega" id="hidden_direccion" value="">
                    <input type="hidden" name="municipio_entrega" id="hidden_municipio" value="">
                    <input type="hidden" name="provincia_entrega" id="hidden_provincia" value="">
                    <input type="hidden" name="email_entrega" id="hidden_email" value="">
                    <input type="hidden" name="instrucciones" id="hidden_instrucciones" value="">
                    <button type="submit" class="btn-continuar">💳 REALIZAR PEDIDO</button>
                </form>
            </div>
               </div>
    </div>
</div>

<!-- BOTÓN VOLVER A LA TIENDA -->
<div style="text-align: center; margin: 1.5rem 0;">
    <a href="/index.php?proveedor=<?php echo urlencode($proveedor['slug']); ?>&registrar_visita=1" style="
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.8rem 1.5rem;
        background: white;
        color: #4a5568;
        text-decoration: none;
        border-radius: 30px;
        font-weight: 600;
        font-size: 0.9rem;
        border: 2px solid #e2e8f0;
        transition: all 0.3s;
    " onmouseover="this.style.borderColor='#667eea'; this.style.color='#667eea';" onmouseout="this.style.borderColor='#e2e8f0'; this.style.color='#4a5568';">
        ← Seguir comprando
    </a>
</div>

<script>
let metodoSeleccionado = '';
let comisionPorcentaje = 0;
let subtotalBase = <?php echo $subtotal; ?>;
let costoEnvio = 0;
let proveedorId = <?php echo $proveedor_id; ?>;
let opcionPago = '<?php 
    if ($pago_anticipado_activo && $pago_con_entrega_activo) {
        echo 'todo'; // ambos activos → por defecto Pagar Todo
    } elseif ($pago_anticipado_activo) {
        echo 'todo'; // solo anticipado
    } elseif ($pago_con_entrega_activo) {
        echo ($porcentaje_entrega >= 100) ? 'entrega' : 'parcial';
    } else {
        echo 'todo'; // fallback (aviso ya se muestra)
    }
?>';
let pagoConEntregaActivo = <?php echo $pago_con_entrega_activo ? 'true' : 'false'; ?>;
let porcentajeEntrega = <?php echo $porcentaje_entrega; ?>;
let porcentajeAhora = <?php echo $porcentaje_ahora; ?>;

const simbolo = '<?php echo htmlspecialchars($moneda_simbolo); ?>';
const codigo = '<?php echo htmlspecialchars($moneda_codigo); ?>';
const nombreTienda = '<?php echo addslashes($proveedor['nombre_tienda']); ?>';

function seleccionarOpcion(opcion, element) {
    document.querySelectorAll('.opcion-pago').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    element.querySelector('input[type="radio"]').checked = true;
    opcionPago = opcion;
    actualizarTotales();
    actualizarEstadoPasarelas(); // ← NUEVO
}

function actualizarEstadoPasarelas() {
    const hayOpcionSeleccionada = document.querySelector('input[name="opcion_pago"]:checked') !== null;
    const grid = document.getElementById('metodos_grid');
    if (grid) {
        if (hayOpcionSeleccionada) {
            grid.classList.remove('deshabilitado');
        } else {
            grid.classList.add('deshabilitado');
        }
    }
}

function seleccionarMetodo(pasarela, comision, element) {
    if (!document.querySelector('input[name="opcion_pago"]:checked')) {
        return; // no hay opción seleccionada → no permitir
    }
    
    document.querySelectorAll('.metodo-item').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
    metodoSeleccionado = pasarela;
    comisionPorcentaje = comision;
    document.getElementById('datos_entrega_container').classList.add('visible');
    
    // ✅ Actualizar barra de progreso
    document.getElementById('step2').classList.remove('active');
    document.getElementById('step2').classList.add('completed');
    document.getElementById('line2').classList.add('completed');
    document.getElementById('step3').classList.remove('pending');
    document.getElementById('step3').classList.add('active');
    
    actualizarTotales();
}

function actualizarTotales() {
    // ============================================
    // CALCULAR Y MOSTRAR IMPORTES (SIN COMISIÓN)
    // Siempre visibles desde el inicio
    // ============================================
    let base = subtotalBase + costoEnvio;
    let total = base;
    let productosVisible = total - costoEnvio;
    
    // Mostrar el contenedor de totales (siempre visible)
    document.getElementById('resumen_detalle').style.display = 'block';
    
    // ============================================
    // CALCULAR MONTOS SEGÚN OPCIÓN DE PAGO
    // ============================================
    let totalAhora = total;
    let totalRecibir = 0;
    
    if (opcionPago === 'entrega') {
        totalAhora = 0;
        totalRecibir = total;
    } else if (opcionPago === 'parcial') {
        totalAhora = total * ((100 - porcentajeEntrega) / 100);
        totalRecibir = total * (porcentajeEntrega / 100);
    }
    
    // Actualizar valores base
    document.getElementById('cliente_subtotal').textContent = simbolo + productosVisible.toFixed(2) + ' ' + codigo;
    
        // Mostrar u ocultar filas según opción
    const filaAhora = document.getElementById('fila_pago_ahora');
    const filaRecibir = document.getElementById('fila_pago_recibir');
    const filaTotal = document.getElementById('fila_total_pedido');
    const separador = document.getElementById('separador_pago');
    
    if (opcionPago === 'todo') {
        // Pagar Todo: solo total, sin separador
        if (filaAhora) filaAhora.style.display = 'none';
        if (filaRecibir) filaRecibir.style.display = 'none';
        if (filaTotal) {
            filaTotal.style.display = 'flex';
            document.getElementById('cliente_total').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
        if (separador) separador.style.display = 'none';
    } else if (opcionPago === 'parcial') {
        // Parcial: total + separador + pagas ahora + pagas al recibir
        if (filaTotal) {
            filaTotal.style.display = 'flex';
            document.getElementById('cliente_total').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
        if (separador) separador.style.display = 'block';
        if (filaAhora) {
            filaAhora.style.display = 'flex';
            document.getElementById('cliente_pago_ahora_pct').textContent = porcentajeAhora;
            document.getElementById('cliente_pago_ahora').textContent = simbolo + totalAhora.toFixed(2) + ' ' + codigo;
        }
        if (filaRecibir) {
            filaRecibir.style.display = 'flex';
            document.getElementById('cliente_pago_recibir').textContent = simbolo + totalRecibir.toFixed(2) + ' ' + codigo;
        }
    } else if (opcionPago === 'entrega') {
        // Entrega: total + separador + pagas al recibir
        if (filaTotal) {
            filaTotal.style.display = 'flex';
            document.getElementById('cliente_total').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
        if (separador) separador.style.display = 'block';
        if (filaAhora) filaAhora.style.display = 'none';
        if (filaRecibir) {
            filaRecibir.style.display = 'flex';
            document.getElementById('cliente_pago_recibir').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
    }
    
    // El envío ya se maneja en el evento change del municipio.
// No hace falta tocar aquí.
}

document.getElementById('entrega_provincia').addEventListener('change', function() {
    const provinciaId = this.value;
    const municipioSelect = document.getElementById('entrega_municipio');
    
    if (!provinciaId) { 
        municipioSelect.innerHTML = '<option value="">Seleccione primero provincia</option>'; 
        return; 
    }
    
    municipioSelect.innerHTML = '<option value="">Cargando...</option>';
    
    fetch('/includes/obtener_municipios_ajax.php?provincia_id=' + provinciaId + '&proveedor_id=' + proveedorId)
        .then(r => r.json())
        .then(data => {
            municipioSelect.innerHTML = '<option value="" disabled selected>Seleccione municipio</option>';
            data.forEach(mun => {
    const opt = document.createElement('option');
    opt.value = mun.municipio;
    // ✅ Mostrar nombre + envío desde el principio
    opt.textContent = mun.municipio + ' - Envío: ' + simbolo + parseFloat(mun.costo).toFixed(1) + ' ' + codigo;
    opt.setAttribute('data-costo', mun.costo);
    municipioSelect.appendChild(opt);
});
        })
        .catch(() => { 
            municipioSelect.innerHTML = '<option value="">Error al cargar</option>'; 
        });
});

document.getElementById('entrega_municipio').addEventListener('change', function() {
    const envioElement = document.getElementById('cliente_envio');
    
    if (this.selectedIndex > 0) {
        // Municipio seleccionado → mostrar importe real
        costoEnvio = parseFloat(this.options[this.selectedIndex].dataset.costo || 0);
        
        if (envioElement) {
            envioElement.textContent = simbolo + costoEnvio.toFixed(2) + ' ' + codigo;
            envioElement.style.color = '#4a5568';
            envioElement.style.fontStyle = 'normal';
        }
    } else {
        // Sin municipio → mostrar placeholder
        costoEnvio = 0;
        
        if (envioElement) {
            envioElement.textContent = 'Seleccione la dirección de entrega';
            envioElement.style.color = '#718096';
            envioElement.style.fontStyle = 'italic';
        }
    }
    actualizarTotales();
});

function completarPago() {
    const nombre = document.getElementById('entrega_nombre').value.trim();
    const telefono = document.getElementById('entrega_telefono').value.trim();
    const direccion = document.getElementById('entrega_direccion').value.trim();
    const provincia = document.getElementById('entrega_provincia').value;
    const municipio = document.getElementById('entrega_municipio').value;
    const email = document.getElementById('entrega_email').value.trim();
    const instrucciones = document.getElementById('entrega_instrucciones').value.trim();
    
    if (!nombre || !telefono || !direccion || !provincia || !municipio) { alert('Completa todos los campos obligatorios'); return; }
    if (!metodoSeleccionado) { alert('Selecciona un método de pago'); return; }
    
    const provinciaNombre = document.getElementById('entrega_provincia').options[document.getElementById('entrega_provincia').selectedIndex].text;
    
    document.getElementById('hidden_metodo_pago').value = metodoSeleccionado;
    document.getElementById('hidden_opcion_pago').value = opcionPago;
    document.getElementById('hidden_costo_envio').value = costoEnvio;
    document.getElementById('hidden_nombre').value = nombre;
    document.getElementById('hidden_telefono').value = telefono;
    document.getElementById('hidden_direccion').value = direccion;
    document.getElementById('hidden_municipio').value = municipio;
    document.getElementById('hidden_provincia').value = provinciaNombre;
    document.getElementById('hidden_email').value = email;
    document.getElementById('hidden_instrucciones').value = instrucciones;
    
    let base = subtotalBase + costoEnvio;
    let total = base;  // ← SIN comisión
    let productosVisible = total - costoEnvio;
    
    // Calcular montos según opción
    let totalAhora = total;
    let totalRecibir = 0;
    
    if (opcionPago === 'entrega') {
        totalAhora = 0;
        totalRecibir = total;
    } else if (opcionPago === 'parcial') {
        totalAhora = total * ((100 - porcentajeEntrega) / 100);
        totalRecibir = total * (porcentajeEntrega / 100);
    }
    
    document.querySelectorAll('.resumen-item-precio').forEach(el => el.style.display = 'block');
    document.getElementById('resumen_detalle').style.display = 'block';
    document.getElementById('cliente_subtotal').textContent = simbolo + productosVisible.toFixed(2) + ' ' + codigo;
    document.getElementById('cliente_total').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
    
        // Actualizar filas dinámicas
    const filaAhora = document.getElementById('fila_pago_ahora');
    const filaRecibir = document.getElementById('fila_pago_recibir');
    const filaTotal = document.getElementById('fila_total_pedido');
    const separador = document.getElementById('separador_pago');
    
    if (opcionPago === 'todo') {
        if (filaAhora) filaAhora.style.display = 'none';
        if (filaRecibir) filaRecibir.style.display = 'none';
        if (filaTotal) {
            filaTotal.style.display = 'flex';
            document.getElementById('cliente_total').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
        if (separador) separador.style.display = 'none';
    } else if (opcionPago === 'parcial') {
        if (filaTotal) {
            filaTotal.style.display = 'flex';
            document.getElementById('cliente_total').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
        if (separador) separador.style.display = 'block';
        if (filaAhora) {
            filaAhora.style.display = 'flex';
            document.getElementById('cliente_pago_ahora_pct').textContent = porcentajeAhora;
            document.getElementById('cliente_pago_ahora').textContent = simbolo + totalAhora.toFixed(2) + ' ' + codigo;
        }
        if (filaRecibir) {
            filaRecibir.style.display = 'flex';
            document.getElementById('cliente_pago_recibir').textContent = simbolo + totalRecibir.toFixed(2) + ' ' + codigo;
        }
    } else if (opcionPago === 'entrega') {
        if (filaTotal) {
            filaTotal.style.display = 'flex';
            document.getElementById('cliente_total').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
        if (separador) separador.style.display = 'block';
        if (filaAhora) filaAhora.style.display = 'none';
        if (filaRecibir) {
            filaRecibir.style.display = 'flex';
            document.getElementById('cliente_pago_recibir').textContent = simbolo + total.toFixed(2) + ' ' + codigo;
        }
    }    
    if (costoEnvio > 0) {
        document.getElementById('envio_row').style.display = 'flex';
        document.getElementById('cliente_envio').textContent = simbolo + costoEnvio.toFixed(2) + ' ' + codigo;
    }
    
    // ============================================
    // RESUMEN DE CONFIRMACIÓN (con desglose)
    // ============================================
    let desglosePago = '';
    
    if (opcionPago === 'todo') {
        desglosePago = `<p><strong>Total a pagar ahora:</strong> ${simbolo}${total.toFixed(2)} ${codigo}</p>`;
    } else if (opcionPago === 'parcial') {
        desglosePago = `
            <p style="color: #10b981;"><strong>Pagas ahora (${porcentajeAhora}%):</strong> ${simbolo}${totalAhora.toFixed(2)} ${codigo}</p>
            <p style="color: #ed8936;"><strong>Pagas al recibir (${porcentajeEntrega}%):</strong> ${simbolo}${totalRecibir.toFixed(2)} ${codigo}</p>
            <p><strong>Total del pedido:</strong> ${simbolo}${total.toFixed(2)} ${codigo}</p>
        `;
    } else if (opcionPago === 'entrega') {
        desglosePago = `<p style="color: #ed8936;"><strong>Pagas al recibir:</strong> ${simbolo}${total.toFixed(2)} ${codigo}</p>`;
    }
    
       // ============================================
    // TEXTO ESPECIAL PARA ZELLE CON PAGO ADELANTADO
    // ============================================
    let textoZelle = '';
    if (metodoSeleccionado === 'zelle' && (opcionPago === 'todo' || opcionPago === 'parcial')) {
        textoZelle = `
            <div style="background:#fffaf0;border:1px solid #ed8936;border-radius:8px;padding:0.7rem 0.9rem;margin:0.6rem 0;font-size:0.85rem;color:#744210;line-height:1.4;">
                📩 Nos comunicaremos con usted para darle las instrucciones de pago.
            </div>
        `;
    }

    let resumenHTML = `
        <h3 style="font-size:1rem; color:#2d3748; margin-bottom:0.6rem;">📍 Datos de Entrega</h3>
        <div style="background:#f0fff4;border:1px solid #48bb78;border-radius:12px;padding:1rem;margin-bottom:1rem;">
            <p><strong>${nombre}</strong></p>
            <p>${direccion}, ${municipio}, ${provinciaNombre}</p>
            <p>📞 ${telefono}</p>
            ${email ? '<p>✉️ ' + email + '</p>' : ''}
            ${instrucciones ? '<p>📝 ' + instrucciones + '</p>' : ''}
        </div>
        <div style="background:#f8fafc;border-radius:12px;padding:1rem;margin-bottom:1rem;">
            <p><strong>Método de pago:</strong> ${metodoSeleccionado}</p>
            <p><strong>Opción:</strong> ${opcionPago === 'todo' ? 'Pagar Todo' : opcionPago === 'entrega' ? 'Pagar con la Entrega' : 'Pagar ' + porcentajeAhora + '% y el resto con la Entrega'}</p>
            ${textoZelle}
            <hr style="margin: 0.8rem 0; border: none; border-top: 1px dashed #cbd5e0;">
            ${desglosePago}
            <div style="text-align: center; margin-top: 0.8rem; font-size: 0.85rem; color: #4a5568;">
                ¡Gracias por comprar en <strong>${nombreTienda}</strong>!
            </div>
        </div>
    `;
    document.getElementById('resumen_confirmacion').innerHTML = resumenHTML;
    
    document.getElementById('paso2').style.display = 'none';
    document.getElementById('paso4').style.display = 'block';
    
    document.getElementById('step2').classList.remove('active');
document.getElementById('step2').classList.add('completed');
document.getElementById('line2').classList.add('completed');
document.getElementById('step3').classList.remove('active');
document.getElementById('step3').classList.remove('pending');
document.getElementById('step3').classList.add('completed');
document.getElementById('line3').classList.add('completed');
document.getElementById('step4').classList.remove('pending');
document.getElementById('step4').classList.add('active');
}

// ============================================
// CARGAR ÚLTIMA DIRECCIÓN AL INICIO
// ============================================
document.addEventListener('DOMContentLoaded', function() {
actualizarEstadoPasarelas();

    // ============================================
// MOSTRAR IMPORTES DESDE EL INICIO (SIN COMISIÓN)
// ============================================
const subtotalElement = document.getElementById('cliente_subtotal');
if (subtotalElement) {
    subtotalElement.textContent = simbolo + subtotalBase.toFixed(2) + ' ' + codigo;
}

const totalElement = document.getElementById('cliente_total');
if (totalElement) {
    totalElement.textContent = simbolo + subtotalBase.toFixed(2) + ' ' + codigo;
}

const filaTotal = document.getElementById('fila_total_pedido');
if (filaTotal) {
    filaTotal.style.display = 'flex';
}

// Mostrar el desglose de importes
const resumenDetalle = document.getElementById('resumen_detalle');
if (resumenDetalle) {
    resumenDetalle.style.display = 'block';
}

// Mostrar precios de cada producto
document.querySelectorAll('.resumen-item-precio').forEach(el => {
    el.style.display = 'block';
});

// ============================================
// TEXTO INICIAL DE ENVÍO (placeholder)
// ============================================
const envioElement = document.getElementById('cliente_envio');
if (envioElement) {
    envioElement.textContent = 'Seleccione la dirección de entrega';
    envioElement.style.color = '#718096';
    envioElement.style.fontStyle = 'italic';
}
    
    // ============================================
    // CARGAR ÚLTIMA DIRECCIÓN (código existente)
    // ============================================
    const provinciaSelect = document.getElementById('entrega_provincia');
    const municipioSelect = document.getElementById('entrega_municipio');
    
    <?php if ($ultima_provincia_id): ?>
    if (provinciaSelect.value) {
        const provinciaId = provinciaSelect.value;
        const ultimoMunicipio = municipioSelect.dataset.ultimo;
        
        fetch('/includes/obtener_municipios_ajax.php?provincia_id=' + provinciaId + '&proveedor_id=' + proveedorId)
            .then(r => r.json())
            .then(data => {
                municipioSelect.innerHTML = '<option value="">Seleccione municipio</option>';
                data.forEach(mun => {
                    const opt = document.createElement('option');
                    opt.value = mun.municipio;
                    opt.textContent = mun.municipio + ' - Envío: ' + simbolo + parseFloat(mun.costo).toFixed(1) + ' ' + codigo;
                    opt.setAttribute('data-costo', mun.costo);
                    if (mun.municipio === ultimoMunicipio) {
                        opt.selected = true;
                    }
                    municipioSelect.appendChild(opt);
                });
                
                if (municipioSelect.selectedIndex > 0) {
                    costoEnvio = parseFloat(municipioSelect.options[municipioSelect.selectedIndex].dataset.costo || 0);
                    actualizarTotales();
                }
            })
            .catch(() => {});
    }
    <?php endif; ?>
});

async function enviarPedido(e) {
    e.preventDefault();
    const formData = new FormData(document.getElementById('formPagoFinal'));

    const resp = await fetch('/checkout/procesar_pago.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    });

    const texto = await resp.text();
    let data;
    try {
        data = JSON.parse(texto);
    } catch (err) {
        console.error('Respuesta no-JSON:', texto);
        alert('Error inesperado del servidor.');
        return false;
    }

    if (!data.success) {
        alert(data.mensaje || 'Error al procesar el pedido');
        return false;
    }

    const f = document.createElement('form');
    f.method = 'POST';
    f.action = data.redirect;
    f.innerHTML = `
        <input type="hidden" name="csrf_token" value="${data.csrf_token}">
        <input type="hidden" name="pedido_id" value="${data.pedido_id}">
        <input type="hidden" name="metodo_pago" value="${data.metodo_pago}">
    `;
    document.body.appendChild(f);
    f.submit();
    return false;
}
</script>
</body>
</html>
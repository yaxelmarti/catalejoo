﻿<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Handler global: cualquier exception → JSON limpio, nunca HTML
set_exception_handler(function ($e) {
    error_log('[procesar_pago] EXCEPTION: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        header('Content-Type: application/json');
        http_response_code(500);
    }
    echo json_encode(['success' => false, 'mensaje' => 'Error interno del servidor']);
    exit;
});

// Handler de errores PHP: solo log, nunca imprimir
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    error_log("[procesar_pago] ERROR [$errno] $errstr @ $errfile:$errline");
    return true;
});

// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();
require_once dirname(__DIR__) . '/conexion.php';
require_once dirname(__DIR__) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__) . '/includes/carrito_funciones.php';
require_once dirname(__DIR__) . '/includes/proveedor_utils.php';
require_once dirname(__DIR__) . '/includes/moneda_funciones.php';

header('Content-Type: application/json');

// Helper para respuestas JSON consistentes
function responder($ok, $datos = []) {
    echo json_encode(array_merge(['success' => $ok], $datos), JSON_UNESCAPED_UNICODE);
    exit;
}

// ===== VALIDAR TOKEN CSRF =====
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    responder(false, ['mensaje' => 'Token de seguridad inválido']);
}

// Función para generar código de pedido: YYMMDD-0001
function generarCodigoPedido($conn) {
    $fecha = date('ymd');
    $prefijo = $fecha . '-';
    
    $stmt = $conn->prepare("SELECT codigo FROM pedidos WHERE codigo LIKE ? ORDER BY codigo DESC LIMIT 1");
    $like = $prefijo . '%';
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $ultimo = $result->fetch_assoc()['codigo'];
        $numero = intval(substr($ultimo, -4)) + 1;
        $nuevo_numero = str_pad($numero, 4, '0', STR_PAD_LEFT);
        $stmt->close();
        return $prefijo . $nuevo_numero;
    }
    $stmt->close();
    return $prefijo . '0001';
}

// Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'];

if ($cliente_id == 0) {
    responder(false, ['mensaje' => 'Cliente no identificado']);
}

// Recibir datos del formulario
$carrito_id = intval($_POST['carrito_id'] ?? 0);
$metodo_pago = $_POST['metodo_pago'] ?? '';
$costo_envio = floatval($_POST['costo_envio'] ?? 0);
$opcion_pago = $_POST['opcion_pago'] ?? 'todo';

// Validar costo de envío
if ($costo_envio < 0) {
    responder(false, ['mensaje' => 'Costo de envío inválido']);
}

// Datos de entrega
$nombre_entrega = trim($_POST['nombre_entrega'] ?? '');
$documento_entrega = trim($_POST['documento_entrega'] ?? '');
$direccion_entrega = trim($_POST['direccion_entrega'] ?? '');
$municipio_entrega = trim($_POST['municipio_entrega'] ?? '');
$provincia_entrega = trim($_POST['provincia_entrega'] ?? 'Villa Clara');
$telefono_entrega = trim($_POST['telefono_entrega'] ?? '');
$email_entrega = trim($_POST['email_entrega'] ?? '');
$instrucciones = trim($_POST['instrucciones'] ?? '');

// Validaciones básicas
if (empty($metodo_pago)) {
    responder(false, ['mensaje' => 'Debe seleccionar un método de pago']);
}

if (empty($nombre_entrega) || empty($direccion_entrega) || empty($municipio_entrega) || empty($telefono_entrega)) {
    responder(false, ['mensaje' => 'Complete todos los campos obligatorios de entrega']);
}

// Verificar que el carrito existe y pertenece al cliente
$stmt = $conn->prepare("SELECT * FROM carritos WHERE id = ? AND cliente_id = ?");
$stmt->bind_param("ii", $carrito_id, $cliente_id);
$stmt->execute();
$carrito = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$carrito) {
    responder(false, ['mensaje' => 'Carrito no válido']);
}

// ===== DETECTAR PROVEEDOR DEL CARRITO =====
$proveedor_id = $carrito['proveedor_id'] ?? 0;

if ($proveedor_id == 0) {
    responder(false, ['mensaje' => 'El carrito no tiene un proveedor asignado']);
}

// Validar que el proveedor existe y está activo
$stmt_prov = $conn->prepare("SELECT id, nombre_tienda, email, email_ventas FROM proveedores WHERE id = ? AND activo = 1");
$stmt_prov->bind_param("i", $proveedor_id);
$stmt_prov->execute();
$proveedor = $stmt_prov->get_result()->fetch_assoc();
$stmt_prov->close();

if (!$proveedor) {
    responder(false, ['mensaje' => 'La tienda no está disponible']);
}

// ============================================
// CARGAR PASARELAS DESDE LA TABLA `pasarelas` (escalable)
// ============================================
$pasarelas_activas = [];
$stmt_pas = $conn->prepare("SELECT slug, nombre, tipo, monedas FROM pasarelas WHERE activo = 1");
$stmt_pas->execute();
$res_pas = $stmt_pas->get_result();
while ($row = $res_pas->fetch_assoc()) {
    $pasarelas_activas[$row['slug']] = $row;
}
$stmt_pas->close();

// ===== VALIDAR QUE EL CARRITO TENGA PRODUCTOS O COMBOS =====
$stmt_check = $conn->prepare("SELECT COUNT(*) as total FROM carrito_productos WHERE carrito_id = ?");
$stmt_check->bind_param("i", $carrito_id);
$stmt_check->execute();
$total_productos = $stmt_check->get_result()->fetch_assoc()['total'];
$stmt_check->close();

$stmt_check_combo = $conn->prepare("SELECT COUNT(*) as total FROM carrito_combos WHERE carrito_id = ?");
$stmt_check_combo->bind_param("i", $carrito_id);
$stmt_check_combo->execute();
$total_combos = $stmt_check_combo->get_result()->fetch_assoc()['total'];
$stmt_check_combo->close();

if ($total_productos == 0 && $total_combos == 0) {
    responder(false, ['mensaje' => 'El carrito está vacío']);
}

// ===== VALIDAR STOCK DE PRODUCTOS =====
$stmt_stock = $conn->prepare("SELECT cp.producto_id, cp.cantidad, p.cantidad as stock 
                              FROM carrito_productos cp 
                              JOIN productos p ON cp.producto_id = p.id 
                              WHERE cp.carrito_id = ?");
$stmt_stock->bind_param("i", $carrito_id);
$stmt_stock->execute();
$productos_stock = $stmt_stock->get_result();

while ($item = $productos_stock->fetch_assoc()) {
    if ($item['cantidad'] > $item['stock']) {
        responder(false, [
            'mensaje' => 'Stock insuficiente para el producto ID ' . $item['producto_id']
        ]);
    }
}
$stmt_stock->close();

// ===== VALIDAR STOCK DE COMBOS =====
$stmt_stock_combo = $conn->prepare("
    SELECT cc.combo_id, cc.cantidad, c.stock_combo as stock 
    FROM carrito_combos cc 
    JOIN combos c ON cc.combo_id = c.id 
    WHERE cc.carrito_id = ?
");
$stmt_stock_combo->bind_param("i", $carrito_id);
$stmt_stock_combo->execute();
$combos_stock = $stmt_stock_combo->get_result();

while ($item = $combos_stock->fetch_assoc()) {
    if ($item['cantidad'] > $item['stock']) {
        responder(false, [
            'mensaje' => 'Stock insuficiente para el combo ID ' . $item['combo_id']
        ]);
    }
}
$stmt_stock_combo->close();

// ===== CALCULAR SUBTOTAL REAL DESDE LA BD =====
$stmt_subtotal = $conn->prepare("
    SELECT 
        (SELECT COALESCE(SUM(cantidad * precio_unitario), 0) FROM carrito_productos WHERE carrito_id = ?) +
        (SELECT COALESCE(SUM(precio_total), 0) FROM carrito_combos WHERE carrito_id = ?) as subtotal
");
$stmt_subtotal->bind_param("ii", $carrito_id, $carrito_id);
$stmt_subtotal->execute();
$subtotal = floatval($stmt_subtotal->get_result()->fetch_assoc()['subtotal']);
$stmt_subtotal->close();

// ===== VALIDAR QUE EL MÉTODO DE PAGO EXISTA Y ESTÉ ACTIVO EN `pasarelas` =====
if (!isset($pasarelas_activas[$metodo_pago])) {
    responder(false, ['mensaje' => 'Método de pago no permitido']);
}

// ===== OBTENER ACTIVACIONES DEL PROVEEDOR =====
$activaciones_proveedor = [];
$stmt_act = $conn->prepare("
    SELECT clave, valor 
    FROM configuracion 
    WHERE grupo = 'pagos' 
      AND proveedor_id = ? 
      AND clave LIKE '%_activo'
");
$stmt_act->bind_param("i", $proveedor_id);
$stmt_act->execute();
$res_act = $stmt_act->get_result();
while ($row = $res_act->fetch_assoc()) {
    $slug = str_replace('_activo', '', $row['clave']);
    $activaciones_proveedor[$slug] = $row['valor'];
}
$stmt_act->close();

// Determinar si el proveedor tiene configuración propia
$total_metodos_proveedor = count(array_filter($activaciones_proveedor, function($v) { return $v == 1; }));
$proveedor_config_id = ($total_metodos_proveedor == 0) ? 0 : $proveedor_id;

// ===== VALIDAR QUE EL MÉTODO ESTÉ ACTIVO PARA EL PROVEEDOR =====
if ($proveedor_config_id > 0) {
    // Proveedor tiene config propia → solo permitir las que tiene activas
    if (!isset($activaciones_proveedor[$metodo_pago]) || $activaciones_proveedor[$metodo_pago] != 1) {
        responder(false, ['mensaje' => 'Método de pago no permitido']);
    }
} else {
    // Proveedor sin config propia → usar la global
    $stmt_glob = $conn->prepare("SELECT valor FROM configuracion WHERE clave = ? AND grupo = 'pagos' AND proveedor_id = 0 LIMIT 1");
    $clave_activo = $metodo_pago . '_activo';
    $stmt_glob->bind_param("s", $clave_activo);
    $stmt_glob->execute();
    $res_glob = $stmt_glob->get_result()->fetch_assoc();
    $stmt_glob->close();
    
    if (!$res_glob || $res_glob['valor'] != 1) {
        responder(false, ['mensaje' => 'El método de pago seleccionado no está disponible']);
    }
}

// ===== VALIDAR QUE EL MÉTODO DE PAGO ACEPTE LA MONEDA DEL CARRITO =====
$moneda_carrito_validar = $carrito['moneda'] ?? 'USD';
$info_pasarela = $pasarelas_activas[$metodo_pago];
$monedas_pasarela = !empty($info_pasarela['monedas']) 
    ? array_map('trim', explode(',', $info_pasarela['monedas'])) 
    : [];

if (!empty($monedas_pasarela) && !in_array($moneda_carrito_validar, $monedas_pasarela)) {
    responder(false, ['mensaje' => 'Este método de pago no acepta la moneda de tu carrito']);
}

// Obtener la comisión del método de pago
$stmt_comision = $conn->prepare("SELECT valor 
                                 FROM configuracion 
                                 WHERE clave = ? 
                                 AND grupo = 'pagos' 
                                 AND proveedor_id = ?");
$clave_comision = $metodo_pago . '_comision';
$stmt_comision->bind_param("si", $clave_comision, $proveedor_config_id);
$stmt_comision->execute();
$comision_data = $stmt_comision->get_result()->fetch_assoc();
$stmt_comision->close();
$porcentaje_comision = $comision_data ? floatval($comision_data['valor']) : 0;

// ============================================
// DETECTAR MONEDA Y TASA DEL CARRITO
// ============================================
$moneda_carrito = $carrito['moneda'] ?? 'USD';
$tasa_aplicada = 1;

if ($moneda_carrito !== 'USD') {
    $tasa_aplicada = getTasaProveedor($conn, $proveedor_id, $moneda_carrito);
    if ($tasa_aplicada <= 0) {
        $tasa_aplicada = 1;
    }
}

// ============================================
// CONVERSIONES
// ============================================
// $subtotal está en USD (de BD).
// $costo_envio YA VIENE en moneda del carrito (del JS).

// Subtotal convertido a moneda del carrito
$subtotal_convertido = round($subtotal * $tasa_aplicada, 2);

// Envío ya está en moneda del carrito
$costo_envio_convertido = round($costo_envio, 2);

// Base sin comisión (en moneda del carrito)
$base_comision = $subtotal_convertido + $costo_envio_convertido;

// Total en moneda del carrito (SIN comisión)
$total_convertido = round($base_comision, 2);

// Total en USD base (auditoría, SIN comisión)
$total = ($tasa_aplicada > 0) 
    ? round($total_convertido / $tasa_aplicada, 2) 
    : $total_convertido;

$monto_pagado_convertido = 0;
$monto_pendiente_convertido = 0;

// ===== OBTENER CONFIGURACIÓN DE PAGO PARCIAL =====
$stmt_parcial = $conn->prepare("
    SELECT clave, valor 
    FROM configuracion 
    WHERE clave IN ('pago_con_entrega_activo', 'porcentaje_con_entrega') 
    AND grupo = 'general' 
    AND proveedor_id = ?
");
$stmt_parcial->bind_param("i", $proveedor_id);
$stmt_parcial->execute();
$config_parcial = $stmt_parcial->get_result();

$pago_parcial = [];
while ($row = $config_parcial->fetch_assoc()) {
    $pago_parcial[$row['clave']] = $row['valor'];
}
$stmt_parcial->close();

if (empty($pago_parcial)) {
    $stmt_parcial_global = $conn->prepare("
        SELECT clave, valor 
        FROM configuracion 
        WHERE clave IN ('pago_con_entrega_activo', 'porcentaje_con_entrega') 
        AND grupo = 'general' 
        AND proveedor_id = 0
    ");
    $stmt_parcial_global->execute();
    $config_parcial_global = $stmt_parcial_global->get_result();
    
    while ($row = $config_parcial_global->fetch_assoc()) {
        $pago_parcial[$row['clave']] = $row['valor'];
    }
    $stmt_parcial_global->close();
}

$pago_con_entrega_activo = ($pago_parcial['pago_con_entrega_activo'] ?? 0) == 1;
$porcentaje_entrega = floatval($pago_parcial['porcentaje_con_entrega'] ?? 100);

// ===== DETECTAR SI EL MÉTODO ES API O MANUAL (desde pasarelas) =====
$tipo_pasarela = $info_pasarela['tipo'] ?? 'api';
$es_metodo_manual = ($tipo_pasarela === 'manual');

// ===== CALCULAR PAGO PARCIAL =====
// Reglas:
// - monto_pagado = 0 siempre al crear (aún no ha pagado)
// - monto_pendiente = lo que debe pagar en el próximo intento
// - porcentaje_pagado = 0 siempre al crear
// - porcentaje_comprometido = % que se pagará al recibir (fijo)
//   * 100% adelantado → 0
//   * Parcial → configuracion.porcentaje_con_entrega (ej: 60)
//   * Contra entrega → 100

$monto_pagado_convertido = 0;
$porcentaje_pagado = 0;

if ($opcion_pago === 'entrega') {
    $monto_pendiente_convertido = $total_convertido;
    $porcentaje_comprometido = 100;
    $estado_actual = 'pendiente_entrega';
    $estado_pago = 'pendiente_entrega';
} elseif ($opcion_pago === 'parcial') {
    $porcentaje_comprometido = intval($porcentaje_entrega);
    $porcentaje_ahora = 100 - $porcentaje_comprometido;
    $monto_pendiente_convertido = round($total_convertido * ($porcentaje_ahora / 100), 2);
    $estado_actual = 'pendiente_parcial';
    $estado_pago = 'pendiente_parcial';
} else {
    $monto_pendiente_convertido = $total_convertido;
    $porcentaje_comprometido = 0;
    
    if ($es_metodo_manual) {
        $estado_actual = 'pendiente_verificacion';
        $estado_pago = 'pendiente_verificacion';
    } else {
        $estado_actual = 'pendiente_pago';
        $estado_pago = 'pendiente';
    }
}

// ===== CALCULAR COMISIÓN DEL 1ER PAGO =====
// La comisión se calcula sobre monto_pendiente (lo que se paga en este intento)
$comision_convertida = round($monto_pendiente_convertido * ($porcentaje_comision / 100), 2);

// Generar código de pedido
$codigo_pedido = generarCodigoPedido($conn);

// ===== CREAR PEDIDO EN TRANSACCIÓN =====
$conn->begin_transaction();

try {
 $stmt = $conn->prepare("INSERT INTO pedidos 
    (codigo, carrito_id, cliente_id, subtotal, subtotal_convertido, envio, comision, forma_pago, total, total_convertido, tipo_pago, moneda, proveedor_id, tipo_cambio_usado, estado_actual, estado_pago, porcentaje_pagado, monto_pagado, monto_pendiente, porcentaje_comprometido) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Tipos: s i i d d d d s d d s s i d s s i d d i
$stmt->bind_param("siiddddsddssidssiddi", 
    $codigo_pedido,               // s  1. codigo
    $carrito_id,                  // i  2. carrito_id
    $cliente_id,                  // i  3. cliente_id
    $subtotal,                    // d  4. subtotal (USD base) ✅
    $subtotal_convertido,         // d  5. subtotal_convertido (moneda del pedido)
    $costo_envio_convertido,      // d  6. envio (moneda del pedido)
    $comision_convertida,         // d  7. comision (moneda del pedido)
    $metodo_pago,                 // s  8. forma_pago
    $total,                       // d  9. total (USD base) ✅
    $total_convertido,            // d 10. total_convertido (moneda del pedido)
    $metodo_pago,                 // s 11. tipo_pago
    $moneda_carrito,              // s 12. moneda
    $proveedor_id,                // i 13. proveedor_id
    $tasa_aplicada,               // d 14. tipo_cambio_usado
    $estado_actual,               // s 15. estado_actual
    $estado_pago,                 // s 16. estado_pago
    $porcentaje_pagado,           // i 17. porcentaje_pagado
    $monto_pagado_convertido,     // d 18. monto_pagado
    $monto_pendiente_convertido,  // d 19. monto_pendiente
    $porcentaje_comprometido      // i 20. porcentaje_comprometido ✅
);

    if (!$stmt->execute()) {
        throw new Exception('Error INSERT pedidos: ' . $stmt->error);
    }

    $pedido_id = $conn->insert_id;

        // Copiar productos individuales CON conversión
    $stmt_detalles = $conn->prepare("INSERT INTO pedido_detalles 
    (pedido_id, producto_id, cantidad, precio_unitario, moneda, precio_convertido, tasa_aplicada, subtotal, subtotal_convertido, proveedor_id)
    SELECT 
        ?, 
        producto_id, 
        cantidad, 
        precio_unitario, 
        ?, 
        precio_unitario * ?, 
        ?, 
        (cantidad * precio_unitario), 
        (cantidad * precio_unitario * ?), 
        ?
    FROM carrito_productos WHERE carrito_id = ?");

// Tipos: i s d d d i i
$stmt_detalles->bind_param("isdddii", 
    $pedido_id, 
    $moneda_carrito, 
    $tasa_aplicada, 
    $tasa_aplicada, 
    $tasa_aplicada, 
    $proveedor_id, 
    $carrito_id
);
    if (!$stmt_detalles->execute()) {
        throw new Exception('Error INSERT pedido_detalles productos: ' . $stmt_detalles->error);
    }

    // Copiar combos CON conversión
    $stmt_combos = $conn->prepare("INSERT INTO pedido_detalles 
    (pedido_id, combo_id, cantidad, precio_unitario, moneda, precio_convertido, tasa_aplicada, subtotal, subtotal_convertido, proveedor_id)
    SELECT 
        ?, 
        combo_id, 
        cantidad, 
        precio_total / cantidad, 
        ?, 
        (precio_total / cantidad) * ?, 
        ?, 
        precio_total, 
        precio_total * ?, 
        ?
    FROM carrito_combos WHERE carrito_id = ?");

// Tipos: i s d d d i i
$stmt_combos->bind_param("isdddii", 
    $pedido_id, 
    $moneda_carrito, 
    $tasa_aplicada, 
    $tasa_aplicada, 
    $tasa_aplicada, 
    $proveedor_id, 
    $carrito_id
);
    if (!$stmt_combos->execute()) {
        throw new Exception('Error INSERT pedido_detalles combos: ' . $stmt_combos->error);
    }

    // Guardar dirección
    $stmt_dir = $conn->prepare("INSERT INTO direcciones_envio 
        (pedido_id, nombre_completo, documento, direccion, municipio, provincia, telefono, email, instrucciones) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt_dir->bind_param("issssssss", 
        $pedido_id, 
        $nombre_entrega, 
        $documento_entrega, 
        $direccion_entrega,
        $municipio_entrega,
        $provincia_entrega, 
        $telefono_entrega, 
        $email_entrega, 
        $instrucciones
    );
    if (!$stmt_dir->execute()) {
        throw new Exception('Error INSERT direcciones_envio: ' . $stmt_dir->error);
    }

    // Registrar estado
    $stmt_estado = $conn->prepare("INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
        VALUES (?, ?, ?, ?)");
        $simbolo_mon = getSimboloPorMoneda($moneda_carrito);
    $obs = "Pedido creado con método de pago: " . $metodo_pago 
         . " | Moneda: " . $moneda_carrito 
         . " | Comisión: " . $simbolo_mon . number_format($comision_convertida, 2) . " " . $moneda_carrito
         . " | Total: " . $simbolo_mon . number_format($total_convertido, 2) . " " . $moneda_carrito;
    $stmt_estado->bind_param("isis", $pedido_id, $estado_actual, $cliente_id, $obs);
    if (!$stmt_estado->execute()) {
        throw new Exception('Error INSERT pedido_estados: ' . $stmt_estado->error);
    }

    // Marcar carrito como comprado
    $stmt_carrito = $conn->prepare("UPDATE carritos SET estado = 'comprado', fecha_cierre = NOW() WHERE id = ?");
    $stmt_carrito->bind_param("i", $carrito_id);
    if (!$stmt_carrito->execute()) {
        throw new Exception('Error UPDATE carritos: ' . $stmt_carrito->error);
    }

    $conn->commit();
} catch (Throwable $e) {
    $conn->rollback();
    error_log('[procesar_pago] Rollback: ' . $e->getMessage());
    responder(false, ['mensaje' => 'No se pudo crear el pedido, inténtalo de nuevo']);
}

// Registrar evento de pago completado (fuera de la transacción)
if (function_exists('registrarEvento')) {
    registrarEvento($conn, 'completar_pago');
}

// ===== ENCOLAR CORREOS (DESPUÉS DEL COMMIT) =====
require_once dirname(__DIR__) . '/includes/cola_correos.php';

// Encolar correo al cliente
encolarCorreo(
    $conn, 
    $cliente['email'] ?? '', 
    'Pedido ' . $codigo_pedido . ' - ' . $proveedor['nombre_tienda'], 
    'pedido_creado', 
    null, 
    $pedido_id
);

// Encolar correo al proveedor
// Determinar email del proveedor (email_ventas > email)
$email_proveedor = !empty($proveedor['email_ventas']) 
    ? $proveedor['email_ventas'] 
    : ($proveedor['email'] ?? '');

// Enviar correo al proveedor al crear el pedido (API y manual)
if (!empty($email_proveedor) && filter_var($email_proveedor, FILTER_VALIDATE_EMAIL)) {
    if ($email_proveedor !== ($cliente['email'] ?? '')) {
        encolarCorreo(
            $conn, 
            $email_proveedor, 
            'Nuevo Pedido ' . $codigo_pedido, 
            'pedido_creado_proveedor', 
            null, 
            $pedido_id
        );
    }
}

// ===== RESPUESTA FINAL AL CLIENTE (JSON) =====
responder(true, [
    'pedido_id'   => $pedido_id,
    'codigo'      => $codigo_pedido,
    'metodo_pago' => $metodo_pago,
    'redirect'    => '/checkout/redirigir_pago.php',
    'csrf_token'  => $_SESSION['csrf_token'],
]);
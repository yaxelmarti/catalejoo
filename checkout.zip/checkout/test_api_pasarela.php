<?php
// ============================================
// TEST API PASARELA - USA EL CÓDIGO REAL
// ============================================
// Ejecuta construirUrl_{slug}() con TEST_MODE activo.
// La petición HTTP NO se hace. Se registra y se simula la respuesta.
// Muestra:
//   - Petición exacta (URL, método, headers, body)
//   - Respuesta simulada
//   - URL de aprobación generada
//   - Estado del pedido ANTES y DESPUÉS
//
// USO:
//   ?slug=paypal&pedido_id=60
//   ?slug=stripe&pedido_id=60
//   &proveedor_id=1 (opcional)
//
// ⚠️ ELIMINAR DESPUÉS DE USAR
// ============================================

error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');

require_once dirname(__DIR__) . '/conexion.php';

// ============================================
// ACTIVAR MODO TEST
// ============================================
define('TEST_MODE', true);
$GLOBALS['test_requests'] = [];

// ============================================
// PARÁMETROS
// ============================================
$slug = preg_replace('/[^a-z0-9_]/', '', strtolower($_GET['slug'] ?? 'paypal'));
$pedido_id = intval($_GET['pedido_id'] ?? 0);
$proveedor_id_override = intval($_GET['proveedor_id'] ?? 0);

if (empty($slug)) {
    exit("Falta parámetro ?slug=...\n");
}

if ($pedido_id <= 0) {
    exit("Falta parámetro &pedido_id=...\n");
}

// ============================================
// OBTENER PEDIDO REAL
// ============================================
$stmt = $conn->prepare("
    SELECT id, codigo, moneda, total, total_convertido, monto_pagado, monto_pendiente, 
           estado_pago, estado_actual, tipo_pago, referencia_externa, transaccion_id, proveedor_id
    FROM pedidos 
    WHERE id = ?
");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pedido) {
    exit("Pedido #$pedido_id no encontrado.\n");
}

$proveedor_id = $proveedor_id_override > 0 ? $proveedor_id_override : intval($pedido['proveedor_id']);
$moneda_pedido = !empty($pedido['moneda']) ? $pedido['moneda'] : 'USD';
$monto_a_pagar = !empty($pedido['total_convertido']) ? floatval($pedido['total_convertido']) : floatval($pedido['total']);

echo "============================================\n";
echo "TEST REAL: $slug\n";
echo "Fecha: " . date('Y-m-d H:i:s') . "\n";
echo "============================================\n\n";

echo "=== PEDIDO ANTES ===\n";
echo "id: {$pedido['id']}\n";
echo "codigo: {$pedido['codigo']}\n";
echo "moneda: {$moneda_pedido}\n";
echo "monto: $monto_a_pagar\n";
echo "estado_pago: {$pedido['estado_pago']}\n";
echo "estado_actual: {$pedido['estado_actual']}\n";
echo "tipo_pago: {$pedido['tipo_pago']}\n";
echo "referencia_externa: " . ($pedido['referencia_externa'] ?? 'NULL') . "\n";
echo "transaccion_id: " . ($pedido['transaccion_id'] ?? 'NULL') . "\n";
echo "proveedor_id: $proveedor_id\n\n";

// ============================================
// CARGAR API
// ============================================
$archivo_api = __DIR__ . '/pago/apis/api_' . $slug . '.php';
if (!file_exists($archivo_api)) {
    exit("Archivo no encontrado: $archivo_api\n");
}

require_once $archivo_api;

$funcion = 'construirUrl_' . $slug;
if (!function_exists($funcion)) {
    exit("Función no encontrada: $funcion\n");
}

// ============================================
// LLAMAR A LA FUNCIÓN REAL
// ============================================
echo "=== EJECUTANDO $funcion() ===\n";

$url_pago = null;
try {
    $url_pago = $funcion($conn, $proveedor_id, $pedido['id'], $monto_a_pagar, $pedido['codigo'], $moneda_pedido);
} catch (Throwable $e) {
    echo "❌ EXCEPCIÓN: " . $e->getMessage() . "\n";
    echo "   Archivo: " . $e->getFile() . ":" . $e->getLine() . "\n";
}

echo "\n";

// ============================================
// MOSTRAR PETICIONES REGISTRADAS
// ============================================
echo "=== PETICIONES HTTP QUE SE HICIERON ===\n";
if (empty($GLOBALS['test_requests'])) {
    echo "(no se registraron peticiones)\n";
} else {
    foreach ($GLOBALS['test_requests'] as $i => $req) {
        echo "\n--- Petición #" . ($i + 1) . ": {$req['funcion']} ---\n";
        echo "URL:      {$req['url']}\n";
        echo "Método:   {$req['metodo']}\n";
        echo "Headers:\n";
        foreach ($req['headers'] as $h) {
            echo "          $h\n";
        }
        echo "Body:\n";
        // Indentar el body
        $body_lines = explode("\n", $req['body']);
        foreach ($body_lines as $line) {
            echo "          $line\n";
        }
    }
}
echo "\n";

// ============================================
// RESULTADO
// ============================================
echo "=== RESULTADO ===\n";
if ($url_pago) {
    echo "✅ URL generada:\n";
    echo "   $url_pago\n";
} else {
    echo "❌ No se generó URL (devolvió null)\n";
}
echo "\n";

// ============================================
// VERIFICAR ACTUALIZACIÓN DEL PEDIDO
// ============================================
// Recargar el pedido para ver si se actualizó referencia_externa
$stmt = $conn->prepare("
    SELECT id, estado_pago, estado_actual, referencia_externa, transaccion_id 
    FROM pedidos 
    WHERE id = ?
");
$stmt->bind_param("i", $pedido_id);
$stmt->execute();
$pedido_despues = $stmt->get_result()->fetch_assoc();
$stmt->close();

echo "=== PEDIDO DESPUÉS ===\n";
echo "estado_pago: " . ($pedido_despues['estado_pago'] ?? 'NULL') . "\n";
echo "estado_actual: " . ($pedido_despues['estado_actual'] ?? 'NULL') . "\n";
echo "referencia_externa: " . ($pedido_despues['referencia_externa'] ?? 'NULL') . "\n";
echo "transaccion_id: " . ($pedido_despues['transaccion_id'] ?? 'NULL') . "\n\n";

// ============================================
// VERIFICACIONES AUTOMÁTICAS
// ============================================
echo "=== VERIFICACIONES ===\n";

$checks = [];

// 1. ¿Se hizo la petición?
$checks[] = [
    'test' => '¿Se registraron peticiones HTTP?',
    'ok' => count($GLOBALS['test_requests']) > 0,
    'detalle' => count($GLOBALS['test_requests']) . ' peticiones registradas'
];

// 2. ¿Se generó URL?
$checks[] = [
    'test' => '¿Se generó URL de pago?',
    'ok' => !empty($url_pago),
    'detalle' => $url_pago ? 'URL: ' . substr($url_pago, 0, 60) . '...' : 'Sin URL'
];

// 3. ¿Se guardó referencia_externa?
$checks[] = [
    'test' => '¿Se guardó referencia_externa en el pedido?',
    'ok' => !empty($pedido_despues['referencia_externa']),
    'detalle' => $pedido_despues['referencia_externa'] ?? 'NULL'
];

// 4. ¿La moneda del pedido es la que se usó?
if ($slug === 'paypal') {
    $currency_enviada = 'USD'; // valor por defecto; se sobreescribe si encontramos el body
    foreach ($GLOBALS['test_requests'] as $req) {
        if (strpos($req['body'], '"currency_code"') !== false) {
            if (preg_match('/"currency_code":\s*"([^"]+)"/', $req['body'], $m)) {
                $currency_enviada = $m[1];
            }
        }
    }
    $checks[] = [
        'test' => "¿Se envió la moneda correcta a PayPal?",
        'ok' => $currency_enviada === strtoupper($moneda_pedido),
        'detalle' => "Enviada: $currency_enviada | Esperada: " . strtoupper($moneda_pedido)
    ];
} elseif ($slug === 'stripe') {
    $currency_enviada = 'usd';
    foreach ($GLOBALS['test_requests'] as $req) {
        if (strpos($req['body'], 'currency') !== false) {
            if (preg_match('/currency=([^&\n]+)/', $req['body'], $m)) {
                $currency_enviada = $m[1];
            }
        }
    }
    $checks[] = [
        'test' => "¿Se envió la moneda correcta a Stripe?",
        'ok' => $currency_enviada === strtolower($moneda_pedido),
        'detalle' => "Enviada: $currency_enviada | Esperada: " . strtolower($moneda_pedido)
    ];
}

foreach ($checks as $check) {
    $icono = $check['ok'] ? '✅' : '❌';
    echo "$icono {$check['test']}\n";
    echo "   → {$check['detalle']}\n";
}

echo "\n============================================\n";
echo "FIN DEL TEST\n";
echo "============================================\n";

$conn->close();
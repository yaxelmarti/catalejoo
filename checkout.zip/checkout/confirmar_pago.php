<?php
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);

session_start();
require_once dirname(__DIR__, 2) . '/conexion.php';
require_once dirname(__DIR__, 2) . '/includes/cliente_identificador.php';
require_once dirname(__DIR__, 2) . '/includes/proveedor_utils.php';

// ============================================
// OBTENER PEDIDO_ID (GET o POST)
// ============================================
$pedido_id = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pedido_id = intval($_POST['pedido_id'] ?? 0);
} else {
    $pedido_id = intval($_GET['pedido'] ?? 0);
}

if ($pedido_id == 0) {
    header('Location: /index.php');
    exit;
}

// Obtener cliente actual
$cliente = obtenerClienteActual($conn);
$cliente_id = $cliente['id'] ?? 0;

if ($cliente_id == 0) {
    header('Location: /index.php?error=login');
    exit;
}

// ============================================
// VALIDAR CSRF (solo si es POST)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        header('Location: /checkout/confirmar_pago.php?pedido=' . $pedido_id . '&error=csrf');
        exit;
    }
}

// Obtener datos del pedido
$stmt = $conn->prepare("SELECT p.* FROM pedidos p WHERE p.id = ? AND p.cliente_id = ?");
$stmt->bind_param("ii", $pedido_id, $cliente_id);
$stmt->execute();
$pedido = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$pedido) {
    header('Location: /index.php');
    exit;
}

// ============================================
// PROCESAR NOTIFICACIÓN DE PAGO (solo POST)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $metodo = trim($_POST['metodo'] ?? 'desconocido');
    $transaccion = trim($_POST['transaccion'] ?? '');
    $referencia = trim($_POST['referencia'] ?? '');
    
    $ref_final = $transaccion ?: ($referencia ?: 'No especificada');
    $obs = "Cliente notificó pago con " . $metodo . ". Referencia: " . $ref_final;
    
    // Verificar si ya existe una notificación previa (idempotencia)
    $stmt_check = $conn->prepare("
        SELECT id FROM pedido_estados 
        WHERE pedido_id = ? AND estado = 'notificacion_cliente' AND observaciones = ?
        LIMIT 1
    ");
    $stmt_check->bind_param("is", $pedido_id, $obs);
    $stmt_check->execute();
    $existe = $stmt_check->get_result()->num_rows > 0;
    $stmt_check->close();
    
    if (!$existe) {
        // Registrar en pedido_estados
        $stmt_estado = $conn->prepare("
            INSERT INTO pedido_estados (pedido_id, estado, usuario_id, observaciones) 
            VALUES (?, 'notificacion_cliente', ?, ?)
        ");
        $stmt_estado->bind_param("iis", $pedido_id, $cliente_id, $obs);
        $stmt_estado->execute();
        $stmt_estado->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Notificado</title>
    <link rel="stylesheet" href="/estilo.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        
        .confirmacion-container {
            max-width: 500px;
            width: 100%;
        }
        
        .confirmacion-card {
            background: white;
            border-radius: 30px;
            padding: 2.5rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        @media (max-width: 480px) {
            .confirmacion-card {
                padding: 1.5rem;
                border-radius: 20px;
            }
        }
        
        .icono-exito {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 2rem;
            color: white;
            font-size: 3rem;
        }
        
        h1 {
            font-size: 2rem;
            color: #2d3748;
            margin-bottom: 1rem;
        }
        
        @media (max-width: 480px) {
            h1 {
                font-size: 1.5rem;
            }
        }
        
        .mensaje {
            color: #718096;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .info-pedido {
            background: #f7fafc;
            border-radius: 15px;
            padding: 1.5rem;
            margin: 1.5rem 0;
            text-align: left;
        }
        
        .info-pedido p {
            color: #4a5568;
            margin-bottom: 0.5rem;
        }
        
        .info-pedido p:last-child {
            margin-bottom: 0;
        }
        
        .btn-mis-pedidos {
            display: inline-block;
            padding: 1rem 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            margin-top: 1rem;
            transition: all 0.3s;
        }
        
        .btn-mis-pedidos:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
        }
    </style>
</head>
<body>
    <div class="confirmacion-container">
        <div class="confirmacion-card">
            <div class="icono-exito">✅</div>
            
            <h1>¡Pago notificado!</h1>
            
            <div class="mensaje">
                Hemos recibido tu notificación de pago para el pedido #<?php echo htmlspecialchars($pedido['codigo'] ?? $pedido['id']); ?>.
                <br><br>
                Nuestro equipo verificará el pago y actualizará el estado del pedido a la mayor brevedad.
            </div>
            
            <div class="info-pedido">
                <p><strong>Estado actual:</strong> Pendiente de confirmación</p>
                <p><strong>Próximos pasos:</strong> Una vez verificado el pago, pasará a empaquetado.</p>
            </div>
            
            <a href="/mis_pedidos.php" class="btn-mis-pedidos">
                📋 Ver mis pedidos
            </a>
        </div>
    </div>
</body>
</html>
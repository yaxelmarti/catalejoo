<!-- Modal de importación (paso 1: subir archivo) -->
<div class="modal-contenido">
    <span class="close-modal" onclick="cerrarModalImportar()">&times;</span>
    <h2 style="margin-bottom: 1.5rem;">📤 Importar Productos</h2>
    
    <!-- Plantilla CSV -->
<a href="data:text/csv;charset=utf-8,%EF%BB%BFnombre,descripci%C3%B3n,marca,peso,cantidad,precio_costo,precio_venta,categor%C3%ADa,imagen_url%0AProducto%20Ejemplo,Descripci%C3%B3n,MarcaEjemplo,0.500,10,15.50,25.99,Electr%C3%B3nica,https://ejemplo.com/imagen.jpg" 
   download="plantilla_productos.csv" 
   class="btn-plantilla">
    📥 Descargar Plantilla CSV
</a>
    
    <form id="formImportar" enctype="multipart/form-data">
        <div style="margin-bottom: 1.5rem;">
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Archivo CSV:</label>
            <input type="file" name="archivo_importar" accept=".csv" required 
                   style="width: 100%; padding: 0.8rem; border: 2px solid #e2e8f0; border-radius: 8px;">
        </div>
        
        <button type="submit" class="btn-accion btn-excel" style="width: 100%;">
            🔍 Analizar Archivo
        </button>
    </form>
</div>

<style>
.btn-plantilla {
    display: inline-block;
    background: #4299e1;
    color: white;
    padding: 0.6rem 1.2rem;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 1rem;
    text-align: center;
    width: 100%;
}

.btn-plantilla:hover {
    background: #3182ce;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(66, 153, 225, 0.3);
}

.btn-accion {
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    font-size: 0.9rem;
}

.btn-excel { 
    background: #48bb78; 
    color: white; 
}

.btn-accion:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.modal-contenido {
    background: white;
    padding: 2.5rem;
    border-radius: 16px;
    max-width: 500px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
}

.close-modal {
    position: absolute;
    top: 1rem;
    right: 1.5rem;
    font-size: 2rem;
    cursor: pointer;
    color: #a0aec0;
    transition: color 0.3s;
}

.close-modal:hover {
    color: #2d3748;
}
</style>

<script>
document.getElementById('formImportar').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('/importar/analizar.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarResumen(data);
        } else {
            alert('Error: ' + data.mensaje);
        }
    })
    .catch(error => {
        alert('Error al analizar el archivo');
    });
});

function mostrarResumen(data) {
    const modal = document.querySelector('.modal-contenido');
    modal.innerHTML = `
        <span class="close-modal" onclick="cerrarModalImportar()">&times;</span>
        <h2 style="margin-bottom: 1.5rem;">📊 Resumen de Importación</h2>
        
        <div style="background: #f7fafc; padding: 1.5rem; border-radius: 12px; margin: 1.5rem 0;">
            <div style="display: flex; justify-content: space-around; text-align: center; margin-bottom: 1rem;">
                <div>
                    <div style="font-size: 2rem; font-weight: 700; color: #48bb78;">${data.nuevos}</div>
                    <div style="color: #718096;">Productos Nuevos</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: 700; color: #ecc94b;">${data.duplicados}</div>
                    <div style="color: #718096;">Productos Duplicados</div>
                </div>
            </div>
            <div style="text-align: center; padding-top: 0.5rem; border-top: 1px solid #e2e8f0;">
                <div style="font-size: 1.2rem; font-weight: 600; color: ${data.precio_diferente > 0 ? '#f56565' : '#48bb78'};">
                    ${data.precio_diferente} duplicados con precio diferente
                </div>
            </div>
        </div>
        
        <p style="margin-bottom: 1.5rem; color: #4a5568; text-align: center;">
            Se procesarán los productos <strong>UNO POR UNO</strong> de forma segura.
        </p>
        
        <div style="display: flex; gap: 1rem;">
            <button onclick="iniciarImportacion('${data.archivo_id}')" class="btn-accion btn-excel" style="flex: 2;">
                🚀 Comenzar Importación
            </button>
            <button onclick="cerrarModalImportar()" class="btn-accion" style="flex: 1; background: #edf2f7; color: #4a5568;">
                Cancelar
            </button>
        </div>
    `;
}

function iniciarImportacion(archivoId) {
    fetch('/importar/procesar_paso.php?iniciar=' + archivoId)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.tipo === 'nuevo') {
                procesarNuevo(data);
            } else if (data.tipo === 'duplicado') {
                mostrarDuplicado(data);
            } else if (data.fin) {
                mostrarResultadoFinal(data);
            }
        } else {
            alert('Error: ' + data.mensaje);
        }
    });
}

function procesarNuevo(data) {
    // Automático: insertar y continuar
    fetch('/importar/procesar_paso.php?procesar=' + data.archivo_id)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.tipo === 'nuevo') {
                procesarNuevo(data);
            } else if (data.tipo === 'duplicado') {
                mostrarDuplicado(data);
            } else if (data.fin) {
                mostrarResultadoFinal(data);
            }
        }
    });
}

function mostrarDuplicado(data) {
    const modal = document.querySelector('.modal-contenido');
    
    // Mantener el resumen arriba
    const resumenHTML = modal.querySelector('.resumen-importacion')?.outerHTML || '';
    
    modal.innerHTML = `
        <span class="close-modal" onclick="cancelarImportacion('${data.archivo_id}')">&times;</span>
        <h2 style="margin-bottom: 1.5rem;">⚠️ Producto Duplicado</h2>
        
        <div class="resumen-importacion" style="background: #f7fafc; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
            <div style="display: flex; justify-content: space-between; font-size: 0.9rem;">
                <span>Procesado: ${data.indice}/${data.total}</span>
                <span>Nuevos: ${data.nuevos_procesados}</span>
                <span>Actualizados: ${data.actualizados}</span>
            </div>
        </div>
        
        <div style="background: white; border: 2px solid #e2e8f0; border-radius: 12px; padding: 1.5rem; margin-bottom: 1.5rem;">
            <h3 style="margin-bottom: 1rem; color: #2d3748;">${data.producto.nombre}</h3>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                <div style="background: #f7fafc; padding: 1rem; border-radius: 8px;">
                    <div style="font-size: 0.8rem; color: #718096;">Cantidad Actual</div>
                    <div style="font-size: 1.5rem; font-weight: 700;">${data.producto.stock_actual}</div>
                </div>
                <div style="background: #ebf8ff; padding: 1rem; border-radius: 8px;">
                    <div style="font-size: 0.8rem; color: #2c5282;">Cantidad Nueva</div>
                    <div style="font-size: 1.5rem; font-weight: 700;">${data.producto.cantidad_csv}</div>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div style="background: #f7fafc; padding: 1rem; border-radius: 8px;">
                    <div style="font-size: 0.8rem; color: #718096;">Precio Costo Actual</div>
                    <div style="font-size: 1.2rem; font-weight: 700;">$${parseFloat(data.producto.precio_actual).toFixed(2)}</div>
                </div>
                <div style="background: ${data.precio_diferente ? '#fed7d7' : '#ebf8ff'}; padding: 1rem; border-radius: 8px;">
                    <div style="font-size: 0.8rem; color: ${data.precio_diferente ? '#c53030' : '#2c5282'};">Precio Costo Nuevo</div>
                    <div style="font-size: 1.2rem; font-weight: 700;">$${parseFloat(data.producto.precio_csv).toFixed(2)}</div>
                </div>
            </div>
            
            ${data.precio_diferente ? 
                '<div style="margin-top: 1rem; padding: 0.5rem; background: #fed7d7; border-radius: 8px; color: #c53030; font-size: 0.9rem; text-align: center;">⚠️ El precio costo es diferente</div>' 
                : ''}
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem; margin-bottom: 0.5rem;">
            <button onclick="accionDuplicado('${data.archivo_id}', 'sumar_cantidad')" class="btn-accion" style="background: #4299e1; color: white;">
                📦 Sumar Cantidad
            </button>
            <button onclick="accionDuplicado('${data.archivo_id}', 'sumar_precio')" class="btn-accion" style="background: #9f7aea; color: white;">
                💰 Sumar Cantidad + Precio
            </button>
        </div>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem;">
            <button onclick="accionDuplicado('${data.archivo_id}', 'omitir')" class="btn-accion" style="background: #ecc94b; color: #744210;">
                ⏭️ Omitir
            </button>
            <button onclick="cancelarImportacion('${data.archivo_id}')" class="btn-accion" style="background: #f56565; color: white;">
                ❌ Cancelar Importación
            </button>
        </div>
    `;
}

function accionDuplicado(archivoId, accion) {
    fetch('/importar/procesar_paso.php?accion=' + accion + '&archivo=' + archivoId)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.tipo === 'nuevo') {
                procesarNuevo(data);
            } else if (data.tipo === 'duplicado') {
                mostrarDuplicado(data);
            } else if (data.fin) {
                mostrarResultadoFinal(data);
            }
        }
    });
}

function cancelarImportacion(archivoId) {
    if (confirm('¿Estás seguro de cancelar TODA la importación? La base de datos volverá al estado anterior.')) {
        fetch('/importar/procesar_paso.php?cancelar=' + archivoId)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const modal = document.querySelector('.modal-contenido');
                modal.innerHTML = `
                    <span class="close-modal" onclick="cerrarModalImportar()">&times;</span>
                    <div style="text-align: center; padding: 2rem;">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">⏹️</div>
                        <h2 style="color: #f56565; margin-bottom: 1rem;">Importación Cancelada</h2>
                        <p style="color: #718096; margin-bottom: 2rem;">La base de datos no ha sido modificada.</p>
                        <button onclick="cerrarModalImportar()" class="btn-accion btn-excel">Cerrar</button>
                    </div>
                `;
            }
        });
    }
}

function mostrarResultadoFinal(data) {
    const modal = document.querySelector('.modal-contenido');
    modal.innerHTML = `
        <span class="close-modal" onclick="cerrarModalImportar()">&times;</span>
        <h2 style="margin-bottom: 1.5rem;">✅ Importación Completada</h2>
        
        <div style="background: #f7fafc; padding: 1.5rem; border-radius: 12px; margin: 1.5rem 0;">
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; text-align: center;">
                <div>
                    <div style="font-size: 2rem; font-weight: 700; color: #48bb78;">${data.nuevos}</div>
                    <div style="color: #718096;">Nuevos</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: 700; color: #4299e1;">${data.actualizados}</div>
                    <div style="color: #718096;">Actualizados</div>
                </div>
                <div>
                    <div style="font-size: 2rem; font-weight: 700; color: #9f7aea;">${data.precios_actualizados}</div>
                    <div style="color: #718096;">Precios</div>
                </div>
            </div>
        </div>
        
        <p style="margin-bottom: 0.5rem;">📦 Cantidad total añadida: <strong>${data.total_cantidad}</strong></p>
        <p style="margin-bottom: 1.5rem;">💰 Precios actualizados: <strong>${data.precios_actualizados}</strong></p>
        
        <button onclick="cerrarModalImportar()" class="btn-accion btn-excel" style="width: 100%;">Cerrar</button>
    `;
}
</script>
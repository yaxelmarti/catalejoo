<?php
require_once __DIR__ . '/../conexion.php';
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

header('Content-Type: application/json');

// Verificar permisos
$roles_permitidos = ['Super Admin', 'Admin', 'Inventario'];
$puede_gestionar = in_array($_SESSION['rol'] ?? '', $roles_permitidos);

if (!$puede_gestionar) {
    echo json_encode(['success' => false, 'mensaje' => 'Permiso denegado']);
    exit;
}

// ============================================
// ANALIZAR ARCHIVO CSV
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['archivo_importar'])) {
    $archivo = $_FILES['archivo_importar'];
    
    if ($archivo['error'] == 0) {
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        
        if ($extension == 'csv') {
            $file = fopen($archivo['tmp_name'], 'r');
            $cabeceras = fgetcsv($file); // Leer y descartar cabeceras
            
            $productos = [];
            $contador = 0;
            $duplicados = 0;
            $nuevos = 0;
            $precio_diferente = 0;
            
            while (($datos = fgetcsv($file)) !== FALSE) {
                $contador++;
                
                // Convertir a UTF-8
                $datos_procesados = [];
                foreach ($datos as $campo) {
                    $encoding = mb_detect_encoding($campo, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
                    if ($encoding && $encoding != 'UTF-8') {
                        $campo = mb_convert_encoding($campo, 'UTF-8', $encoding);
                    }
                    $datos_procesados[] = $campo;
                }
                
                // NUEVO ORDEN: 9 columnas
                // 0: nombre, 1: descripcion, 2: marca, 3: peso, 4: cantidad, 5: precio_costo, 6: precio_venta, 7: categoria, 8: imagen_url
                $nombre = $conn->real_escape_string($datos_procesados[0] ?? '');
                $descripcion = $datos_procesados[1] ?? '';
                $marca = $datos_procesados[2] ?? '';
                $peso = floatval($datos_procesados[3] ?? 0);
                $cantidad = intval($datos_procesados[4] ?? 0);
                $precio_costo = floatval($datos_procesados[5] ?? 0);
                $precio_venta = floatval($datos_procesados[6] ?? 0);
                $categoria = $datos_procesados[7] ?? '';
                $imagen = $datos_procesados[8] ?? '';
                
                if (empty($nombre)) continue;
                
                // Verificar si existe
                $check = $conn->query("SELECT id, cantidad, precio_costo FROM productos WHERE nombre = '$nombre' LIMIT 1");
                
                $es_duplicado = ($check->num_rows > 0);
                
                if ($es_duplicado) {
                    $duplicados++;
                    $existente = $check->fetch_assoc();
                    // Verificar si el precio costo es diferente
                    if (abs($existente['precio_costo'] - $precio_costo) > 0.01) {
                        $precio_diferente++;
                    }
                } else {
                    $nuevos++;
                }
                
                $productos[] = [
                    'nombre' => $nombre,
                    'descripcion' => $descripcion,
                    'marca' => $marca,
                    'peso' => $peso,
                    'cantidad' => $cantidad,
                    'precio_costo' => $precio_costo,
                    'precio_venta' => $precio_venta,
                    'categoria' => $categoria,
                    'imagen' => $imagen,
                    'duplicado' => $es_duplicado
                ];
            }
            fclose($file);
            
            // Generar ID único para esta importación
            $archivo_id = uniqid('import_', true);
            
            // Guardar en sesión
            $_SESSION['importacion'][$archivo_id] = [
                'productos' => $productos,
                'indice' => 0,
                'total' => $contador,
                'nuevos' => $nuevos,
                'duplicados' => $duplicados,
                'nuevos_procesados' => 0,
                'actualizados' => 0,
                'precios_actualizados' => 0,
                'total_cantidad' => 0,
                'en_curso' => false
            ];
            
            echo json_encode([
                'success' => true,
                'archivo_id' => $archivo_id,
                'nuevos' => $nuevos,
                'duplicados' => $duplicados,
                'precio_diferente' => $precio_diferente,
                'total' => $contador
            ]);
            exit;
            
        } else {
            echo json_encode(['success' => false, 'mensaje' => 'Solo se permiten archivos CSV']);
            exit;
        }
    }
}

echo json_encode(['success' => false, 'mensaje' => 'Error al subir el archivo']);
exit;
?>
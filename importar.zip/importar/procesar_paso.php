<?php
require_once __DIR__ . '/../conexion.php';
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

header('Content-Type: application/json');

// Verificar permisos
$roles_permitidos = ['Super Admin', 'Admin', 'Inventario'];
$puede_gestionar = in_array($_SESSION['rol'] ?? '', $roles_permitidos);

if (!$puede_gestionar) {
    echo json_encode(['success' => false, 'mensaje' => 'Permiso denegado']);
    exit;
}

// ============================================
// INICIAR IMPORTACIÓN (crear transacción)
// ============================================
if (isset($_GET['iniciar'])) {
    $archivo_id = $_GET['iniciar'];
    
    if (!isset($_SESSION['importacion'][$archivo_id])) {
        echo json_encode(['success' => false, 'mensaje' => 'Archivo no encontrado']);
        exit;
    }
    
    // Iniciar transacción
    $conn->begin_transaction();
    
    // Marcar como en curso
    $_SESSION['importacion'][$archivo_id]['en_curso'] = true;
    
    // Obtener primer producto
    $producto = $_SESSION['importacion'][$archivo_id]['productos'][0];
    $indice = 0;
    
    if ($producto['duplicado']) {
        // Obtener datos actuales de la BD
        $nombre = $conn->real_escape_string($producto['nombre']);
        $check = $conn->query("SELECT id, cantidad, precio_costo FROM productos WHERE nombre = '$nombre' LIMIT 1");
        $existente = $check->fetch_assoc();
        
        echo json_encode([
            'success' => true,
            'archivo_id' => $archivo_id,
            'tipo' => 'duplicado',
            'indice' => $indice + 1,
            'total' => $_SESSION['importacion'][$archivo_id]['total'],
            'nuevos_procesados' => $_SESSION['importacion'][$archivo_id]['nuevos_procesados'],
            'actualizados' => $_SESSION['importacion'][$archivo_id]['actualizados'],
            'precio_diferente' => abs($existente['precio_costo'] - $producto['precio_costo']) > 0.01,
            'producto' => [
                'nombre' => $producto['nombre'],
                'stock_actual' => $existente['cantidad'],
                'precio_actual' => $existente['precio_costo'],
                'cantidad_csv' => $producto['cantidad'],
                'precio_csv' => $producto['precio_costo']
            ]
        ]);
    } else {
        // Producto nuevo, procesar automáticamente
        procesarProductoNuevo($conn, $archivo_id, $indice, $producto);
    }
    exit;
}

// ============================================
// PROCESAR ACCIÓN SOBRE DUPLICADO
// ============================================
if (isset($_GET['accion']) && isset($_GET['archivo'])) {
    $archivo_id = $_GET['archivo'];
    $accion = $_GET['accion'];
    
    if (!isset($_SESSION['importacion'][$archivo_id])) {
        echo json_encode(['success' => false, 'mensaje' => 'Archivo no encontrado']);
        exit;
    }
    
    $indice_actual = $_SESSION['importacion'][$archivo_id]['indice'];
    $producto = $_SESSION['importacion'][$archivo_id]['productos'][$indice_actual];
    
    // Obtener datos actuales
    $nombre = $conn->real_escape_string($producto['nombre']);
    $check = $conn->query("SELECT id, cantidad, precio_costo, precio, descripcion, imagen_url, categoria_id FROM productos WHERE nombre = '$nombre' LIMIT 1");
    $existente = $check->fetch_assoc();
    
    $producto_id = $existente['id'];
    $cantidad_anterior = $existente['cantidad'];
    $precio_anterior = $existente['precio_costo'];
    
    $cambios = [];
    $precio_actualizado = false;
    
    switch ($accion) {
        case 'sumar_cantidad':
            $nueva_cantidad = $cantidad_anterior + $producto['cantidad'];
            $sql = "UPDATE productos SET cantidad = $nueva_cantidad WHERE id = $producto_id";
            $conn->query($sql);
            
            $cambios['cantidad'] = [
                'antes' => $cantidad_anterior,
                'despues' => $nueva_cantidad
            ];
            
            $_SESSION['importacion'][$archivo_id]['actualizados']++;
            $_SESSION['importacion'][$archivo_id]['total_cantidad'] += $producto['cantidad'];
            break;
            
        case 'sumar_precio':
            $nueva_cantidad = $cantidad_anterior + $producto['cantidad'];
            // Promediar precio costo
            $nuevo_precio = ($precio_anterior * $cantidad_anterior + $producto['precio_costo'] * $producto['cantidad']) / $nueva_cantidad;
            $sql = "UPDATE productos SET cantidad = $nueva_cantidad, precio_costo = $nuevo_precio WHERE id = $producto_id";
            $conn->query($sql);
            
            $cambios['cantidad'] = [
                'antes' => $cantidad_anterior,
                'despues' => $nueva_cantidad
            ];
            $cambios['precio_costo'] = [
                'antes' => $precio_anterior,
                'despues' => $nuevo_precio
            ];
            
            $_SESSION['importacion'][$archivo_id]['actualizados']++;
            $_SESSION['importacion'][$archivo_id]['precios_actualizados']++;
            $_SESSION['importacion'][$archivo_id]['total_cantidad'] += $producto['cantidad'];
            $precio_actualizado = true;
            break;
            
        case 'omitir':
            // No hacer nada
            $_SESSION['importacion'][$archivo_id]['indice']++;
            $nuevo_indice = $_SESSION['importacion'][$archivo_id]['indice'];
            
            if ($nuevo_indice >= $_SESSION['importacion'][$archivo_id]['total']) {
                // Terminó
                $conn->commit();
                echo json_encode([
                    'success' => true,
                    'fin' => true,
                    'nuevos' => $_SESSION['importacion'][$archivo_id]['nuevos_procesados'],
                    'actualizados' => $_SESSION['importacion'][$archivo_id]['actualizados'],
                    'precios_actualizados' => $_SESSION['importacion'][$archivo_id]['precios_actualizados'],
                    'total_cantidad' => $_SESSION['importacion'][$archivo_id]['total_cantidad']
                ]);
                unset($_SESSION['importacion'][$archivo_id]);
                exit;
            }
            
            // Siguiente producto
            $siguiente = $_SESSION['importacion'][$archivo_id]['productos'][$nuevo_indice];
            if ($siguiente['duplicado']) {
                $check = $conn->query("SELECT id, cantidad, precio_costo FROM productos WHERE nombre = '{$conn->real_escape_string($siguiente['nombre'])}' LIMIT 1");
                $sig_existente = $check->fetch_assoc();
                echo json_encode([
                    'success' => true,
                    'archivo_id' => $archivo_id,
                    'tipo' => 'duplicado',
                    'indice' => $nuevo_indice + 1,
                    'total' => $_SESSION['importacion'][$archivo_id]['total'],
                    'nuevos_procesados' => $_SESSION['importacion'][$archivo_id]['nuevos_procesados'],
                    'actualizados' => $_SESSION['importacion'][$archivo_id]['actualizados'],
                    'precio_diferente' => abs($sig_existente['precio_costo'] - $siguiente['precio_costo']) > 0.01,
                    'producto' => [
                        'nombre' => $siguiente['nombre'],
                        'stock_actual' => $sig_existente['cantidad'],
                        'precio_actual' => $sig_existente['precio_costo'],
                        'cantidad_csv' => $siguiente['cantidad'],
                        'precio_csv' => $siguiente['precio_costo']
                    ]
                ]);
                exit;
            } else {
                procesarProductoNuevo($conn, $archivo_id, $nuevo_indice, $siguiente);
                exit;
            }
            break;
    }
    
    // Si llegamos aquí, se actualizó el producto
    if ($accion != 'omitir') {
        
        // Guardar en historial_producto (movimiento de inventario)
        $tipo_evento = 'reabastecimiento';
        $observaciones = $precio_actualizado ? 
            "Importación: cantidad +{$producto['cantidad']}, precio promedio" : 
            "Importación: cantidad +{$producto['cantidad']}";
        
        $sql_historial1 = "INSERT INTO historial_producto 
            (producto_id, tipo_evento, cantidad, stock_antes, stock_despues, observaciones) 
            VALUES ($producto_id, '$tipo_evento', {$producto['cantidad']}, $cantidad_anterior, $nueva_cantidad, '$observaciones')";
        $conn->query($sql_historial1);
        
        // Guardar en historial_productos_cambios (auditoría) - SOLO LOS CAMPOS QUE CAMBIARON
        $usuario_id = $_SESSION['usuario_id'];
        $usuario_nombre = $_SESSION['nombre'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        
        $cambios_json = json_encode($cambios, JSON_UNESCAPED_UNICODE);
        
        $sql_historial2 = "INSERT INTO historial_productos_cambios 
            (producto_id, usuario_id, usuario_nombre, accion, cambios, ip_address, user_agent) 
            VALUES ($producto_id, $usuario_id, '$usuario_nombre', 'editar', '$cambios_json', '$ip', '$user_agent')";
        $conn->query($sql_historial2);
    }
    
    // Avanzar índice
    $_SESSION['importacion'][$archivo_id]['indice']++;
    $nuevo_indice = $_SESSION['importacion'][$archivo_id]['indice'];
    
    if ($nuevo_indice >= $_SESSION['importacion'][$archivo_id]['total']) {
        // Terminó
        $conn->commit();
        echo json_encode([
            'success' => true,
            'fin' => true,
            'nuevos' => $_SESSION['importacion'][$archivo_id]['nuevos_procesados'],
            'actualizados' => $_SESSION['importacion'][$archivo_id]['actualizados'],
            'precios_actualizados' => $_SESSION['importacion'][$archivo_id]['precios_actualizados'],
            'total_cantidad' => $_SESSION['importacion'][$archivo_id]['total_cantidad']
        ]);
        unset($_SESSION['importacion'][$archivo_id]);
        exit;
    }
    
    // Siguiente producto
    $siguiente = $_SESSION['importacion'][$archivo_id]['productos'][$nuevo_indice];
    if ($siguiente['duplicado']) {
        $check = $conn->query("SELECT id, cantidad, precio_costo FROM productos WHERE nombre = '{$conn->real_escape_string($siguiente['nombre'])}' LIMIT 1");
        $sig_existente = $check->fetch_assoc();
        echo json_encode([
            'success' => true,
            'archivo_id' => $archivo_id,
            'tipo' => 'duplicado',
            'indice' => $nuevo_indice + 1,
            'total' => $_SESSION['importacion'][$archivo_id]['total'],
            'nuevos_procesados' => $_SESSION['importacion'][$archivo_id]['nuevos_procesados'],
            'actualizados' => $_SESSION['importacion'][$archivo_id]['actualizados'],
            'precio_diferente' => abs($sig_existente['precio_costo'] - $siguiente['precio_costo']) > 0.01,
            'producto' => [
                'nombre' => $siguiente['nombre'],
                'stock_actual' => $sig_existente['cantidad'],
                'precio_actual' => $sig_existente['precio_costo'],
                'cantidad_csv' => $siguiente['cantidad'],
                'precio_csv' => $siguiente['precio_costo']
            ]
        ]);
        exit;
    } else {
        procesarProductoNuevo($conn, $archivo_id, $nuevo_indice, $siguiente);
        exit;
    }
}

// ============================================
// CANCELAR IMPORTACIÓN
// ============================================
if (isset($_GET['cancelar'])) {
    $archivo_id = $_GET['cancelar'];
    
    if (isset($_SESSION['importacion'][$archivo_id]) && $_SESSION['importacion'][$archivo_id]['en_curso']) {
        $conn->rollback();
    }
    
    unset($_SESSION['importacion'][$archivo_id]);
    
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// FUNCIÓN PARA PROCESAR PRODUCTO NUEVO
// ============================================
function procesarProductoNuevo($conn, $archivo_id, $indice, $producto) {
    
    // Buscar categoría
    $categoria = $conn->real_escape_string($producto['categoria']);
    $cat_result = $conn->query("SELECT id FROM categorias WHERE nombre LIKE '%$categoria%' LIMIT 1");
    $categoria_id = $cat_result->num_rows > 0 ? $cat_result->fetch_assoc()['id'] : 'NULL';
    
    // Insertar producto con marca y peso
    $sql = "INSERT INTO productos (nombre, descripcion, marca, peso, cantidad, precio_costo, precio, imagen_url, categoria_id, activo) 
            VALUES (
                '{$conn->real_escape_string($producto['nombre'])}',
                '{$conn->real_escape_string($producto['descripcion'])}',
                '{$conn->real_escape_string($producto['marca'])}',
                {$producto['peso']},
                {$producto['cantidad']},
                {$producto['precio_costo']},
                {$producto['precio_venta']},
                '{$conn->real_escape_string($producto['imagen'])}',
                $categoria_id,
                0
            )";
    
    if ($conn->query($sql)) {
        $nuevo_id = $conn->insert_id;
        
        // Guardar en historial_producto
        $sql_historial1 = "INSERT INTO historial_producto 
            (producto_id, tipo_evento, cantidad, stock_antes, stock_despues, observaciones) 
            VALUES ($nuevo_id, 'entrada_inicial', {$producto['cantidad']}, 0, {$producto['cantidad']}, 'Importado por CSV')";
        $conn->query($sql_historial1);
        
        // Guardar en historial_productos_cambios (CREAR)
        $usuario_id = $_SESSION['usuario_id'];
        $usuario_nombre = $_SESSION['nombre'];
        $ip = $_SERVER['REMOTE_ADDR'];
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        
        // Preparar JSON con TODOS los datos del producto creado
        $cambios_json = json_encode([
            'nombre' => $producto['nombre'],
            'descripcion' => $producto['descripcion'],
            'marca' => $producto['marca'],
            'peso' => $producto['peso'],
            'cantidad' => $producto['cantidad'],
            'precio_costo' => $producto['precio_costo'],
            'precio' => $producto['precio_venta'],
            'categoria_id' => $categoria_id,
            'imagen_url' => $producto['imagen'],
            'activo' => 0
        ], JSON_UNESCAPED_UNICODE);
        
        $sql_historial2 = "INSERT INTO historial_productos_cambios 
            (producto_id, usuario_id, usuario_nombre, accion, cambios, ip_address, user_agent) 
            VALUES ($nuevo_id, $usuario_id, '$usuario_nombre', 'crear', '$cambios_json', '$ip', '$user_agent')";
        $conn->query($sql_historial2);
        
        $_SESSION['importacion'][$archivo_id]['nuevos_procesados']++;
        $_SESSION['importacion'][$archivo_id]['total_cantidad'] += $producto['cantidad'];
    }
    
    // Avanzar índice
    $_SESSION['importacion'][$archivo_id]['indice']++;
    $nuevo_indice = $_SESSION['importacion'][$archivo_id]['indice'];
    
    if ($nuevo_indice >= $_SESSION['importacion'][$archivo_id]['total']) {
        // Terminó
        $conn->commit();
        echo json_encode([
            'success' => true,
            'fin' => true,
            'nuevos' => $_SESSION['importacion'][$archivo_id]['nuevos_procesados'],
            'actualizados' => $_SESSION['importacion'][$archivo_id]['actualizados'],
            'precios_actualizados' => $_SESSION['importacion'][$archivo_id]['precios_actualizados'],
            'total_cantidad' => $_SESSION['importacion'][$archivo_id]['total_cantidad']
        ]);
        unset($_SESSION['importacion'][$archivo_id]);
        exit;
    }
    
    // Siguiente producto
    $siguiente = $_SESSION['importacion'][$archivo_id]['productos'][$nuevo_indice];
    if ($siguiente['duplicado']) {
        $check = $conn->query("SELECT id, cantidad, precio_costo FROM productos WHERE nombre = '{$conn->real_escape_string($siguiente['nombre'])}' LIMIT 1");
        $sig_existente = $check->fetch_assoc();
        echo json_encode([
            'success' => true,
            'archivo_id' => $archivo_id,
            'tipo' => 'duplicado',
            'indice' => $nuevo_indice + 1,
            'total' => $_SESSION['importacion'][$archivo_id]['total'],
            'nuevos_procesados' => $_SESSION['importacion'][$archivo_id]['nuevos_procesados'],
            'actualizados' => $_SESSION['importacion'][$archivo_id]['actualizados'],
            'precio_diferente' => abs($sig_existente['precio_costo'] - $siguiente['precio_costo']) > 0.01,
            'producto' => [
                'nombre' => $siguiente['nombre'],
                'stock_actual' => $sig_existente['cantidad'],
                'precio_actual' => $sig_existente['precio_costo'],
                'cantidad_csv' => $siguiente['cantidad'],
                'precio_csv' => $siguiente['precio_costo']
            ]
        ]);
        exit;
    } else {
        procesarProductoNuevo($conn, $archivo_id, $nuevo_indice, $siguiente);
        exit;
    }
}
?>
<?php
require_once __DIR__ . '/../conexion.php';
// Configurar cookies de sesión seguras ANTES de session_start()
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

session_start();

// Verificar permisos
$roles_permitidos = ['Super Admin', 'Admin', 'Inventario'];
$puede_gestionar = in_array($_SESSION['rol'] ?? '', $roles_permitidos);

if (!$puede_gestionar) {
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// PROCESAR IMPORTACIÓN CON DETECCIÓN DE DUPLICADOS
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['archivo_importar'])) {
    $archivo = $_FILES['archivo_importar'];
    
    if ($archivo['error'] == 0) {
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        
        if ($extension == 'csv') {
            $file = fopen($archivo['tmp_name'], 'r');
            $cabeceras = fgetcsv($file);
            
            $productos_nuevos = [];
            $productos_duplicados = [];
            $fila_num = 1;
            
            // PRIMERA PASADA: Detectar todos los duplicados
            while (($datos = fgetcsv($file)) !== FALSE) {
                $fila_num++;
                
                // Convertir a UTF-8
                $datos_procesados = [];
                foreach ($datos as $campo) {
                    $encoding = mb_detect_encoding($campo, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
                    if ($encoding && $encoding != 'UTF-8') {
                        $campo = mb_convert_encoding($campo, 'UTF-8', $encoding);
                    }
                    $datos_procesados[] = $campo;
                }
                
                $nombre = $conn->real_escape_string($datos_procesados[0]);
                $descripcion = $conn->real_escape_string($datos_procesados[1] ?? '');
                $cantidad = intval($datos_procesados[2] ?? 0);
                $precio_costo = floatval($datos_procesados[3] ?? 0);
                $precio_venta = floatval($datos_procesados[4] ?? 0);
                $categoria = $conn->real_escape_string($datos_procesados[5] ?? '');
                $imagen = $conn->real_escape_string($datos_procesados[6] ?? '');
                
                // Buscar categoría
                $cat_result = $conn->query("SELECT id FROM categorias WHERE nombre LIKE '%$categoria%' LIMIT 1");
                $categoria_id = $cat_result->num_rows > 0 ? $cat_result->fetch_assoc()['id'] : null;
                
                // Verificar si el producto ya existe
                $check = $conn->query("SELECT id, cantidad, precio_costo FROM productos WHERE nombre = '$nombre' LIMIT 1");
                
                $producto = [
                    'nombre' => $nombre,
                    'descripcion' => $descripcion,
                    'cantidad' => $cantidad,
                    'precio_costo' => $precio_costo,
                    'precio_venta' => $precio_venta,
                    'categoria' => $categoria,
                    'categoria_id' => $categoria_id,
                    'imagen' => $imagen,
                    'fila' => $fila_num
                ];
                
                if ($check->num_rows > 0) {
                    $existente = $check->fetch_assoc();
                    $producto['existente_id'] = $existente['id'];
                    $producto['existente_cantidad'] = $existente['cantidad'];
                    $producto['existente_costo'] = $existente['precio_costo'];
                    $productos_duplicados[] = $producto;
                } else {
                    $productos_nuevos[] = $producto;
                }
            }
            fclose($file);
            
            // Guardar en sesión para la vista previa
            $_SESSION['importar_temp'] = [
                'nuevos' => $productos_nuevos,
                'duplicados' => $productos_duplicados
            ];
            
            // Redirigir a vista previa
            header('Location: vista_previa.php');
            exit;
            
        } else {
            $_SESSION['mensaje'] = "⚠️ Solo se permiten archivos CSV";
            $_SESSION['tipo_mensaje'] = "error";
            header('Location: /admin.php');
            exit;
        }
    } else {
        $_SESSION['mensaje'] = "❌ Error al subir el archivo";
        $_SESSION['tipo_mensaje'] = "error";
        header('Location: /admin.php');
        exit;
    }
} else {
    header('Location: /admin.php');
    exit;
}
?>
<?php
// ============================================
// REPORTE: CLIENTES
// Versión 27 Oct 2026
// NOTA: este archivo se incluye desde /reportes.php.
// NO debe incluir header.php ni footer.php (ya los maneja el padre).
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================
// VALIDAR SESIÓN (el padre ya validó, esto es defensa en profundidad)
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    echo '<div class="alert error">Sesión expirada</div>';
    return;
}

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$rol_actual = trim($_SESSION['rol'] ?? '');

// ============================================
// VERIFICACIÓN DE PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    echo '<div class="alert error">Acceso denegado</div>';
    return;
}

// Proveedores/Inventario/Vendedor no tienen acceso (por si acaso)
if (function_exists('esRolProveedor') && esRolProveedor($rol_actual)) {
    echo '<div class="alert error">Acceso denegado</div>';
    return;
}

// Exportar: solo Super Admin y Gerente
$puede_exportar = in_array($rol_actual, ['Super Admin', 'Gerente'], true);

// ============================================
// PROCESAR FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

if (!empty($_GET['nombre'])) {
    $where[] = "CONCAT(c.nombre, ' ', c.apellidos) LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['email'])) {
    $where[] = "c.email LIKE ?";
    $params[] = "%" . $_GET['email'] . "%";
    $types .= "s";
}

if (!empty($_GET['documento'])) {
    $where[] = "c.documento LIKE ?";
    $params[] = "%" . $_GET['documento'] . "%";
    $types .= "s";
}

if (!empty($_GET['movil'])) {
    $where[] = "c.movil LIKE ?";
    $params[] = "%" . $_GET['movil'] . "%";
    $types .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $where[] = "DATE(c.fecha_registro) >= ?";
    $params[] = $_GET['fecha_desde'];
    $types .= "s";
}
if (!empty($_GET['fecha_hasta'])) {
    $where[] = "DATE(c.fecha_registro) <= ?";
    $params[] = $_GET['fecha_hasta'];
    $types .= "s";
}

if (isset($_GET['email_verified']) && $_GET['email_verified'] !== '') {
    $where[] = "c.email_verified = ?";
    $params[] = intval($_GET['email_verified']);
    $types .= "i";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// CONTAR TOTAL (con filtros)
// ============================================
$count_sql = "SELECT COUNT(*) as total FROM clientes c $sql_where";
$total_registros = 0;
$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $count_stmt->close();
} else {
    error_log("[reportes_clientes] prepare count: " . $conn->error);
}

$total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA PRINCIPAL (LIMIT/OFFSET parametrizados)
// ============================================
$sql = "SELECT c.*, 
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id) as total_carritos,
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id AND estado = 'comprado') as compras_completadas,
        (SELECT COUNT(*) FROM carritos WHERE cliente_id = c.id AND estado = 'pendiente') as carritos_pendientes,
        (SELECT SUM(cantidad * precio_unitario) FROM carrito_productos cp 
         JOIN carritos ca ON cp.carrito_id = ca.id 
         WHERE ca.cliente_id = c.id AND ca.estado = 'comprado') as total_gastado
        FROM clientes c 
        $sql_where 
        ORDER BY c.fecha_registro DESC
        LIMIT ? OFFSET ?";

$params_select = $params;
$types_select = $types . 'ii';
$params_select[] = $por_pagina;
$params_select[] = $offset;

$clientes = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param($types_select, ...$params_select);
    $stmt->execute();
    $clientes = $stmt->get_result();
} else {
    error_log("[reportes_clientes] prepare select: " . $conn->error);
}

// ============================================
// ESTADÍSTICAS (con los mismos filtros)
// ============================================
$stats = ['total' => 0, 'verificados' => 0];
$stats_sql = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN email_verified = 1 THEN 1 ELSE 0 END) as verificados
    FROM clientes c
    $sql_where";
$stats_stmt = $conn->prepare($stats_sql);
if ($stats_stmt) {
    if (!empty($params)) {
        $stats_stmt->bind_param($types, ...$params);
    }
    $stats_stmt->execute();
    $row_stats = $stats_stmt->get_result()->fetch_assoc();
    if ($row_stats) {
        $stats = [
            'total' => intval($row_stats['total'] ?? 0),
            'verificados' => intval($row_stats['verificados'] ?? 0),
        ];
    }
    $stats_stmt->close();
} else {
    error_log("[reportes_clientes] prepare stats: " . $conn->error);
}

// ============================================
// BASE URL
// ============================================
$base_url = '/reportes.php?tab=clientes';
?>

<style>
.reportes-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.filtros-card {
    background: white;
    border-radius: 12px;
    padding: clamp(1rem, 3vw, 1.5rem);
    margin-bottom: 2rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.filtros-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 1rem;
}

.filtro-grupo label {
    display: block;
    font-size: 0.8rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.3rem;
}

.filtro-grupo input,
.filtro-grupo select {
    width: 100%;
    padding: 0.6rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    font-size: 16px;
    min-height: 44px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: 1rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.stat-card .label {
    font-size: 0.75rem;
    color: #718096;
    text-transform: uppercase;
}

.stat-card .value {
    font-size: clamp(1.2rem, 4vw, 1.5rem);
    font-weight: 600;
    color: #2d3748;
}

.tabla-clientes {
    background: white;
    border-radius: 12px;
    padding: clamp(0.5rem, 2vw, 1.5rem);
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.tabla-clientes table {
    width: 100%;
    min-width: 900px;
    border-collapse: collapse;
    font-size: 0.9rem;
}

.tabla-clientes th {
    text-align: left;
    padding: 1rem 0.5rem;
    background: #f8fafc;
    color: #4a5568;
    font-weight: 600;
    border-bottom: 2px solid #e2e8f0;
    white-space: nowrap;
}

.tabla-clientes td {
    padding: 0.8rem 0.5rem;
    border-bottom: 1px solid #edf2f7;
}

.badge-verificado {
    background: #48bb78;
    color: white;
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.8rem;
    white-space: nowrap;
}

.badge-no-verificado {
    background: #f56565;
    color: white;
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.8rem;
    white-space: nowrap;
}

.btn-accion {
    background: #667eea;
    color: white;
    padding: 0.3rem 0.8rem;
    border-radius: 4px;
    text-decoration: none;
    font-size: 0.8rem;
    display: inline-flex;
    align-items: center;
    min-height: 32px;
}

.btn-accion:hover {
    background: #5a67d8;
}

.btn-filtro {
    padding: 0.6rem 1.5rem;
    border: none;
    border-radius: 6px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    min-height: 44px;
}

.btn-filtro-aplicar {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
}

.btn-filtro-limpiar {
    background: #edf2f7;
    color: #4a5568;
}

.text-center { text-align: center; }
.text-right { text-align: right; }

.sin-datos {
    padding: 2rem;
    text-align: center;
    color: #a0aec0;
}

/* Paginación */
.paginacion-container {
    display: flex;
    justify-content: center;
    gap: 0.3rem;
    flex-wrap: wrap;
    margin-top: 1.5rem;
}

.paginacion-container a,
.paginacion-container span {
    padding: 0.4rem 0.8rem;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
    border: 1px solid #e2e8f0;
    background: white;
    color: #374151;
    min-width: 40px;
    min-height: 44px;
    text-align: center;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.paginacion-container a:hover {
    background: var(--primary, #667eea);
    color: white;
    border-color: var(--primary, #667eea);
}

.paginacion-container .active {
    background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
    color: white;
    border-color: var(--primary, #667eea);
}

.paginacion-container .disabled {
    opacity: 0.4;
    cursor: not-allowed;
}

@media (max-width: 768px) {
    .btn-filtro {
        width: 100%;
        justify-content: center;
    }
}
</style>

<div class="reportes-header">
    <h1 style="margin: 0; font-size: clamp(1.3rem, 5vw, 1.8rem); color: #2d3748;">👥 Reporte de Clientes</h1>
    <a href="/reportes.php?tab=dashboard" class="btn-accion" style="min-height: 44px; padding: 0.6rem 1rem;">← Volver al Dashboard</a>
</div>

<!-- Tarjetas de estadísticas (con filtros aplicados) -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="label">Total Clientes</div>
        <div class="value"><?php echo number_format($stats['total']); ?></div>
    </div>
    <div class="stat-card">
        <div class="label">Verificados</div>
        <div class="value"><?php echo number_format($stats['verificados']); ?></div>
    </div>
    <div class="stat-card">
        <div class="label">Tasa Verificación</div>
        <div class="value"><?php echo $stats['total'] > 0 ? round(($stats['verificados'] / $stats['total']) * 100, 1) : 0; ?>%</div>
    </div>
</div>

<!-- Filtros -->
<div class="filtros-card">
    <h3 style="margin-bottom: 1rem;">🔍 Filtrar Clientes</h3>
    
    <form method="GET" action="/reportes.php">
        <input type="hidden" name="tab" value="clientes">
        <div class="filtros-grid">
            <div class="filtro-grupo">
                <label>Nombre</label>
                <input type="text" name="nombre" value="<?php echo htmlspecialchars($_GET['nombre'] ?? ''); ?>">
            </div>
            
            <div class="filtro-grupo">
                <label>Email</label>
                <input type="text" name="email" value="<?php echo htmlspecialchars($_GET['email'] ?? ''); ?>">
            </div>
            
            <div class="filtro-grupo">
                <label>Documento</label>
                <input type="text" name="documento" value="<?php echo htmlspecialchars($_GET['documento'] ?? ''); ?>">
            </div>
            
            <div class="filtro-grupo">
                <label>Móvil</label>
                <input type="text" name="movil" value="<?php echo htmlspecialchars($_GET['movil'] ?? ''); ?>">
            </div>
        </div>
        
        <div class="filtros-grid">
            <div class="filtro-grupo">
                <label>Fecha desde</label>
                <input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>">
            </div>
            
            <div class="filtro-grupo">
                <label>Fecha hasta</label>
                <input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>">
            </div>
            
            <div class="filtro-grupo">
                <label>Verificado</label>
                <select name="email_verified">
                    <option value="">Todos</option>
                    <option value="1" <?php echo ($_GET['email_verified'] ?? '') === '1' ? 'selected' : ''; ?>>Verificados</option>
                    <option value="0" <?php echo ($_GET['email_verified'] ?? '') === '0' ? 'selected' : ''; ?>>No verificados</option>
                </select>
            </div>
        </div>
        
        <div style="display: flex; gap: 0.5rem; justify-content: flex-end; flex-wrap: wrap;">
            <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar Filtros</button>
            <a href="/reportes.php?tab=clientes" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
        </div>
    </form>
</div>

<!-- Tabla de clientes -->
<div class="tabla-clientes">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Documento</th>
                <th>Móvil</th>
                <th>Registro</th>
                <th>Verificado</th>
                <th>Carritos</th>
                <th>Compras</th>
                <th>Total Gastado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($clientes && $clientes->num_rows > 0): ?>
                <?php while($c = $clientes->fetch_assoc()): 
                    $ts = strtotime($c['fecha_registro'] ?? '');
                    $fecha_str = ($ts !== false) ? date('d/m/Y', $ts) : '—';
                ?>
                <tr>
                    <td>#<?php echo intval($c['id']); ?></td>
                    <td><strong><?php echo htmlspecialchars(trim(($c['nombre'] ?? '') . ' ' . ($c['apellidos'] ?? ''))); ?></strong></td>
                    <td><?php echo htmlspecialchars($c['email'] ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($c['documento'] ?? ''); ?></td>
                    <td><?php echo htmlspecialchars($c['movil'] ?? ''); ?></td>
                    <td><?php echo $fecha_str; ?></td>
                    <td>
                        <?php if (!empty($c['email_verified'])): ?>
                            <span class="badge-verificado">✅ Verificado</span>
                        <?php else: ?>
                            <span class="badge-no-verificado">❌ No verificado</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?php echo intval($c['total_carritos'] ?? 0); ?></td>
                    <td class="text-center"><?php echo intval($c['compras_completadas'] ?? 0); ?></td>
                    <td class="text-right">$<?php echo number_format(floatval($c['total_gastado'] ?? 0), 2); ?></td>
                    <td>
                        <a href="/admin/historial_cliente.php?id=<?php echo intval($c['id']); ?>" class="btn-accion">Ver</a>
                        <a href="/admin/historial_cliente_cambios.php?id=<?php echo intval($c['id']); ?>" class="btn-accion" title="Ver historial de cambios">📋</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="11" class="sin-datos">No hay clientes para mostrar con los filtros seleccionados</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Paginación -->
<?php if ($total_paginas > 1): 
    $query_params = $_GET;
?>
<div class="paginacion-container">
    <?php if ($pagina_actual > 1): ?>
        <?php $query_params['pagina'] = 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">«</a>
        <?php $query_params['pagina'] = $pagina_actual - 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
    <?php else: ?>
        <span class="disabled">«</span>
        <span class="disabled">‹</span>
    <?php endif; ?>

    <?php
    $rango = 3;
    $inicio = max(1, $pagina_actual - $rango);
    $fin = min($total_paginas, $pagina_actual + $rango);

    if ($inicio > 1) {
        $query_params['pagina'] = 1;
        echo '<a href="?' . http_build_query($query_params) . '">1</a>';
        if ($inicio > 2) echo '<span>…</span>';
    }

    for ($i = $inicio; $i <= $fin; $i++) {
        if ($i == $pagina_actual) {
            echo '<span class="active">' . $i . '</span>';
        } else {
            $query_params['pagina'] = $i;
            echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
        }
    }

    if ($fin < $total_paginas) {
        if ($fin < $total_paginas - 1) echo '<span>…</span>';
        $query_params['pagina'] = $total_paginas;
        echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
    }
    ?>

    <?php if ($pagina_actual < $total_paginas): ?>
        <?php $query_params['pagina'] = $pagina_actual + 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">›</a>
        <?php $query_params['pagina'] = $total_paginas; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">»</a>
    <?php else: ?>
        <span class="disabled">›</span>
        <span class="disabled">»</span>
    <?php endif; ?>
</div>
<?php endif; ?>
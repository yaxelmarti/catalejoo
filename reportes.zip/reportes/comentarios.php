<?php
// ============================================
// COMENTARIOS DE CLIENTES
// Versión 27 Oct 2026
// Ubicación: /reportes/comentarios.php
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ✅ Rutas absolutas desde este archivo (subcarpeta /reportes/)
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

$rol_actual = trim($_SESSION['rol'] ?? '');
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);

// ============================================
// PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    error_log("[comentarios] Permiso denegado. Rol: $rol_actual, usuario: $usuario_id_actual");
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// ACCIONES (POST con CSRF)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!function_exists('csrf_validar') || !csrf_validar($token)) {
        error_log("[comentarios] CSRF inválido. Usuario: $usuario_id_actual");
        $_SESSION['mensaje'] = '❌ Token de seguridad inválido';
        $_SESSION['tipo_mensaje'] = 'error';
        header('Location: /reportes/comentarios.php');
        exit;
    }

    $accion = $_POST['accion'] ?? '';
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;

    if ($id > 0) {
        if ($accion === 'marcar_leido') {
            $stmt = $conn->prepare("UPDATE comentarios_clientes SET leido = 1 WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    error_log("[comentarios] marcar_leido OK. Usuario: $usuario_id_actual, id: $id");
                    $_SESSION['mensaje'] = '✅ Comentario marcado como leído';
                    $_SESSION['tipo_mensaje'] = 'exito';
                } else {
                    error_log("[comentarios] marcar_leido error: " . $conn->error);
                    $_SESSION['mensaje'] = '❌ Error al marcar como leído';
                    $_SESSION['tipo_mensaje'] = 'error';
                }
                $stmt->close();
            }
        } elseif ($accion === 'eliminar') {
            $stmt = $conn->prepare("DELETE FROM comentarios_clientes WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $id);
                if ($stmt->execute()) {
                    error_log("[comentarios] eliminar OK. Usuario: $usuario_id_actual, id: $id");
                    $_SESSION['mensaje'] = '✅ Comentario eliminado';
                    $_SESSION['tipo_mensaje'] = 'exito';
                } else {
                    error_log("[comentarios] eliminar error: " . $conn->error);
                    $_SESSION['mensaje'] = '❌ Error al eliminar';
                    $_SESSION['tipo_mensaje'] = 'error';
                }
                $stmt->close();
            }
        }
    }

    header('Location: /reportes/comentarios.php');
    exit;
}

// ============================================
// OBTENER COMENTARIOS
// ============================================
$result = $conn->query("SELECT * FROM comentarios_clientes ORDER BY leido ASC, fecha DESC");
$mensaje = $_SESSION['mensaje'] ?? '';
$tipo_mensaje = $_SESSION['tipo_mensaje'] ?? 'info';
unset($_SESSION['mensaje']);
unset($_SESSION['tipo_mensaje']);

// Contar no leídos
$no_leidos = 0;
if ($result) {
    $result->data_seek(0);
    while ($row_tmp = $result->fetch_assoc()) {
        if (!$row_tmp['leido']) $no_leidos++;
    }
    $result->data_seek(0);
}
?>

<style>
.comentarios-container {
    max-width: 1200px;
    margin: 1rem auto;
    padding: 0 1rem;
}

@media (min-width: 768px) {
    .comentarios-container { padding: 0 2rem; }
}

.header-comentarios {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.header-comentarios h1 {
    font-size: clamp(1.3rem, 5vw, 1.5rem);
    color: #2d3748;
    margin: 0;
}

.btn-volver {
    padding: 0.5rem 1rem;
    background: #edf2f7;
    border-radius: 8px;
    text-decoration: none;
    color: #4a5568;
    font-weight: 600;
    min-height: 44px;
    display: inline-flex;
    align-items: center;
    transition: all 0.3s;
}
.btn-volver:hover {
    background: #e2e8f0;
    transform: translateY(-2px);
}

.mensaje-alerta {
    padding: 0.8rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    font-size: 0.9rem;
}
.mensaje-alerta.exito { background: #c6f6d5; color: #22543d; }
.mensaje-alerta.error { background: #fed7d7; color: #742a2a; }
.mensaje-alerta.info { background: #bee3f8; color: #2a4365; }

.table-responsive {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.tabla-comentarios {
    width: 100%;
    min-width: 900px;
    border-collapse: collapse;
}

.tabla-comentarios th,
.tabla-comentarios td {
    padding: 0.8rem;
    text-align: left;
    border-bottom: 1px solid #e2e8f0;
    vertical-align: top;
    font-size: 0.85rem;
}

.tabla-comentarios th {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.comentario-no-leido {
    background: #fef5e7;
}

.badge-tipo {
    display: inline-block;
    padding: 0.2rem 0.6rem;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
    white-space: nowrap;
}
.badge-bug { background: #f56565; color: white; }
.badge-sugerencia { background: #48bb78; color: white; }
.badge-comentario { background: #4299e1; color: white; }

.acciones {
    display: flex;
    gap: 0.3rem;
    flex-wrap: nowrap;
}

.btn-icono {
    background: none;
    border: 1px solid transparent;
    font-size: 1rem;
    cursor: pointer;
    padding: 0.3rem 0.5rem;
    border-radius: 6px;
    min-height: 36px;
    min-width: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s;
    text-decoration: none;
}
.btn-leer { color: #48bb78; }
.btn-leer:hover { background: #c6f6d5; border-color: #48bb78; }
.btn-eliminar { color: #f56565; }
.btn-eliminar:hover { background: #fed7d7; border-color: #f56565; }

.col-mensaje { max-width: 300px; word-break: break-word; }
.col-url a { color: var(--primary, #667eea); text-decoration: none; }
.col-url a:hover { text-decoration: underline; }

@media (max-width: 768px) {
    .tabla-comentarios th,
    .tabla-comentarios td {
        padding: 0.5rem;
        font-size: 0.8rem;
    }
}
</style>

<div class="comentarios-container">
    <div class="header-comentarios">
        <h1>
            💬 Comentarios de Clientes
            <?php if ($no_leidos > 0): ?>
                <span style="background: #f56565; color: white; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.75rem; vertical-align: middle;">
                    <?php echo intval($no_leidos); ?> nuevos
                </span>
            <?php endif; ?>
        </h1>
        <a href="/admin.php" class="btn-volver">← Volver</a>
    </div>

    <?php if ($mensaje): ?>
        <div class="mensaje-alerta <?php echo htmlspecialchars($tipo_mensaje); ?>">
            <?php echo htmlspecialchars($mensaje); ?>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="tabla-comentarios">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Tipo</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Mensaje</th>
                    <th>URL</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): 
                        $ts = strtotime($row['fecha'] ?? '');
                        $fecha_str = ($ts !== false) ? date('d/m/Y H:i', $ts) : '—';
                        $url_ok = false;
                        $url_row = $row['url'] ?? '';
                        if (!empty($url_row) && (strpos($url_row, '/') === 0 || strpos($url_row, 'http://') === 0 || strpos($url_row, 'https://') === 0)) {
                            $url_ok = true;
                        }
                        $tipo_row = $row['tipo'] ?? 'comentario';
                        $tipo_label = '💬 Comentario';
                        $tipo_class = 'badge-comentario';
                        if ($tipo_row === 'bug') { $tipo_label = '🐞 Error'; $tipo_class = 'badge-bug'; }
                        elseif ($tipo_row === 'sugerencia') { $tipo_label = '💡 Sugerencia'; $tipo_class = 'badge-sugerencia'; }
                    ?>
                    <tr class="<?php echo !empty($row['leido']) ? '' : 'comentario-no-leido'; ?>">
                        <td><?php echo $fecha_str; ?></td>
                        <td>
                            <span class="badge-tipo <?php echo htmlspecialchars($tipo_class); ?>">
                                <?php echo htmlspecialchars($tipo_label); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($row['nombre'] ?: 'Anónimo'); ?></td>
                        <td><?php echo htmlspecialchars($row['email'] ?: '—'); ?></td>
                        <td class="col-mensaje"><?php echo nl2br(htmlspecialchars($row['mensaje'] ?? '')); ?></td>
                        <td class="col-url">
                            <?php if ($url_ok): ?>
                                <a href="<?php echo htmlspecialchars($url_row); ?>" target="_blank" rel="noopener noreferrer">Ver</a>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>
                        <td class="acciones">
                            <?php if (empty($row['leido'])): ?>
                                <form method="POST" action="/reportes/comentarios.php" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="accion" value="marcar_leido">
                                    <input type="hidden" name="id" value="<?php echo intval($row['id']); ?>">
                                    <button type="submit" class="btn-icono btn-leer" title="Marcar como leído">✓</button>
                                </form>
                            <?php endif; ?>
                            <form method="POST" action="/reportes/comentarios.php" style="display:inline;" onsubmit="return confirm('¿Eliminar este comentario?')">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="accion" value="eliminar">
                                <input type="hidden" name="id" value="<?php echo intval($row['id']); ?>">
                                <button type="submit" class="btn-icono btn-eliminar" title="Eliminar">🗑️</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 2rem; color: #a0aec0;">📭 No hay comentarios aún</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
require_once __DIR__ . '/../footer.php';
?>
<?php
// ============================================
// REPORTE: VENTAS (unificado - legacy mantenido)
// Versión 27 Oct 2026
// NOTA: se incluye desde /reportes.php. No abrir/cerrar HTML ni incluir header/footer.
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (!isset($_SESSION['usuario_id'])) {
    echo '<div class="alert error">Sesión expirada</div>';
    return;
}

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$rol_actual = trim($_SESSION['rol'] ?? '');

// ============================================
// PERMISOS (matriz de roles)
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario', 'Vendedor'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    echo '<div class="alert error">Acceso denegado</div>';
    return;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;
if (function_exists('obtenerProveedorId')) {
    $proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
}
if (function_exists('esRolProveedor')) {
    $es_proveedor = esRolProveedor($rol_actual);
}

if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo '<div class="alert error">❌ No se encontró una tienda asociada a tu usuario</div>';
    return;
}

// Símbolo de moneda (fallback)
$moneda_simbolo = '$';
try {
    $stmt_cfg = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'moneda_simbolo' LIMIT 1");
    if ($stmt_cfg) {
        $stmt_cfg->execute();
        $row_cfg = $stmt_cfg->get_result()->fetch_assoc();
        if ($row_cfg && !empty($row_cfg['valor'])) {
            $moneda_simbolo = $row_cfg['valor'];
        }
        $stmt_cfg->close();
    }
} catch (Throwable $e) {
    // fallback '$'
}

$tipo_reporte = isset($_GET['tipo_reporte']) ? $_GET['tipo_reporte'] : 'productos';
$tipos_validos = ['productos', 'pedidos', 'clientes'];
if (!in_array($tipo_reporte, $tipos_validos, true)) {
    $tipo_reporte = 'productos';
}

// ============================================
// FILTROS DE FECHA
// ============================================
$fecha_desde = isset($_GET['fecha_desde']) ? trim($_GET['fecha_desde']) : '';
$fecha_hasta = isset($_GET['fecha_hasta']) ? trim($_GET['fecha_hasta']) : '';

// WHERE base sobre pedidos (con alias p)
$where = ["p.estado_actual = 'entregado'"];
$params = [];
$types = "";

if (!empty($fecha_desde)) {
    $where[] = "p.fecha_pedido >= ?";
    $params[] = $fecha_desde . ' 00:00:00';
    $types .= "s";
}
if (!empty($fecha_hasta)) {
    $where[] = "p.fecha_pedido <= ?";
    $params[] = $fecha_hasta . ' 23:59:59';
    $types .= "s";
}

// Filtro adicional por proveedor si aplica
if ($proveedor_id_usuario > 0) {
    $where[] = "EXISTS (
        SELECT 1 FROM pedido_detalles pd_filter 
        WHERE pd_filter.pedido_id = p.id 
        AND pd_filter.proveedor_id = ?
    )";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
}

$sql_where = "WHERE " . implode(" AND ", $where);

// WHERE para envíos (alias p2, sin EXISTS duplicado)
$where_envio = ["p2.estado_actual = 'entregado'"];
$params_envio = [];
$types_envio = "";
if (!empty($fecha_desde)) {
    $where_envio[] = "p2.fecha_pedido >= ?";
    $params_envio[] = $fecha_desde . ' 00:00:00';
    $types_envio .= "s";
}
if (!empty($fecha_hasta)) {
    $where_envio[] = "p2.fecha_pedido <= ?";
    $params_envio[] = $fecha_hasta . ' 23:59:59';
    $types_envio .= "s";
}
if ($proveedor_id_usuario > 0) {
    $where_envio[] = "EXISTS (
        SELECT 1 FROM pedido_detalles pd_filter 
        WHERE pd_filter.pedido_id = p2.id 
        AND pd_filter.proveedor_id = ?
    )";
    $params_envio[] = $proveedor_id_usuario;
    $types_envio .= "i";
}
$sql_where_envio = "WHERE " . implode(" AND ", $where_envio);

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

$base_url = '/reportes.php?tab=ventas&tipo_reporte=' . urlencode($tipo_reporte);
$totales = [];
$datos = null;
$total_registros = 0;
$total_paginas = 1;

// ============================================
// REPORTE POR PRODUCTOS
// ============================================
if ($tipo_reporte === 'productos') {
    // Contar total (líneas, no pedidos)
    $count_sql = "SELECT COUNT(*) as total 
                  FROM pedidos p
                  JOIN pedido_detalles pd ON p.id = pd.pedido_id
                  JOIN productos pr ON pd.producto_id = pr.id
                  $sql_where";
    $count_stmt = $conn->prepare($count_sql);
    if ($count_stmt) {
        if (!empty($params)) {
            $count_stmt->bind_param($types, ...$params);
        }
        $count_stmt->execute();
        $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $count_stmt->close();
    } else {
        error_log("[reportes_ventas][productos] prepare count: " . $conn->error);
    }

    $total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
    $pagina_actual = min($pagina_actual, $total_paginas);
    $offset = ($pagina_actual - 1) * $por_pagina;

    // Consulta principal
    $sql = "SELECT 
                p.fecha_pedido,
                pr.nombre AS producto_nombre,
                pr.porcentaje_rebaja,
                pr.precio_original,
                pd.cantidad,
                pd.precio_unitario AS precio_venta_unitario,
                pr.precio_costo,
                (pd.cantidad * pd.precio_unitario) AS importe_venta,
                (pd.cantidad * pr.precio_costo) AS importe_costo
            FROM pedidos p
            JOIN pedido_detalles pd ON p.id = pd.pedido_id
            JOIN productos pr ON pd.producto_id = pr.id
            $sql_where
            ORDER BY p.fecha_pedido DESC
            LIMIT ? OFFSET ?";

    $params_select = $params;
    $types_select = $types . 'ii';
    $params_select[] = $por_pagina;
    $params_select[] = $offset;

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types_select, ...$params_select);
        $stmt->execute();
        $datos = $stmt->get_result();
    } else {
        error_log("[reportes_ventas][productos] prepare select: " . $conn->error);
    }

    // Totales de líneas
    $totales_lineas_sql = "SELECT 
            COALESCE(SUM(pd.cantidad), 0) AS total_unidades,
            COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) AS total_venta,
            COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_costo
        FROM pedidos p
        JOIN pedido_detalles pd ON p.id = pd.pedido_id
        JOIN productos pr ON pd.producto_id = pr.id
        $sql_where";
    $stmt_tl = $conn->prepare($totales_lineas_sql);
    if ($stmt_tl) {
        if (!empty($params)) {
            $stmt_tl->bind_param($types, ...$params);
        }
        $stmt_tl->execute();
        $row_tl = $stmt_tl->get_result()->fetch_assoc();
        if ($row_tl) {
            $totales['total_unidades'] = $row_tl['total_unidades'];
            $totales['total_venta'] = $row_tl['total_venta'];
            $totales['total_costo'] = $row_tl['total_costo'];
            $totales['total_ganancia'] = floatval($totales['total_venta']) - floatval($totales['total_costo']);
        }
        $stmt_tl->close();
    }
}

// ============================================
// REPORTE POR PEDIDOS
// ============================================
if ($tipo_reporte === 'pedidos') {
    $count_sql = "SELECT COUNT(DISTINCT p.id) as total FROM pedidos p $sql_where";
    $count_stmt = $conn->prepare($count_sql);
    if ($count_stmt) {
        if (!empty($params)) {
            $count_stmt->bind_param($types, ...$params);
        }
        $count_stmt->execute();
        $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $count_stmt->close();
    }

    $total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
    $pagina_actual = min($pagina_actual, $total_paginas);
    $offset = ($pagina_actual - 1) * $por_pagina;

    $sql = "SELECT 
                p.id AS pedido_id,
                p.fecha_pedido,
                CONCAT(c.nombre, ' ', c.apellidos) AS cliente_nombre,
                c.email AS cliente_email,
                COALESCE((SELECT COUNT(*) FROM pedido_detalles pd2 WHERE pd2.pedido_id = p.id), 0) AS total_items,
                COALESCE((SELECT SUM(pd3.cantidad) FROM pedido_detalles pd3 WHERE pd3.pedido_id = p.id), 0) AS total_unidades,
                COALESCE((SELECT SUM(pd4.cantidad * pd4.precio_unitario) FROM pedido_detalles pd4 WHERE pd4.pedido_id = p.id), 0) AS importe_venta,
                COALESCE((SELECT SUM(pd5.cantidad * pr5.precio_costo) 
                          FROM pedido_detalles pd5 
                          JOIN productos pr5 ON pd5.producto_id = pr5.id 
                          WHERE pd5.pedido_id = p.id), 0) AS importe_costo,
                COALESCE(p.envio, 0) AS importe_envio
            FROM pedidos p
            JOIN clientes c ON p.cliente_id = c.id
            $sql_where
            ORDER BY p.fecha_pedido DESC
            LIMIT ? OFFSET ?";

    $params_select = $params;
    $types_select = $types . 'ii';
    $params_select[] = $por_pagina;
    $params_select[] = $offset;

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types_select, ...$params_select);
        $stmt->execute();
        $datos = $stmt->get_result();
    }

    // Totales
    $totales['total_pedidos'] = $total_registros;

    $totales_lineas_sql = "SELECT 
            COALESCE(SUM(pd.cantidad), 0) AS total_unidades,
            COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) AS total_venta,
            COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_costo
        FROM pedidos p
        JOIN pedido_detalles pd ON p.id = pd.pedido_id
        JOIN productos pr ON pd.producto_id = pr.id
        $sql_where";
    $stmt_tl = $conn->prepare($totales_lineas_sql);
    if ($stmt_tl) {
        if (!empty($params)) {
            $stmt_tl->bind_param($types, ...$params);
        }
        $stmt_tl->execute();
        $row_tl = $stmt_tl->get_result()->fetch_assoc();
        if ($row_tl) {
            $totales['total_unidades'] = $row_tl['total_unidades'];
            $totales['total_venta'] = $row_tl['total_venta'];
            $totales['total_costo'] = $row_tl['total_costo'];
            $totales['total_ganancia'] = floatval($totales['total_venta']) - floatval($totales['total_costo']);
        }
        $stmt_tl->close();
    }

    $totales_envio_sql = "SELECT COALESCE(SUM(p2.envio), 0) AS total_envio FROM pedidos p2 $sql_where_envio";
    $stmt_te = $conn->prepare($totales_envio_sql);
    if ($stmt_te) {
        if (!empty($params_envio)) {
            $stmt_te->bind_param($types_envio, ...$params_envio);
        }
        $stmt_te->execute();
        $row_te = $stmt_te->get_result()->fetch_assoc();
        $totales['total_envio'] = floatval($row_te['total_envio'] ?? 0);
        $stmt_te->close();
    }
}

// ============================================
// REPORTE POR CLIENTES
// ============================================
if ($tipo_reporte === 'clientes') {
    $count_sql = "SELECT COUNT(DISTINCT c.id) as total 
                  FROM clientes c
                  JOIN pedidos p ON c.id = p.cliente_id
                  $sql_where";
    $count_stmt = $conn->prepare($count_sql);
    if ($count_stmt) {
        if (!empty($params)) {
            $count_stmt->bind_param($types, ...$params);
        }
        $count_stmt->execute();
        $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $count_stmt->close();
    }

    $total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
    $pagina_actual = min($pagina_actual, $total_paginas);
    $offset = ($pagina_actual - 1) * $por_pagina;

    $sql = "SELECT 
                c.id,
                CONCAT(c.nombre, ' ', c.apellidos) AS cliente_nombre,
                c.email AS cliente_email,
                COUNT(DISTINCT p.id) AS total_pedidos,
                COALESCE(SUM(pd.cantidad), 0) AS total_unidades,
                COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) AS total_venta,
                COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_costo,
                COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) - COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_ganancia,
                COALESCE((
                    SELECT SUM(p2.envio) 
                    FROM pedidos p2 
                    WHERE p2.cliente_id = c.id AND p2.estado_actual = 'entregado'
                    " . (!empty($fecha_desde) ? " AND p2.fecha_pedido >= '" . $conn->real_escape_string($fecha_desde) . " 00:00:00'" : "") . "
                    " . (!empty($fecha_hasta) ? " AND p2.fecha_pedido <= '" . $conn->real_escape_string($fecha_hasta) . " 23:59:59'" : "") . "
                ), 0) AS total_envio
            FROM clientes c
            JOIN pedidos p ON c.id = p.cliente_id
            LEFT JOIN pedido_detalles pd ON p.id = pd.pedido_id
            LEFT JOIN productos pr ON pd.producto_id = pr.id
            $sql_where
            GROUP BY c.id
            ORDER BY total_venta DESC
            LIMIT ? OFFSET ?";

    $params_select = $params;
    $types_select = $types . 'ii';
    $params_select[] = $por_pagina;
    $params_select[] = $offset;

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param($types_select, ...$params_select);
        $stmt->execute();
        $datos = $stmt->get_result();
    }

    $totales['total_clientes'] = $total_registros;

    $totales_lineas_sql = "SELECT 
            COALESCE(SUM(pd.cantidad), 0) AS total_unidades,
            COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) AS total_venta,
            COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_costo
        FROM clientes c
        JOIN pedidos p ON c.id = p.cliente_id
        LEFT JOIN pedido_detalles pd ON p.id = pd.pedido_id
        LEFT JOIN productos pr ON pd.producto_id = pr.id
        $sql_where";
    $stmt_tl = $conn->prepare($totales_lineas_sql);
    if ($stmt_tl) {
        if (!empty($params)) {
            $stmt_tl->bind_param($types, ...$params);
        }
        $stmt_tl->execute();
        $row_tl = $stmt_tl->get_result()->fetch_assoc();
        if ($row_tl) {
            $totales['total_unidades'] = $row_tl['total_unidades'];
            $totales['total_venta'] = $row_tl['total_venta'];
            $totales['total_costo'] = $row_tl['total_costo'];
            $totales['total_ganancia'] = floatval($totales['total_venta']) - floatval($totales['total_costo']);
        }
        $stmt_tl->close();
    }

    $totales_envio_sql = "SELECT COALESCE(SUM(p2.envio), 0) AS total_envio FROM pedidos p2 $sql_where_envio";
    $stmt_te = $conn->prepare($totales_envio_sql);
    if ($stmt_te) {
        if (!empty($params_envio)) {
            $stmt_te->bind_param($types_envio, ...$params_envio);
        }
        $stmt_te->execute();
        $row_te = $stmt_te->get_result()->fetch_assoc();
        $totales['total_envio'] = floatval($row_te['total_envio'] ?? 0);
        $stmt_te->close();
    }
}

// Base URL para orden y paginación
$base_url_full = $base_url . '&' . http_build_query(array_filter($_GET, function($k) {
    return !in_array($k, ['order_by', 'order_dir', 'pagina'], true);
}, ARRAY_FILTER_USE_KEY));

// Link builder para los tabs (conserva fechas)
$link_tab = function($tipo) use ($fecha_desde, $fecha_hasta) {
    $url = '/reportes.php?tab=ventas&tipo_reporte=' . urlencode($tipo);
    if (!empty($fecha_desde)) $url .= '&fecha_desde=' . urlencode($fecha_desde);
    if (!empty($fecha_hasta)) $url .= '&fecha_hasta=' . urlencode($fecha_hasta);
    return $url;
};
?>

<style>
.reportes-ventas-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.botones-reporte { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.btn-reporte { padding: 0.5rem 1rem; border-radius: 8px; text-decoration: none; font-size: 0.85rem; font-weight: 600; background: #edf2f7; color: #4a5568; transition: all 0.3s; min-height: 44px; display: inline-flex; align-items: center; }
.btn-reporte.active { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; }
.btn-reporte:hover { transform: translateY(-2px); }
.stats-ventas { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.75rem; margin-bottom: 1.5rem; }
@media (min-width: 768px) { .stats-ventas { grid-template-columns: repeat(6, 1fr); gap: 1rem; } }
.stat-card { background: #f8fafc; border-radius: 10px; padding: 0.75rem; text-align: center; border: 1px solid #e2e8f0; }
.stat-card .label { font-size: 0.65rem; color: #718096; text-transform: uppercase; }
.stat-card .value { font-size: clamp(0.9rem, 3vw, 1.1rem); font-weight: 700; color: #2d3748; }
.stat-card .small { font-size: 0.7rem; color: #718096; }
.filtros-ventas { background: #f8fafc; border-radius: 12px; padding: 1rem; margin-bottom: 1.5rem; border: 1px solid #e2e8f0; }
@media (min-width: 768px) { .filtros-ventas { padding: 1.5rem; } }
.filtros-linea { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 0.75rem; }
.filtro-item { flex: 1; min-width: 120px; }
.filtro-item label { display: block; font-size: 0.65rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem; text-transform: uppercase; }
.filtro-item input { width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 16px; min-height: 44px; }
.filtros-botones { display: flex; gap: 0.5rem; flex-shrink: 0; }
.btn-filtro { padding: 0.5rem 1rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.8rem; text-decoration: none; display: inline-flex; align-items: center; justify-content: center; min-height: 44px; }
.btn-filtro-aplicar { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; }
.btn-filtro-limpiar { background: #edf2f7; color: #4a5568; }
.tabla-ventas { overflow-x: auto; width: 100%; -webkit-overflow-scrolling: touch; }
.tabla-ventas table { width: 100%; min-width: 700px; border-collapse: collapse; font-size: 0.75rem; }
@media (min-width: 768px) { .tabla-ventas table { font-size: 0.85rem; min-width: 800px; } }
.tabla-ventas th { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; padding: 0.7rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.7rem; text-transform: uppercase; white-space: nowrap; }
.tabla-ventas td { padding: 0.7rem 0.5rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }
.tabla-ventas tfoot td { background: #f8fafc; font-weight: 600; }
.text-right { text-align: right; }
.text-center { text-align: center; }
.ganancia-positiva { color: #48bb78; font-weight: 600; }
.ganancia-negativa { color: #f56565; font-weight: 600; }
.sin-datos { padding: 2rem; text-align: center; color: #a0aec0; }
.paginacion-container { display: flex; justify-content: center; gap: 0.3rem; flex-wrap: wrap; margin-top: 1.5rem; }
.paginacion-container a, .paginacion-container span { padding: 0.4rem 0.8rem; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500; border: 1px solid #e2e8f0; background: white; color: #374151; min-width: 40px; min-height: 44px; text-align: center; display: inline-flex; align-items: center; justify-content: center; }
.paginacion-container a:hover { background: var(--primary, #667eea); color: white; border-color: var(--primary, #667eea); }
.paginacion-container .active { background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2)); color: white; border-color: var(--primary, #667eea); }
.paginacion-container .disabled { opacity: 0.4; cursor: not-allowed; }
</style>

<div class="reportes-ventas-header">
    <h2 style="margin: 0; font-size: clamp(1.2rem, 4vw, 1.5rem); color: #2d3748;">💰 Reporte de Ventas</h2>
    <div class="botones-reporte">
        <a href="<?php echo htmlspecialchars($link_tab('productos')); ?>" class="btn-reporte <?php echo $tipo_reporte === 'productos' ? 'active' : ''; ?>">📦 Productos</a>
        <a href="<?php echo htmlspecialchars($link_tab('pedidos')); ?>" class="btn-reporte <?php echo $tipo_reporte === 'pedidos' ? 'active' : ''; ?>">📋 Pedidos</a>
        <a href="<?php echo htmlspecialchars($link_tab('clientes')); ?>" class="btn-reporte <?php echo $tipo_reporte === 'clientes' ? 'active' : ''; ?>">👥 Clientes</a>
    </div>
</div>

<!-- ESTADÍSTICAS POR TIPO -->
<?php if ($tipo_reporte === 'productos'): ?>
<div class="stats-ventas">
    <div class="stat-card"><div class="label">Unidades Vendidas</div><div class="value"><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Costo Total</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Venta Total</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Ganancia Total</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></div><div class="small">Margen: <?php echo floatval($totales['total_venta'] ?? 0) > 0 ? round((($totales['total_venta'] - $totales['total_costo']) / $totales['total_venta']) * 100, 2) : 0; ?>%</div></div>
</div>
<?php elseif ($tipo_reporte === 'pedidos'): ?>
<div class="stats-ventas">
    <div class="stat-card"><div class="label">Total Pedidos</div><div class="value"><?php echo number_format(intval($totales['total_pedidos'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Unidades</div><div class="value"><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Costo</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Venta</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Ganancia</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Envío</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_envio'] ?? 0), 2); ?></div></div>
</div>
<?php elseif ($tipo_reporte === 'clientes'): ?>
<div class="stats-ventas">
    <div class="stat-card"><div class="label">Total Clientes</div><div class="value"><?php echo number_format(intval($totales['total_clientes'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Unidades</div><div class="value"><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Costo</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Venta</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Ganancia</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Envío</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_envio'] ?? 0), 2); ?></div></div>
</div>
<?php endif; ?>

<!-- FILTROS -->
<div class="filtros-ventas">
    <form method="GET" action="/reportes.php">
        <input type="hidden" name="tab" value="ventas">
        <input type="hidden" name="tipo_reporte" value="<?php echo htmlspecialchars($tipo_reporte); ?>">
        <div class="filtros-linea">
            <div class="filtro-item"><label>Fecha desde</label><input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($fecha_desde); ?>"></div>
            <div class="filtro-item"><label>Fecha hasta</label><input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($fecha_hasta); ?>"></div>
            <div class="filtros-botones">
                <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button>
                <a href="/reportes.php?tab=ventas&tipo_reporte=<?php echo htmlspecialchars($tipo_reporte); ?>" class="btn-filtro btn-filtro-limpiar">Limpiar</a>
            </div>
        </div>
    </form>
</div>

<!-- TABLAS POR TIPO -->
<div class="tabla-ventas">
    <?php if ($tipo_reporte === 'productos'): ?>
        <table>
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Producto</th>
                    <th>% Reb.</th>
                    <th class="text-right">Cant.</th>
                    <th class="text-right">P. Venta</th>
                    <th class="text-right">P. Costo</th>
                    <th class="text-right">Imp. Venta</th>
                    <th class="text-right">Imp. Costo</th>
                    <th class="text-right">Ganancia</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($datos && $datos->num_rows > 0): ?>
                    <?php while($row = $datos->fetch_assoc()): 
                        $ganancia = floatval($row['importe_venta']) - floatval($row['importe_costo']);
                        $ts = strtotime($row['fecha_pedido'] ?? '');
                        $fecha_str = ($ts !== false) ? date('d/m/Y H:i', $ts) : '—';
                    ?>
                    <tr>
                        <td><?php echo $fecha_str; ?></td>
                        <td><?php echo htmlspecialchars($row['producto_nombre']); ?></td>
                        <td><?php echo intval($row['porcentaje_rebaja'] ?? 0); ?>%</td>
                        <td class="text-right"><?php echo number_format(intval($row['cantidad'])); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['precio_venta_unitario']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['precio_costo']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['importe_venta']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['importe_costo']), 2); ?></td>
                        <td class="text-right <?php echo $ganancia >= 0 ? 'ganancia-positiva' : 'ganancia-negativa'; ?>"><?php echo htmlspecialchars($moneda_simbolo) . number_format($ganancia, 2); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="9" class="sin-datos">📭 No hay ventas entregadas en el período seleccionado</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3"><strong>TOTALES</strong></td>
                    <td class="text-right"><strong><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></strong></td>
                    <td colspan="2"></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></strong></td>
                </tr>
            </tfoot>
        </table>

    <?php elseif ($tipo_reporte === 'pedidos'): ?>
        <table>
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Fecha</th>
                    <th>Cliente</th>
                    <th class="text-right">Items</th>
                    <th class="text-right">Unidades</th>
                    <th class="text-right">Venta</th>
                    <th class="text-right">Costo</th>
                    <th class="text-right">Ganancia</th>
                    <th class="text-right">Envío</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($datos && $datos->num_rows > 0): ?>
                    <?php while($row = $datos->fetch_assoc()): 
                        $ganancia = floatval($row['importe_venta']) - floatval($row['importe_costo']);
                        $ts = strtotime($row['fecha_pedido'] ?? '');
                        $fecha_str = ($ts !== false) ? date('d/m/Y H:i', $ts) : '—';
                    ?>
                    <tr>
                        <td class="text-center">#<?php echo intval($row['pedido_id']); ?></td>
                        <td><?php echo $fecha_str; ?></td>
                        <td><?php echo htmlspecialchars($row['cliente_nombre']); ?><br><small><?php echo htmlspecialchars($row['cliente_email'] ?? ''); ?></small></td>
                        <td class="text-right"><?php echo number_format(intval($row['total_items'])); ?></td>
                        <td class="text-right"><?php echo number_format(intval($row['total_unidades'])); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['importe_venta']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['importe_costo']), 2); ?></td>
                        <td class="text-right <?php echo $ganancia >= 0 ? 'ganancia-positiva' : 'ganancia-negativa'; ?>"><?php echo htmlspecialchars($moneda_simbolo) . number_format($ganancia, 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['importe_envio']), 2); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="9" class="sin-datos">📭 No hay pedidos entregados en el período seleccionado</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3"><strong>TOTALES</strong></td>
                    <td class="text-right"><strong><?php echo number_format(intval($totales['total_pedidos'] ?? 0)); ?></strong></td>
                    <td class="text-right"><strong><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_envio'] ?? 0), 2); ?></strong></td>
                </tr>
            </tfoot>
        </table>

    <?php elseif ($tipo_reporte === 'clientes'): ?>
        <table>
            <thead>
                <tr>
                    <th>Cliente</th>
                    <th>Email</th>
                    <th class="text-right">Pedidos</th>
                    <th class="text-right">Unidades</th>
                    <th class="text-right">Venta</th>
                    <th class="text-right">Costo</th>
                    <th class="text-right">Ganancia</th>
                    <th class="text-right">Envío</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($datos && $datos->num_rows > 0): ?>
                    <?php while($row = $datos->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['cliente_nombre']); ?></td>
                        <td><?php echo htmlspecialchars($row['cliente_email'] ?? ''); ?></td>
                        <td class="text-right"><?php echo number_format(intval($row['total_pedidos'])); ?></td>
                        <td class="text-right"><?php echo number_format(intval($row['total_unidades'])); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['total_venta']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['total_costo']), 2); ?></td>
                        <td class="text-right <?php echo floatval($row['total_ganancia']) >= 0 ? 'ganancia-positiva' : 'ganancia-negativa'; ?>"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['total_ganancia']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['total_envio']), 2); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="sin-datos">📭 No hay clientes con pedidos entregados en el período seleccionado</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="2"><strong>TOTALES</strong></td>
                    <td class="text-right"><strong><?php echo number_format(intval($totales['total_clientes'] ?? 0)); ?></strong></td>
                    <td class="text-right"><strong><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></strong></td>
                    <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_envio'] ?? 0), 2); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    <?php endif; ?>
</div>

<!-- PAGINACIÓN -->
<?php if ($total_paginas > 1): 
    $query_params = $_GET;
?>
<div class="paginacion-container">
    <?php if ($pagina_actual > 1): ?>
        <?php $query_params['pagina'] = 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">«</a>
        <?php $query_params['pagina'] = $pagina_actual - 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
    <?php else: ?>
        <span class="disabled">«</span>
        <span class="disabled">‹</span>
    <?php endif; ?>

    <?php
    $rango = 3;
    $inicio = max(1, $pagina_actual - $rango);
    $fin = min($total_paginas, $pagina_actual + $rango);

    if ($inicio > 1) {
        $query_params['pagina'] = 1;
        echo '<a href="?' . http_build_query($query_params) . '">1</a>';
        if ($inicio > 2) echo '<span>…</span>';
    }

    for ($i = $inicio; $i <= $fin; $i++) {
        if ($i == $pagina_actual) {
            echo '<span class="active">' . $i . '</span>';
        } else {
            $query_params['pagina'] = $i;
            echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
        }
    }

    if ($fin < $total_paginas) {
        if ($fin < $total_paginas - 1) echo '<span>…</span>';
        $query_params['pagina'] = $total_paginas;
        echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
    }
    ?>

    <?php if ($pagina_actual < $total_paginas): ?>
        <?php $query_params['pagina'] = $pagina_actual + 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">›</a>
        <?php $query_params['pagina'] = $total_paginas; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">»</a>
    <?php else: ?>
        <span class="disabled">›</span>
        <span class="disabled">»</span>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php
// ============================================
// REPORTE: VENTAS POR PEDIDOS
// Versión 27 Oct 2026
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (!isset($_SESSION['usuario_id'])) {
    echo '<div class="alert error">Sesión expirada</div>';
    return;
}

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$rol_actual = trim($_SESSION['rol'] ?? '');
$es_super_admin = ($rol_actual === 'Super Admin');

// Símbolo de moneda (fallback seguro)
$moneda_simbolo = '$';
if (isset($config['moneda_simbolo']) && $config['moneda_simbolo'] !== '') {
    $moneda_simbolo = $config['moneda_simbolo'];
} else {
    try {
        $stmt_cfg = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'moneda_simbolo' LIMIT 1");
        if ($stmt_cfg) {
            $stmt_cfg->execute();
            $row_cfg = $stmt_cfg->get_result()->fetch_assoc();
            if ($row_cfg && !empty($row_cfg['valor'])) {
                $moneda_simbolo = $row_cfg['valor'];
            }
            $stmt_cfg->close();
        }
    } catch (Throwable $e) {
        // fallback silencioso
    }
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (function_exists('obtenerProveedorId')) {
    $proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
}
if (function_exists('esRolProveedor')) {
    $es_proveedor = esRolProveedor($rol_actual);
}

if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo '<div class="alert error">❌ No se encontró una tienda asociada a tu usuario</div>';
    return;
}

// ============================================
// ORDENAMIENTO
// ============================================
$columnas_validas = [
    'id' => 'p.id',
    'fecha' => 'p.fecha_pedido',
    'cliente' => 'cliente_nombre',
    'email' => 'c.email',
    'unidades' => 'total_unidades',
    'venta' => 'total_venta',
    'costo' => 'total_costo',
    'ganancia' => 'ganancia',
    'envio' => 'p.envio'
];
$order_by = isset($_GET['order_by']) && isset($columnas_validas[$_GET['order_by']]) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . $columnas_validas[$order_by] . " $order_dir";

// ============================================
// FILTROS BASE (para pedidos)
// ============================================
$where = [];
$params = [];
$types = "";

// 🔥 FILTRO OBLIGATORIO POR PROVEEDOR (en pedido_detalles → productos)
$where_proveedor = "";
$params_proveedor = [];
$types_proveedor = "";
if ($proveedor_id_usuario > 0) {
    $where_proveedor = " AND pd_filter.proveedor_id = ?";
    $params_proveedor[] = $proveedor_id_usuario;
    $types_proveedor .= "i";
}

// Filtros de fecha sobre el pedido
if (!empty($_GET['fecha_desde'])) {
    $where[] = "p.fecha_pedido >= ?";
    $params[] = $_GET['fecha_desde'] . ' 00:00:00';
    $types .= "s";
}
if (!empty($_GET['fecha_hasta'])) {
    $where[] = "p.fecha_pedido <= ?";
    $params[] = $_GET['fecha_hasta'] . ' 23:59:59';
    $types .= "s";
}
$where[] = "p.estado_actual IN ('pagado', 'entregado')";

$sql_where = "WHERE " . implode(" AND ", $where);

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// WHERE COMPLETO SEGÚN ROL
// ============================================
// Si es proveedor → solo pedidos que contengan al menos 1 producto suyo.
// Si es global → todos los pedidos.
if ($proveedor_id_usuario > 0) {
    $sql_where_completo = $sql_where . " AND EXISTS (
        SELECT 1 FROM pedido_detalles pd_filter 
        WHERE pd_filter.pedido_id = p.id 
        AND pd_filter.proveedor_id = ?
    )";
    $params_completo = array_merge($params, [$proveedor_id_usuario]);
    $types_completo = $types . 'i';
} else {
    $sql_where_completo = $sql_where;
    $params_completo = $params;
    $types_completo = $types;
}

// ============================================
// CONTAR TOTAL (usando el WHERE completo)
// ============================================
$count_sql = "SELECT COUNT(DISTINCT p.id) as total FROM pedidos p $sql_where_completo";
$total_registros = 0;
$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($params_completo)) {
        $count_stmt->bind_param($types_completo, ...$params_completo);
    }
    $count_stmt->execute();
    $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $count_stmt->close();
} else {
    error_log("[reportes_ventas_pedidos] prepare count: " . $conn->error);
}

$total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA PRINCIPAL
// ============================================
// Nota: si es proveedor, las SUM de unidades/venta/costo también deben filtrar por sus productos
if ($proveedor_id_usuario > 0) {
    $sql = "SELECT 
                p.id,
                p.fecha_pedido,
                CONCAT(c.nombre, ' ', c.apellidos) AS cliente_nombre,
                c.email,
                COALESCE((
                    SELECT SUM(pd.cantidad) 
                    FROM pedido_detalles pd 
                    WHERE pd.pedido_id = p.id AND pd.proveedor_id = ?
                ), 0) AS total_unidades,
                COALESCE((
                    SELECT SUM(pd.cantidad * pd.precio_unitario) 
                    FROM pedido_detalles pd 
                    WHERE pd.pedido_id = p.id AND pd.proveedor_id = ?
                ), 0) AS total_venta,
                COALESCE((
                    SELECT SUM(pd.cantidad * pr.precio_costo) 
                    FROM pedido_detalles pd 
                    JOIN productos pr ON pd.producto_id = pr.id 
                    WHERE pd.pedido_id = p.id AND pd.proveedor_id = ?
                ), 0) AS total_costo,
                COALESCE(p.envio, 0) AS envio
            FROM pedidos p
            JOIN clientes c ON p.cliente_id = c.id
            $sql_where_completo
            $order_sql
            LIMIT ? OFFSET ?";

    $params_select = array_merge(
        [$proveedor_id_usuario, $proveedor_id_usuario, $proveedor_id_usuario],
        $params_completo,
        [$por_pagina, $offset]
    );
    $types_select = 'iii' . $types_completo . 'ii';
} else {
    $sql = "SELECT 
                p.id,
                p.fecha_pedido,
                CONCAT(c.nombre, ' ', c.apellidos) AS cliente_nombre,
                c.email,
                COALESCE((
                    SELECT SUM(pd.cantidad) 
                    FROM pedido_detalles pd 
                    WHERE pd.pedido_id = p.id
                ), 0) AS total_unidades,
                COALESCE((
                    SELECT SUM(pd.cantidad * pd.precio_unitario) 
                    FROM pedido_detalles pd 
                    WHERE pd.pedido_id = p.id
                ), 0) AS total_venta,
                COALESCE((
                    SELECT SUM(pd.cantidad * pr.precio_costo) 
                    FROM pedido_detalles pd 
                    JOIN productos pr ON pd.producto_id = pr.id 
                    WHERE pd.pedido_id = p.id
                ), 0) AS total_costo,
                COALESCE(p.envio, 0) AS envio
            FROM pedidos p
            JOIN clientes c ON p.cliente_id = c.id
            $sql_where_completo
            $order_sql
            LIMIT ? OFFSET ?";

    $params_select = array_merge($params_completo, [$por_pagina, $offset]);
    $types_select = $types_completo . 'ii';
}

$datos = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param($types_select, ...$params_select);
    $stmt->execute();
    $datos = $stmt->get_result();
} else {
    error_log("[reportes_ventas_pedidos] prepare select: " . $conn->error);
}

// ============================================
// TOTALES (dos queries separadas para evitar inflado por JOIN)
// ============================================
$totales = [
    'total_pedidos' => 0,
    'total_unidades' => 0,
    'total_venta' => 0,
    'total_costo' => 0,
    'total_ganancia' => 0,
    'total_envio' => 0
];

// 1) Totales de líneas (unidades, venta, costo) con filtro por proveedor si aplica
if ($proveedor_id_usuario > 0) {
    $totales_lineas_sql = "SELECT 
                COALESCE(SUM(pd.cantidad), 0) AS total_unidades,
                COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) AS total_venta,
                COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_costo
            FROM pedido_detalles pd
            JOIN pedidos p ON p.id = pd.pedido_id
            JOIN productos pr ON pd.producto_id = pr.id
            $sql_where
            AND pd.proveedor_id = ?";
    $totales_lineas_params = array_merge($params, [$proveedor_id_usuario]);
    $totales_lineas_types = $types . 'i';
} else {
    $totales_lineas_sql = "SELECT 
                COALESCE(SUM(pd.cantidad), 0) AS total_unidades,
                COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) AS total_venta,
                COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_costo
            FROM pedido_detalles pd
            JOIN pedidos p ON p.id = pd.pedido_id
            JOIN productos pr ON pd.producto_id = pr.id
            $sql_where";
    $totales_lineas_params = $params;
    $totales_lineas_types = $types;
}

$stmt_tl = $conn->prepare($totales_lineas_sql);
if ($stmt_tl) {
    if (!empty($totales_lineas_params)) {
        $stmt_tl->bind_param($totales_lineas_types, ...$totales_lineas_params);
    }
    $stmt_tl->execute();
    $row_tl = $stmt_tl->get_result()->fetch_assoc();
    if ($row_tl) {
        $totales['total_unidades'] = $row_tl['total_unidades'];
        $totales['total_venta'] = $row_tl['total_venta'];
        $totales['total_costo'] = $row_tl['total_costo'];
    }
    $stmt_tl->close();
} else {
    error_log("[reportes_ventas_pedidos] prepare totales_lineas: " . $conn->error);
}

// 2) Total de pedidos y envío (sobre pedidos, sin JOIN que infle)
$totales_pedidos_sql = "SELECT 
            COUNT(DISTINCT p.id) AS total_pedidos,
            COALESCE(SUM(p.envio), 0) AS total_envio
        FROM pedidos p
        $sql_where_completo";
$stmt_tp = $conn->prepare($totales_pedidos_sql);
if ($stmt_tp) {
    if (!empty($params_completo)) {
        $stmt_tp->bind_param($types_completo, ...$params_completo);
    }
    $stmt_tp->execute();
    $row_tp = $stmt_tp->get_result()->fetch_assoc();
    if ($row_tp) {
        $totales['total_pedidos'] = $row_tp['total_pedidos'];
        $totales['total_envio'] = $row_tp['total_envio'];
    }
    $stmt_tp->close();
} else {
    error_log("[reportes_ventas_pedidos] prepare totales_pedidos: " . $conn->error);
}

$totales['total_ganancia'] = floatval($totales['total_venta']) - floatval($totales['total_costo']);

// ============================================
// BASE URL PARA PAGINACIÓN Y ORDEN
// ============================================
$base_url = '/reportes.php?tab=ventas&tipo_reporte=pedidos&' . http_build_query(array_filter($_GET, function($k) {
    return !in_array($k, ['order_by', 'order_dir', 'pagina'], true);
}, ARRAY_FILTER_USE_KEY));
?>

<style>
.reportes-ventas-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.botones-reporte { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.btn-reporte { padding: 0.5rem 1rem; border-radius: 8px; text-decoration: none; font-size: 0.85rem; font-weight: 600; background: #edf2f7; color: #4a5568; transition: all 0.3s; min-height: 44px; display: inline-flex; align-items: center; }
.btn-reporte.active { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; }
.btn-reporte:hover { transform: translateY(-2px); }
.stats-ventas { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.75rem; margin-bottom: 1.5rem; }
@media (min-width: 768px) { .stats-ventas { grid-template-columns: repeat(6, 1fr); gap: 1rem; } }
.stat-card { background: #f8fafc; border-radius: 10px; padding: 0.75rem; text-align: center; border: 1px solid #e2e8f0; }
.stat-card .label { font-size: 0.65rem; color: #718096; text-transform: uppercase; }
.stat-card .value { font-size: 1rem; font-weight: 700; color: #2d3748; }
.filtros-ventas { background: #f8fafc; border-radius: 12px; padding: 1rem; margin-bottom: 1.5rem; border: 1px solid #e2e8f0; }
@media (min-width: 768px) { .filtros-ventas { padding: 1.5rem; } }
.filtros-linea { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 0.75rem; }
.filtro-item { flex: 1; min-width: 120px; }
.filtro-item label { display: block; font-size: 0.65rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem; text-transform: uppercase; }
.filtro-item input { width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 16px; min-height: 44px; }
.filtros-botones { display: flex; gap: 0.5rem; flex-shrink: 0; }
.btn-filtro { padding: 0.5rem 1rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.8rem; text-decoration: none; display: inline-flex; align-items: center; min-height: 44px; }
.btn-filtro-aplicar { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; }
.btn-filtro-limpiar { background: #edf2f7; color: #4a5568; }
.tabla-ventas { overflow-x: auto; width: 100%; -webkit-overflow-scrolling: touch; }
.tabla-ventas table { width: 100%; min-width: 800px; border-collapse: collapse; font-size: 0.75rem; }
@media (min-width: 768px) { .tabla-ventas table { font-size: 0.85rem; } }
.tabla-ventas th { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; padding: 0.7rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.7rem; text-transform: uppercase; white-space: nowrap; }
.tabla-ventas th a { color: white; text-decoration: none; display: flex; align-items: center; gap: 4px; }
.tabla-ventas td { padding: 0.7rem 0.5rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }
.text-right { text-align: right; }
.ganancia-positiva { color: #48bb78; font-weight: 600; }
.ganancia-negativa { color: #f56565; font-weight: 600; }
.sin-datos { padding: 2rem; text-align: center; color: #a0aec0; }
.paginacion-container { display: flex; justify-content: center; gap: 0.3rem; flex-wrap: wrap; margin-top: 1.5rem; }
.paginacion-container a, .paginacion-container span { padding: 0.4rem 0.8rem; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500; border: 1px solid #e2e8f0; background: white; color: #374151; min-width: 40px; min-height: 44px; text-align: center; display: inline-flex; align-items: center; justify-content: center; }
.paginacion-container a:hover { background: var(--primary, #667eea); color: white; border-color: var(--primary, #667eea); }
.paginacion-container .active { background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2)); color: white; border-color: var(--primary, #667eea); }
.paginacion-container .disabled { opacity: 0.4; cursor: not-allowed; }
</style>

<div class="reportes-ventas-header">
    <div class="botones-reporte">
        <a href="/reportes.php?tab=ventas&tipo_reporte=productos" class="btn-reporte">📦 Productos</a>
        <a href="/reportes.php?tab=ventas&tipo_reporte=pedidos" class="btn-reporte active">📋 Pedidos</a>
        <a href="/reportes.php?tab=ventas&tipo_reporte=clientes" class="btn-reporte">👥 Clientes</a>
    </div>
</div>

<div class="stats-ventas">
    <div class="stat-card"><div class="label">Total Pedidos</div><div class="value"><?php echo number_format(intval($totales['total_pedidos'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Unidades</div><div class="value"><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Costo</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Venta</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Ganancia</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Envío</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_envio'] ?? 0), 2); ?></div></div>
</div>

<div class="filtros-ventas">
    <form method="GET" action="/reportes.php">
        <input type="hidden" name="tab" value="ventas"><input type="hidden" name="tipo_reporte" value="pedidos">
        <div class="filtros-linea">
            <div class="filtro-item"><label>Fecha desde</label><input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>"></div>
            <div class="filtro-item"><label>Fecha hasta</label><input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>"></div>
            <div class="filtros-botones"><button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button><a href="/reportes.php?tab=ventas&tipo_reporte=pedidos" class="btn-filtro btn-filtro-limpiar">Limpiar</a></div>
        </div>
    </form>
</div>

<div class="tabla-ventas">
    <table>
        <thead>
            <tr>
                <th><a href="<?php echo htmlspecialchars($base_url . '&order_by=id&order_dir=' . (($order_by == 'id' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">ID <?php echo $order_by == 'id' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th><a href="<?php echo htmlspecialchars($base_url . '&order_by=fecha&order_dir=' . (($order_by == 'fecha' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Fecha <?php echo $order_by == 'fecha' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th><a href="<?php echo htmlspecialchars($base_url . '&order_by=cliente&order_dir=' . (($order_by == 'cliente' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Cliente <?php echo $order_by == 'cliente' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th><a href="<?php echo htmlspecialchars($base_url . '&order_by=email&order_dir=' . (($order_by == 'email' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Email <?php echo $order_by == 'email' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=unidades&order_dir=' . (($order_by == 'unidades' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Unidades <?php echo $order_by == 'unidades' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=venta&order_dir=' . (($order_by == 'venta' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Venta <?php echo $order_by == 'venta' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=costo&order_dir=' . (($order_by == 'costo' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Costo <?php echo $order_by == 'costo' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=ganancia&order_dir=' . (($order_by == 'ganancia' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Ganancia <?php echo $order_by == 'ganancia' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=envio&order_dir=' . (($order_by == 'envio' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Envío <?php echo $order_by == 'envio' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
            </tr>
        </thead>
        <tbody>
            <?php if ($datos && $datos->num_rows > 0): ?>
                <?php while($row = $datos->fetch_assoc()): 
                    $ganancia = floatval($row['total_venta']) - floatval($row['total_costo']);
                    $ts = strtotime($row['fecha_pedido'] ?? '');
                    $fecha_str = ($ts !== false) ? date('d/m/Y', $ts) : '—';
                ?>
                <tr>
                    <td class="text-center">#<?php echo intval($row['id']); ?></td>
                    <td><?php echo $fecha_str; ?></td>
                    <td><?php echo htmlspecialchars($row['cliente_nombre']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td class="text-right"><?php echo number_format(intval($row['total_unidades'])); ?></td>
                    <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['total_venta']), 2); ?></td>
                    <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['total_costo']), 2); ?></td>
                    <td class="text-right <?php echo $ganancia >= 0 ? 'ganancia-positiva' : 'ganancia-negativa'; ?>"><?php echo htmlspecialchars($moneda_simbolo) . number_format($ganancia, 2); ?></td>
                    <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['envio']), 2); ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="9" class="sin-datos">📭 No hay pedidos entregados en el período seleccionado</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4"><strong>TOTALES</strong></td>
                <td class="text-right"><strong><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></strong></td>
                <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></strong></td>
                <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></strong></td>
                <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></strong></td>
                <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_envio'] ?? 0), 2); ?></strong></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php if ($total_paginas > 1): 
    $query_params = $_GET;
?>
<div class="paginacion-container">
    <?php if ($pagina_actual > 1): ?>
        <?php $query_params['pagina'] = 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">«</a>
        <?php $query_params['pagina'] = $pagina_actual - 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
    <?php else: ?>
        <span class="disabled">«</span>
        <span class="disabled">‹</span>
    <?php endif; ?>

    <?php
    $rango = 3;
    $inicio = max(1, $pagina_actual - $rango);
    $fin = min($total_paginas, $pagina_actual + $rango);

    if ($inicio > 1) {
        $query_params['pagina'] = 1;
        echo '<a href="?' . http_build_query($query_params) . '">1</a>';
        if ($inicio > 2) echo '<span>…</span>';
    }

    for ($i = $inicio; $i <= $fin; $i++) {
        if ($i == $pagina_actual) {
            echo '<span class="active">' . $i . '</span>';
        } else {
            $query_params['pagina'] = $i;
            echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
        }
    }

    if ($fin < $total_paginas) {
        if ($fin < $total_paginas - 1) echo '<span>…</span>';
        $query_params['pagina'] = $total_paginas;
        echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
    }
    ?>

    <?php if ($pagina_actual < $total_paginas): ?>
        <?php $query_params['pagina'] = $pagina_actual + 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">›</a>
        <?php $query_params['pagina'] = $total_paginas; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">»</a>
    <?php else: ?>
        <span class="disabled">›</span>
        <span class="disabled">»</span>
    <?php endif; ?>
</div>
<?php endif; ?>
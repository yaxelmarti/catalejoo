<?php
// ============================================
// REPORTE: DASHBOARD
// Versión 27 Oct 2026
// NOTA: se incluye desde /reportes.php. No abrir/cerrar HTML ni incluir header/footer.
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (!isset($_SESSION['usuario_id'])) {
    echo '<div class="alert error">Sesión expirada</div>';
    return;
}

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$rol_actual = trim($_SESSION['rol'] ?? '');

// ============================================
// PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    echo '<div class="alert error">Acceso denegado</div>';
    return;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;
if (function_exists('obtenerProveedorId')) {
    $proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
}
if (function_exists('esRolProveedor')) {
    $es_proveedor = esRolProveedor($rol_actual);
}

if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo '<div class="alert error">❌ No se encontró una tienda asociada a tu usuario</div>';
    return;
}

// Símbolo de moneda (fallback)
$moneda_simbolo = '$';
try {
    $stmt_cfg = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'moneda_simbolo' LIMIT 1");
    if ($stmt_cfg) {
        $stmt_cfg->execute();
        $row_cfg = $stmt_cfg->get_result()->fetch_assoc();
        if ($row_cfg && !empty($row_cfg['valor'])) {
            $moneda_simbolo = $row_cfg['valor'];
        }
        $stmt_cfg->close();
    }
} catch (Throwable $e) {
    // fallback a '$'
}

// ============================================
// ESTADÍSTICAS (con filtro por proveedor si aplica)
// ============================================
$stats = [
    'clientes' => ['total' => 0, 'verificados' => 0],
    'carritos' => ['total' => 0, 'pendientes' => 0, 'comprados' => 0, 'cancelados' => 0],
    'productos' => ['total_productos' => 0, 'stock_total' => 0, 'agotados' => 0],
    'ventas_mes' => ['pedidos_mes' => 0, 'ingresos_mes' => 0]
];

// ---------- CLIENTES ----------
// Global: todos los clientes
// Proveedor: solo clientes que han comprado en su tienda
if ($proveedor_id_usuario > 0) {
    $sql_clientes = "SELECT 
        COUNT(DISTINCT c.id) as total,
        SUM(CASE WHEN c.email_verified = 1 THEN 1 ELSE 0 END) as verificados
        FROM clientes c
        WHERE EXISTS (
            SELECT 1 FROM carritos ca
            JOIN carrito_productos cp ON cp.carrito_id = ca.id
            JOIN productos p ON cp.producto_id = p.id
            WHERE ca.cliente_id = c.id 
            AND ca.estado = 'comprado'
            AND p.proveedor_id = ?
        )";
    $stmt_c = $conn->prepare($sql_clientes);
    if ($stmt_c) {
        $stmt_c->bind_param("i", $proveedor_id_usuario);
        $stmt_c->execute();
        $row_c = $stmt_c->get_result()->fetch_assoc();
        if ($row_c) {
            $stats['clientes']['total'] = intval($row_c['total'] ?? 0);
            $stats['clientes']['verificados'] = intval($row_c['verificados'] ?? 0);
        }
        $stmt_c->close();
    }
} else {
    $result = $conn->query("SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN email_verified = 1 THEN 1 ELSE 0 END) as verificados
        FROM clientes");
    if ($result) {
        $row_c = $result->fetch_assoc();
        if ($row_c) {
            $stats['clientes']['total'] = intval($row_c['total'] ?? 0);
            $stats['clientes']['verificados'] = intval($row_c['verificados'] ?? 0);
        }
    }
}

// ---------- CARRITOS ----------
// Global: todos los carritos
// Proveedor: solo carritos que contengan productos suyos
if ($proveedor_id_usuario > 0) {
    $sql_carritos = "SELECT 
        COUNT(DISTINCT ca.id) as total,
        SUM(CASE WHEN ca.estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
        SUM(CASE WHEN ca.estado = 'comprado' THEN 1 ELSE 0 END) as comprados,
        SUM(CASE WHEN ca.estado = 'cancelado' THEN 1 ELSE 0 END) as cancelados
        FROM carritos ca
        WHERE EXISTS (
            SELECT 1 FROM carrito_productos cp
            JOIN productos p ON cp.producto_id = p.id
            WHERE cp.carrito_id = ca.id AND p.proveedor_id = ?
        )";
    $stmt_ca = $conn->prepare($sql_carritos);
    if ($stmt_ca) {
        $stmt_ca->bind_param("i", $proveedor_id_usuario);
        $stmt_ca->execute();
        $row_ca = $stmt_ca->get_result()->fetch_assoc();
        if ($row_ca) {
            $stats['carritos']['total'] = intval($row_ca['total'] ?? 0);
            $stats['carritos']['pendientes'] = intval($row_ca['pendientes'] ?? 0);
            $stats['carritos']['comprados'] = intval($row_ca['comprados'] ?? 0);
            $stats['carritos']['cancelados'] = intval($row_ca['cancelados'] ?? 0);
        }
        $stmt_ca->close();
    }
} else {
    $result = $conn->query("SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
        SUM(CASE WHEN estado = 'comprado' THEN 1 ELSE 0 END) as comprados,
        SUM(CASE WHEN estado = 'cancelado' THEN 1 ELSE 0 END) as cancelados
        FROM carritos");
    if ($result) {
        $row_ca = $result->fetch_assoc();
        if ($row_ca) {
            $stats['carritos']['total'] = intval($row_ca['total'] ?? 0);
            $stats['carritos']['pendientes'] = intval($row_ca['pendientes'] ?? 0);
            $stats['carritos']['comprados'] = intval($row_ca['comprados'] ?? 0);
            $stats['carritos']['cancelados'] = intval($row_ca['cancelados'] ?? 0);
        }
    }
}

// ---------- PRODUCTOS ----------
// Global: todos los productos
// Proveedor: solo sus productos
if ($proveedor_id_usuario > 0) {
    $sql_productos = "SELECT 
        COUNT(*) as total_productos,
        COALESCE(SUM(cantidad), 0) as stock_total,
        SUM(CASE WHEN cantidad = 0 THEN 1 ELSE 0 END) as agotados
        FROM productos
        WHERE proveedor_id = ?";
    $stmt_p = $conn->prepare($sql_productos);
    if ($stmt_p) {
        $stmt_p->bind_param("i", $proveedor_id_usuario);
        $stmt_p->execute();
        $row_p = $stmt_p->get_result()->fetch_assoc();
        if ($row_p) {
            $stats['productos']['total_productos'] = intval($row_p['total_productos'] ?? 0);
            $stats['productos']['stock_total'] = intval($row_p['stock_total'] ?? 0);
            $stats['productos']['agotados'] = intval($row_p['agotados'] ?? 0);
        }
        $stmt_p->close();
    }
} else {
    $result = $conn->query("SELECT 
        COUNT(*) as total_productos,
        COALESCE(SUM(cantidad), 0) as stock_total,
        SUM(CASE WHEN cantidad = 0 THEN 1 ELSE 0 END) as agotados
        FROM productos");
    if ($result) {
        $row_p = $result->fetch_assoc();
        if ($row_p) {
            $stats['productos']['total_productos'] = intval($row_p['total_productos'] ?? 0);
            $stats['productos']['stock_total'] = intval($row_p['stock_total'] ?? 0);
            $stats['productos']['agotados'] = intval($row_p['agotados'] ?? 0);
        }
    }
}

// ---------- VENTAS DEL MES ----------
// Global: todas las ventas del mes
// Proveedor: solo ventas de sus productos del mes
if ($proveedor_id_usuario > 0) {
    $sql_ventas = "SELECT 
        COUNT(DISTINCT ca.id) as pedidos_mes,
        COALESCE(SUM(cp.cantidad * cp.precio_unitario), 0) as ingresos_mes
        FROM carritos ca
        JOIN carrito_productos cp ON ca.id = cp.carrito_id
        JOIN productos p ON cp.producto_id = p.id
        WHERE ca.estado = 'comprado' 
        AND p.proveedor_id = ?
        AND MONTH(ca.fecha_cierre) = MONTH(CURRENT_DATE())
        AND YEAR(ca.fecha_cierre) = YEAR(CURRENT_DATE())";
    $stmt_v = $conn->prepare($sql_ventas);
    if ($stmt_v) {
        $stmt_v->bind_param("i", $proveedor_id_usuario);
        $stmt_v->execute();
        $row_v = $stmt_v->get_result()->fetch_assoc();
        if ($row_v) {
            $stats['ventas_mes']['pedidos_mes'] = intval($row_v['pedidos_mes'] ?? 0);
            $stats['ventas_mes']['ingresos_mes'] = floatval($row_v['ingresos_mes'] ?? 0);
        }
        $stmt_v->close();
    }
} else {
    $result = $conn->query("SELECT 
        COUNT(DISTINCT ca.id) as pedidos_mes,
        COALESCE(SUM(cp.cantidad * cp.precio_unitario), 0) as ingresos_mes
        FROM carritos ca
        JOIN carrito_productos cp ON ca.id = cp.carrito_id
        WHERE ca.estado = 'comprado' 
        AND MONTH(ca.fecha_cierre) = MONTH(CURRENT_DATE())
        AND YEAR(ca.fecha_cierre) = YEAR(CURRENT_DATE())");
    if ($result) {
        $row_v = $result->fetch_assoc();
        if ($row_v) {
            $stats['ventas_mes']['pedidos_mes'] = intval($row_v['pedidos_mes'] ?? 0);
            $stats['ventas_mes']['ingresos_mes'] = floatval($row_v['ingresos_mes'] ?? 0);
        }
    }
}

// ============================================
// PRODUCTOS MÁS VENDIDOS (con filtro por proveedor)
// ============================================
$productos_top = null;

if ($proveedor_id_usuario > 0) {
    $sql_top = "SELECT p.nombre, SUM(cp.cantidad) as total_vendido
        FROM productos p
        JOIN carrito_productos cp ON p.id = cp.producto_id
        JOIN carritos c ON cp.carrito_id = c.id
        WHERE c.estado = 'comprado'
        AND p.proveedor_id = ?
        GROUP BY p.id
        ORDER BY total_vendido DESC
        LIMIT 5";
    $stmt_top = $conn->prepare($sql_top);
    if ($stmt_top) {
        $stmt_top->bind_param("i", $proveedor_id_usuario);
        $stmt_top->execute();
        $productos_top = $stmt_top->get_result();
        $stmt_top->close();
    }
} else {
    $productos_top = $conn->query("
        SELECT p.nombre, SUM(cp.cantidad) as total_vendido
        FROM productos p
        JOIN carrito_productos cp ON p.id = cp.producto_id
        JOIN carritos c ON cp.carrito_id = c.id
        WHERE c.estado = 'comprado'
        GROUP BY p.id
        ORDER BY total_vendido DESC
        LIMIT 5
    ");
}
?>

<style>
.dashboard-header {
    margin-bottom: 1.5rem;
}

.dashboard-header h1 {
    font-size: clamp(1.3rem, 5vw, 1.8rem);
    color: #2d3748;
    margin: 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

@media (min-width: 768px) {
    .stats-grid {
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
    }
}

.stat-card {
    background: white;
    border-radius: 10px;
    padding: clamp(1rem, 3vw, 1.5rem);
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    border-left: 4px solid var(--primary, #667eea);
}

.stat-card .stat-label {
    font-size: 0.75rem;
    color: #718096;
    text-transform: uppercase;
    font-weight: 600;
}

.stat-card .stat-value {
    font-size: clamp(1.5rem, 5vw, 2rem);
    font-weight: 700;
    color: #2d3748;
    margin: 0.3rem 0;
}

.stat-card .stat-detail {
    font-size: 0.8rem;
    color: #48bb78;
}

.report-links {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin: 2rem 0;
}

.report-link {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
    padding: 2rem 1rem;
    border-radius: 10px;
    text-decoration: none;
    text-align: center;
    transition: transform 0.3s;
    min-height: 44px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.report-link:hover {
    transform: translateY(-5px);
}

.report-link h3 {
    margin: 0.5rem 0 0.3rem;
    color: white;
    font-size: 1.1rem;
}

.report-link p {
    margin: 0;
    font-size: 0.85rem;
    opacity: 0.9;
}

.table-container {
    background: white;
    border-radius: 10px;
    padding: clamp(1rem, 3vw, 1.5rem);
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    margin-top: 2rem;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.table-container h3 {
    margin: 0 0 1rem 0;
    color: #2d3748;
}

.table-container table {
    width: 100%;
    min-width: 400px;
    border-collapse: collapse;
    font-size: 0.9rem;
}

.table-container th {
    background: #f8fafc;
    color: #4a5568;
    text-align: left;
    padding: 0.8rem 0.5rem;
    font-size: 0.75rem;
    text-transform: uppercase;
    border-bottom: 2px solid #e2e8f0;
    font-weight: 600;
}

.table-container td {
    padding: 0.8rem 0.5rem;
    border-bottom: 1px solid #edf2f7;
}

.sin-datos {
    padding: 2rem;
    text-align: center;
    color: #a0aec0;
}
</style>

<div class="dashboard-header">
    <h1>📊 Dashboard de Reportes</h1>
</div>

<!-- Accesos rápidos -->
<div class="report-links">
    <?php if (in_array($rol_actual, ['Super Admin', 'Gerente', 'Supervisor', 'Contador'], true)): ?>
    <a href="/reportes.php?tab=clientes" class="report-link">
        <div style="font-size: 2.5rem;">👥</div>
        <h3>Clientes</h3>
        <p>Ver listado completo</p>
    </a>
    <?php endif; ?>
    
    <a href="/reportes.php?tab=carritos" class="report-link">
        <div style="font-size: 2.5rem;">🛒</div>
        <h3>Carritos</h3>
        <p>Gestionar carritos</p>
    </a>
    
    <a href="/admin.php" class="report-link">
        <div style="font-size: 2.5rem;">📦</div>
        <h3>Productos</h3>
        <p>Ir al panel</p>
    </a>
</div>

<!-- Estadísticas (con filtros por proveedor cuando aplica) -->
<div class="stats-grid">
    <?php if (in_array($rol_actual, ['Super Admin', 'Gerente', 'Supervisor', 'Contador'], true)): ?>
    <div class="stat-card">
        <div class="stat-label">Clientes</div>
        <div class="stat-value"><?php echo number_format($stats['clientes']['total']); ?></div>
        <div class="stat-detail"><?php echo number_format($stats['clientes']['verificados']); ?> verificados</div>
    </div>
    <?php endif; ?>
    
    <div class="stat-card">
        <div class="stat-label">Carritos</div>
        <div class="stat-value"><?php echo number_format($stats['carritos']['total']); ?></div>
        <div class="stat-detail">
            <?php echo number_format($stats['carritos']['pendientes']); ?> pendientes | 
            <?php echo number_format($stats['carritos']['comprados']); ?> comprados
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-label">Productos</div>
        <div class="stat-value"><?php echo number_format($stats['productos']['total_productos']); ?></div>
        <div class="stat-detail">
            Stock total: <?php echo number_format($stats['productos']['stock_total']); ?> | 
            <?php echo number_format($stats['productos']['agotados']); ?> agotados
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-label">Ventas del mes</div>
        <div class="stat-value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($stats['ventas_mes']['ingresos_mes'] ?? 0), 2); ?></div>
        <div class="stat-detail"><?php echo number_format(intval($stats['ventas_mes']['pedidos_mes'] ?? 0)); ?> pedidos</div>
    </div>
</div>

<!-- Productos más vendidos -->
<div class="table-container">
    <h3>🏆 Productos más vendidos</h3>
    <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th>Unidades vendidas</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($productos_top && $productos_top->num_rows > 0): ?>
                <?php while($p = $productos_top->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                    <td><strong><?php echo number_format(intval($p['total_vendido'])); ?></strong></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="2" class="sin-datos">📭 No hay ventas registradas</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
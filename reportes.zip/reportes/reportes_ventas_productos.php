<?php
// ============================================
// REPORTE: VENTAS POR PRODUCTOS
// Versión 27 Oct 2026
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ============================================
// VALIDACIONES BÁSICAS (el padre ya validó sesión/permisos)
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    echo '<div class="alert error">Sesión expirada</div>';
    return;
}

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$rol_actual = trim($_SESSION['rol'] ?? '');
$es_super_admin = ($rol_actual === 'Super Admin');

// Símbolo de moneda (fallback seguro)
$moneda_simbolo = '$';
if (isset($config['moneda_simbolo']) && $config['moneda_simbolo'] !== '') {
    $moneda_simbolo = $config['moneda_simbolo'];
} else {
    // Intentar leer de configuracion
    try {
        $stmt_cfg = $conn->prepare("SELECT valor FROM configuracion WHERE clave = 'moneda_simbolo' LIMIT 1");
        if ($stmt_cfg) {
            $stmt_cfg->execute();
            $row_cfg = $stmt_cfg->get_result()->fetch_assoc();
            if ($row_cfg && !empty($row_cfg['valor'])) {
                $moneda_simbolo = $row_cfg['valor'];
            }
            $stmt_cfg->close();
        }
    } catch (Throwable $e) {
        // Silencioso, usar '$'
    }
}

// ============================================
// DETECTAR PROVEEDOR DEL USUARIO
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;

if (function_exists('obtenerProveedorId')) {
    $proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
}
if (function_exists('esRolProveedor')) {
    $es_proveedor = esRolProveedor($rol_actual);
}

// Si es rol de tienda sin tienda → bloquear
if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo '<div class="alert error">❌ No se encontró una tienda asociada a tu usuario</div>';
    return;
}

// ============================================
// ORDENAMIENTO
// ============================================
$columnas_validas = [
    'fecha' => 'p.fecha_pedido',
    'producto' => 'pr.nombre',
    'cantidad' => 'pd.cantidad',
    'precio_venta' => 'pd.precio_unitario',
    'precio_costo' => 'pr.precio_costo',
    'importe_venta' => 'importe_venta',
    'importe_costo' => 'importe_costo',
    'ganancia' => 'ganancia'
];
$order_by = isset($_GET['order_by']) && isset($columnas_validas[$_GET['order_by']]) ? $_GET['order_by'] : 'fecha';
$order_dir = isset($_GET['order_dir']) && strtoupper($_GET['order_dir']) == 'ASC' ? 'ASC' : 'DESC';
$order_sql = "ORDER BY " . $columnas_validas[$order_by] . " $order_dir";

// ============================================
// FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

// 🔥 FILTRO OBLIGATORIO POR PROVEEDOR
if ($proveedor_id_usuario > 0) {
    $where[] = "pr.proveedor_id = ?";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
}

// Filtros de fecha
if (!empty($_GET['fecha_desde'])) {
    $where[] = "p.fecha_pedido >= ?";
    $params[] = $_GET['fecha_desde'] . ' 00:00:00';
    $types .= "s";
}
if (!empty($_GET['fecha_hasta'])) {
    $where[] = "p.fecha_pedido <= ?";
    $params[] = $_GET['fecha_hasta'] . ' 23:59:59';
    $types .= "s";
}

// Solo ventas entregadas
$where[] = "p.estado_actual IN ('pagado', 'entregado')";

$sql_where = "WHERE " . implode(" AND ", $where);

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// CONTAR TOTAL
// ============================================
$count_sql = "SELECT COUNT(*) as total 
              FROM pedidos p 
              JOIN pedido_detalles pd ON p.id = pd.pedido_id 
              JOIN productos pr ON pd.producto_id = pr.id
              $sql_where";
$total_registros = 0;
$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $count_stmt->close();
} else {
    error_log("[reportes_ventas_productos] prepare count: " . $conn->error);
}

$total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA PRINCIPAL (LIMIT/OFFSET parametrizados)
// ============================================
$sql = "SELECT 
            p.fecha_pedido,
            pr.nombre AS producto_nombre,
            pd.cantidad,
            pd.precio_unitario AS precio_venta,
            pr.precio_costo,
            (pd.cantidad * pd.precio_unitario) AS importe_venta,
            (pd.cantidad * pr.precio_costo) AS importe_costo,
            ((pd.cantidad * pd.precio_unitario) - (pd.cantidad * pr.precio_costo)) AS ganancia
        FROM pedidos p
        JOIN pedido_detalles pd ON p.id = pd.pedido_id
        JOIN productos pr ON pd.producto_id = pr.id
        $sql_where
        $order_sql
        LIMIT ? OFFSET ?";

$params_select = $params;
$types_select = $types . 'ii';
$params_select[] = $por_pagina;
$params_select[] = $offset;

$datos = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param($types_select, ...$params_select);
    $stmt->execute();
    $datos = $stmt->get_result();
} else {
    error_log("[reportes_ventas_productos] prepare select: " . $conn->error);
}

// ============================================
// TOTALES (con los mismos filtros)
// ============================================
$totales_sql = "SELECT 
                    COALESCE(SUM(pd.cantidad), 0) AS total_unidades,
                    COALESCE(SUM(pd.cantidad * pd.precio_unitario), 0) AS total_venta,
                    COALESCE(SUM(pd.cantidad * pr.precio_costo), 0) AS total_costo
                FROM pedidos p
                JOIN pedido_detalles pd ON p.id = pd.pedido_id
                JOIN productos pr ON pd.producto_id = pr.id
                $sql_where";
$totales = [
    'total_unidades' => 0,
    'total_venta' => 0,
    'total_costo' => 0,
    'total_ganancia' => 0
];
$totales_stmt = $conn->prepare($totales_sql);
if ($totales_stmt) {
    if (!empty($params)) {
        $totales_stmt->bind_param($types, ...$params);
    }
    $totales_stmt->execute();
    $row_tot = $totales_stmt->get_result()->fetch_assoc();
    if ($row_tot) {
        $totales = $row_tot;
        $totales['total_ganancia'] = floatval($totales['total_venta']) - floatval($totales['total_costo']);
    }
    $totales_stmt->close();
} else {
    error_log("[reportes_ventas_productos] prepare totales: " . $conn->error);
}

// ============================================
// BASE URL PARA PAGINACIÓN Y ORDEN
// ============================================
$base_url = '/reportes.php?tab=ventas&tipo_reporte=productos&' . http_build_query(array_filter($_GET, function($k) {
    return !in_array($k, ['order_by', 'order_dir', 'pagina'], true);
}, ARRAY_FILTER_USE_KEY));
?>

<style>
.reportes-ventas-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
.botones-reporte { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.btn-reporte { padding: 0.5rem 1rem; border-radius: 8px; text-decoration: none; font-size: 0.85rem; font-weight: 600; background: #edf2f7; color: #4a5568; transition: all 0.3s; min-height: 44px; display: inline-flex; align-items: center; }
.btn-reporte.active { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; }
.btn-reporte:hover { transform: translateY(-2px); }
.stats-ventas { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.75rem; margin-bottom: 1.5rem; }
@media (min-width: 768px) { .stats-ventas { grid-template-columns: repeat(4, 1fr); gap: 1rem; } }
.stat-card { background: #f8fafc; border-radius: 10px; padding: 0.75rem; text-align: center; border: 1px solid #e2e8f0; }
.stat-card .label { font-size: 0.65rem; color: #718096; text-transform: uppercase; }
.stat-card .value { font-size: 1.2rem; font-weight: 700; color: #2d3748; }
.stat-card .small { font-size: 0.7rem; color: #718096; }
.filtros-ventas { background: #f8fafc; border-radius: 12px; padding: 1rem; margin-bottom: 1.5rem; border: 1px solid #e2e8f0; }
@media (min-width: 768px) { .filtros-ventas { padding: 1.5rem; } }
.filtros-linea { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 0.75rem; }
.filtro-item { flex: 1; min-width: 120px; }
.filtro-item label { display: block; font-size: 0.65rem; font-weight: 600; color: #4a5568; margin-bottom: 0.2rem; text-transform: uppercase; }
.filtro-item input { width: 100%; padding: 0.5rem; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 16px; min-height: 44px; }
.filtros-botones { display: flex; gap: 0.5rem; flex-shrink: 0; }
.btn-filtro { padding: 0.5rem 1rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 0.8rem; text-decoration: none; display: inline-flex; align-items: center; min-height: 44px; }
.btn-filtro-aplicar { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; }
.btn-filtro-limpiar { background: #edf2f7; color: #4a5568; }
.tabla-ventas { overflow-x: auto; width: 100%; -webkit-overflow-scrolling: touch; }
.tabla-ventas table { width: 100%; min-width: 600px; border-collapse: collapse; font-size: 0.75rem; }
@media (min-width: 768px) { .tabla-ventas table { font-size: 0.85rem; min-width: 800px; } }
.tabla-ventas th { background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%); color: white; padding: 0.7rem 0.5rem; text-align: left; font-weight: 600; font-size: 0.7rem; text-transform: uppercase; white-space: nowrap; }
.tabla-ventas th a { color: white; text-decoration: none; display: flex; align-items: center; gap: 4px; }
.tabla-ventas td { padding: 0.7rem 0.5rem; border-bottom: 1px solid #edf2f7; vertical-align: middle; }
.text-right { text-align: right; }
.ganancia-positiva { color: #48bb78; font-weight: 600; }
.ganancia-negativa { color: #f56565; font-weight: 600; }
.sin-datos { padding: 2rem; text-align: center; color: #a0aec0; }
.paginacion-container { display: flex; justify-content: center; gap: 0.3rem; flex-wrap: wrap; margin-top: 1.5rem; }
.paginacion-container a, .paginacion-container span { padding: 0.4rem 0.8rem; border-radius: 6px; text-decoration: none; font-size: 0.85rem; font-weight: 500; border: 1px solid #e2e8f0; background: white; color: #374151; min-width: 40px; min-height: 44px; text-align: center; display: inline-flex; align-items: center; justify-content: center; }
.paginacion-container a:hover { background: var(--primary, #667eea); color: white; border-color: var(--primary, #667eea); }
.paginacion-container .active { background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2)); color: white; border-color: var(--primary, #667eea); }
.paginacion-container .disabled { opacity: 0.4; cursor: not-allowed; }
</style>

<div class="reportes-ventas-header">
    <div class="botones-reporte">
        <a href="/reportes.php?tab=ventas&tipo_reporte=productos" class="btn-reporte active">📦 Productos</a>
        <a href="/reportes.php?tab=ventas&tipo_reporte=pedidos" class="btn-reporte">📋 Pedidos</a>
        <a href="/reportes.php?tab=ventas&tipo_reporte=clientes" class="btn-reporte">👥 Clientes</a>
    </div>
</div>

<div class="stats-ventas">
    <div class="stat-card"><div class="label">Unidades Vendidas</div><div class="value"><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></div></div>
    <div class="stat-card"><div class="label">Costo Total</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Venta Total</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></div></div>
    <div class="stat-card"><div class="label">Ganancia Total</div><div class="value"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></div><div class="small">Margen: <?php echo floatval($totales['total_venta'] ?? 0) > 0 ? round(($totales['total_ganancia'] / $totales['total_venta']) * 100, 2) : 0; ?>%</div></div>
</div>

<div class="filtros-ventas">
    <form method="GET" action="/reportes.php">
        <input type="hidden" name="tab" value="ventas"><input type="hidden" name="tipo_reporte" value="productos">
        <div class="filtros-linea">
            <div class="filtro-item"><label>Fecha desde</label><input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>"></div>
            <div class="filtro-item"><label>Fecha hasta</label><input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>"></div>
            <div class="filtros-botones"><button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar</button><a href="/reportes.php?tab=ventas&tipo_reporte=productos" class="btn-filtro btn-filtro-limpiar">Limpiar</a></div>
        </div>
    </form>
</div>

<div class="tabla-ventas">
    <table>
        <thead>
            <tr>
                <th><a href="<?php echo htmlspecialchars($base_url . '&order_by=fecha&order_dir=' . (($order_by == 'fecha' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Fecha <?php echo $order_by == 'fecha' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th><a href="<?php echo htmlspecialchars($base_url . '&order_by=producto&order_dir=' . (($order_by == 'producto' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Producto <?php echo $order_by == 'producto' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=cantidad&order_dir=' . (($order_by == 'cantidad' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Cantidad <?php echo $order_by == 'cantidad' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=precio_venta&order_dir=' . (($order_by == 'precio_venta' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Precio Venta <?php echo $order_by == 'precio_venta' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=precio_costo&order_dir=' . (($order_by == 'precio_costo' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Precio Costo <?php echo $order_by == 'precio_costo' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=importe_venta&order_dir=' . (($order_by == 'importe_venta' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Importe Venta <?php echo $order_by == 'importe_venta' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=importe_costo&order_dir=' . (($order_by == 'importe_costo' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Importe Costo <?php echo $order_by == 'importe_costo' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                <th class="text-right"><a href="<?php echo htmlspecialchars($base_url . '&order_by=ganancia&order_dir=' . (($order_by == 'ganancia' && $order_dir == 'ASC') ? 'DESC' : 'ASC')); ?>">Ganancia <?php echo $order_by == 'ganancia' ? ($order_dir == 'ASC' ? '▲' : '▼') : ''; ?></a></th>
            </tr>
        </thead>
        <tbody>
            <?php if ($datos && $datos->num_rows > 0): ?>
                <?php while($row = $datos->fetch_assoc()): 
                    $ts = strtotime($row['fecha_pedido'] ?? '');
                    $fecha_str = ($ts !== false) ? date('d/m/Y H:i', $ts) : '—';
                ?>
                    <tr>
                        <td><?php echo $fecha_str; ?></td>
                        <td><?php echo htmlspecialchars($row['producto_nombre']); ?></td>
                        <td class="text-right"><?php echo number_format(intval($row['cantidad'])); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['precio_venta']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['precio_costo']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['importe_venta']), 2); ?></td>
                        <td class="text-right"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['importe_costo']), 2); ?></td>
                        <td class="text-right <?php echo floatval($row['ganancia']) >= 0 ? 'ganancia-positiva' : 'ganancia-negativa'; ?>"><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($row['ganancia']), 2); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="8" class="sin-datos">📭 No hay ventas entregadas en el período seleccionado</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2"><strong>TOTALES</strong></td>
                <td class="text-right"><strong><?php echo number_format(intval($totales['total_unidades'] ?? 0)); ?></strong></td>
                <td class="text-right"><strong></strong></td>
                <td class="text-right"><strong></strong></td>
                <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_venta'] ?? 0), 2); ?></strong></td>
                <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_costo'] ?? 0), 2); ?></strong></td>
                <td class="text-right"><strong><?php echo htmlspecialchars($moneda_simbolo) . number_format(floatval($totales['total_ganancia'] ?? 0), 2); ?></strong></td>
            </tr>
        </tfoot>
    </table>
</div>

<?php if ($total_paginas > 1): 
    $query_params = $_GET;
?>
<div class="paginacion-container">
    <?php if ($pagina_actual > 1): ?>
        <?php $query_params['pagina'] = 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">«</a>
        <?php $query_params['pagina'] = $pagina_actual - 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
    <?php else: ?>
        <span class="disabled">«</span>
        <span class="disabled">‹</span>
    <?php endif; ?>

    <?php
    $rango = 3;
    $inicio = max(1, $pagina_actual - $rango);
    $fin = min($total_paginas, $pagina_actual + $rango);

    if ($inicio > 1) {
        $query_params['pagina'] = 1;
        echo '<a href="?' . http_build_query($query_params) . '">1</a>';
        if ($inicio > 2) echo '<span>…</span>';
    }

    for ($i = $inicio; $i <= $fin; $i++) {
        if ($i == $pagina_actual) {
            echo '<span class="active">' . $i . '</span>';
        } else {
            $query_params['pagina'] = $i;
            echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
        }
    }

    if ($fin < $total_paginas) {
        if ($fin < $total_paginas - 1) echo '<span>…</span>';
        $query_params['pagina'] = $total_paginas;
        echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
    }
    ?>

    <?php if ($pagina_actual < $total_paginas): ?>
        <?php $query_params['pagina'] = $pagina_actual + 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">›</a>
        <?php $query_params['pagina'] = $total_paginas; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">»</a>
    <?php else: ?>
        <span class="disabled">›</span>
        <span class="disabled">»</span>
    <?php endif; ?>
</div>
<?php endif; ?>
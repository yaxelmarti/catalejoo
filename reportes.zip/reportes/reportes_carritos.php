<?php
// ============================================
// REPORTE: CARRITOS
// Versión 27 Oct 2026
// NOTA: se incluye desde /reportes.php. No abrir/cerrar HTML ni incluir header/footer.
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if (!isset($_SESSION['usuario_id'])) {
    echo '<div class="alert error">Sesión expirada</div>';
    return;
}

$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$rol_actual = trim($_SESSION['rol'] ?? '');

// ============================================
// PERMISOS
// ============================================
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario'];
if (!in_array($rol_actual, $roles_permitidos, true)) {
    echo '<div class="alert error">Acceso denegado</div>';
    return;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$proveedor_id_usuario = 0;
$es_proveedor = false;
if (function_exists('obtenerProveedorId')) {
    $proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
}
if (function_exists('esRolProveedor')) {
    $es_proveedor = esRolProveedor($rol_actual);
}

if ($es_proveedor && $proveedor_id_usuario == 0) {
    echo '<div class="alert error">❌ No se encontró una tienda asociada a tu usuario</div>';
    return;
}

// ============================================
// PROCESAR FILTROS
// ============================================
$where = [];
$params = [];
$types = "";

// 🔥 FILTRO OBLIGATORIO POR PROVEEDOR
if ($proveedor_id_usuario > 0) {
    $where[] = "ca.proveedor_id = ?";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
}

if (!empty($_GET['carrito_id'])) {
    $where[] = "ca.id = ?";
    $params[] = intval($_GET['carrito_id']);
    $types .= "i";
}

if (!empty($_GET['cliente'])) {
    $where[] = "(c.nombre LIKE ? OR c.apellidos LIKE ? OR c.email LIKE ?)";
    $search = "%" . $_GET['cliente'] . "%";
    $params[] = $search;
    $params[] = $search;
    $params[] = $search;
    $types .= "sss";
}

if (!empty($_GET['estado'])) {
    $where[] = "ca.estado = ?";
    $params[] = $_GET['estado'];
    $types .= "s";
}

if (!empty($_GET['fecha_desde'])) {
    $where[] = "DATE(ca.fecha_inicio) >= ?";
    $params[] = $_GET['fecha_desde'];
    $types .= "s";
}
if (!empty($_GET['fecha_hasta'])) {
    $where[] = "DATE(ca.fecha_inicio) <= ?";
    $params[] = $_GET['fecha_hasta'];
    $types .= "s";
}

if (!empty($_GET['monto_min'])) {
    $where[] = "(SELECT COALESCE(SUM(cantidad * precio_unitario), 0) FROM carrito_productos WHERE carrito_id = ca.id) >= ?";
    $params[] = floatval($_GET['monto_min']);
    $types .= "d";
}
if (!empty($_GET['monto_max'])) {
    $where[] = "(SELECT COALESCE(SUM(cantidad * precio_unitario), 0) FROM carrito_productos WHERE carrito_id = ca.id) <= ?";
    $params[] = floatval($_GET['monto_max']);
    $types .= "d";
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// CONTAR TOTAL
// ============================================
$count_sql = "SELECT COUNT(*) as total FROM carritos ca JOIN clientes c ON ca.cliente_id = c.id $sql_where";
$total_registros = 0;
$count_stmt = $conn->prepare($count_sql);
if ($count_stmt) {
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total_registros = intval($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $count_stmt->close();
} else {
    error_log("[reportes_carritos] prepare count: " . $conn->error);
}

$total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA PRINCIPAL (LIMIT/OFFSET parametrizados)
// ============================================
$sql = "SELECT 
            ca.*,
            c.nombre,
            c.apellidos,
            c.email,
            (SELECT COUNT(*) FROM carrito_productos WHERE carrito_id = ca.id) as total_productos,
            (SELECT COALESCE(SUM(cantidad), 0) FROM carrito_productos WHERE carrito_id = ca.id) as total_items,
            (SELECT COALESCE(SUM(cantidad * precio_unitario), 0) FROM carrito_productos WHERE carrito_id = ca.id) as total_monto
        FROM carritos ca
        JOIN clientes c ON ca.cliente_id = c.id
        $sql_where
        ORDER BY ca.fecha_inicio DESC
        LIMIT ? OFFSET ?";

$params_select = $params;
$types_select = $types . 'ii';
$params_select[] = $por_pagina;
$params_select[] = $offset;

$carritos = null;
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param($types_select, ...$params_select);
    $stmt->execute();
    $carritos = $stmt->get_result();
} else {
    error_log("[reportes_carritos] prepare select: " . $conn->error);
}

// ============================================
// ESTADÍSTICAS (con los mismos filtros)
// ============================================
$stats = [
    'total' => 0,
    'pendientes' => 0,
    'comprados' => 0,
    'cancelados' => 0,
    'expirados' => 0
];

$stats_sql = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN ca.estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes,
    SUM(CASE WHEN ca.estado = 'comprado' THEN 1 ELSE 0 END) as comprados,
    SUM(CASE WHEN ca.estado = 'cancelado' THEN 1 ELSE 0 END) as cancelados,
    SUM(CASE WHEN ca.estado = 'expirado' THEN 1 ELSE 0 END) as expirados
    FROM carritos ca
    JOIN clientes c ON ca.cliente_id = c.id
    $sql_where";
$stats_stmt = $conn->prepare($stats_sql);
if ($stats_stmt) {
    if (!empty($params)) {
        $stats_stmt->bind_param($types, ...$params);
    }
    $stats_stmt->execute();
    $row_stats = $stats_stmt->get_result()->fetch_assoc();
    if ($row_stats) {
        $stats = [
            'total' => intval($row_stats['total'] ?? 0),
            'pendientes' => intval($row_stats['pendientes'] ?? 0),
            'comprados' => intval($row_stats['comprados'] ?? 0),
            'cancelados' => intval($row_stats['cancelados'] ?? 0),
            'expirados' => intval($row_stats['expirados'] ?? 0),
        ];
    }
    $stats_stmt->close();
} else {
    error_log("[reportes_carritos] prepare stats: " . $conn->error);
}
?>

<style>
.carritos-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.carritos-header h1 {
    font-size: clamp(1.3rem, 5vw, 1.8rem);
    color: #2d3748;
    margin: 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}
@media (min-width: 640px) {
    .stats-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (min-width: 1024px) {
    .stats-grid { grid-template-columns: repeat(5, 1fr); gap: 1rem; }
}

.stat-card {
    background: white;
    border-radius: 8px;
    padding: 0.75rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    text-align: center;
    border-top: 3px solid transparent;
}
.stat-card.pendiente { border-top-color: #ecc94b; }
.stat-card.comprado { border-top-color: #48bb78; }
.stat-card.cancelado { border-top-color: #f56565; }
.stat-card.expirado { border-top-color: #a0aec0; }

.stat-card .label {
    font-size: 0.7rem;
    color: #718096;
    text-transform: uppercase;
}
.stat-card .value {
    font-size: clamp(1.2rem, 4vw, 1.5rem);
    font-weight: 600;
    color: #2d3748;
}

.filtros-card {
    background: #f8fafc;
    border-radius: 8px;
    padding: clamp(1rem, 3vw, 1.5rem);
    margin-bottom: 1.5rem;
    border: 1px solid #e2e8f0;
}

.filtros-row {
    display: grid;
    grid-template-columns: 1fr;
    gap: 0.8rem;
    margin-bottom: 1rem;
}
@media (min-width: 640px) {
    .filtros-row { grid-template-columns: repeat(2, 1fr); }
}
@media (min-width: 1024px) {
    .filtros-row { grid-template-columns: repeat(4, 1fr); }
}

.filtro-item label {
    display: block;
    font-size: 0.7rem;
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 0.2rem;
    text-transform: uppercase;
}

.filtro-item input,
.filtro-item select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    font-size: 16px;
    min-height: 44px;
}

.filtros-acciones {
    display: flex;
    gap: 0.5rem;
    justify-content: flex-end;
    margin-top: 1rem;
    flex-wrap: wrap;
}

.btn-filtro {
    padding: 0.5rem 1.2rem;
    border: none;
    border-radius: 6px;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.9rem;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 44px;
}

.btn-filtro-aplicar {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
}
.btn-filtro-limpiar {
    background: #edf2f7;
    color: #4a5568;
}

.tabla-reporte {
    background: white;
    border-radius: 8px;
    padding: 0.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.tabla-reporte table {
    width: 100%;
    min-width: 800px;
    border-collapse: collapse;
    font-size: 0.85rem;
}

.tabla-reporte th {
    background: linear-gradient(135deg, var(--primary, #667eea) 0%, var(--secondary, #764ba2) 100%);
    color: white;
    padding: 0.8rem;
    text-align: left;
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: uppercase;
    white-space: nowrap;
}

.tabla-reporte td {
    padding: 0.8rem;
    border-bottom: 1px solid #edf2f7;
}

.badge-estado {
    padding: 0.2rem 0.5rem;
    border-radius: 20px;
    font-size: 0.75rem;
    color: white;
    display: inline-block;
    white-space: nowrap;
}
.badge-pendiente { background: #ecc94b; }
.badge-comprado { background: #48bb78; }
.badge-cancelado { background: #f56565; }
.badge-expirado { background: #a0aec0; }

.btn-accion {
    background: #667eea;
    color: white;
    padding: 0.3rem 0.8rem;
    border-radius: 4px;
    text-decoration: none;
    font-size: 0.8rem;
    display: inline-flex;
    align-items: center;
    min-height: 32px;
}
.btn-accion:hover { background: #5a67d8; }

.text-right { text-align: right; }
.text-center { text-align: center; }
.sin-datos { padding: 2rem; color: #a0aec0; text-align: center; }

.paginacion-container {
    display: flex;
    justify-content: center;
    gap: 0.3rem;
    flex-wrap: wrap;
    margin-top: 1.5rem;
}
.paginacion-container a,
.paginacion-container span {
    padding: 0.4rem 0.8rem;
    border-radius: 6px;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 500;
    border: 1px solid #e2e8f0;
    background: white;
    color: #374151;
    min-width: 40px;
    min-height: 44px;
    text-align: center;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
.paginacion-container a:hover {
    background: var(--primary, #667eea);
    color: white;
    border-color: var(--primary, #667eea);
}
.paginacion-container .active {
    background: linear-gradient(135deg, var(--primary, #667eea), var(--secondary, #764ba2));
    color: white;
    border-color: var(--primary, #667eea);
}
.paginacion-container .disabled {
    opacity: 0.4;
    cursor: not-allowed;
}

@media (max-width: 640px) {
    .filtros-acciones {
        flex-direction: column;
    }
    .btn-filtro {
        width: 100%;
    }
}
</style>

<div class="carritos-header">
    <h1>🛒 Reporte de Carritos</h1>
</div>

<!-- ESTADÍSTICAS (con filtros aplicados) -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="label">Total Carritos</div>
        <div class="value"><?php echo number_format($stats['total']); ?></div>
    </div>
    <div class="stat-card pendiente">
        <div class="label">Pendientes</div>
        <div class="value"><?php echo number_format($stats['pendientes']); ?></div>
    </div>
    <div class="stat-card comprado">
        <div class="label">Completados</div>
        <div class="value"><?php echo number_format($stats['comprados']); ?></div>
    </div>
    <div class="stat-card cancelado">
        <div class="label">Cancelados</div>
        <div class="value"><?php echo number_format($stats['cancelados']); ?></div>
    </div>
    <div class="stat-card expirado">
        <div class="label">Expirados</div>
        <div class="value"><?php echo number_format($stats['expirados']); ?></div>
    </div>
</div>

<!-- FILTROS -->
<div class="filtros-card">
    <form method="GET" action="/reportes.php">
        <input type="hidden" name="tab" value="carritos">
        <div class="filtros-row">
            <div class="filtro-item">
                <label>ID Carrito</label>
                <input type="number" name="carrito_id" value="<?php echo htmlspecialchars($_GET['carrito_id'] ?? ''); ?>" placeholder="Ej: 123" min="0">
            </div>
            <div class="filtro-item">
                <label>Cliente</label>
                <input type="text" name="cliente" value="<?php echo htmlspecialchars($_GET['cliente'] ?? ''); ?>" placeholder="Nombre o email">
            </div>
            <div class="filtro-item">
                <label>Estado</label>
                <select name="estado">
                    <option value="">Todos</option>
                    <option value="pendiente" <?php echo ($_GET['estado'] ?? '') === 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                    <option value="comprado" <?php echo ($_GET['estado'] ?? '') === 'comprado' ? 'selected' : ''; ?>>Comprado</option>
                    <option value="cancelado" <?php echo ($_GET['estado'] ?? '') === 'cancelado' ? 'selected' : ''; ?>>Cancelado</option>
                    <option value="expirado" <?php echo ($_GET['estado'] ?? '') === 'expirado' ? 'selected' : ''; ?>>Expirado</option>
                </select>
            </div>
            <div class="filtro-item">
                <label>Fecha desde</label>
                <input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>">
            </div>
        </div>

        <div class="filtros-row">
            <div class="filtro-item">
                <label>Fecha hasta</label>
                <input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>">
            </div>
            <div class="filtro-item">
                <label>Monto mínimo</label>
                <input type="number" step="0.01" min="0" name="monto_min" value="<?php echo htmlspecialchars($_GET['monto_min'] ?? ''); ?>" placeholder="0.00">
            </div>
            <div class="filtro-item">
                <label>Monto máximo</label>
                <input type="number" step="0.01" min="0" name="monto_max" value="<?php echo htmlspecialchars($_GET['monto_max'] ?? ''); ?>" placeholder="0.00">
            </div>
            <div class="filtro-item"><!-- Espacio --></div>
        </div>

        <div class="filtros-acciones">
            <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar Filtros</button>
            <a href="/reportes.php?tab=carritos" class="btn-filtro btn-filtro-limpiar">Limpiar Filtros</a>
        </div>
    </form>
</div>

<!-- TABLA -->
<div class="tabla-reporte">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Email</th>
                <th>Inicio</th>
                <th>Expira</th>
                <th>Estado</th>
                <th>Prod.</th>
                <th>Items</th>
                <th>Total</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($carritos && $carritos->num_rows > 0): ?>
                <?php while($c = $carritos->fetch_assoc()): 
                    $estado_class = '';
                    if ($c['estado'] == 'pendiente') $estado_class = 'badge-pendiente';
                    elseif ($c['estado'] == 'comprado') $estado_class = 'badge-comprado';
                    elseif ($c['estado'] == 'cancelado') $estado_class = 'badge-cancelado';
                    elseif ($c['estado'] == 'expirado') $estado_class = 'badge-expirado';

                    $ts_inicio = strtotime($c['fecha_inicio'] ?? '');
                    $fecha_inicio_str = ($ts_inicio !== false) ? date('d/m/Y', $ts_inicio) : '—';
                    
                    $fecha_expiracion_str = '-';
                    if (!empty($c['fecha_expiracion'])) {
                        $ts_exp = strtotime($c['fecha_expiracion']);
                        if ($ts_exp !== false) {
                            $fecha_expiracion_str = date('d/m/Y', $ts_exp);
                        }
                    }
                ?>
                <tr>
                    <td>#<?php echo intval($c['id']); ?></td>
                    <td><?php echo htmlspecialchars(trim(($c['nombre'] ?? '') . ' ' . ($c['apellidos'] ?? ''))); ?></td>
                    <td><?php echo htmlspecialchars($c['email'] ?? ''); ?></td>
                    <td><?php echo $fecha_inicio_str; ?></td>
                    <td><?php echo $fecha_expiracion_str; ?></td>
                    <td><span class="badge-estado <?php echo $estado_class; ?>"><?php echo htmlspecialchars(ucfirst($c['estado'] ?? '')); ?></span></td>
                    <td class="text-center"><?php echo intval($c['total_productos'] ?? 0); ?></td>
                    <td class="text-center"><?php echo intval($c['total_items'] ?? 0); ?></td>
                    <td class="text-right">$<?php echo number_format(floatval($c['total_monto'] ?? 0), 2); ?></td>
                    <td>
                        <a href="/admin/detalle_carrito.php?id=<?php echo intval($c['id']); ?>" class="btn-accion">Ver</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="10" class="sin-datos">📭 No hay carritos para mostrar con los filtros seleccionados</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- PAGINACIÓN -->
<?php if ($total_paginas > 1): 
    $query_params = $_GET;
?>
<div class="paginacion-container">
    <?php if ($pagina_actual > 1): ?>
        <?php $query_params['pagina'] = 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">«</a>
        <?php $query_params['pagina'] = $pagina_actual - 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
    <?php else: ?>
        <span class="disabled">«</span>
        <span class="disabled">‹</span>
    <?php endif; ?>

    <?php
    $rango = 3;
    $inicio = max(1, $pagina_actual - $rango);
    $fin = min($total_paginas, $pagina_actual + $rango);

    if ($inicio > 1) {
        $query_params['pagina'] = 1;
        echo '<a href="?' . http_build_query($query_params) . '">1</a>';
        if ($inicio > 2) echo '<span>…</span>';
    }

    for ($i = $inicio; $i <= $fin; $i++) {
        if ($i == $pagina_actual) {
            echo '<span class="active">' . $i . '</span>';
        } else {
            $query_params['pagina'] = $i;
            echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
        }
    }

    if ($fin < $total_paginas) {
        if ($fin < $total_paginas - 1) echo '<span>…</span>';
        $query_params['pagina'] = $total_paginas;
        echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
    }
    ?>

    <?php if ($pagina_actual < $total_paginas): ?>
        <?php $query_params['pagina'] = $pagina_actual + 1; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">›</a>
        <?php $query_params['pagina'] = $total_paginas; ?>
        <a href="?<?php echo http_build_query($query_params); ?>">»</a>
    <?php else: ?>
        <span class="disabled">›</span>
        <span class="disabled">»</span>
    <?php endif; ?>
</div>
<?php endif; ?>
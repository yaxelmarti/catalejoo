<?php
// ============================================
// REPORTE DE PRODUCTOS - /reportes/reporte_productos.php
// Versión 27 Oct 2026
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ✅ Orden correcto
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/proveedor_utils.php';
require_once __DIR__ . '/../header.php';

// ============================================
// VALIDAR SESIÓN
// ============================================
if (!isset($_SESSION['usuario_id'])) {
    header('Location: /login.php');
    exit;
}

// ============================================
// VERIFICACIÓN DE PERMISOS
// ============================================
$rol_actual = trim($_SESSION['rol'] ?? '');
$roles_permitidos = ['Super Admin', 'Gerente', 'Supervisor', 'Contador', 'Proveedor', 'Inventario'];
$puede_gestionar = in_array($rol_actual, $roles_permitidos, true);
$es_supervisor = ($rol_actual === 'Supervisor');
$es_contador = ($rol_actual === 'Contador');

if (!$puede_gestionar && !$es_supervisor && !$es_contador) {
    error_log("[reporte_productos] Permiso denegado. Rol: $rol_actual, usuario: " . intval($_SESSION['usuario_id'] ?? 0));
    header('Location: /admin.php?error=permiso');
    exit;
}

// ============================================
// DETECTAR PROVEEDOR
// ============================================
$usuario_id_actual = intval($_SESSION['usuario_id'] ?? 0);
$proveedor_id_usuario = intval(obtenerProveedorId($conn, $usuario_id_actual, $rol_actual));
$es_proveedor = esRolProveedor($rol_actual);

if ($es_proveedor && $proveedor_id_usuario == 0) {
    $_SESSION['mensaje'] = '❌ No se encontró una tienda asociada a tu usuario';
    $_SESSION['tipo_mensaje'] = 'error';
    header('Location: /admin.php');
    exit;
}

if ($proveedor_id_usuario > 0) {
    $stmt_check = $conn->prepare("SELECT id FROM proveedores WHERE id = ? AND activo = 1 LIMIT 1");
    if ($stmt_check) {
        $stmt_check->bind_param("i", $proveedor_id_usuario);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows === 0) {
            $stmt_check->close();
            $_SESSION['mensaje'] = '❌ Tu tienda no está activa';
            $_SESSION['tipo_mensaje'] = 'error';
            header('Location: /admin.php');
            exit;
        }
        $stmt_check->close();
    }
}

$es_super_admin = ($rol_actual === 'Super Admin');

// ============================================
// PROCESAR FILTROS (parametrizados)
// ============================================
$where = [];
$params = [];
$types = "";

// Filtrar por proveedor del usuario
if ($proveedor_id_usuario > 0) {
    $where[] = "p.proveedor_id = ?";
    $params[] = $proveedor_id_usuario;
    $types .= "i";
} elseif ($es_super_admin && !empty($_GET['proveedor_id'])) {
    // Super Admin puede filtrar por proveedor específico
    $where[] = "p.proveedor_id = ?";
    $params[] = intval($_GET['proveedor_id']);
    $types .= "i";
}

if (!empty($_GET['nombre'])) {
    $where[] = "p.nombre LIKE ?";
    $params[] = "%" . $_GET['nombre'] . "%";
    $types .= "s";
}

if (!empty($_GET['categoria'])) {
    $where[] = "p.categoria_id = ?";
    $params[] = intval($_GET['categoria']);
    $types .= "i";
}

if (isset($_GET['cantidad']) && $_GET['cantidad'] !== '' && isset($_GET['cantidad_operador'])) {
    $operador = $_GET['cantidad_operador'];
    if (in_array($operador, ['=', '<', '>'], true)) {
        $where[] = "p.cantidad $operador ?";
        $params[] = intval($_GET['cantidad']);
        $types .= "i";
    }
}

if (isset($_GET['precio_costo']) && $_GET['precio_costo'] !== '' && isset($_GET['costo_operador'])) {
    $operador = $_GET['costo_operador'];
    if (in_array($operador, ['=', '<', '>'], true)) {
        $where[] = "p.precio_costo $operador ?";
        $params[] = floatval($_GET['precio_costo']);
        $types .= "d";
    }
}

if (isset($_GET['precio_venta']) && $_GET['precio_venta'] !== '' && isset($_GET['venta_operador'])) {
    $operador = $_GET['venta_operador'];
    if (in_array($operador, ['=', '<', '>'], true)) {
        $where[] = "p.precio $operador ?";
        $params[] = floatval($_GET['precio_venta']);
        $types .= "d";
    }
}

// Filtro de fecha
if (!empty($_GET['fecha_tipo'])) {
    switch ($_GET['fecha_tipo']) {
        case 'rango':
            if (!empty($_GET['fecha_desde'])) {
                $where[] = "DATE(p.fecha_creacion) >= ?";
                $params[] = $_GET['fecha_desde'];
                $types .= "s";
            }
            if (!empty($_GET['fecha_hasta'])) {
                $where[] = "DATE(p.fecha_creacion) <= ?";
                $params[] = $_GET['fecha_hasta'];
                $types .= "s";
            }
            break;
        case '30_dias':
            $where[] = "p.fecha_creacion >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            break;
        case '60_dias':
            $where[] = "p.fecha_creacion >= DATE_SUB(NOW(), INTERVAL 60 DAY)";
            break;
        case '90_dias':
            $where[] = "p.fecha_creacion >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
            break;
        case 'envejecidos':
            $where[] = "p.fecha_creacion < DATE_SUB(NOW(), INTERVAL 90 DAY)";
            break;
    }
}

$sql_where = "";
if (!empty($where)) {
    $sql_where = "WHERE " . implode(" AND ", $where);
}

// ============================================
// PAGINACIÓN
// ============================================
$por_pagina = isset($_GET['por_pagina']) ? intval($_GET['por_pagina']) : 25;
$por_pagina = in_array($por_pagina, [25, 50, 100], true) ? $por_pagina : 25;
$pagina_actual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

// ============================================
// CONTAR TOTAL (con filtros)
// ============================================
$count_sql = "SELECT COUNT(*) as total FROM productos p $sql_where";
$stmt_count = $conn->prepare($count_sql);
if (!$stmt_count) {
    error_log("[reporte_productos] prepare count: " . $conn->error);
    $total_registros = 0;
} else {
    if (!empty($params)) {
        $stmt_count->bind_param($types, ...$params);
    }
    $stmt_count->execute();
    $total_registros = intval($stmt_count->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt_count->close();
}

$total_paginas = max(1, (int)ceil($total_registros / $por_pagina));
$pagina_actual = min($pagina_actual, $total_paginas);
$offset = ($pagina_actual - 1) * $por_pagina;

// ============================================
// CONSULTA DE PRODUCTOS (parametrizada LIMIT/OFFSET)
// ============================================
$sql = "SELECT p.*, c.nombre as categoria_nombre, c.icono as categoria_icono, pr.nombre_tienda
        FROM productos p 
        LEFT JOIN categorias c ON p.categoria_id = c.id 
        LEFT JOIN proveedores pr ON p.proveedor_id = pr.id
        $sql_where 
        ORDER BY p.fecha_creacion DESC
        LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log("[reporte_productos] prepare select: " . $conn->error);
    $productos = null;
} else {
    $params_select = $params;
    $types_select = $types . 'ii';
    $params_select[] = $por_pagina;
    $params_select[] = $offset;
    $stmt->bind_param($types_select, ...$params_select);
    $stmt->execute();
    $productos = $stmt->get_result();
}

// ============================================
// TOTALES CON LOS MISMOS FILTROS (¡corregido!)
// ============================================
$totales_sql = "SELECT 
    COUNT(*) as total_productos,
    COALESCE(SUM(p.cantidad), 0) as total_unidades,
    COALESCE(SUM(p.precio_costo * p.cantidad), 0) as total_costo,
    COALESCE(SUM(p.precio * p.cantidad), 0) as total_venta
    FROM productos p
    $sql_where";
$stmt_tot = $conn->prepare($totales_sql);
$totales = [
    'total_productos' => 0,
    'total_unidades' => 0,
    'total_costo' => 0,
    'total_venta' => 0
];
if ($stmt_tot) {
    if (!empty($params)) {
        $stmt_tot->bind_param($types, ...$params);
    }
    $stmt_tot->execute();
    $row = $stmt_tot->get_result()->fetch_assoc();
    if ($row) {
        $totales = $row;
    }
    $stmt_tot->close();
}

// Categorías para filtros
$categorias = $conn->query("SELECT id, nombre, icono FROM categorias WHERE activo = 1 ORDER BY nombre");

// Proveedores para filtro (solo Super Admin)
$lista_proveedores = [];
if ($es_super_admin) {
    $res_prov = $conn->query("SELECT id, nombre_tienda FROM proveedores WHERE activo = 1 ORDER BY nombre_tienda ASC");
    if ($res_prov) {
        while ($p = $res_prov->fetch_assoc()) {
            $lista_proveedores[] = $p;
        }
        $res_prov->free();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Reporte de Productos - Panel de Administración</title>
    <style>
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
        }

        .reportes-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: clamp(0.5rem, 3vw, 1rem);
        }

        .reportes-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .reportes-titulo h1 {
            font-size: clamp(1.3rem, 5vw, 1.8rem);
            color: #2d3748;
            margin: 0;
        }

        .reportes-acciones {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .btn-accion {
            padding: clamp(0.5rem, 2vw, 0.6rem) clamp(1rem, 3vw, 1.2rem);
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: clamp(0.8rem, 2.5vw, 0.9rem);
            text-decoration: none;
            min-height: 44px;
        }

        .btn-imprimir { background: #4299e1; color: white; }
        .btn-excel { background: #48bb78; color: white; }

        .btn-accion:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .totales-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .total-card {
            background: white;
            border-radius: 12px;
            padding: clamp(0.8rem, 3vw, 1rem);
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }

        .total-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .total-icon { font-size: clamp(1.2rem, 4vw, 1.5rem); }
        .total-label { 
            font-size: clamp(0.65rem, 2.5vw, 0.75rem); 
            color: #718096; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
        }
        .total-value { 
            font-size: clamp(1rem, 4vw, 1.2rem); 
            font-weight: 700; 
            color: #2d3748; 
        }

        .filtros-card {
            background: white;
            border-radius: 16px;
            padding: clamp(1rem, 4vw, 1.5rem);
            margin-bottom: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .filtros-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .filtros-row-precios {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .filtro-item label {
            display: block;
            font-size: clamp(0.7rem, 2.5vw, 0.75rem);
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 0.2rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .filtro-item input,
        .filtro-item select {
            width: 100%;
            padding: clamp(0.5rem, 2vw, 0.6rem);
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 16px; /* evita zoom iOS */
            transition: all 0.3s;
            min-height: 44px;
        }

        .filtro-item input:focus,
        .filtro-item select:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
        }

        .filtro-operador {
            display: flex;
            gap: 0.3rem;
        }

        .filtro-operador select {
            width: 70px;
            flex-shrink: 0;
        }

        .filtros-acciones {
            display: flex;
            gap: 0.5rem;
            justify-content: flex-end;
            margin-top: 1rem;
            flex-wrap: wrap;
        }

        .btn-filtro {
            padding: clamp(0.5rem, 2vw, 0.6rem) clamp(1rem, 3vw, 1.2rem);
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: clamp(0.8rem, 2.5vw, 0.9rem);
            transition: all 0.3s;
            min-height: 44px;
        }

        .btn-filtro-aplicar {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
        }

        .btn-filtro-aplicar:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102,126,234,0.3);
        }

        .btn-filtro-limpiar {
            background: #edf2f7;
            color: #4a5568;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            line-height: 44px;
        }

        .btn-filtro-limpiar:hover {
            background: #e2e8f0;
            transform: translateY(-2px);
        }

        .tabla-wrapper {
            background: white;
            border-radius: 16px;
            padding: 1rem;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .tabla-reporte {
            width: 100%;
            border-collapse: collapse;
            font-size: clamp(0.75rem, 2.5vw, 0.85rem);
            min-width: 800px;
        }

        .tabla-reporte th {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: clamp(0.6rem, 2vw, 0.8rem) clamp(0.4rem, 1.5vw, 0.6rem);
            text-align: left;
            font-size: clamp(0.65rem, 2vw, 0.7rem);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .tabla-reporte td {
            padding: clamp(0.6rem, 2vw, 0.8rem) clamp(0.4rem, 1.5vw, 0.6rem);
            border-bottom: 1px solid #edf2f7;
            vertical-align: middle;
        }

        .tabla-reporte tr:hover {
            background: #f8fafc;
        }

        .text-right { text-align: right; }
        .text-center { text-align: center; }

        /* Paginación */
        .paginacion-container {
            display: flex;
            justify-content: center;
            gap: 0.3rem;
            flex-wrap: wrap;
            margin-top: 1.5rem;
        }

        .paginacion-container a,
        .paginacion-container span {
            padding: 0.4rem 0.8rem;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            border: 1px solid #e2e8f0;
            background: white;
            color: #374151;
            min-width: 40px;
            min-height: 44px;
            text-align: center;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .paginacion-container a:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .paginacion-container .active {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-color: var(--primary);
        }

        .paginacion-container .disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        @media print {
            @page {
                size: landscape;
                margin: 1.5cm;
            }
            body * { visibility: hidden; }
            .reportes-container, .reportes-container * { visibility: visible; }
            .reportes-container {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
            .filtros-card, .reportes-acciones, .totales-grid, .btn-accion, .btn-filtro, .filtros-acciones, .paginacion-container {
                display: none !important;
            }
            .tabla-reporte { width: 100%; border-collapse: collapse; }
            .tabla-reporte th, .tabla-reporte td {
                border: 1px solid #000;
                padding: 4px;
            }
            .print-header {
                display: block !important;
                text-align: center;
                margin-bottom: 20px;
            }
            .print-header h1 { font-size: 18pt; }
            .print-header p { font-size: 10pt; }
        }

        @media (max-width: 768px) {
            .filtros-row,
            .filtros-row-precios {
                grid-template-columns: 1fr;
                gap: 0.8rem;
            }
            .filtros-acciones {
                flex-direction: column;
            }
            .btn-filtro, .btn-filtro-limpiar {
                width: 100%;
                text-align: center;
            }
            .reportes-acciones {
                width: 100%;
                justify-content: space-between;
            }
            .btn-accion {
                flex: 1;
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .totales-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .btn-accion span {
                display: none;
            }
            .btn-accion {
                width: 45px;
                padding: 0.6rem;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="reportes-container">
    <!-- Encabezado para impresión -->
    <div class="print-header" style="display: none;">
        <h1>REPORTE DE PRODUCTOS</h1>
        <p>Filtro aplicado: 
            <?php
            $filtros_aplicados = [];
            if (!empty($_GET['nombre'])) $filtros_aplicados[] = "Nombre: " . $_GET['nombre'];
            if (!empty($_GET['categoria'])) {
                $cat_id = intval($_GET['categoria']);
                $cat_nombre = '';
                if ($categorias) {
                    $categorias->data_seek(0);
                    while ($cat = $categorias->fetch_assoc()) {
                        if (intval($cat['id']) === $cat_id) {
                            $cat_nombre = $cat['nombre'];
                            break;
                        }
                    }
                }
                if ($cat_nombre) $filtros_aplicados[] = "Categoría: " . $cat_nombre;
            }
            if (!empty($_GET['cantidad'])) $filtros_aplicados[] = "Cantidad: " . ($_GET['cantidad_operador'] ?? '=') . " " . $_GET['cantidad'];
            if (!empty($_GET['precio_costo'])) $filtros_aplicados[] = "P. Costo: " . ($_GET['costo_operador'] ?? '=') . " $" . $_GET['precio_costo'];
            if (!empty($_GET['precio_venta'])) $filtros_aplicados[] = "P. Venta: " . ($_GET['venta_operador'] ?? '=') . " $" . $_GET['precio_venta'];
            if (!empty($_GET['fecha_tipo'])) {
                $fechas = [
                    '30_dias' => 'Últimos 30 días',
                    '60_dias' => 'Últimos 60 días',
                    '90_dias' => 'Últimos 90 días',
                    'envejecidos' => 'Envejecidos (+90 días)',
                    'rango' => 'Rango personalizado'
                ];
                $filtros_aplicados[] = $fechas[$_GET['fecha_tipo']] ?? $_GET['fecha_tipo'];
            }
            echo htmlspecialchars(!empty($filtros_aplicados) ? implode(' | ', $filtros_aplicados) : 'Sin filtros');
            ?>
        </p>
        <p>Generado por: <?php echo htmlspecialchars($_SESSION['nombre'] ?? 'Usuario'); ?> | Fecha: <?php echo date('d/m/Y H:i:s'); ?></p>
    </div>

    <!-- CABECERA -->
    <div class="reportes-header">
        <div class="reportes-titulo">
            <h1>📦 Reporte de Productos</h1>
        </div>
        
        <div class="reportes-acciones">
            <button onclick="window.print()" class="btn-accion btn-imprimir">
                <span>🖨️</span> <span>Imprimir</span>
            </button>
            <button onclick="exportarExcel()" class="btn-accion btn-excel">
                <span>📊</span> <span>Exportar Excel</span>
            </button>
        </div>
    </div>

    <!-- TOTALES (con filtros aplicados) -->
    <div class="totales-grid">
        <div class="total-card">
            <div class="total-icon">📦</div>
            <div class="total-label">Total Productos</div>
            <div class="total-value"><?php echo intval($totales['total_productos'] ?? 0); ?></div>
        </div>
        <div class="total-card">
            <div class="total-icon">🔢</div>
            <div class="total-label">Total Unidades</div>
            <div class="total-value"><?php echo intval($totales['total_unidades'] ?? 0); ?></div>
        </div>
        <div class="total-card">
            <div class="total-icon">💰</div>
            <div class="total-label">Costo Total (USD)</div>
            <div class="total-value">$<?php echo number_format(floatval($totales['total_costo'] ?? 0), 2); ?></div>
        </div>
        <div class="total-card">
            <div class="total-icon">💵</div>
            <div class="total-label">Venta Total (USD)</div>
            <div class="total-value">$<?php echo number_format(floatval($totales['total_venta'] ?? 0), 2); ?></div>
        </div>
        <div class="total-card">
            <div class="total-icon">📈</div>
            <div class="total-label">Margen (USD)</div>
            <?php $margen = floatval($totales['total_venta'] ?? 0) - floatval($totales['total_costo'] ?? 0); ?>
            <div class="total-value" style="color: <?php echo $margen >= 0 ? '#48bb78' : '#f56565'; ?>">
                $<?php echo number_format($margen, 2); ?>
            </div>
        </div>
    </div>

    <!-- FILTROS -->
    <div class="filtros-card">
        <form method="GET">
            <div class="filtros-row">
                <div class="filtro-item">
                    <label>📝 Nombre del Producto</label>
                    <input type="text" name="nombre" value="<?php echo htmlspecialchars($_GET['nombre'] ?? ''); ?>" placeholder="Buscar producto...">
                </div>
                
                <div class="filtro-item">
                    <label>📌 Categoría</label>
                    <select name="categoria">
                        <option value="">Todas las categorías</option>
                        <?php 
                        if ($categorias) {
                            $categorias->data_seek(0);
                            while($cat = $categorias->fetch_assoc()): 
                            ?>
                                <option value="<?php echo intval($cat['id']); ?>" 
                                    <?php echo (intval($_GET['categoria'] ?? 0) === intval($cat['id'])) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['icono'] ?? ''); ?> <?php echo htmlspecialchars($cat['nombre']); ?>
                                </option>
                            <?php endwhile; 
                        } ?>
                    </select>
                </div>
                
                <?php if ($es_super_admin && !empty($lista_proveedores)): ?>
                <div class="filtro-item">
                    <label>🏪 Proveedor</label>
                    <select name="proveedor_id">
                        <option value="">Todos los proveedores</option>
                        <?php foreach ($lista_proveedores as $prov): ?>
                            <option value="<?php echo intval($prov['id']); ?>" 
                                <?php echo (intval($_GET['proveedor_id'] ?? 0) === intval($prov['id'])) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($prov['nombre_tienda']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                
                <div class="filtro-item">
                    <label>📅 Rango de Fechas</label>
                    <select name="fecha_tipo" onchange="toggleRangoFecha(this)">
                        <option value="">Sin filtro</option>
                        <option value="rango" <?php echo ($_GET['fecha_tipo'] ?? '') == 'rango' ? 'selected' : ''; ?>>Rango personalizado</option>
                        <option value="30_dias" <?php echo ($_GET['fecha_tipo'] ?? '') == '30_dias' ? 'selected' : ''; ?>>Últimos 30 días</option>
                        <option value="60_dias" <?php echo ($_GET['fecha_tipo'] ?? '') == '60_dias' ? 'selected' : ''; ?>>Últimos 60 días</option>
                        <option value="90_dias" <?php echo ($_GET['fecha_tipo'] ?? '') == '90_dias' ? 'selected' : ''; ?>>Últimos 90 días</option>
                        <option value="envejecidos" <?php echo ($_GET['fecha_tipo'] ?? '') == 'envejecidos' ? 'selected' : ''; ?>>Envejecidos (+90 días)</option>
                    </select>
                </div>
            </div>

            <div class="filtros-row-precios">
                <div class="filtro-item">
                    <label>🔢 Cantidad en Stock</label>
                    <div class="filtro-operador">
                        <select name="cantidad_operador">
                            <option value="=" <?php echo ($_GET['cantidad_operador'] ?? '') == '=' ? 'selected' : ''; ?>>Igual a</option>
                            <option value="<" <?php echo ($_GET['cantidad_operador'] ?? '') == '<' ? 'selected' : ''; ?>>Menor que</option>
                            <option value=">" <?php echo ($_GET['cantidad_operador'] ?? '') == '>' ? 'selected' : ''; ?>>Mayor que</option>
                        </select>
                        <input type="number" name="cantidad" value="<?php echo htmlspecialchars($_GET['cantidad'] ?? ''); ?>" placeholder="0" min="0">
                    </div>
                </div>
                
                <div class="filtro-item">
                    <label>💰 Precio de Costo (USD)</label>
                    <div class="filtro-operador">
                        <select name="costo_operador">
                            <option value="=" <?php echo ($_GET['costo_operador'] ?? '') == '=' ? 'selected' : ''; ?>>Igual a</option>
                            <option value="<" <?php echo ($_GET['costo_operador'] ?? '') == '<' ? 'selected' : ''; ?>>Menor que</option>
                            <option value=">" <?php echo ($_GET['costo_operador'] ?? '') == '>' ? 'selected' : ''; ?>>Mayor que</option>
                        </select>
                        <input type="number" name="precio_costo" step="0.01" min="0" value="<?php echo htmlspecialchars($_GET['precio_costo'] ?? ''); ?>" placeholder="0.00">
                    </div>
                </div>
                
                <div class="filtro-item">
                    <label>💵 Precio de Venta (USD)</label>
                    <div class="filtro-operador">
                        <select name="venta_operador">
                            <option value="=" <?php echo ($_GET['venta_operador'] ?? '') == '=' ? 'selected' : ''; ?>>Igual a</option>
                            <option value="<" <?php echo ($_GET['venta_operador'] ?? '') == '<' ? 'selected' : ''; ?>>Menor que</option>
                            <option value=">" <?php echo ($_GET['venta_operador'] ?? '') == '>' ? 'selected' : ''; ?>>Mayor que</option>
                        </select>
                        <input type="number" name="precio_venta" step="0.01" min="0" value="<?php echo htmlspecialchars($_GET['precio_venta'] ?? ''); ?>" placeholder="0.00">
                    </div>
                </div>
            </div>

            <div id="rango_fechas" style="display: <?php echo ($_GET['fecha_tipo'] ?? '') == 'rango' ? 'block' : 'none'; ?>; margin-bottom: 1rem;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <input type="date" name="fecha_desde" value="<?php echo htmlspecialchars($_GET['fecha_desde'] ?? ''); ?>" placeholder="Desde" style="padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 16px; min-height: 44px;">
                    <input type="date" name="fecha_hasta" value="<?php echo htmlspecialchars($_GET['fecha_hasta'] ?? ''); ?>" placeholder="Hasta" style="padding: 0.6rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 16px; min-height: 44px;">
                </div>
            </div>

            <div class="filtros-acciones">
                <button type="submit" class="btn-filtro btn-filtro-aplicar">Aplicar Filtros</button>
                <a href="/reportes/reporte_productos.php" class="btn-filtro btn-filtro-limpiar">Limpiar Filtros</a>
            </div>
        </form>
    </div>

    <!-- TABLA DE PRODUCTOS -->
    <div class="tabla-wrapper">
        <table class="tabla-reporte" id="tablaProductos">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Cantidad</th>
                    <th>P. Costo (USD)</th>
                    <th>Importe Costo</th>
                    <th>P. Venta (USD)</th>
                    <th>Importe Venta</th>
                    <th>Margen</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($productos && $productos->num_rows > 0): 
                    while($p = $productos->fetch_assoc()): 
                        $importe_costo = floatval($p['precio_costo']) * intval($p['cantidad']);
                        $importe_venta = floatval($p['precio']) * intval($p['cantidad']);
                        $margen = $importe_venta - $importe_costo;
                        $porcentaje = $importe_costo > 0 ? ($margen / $importe_costo) * 100 : 0;
                        $ts_creacion = strtotime($p['fecha_creacion'] ?? '');
                        $fecha_str = ($ts_creacion !== false) ? date('d/m/Y', $ts_creacion) : '—';
                ?>
                <tr>
                    <td class="text-center">#<?php echo intval($p['id']); ?></td>
                    <td><strong><?php echo htmlspecialchars($p['nombre']); ?></strong></td>
                    <td><?php echo htmlspecialchars($p['categoria_icono'] ?? '📦'); ?> <?php echo htmlspecialchars($p['categoria_nombre'] ?? 'Sin categoría'); ?></td>
                    <td class="text-center"><?php echo intval($p['cantidad']); ?></td>
                    <td class="text-right">$<?php echo number_format(floatval($p['precio_costo']), 2); ?></td>
                    <td class="text-right">$<?php echo number_format($importe_costo, 2); ?></td>
                    <td class="text-right">$<?php echo number_format(floatval($p['precio']), 2); ?></td>
                    <td class="text-right">$<?php echo number_format($importe_venta, 2); ?></td>
                    <td class="text-right" style="color: <?php echo $margen >= 0 ? '#48bb78' : '#f56565'; ?>">
                        $<?php echo number_format($margen, 2); ?> (<?php echo number_format($porcentaje, 1); ?>%)
                    </td>
                    <td><?php echo $fecha_str; ?></td>
                </tr>
                <?php endwhile; ?>
                <?php else: ?>
                <tr>
                    <td colspan="10" class="text-center" style="padding: 3rem;">📭 No hay productos para mostrar con los filtros seleccionados</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- PAGINACIÓN -->
    <?php if ($total_paginas > 1): 
        $query_params = $_GET;
    ?>
    <div class="paginacion-container">
        <?php if ($pagina_actual > 1): ?>
            <?php $query_params['pagina'] = 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">«</a>
            <?php $query_params['pagina'] = $pagina_actual - 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">‹</a>
        <?php else: ?>
            <span class="disabled">«</span>
            <span class="disabled">‹</span>
        <?php endif; ?>

        <?php
        $rango = 3;
        $inicio = max(1, $pagina_actual - $rango);
        $fin = min($total_paginas, $pagina_actual + $rango);

        if ($inicio > 1) {
            $query_params['pagina'] = 1;
            echo '<a href="?' . http_build_query($query_params) . '">1</a>';
            if ($inicio > 2) echo '<span>…</span>';
        }

        for ($i = $inicio; $i <= $fin; $i++) {
            if ($i == $pagina_actual) {
                echo '<span class="active">' . $i . '</span>';
            } else {
                $query_params['pagina'] = $i;
                echo '<a href="?' . http_build_query($query_params) . '">' . $i . '</a>';
            }
        }

        if ($fin < $total_paginas) {
            if ($fin < $total_paginas - 1) echo '<span>…</span>';
            $query_params['pagina'] = $total_paginas;
            echo '<a href="?' . http_build_query($query_params) . '">' . $total_paginas . '</a>';
        }
        ?>

        <?php if ($pagina_actual < $total_paginas): ?>
            <?php $query_params['pagina'] = $pagina_actual + 1; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">›</a>
            <?php $query_params['pagina'] = $total_paginas; ?>
            <a href="?<?php echo http_build_query($query_params); ?>">»</a>
        <?php else: ?>
            <span class="disabled">›</span>
            <span class="disabled">»</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<script>
function toggleRangoFecha(select) {
    const rangoDiv = document.getElementById('rango_fechas');
    rangoDiv.style.display = select.value === 'rango' ? 'block' : 'none';
}

function exportarExcel() {
    const tablaOriginal = document.querySelector('.tabla-reporte');
    const tabla = tablaOriginal.cloneNode(true);
    let htmlContent = tabla.outerHTML;
    const prefijo = '<html><head><meta charset="UTF-8"></head><body>';
    const sufijo = '</body></html>';
    const contenidoFinal = prefijo + htmlContent + sufijo;
    
    const blob = new Blob([contenidoFinal], { type: 'application/vnd.ms-excel;charset=UTF-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'reporte_productos.xls';
    a.click();
    URL.revokeObjectURL(url);
}

window.addEventListener('load', function() {
    const fechaSelect = document.querySelector('select[name="fecha_tipo"]');
    if (fechaSelect && fechaSelect.value === 'rango') {
        document.getElementById('rango_fechas').style.display = 'block';
    }
});
</script>

<?php
require_once __DIR__ . '/../footer.php';
?>